<?php
session_start();
require_once __DIR__ . '/core/dmd_mfa.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$email = isset($_SESSION['user']['email']) ? dmd_safe_user_key($_SESSION['user']['email']) : '';
if ($email === '' && isset($_SESSION['dmd_mfa_enroll_pending']) && is_array($_SESSION['dmd_mfa_enroll_pending'])) {
    $pending = $_SESSION['dmd_mfa_enroll_pending'];
    $issuedAt = (int)($pending['issued_at'] ?? 0);
    if ($issuedAt > 0 && time() - $issuedAt <= 600) {
        $email = dmd_safe_user_key((string)($pending['email'] ?? ''));
    }
}
$setup = isset($_SESSION['dmd_mfa_setup']) && is_array($_SESSION['dmd_mfa_setup']) ? $_SESSION['dmd_mfa_setup'] : array();

if (
    $email === '' ||
    empty($setup['email']) ||
    !hash_equals($email, (string)$setup['email']) ||
    empty($setup['secret']) ||
    empty($setup['created_at']) ||
    (time() - (int)$setup['created_at']) > 900
) {
    http_response_code(403);
    exit;
}

require_once __DIR__ . '/core/vendor/phpqrcode.php';
$uri = dmd_mfa_otpauth_uri($email, (string)$setup['secret']);
$matrix = QRcode::text($uri, false, QR_ECLEVEL_M, 1, 4);
if (!is_array($matrix) || empty($matrix)) {
    http_response_code(500);
    exit;
}

$modules = count($matrix);
$margin = 4;
$size = $modules + ($margin * 2);

header('Content-Type: image/svg+xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $size . ' ' . $size . '" shape-rendering="crispEdges">';
echo '<rect width="100%" height="100%" fill="#fff"/>';
echo '<path fill="#000" d="';
for ($y = 0; $y < $modules; $y++) {
    $row = (string)$matrix[$y];
    for ($x = 0; $x < strlen($row); $x++) {
        if ($row[$x] === '1') {
            echo 'M' . ($x + $margin) . ' ' . ($y + $margin) . 'h1v1h-1z';
        }
    }
}
echo '"/></svg>';
