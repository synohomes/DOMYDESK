<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../core/dmd_permissions.php';

if (empty($_SESSION['user']['email'])) {
    $currentUrl = $_SERVER['REQUEST_URI'] ?? '/modules/modules.php';

    header('Location: /domydesk/login.php?redirect=' . rawurlencode($currentUrl));
    exit;
}

$userEmail = $_SESSION['user']['email'];
$userDir   = __DIR__ . "/../users/profiles/" . $userEmail;
$themeFile = $userDir . "/theme.json";

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_initial($text) {
    $text = trim((string)$text);

    if ($text === '') {
        return '?';
    }

    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($text, 0, 1, 'UTF-8'), 'UTF-8');
    }

    return strtoupper(substr($text, 0, 1));
}

function dmd_icon_path($mod) {
    $id = $mod['id'] ?? '';

    if (!empty($mod['icon'])) {
        $icon = trim((string)$mod['icon']);

        if (preg_match('#^https?://#i', $icon)) {
            return $icon;
        }

        return "../" . ltrim($icon, "/");
    }

    return "../modules/" . rawurlencode($id) . "/icon.png";
}

$theme = 'default';

if (file_exists($themeFile)) {
    $themeData = json_decode(file_get_contents($themeFile), true);

    if (
        !empty($themeData['theme']) &&
        file_exists(__DIR__ . "/../theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
}

$allModules = array_values(dmd_effective_modules($userEmail, false));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['module_id'], $_POST['action'])) {
    $modId  = trim((string)$_POST['module_id']);
    $action = trim((string)$_POST['action']);

    if ($action === 'enable') {
        dmd_set_user_module_enabled($userEmail, $modId, true);
    } elseif ($action === 'disable') {
        dmd_set_user_module_enabled($userEmail, $modId, false);
    }

    $returnPanel = isset($_POST['return_panel']) ? $_POST['return_panel'] : 'panel_all';
    $returnPanel = preg_replace('/[^a-zA-Z0-9_\-]/', '', $returnPanel);

    header('Location: ' . $_SERVER['PHP_SELF'] . '#' . $returnPanel);
    exit;
}

$allModulesClean  = [];
$enabledModules   = [];
$disabledModules  = [];

foreach ($allModules as $mod) {
    if (empty($mod['id'])) {
        continue;
    }

    $id = (string)$mod['id'];
    $enabled = dmd_user_module_is_enabled($userEmail, $id);

    $mod['_enabled'] = $enabled;

    $allModulesClean[] = $mod;

    if ($enabled) {
        $enabledModules[] = $mod;
    } else {
        $disabledModules[] = $mod;
    }
}

$totalModules  = count($allModulesClean);
$totalEnabled  = count($enabledModules);
$totalDisabled = count($disabledModules);

$panels = [
    [
        'id'       => 'panel_all',
        'title'    => 'Tous les modules',
        'subtitle' => $totalModules . ' module' . ($totalModules > 1 ? 's' : ''),
        'icon'     => 'T',
        'modules'  => $allModulesClean
    ],
    [
        'id'       => 'panel_enabled',
        'title'    => 'Modules activés',
        'subtitle' => $totalEnabled . ' activé' . ($totalEnabled > 1 ? 's' : ''),
        'icon'     => '✓',
        'modules'  => $enabledModules
    ],
    [
        'id'       => 'panel_disabled',
        'title'    => 'Modules désactivés',
        'subtitle' => $totalDisabled . ' désactivé' . ($totalDisabled > 1 ? 's' : ''),
        'icon'     => '×',
        'modules'  => $disabledModules
    ]
];

$firstPanel = 'panel_all';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modules disponibles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../theme/<?php echo h($theme); ?>/style.css">

    
</head>

<body>
<?php include __DIR__ . '/../header.php'; ?>

<main class="modules-page">
    <div class="modules-header">
        <div class="modules-title-block">
            <h1>Modules disponibles</h1>
            <p>Affichez ou masquez les modules auxquels votre rôle ou un administrateur vous donne accès.</p>
        </div>

        <div class="modules-stats">
            <div class="modules-stat">
                <?= intval($totalModules) ?> module<?= $totalModules > 1 ? 's' : '' ?>
            </div>

            <div class="modules-stat">
                <?= intval($totalEnabled) ?> activé<?= $totalEnabled > 1 ? 's' : '' ?>
            </div>

            <div class="modules-stat">
                <?= intval($totalDisabled) ?> désactivé<?= $totalDisabled > 1 ? 's' : '' ?>
            </div>
        </div>
    </div>

    <section class="modules-tabs-zone">
        <h2 class="modules-tabs-title">Affichage</h2>

        <div class="modules-tabs-grid">
            <?php foreach ($panels as $panel): ?>
                <button
                    type="button"
                    class="modules-tab-card"
                    data-panel="<?= h($panel['id']) ?>"
                >
                    <span class="modules-tab-main">
                        <span class="modules-tab-icon"><?= h($panel['icon']) ?></span>

                        <span>
                            <span class="modules-tab-name"><?= h($panel['title']) ?></span>
                            <span class="modules-tab-count"><?= h($panel['subtitle']) ?></span>
                        </span>
                    </span>
                </button>
            <?php endforeach; ?>
        </div>
    </section>

    <?php foreach ($panels as $panel): ?>
        <section
            id="<?= h($panel['id']) ?>"
            class="modules-panel <?= $panel['id'] === $firstPanel ? 'is-active' : '' ?>"
            data-panel-content="<?= h($panel['id']) ?>"
        >
            <div class="modules-panel-head">
                <h2 class="modules-panel-title"><?= h($panel['title']) ?></h2>
                <div class="modules-panel-subtitle"><?= h($panel['subtitle']) ?></div>
            </div>

            <?php if (empty($panel['modules'])): ?>
                <div class="modules-empty">
                    Aucun module dans cette liste.
                </div>
            <?php else: ?>
                <div class="modules-grid">
                    <?php foreach ($panel['modules'] as $mod): ?>
                        <?php
                            $id = $mod['id'] ?? '';

                            if ($id === '') {
                                continue;
                            }

                            $name        = $mod['name'] ?? $id;
                            $description = $mod['description'] ?? '';
                            $enabled     = dmd_user_module_is_enabled($userEmail, $id);
                            $iconPath    = dmd_icon_path($mod);
                            $fallback    = dmd_initial($name);
                        ?>

                        <article class="module-card <?= $enabled ? 'is-enabled' : 'is-disabled' ?>">
                            <div class="module-card-top">
                                <div class="module-icon-box">
                                    <span class="module-fallback-icon"><?= h($fallback) ?></span>

                                    <img
                                        class="module-icon"
                                        src="<?= h($iconPath) ?>"
                                        alt=""
                                        onload="this.previousElementSibling.style.display='none'"
                                        onerror="this.style.display='none'"
                                    >
                                </div>

                                <div class="module-main">
                                    <h3 class="module-name" title="<?= h($name) ?>">
                                        <?= h($name) ?>
                                    </h3>
                                </div>
                            </div>

                            <p class="module-desc" title="<?= h($description) ?>">
                                <?= h($description) ?>
                            </p>

                            <div class="module-card-bottom">
                                <span class="module-status <?= $enabled ? 'is-on' : 'is-off' ?>">
                                    <?= $enabled ? 'Activé' : 'Désactivé' ?>
                                </span>

                                <form method="post" class="module-action-form">
                                    <input type="hidden" name="module_id" value="<?= h($id) ?>">
                                    <input type="hidden" name="return_panel" value="<?= h($panel['id']) ?>">

                                    <button
                                        class="module-btn <?= $enabled ? 'is-disable' : 'is-enable' ?>"
                                        type="submit"
                                        name="action"
                                        value="<?= $enabled ? 'disable' : 'enable' ?>"
                                    >
                                        <?= $enabled ? 'Désactiver' : 'Activer' ?>
                                    </button>
                                </form>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.modules-tab-card[data-panel]');
    const panels = document.querySelectorAll('.modules-panel[data-panel-content]');

    function showPanel(panelId, updateHash = true) {
        buttons.forEach(function (button) {
            button.classList.toggle('is-active', button.dataset.panel === panelId);
        });

        panels.forEach(function (panel) {
            panel.classList.toggle('is-active', panel.dataset.panelContent === panelId);
        });

        if (updateHash) {
            history.replaceState(null, '', '#' + panelId);
        }
    }

    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            showPanel(button.dataset.panel);
        });
    });

    const hashPanel = window.location.hash ? window.location.hash.substring(1) : '';
    const hashExists = hashPanel && document.querySelector('[data-panel-content="' + CSS.escape(hashPanel) + '"]');

    if (hashExists) {
        showPanel(hashPanel, false);
        return;
    }

    showPanel('<?= h($firstPanel) ?>', false);
});
</script>

</body>
</html>