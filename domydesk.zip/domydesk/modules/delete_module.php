<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: text/plain; charset=utf-8');

require_once dirname(__DIR__) . '/core/dmd_permissions.php';

$currentEmail = $_SESSION['user']['email'] ?? '';
$currentProfile = $currentEmail !== '' ? dmd_read_profile($currentEmail) : [];

if (!dmd_is_system_admin_profile($currentProfile)) {
    http_response_code(403);
    exit("⛔ Accès refusé (admin requis).");
}

$raw = $_GET['id'] ?? $_POST['id'] ?? $_POST['module_id'] ?? '';
$raw = trim((string)$raw);
if ($raw === '') {
    http_response_code(400);
    exit("⛔ ID module manquant (paramètre id/module_id).");
}

$id = strtolower(basename($raw));
$DEBUG = isset($_GET['debug']) || isset($_POST['debug']);
$modulesDir = realpath(__DIR__);
$baseDir = dirname($modulesDir);
$listPath = $modulesDir . '/list.json';
$moduleDir = $modulesDir . '/' . $id;

function load_json_safe($p) {
    $t = @file_get_contents($p);
    if ($t === false) return [];
    $j = json_decode($t, true);
    return is_array($j) ? $j : [];
}

function save_json_safe($p, $arr) {
    @file_put_contents($p, json_encode($arr, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    @chmod($p, 0644);
}

function rrmdir_simple($dir) {
    if (!is_dir($dir)) return;
    foreach (array_diff(scandir($dir), ['.', '..']) as $it) {
        $path = $dir . '/' . $it;
        if (is_dir($path)) rrmdir_simple($path); else @unlink($path);
    }
    @rmdir($dir);
}

if ($DEBUG) {
    echo ">> DEBUG ON\nID: $id\n";
    echo "list.json     : " . (realpath($listPath) ?: $listPath) . "\n";
    echo "modules dir   : " . (realpath($modulesDir) ?: $modulesDir) . "\n\n";
}

$removedGlobal = 0;
if (is_file($listPath)) {
    $list = load_json_safe($listPath);
    $new = [];
    foreach ($list as $row) {
        $rid = strtolower(trim($row['id'] ?? ''));
        $icon = strtolower(trim($row['icon'] ?? ''));
        $match = ($rid === $id) || ($icon && strpos($icon, '/' . $id . '/') !== false);
        if (!$match) $new[] = $row;
    }
    $removedGlobal = count($list) - count($new);
    save_json_safe($listPath, $new);
}

// DoMyDesk 1.2.0 : les droits rôles/utilisateurs sont persistants.
// Désinstaller le code d'un module ne supprime donc plus ses ACL.
if (is_dir($moduleDir)) {
    rrmdir_simple($moduleDir);
}

echo "✅ Suppression terminée pour l’ID \"$id\".\n";
echo "- list.json: " . ($removedGlobal ? "entrée supprimée" : "aucune entrée trouvée") . "\n";
echo "- droits rôles/utilisateurs: conservés\n";
