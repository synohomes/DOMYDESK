<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_media.php';

if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$viewerEmail = $_SESSION['user']['email'];
$viewerProfile = dmd_read_profile($viewerEmail);
$viewerRole = $viewerProfile['role_system'] ?? 'user';

$viewerDir = __DIR__ . '/users/profiles/' . $viewerEmail . '/';
$themeJson = $viewerDir . 'theme.json';
$theme     = 'default';

if (file_exists($themeJson)) {
    $themeData = json_decode(file_get_contents($themeJson), true);

    if (
        !empty($themeData['theme']) &&
        file_exists(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
}

$targetEmail = isset($_GET['user']) ? urldecode($_GET['user']) : $viewerEmail;

if (
    strpos($targetEmail, '..') !== false ||
    strpos($targetEmail, '/') !== false ||
    strpos($targetEmail, '\\') !== false
) {
    die('Paramètre utilisateur invalide.');
}

$targetDir   = __DIR__ . '/users/profiles/' . $targetEmail . '/';
$profilePath = dmd_profile_path($targetEmail, true);
$avatarPath  = dmd_user_avatar_file($targetEmail);
$siteMediaSettings = dmd_site_settings_read();
$bannerPath = dmd_effective_user_banner_file($targetEmail, $siteMediaSettings);
$avatarUrl = $avatarPath !== '' ? dmd_media_public_url($avatarPath) : '';
$bannerUrl = $bannerPath !== '' ? dmd_media_public_url($bannerPath) : '';

if (!file_exists($profilePath)) {
    die('Profil introuvable.');
}

$profile = dmd_read_profile($targetEmail);
$modules = array_values(dmd_effective_modules($targetEmail, true));

if (!is_array($profile) || empty($profile)) {
    die('Profil invalide.');
}

$canEdit = (
    $targetEmail === $viewerEmail ||
    in_array($viewerRole, ['admin', 'superadmin'], true)
);

$profileTitle = trim(($profile['prenom'] ?? '') . ' ' . ($profile['nom'] ?? ''));
if ($profileTitle === '') {
    $profileTitle = $profile['email'] ?? $targetEmail;
}

$enabledModules = $modules;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Profil de <?= htmlspecialchars($profileTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS du thème choisi par l'utilisateur -->
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <link rel="stylesheet" href="core/dmd_profile_media.css?v=<?= is_file(__DIR__ . '/core/dmd_profile_media.css') ? (int)filemtime(__DIR__ . '/core/dmd_profile_media.css') : 120 ?>">
</head>

<body>

<?php include 'header.php'; ?>

<div class="profile-scope">
    <h1>Fiche utilisateur</h1>

    <div class="section">
        <div class="dmd-profile-cover<?= $bannerUrl !== '' ? ' has-banner' : '' ?>">
            <?php if ($bannerUrl !== ''): ?>
                <img class="dmd-profile-cover-image" src="<?= htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Bannière du profil">
            <?php endif; ?>
            <div class="dmd-profile-cover-identity">
                <?php if ($avatarUrl !== ''): ?>
                    <img class="dmd-profile-cover-avatar" src="<?= htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Avatar">
                <?php else: ?>
                    <div class="dmd-profile-cover-avatar-fallback">
                        <?= htmlspecialchars(strtoupper(substr(trim((string)($profile['prenom'] ?? $profileTitle)), 0, 1)), ENT_QUOTES, 'UTF-8') ?>
                    </div>
                <?php endif; ?>
                <div class="dmd-profile-cover-copy">
                    <h2><?= htmlspecialchars($profileTitle, ENT_QUOTES, 'UTF-8') ?></h2>
                    <p><?= htmlspecialchars($profile['email'] ?? $targetEmail, ENT_QUOTES, 'UTF-8') ?></p>
                </div>
            </div>
            <?php if ($canEdit): ?>
                <a href="profile_edit.php?email=<?= urlencode($targetEmail) ?>" class="edit-icon" title="Modifier le profil">✏️ Modifier</a>
            <?php endif; ?>
        </div>

        <div class="info">
            <p><strong>Prénom :</strong> <?= htmlspecialchars($profile['prenom'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
            <p><strong>Nom :</strong> <?= htmlspecialchars($profile['nom'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
            <?php if (!empty($profile['pseudo'])): ?><p><strong>Pseudo :</strong> <?= htmlspecialchars($profile['pseudo'], ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
            <p><strong>Rôle système :</strong> <?= htmlspecialchars($profile['role_system'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
            <p><strong>Rôle métier :</strong> <?= htmlspecialchars($profile['role_metier'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
        </div>

        <div class="modules">
            <h2>Modules activés :</h2>

            <?php if (!empty($enabledModules)): ?>
                <ul>
                    <?php foreach ($enabledModules as $module): ?>
                        <li>
                            <?= htmlspecialchars($module['name'] ?? $module['id'] ?? 'Module', ENT_QUOTES, 'UTF-8') ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Aucun module activé.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="back-links">
        <a class="back-link" href="dashboard.php">
            ← Retour au dashboard
        </a>

        <a class="back-link" href="members.php">
            ← Retour à la liste des membres
        </a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const scope = document.querySelector('.profile-scope');
    const section = scope?.querySelector('.section');

    if (!scope || !section) {
        return;
    }

    const cs = getComputedStyle(section);
    const accent = cs.borderTopColor || cs.borderColor;

    if (accent) {
        scope.style.setProperty('--accent', accent);
    }
});
</script>

</body>
</html>