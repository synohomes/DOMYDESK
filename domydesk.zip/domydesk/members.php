<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_system_services.php';
require_once __DIR__ . '/core/dmd_media.php';

if (!isset($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

dmd_require_page_access('members');

$currentEmail = $_SESSION['user']['email'];
$currentProfile = dmd_read_profile($currentEmail);
$currentUserRole = $currentProfile['role_system'] ?? ($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? 'user'));
$isSystemAdmin = in_array($currentUserRole, ['admin', 'superadmin'], true);
$isSuperadminCurrent = ($currentUserRole === 'superadmin');

$baseDir = __DIR__;
$profilesDir = $baseDir . '/users/profiles/';
$presenceDir = $baseDir . '/data/presence/';
$presenceFile = $presenceDir . 'users.json';
$presenceTtl = 180;
$siteMediaSettings = dmd_site_settings_read();
$siteDefaultBannerFile = dmd_site_asset_file($siteMediaSettings, 'banner_path');
$siteDefaultBannerUrl = $siteDefaultBannerFile !== '' ? dmd_media_public_url($siteDefaultBannerFile) : '';

$csrfToken = $_SESSION['members_csrf'] ?? bin2hex(random_bytes(32));
$_SESSION['members_csrf'] = $csrfToken;

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function safeUserFolderName($email) {
    $email = (string)$email;

    if ($email === '' || strpos($email, '..') !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) {
        return null;
    }

    return $email;
}

function readJsonFile($path, $fallback = []) {
    if (!is_file($path)) {
        return $fallback;
    }

    $raw = file_get_contents($path);

    if ($raw === false || trim($raw) === '') {
        return $fallback;
    }

    $data = json_decode($raw, true);

    return is_array($data) ? $data : $fallback;
}

function writeJsonFile($path, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return $json !== false && file_put_contents($path, $json, LOCK_EX) !== false;
}

function ensureDirectory($dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }
}

function updatePresence($presenceDir, $presenceFile, $email, $ttl = 180) {
    $email = trim((string)$email);
    if ($email === '') {
        return;
    }

    ensureDirectory($presenceDir);

    $htaccess = $presenceDir . '.htaccess';
    if (!is_file($htaccess)) {
        file_put_contents($htaccess, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
    }

    $now = time();
    $presence = readJsonFile($presenceFile, []);

    if (!is_array($presence)) {
        $presence = [];
    }

    foreach ($presence as $presenceEmail => $item) {
        $lastSeen = (int)($item['last_seen'] ?? 0);
        if ($lastSeen <= 0 || ($now - $lastSeen) > ($ttl * 2)) {
            unset($presence[$presenceEmail]);
        }
    }

    $presence[$email] = [
        'email' => $email,
        'session_id' => session_id(),
        'last_seen' => $now,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ];

    writeJsonFile($presenceFile, $presence);
}

function getOnlineUsers($presenceFile, $ttl = 180) {
    $presence = readJsonFile($presenceFile, []);
    $online = [];
    $now = time();

    if (!is_array($presence)) {
        return $online;
    }

    foreach ($presence as $email => $item) {
        $lastSeen = (int)($item['last_seen'] ?? 0);
        if ($lastSeen > 0 && ($now - $lastSeen) <= $ttl) {
            $online[$email] = [
                'last_seen' => $lastSeen,
                'last_seen_label' => date('d/m/Y à H:i', $lastSeen),
            ];
        }
    }

    return $online;
}

function countModules($modules) {
    $total = 0;
    $enabled = 0;
    $enabledList = [];

    if (!is_array($modules)) {
        return [
            'total' => 0,
            'enabled' => 0,
            'enabled_list' => []
        ];
    }

    foreach ($modules as $module) {
        if (!is_array($module)) {
            continue;
        }

        $total++;

        if (!empty($module['enabled'])) {
            $enabled++;
            $enabledList[] = [
                'id' => $module['id'] ?? '',
                'name' => $module['name'] ?? ($module['id'] ?? 'Module'),
                'description' => $module['description'] ?? ''
            ];
        }
    }

    return [
        'total' => $total,
        'enabled' => $enabled,
        'enabled_list' => $enabledList
    ];
}

function firstLetter($value) {
    $value = trim((string)$value);

    if ($value === '') {
        return '';
    }

    if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
        return mb_strtoupper(mb_substr($value, 0, 1));
    }

    return strtoupper(substr($value, 0, 1));
}

function userInitials($prenom, $nom, $email) {
    $letters = firstLetter($prenom) . firstLetter($nom);

    if ($letters === '') {
        $letters = firstLetter($email);
    }

    return $letters;
}

function normalizeRolesMetier($rawRoles) {
    $roles = [];

    if (!is_array($rawRoles)) {
        return $roles;
    }

    foreach ($rawRoles as $key => $value) {
        if (is_string($value)) {
            $roles[] = $value;
        } elseif (is_array($value)) {
            if (!empty($value['name'])) {
                $roles[] = $value['name'];
            } elseif (!empty($value['label'])) {
                $roles[] = $value['label'];
            } elseif (is_string($key)) {
                $roles[] = $key;
            }
        } elseif (is_string($key)) {
            $roles[] = $key;
        }
    }

    $roles = array_values(array_unique(array_filter($roles)));
    sort($roles, SORT_NATURAL | SORT_FLAG_CASE);

    return $roles;
}

function formatCreatedAt($createdAt) {
    $createdAt = trim((string)$createdAt);

    if ($createdAt === '') {
        return 'Non renseignée';
    }

    $timestamp = strtotime($createdAt);

    if ($timestamp === false) {
        return $createdAt;
    }

    return date('d/m/Y à H:i', $timestamp);
}


function dmd_members_ad_group_label($dn) {
    $dn = trim((string)$dn);
    if ($dn === '') {
        return '';
    }

    $first = preg_split('/(?<!\\\\),/', $dn, 2);
    $first = trim((string)($first[0] ?? $dn));
    if (preg_match('/^CN=(.*)$/i', $first, $m)) {
        $value = (string)$m[1];
        $value = preg_replace_callback('/\\\\([0-9A-Fa-f]{2})/', static function ($match) {
            return chr(hexdec($match[1]));
        }, $value);
        return strtr($value, [
            '\\,' => ',',
            '\\=' => '=',
            '\\+' => '+',
            '\\#' => '#',
            '\\;' => ';',
            '\\\\' => '\\',
        ]);
    }

    return $first;
}

function dmd_members_ad_info($profile) {
    if (!is_array($profile)) {
        return [
            'is_ad' => false,
            'username' => '',
            'full_username' => '',
            'netbios_domain' => '',
            'dns_domain' => '',
            'groups' => [],
            'last_sync_at' => '',
        ];
    }

    $containers = [$profile];

    foreach (['ad', 'ad_identity', 'active_directory', 'directory', 'ldap', 'identity', 'auth'] as $containerKey) {
        if (isset($profile[$containerKey]) && is_array($profile[$containerKey])) {
            $containers[] = $profile[$containerKey];
        }
    }

    $username = '';
    $upn = '';
    $netbiosDomain = '';
    $dnsDomain = '';
    $memberOf = [];
    $lastSyncAt = '';

    $samKeys = [
        'samaccountname',
        'sam_account_name',
        'sAMAccountName',
        'ad_samaccountname',
        'ad_sam_account_name',
        'ad_username',
        'ad_login',
        'ldap_username',
        'ldap_login',
        'username',
        'login',
    ];

    $upnKeys = [
        'userprincipalname',
        'user_principal_name',
        'userPrincipalName',
        'ad_upn',
        'upn',
    ];

    $netbiosKeys = [
        'netbios_domain',
        'netbios_name',
        'domain_netbios',
        'ad_netbios_domain',
        'ad_domain_short',
    ];

    $dnsDomainKeys = [
        'domain',
        'dns_domain',
        'ad_domain',
        'domain_dns',
    ];

    foreach ($containers as $container) {
        foreach ($samKeys as $key) {
            if (array_key_exists($key, $container)) {
                $candidate = trim((string)$container[$key]);
                if ($candidate !== '') {
                    $username = $candidate;
                    break 2;
                }
            }
        }
    }

    foreach ($containers as $container) {
        foreach ($upnKeys as $key) {
            if (array_key_exists($key, $container)) {
                $candidate = trim((string)$container[$key]);
                if ($candidate !== '') {
                    $upn = $candidate;
                    break 2;
                }
            }
        }
    }

    foreach ($containers as $container) {
        foreach ($netbiosKeys as $key) {
            if (array_key_exists($key, $container)) {
                $candidate = trim((string)$container[$key]);
                if ($candidate !== '') {
                    $netbiosDomain = $candidate;
                    break 2;
                }
            }
        }
    }

    foreach ($containers as $container) {
        foreach ($dnsDomainKeys as $key) {
            if (array_key_exists($key, $container)) {
                $candidate = trim((string)$container[$key]);
                if ($candidate !== '') {
                    $dnsDomain = $candidate;
                    break 2;
                }
            }
        }
    }

    foreach ($containers as $container) {
        foreach (['member_of', 'memberof', 'memberOf', 'ad_member_of'] as $key) {
            if (isset($container[$key]) && is_array($container[$key])) {
                $memberOf = array_values(array_filter(array_map('strval', $container[$key]), static fn($v) => trim($v) !== ''));
                if ($memberOf) {
                    break 2;
                }
            }
        }
    }

    foreach ($containers as $container) {
        foreach (['last_sync_at', 'ad_last_sync_at', 'sync_at', 'last_directory_sync'] as $key) {
            if (isset($container[$key]) && !is_array($container[$key])) {
                $candidate = trim((string)$container[$key]);
                if ($candidate !== '') {
                    $lastSyncAt = $candidate;
                    break 2;
                }
            }
        }
    }

    if ($username === '' && $upn !== '') {
        $username = trim((string)strtok($upn, '@'));
        if ($username === '') {
            $username = $upn;
        }
    }

    if ($dnsDomain === '' && strpos($upn, '@') !== false) {
        $dnsDomain = trim((string)substr($upn, strpos($upn, '@') + 1));
    }

    $sourceValues = [];
    foreach ([
        'auth_source', 'source_auth', 'authentication_source', 'identity_source',
        'directory_source', 'provider', 'auth_provider', 'account_source'
    ] as $sourceKey) {
        if (isset($profile[$sourceKey]) && !is_array($profile[$sourceKey])) {
            $sourceValues[] = strtolower(trim((string)$profile[$sourceKey]));
        }
    }

    foreach ($containers as $container) {
        foreach (['source', 'provider', 'type', 'auth_source'] as $sourceKey) {
            if (isset($container[$sourceKey]) && !is_array($container[$sourceKey])) {
                $sourceValues[] = strtolower(trim((string)$container[$sourceKey]));
            }
        }
    }

    $isAd = false;
    foreach ($sourceValues as $sourceValue) {
        if (in_array($sourceValue, ['ad', 'active_directory', 'active directory', 'ldap', 'domain'], true)) {
            $isAd = true;
            break;
        }
    }

    $identityMarkerKeys = [
        'objectguid', 'object_guid', 'ad_object_guid', 'objectsid', 'object_sid',
        'ad_object_sid', 'distinguishedname', 'distinguished_name', 'ad_dn',
        'ad_distinguished_name', 'directory_guid', 'directory_sid'
    ];

    if (!$isAd) {
        foreach ($containers as $container) {
            foreach ($identityMarkerKeys as $key) {
                if (isset($container[$key]) && trim((string)$container[$key]) !== '') {
                    $isAd = true;
                    break 2;
                }
            }
        }
    }

    if (!$isAd && $username !== '') {
        foreach ($containers as $container) {
            foreach (array_merge($samKeys, $upnKeys) as $key) {
                if (array_key_exists($key, $container) && $container !== $profile) {
                    $isAd = true;
                    break 2;
                }
            }
        }

        foreach (['ad_username', 'ad_login', 'ad_samaccountname', 'ad_sam_account_name', 'ad_upn'] as $key) {
            if (isset($profile[$key]) && trim((string)$profile[$key]) !== '') {
                $isAd = true;
                break;
            }
        }
    }

    $groups = [];
    foreach ($memberOf as $groupDn) {
        $groupDn = trim((string)$groupDn);
        if ($groupDn === '') {
            continue;
        }
        $groups[] = [
            'name' => dmd_members_ad_group_label($groupDn),
            'dn' => $groupDn,
        ];
    }
    usort($groups, static function ($a, $b) {
        return strnatcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
    });

    $fullUsername = '';
    if ($isAd && $username !== '') {
        if (strpos($username, '\\') !== false) {
            $fullUsername = $username;
        } elseif ($netbiosDomain !== '') {
            $fullUsername = $netbiosDomain . '\\' . $username;
        } elseif ($dnsDomain !== '') {
            // Compatibilité pour les profils importés avant l'ajout du nom NetBIOS.
            // Une synchronisation AD remplacera ce repli par le vrai nom NetBIOS.
            $fullUsername = $dnsDomain . '\\' . $username;
        } else {
            $fullUsername = $username;
        }
    }

    return [
        'is_ad' => $isAd,
        'username' => $isAd ? $username : '',
        'full_username' => $isAd ? $fullUsername : '',
        'netbios_domain' => $isAd ? $netbiosDomain : '',
        'dns_domain' => $isAd ? $dnsDomain : '',
        'groups' => $isAd ? $groups : [],
        'last_sync_at' => $isAd ? $lastSyncAt : '',
    ];
}

function dmd_members_profile_change_summary($before, $after) {
    $labels = [
        'prenom' => 'Prénom',
        'nom' => 'Nom',
        'pseudo' => 'Pseudo',
        'role_system' => 'Rôle système',
        'role_metier' => 'Rôle métier',
        'adresse' => 'Adresse',
        'code_postal' => 'Code postal',
        'ville' => 'Ville',
        'pays' => 'Pays',
        'telephone' => 'Téléphone',
        'whatsapp' => 'WhatsApp',
        'facebook' => 'Facebook',
        'groupe_facebook' => 'Groupe Facebook',
        'linkedin' => 'LinkedIn',
        'instagram' => 'Instagram',
        'site_web' => 'Site web',
        'entreprise' => 'Entreprise',
        'poste' => 'Poste',
        'service' => 'Service',
        'bio' => 'Bio',
        'autres_infos' => 'Autres informations',
        'notes_admin' => 'Notes admin',
    ];

    $changed = [];
    foreach ($labels as $field => $label) {
        $beforeValue = (string)($before[$field] ?? '');
        $afterValue = (string)($after[$field] ?? '');
        if ($beforeValue !== $afterValue) {
            $changed[$field] = [
                'label' => $label,
                // On ne recopie pas les données personnelles dans les logs système.
                'before' => in_array($field, ['role_system', 'role_metier', 'pseudo'], true) ? $beforeValue : null,
                'after' => in_array($field, ['role_system', 'role_metier', 'pseudo'], true) ? $afterValue : null,
            ];
        }
    }
    return $changed;
}

function dmd_members_module_override_summary($beforeAcl, $afterAcl, $installedModules) {
    $beforeOverrides = isset($beforeAcl['overrides']) && is_array($beforeAcl['overrides']) ? $beforeAcl['overrides'] : [];
    $afterOverrides = isset($afterAcl['overrides']) && is_array($afterAcl['overrides']) ? $afterAcl['overrides'] : [];
    $ids = array_values(array_unique(array_merge(array_keys($beforeOverrides), array_keys($afterOverrides))));
    sort($ids, SORT_NATURAL | SORT_FLAG_CASE);

    $changes = [];
    foreach ($ids as $moduleId) {
        $beforeState = strtolower((string)($beforeOverrides[$moduleId]['state'] ?? 'inherit'));
        $afterState = strtolower((string)($afterOverrides[$moduleId]['state'] ?? 'inherit'));
        $beforePerms = isset($beforeOverrides[$moduleId]['permissions']) && is_array($beforeOverrides[$moduleId]['permissions'])
            ? array_values($beforeOverrides[$moduleId]['permissions']) : [];
        $afterPerms = isset($afterOverrides[$moduleId]['permissions']) && is_array($afterOverrides[$moduleId]['permissions'])
            ? array_values($afterOverrides[$moduleId]['permissions']) : [];
        sort($beforePerms, SORT_NATURAL | SORT_FLAG_CASE);
        sort($afterPerms, SORT_NATURAL | SORT_FLAG_CASE);

        if ($beforeState === $afterState && $beforePerms === $afterPerms) {
            continue;
        }

        $changes[$moduleId] = [
            'name' => (string)($installedModules[$moduleId]['name'] ?? $moduleId),
            'before' => $beforeState,
            'after' => $afterState,
            'permissions_before' => $beforePerms,
            'permissions_after' => $afterPerms,
        ];
    }
    return $changes;
}

function dmd_members_module_change_message($changes) {
    if (!$changes) {
        return '';
    }

    $parts = [];
    foreach ($changes as $moduleId => $change) {
        $name = (string)($change['name'] ?? $moduleId);
        $after = (string)($change['after'] ?? 'inherit');
        if ($after === 'allow') {
            $parts[] = $name . ' : autorisé';
        } elseif ($after === 'deny') {
            $parts[] = $name . ' : refusé';
        } else {
            $parts[] = $name . ' : hérite du rôle';
        }
    }
    return implode(' · ', $parts);
}

function formatLastSeen($timestamp) {
    $timestamp = (int)$timestamp;

    if ($timestamp <= 0) {
        return 'Jamais vu';
    }

    $diff = time() - $timestamp;

    if ($diff < 60) {
        return 'vu à l’instant';
    }

    if ($diff < 3600) {
        $minutes = max(1, floor($diff / 60));
        return 'vu il y a ' . $minutes . ' min';
    }

    return 'vu le ' . date('d/m/Y à H:i', $timestamp);
}

updatePresence($presenceDir, $presenceFile, $currentEmail, $presenceTtl);
$onlineUsers = getOnlineUsers($presenceFile, $presenceTtl);

$userDir = $profilesDir . $currentEmail . '/';
$themeJson = $userDir . 'theme.json';
$theme = 'default';

$themeData = readJsonFile($themeJson, []);

if (!empty($themeData['theme']) && is_file($baseDir . '/theme/' . basename($themeData['theme']) . '/style.css')) {
    $theme = basename($themeData['theme']);
} else {
    $profileThemeData = dmd_read_profile($currentEmail);

    if (!empty($profileThemeData['theme']) && is_file($baseDir . '/theme/' . basename($profileThemeData['theme']) . '/style.css')) {
        $theme = basename($profileThemeData['theme']);
    }
}

$rolesMetierPath = $baseDir . '/data/roles_metier.json';
$rolesMetier = dmd_roles_catalog();
$roleSystemOptions = $isSuperadminCurrent ? ['user', 'admin', 'superadmin'] : ['user', 'admin'];
$installedPermissionModules = dmd_installed_modules();
$rolesModulesData = dmd_read_roles_modules();

$saveMessage = '';
$saveError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['members_action'] ?? '') === 'update_user') {
    if (!$isSystemAdmin) {
        $saveError = 'Action refusée.';
    } elseif (!hash_equals($csrfToken, $_POST['csrf_token'] ?? '')) {
        $saveError = 'Session expirée, veuillez réessayer.';
    } else {
        $targetEmail = safeUserFolderName($_POST['target_email'] ?? '');

        if ($targetEmail === null) {
            $saveError = 'Utilisateur invalide.';
        } else {
            $targetDir = $profilesDir . $targetEmail . '/';
            $profilePath = dmd_profile_path($targetEmail, true);

            if (!is_file($profilePath)) {
                $saveError = 'Profil introuvable.';
            } else {
                $profile = readJsonFile($profilePath, []);
                $profileBefore = $profile;
                $moduleAclBefore = dmd_read_user_modules_acl($targetEmail);
                $targetRoleBefore = (string)($profileBefore['role_system'] ?? 'user');
                $avatarChanged = false;
                $bannerChanged = false;
                $passwordChanged = false;

                if (!$isSuperadminCurrent && $targetRoleBefore === 'superadmin') {
                    $saveError = 'Un compte Admin ne peut pas modifier un compte Superadmin.';
                    dmd_system_log('superadmin_profile_change_denied', $targetEmail, 'denied', 'Un administrateur a tenté de modifier un compte Superadmin depuis Membres.');
                }

                $newPrenom = trim((string)($_POST['prenom'] ?? ''));
                $newNom = trim((string)($_POST['nom'] ?? ''));
                $newRoleSystem = trim((string)($_POST['role_system'] ?? 'user'));
                $newRoleMetier = trim((string)($_POST['role_metier'] ?? ''));

                if (!in_array($newRoleSystem, $roleSystemOptions, true)) {
                    $newRoleSystem = $profile['role_system'] ?? 'user';
                }

                if ($saveError === '' && $isSuperadminCurrent && $targetRoleBefore === 'superadmin' && $newRoleSystem !== 'superadmin') {
                    $idx = dmd_notification_index();
                    $superadmins = isset($idx['role_system']['superadmin']) && is_array($idx['role_system']['superadmin'])
                        ? $idx['role_system']['superadmin']
                        : [];
                    if (count($superadmins) <= 1) {
                        $newRoleSystem = 'superadmin';
                        $saveError = 'Le dernier Superadmin ne peut pas être rétrogradé.';
                        dmd_system_log('last_superadmin_role_change_denied', $targetEmail, 'denied', 'Tentative de rétrogradation du dernier Superadmin depuis Membres.');
                    }
                }

                if ($newRoleMetier !== '' && !in_array($newRoleMetier, $rolesMetier, true)) {
                    $newRoleMetier = $profile['role_metier'] ?? '';
                }

                $profile['prenom'] = $newPrenom;
                $profile['nom'] = $newNom;
                $profile['role_system'] = $newRoleSystem;
                $profile['role_metier'] = $newRoleMetier;

                $editableTextFields = [
                    'pseudo', 'adresse', 'code_postal', 'ville', 'pays',
                    'telephone', 'whatsapp', 'facebook', 'groupe_facebook', 'linkedin',
                    'instagram', 'site_web', 'entreprise', 'poste', 'service',
                    'bio', 'autres_infos', 'notes_admin'
                ];

                foreach ($editableTextFields as $fieldName) {
                    $profile[$fieldName] = trim((string)($_POST[$fieldName] ?? ''));
                }

                if (empty($profile['email'])) {
                    $profile['email'] = $targetEmail;
                }

                $newPassword = (string)($_POST['new_password'] ?? '');
                $newPasswordConfirm = (string)($_POST['new_password_confirm'] ?? '');

                if ($newPassword !== '' || $newPasswordConfirm !== '') {
                    if (strlen($newPassword) < 8) {
                        $saveError = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
                    } elseif ($newPassword !== $newPasswordConfirm) {
                        $saveError = 'La confirmation du mot de passe ne correspond pas.';
                    } else {
                        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                        $profile['password'] = $newHash;
                        $profile['motdepasse'] = $newHash;
                        $passwordChanged = true;

                        if (isset($profile['password_hash'])) {
                            unset($profile['password_hash']);
                        }
                    }
                }
                $mediaDir = dmd_user_media_dir($targetEmail, true);

                if (
                    $saveError === '' &&
                    isset($_FILES['avatar']) &&
                    is_array($_FILES['avatar']) &&
                    ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
                ) {
                    $storedAvatar = dmd_media_store_upload($_FILES['avatar'], $mediaDir, 'avatar', true);
                    if (empty($storedAvatar['success'])) {
                        $saveError = (string)($storedAvatar['error'] ?? 'Impossible d’enregistrer le nouvel avatar.');
                    } else {
                        $avatarChanged = true;
                    }
                }

                if (
                    $saveError === '' &&
                    isset($_FILES['banner']) &&
                    is_array($_FILES['banner']) &&
                    ($_FILES['banner']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE
                ) {
                    $storedBanner = dmd_media_store_upload($_FILES['banner'], $mediaDir, 'baniere', true);
                    if (empty($storedBanner['success'])) {
                        $saveError = (string)($storedBanner['error'] ?? 'Impossible d’enregistrer la nouvelle bannière.');
                    } else {
                        $bannerChanged = true;
                    }
                }

                if ($saveError === '') {
                    if (dmd_write_profile($targetEmail, $profile)) {
                        $overrideStates = isset($_POST['module_overrides']) && is_array($_POST['module_overrides'])
                            ? $_POST['module_overrides']
                            : array();

                        if (!dmd_replace_user_module_overrides($targetEmail, $overrideStates)) {
                            $saveError = 'Profil enregistré, mais les exceptions modules n’ont pas pu être sauvegardées.';
                            dmd_system_log('user_module_permissions_update_failed', $targetEmail, 'error', 'Le profil a été enregistré mais les exceptions modules n’ont pas pu être sauvegardées depuis Membres.');
                        } else {
                            // IMPORTANT : Membres est une autre voie d'administration que profile_edit/site_settings.
                            // On journalise ici l'opération complète, sans scan de profils.
                            $profileAfter = dmd_read_profile($targetEmail);
                            $moduleAclAfter = dmd_read_user_modules_acl($targetEmail);
                            $profileChanges = dmd_members_profile_change_summary($profileBefore, $profileAfter);
                            $moduleChanges = dmd_members_module_override_summary($moduleAclBefore, $moduleAclAfter, $installedPermissionModules);

                            if ($profileChanges) {
                                if (isset($profileChanges['role_system']) || isset($profileChanges['role_metier'])) {
                                    dmd_notification_index_refresh_user($targetEmail);
                                }
                                $fieldLabels = [];
                                foreach ($profileChanges as $change) {
                                    $fieldLabels[] = (string)($change['label'] ?? 'Champ');
                                }
                                dmd_system_log(
                                    'user_profile_updated',
                                    $targetEmail,
                                    'success',
                                    'Profil utilisateur modifié depuis la page Membres : ' . implode(', ', $fieldLabels) . '.',
                                    ['changes' => $profileChanges]
                                );

                                if ($targetEmail !== $currentEmail) {
                                    $roleChanged = isset($profileChanges['role_system']) || isset($profileChanges['role_metier']);
                                    dmd_notify_user(
                                        $targetEmail,
                                        $roleChanged ? 'permissions_changed' : 'profile_changed',
                                        $roleChanged ? 'Votre profil DoMyDesk et vos rôles ont été modifiés' : 'Votre profil DoMyDesk a été modifié',
                                        count($fieldLabels) . ' modification(s) ont été effectuées sur votre compte.',
                                        [
                                            'level' => 'warning',
                                            'action_url' => 'profile_view.php',
                                            'action_label' => 'Voir mon profil',
                                            'meta' => [
                                                'scope' => 'profile',
                                                'target' => $targetEmail,
                                                'changes' => $profileChanges,
                                            ],
                                        ]
                                    );
                                }
                            }

                            if ($passwordChanged) {
                                dmd_system_log('user_password_reset', $targetEmail, 'success', 'Mot de passe utilisateur réinitialisé depuis la page Membres.');
                                if ($targetEmail !== $currentEmail) {
                                    dmd_notify_user(
                                        $targetEmail,
                                        'security',
                                        'Votre mot de passe a été réinitialisé',
                                        'Un administrateur a réinitialisé le mot de passe de votre compte DoMyDesk.',
                                        ['level' => 'warning']
                                    );
                                }
                            }

                            if ($avatarChanged) {
                                dmd_system_log('user_avatar_updated', $targetEmail, 'success', 'Avatar utilisateur modifié depuis la page Membres.');
                                if ($targetEmail !== $currentEmail) {
                                    dmd_notify_user(
                                        $targetEmail,
                                        'profile_changed',
                                        'Votre avatar a été modifié',
                                        'Un administrateur a modifié l’avatar de votre compte DoMyDesk.',
                                        ['level' => 'info', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']
                                    );
                                }
                            }

                            if ($bannerChanged) {
                                dmd_system_log('user_banner_updated', $targetEmail, 'success', 'Bannière utilisateur modifiée depuis la page Membres.');
                                if ($targetEmail !== $currentEmail) {
                                    dmd_notify_user(
                                        $targetEmail,
                                        'profile_changed',
                                        'Votre bannière a été modifiée',
                                        'Un administrateur a modifié la bannière de votre compte DoMyDesk.',
                                        ['level' => 'info', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']
                                    );
                                }
                            }

                            if ($moduleChanges) {
                                $moduleMessage = dmd_members_module_change_message($moduleChanges);
                                dmd_system_log(
                                    'user_module_permissions_updated',
                                    $targetEmail,
                                    'success',
                                    'Autorisations modules modifiées depuis la page Membres.',
                                    ['changes' => $moduleChanges]
                                );
                                dmd_notification_index_refresh_user($targetEmail);

                                if ($targetEmail !== $currentEmail) {
                                    dmd_notify_user(
                                        $targetEmail,
                                        'permissions_changed',
                                        'Vos accès aux modules ont changé',
                                        $moduleMessage !== '' ? $moduleMessage : 'Un administrateur a modifié vos accès aux modules DoMyDesk.',
                                        [
                                            'level' => 'warning',
                                            'action_url' => 'profile_edit.php',
                                            'action_label' => 'Voir mes modules',
                                            'meta' => [
                                                'scope' => 'modules',
                                                'target' => $targetEmail,
                                                'changes' => $moduleChanges,
                                            ],
                                        ]
                                    );
                                }
                            }

                            header('Location: members.php?saved=1');
                            exit;
                        }
                    } else {
                        $saveError = 'Impossible de sauvegarder le profil.';
                        dmd_system_log('user_profile_update_failed', $targetEmail, 'error', 'Impossible de sauvegarder le profil depuis la page Membres.');
                    }
                }
            }
        }
    }
}

if (isset($_GET['saved'])) {
    $saveMessage = 'Utilisateur mis à jour.';
}

$members = [];

if (is_dir($profilesDir)) {
    foreach (scandir($profilesDir) as $folder) {
        if ($folder === '.' || $folder === '..') {
            continue;
        }

        $safeFolder = safeUserFolderName($folder);

        if ($safeFolder === null) {
            continue;
        }

        $memberDir = $profilesDir . $safeFolder . '/';
        $profilePath = dmd_profile_path($safeFolder, true);

        if (!is_file($profilePath)) {
            continue;
        }

        $profile = dmd_read_profile($safeFolder);

        if (empty($profile)) {
            continue;
        }

        $moduleMatrix = dmd_user_module_matrix($safeFolder);
        $enabledList = array();

        foreach ($moduleMatrix as $moduleItem) {
            if (empty($moduleItem['effective']) || empty($moduleItem['enabled'])) {
                continue;
            }

            $enabledList[] = array(
                'id' => $moduleItem['id'] ?? '',
                'name' => $moduleItem['name'] ?? ($moduleItem['id'] ?? 'Module'),
                'description' => $moduleItem['description'] ?? '',
            );
        }

        $moduleCounts = array(
            'total' => count($moduleMatrix),
            'enabled' => count($enabledList),
            'enabled_list' => $enabledList,
        );

        $prenom = $profile['prenom'] ?? '';
        $nom = $profile['nom'] ?? '';
        $email = $profile['email'] ?? $safeFolder;
        $avatarFile = dmd_user_avatar_file($safeFolder);
        $avatarExists = $avatarFile !== '';
        $avatarSrc = $avatarExists ? dmd_media_public_url($avatarFile) : '';
        $userBannerFile = dmd_user_banner_file($safeFolder);
        $effectiveBannerFile = $userBannerFile !== '' ? $userBannerFile : $siteDefaultBannerFile;
        $bannerExists = $effectiveBannerFile !== '';
        $bannerSrc = $bannerExists ? dmd_media_public_url($effectiveBannerFile) : '';
        $createdAt = $profile['created_at'] ?? '';
        $presenceData = $onlineUsers[$email] ?? ($onlineUsers[$safeFolder] ?? null);
        $isOnline = is_array($presenceData);
        $lastSeen = $presenceData['last_seen'] ?? 0;
        $adInfo = dmd_members_ad_info($profile);

        $members[] = [
            'folder' => $safeFolder,
            'email' => $email,
            'prenom' => $prenom,
            'nom' => $nom,
            'display_name' => trim($prenom . ' ' . $nom) ?: $email,
            'role_system' => $profile['role_system'] ?? 'user',
            'role_metier' => $profile['role_metier'] ?? '',
            'is_ad' => !empty($adInfo['is_ad']),
            'ad_username' => trim((string)($adInfo['username'] ?? '')),
            'ad_full_username' => trim((string)($adInfo['full_username'] ?? '')),
            'ad_netbios_domain' => trim((string)($adInfo['netbios_domain'] ?? '')),
            'ad_dns_domain' => trim((string)($adInfo['dns_domain'] ?? '')),
            'ad_groups' => is_array($adInfo['groups'] ?? null) ? $adInfo['groups'] : [],
            'ad_group_count' => is_array($adInfo['groups'] ?? null) ? count($adInfo['groups']) : 0,
            'ad_last_sync_at' => trim((string)($adInfo['last_sync_at'] ?? '')),
            'pseudo' => trim((string)($profile['pseudo'] ?? '')),
            'adresse' => trim((string)($profile['adresse'] ?? '')),
            'code_postal' => trim((string)($profile['code_postal'] ?? '')),
            'ville' => trim((string)($profile['ville'] ?? '')),
            'pays' => trim((string)($profile['pays'] ?? '')),
            'telephone' => trim((string)($profile['telephone'] ?? '')),
            'whatsapp' => trim((string)($profile['whatsapp'] ?? '')),
            'facebook' => trim((string)($profile['facebook'] ?? '')),
            'groupe_facebook' => trim((string)($profile['groupe_facebook'] ?? '')),
            'linkedin' => trim((string)($profile['linkedin'] ?? '')),
            'instagram' => trim((string)($profile['instagram'] ?? '')),
            'site_web' => trim((string)($profile['site_web'] ?? '')),
            'entreprise' => trim((string)($profile['entreprise'] ?? '')),
            'poste' => trim((string)($profile['poste'] ?? '')),
            'service' => trim((string)($profile['service'] ?? '')),
            'bio' => trim((string)($profile['bio'] ?? '')),
            'autres_infos' => trim((string)($profile['autres_infos'] ?? '')),
            'notes_admin' => $isSystemAdmin ? trim((string)($profile['notes_admin'] ?? '')) : '',
            'created_at' => $createdAt,
            'created_at_label' => formatCreatedAt($createdAt),
            'is_online' => $isOnline,
            'online_label' => $isOnline ? 'Connecté' : 'Déconnecté',
            'last_seen' => $lastSeen,
            'last_seen_label' => $isOnline ? formatLastSeen($lastSeen) : 'Non connecté',
            'modules_enabled' => $moduleCounts['enabled'],
            'modules_total' => $moduleCounts['total'],
            'enabled_modules' => $moduleCounts['enabled_list'],
            'module_matrix' => $moduleMatrix,
            'avatar_exists' => $avatarExists,
            'avatar_src' => $avatarSrc,
            'banner_exists' => $bannerExists,
            'banner_src' => $bannerSrc,
            'banner_is_default' => ($userBannerFile === '' && $siteDefaultBannerFile !== ''),
            'initials' => userInitials($prenom, $nom, $email),
        ];
    }
}

usort($members, function ($a, $b) {
    if (($a['is_online'] ?? false) !== ($b['is_online'] ?? false)) {
        return !empty($a['is_online']) ? -1 : 1;
    }

    return strcasecmp($a['display_name'], $b['display_name']);
});

$membersJson = json_encode($members, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$rolesMetierJson = json_encode($rolesMetier, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$roleSystemOptionsJson = json_encode($roleSystemOptions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$rolesModulesJson = json_encode($rolesModulesData['roles'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$moduleAccessModesJson = json_encode($rolesModulesData['module_access'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$pageTitle = 'Membres';

include 'header.php';
?>

<style>
.member-avatar-wrap {
    position: relative;
}


.member-ad-username {
    display: block;
    margin-top: 4px;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 10px;
    line-height: 1.2;
    opacity: .82;
}


.member-view-identity {
    position: relative;
}

.member-view-ad-identity {
    margin: 8px 0 8px 118px;
    min-height: 42px;
    display: flex;
    align-items: center;
    gap: 9px;
    min-width: 0;
}

.member-view-ad-identity.member-hidden {
    display: none;
}

.member-view-ad-copy {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.member-view-ad-copy span {
    font-size: 9px;
    opacity: .66;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.member-view-ad-copy strong {
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
}

.member-view-avatar-anchor {
    position: relative;
}

.member-view-ad-groups-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    min-height: 26px;
    padding: 4px 9px;
    border: 1px solid var(--border-color);
    border-radius: 999px;
    background: var(--input-bg, transparent);
    color: var(--text-color, inherit);
    font-size: 9px;
    font-weight: 700;
    line-height: 1;
    cursor: pointer;
    white-space: nowrap;
}

.member-view-ad-groups-button:hover,
.member-view-ad-groups-button:focus-visible {
    filter: brightness(1.08);
}

.member-ad-groups-backdrop {
    position: fixed;
    inset: 0;
    z-index: 1000002;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 18px;
    background: rgba(0,0,0,.58);
}

.member-ad-groups-backdrop.active {
    display: flex;
}

.member-ad-groups-popup {
    width: min(520px, 100%);
    max-height: min(70vh, 620px);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border: 1px solid var(--border-color);
    border-radius: 12px;
    background: var(--card-bg, #0f1720);
    color: var(--text-color, inherit);
    box-shadow: 0 18px 55px rgba(0,0,0,.35);
}

.member-ad-groups-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 14px;
    border-bottom: 1px solid var(--border-color);
}

.member-ad-groups-head h3 {
    margin: 0;
    font-size: 13px;
}

.member-ad-groups-close {
    min-width: 34px;
    height: 30px;
    padding: 0 9px;
}

.member-ad-groups-body {
    overflow: auto;
    padding: 12px 14px 14px;
}

.member-ad-groups-login {
    margin-bottom: 10px;
    font-size: 11px;
}

.member-ad-groups-list {
    display: grid;
    gap: 7px;
}

.member-ad-group-item {
    display: grid;
    gap: 2px;
    padding: 8px 10px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
}

.member-ad-group-item strong {
    font-size: 11px;
}

.member-ad-group-item small {
    opacity: .62;
    overflow-wrap: anywhere;
    font-size: 9px;
}

.member-ad-groups-note {
    margin-top: 10px;
    font-size: 9px;
    opacity: .62;
}

@media (max-width: 620px) {
    .member-view-ad-identity {
        margin-left: 0;
        padding-top: 8px;
    }
}
</style>

<main class="members-page">
    <div class="members-head">
        <div class="members-title-block">
            <h1>Membres</h1>
            <p>Utilisateurs, rôles, modules et présence.</p>
        </div>

        <div class="members-count">
            <span id="membersVisibleCount"><?= count($members) ?></span> / <?= count($members) ?> membre<?= count($members) > 1 ? 's' : '' ?>
        </div>
    </div>

    <?php if ($saveMessage !== ''): ?>
        <div class="members-alert"><?= e($saveMessage) ?></div>
    <?php endif; ?>

    <?php if ($saveError !== ''): ?>
        <div class="members-alert error"><?= e($saveError) ?></div>
    <?php endif; ?>

    <?php if (!empty($members)): ?>
        <section class="members-toolbar">
            <input
                type="search"
                class="members-search"
                id="membersSearch"
                placeholder="Rechercher un membre, un e-mail, un rôle..."
                autocomplete="off"
            >

            <div class="members-filters" aria-label="Filtres membres">
                <button type="button" class="members-filter active" data-filter="all">Tous</button>
                <button type="button" class="members-filter" data-filter="online">Connectés</button>
                <button type="button" class="members-filter" data-filter="offline">Déconnectés</button>
                <button type="button" class="members-filter" data-filter="admin">Admins</button>
				<button type="button" class="members-filter" data-filter="superadmin">Propriétaire</button>
                <button type="button" class="members-filter" data-filter="user">Utilisateurs</button>
                <button type="button" class="members-filter" data-filter="with_modules">Avec modules</button>
                <button type="button" class="members-filter" data-filter="without_modules">Sans module</button>
            </div>
        </section>

        <section class="members-grid" aria-label="Liste des membres" id="membersGrid">
            <?php foreach ($members as $member): ?>
                <?php
$searchText = strtolower(trim(
    ($member['display_name'] ?? '') . ' ' .
    ($member['email'] ?? '') . ' ' .
    ($member['role_system'] ?? '') . ' ' .
    ($member['role_metier'] ?? '') . ' ' .
    ($member['ad_username'] ?? '') . ' ' .
    ($member['ad_full_username'] ?? '') . ' ' .
    implode(' ', array_map(static fn($g) => (string)($g['name'] ?? ''), is_array($member['ad_groups'] ?? null) ? $member['ad_groups'] : [])) . ' ' .
    ($member['created_at_label'] ?? '') . ' ' .
    ($member['online_label'] ?? '') . ' ' .
    ($member['adresse'] ?? '') . ' ' .
    ($member['ville'] ?? '') . ' ' .
    ($member['pays'] ?? '') . ' ' .
    ($member['telephone'] ?? '') . ' ' .
    ($member['whatsapp'] ?? '') . ' ' .
    ($member['facebook'] ?? '') . ' ' .
    ($member['groupe_facebook'] ?? '') . ' ' .
    ($member['linkedin'] ?? '') . ' ' .
    ($member['instagram'] ?? '') . ' ' .
    ($member['site_web'] ?? '') . ' ' .
    ($member['entreprise'] ?? '') . ' ' .
    ($member['poste'] ?? '') . ' ' .
    ($member['service'] ?? '') . ' ' .
    ($member['bio'] ?? '') . ' ' .
    ($member['autres_infos'] ?? '')
));
                ?>

                <article
                    class="member-card"
                    data-member-card
                    data-search="<?= e($searchText) ?>"
                    data-role-system="<?= e($member['role_system']) ?>"
                    data-modules-enabled="<?= (int)$member['modules_enabled'] ?>"
                    data-online="<?= !empty($member['is_online']) ? '1' : '0' ?>"
                    data-ad="<?= !empty($member['is_ad']) ? '1' : '0' ?>"
                >
                    <button
                        type="button"
                        class="member-open"
                        data-open-member="<?= e($member['folder']) ?>"
                        aria-label="Voir la fiche de <?= e($member['display_name']) ?>"
                    ></button>

                    <span class="member-avatar-wrap" title="<?= e($member['online_label'] . ' - ' . $member['last_seen_label']) ?>">
                        <?php if ($member['avatar_exists']): ?>
                            <img
                                class="member-avatar"
                                src="<?= e($member['avatar_src']) ?>"
                                alt="Avatar de <?= e($member['display_name']) ?>"
                            >
                        <?php else: ?>
                            <span class="member-avatar-fallback" aria-hidden="true">
                                <?= e($member['initials']) ?>
                            </span>
                        <?php endif; ?>

                        <span
                            class="member-status-dot <?= !empty($member['is_online']) ? 'is-online' : 'is-offline' ?>"
                            aria-label="<?= e($member['online_label']) ?>"
                        ></span>

                    </span>

                    <span class="member-info">
                        <span class="member-name-line">
                            <strong class="member-name" title="<?= e($member['display_name']) ?>">
                                <?= e($member['display_name']) ?>
                            </strong>
                        </span>

                        <span class="member-email" title="<?= e($member['email']) ?>">
                            <?= e($member['email']) ?>
                        </span>

                        <?php
                            $cardLocation = trim(($member['ville'] ?? '') . (!empty($member['pays']) ? ' ' . $member['pays'] : ''));
                        ?>

                        <span class="member-meta">
                            <span class="member-pill"><?= e($member['role_system'] ?: 'user') ?></span>
                            <span class="member-pill"><?= e($member['role_metier'] ?: 'Aucun rôle métier') ?></span>
                            <span class="member-pill"><?= (int)$member['modules_enabled'] ?> / <?= (int)$member['modules_total'] ?> modules</span>
                            <span class="member-pill">Créé le <?= e($member['created_at_label']) ?></span>
                            <?php if ($cardLocation !== ''): ?>
                                <span class="member-pill">Localisation <?= e($cardLocation) ?></span>
                            <?php endif; ?>
                        </span>

                        <?php if (!empty($member['is_ad']) && $member['ad_username'] !== ''): ?>
                            <span
                                class="member-ad-username"
                                title="Identifiant Active Directory : <?= e($member['ad_username']) ?>"
                            >AD : <?= e($member['ad_username']) ?></span>
                        <?php endif; ?>
                    </span>

                    <?php if ($isSystemAdmin): ?>

                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </section>

        <div class="members-no-result" id="membersNoResult">
            Aucun membre ne correspond à la recherche.
        </div>
    <?php else: ?>
        <div class="members-empty">
            Aucun membre trouvé.
        </div>
    <?php endif; ?>
</main>

<div class="member-modal-backdrop" id="memberModal" aria-hidden="true">
    <div class="member-modal" role="dialog" aria-modal="true" aria-labelledby="memberModalTitle">
        <div class="member-modal-head">
            <h2 class="member-modal-title" id="memberModalTitle">Fiche utilisateur</h2>
            <button type="button" class="member-modal-close" data-close-member-modal>×</button>
        </div>

        <div class="member-modal-body">
            <section id="memberViewPanel">
                <div id="memberViewIdentity" class="member-view-identity">
                    <div id="memberViewBanner" class="member-view-banner member-hidden"></div>
                    <div class="member-view-avatar-anchor">
                        <div id="memberViewAvatar" class="member-view-avatar-slot"></div>
                        <span id="memberViewAvatarStatus" class="member-view-avatar-status is-offline" aria-label="Déconnecté"></span>
                    </div>
                    <div id="memberViewAdIdentity" class="member-view-ad-identity member-hidden">
                        <div class="member-view-ad-copy">
                            <span>Identifiant Active Directory</span>
                            <strong id="memberViewAdLogin"></strong>
                        </div>
                        <button type="button" class="member-view-ad-groups-button" id="memberViewAdGroupsButton" title="Voir les groupes Active Directory" aria-label="Voir les groupes Active Directory">Groupes AD <span id="memberViewAdGroupsCount">0</span></button>
                    </div>
                </div>

                <div class="member-detail-grid member-detail-grid-profile">
                    <div class="member-detail member-compact-detail">
                        <span>Prénom</span>
                        <strong id="memberViewPrenom"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>Nom</span>
                        <strong id="memberViewNom"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>Pseudo</span>
                        <strong id="memberViewPseudo"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>E-mail</span>
                        <strong id="memberViewEmail"></strong>
                    </div>



                    <div class="member-detail member-compact-detail">
                        <span>Rôle système</span>
                        <strong id="memberViewRoleSystem"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>Rôle métier</span>
                        <strong id="memberViewRoleMetier"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>Modules activés</span>
                        <strong id="memberViewModulesCount"></strong>
                    </div>

                    <div class="member-detail member-compact-detail">
                        <span>Date de création</span>
                        <strong id="memberViewCreatedAt"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewAdresseBox">
                        <span>Adresse</span>
                        <strong id="memberViewAdresse"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewVilleBox">
                        <span>Ville / pays</span>
                        <strong id="memberViewVille"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewTelephoneBox">
                        <span>Téléphone</span>
                        <strong id="memberViewTelephone"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewWhatsappBox">
                        <span>WhatsApp</span>
                        <strong id="memberViewWhatsapp"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewEntrepriseBox">
                        <span>Entreprise</span>
                        <strong id="memberViewEntreprise"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewPosteBox">
                        <span>Poste</span>
                        <strong id="memberViewPoste"></strong>
                    </div>

                    <div class="member-detail member-compact-detail" id="memberViewServiceBox">
                        <span>Service</span>
                        <strong id="memberViewService"></strong>
                    </div>
                </div>

                <div class="member-links-row" id="memberViewSocialBox">
                    <span class="member-links-label">Liens</span>
                    <div id="memberViewSocial" class="member-link-chips"></div>
                </div>

                <div class="member-detail member-long-detail" id="memberViewBioBox">
                    <span>Bio / autres informations</span>
                    <strong id="memberViewBio"></strong>
                </div>

                <?php if ($isSystemAdmin): ?>
                    <div class="member-detail member-long-detail" id="memberViewNotesAdminBox">
                        <span>Notes admin</span>
                        <strong id="memberViewNotesAdmin"></strong>
                    </div>
                <?php endif; ?>

                <div class="member-modules-head">Modules actifs</div>
                <div class="member-modules-list" id="memberViewModulesList"></div>

                <div class="member-modal-actions">
                    <button type="button" class="member-modal-btn" id="memberCopyEmail">
                        Copier l’e-mail
                    </button>

                    <?php if ($isSystemAdmin): ?>
                        <button type="button" class="member-modal-btn" id="memberSwitchToEdit">
                            Modifier cet utilisateur
                        </button>
                    <?php endif; ?>

                    <button type="button" class="member-modal-btn" data-close-member-modal>
                        Fermer
                    </button>
                </div>

                <div class="member-copy-status" id="memberCopyStatus"></div>
            </section>

            <?php if ($isSystemAdmin): ?>
                <section id="memberEditPanel" class="member-hidden">
						<form class="member-form" method="post" action="members.php" enctype="multipart/form-data">
                        <input type="hidden" name="members_action" value="update_user">
                        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
                        <input type="hidden" name="target_email" id="editTargetEmail" value="">

                        <div class="member-form-note">
                           L’e-mail reste verrouillé pour ne pas casser le dossier utilisateur. Laissez le mot de passe vide pour ne pas le changer.
                        </div>

                        <div class="member-form-row">
                            <label for="editEmailReadonly">Email / dossier utilisateur</label>
                            <input type="text" id="editEmailReadonly" value="" readonly>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editPrenom">Prénom</label>
                                <input type="text" name="prenom" id="editPrenom" value="">
                            </div>
                            <div>
                                <label for="editNom">Nom</label>
                                <input type="text" name="nom" id="editNom" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editPseudo">Pseudo</label>
                                <input type="text" name="pseudo" id="editPseudo" value="">
                            </div>
                            <div>
                                <label for="editRoleSystem">Rôle système</label>
                                <select name="role_system" id="editRoleSystem"></select>
                            </div>
                        </div>

                        <div class="member-form-row">
                            <label for="editRoleMetier">Rôle métier</label>
                            <select name="role_metier" id="editRoleMetier"></select>
                        </div>

                        <h3>Autorisations modules</h3>
                        <p class="member-permissions-help">
                            Hérité suit le rôle métier. Autorisé ajoute une exception. Refusé bloque le module pour cet utilisateur.
                        </p>
                        <div class="member-module-rights" id="editModulePermissions"></div>

                        <div class="member-form-row">
                            <div>
                                <label for="editAdresse">Adresse</label>
                                <input type="text" name="adresse" id="editAdresse" value="">
                            </div>
                            <div>
                                <label for="editCodePostal">Code postal</label>
                                <input type="text" name="code_postal" id="editCodePostal" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editVille">Ville</label>
                                <input type="text" name="ville" id="editVille" value="">
                            </div>
                            <div>
                                <label for="editPays">Pays</label>
                                <input type="text" name="pays" id="editPays" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editTelephone">Téléphone</label>
                                <input type="text" name="telephone" id="editTelephone" value="">
                            </div>
                            <div>
                                <label for="editWhatsapp">WhatsApp</label>
                                <input type="text" name="whatsapp" id="editWhatsapp" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editFacebook">Facebook</label>
                                <input type="text" name="facebook" id="editFacebook" value="">
                            </div>
                            <div>
                                <label for="editGroupeFacebook">Groupe Facebook</label>
                                <input type="text" name="groupe_facebook" id="editGroupeFacebook" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editLinkedin">LinkedIn</label>
                                <input type="text" name="linkedin" id="editLinkedin" value="">
                            </div>
                            <div>
                                <label for="editInstagram">Instagram</label>
                                <input type="text" name="instagram" id="editInstagram" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <label for="editSiteWeb">Site web</label>
                            <input type="text" name="site_web" id="editSiteWeb" value="">
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editEntreprise">Entreprise</label>
                                <input type="text" name="entreprise" id="editEntreprise" value="">
                            </div>
                            <div>
                                <label for="editPoste">Poste</label>
                                <input type="text" name="poste" id="editPoste" value="">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <label for="editService">Service</label>
                            <input type="text" name="service" id="editService" value="">
                        </div>

                        <div class="member-form-row">
                            <label for="editBio">Bio</label>
                            <textarea name="bio" id="editBio" rows="3"></textarea>
                        </div>

                        <div class="member-form-row">
                            <label for="editAutresInfos">Autres informations</label>
                            <textarea name="autres_infos" id="editAutresInfos" rows="3"></textarea>
                        </div>

                        <div class="member-form-row">
                            <label for="editNotesAdmin">Notes admin</label>
                            <textarea name="notes_admin" id="editNotesAdmin" rows="3"></textarea>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editNewPassword">Nouveau mot de passe</label>
                                <input type="password" name="new_password" id="editNewPassword" value="" minlength="8" autocomplete="new-password">
                            </div>
                            <div>
                                <label for="editNewPasswordConfirm">Confirmation</label>
                                <input type="password" name="new_password_confirm" id="editNewPasswordConfirm" value="" minlength="8" autocomplete="new-password">
                            </div>
                        </div>

                        <div class="member-form-row">
                            <div>
                                <label for="editAvatar">Remplacer l’avatar</label>
                                <input type="file" name="avatar" id="editAvatar" accept="image/*,.svg">
                            </div>
                            <div>
                                <label for="editBanner">Remplacer la bannière</label>
                                <input type="file" name="banner" id="editBanner" accept="image/*,.svg">
                            </div>
                        </div>

                        <div class="member-modal-actions">
                            <button type="button" class="member-modal-btn" id="memberBackToView">
                                Retour à la fiche
                            </button>

                            <button type="submit" class="member-modal-btn">
                                Enregistrer
                            </button>
                        </div>
                    </form>
                </section>
            <?php endif; ?>
        </div>
    </div>
</div>



<div class="member-ad-groups-backdrop" id="memberAdGroupsModal" aria-hidden="true">
    <div class="member-ad-groups-popup" role="dialog" aria-modal="true" aria-labelledby="memberAdGroupsTitle">
        <div class="member-ad-groups-head">
            <h3 id="memberAdGroupsTitle">Groupes Active Directory</h3>
            <button type="button" class="member-ad-groups-close" data-close-ad-groups>×</button>
        </div>
        <div class="member-ad-groups-body">
            <div class="member-ad-groups-login" id="memberAdGroupsLogin"></div>
            <div class="member-ad-groups-list" id="memberAdGroupsList"></div>
            <div class="member-ad-groups-note" id="memberAdGroupsNote"></div>
        </div>
    </div>
</div>


<script>
(function () {
    const members = <?= $membersJson ?: '[]' ?>;
    const rolesMetier = <?= $rolesMetierJson ?: '[]' ?>;
    const roleSystemOptions = <?= $roleSystemOptionsJson ?: '[]' ?>;
    const roleModules = <?= $rolesModulesJson ?: '{}' ?>;
    const moduleAccessModes = <?= $moduleAccessModesJson ?: '{}' ?>;
    const isSystemAdmin = <?= $isSystemAdmin ? 'true' : 'false' ?>;

    const membersByFolder = {};

    members.forEach(member => {
        membersByFolder[member.folder] = member;
    });

    const modal = document.getElementById('memberModal');
    const viewPanel = document.getElementById('memberViewPanel');
    const editPanel = document.getElementById('memberEditPanel');

    const title = document.getElementById('memberModalTitle');
    const avatar = document.getElementById('memberViewAvatar');
    const viewIdentity = document.getElementById('memberViewIdentity');
    const viewBanner = document.getElementById('memberViewBanner');
    const viewAvatarStatus = document.getElementById('memberViewAvatarStatus');
    const viewAdIdentity = document.getElementById('memberViewAdIdentity');
    const viewAdLogin = document.getElementById('memberViewAdLogin');
    const viewAdGroupsButton = document.getElementById('memberViewAdGroupsButton');
    const viewAdGroupsCount = document.getElementById('memberViewAdGroupsCount');
    const adGroupsModal = document.getElementById('memberAdGroupsModal');
    const adGroupsLogin = document.getElementById('memberAdGroupsLogin');
    const adGroupsList = document.getElementById('memberAdGroupsList');
    const adGroupsNote = document.getElementById('memberAdGroupsNote');
    const viewPrenom = document.getElementById('memberViewPrenom');
    const viewNom = document.getElementById('memberViewNom');
    const viewPseudo = document.getElementById('memberViewPseudo');
    const viewEmail = document.getElementById('memberViewEmail');
    const viewOnlineStatus = document.getElementById('memberViewOnlineStatus');
    const viewRoleSystem = document.getElementById('memberViewRoleSystem');
    const viewRoleMetier = document.getElementById('memberViewRoleMetier');
    const viewModulesCount = document.getElementById('memberViewModulesCount');
    const viewCreatedAt = document.getElementById('memberViewCreatedAt');
    const viewModulesList = document.getElementById('memberViewModulesList');
    const viewAdresse = document.getElementById('memberViewAdresse');
    const viewAdresseBox = document.getElementById('memberViewAdresseBox');
    const viewVille = document.getElementById('memberViewVille');
    const viewVilleBox = document.getElementById('memberViewVilleBox');
    const viewTelephone = document.getElementById('memberViewTelephone');
    const viewTelephoneBox = document.getElementById('memberViewTelephoneBox');
    const viewWhatsapp = document.getElementById('memberViewWhatsapp');
    const viewWhatsappBox = document.getElementById('memberViewWhatsappBox');
    const viewEntreprise = document.getElementById('memberViewEntreprise');
    const viewEntrepriseBox = document.getElementById('memberViewEntrepriseBox');
    const viewPoste = document.getElementById('memberViewPoste');
    const viewPosteBox = document.getElementById('memberViewPosteBox');
    const viewService = document.getElementById('memberViewService');
    const viewServiceBox = document.getElementById('memberViewServiceBox');
    const viewSocial = document.getElementById('memberViewSocial');
    const viewSocialBox = document.getElementById('memberViewSocialBox');
    const viewBio = document.getElementById('memberViewBio');
    const viewBioBox = document.getElementById('memberViewBioBox');
    const viewNotesAdmin = document.getElementById('memberViewNotesAdmin');
    const viewNotesAdminBox = document.getElementById('memberViewNotesAdminBox');

    const switchToEditBtn = document.getElementById('memberSwitchToEdit');
    const backToViewBtn = document.getElementById('memberBackToView');
    const copyEmailBtn = document.getElementById('memberCopyEmail');
    const copyStatus = document.getElementById('memberCopyStatus');

    const searchInput = document.getElementById('membersSearch');
    const filterButtons = document.querySelectorAll('.members-filter');
    const cards = document.querySelectorAll('[data-member-card]');
    const noResult = document.getElementById('membersNoResult');
    const visibleCount = document.getElementById('membersVisibleCount');

    let currentMember = null;
    let currentFilter = 'all';

    function escapeHtml(value) {
        return String(value ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function normalize(value) {
        return String(value || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim();
    }

    function openModal() {
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('noscroll');
    }

    function closeModal() {
        closeAdGroupsModal();
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('noscroll');
        currentMember = null;

        if (copyStatus) {
            copyStatus.textContent = '';
        }
    }

    function showViewPanel() {
        if (viewPanel) {
            viewPanel.classList.remove('member-hidden');
        }

        if (editPanel) {
            editPanel.classList.add('member-hidden');
        }

        title.textContent = 'Fiche utilisateur';
    }

    function showEditPanel() {
        if (!isSystemAdmin || !currentMember || !editPanel) {
            return;
        }

        fillEditForm(currentMember);

        viewPanel.classList.add('member-hidden');
        editPanel.classList.remove('member-hidden');
        title.textContent = 'Modifier utilisateur';
    }

    function makeStatusHtml(member) {
        const online = !!member.is_online;
        const label = escapeHtml(member.online_label || 'Déconnecté');
        const lastSeen = escapeHtml(member.last_seen_label || 'Non connecté');
        const className = online ? 'is-online' : 'is-offline';

        return `<span class="member-status-inline ${className}"><span></span>${label} <small>${lastSeen}</small></span>`;
    }

    function closeAdGroupsModal() {
        if (!adGroupsModal) {
            return;
        }
        adGroupsModal.classList.remove('active');
        adGroupsModal.setAttribute('aria-hidden', 'true');
    }

    function openAdGroupsModal(member) {
        if (!adGroupsModal || !member || !member.is_ad) {
            return;
        }

        const groups = Array.isArray(member.ad_groups) ? member.ad_groups : [];
        const login = String(member.ad_full_username || member.ad_username || '').trim();

        if (adGroupsLogin) {
            adGroupsLogin.innerHTML = login !== ''
                ? `<strong>${escapeHtml(login)}</strong>`
                : '<strong>Compte Active Directory</strong>';
        }

        if (adGroupsList) {
            if (groups.length > 0) {
                adGroupsList.innerHTML = groups.map(group => {
                    const name = String(group?.name || group?.dn || 'Groupe AD').trim();
                    const dn = String(group?.dn || '').trim();
                    return `<div class="member-ad-group-item"><strong>${escapeHtml(name)}</strong>${dn !== '' ? `<small>${escapeHtml(dn)}</small>` : ''}</div>`;
                }).join('');
            } else {
                adGroupsList.innerHTML = '<div class="member-ad-group-item"><strong>Aucun groupe remonté par la dernière synchronisation AD.</strong></div>';
            }
        }

        if (adGroupsNote) {
            const sync = String(member.ad_last_sync_at || '').trim();
            adGroupsNote.textContent = sync !== ''
                ? `Groupes enregistrés lors de la dernière synchronisation AD : ${sync}`
                : 'Groupes enregistrés dans le profil DoMyDesk lors de la synchronisation Active Directory.';
        }

        adGroupsModal.classList.add('active');
        adGroupsModal.setAttribute('aria-hidden', 'false');
    }

    function fillView(member) {
        currentMember = member;

        if (copyStatus) {
            copyStatus.textContent = '';
        }

        title.textContent = 'Fiche utilisateur';
        viewPrenom.textContent = String(member.prenom || '').trim() || 'Non renseigné';
        viewNom.textContent = String(member.nom || '').trim() || 'Non renseigné';
        viewPseudo.textContent = String(member.pseudo || '').trim() || 'Non renseigné';
        viewEmail.textContent = member.email || member.folder || 'Non renseigné';

        const isAdMember = !!member.is_ad;
        if (viewAdIdentity) {
            viewAdIdentity.classList.toggle('member-hidden', !isAdMember);
        }
        if (viewAdLogin) {
            viewAdLogin.textContent = isAdMember
                ? (String(member.ad_full_username || member.ad_username || '').trim() || 'Identifiant AD non renseigné')
                : '';
        }
        if (viewAdGroupsCount) {
            viewAdGroupsCount.textContent = isAdMember ? String(member.ad_group_count || 0) : '0';
        }
        if (viewAdGroupsButton) {
            viewAdGroupsButton.hidden = !isAdMember;
            const count = Number(member.ad_group_count || 0);
            const label = count > 1 ? `${count} groupes Active Directory` : `${count} groupe Active Directory`;
            viewAdGroupsButton.title = isAdMember ? `Voir ${label}` : 'Voir les groupes Active Directory';
            viewAdGroupsButton.setAttribute('aria-label', isAdMember ? `Voir ${label}` : 'Voir les groupes Active Directory');
        }

        if (viewOnlineStatus) {
            viewOnlineStatus.innerHTML = makeStatusHtml(member);
        }

        if (viewAvatarStatus) {
            const online = !!member.is_online;
            viewAvatarStatus.classList.toggle('is-online', online);
            viewAvatarStatus.classList.toggle('is-offline', !online);
            viewAvatarStatus.setAttribute('aria-label', member.online_label || (online ? 'Connecté' : 'Déconnecté'));
            viewAvatarStatus.title = `${member.online_label || (online ? 'Connecté' : 'Déconnecté')} - ${member.last_seen_label || ''}`;
        }

        viewRoleSystem.textContent = member.role_system || 'user';
        viewRoleMetier.textContent = member.role_metier || 'Aucun rôle métier';
        viewModulesCount.textContent = `${member.modules_enabled || 0} / ${member.modules_total || 0}`;
        viewCreatedAt.textContent = member.created_at_label || 'Non renseignée';

        function setOptionalBox(box, target, value) {
            if (!box || !target) {
                return false;
            }

            const cleanValue = String(value || '').trim();

            if (cleanValue !== '') {
                target.textContent = cleanValue;
                box.classList.remove('member-hidden');
                return true;
            }

            target.textContent = '';
            box.classList.add('member-hidden');
            return false;
        }

        setOptionalBox(viewAdresseBox, viewAdresse, member.adresse || '');
        setOptionalBox(viewVilleBox, viewVille, [member.code_postal, member.ville, member.pays].filter(Boolean).join(' '));
        setOptionalBox(viewTelephoneBox, viewTelephone, member.telephone || '');
        setOptionalBox(viewWhatsappBox, viewWhatsapp, member.whatsapp || '');
        setOptionalBox(viewEntrepriseBox, viewEntreprise, member.entreprise || '');
        setOptionalBox(viewPosteBox, viewPoste, member.poste || '');
        setOptionalBox(viewServiceBox, viewService, member.service || '');

        function buildSocialLinks(member) {
            return [
                ['Facebook', member.facebook],
                ['Groupe Facebook', member.groupe_facebook],
                ['LinkedIn', member.linkedin],
                ['Instagram', member.instagram],
                ['Site web', member.site_web]
            ].filter(item => String(item[1] || '').trim() !== '');
        }

        const socialLinks = buildSocialLinks(member);
        if (viewSocialBox && viewSocial) {
            if (socialLinks.length > 0) {
                viewSocial.innerHTML = socialLinks.map(([label, value]) => {
                    const safeLabel = escapeHtml(label);
                    const safeValue = escapeHtml(value);
                    const href = /^(https?:)?\/\//i.test(value) ? value : '';

                    if (href) {
                        return `<a class="member-link-chip" href="${escapeHtml(href)}" target="_blank" rel="noopener" title="${safeValue}">${safeLabel}</a>`;
                    }

                    return `<span class="member-link-chip" title="${safeValue}">${safeLabel}</span>`;
                }).join('');
                viewSocialBox.classList.remove('member-hidden');
            } else {
                viewSocial.innerHTML = '';
                viewSocialBox.classList.add('member-hidden');
            }
        }

        setOptionalBox(viewBioBox, viewBio, [member.bio, member.autres_infos].filter(Boolean).join('\n'));
        setOptionalBox(viewNotesAdminBox, viewNotesAdmin, member.notes_admin || '');

        if (viewBanner && viewIdentity) {
            if (member.banner_exists && member.banner_src) {
                viewBanner.innerHTML = `<img src="${escapeHtml(member.banner_src)}" alt="Bannière">`;
                viewBanner.classList.remove('member-hidden');
                viewIdentity.classList.add('has-banner');
            } else {
                viewBanner.innerHTML = '';
                viewBanner.classList.add('member-hidden');
                viewIdentity.classList.remove('has-banner');
            }
        }

        if (member.avatar_exists && member.avatar_src) {
            avatar.innerHTML = `<img class="member-view-avatar" src="${escapeHtml(member.avatar_src)}" alt="Avatar">`;
        } else {
            avatar.innerHTML = `<div class="member-view-avatar-fallback">${escapeHtml(member.initials || '?')}</div>`;
        }

        const enabledModules = Array.isArray(member.enabled_modules) ? member.enabled_modules : [];

        if (enabledModules.length > 0) {
            viewModulesList.innerHTML = enabledModules.map(module => {
                return `<div class="member-module-item">${escapeHtml(module.name || module.id || 'Module')}</div>`;
            }).join('');
        } else {
            viewModulesList.innerHTML = `<div class="member-module-item">Aucun module activé</div>`;
        }
    }

    function roleAllowsModule(role, moduleId) {
        const roleData = roleModules[role] || {};
        const modules = roleData.modules || {};
        return !!(modules[moduleId] && modules[moduleId].enabled);
    }

    function moduleAccessMode(moduleId) {
        return moduleAccessModes[moduleId] === 'everyone' ? 'everyone' : 'controlled';
    }

    function refreshEditModuleResults() {
        const roleSelect = document.getElementById('editRoleMetier');
        const systemSelect = document.getElementById('editRoleSystem');
        const selectedRole = roleSelect ? roleSelect.value : '';
        const selectedSystem = systemSelect ? systemSelect.value : 'user';
        const adminBypass = selectedSystem === 'admin' || selectedSystem === 'superadmin';

        document.querySelectorAll('[data-module-permission-row]').forEach(row => {
            const moduleId = row.dataset.moduleId || '';
            const overrideSelect = row.querySelector('[data-module-override]');
            const result = row.querySelector('[data-module-result]');
            const state = overrideSelect ? overrideSelect.value : 'inherit';
            const accessMode = moduleAccessMode(moduleId);
            const inherited = accessMode === 'everyone' ? true : roleAllowsModule(selectedRole, moduleId);

            let allowed = inherited;
            let source = accessMode === 'everyone'
                ? 'Autorisé à tous les utilisateurs'
                : (inherited ? `Hérité de ${selectedRole || '—'}` : 'Non attribué par le rôle');

            if (adminBypass) {
                allowed = true;
                source = 'Administrateur : accès complet';
            } else if (state === 'allow') {
                allowed = true;
                source = 'Exception utilisateur : autorisé';
            } else if (state === 'deny') {
                allowed = false;
                source = 'Exception utilisateur : refusé';
            }

            if (result) {
                result.innerHTML = `<strong>${allowed ? '✓ Autorisé' : '✕ Refusé'}</strong><small>${escapeHtml(source)}</small>`;
            }
        });
    }

    function renderEditModulePermissions(member) {
        const container = document.getElementById('editModulePermissions');

        if (!container) {
            return;
        }

        const matrix = member.module_matrix || {};
        const entries = Object.values(matrix);

        if (entries.length === 0) {
            container.innerHTML = '<div class="member-module-item">Aucun module installé.</div>';
            return;
        }

        container.innerHTML = entries.map(module => {
            const id = module.id || '';
            const name = module.name || id || 'Module';
            const override = ['inherit', 'allow', 'deny'].includes(module.override) ? module.override : 'inherit';
            const accessMode = module.access_mode === 'everyone' ? 'everyone' : 'controlled';
            const inheritLabel = accessMode === 'everyone' ? 'Droit global' : 'Hérité du rôle';

            return `
                <div class="member-module-right" data-module-permission-row data-module-id="${escapeHtml(id)}">
                    <div>
                        <strong>${escapeHtml(name)}</strong>
                        <small>${escapeHtml(id)}</small>
                    </div>
                    <select name="module_overrides[${escapeHtml(id)}]" data-module-override>
                        <option value="inherit" ${override === 'inherit' ? 'selected' : ''}>${inheritLabel}</option>
                        <option value="allow" ${override === 'allow' ? 'selected' : ''}>Autorisé</option>
                        <option value="deny" ${override === 'deny' ? 'selected' : ''}>Refusé</option>
                    </select>
                    <div class="member-module-result" data-module-result></div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('[data-module-override]').forEach(select => {
            select.addEventListener('change', refreshEditModuleResults);
        });

        refreshEditModuleResults();
    }

    function fillEditForm(member) {
        const editTargetEmail = document.getElementById('editTargetEmail');
        const editEmailReadonly = document.getElementById('editEmailReadonly');
        const editPrenom = document.getElementById('editPrenom');
        const editNom = document.getElementById('editNom');
        const editRoleSystem = document.getElementById('editRoleSystem');
        const editRoleMetier = document.getElementById('editRoleMetier');
        const editFieldIds = {
            pseudo: 'editPseudo', adresse: 'editAdresse', code_postal: 'editCodePostal', ville: 'editVille', pays: 'editPays',
            telephone: 'editTelephone', whatsapp: 'editWhatsapp', facebook: 'editFacebook', groupe_facebook: 'editGroupeFacebook', linkedin: 'editLinkedin',
            instagram: 'editInstagram', site_web: 'editSiteWeb', entreprise: 'editEntreprise', poste: 'editPoste', service: 'editService',
            bio: 'editBio', autres_infos: 'editAutresInfos', notes_admin: 'editNotesAdmin'
        };

        if (!editTargetEmail || !editEmailReadonly || !editPrenom || !editNom || !editRoleSystem || !editRoleMetier) {
            return;
        }

        editTargetEmail.value = member.folder || '';
        editEmailReadonly.value = member.email || member.folder || '';
        editPrenom.value = member.prenom || '';
        editNom.value = member.nom || '';

        Object.entries(editFieldIds).forEach(([fieldName, elementId]) => {
            const input = document.getElementById(elementId);
            if (input) {
                input.value = member[fieldName] || '';
            }
        });

        const editNewPassword = document.getElementById('editNewPassword');
        const editNewPasswordConfirm = document.getElementById('editNewPasswordConfirm');
        if (editNewPassword) editNewPassword.value = '';
        if (editNewPasswordConfirm) editNewPasswordConfirm.value = '';

        const editAvatar = document.getElementById('editAvatar');
        const editDeleteAvatar = document.getElementById('editDeleteAvatar');

        if (editAvatar) {
            editAvatar.value = '';
        }

        if (editDeleteAvatar) {
            editDeleteAvatar.checked = false;
        }

        const currentRoleSystem = member.role_system || 'user';
        const systemRoles = [...roleSystemOptions];

        if (!systemRoles.includes(currentRoleSystem)) {
            systemRoles.push(currentRoleSystem);
        }

        editRoleSystem.innerHTML = systemRoles.map(role => {
            const selected = role === currentRoleSystem ? 'selected' : '';
            return `<option value="${escapeHtml(role)}" ${selected}>${escapeHtml(role)}</option>`;
        }).join('');

        const currentRoleMetier = member.role_metier || '';
        const metierRoles = [''];

        rolesMetier.forEach(role => {
            if (role && !metierRoles.includes(role)) {
                metierRoles.push(role);
            }
        });

        if (currentRoleMetier && !metierRoles.includes(currentRoleMetier)) {
            metierRoles.push(currentRoleMetier);
        }

        editRoleMetier.innerHTML = metierRoles.map(role => {
            const selected = role === currentRoleMetier ? 'selected' : '';
            const label = role === '' ? 'Aucun rôle métier' : role;
            return `<option value="${escapeHtml(role)}" ${selected}>${escapeHtml(label)}</option>`;
        }).join('');

        renderEditModulePermissions(member);

        editRoleMetier.onchange = refreshEditModuleResults;
        editRoleSystem.onchange = refreshEditModuleResults;
        refreshEditModuleResults();
    }

    function openMember(folder, mode) {
        const member = membersByFolder[folder];

        if (!member) {
            return;
        }

        fillView(member);
        openModal();

        if (mode === 'edit') {
            showEditPanel();
        } else {
            showViewPanel();
        }
    }

    function applyFilters() {
        const query = normalize(searchInput ? searchInput.value : '');
        let shown = 0;

        cards.forEach(card => {
            const searchText = normalize(card.dataset.search || '');
            const roleSystem = card.dataset.roleSystem || 'user';
            const modulesEnabled = parseInt(card.dataset.modulesEnabled || '0', 10);
            const isOnline = card.dataset.online === '1';

            let filterOk = true;

            if (currentFilter === 'online') {
                filterOk = isOnline;
            } else if (currentFilter === 'offline') {
                filterOk = !isOnline;
            } else if (currentFilter === 'admin') {
                filterOk = roleSystem === 'admin';
            } else if (currentFilter === 'superadmin') {
                filterOk = roleSystem === 'superadmin';
            } else if (currentFilter === 'user') {
                filterOk = roleSystem === 'user';
            } else if (currentFilter === 'with_modules') {
                filterOk = modulesEnabled > 0;
            } else if (currentFilter === 'without_modules') {
                filterOk = modulesEnabled <= 0;
            }

            const searchOk = query === '' || searchText.includes(query);

            if (filterOk && searchOk) {
                card.classList.remove('is-hidden');
                shown++;
            } else {
                card.classList.add('is-hidden');
            }
        });

        if (visibleCount) {
            visibleCount.textContent = shown;
        }

        if (noResult) {
            noResult.classList.toggle('active', shown === 0);
        }
    }

    function fallbackCopyText(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', 'readonly');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();

        let success = false;

        try {
            success = document.execCommand('copy');
        } catch (error) {
            success = false;
        }

        document.body.removeChild(textarea);
        return success;
    }

    async function copyCurrentEmail() {
        if (!currentMember || !currentMember.email) {
            return;
        }

        const email = currentMember.email;
        let copied = false;

        if (navigator.clipboard && window.isSecureContext) {
            try {
                await navigator.clipboard.writeText(email);
                copied = true;
            } catch (error) {
                copied = false;
            }
        }

        if (!copied) {
            copied = fallbackCopyText(email);
        }

        if (copyStatus) {
            copyStatus.textContent = copied ? 'E-mail copié.' : 'Impossible de copier automatiquement.';
        }
    }

    document.querySelectorAll('[data-open-member]').forEach(button => {
        button.addEventListener('click', function () {
            openMember(this.dataset.openMember, 'view');
        });
    });

    document.querySelectorAll('[data-edit-member]').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openMember(this.dataset.editMember, 'edit');
        });
    });

    if (viewAdGroupsButton) {
        viewAdGroupsButton.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            openAdGroupsModal(currentMember);
        });
    }

    document.querySelectorAll('[data-close-ad-groups]').forEach(button => {
        button.addEventListener('click', closeAdGroupsModal);
    });

    if (adGroupsModal) {
        adGroupsModal.addEventListener('click', function (event) {
            if (event.target === adGroupsModal) {
                closeAdGroupsModal();
            }
        });
    }

    document.querySelectorAll('[data-close-member-modal]').forEach(button => {
        button.addEventListener('click', closeModal);
    });

    modal.addEventListener('click', function (event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') {
            return;
        }
        if (adGroupsModal && adGroupsModal.classList.contains('active')) {
            closeAdGroupsModal();
            return;
        }
        if (modal.classList.contains('active')) {
            closeModal();
        }
    });

    if (switchToEditBtn) {
        switchToEditBtn.addEventListener('click', showEditPanel);
    }

    if (backToViewBtn) {
        backToViewBtn.addEventListener('click', showViewPanel);
    }

    if (copyEmailBtn) {
        copyEmailBtn.addEventListener('click', copyCurrentEmail);
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyFilters);
    }

    filterButtons.forEach(button => {
        button.addEventListener('click', function () {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentFilter = this.dataset.filter || 'all';
            applyFilters();
        });
    });

    applyFilters();
})();
</script>

</body>
</html>