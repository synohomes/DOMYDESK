<?php
/**
 * DoMyDesk -> DoMySocial identity bridge.
 * Read-only API: DoMyDesk never depends on DoMySocial to authenticate users.
 */
require_once __DIR__ . '/dmd_permissions.php';
require_once __DIR__ . '/dmd_media.php';
require_once __DIR__ . '/dmd_mfa.php';
require_once __DIR__ . '/directory/dmd_directory.php';

if (!function_exists('dmd_domysocial_bridge_file')) {
    function dmd_domysocial_bridge_file() {
        return DMD_ROOT . '/data/secure/domysocial_bridge.json';
    }
}

if (!function_exists('dmd_domysocial_bridge_read')) {
    function dmd_domysocial_bridge_read() {
        $file=dmd_domysocial_bridge_file();
        $data=is_file($file)?json_decode((string)@file_get_contents($file),true):null;
        return is_array($data)?array_replace(array('version'=>2,'tokens'=>array()),$data):array('version'=>2,'tokens'=>array());
    }
}

if (!function_exists('dmd_domysocial_bridge_write')) {
    function dmd_domysocial_bridge_write($data) {
        if (!is_array($data)) return false;
        $dir=dirname(dmd_domysocial_bridge_file());
        if (!is_dir($dir)) @mkdir($dir,0750,true);
        $data['version']=2; $data['updated_at']=date('c');
        $json=json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;
        $ok=@file_put_contents(dmd_domysocial_bridge_file(),$json."\n",LOCK_EX)!==false;
        if ($ok) @chmod(dmd_domysocial_bridge_file(),0640);
        return $ok;
    }
}

if (!function_exists('dmd_domysocial_bridge_key_from_token')) {
    function dmd_domysocial_bridge_key_from_token($token) {
        return hash('sha256', "DMD-DMS-BRIDGE-KEY\0" . (string)$token, true);
    }
}

if (!function_exists('dmd_domysocial_bridge_generate_token')) {
    function dmd_domysocial_bridge_generate_token($label='DoMySocial') {
        $id=bin2hex(random_bytes(8));
        $secret=rtrim(strtr(base64_encode(random_bytes(32)),'+/','-_'),'=');
        $raw=$id.'.'.$secret;
        $cfg=dmd_domysocial_bridge_read();
        $tokens=array_values(array_filter((array)($cfg['tokens']??array()),function($row){ return is_array($row) && !empty($row['active']); }));
        if (count($tokens)>=50) return false;
        $tokens[]=array(
            'id'=>$id,
            'label'=>substr(trim((string)$label),0,120),
            'key_b64'=>base64_encode(dmd_domysocial_bridge_key_from_token($raw)),
            'created_at'=>date('c'),
            'paired_at'=>'',
            'dms_instance_uid'=>'',
            'dms_instance_name'=>'',
            'last_used_at'=>'',
            'last_ip'=>'',
            'active'=>true,
        );
        $cfg['tokens']=$tokens;
        if (!dmd_domysocial_bridge_write($cfg)) return false;
        return array('id'=>$id,'token'=>$raw);
    }
}

if (!function_exists('dmd_domysocial_bridge_revoke_token')) {
    function dmd_domysocial_bridge_revoke_token($id) {
        $id=trim((string)$id);
        if ($id==='') return false;
        $cfg=dmd_domysocial_bridge_read();
        $found=false; $tokens=array();
        foreach ((array)($cfg['tokens']??array()) as $row) {
            if (!is_array($row)) continue;
            if (hash_equals((string)($row['id']??''),$id)) { $found=true; continue; }
            $tokens[]=$row;
        }
        if (!$found) return false;
        $cfg['tokens']=$tokens;
        return dmd_domysocial_bridge_write($cfg);
    }
}

if (!function_exists('dmd_domysocial_bridge_revoke_all')) {
    function dmd_domysocial_bridge_revoke_all() {
        $cfg=dmd_domysocial_bridge_read(); $cfg['tokens']=array(); return dmd_domysocial_bridge_write($cfg);
    }
}

if (!function_exists('dmd_domysocial_bridge_b64url_decode')) {
    function dmd_domysocial_bridge_b64url_decode($v) {
        $v=strtr((string)$v,'-_','+/'); $pad=strlen($v)%4; if($pad)$v.=str_repeat('=',4-$pad);
        return base64_decode($v,true);
    }
}

if (!function_exists('dmd_domysocial_bridge_verify_request')) {
    function dmd_domysocial_bridge_verify_request($id,$timestamp,$nonce,$signature,$method,$target,$dmsInstanceUid='',$dmsInstanceName='',$bridgeVersion=1) {
        $id=trim((string)$id); $timestamp=(int)$timestamp; $nonce=trim((string)$nonce); $signature=trim((string)$signature);
        $dmsInstanceUid=substr(trim((string)$dmsInstanceUid),0,190);
        $dmsInstanceName=substr(trim((string)$dmsInstanceName),0,120);
        $bridgeVersion=(int)$bridgeVersion;
        if ($id==='' || $timestamp<=0 || abs(time()-$timestamp)>120 || !preg_match('/^[A-Za-z0-9_-]{16,128}$/',$nonce)) return false;
        $cfg=dmd_domysocial_bridge_read();
        foreach ((array)($cfg['tokens']??array()) as $i=>$row) {
            if (empty($row['active']) || !hash_equals((string)($row['id']??''),$id)) continue;
            $key=base64_decode((string)($row['key_b64']??''),true);
            if (!is_string($key) || strlen($key)!==32) return false;
            if ($bridgeVersion>=2 || $dmsInstanceUid!=='') {
                $canonical=strtoupper((string)$method)."\n".(string)$target."\n".$timestamp."\n".$nonce."\n".$dmsInstanceUid."\n".$dmsInstanceName;
            } else {
                $canonical=strtoupper((string)$method)."\n".(string)$target."\n".$timestamp."\n".$nonce;
            }
            $expected=rtrim(strtr(base64_encode(hash_hmac('sha256',$canonical,$key,true)),'+/','-_'),'=');
            if (!hash_equals($expected,$signature)) return false;
            $cfg['tokens'][$i]['last_used_at']=date('c');
            $cfg['tokens'][$i]['last_ip']=(string)($_SERVER['REMOTE_ADDR']??'');
            if ($dmsInstanceUid!=='') {
                $known=trim((string)($cfg['tokens'][$i]['dms_instance_uid']??''));
                if ($known!=='' && !hash_equals($known,$dmsInstanceUid)) return false;
                $cfg['tokens'][$i]['dms_instance_uid']=$dmsInstanceUid;
                $cfg['tokens'][$i]['dms_instance_name']=$dmsInstanceName!==''?$dmsInstanceName:(string)($cfg['tokens'][$i]['label']??'DoMySocial');
                if (empty($cfg['tokens'][$i]['paired_at'])) $cfg['tokens'][$i]['paired_at']=date('c');
            }
            dmd_domysocial_bridge_write($cfg);
            return array('row'=>$cfg['tokens'][$i],'key'=>$key);
        }
        return false;
    }
}

if (!function_exists('dmd_domysocial_bridge_instance_uid')) {
    function dmd_domysocial_bridge_instance_uid() {
        $file=DMD_ROOT.'/data/id_domydesk.txt';
        return is_file($file)?trim((string)@file_get_contents($file)):'';
    }
}

if (!function_exists('dmd_domysocial_bridge_user_uid')) {
    function dmd_domysocial_bridge_user_uid($email,&$profile) {
        $uid=trim((string)($profile['domysocial_bridge_uid']??''));
        if ($uid!=='') return $uid;
        $uid='dmdusr_'.bin2hex(random_bytes(16));
        $profile['domysocial_bridge_uid']=$uid;
        $profile['domysocial_bridge_uid_created_at']=date('c');
        dmd_write_profile($email,$profile);
        return $uid;
    }
}

if (!function_exists('dmd_domysocial_bridge_media')) {
    function dmd_domysocial_bridge_media($file) {
        $file=(string)$file;
        if ($file==='' || !is_file($file) || is_link($file)) return null;
        $size=(int)@filesize($file); if ($size<1 || $size>20*1024*1024) return null;
        $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=(string)$finfo->file($file);
        if (!in_array($mime,array('image/jpeg','image/png','image/webp','image/gif'),true)) return null;
        $raw=@file_get_contents($file); if (!is_string($raw)) return null;
        return array('mime'=>$mime,'size'=>$size,'data'=>base64_encode($raw));
    }
}

if (!function_exists('dmd_domysocial_bridge_user_payload')) {
    function dmd_domysocial_bridge_user_payload($email,$includeMedia=true,$includeMfa=true) {
        $profile=dmd_read_profile($email);
        if (!is_array($profile) || !$profile) return null;
        $uid=dmd_domysocial_bridge_user_uid($email,$profile);
        $display=trim((string)($profile['pseudo']??''));
        if ($display==='') $display=trim((string)($profile['prenom']??'').' '.(string)($profile['nom']??''));
        if ($display==='') $display=$email;
        $status=strtolower((string)($profile['account_status']??'active'));
        $ad=is_array($profile['ad']??null)?$profile['ad']:array();
        $out=array(
            'uid'=>$uid,
            'email'=>(string)($profile['email']??$email),
            'pseudo'=>$display,
            'display_name'=>$display,
            'first_name'=>(string)($profile['prenom']??''),
            'last_name'=>(string)($profile['nom']??''),
            'active'=>!in_array($status,array('suspended','banned','disabled'),true),
            'auth_source'=>(string)($profile['auth_source']??'local'),
            'ad'=>array(
                'object_guid'=>(string)($ad['object_guid']??''),
                'sam_account_name'=>(string)($ad['sam_account_name']??''),
                'user_principal_name'=>(string)($ad['user_principal_name']??''),
                'distinguished_name'=>(string)($ad['distinguished_name']??''),
                'enabled'=>array_key_exists('enabled',$ad)?!empty($ad['enabled']):true,
            ),
        );
        if ($includeMedia) {
            $out['avatar']=dmd_domysocial_bridge_media(dmd_user_avatar_file($email));
            $out['banner']=dmd_domysocial_bridge_media(dmd_user_banner_file($email));
        }
        if ($includeMfa) {
            $mfa=dmd_mfa_read($email);
            $enabled=dmd_mfa_enabled($email);
            $secret=$enabled?dmd_mfa_decrypt_secret((string)($mfa['secret_enc']??'')):'';
            $out['mfa']=array(
                'enabled'=>$enabled && is_string($secret) && $secret!=='',
                'secret'=>is_string($secret)?$secret:'',
                'updated_at'=>(string)($mfa['updated_at']??$mfa['created_at']??''),
            );
        }
        return $out;
    }
}


if (!function_exists('dmd_domysocial_bridge_directory_ca_payload')) {
    function dmd_domysocial_bridge_directory_ca_payload() {
        if (!function_exists('dmd_directory_ca_exists') || !dmd_directory_ca_exists()) return null;
        $file=dmd_directory_ca_file();
        if (!is_file($file) || !is_readable($file)) return null;
        $size=(int)@filesize($file); if ($size<1 || $size>1048576) return null;
        $pem=@file_get_contents($file); if (!is_string($pem) || trim($pem)==='') return null;
        $info=function_exists('dmd_directory_ca_info')?dmd_directory_ca_info():array();
        return array(
            'pem'=>$pem,
            'fingerprint_sha256'=>(string)($info['fingerprint_sha256']??''),
            'subject_cn'=>(string)($info['subject_cn']??''),
            'issuer_cn'=>(string)($info['issuer_cn']??''),
            'valid_to'=>(string)($info['valid_to']??''),
        );
    }
}

if (!function_exists('dmd_domysocial_bridge_export')) {
    function dmd_domysocial_bridge_export($includeUsers=true,$includeMedia=true,$includeMfa=true,$includeDirectory=true) {
        $payload=array(
            'version'=>1,
            'generated_at'=>date('c'),
            'instance'=>array('uid'=>dmd_domysocial_bridge_instance_uid(),'product'=>'DoMyDesk'),
        );
        if ($includeDirectory) {
            $dir=dmd_directory_config_read(true);
            $payload['directory']=array(
                'enabled'=>!empty($dir['enabled']),
                'authentication_enabled'=>!empty($dir['authentication_enabled']),
                'host'=>(string)($dir['host']??''),
                'port'=>(int)($dir['port']??636),
                'security'=>(string)($dir['security']??'ldaps'),
                'verify_certificate'=>array_key_exists('verify_certificate',$dir)?!empty($dir['verify_certificate']):true,
                'timeout'=>(int)($dir['timeout']??8),
                'domain'=>(string)($dir['domain']??''),
                'base_dn'=>(string)($dir['base_dn']??''),
                'bind_user'=>(string)($dir['bind_user']??''),
                'bind_password'=>(string)($dir['bind_password']??''),
                'ca_certificate'=>dmd_domysocial_bridge_directory_ca_payload(),
            );
        }
        if ($includeUsers) {
            $payload['users']=array();
            foreach (glob(DMD_ROOT.'/users/profiles/*',GLOB_ONLYDIR)?:array() as $dir) {
                $email=basename($dir);
                if (dmd_safe_user_key($email)==='') continue;
                $u=dmd_domysocial_bridge_user_payload($email,$includeMedia,$includeMfa);
                if (is_array($u)) $payload['users'][]=$u;
            }
        }
        return $payload;
    }
}

if (!function_exists('dmd_domysocial_bridge_encrypt_payload')) {
    function dmd_domysocial_bridge_encrypt_payload($payload,$key) {
        if (!function_exists('openssl_encrypt') || !is_string($key) || strlen($key)!==32) return false;
        $plain=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (!is_string($plain)) return false;
        $iv=random_bytes(12); $tag='';
        $cipher=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,'DMD-DMS-BRIDGE-V1',16);
        if ($cipher===false) return false;
        return base64_encode($iv.$tag.$cipher);
    }
}
