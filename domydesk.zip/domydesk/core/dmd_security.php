<?php
/**
 * DoMyDesk 1.2.0 - helpers HTTP / CSRF pour les services.
 * Compatible avec le mécanisme de session actuellement utilisé par DoMyDesk.
 * PHP 7.3+
 */

if (!function_exists('dmd_security_session_start')) {
    function dmd_security_session_start() {
        if (session_status() === PHP_SESSION_NONE) {
            /*
             * DoMyDesk garde la session tant que l'utilisateur utilise le site.
             * Certains hébergeurs imposent une durée PHP très courte (ex. 600 s),
             * ce qui pouvait déconnecter un dashboard simplement laissé ouvert.
             *
             * - cookie_lifetime = 0 : cookie valable jusqu'à la fermeture du navigateur
             * - gc_maxlifetime = 12 h : évite une purge serveur trop agressive
             *
             * Le heartbeat applicatif renouvelle ensuite réellement l'activité.
             */
            @ini_set('session.cookie_lifetime', '0');
            @ini_set('session.gc_maxlifetime', '43200');

            $cookie = session_get_cookie_params();
            $params = array(
                'lifetime' => 0,
                'path' => isset($cookie['path']) ? (string)$cookie['path'] : '/',
                'domain' => isset($cookie['domain']) ? (string)$cookie['domain'] : '',
                'secure' => !empty($cookie['secure']),
                'httponly' => !empty($cookie['httponly']),
            );
            if (isset($cookie['samesite']) && (string)$cookie['samesite'] !== '') {
                $params['samesite'] = (string)$cookie['samesite'];
            }
            @session_set_cookie_params($params);
            session_start();
        }
    }
}

if (!function_exists('dmd_csrf_scope')) {
    function dmd_csrf_scope($scope) {
        $scope = strtolower(trim((string)$scope));
        $scope = preg_replace('/[^a-z0-9._-]+/', '_', $scope);
        return $scope !== '' ? $scope : 'core';
    }
}

if (!function_exists('dmd_csrf_token')) {
    function dmd_csrf_token($scope = 'core') {
        dmd_security_session_start();
        $scope = dmd_csrf_scope($scope);
        if (!isset($_SESSION['dmd_csrf']) || !is_array($_SESSION['dmd_csrf'])) {
            $_SESSION['dmd_csrf'] = array();
        }
        if (empty($_SESSION['dmd_csrf'][$scope]) || !is_string($_SESSION['dmd_csrf'][$scope])) {
            try {
                $_SESSION['dmd_csrf'][$scope] = bin2hex(random_bytes(32));
            } catch (Exception $e) {
                $_SESSION['dmd_csrf'][$scope] = hash('sha256', uniqid('', true) . mt_rand());
            }
        }
        return (string)$_SESSION['dmd_csrf'][$scope];
    }
}

if (!function_exists('dmd_csrf_request_token')) {
    function dmd_csrf_request_token($payload = null) {
        if (!empty($_SERVER['HTTP_X_DMD_CSRF'])) {
            return trim((string)$_SERVER['HTTP_X_DMD_CSRF']);
        }
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            if (is_array($headers)) {
                foreach ($headers as $key => $value) {
                    if (strtolower((string)$key) === 'x-dmd-csrf') return trim((string)$value);
                }
            }
        }
        if (is_array($payload) && isset($payload['csrf_token'])) return trim((string)$payload['csrf_token']);
        if (isset($_POST['csrf_token'])) return trim((string)$_POST['csrf_token']);
        return '';
    }
}

if (!function_exists('dmd_csrf_validate')) {
    function dmd_csrf_validate($token, $scope = 'core') {
        $expected = dmd_csrf_token($scope);
        $token = trim((string)$token);
        return $token !== '' && hash_equals($expected, $token);
    }
}

if (!function_exists('dmd_json_body')) {
    function dmd_json_body($fallback = array()) {
        $raw = (string)file_get_contents('php://input');
        if ($raw === '') return $fallback;
        $decoded = json_decode($raw, true);
        return (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : $fallback;
    }
}

if (!function_exists('dmd_json_response')) {
    function dmd_json_response($data, $status = 200) {
        if (!headers_sent()) {
            http_response_code((int)$status);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('dmd_api_require_user')) {
    function dmd_api_require_user() {
        dmd_security_session_start();
        $email = isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
        if ($email === '') dmd_json_response(array('ok' => false, 'error' => 'unauthorized'), 401);
        return $email;
    }
}

if (!function_exists('dmd_api_require_method')) {
    function dmd_api_require_method($method) {
        $actual = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        $expected = strtoupper((string)$method);
        if ($actual !== $expected) dmd_json_response(array('ok' => false, 'error' => 'method_not_allowed'), 405);
    }
}

if (!function_exists('dmd_api_require_csrf')) {
    function dmd_api_require_csrf($scope, $payload = null) {
        $token = dmd_csrf_request_token($payload);
        if (!dmd_csrf_validate($token, $scope)) dmd_json_response(array('ok' => false, 'error' => 'csrf_invalid'), 403);
        return true;
    }
}
