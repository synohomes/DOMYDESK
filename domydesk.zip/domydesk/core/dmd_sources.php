<?php
/**
 * DoMyDesk - sources officielles GitHub.
 *
 * Architecture :
 *   /sources/github_sources.json = configuration des URL distantes
 *   /sources/*.json              = dernier cache local valide des catalogues
 *
 * Le catalogue est lu directement depuis GitHub quand il est joignable.
 * En cas d'echec reseau, DoMyDesk peut continuer avec le dernier cache valide.
 */

if (!function_exists('dmd_sources_map')) {
    function dmd_sources_map(): array
    {
        return [
            'actus' => [
                'config_key' => 'actus',
                'cache' => 'actus.json',
            ],
            'modules' => [
                'config_key' => 'modules',
                'cache' => 'listmodules.json',
            ],
            'themes' => [
                'config_key' => 'themes',
                'cache' => 'themes.json',
            ],
            'updates_modules' => [
                'config_key' => 'updates_modules',
                'cache' => 'updatesmodules.json',
            ],
            'updates_systeme' => [
                'config_key' => 'updates_systeme',
                'cache' => 'updatessystems.json',
            ],

            // Alias conserves pour compatibilite.
            'listmodules' => [
                'config_key' => 'modules',
                'cache' => 'listmodules.json',
            ],
            'module_updates' => [
                'config_key' => 'updates_modules',
                'cache' => 'updatesmodules.json',
            ],
            'updatesmodules' => [
                'config_key' => 'updates_modules',
                'cache' => 'updatesmodules.json',
            ],
            'system_updates' => [
                'config_key' => 'updates_systeme',
                'cache' => 'updatessystems.json',
            ],
            'updatessystems' => [
                'config_key' => 'updates_systeme',
                'cache' => 'updatessystems.json',
            ],
        ];
    }
}

if (!function_exists('dmd_source_valid_json_raw')) {
    function dmd_source_valid_json_raw($raw): bool
    {
        if (!is_string($raw) || trim($raw) === '') {
            return false;
        }

        json_decode($raw, true);
        return json_last_error() === JSON_ERROR_NONE;
    }
}

if (!function_exists('dmd_source_definition')) {
    function dmd_source_definition(string $baseDir, string $key, ?string &$error = null): array
    {
        $error = '';
        $map = dmd_sources_map();
        $entryMap = $map[$key] ?? null;

        if (!is_array($entryMap)) {
            $error = 'Source inconnue : ' . $key;
            return [];
        }

        $sourcesDir = rtrim($baseDir, '/\\') . '/sources';
        $configPath = $sourcesDir . '/github_sources.json';

        if (!is_file($configPath)) {
            $error = 'Configuration des sources introuvable : /sources/github_sources.json';
            return [];
        }

        $configRaw = @file_get_contents($configPath);
        $config = is_string($configRaw) ? json_decode($configRaw, true) : null;

        if (!is_array($config)) {
            $error = 'Configuration JSON invalide : /sources/github_sources.json';
            return [];
        }

        $configKey = (string)($entryMap['config_key'] ?? '');
        $sourceConfig = $config[$configKey] ?? null;

        if (!is_array($sourceConfig)) {
            $error = 'Source absente de /sources/github_sources.json : ' . $configKey;
            return [];
        }

        $url = trim((string)($sourceConfig['url'] ?? ''));
        if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
            $error = 'URL invalide dans /sources/github_sources.json pour ' . $configKey;
            return [];
        }

        $parts = parse_url($url);
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower((string)($parts['host'] ?? ''));

        if ($scheme !== 'https' || !in_array($host, ['raw.githubusercontent.com', 'github.com'], true)) {
            $error = 'URL GitHub non autorisee dans /sources/github_sources.json pour ' . $configKey;
            return [];
        }

        $cacheName = trim((string)($sourceConfig['cache'] ?? ($entryMap['cache'] ?? '')));
        $cacheName = basename($cacheName);
        if ($cacheName === '' || strtolower(pathinfo($cacheName, PATHINFO_EXTENSION)) !== 'json') {
            $cacheName = basename((string)($entryMap['cache'] ?? 'cache.json'));
        }

        return [
            'key' => $key,
            'config_key' => $configKey,
            'source_file' => 'github_sources.json',
            'source_path' => $configPath,
            'cache_file' => $cacheName,
            'cache_path' => $sourcesDir . '/' . $cacheName,
            'url' => $url,
        ];
    }
}

if (!function_exists('dmd_source_url')) {
    function dmd_source_url(string $baseDir, string $key, ?string &$error = null): string
    {
        $entry = dmd_source_definition($baseDir, $key, $error);
        return (string)($entry['url'] ?? '');
    }
}

if (!function_exists('dmd_source_fresh_url')) {
    function dmd_source_fresh_url(string $url): string
    {
        if ($url === '') {
            return '';
        }

        $separator = strpos($url, '?') === false ? '?' : '&';
        return $url . $separator . '_dmd_refresh=' . rawurlencode(sprintf('%.6F', microtime(true)));
    }
}

if (!function_exists('dmd_source_http_get')) {
    function dmd_source_http_get(string $url, bool $forceRefresh = false, ?string &$error = null)
    {
        $error = '';
        $requestUrl = $forceRefresh ? dmd_source_fresh_url($url) : $url;

        if (function_exists('curl_init')) {
            $ch = curl_init($requestUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 6,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_USERAGENT => 'DoMyDesk-Sources/1.2.0',
                CURLOPT_HTTPHEADER => [
                    'Accept: application/json',
                    'Cache-Control: no-cache, no-store, must-revalidate',
                    'Pragma: no-cache',
                ],
                CURLOPT_FRESH_CONNECT => $forceRefresh,
                CURLOPT_FORBID_REUSE => $forceRefresh,
            ]);

            $body = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);

            if ($body === false) {
                $error = 'cURL : ' . $curlError;
                return false;
            }
            if ($code < 200 || $code >= 300) {
                $error = 'HTTP ' . $code;
                return false;
            }

            return (string)$body;
        }

        $headers =
            "User-Agent: DoMyDesk-Sources/1.2.0\r\n" .
            "Accept: application/json\r\n" .
            "Cache-Control: no-cache, no-store, must-revalidate\r\n" .
            "Pragma: no-cache\r\n" .
            "Connection: close\r\n";

        $context = stream_context_create([
            'http' => [
                'timeout' => 30,
                'ignore_errors' => true,
                'header' => $headers,
            ],
            'https' => [
                'timeout' => 30,
                'ignore_errors' => true,
                'header' => $headers,
            ],
        ]);

        $body = @file_get_contents($requestUrl, false, $context);
        if ($body === false) {
            $error = 'Telechargement GitHub impossible.';
            return false;
        }

        if (isset($http_response_header) && is_array($http_response_header) && isset($http_response_header[0])) {
            if (preg_match('~\s(\d{3})\s~', (string)$http_response_header[0], $m)) {
                $code = (int)$m[1];
                if ($code < 200 || $code >= 300) {
                    $error = 'HTTP ' . $code;
                    return false;
                }
            }
        }

        return (string)$body;
    }
}

if (!function_exists('dmd_source_cache_read')) {
    function dmd_source_cache_read(array $entry)
    {
        $cachePath = (string)($entry['cache_path'] ?? '');
        if ($cachePath === '' || !is_file($cachePath)) {
            return false;
        }

        $raw = @file_get_contents($cachePath);
        return dmd_source_valid_json_raw($raw) ? (string)$raw : false;
    }
}

if (!function_exists('dmd_source_cache_write')) {
    function dmd_source_cache_write(array $entry, string $raw): bool
    {
        if (!dmd_source_valid_json_raw($raw)) {
            return false;
        }

        $cachePath = (string)($entry['cache_path'] ?? '');
        if ($cachePath === '') {
            return false;
        }

        $dir = dirname($cachePath);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        $tmp = $cachePath . '.tmp-' . getmypid() . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
        if (@file_put_contents($tmp, $raw, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }

        @chmod($tmp, 0664);
        if (!@rename($tmp, $cachePath)) {
            @unlink($tmp);
            return false;
        }

        @chmod($cachePath, 0664);
        return true;
    }
}

if (!function_exists('dmd_source_refresh')) {
    function dmd_source_refresh(string $baseDir, string $key, ?string &$error = null)
    {
        $entry = dmd_source_definition($baseDir, $key, $error);
        if (!$entry) {
            return false;
        }

        $raw = dmd_source_http_get($entry['url'], true, $error);
        if ($raw === false) {
            return false;
        }

        if (!dmd_source_valid_json_raw($raw)) {
            $error = 'Le fichier recu depuis GitHub n\'est pas un JSON valide.';
            return false;
        }

        if (!dmd_source_cache_write($entry, $raw)) {
            $error = 'Catalogue recu mais impossible a mettre en cache dans /sources/' . $entry['cache_file'];
            return false;
        }

        return $raw;
    }
}

if (!function_exists('dmd_source_load_raw')) {
    function dmd_source_load_raw(
        string $baseDir,
        string $key,
        bool $forceRefresh = false,
        ?string &$error = null,
        ?bool &$refreshed = null
    ) {
        $error = '';
        $refreshed = false;

        $entry = dmd_source_definition($baseDir, $key, $error);
        if (!$entry) {
            return false;
        }

        $remoteError = '';
        $raw = dmd_source_http_get($entry['url'], $forceRefresh, $remoteError);

        if ($raw !== false && dmd_source_valid_json_raw($raw)) {
            // On garde toujours le dernier catalogue GitHub valide en cache local.
            dmd_source_cache_write($entry, (string)$raw);
            $refreshed = true;
            $error = '';
            return (string)$raw;
        }

        if ($raw !== false && !dmd_source_valid_json_raw($raw)) {
            $remoteError = 'Le fichier recu depuis GitHub n\'est pas un JSON valide.';
        }

        // GitHub indisponible : conserver le fonctionnement avec le dernier cache valide.
        $cached = dmd_source_cache_read($entry);
        if ($cached !== false) {
            $error = $remoteError;
            return $cached;
        }

        $error = $remoteError !== ''
            ? $remoteError
            : 'Catalogue GitHub indisponible et aucun cache local valide.';
        return false;
    }
}

if (!function_exists('dmd_source_load_json')) {
    function dmd_source_load_json(
        string $baseDir,
        string $key,
        bool $forceRefresh = false,
        ?string &$error = null,
        ?bool &$refreshed = null
    ): array {
        $raw = dmd_source_load_raw($baseDir, $key, $forceRefresh, $error, $refreshed);
        if ($raw === false) {
            return [];
        }

        $data = json_decode($raw, true);
        if (!is_array($data)) {
            $error = 'Le JSON GitHub ne contient pas une structure exploitable.';
            return [];
        }

        return $data;
    }
}
