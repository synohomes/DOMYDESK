<?php
/**
 * DoMyDesk 1.2.0 - Médias utilisateur / site.
 *
 * Les GIF sont conservés tels quels (pas de réencodage) afin de préserver
 * l'animation. Les fichiers sont seulement validés, renommés et rangés.
 */

if (!defined('DMD_MEDIA_ROOT')) {
    define('DMD_MEDIA_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_media_safe_email')) {
    function dmd_media_safe_email($email) {
        $email = trim((string)$email);
        if ($email === '' || basename($email) !== $email) return '';
        if (strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) return '';
        return $email;
    }
}

if (!function_exists('dmd_media_normalize_ext')) {
    function dmd_media_normalize_ext($ext) {
        $ext = strtolower(trim((string)$ext));
        return $ext === 'jpeg' ? 'jpg' : $ext;
    }
}

if (!function_exists('dmd_media_find_named')) {
    function dmd_media_find_named($dir, $stem, $extensions = null) {
        $dir = rtrim((string)$dir, '/\\') . '/';
        $stem = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$stem);
        if ($stem === '') return '';

        if ($extensions === null) {
            foreach (glob($dir . $stem . '.*') ?: array() as $candidate) {
                if (!is_file($candidate)) continue;
                $ext = strtolower((string)pathinfo($candidate, PATHINFO_EXTENSION));
                if ($ext !== '' && preg_match('/^[a-z0-9]{1,12}$/', $ext)) return $candidate;
            }
            return '';
        }

        foreach ($extensions as $ext) {
            $candidate = $dir . $stem . '.' . $ext;
            if (is_file($candidate)) return $candidate;
        }
        return '';
    }
}

if (!function_exists('dmd_media_remove_named')) {
    function dmd_media_remove_named($dir, $stem, $extensions = null) {
        $dir = rtrim((string)$dir, '/\\') . '/';
        $stem = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$stem);
        if ($stem === '') return;

        if ($extensions === null) {
            foreach (glob($dir . $stem . '.*') ?: array() as $candidate) {
                if (is_file($candidate)) @unlink($candidate);
            }
            return;
        }

        foreach ($extensions as $ext) {
            $candidate = $dir . $stem . '.' . $ext;
            if (is_file($candidate)) @unlink($candidate);
        }
    }
}

if (!function_exists('dmd_media_svg_is_safe')) {
    function dmd_media_svg_is_safe($tmp) {
        $raw = @file_get_contents($tmp);
        if ($raw === false || trim($raw) === '') return false;
        if (stripos($raw, '<svg') === false) return false;

        $blocked = array(
            '/<\\s*script\\b/i',
            '/<\\s*foreignObject\\b/i',
            '/\\bon[a-z0-9_-]+\\s*=/i',
            '/javascript\\s*:/i',
            '/data\\s*:\\s*text\\/html/i',
            '/(?:href|xlink:href)\\s*=\\s*["\\\']\\s*(?:https?:|\\/\\/)/i',
            '/url\\s*\\(\\s*["\\\']?\\s*(?:https?:|\\/\\/)/i',
        );
        foreach ($blocked as $pattern) {
            if (preg_match($pattern, $raw)) return false;
        }
        return true;
    }
}

if (!function_exists('dmd_media_validate_upload')) {
    function dmd_media_validate_upload($file, $allowSvg = false) {
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return array('success' => false, 'error' => 'Fichier absent ou upload invalide.');
        }

        $tmp = (string)($file['tmp_name'] ?? '');
        $name = (string)($file['name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return array('success' => false, 'error' => 'Fichier temporaire invalide.');
        }

        $originalExt = dmd_media_normalize_ext(pathinfo($name, PATHINFO_EXTENSION));
        $mime = '';

        if (class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = strtolower(trim((string)$finfo->file($tmp)));
        }

        $imageInfo = null;
        if (function_exists('getimagesize')) {
            $imageInfo = @getimagesize($tmp);
            if (is_array($imageInfo) && !empty($imageInfo['mime'])) {
                $detectedMime = strtolower(trim((string)$imageInfo['mime']));
                if ($detectedMime !== '') $mime = $detectedMime;
            }
        }

        $mimeToExt = array(
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/pjpeg' => 'jpg',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'image/bmp' => 'bmp',
            'image/x-ms-bmp' => 'bmp',
            'image/avif' => 'avif',
            'image/x-icon' => 'ico',
            'image/vnd.microsoft.icon' => 'ico',
            'image/svg+xml' => 'svg',
        );

        $looksSvg = ($originalExt === 'svg' || $mime === 'image/svg+xml');
        if ($looksSvg) {
            if (!$allowSvg) {
                return array('success' => false, 'error' => 'SVG non autorisé pour cet emplacement.');
            }
            if (!dmd_media_svg_is_safe($tmp)) {
                return array('success' => false, 'error' => 'SVG refusé : contenu potentiellement dangereux.');
            }
            return array('success' => true, 'error' => '', 'ext' => 'svg', 'tmp' => $tmp, 'mime' => 'image/svg+xml');
        }

        $isImageMime = ($mime !== '' && strpos($mime, 'image/') === 0);
        if (!is_array($imageInfo) && !$isImageMime) {
            return array('success' => false, 'error' => 'Le fichier ne semble pas être une image valide.');
        }

        // L'extension finale vient en priorité du contenu réel. Pour un format
        // image moins courant reconnu par PHP, on conserve son extension propre.
        $ext = isset($mimeToExt[$mime]) ? $mimeToExt[$mime] : '';
        if ($ext === '' && preg_match('/^[a-z0-9]{1,12}$/', $originalExt)) {
            $ext = $originalExt;
        }
        if ($ext === '' && $isImageMime) {
            $subtype = strtolower((string)substr($mime, 6));
            $subtype = preg_replace('/[^a-z0-9]/', '', $subtype);
            if ($subtype === 'jpeg' || $subtype === 'pjpeg') $subtype = 'jpg';
            if ($subtype !== '') $ext = substr($subtype, 0, 12);
        }

        if ($ext === '') {
            return array('success' => false, 'error' => 'Impossible de déterminer le format de cette image.');
        }

        return array('success' => true, 'error' => '', 'ext' => $ext, 'tmp' => $tmp, 'mime' => $mime);
    }
}

if (!function_exists('dmd_media_store_upload')) {
    function dmd_media_store_upload($file, $dir, $stem, $allowSvg = false) {
        $check = dmd_media_validate_upload($file, $allowSvg);
        if (empty($check['success'])) return $check;

        $dir = rtrim((string)$dir, '/\\') . '/';
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return array('success' => false, 'error' => 'Impossible de créer le dossier de destination.');
        }
        @chmod($dir, 0775);

        dmd_media_remove_named($dir, $stem);
        $target = $dir . $stem . '.' . $check['ext'];
        if (!@move_uploaded_file($check['tmp'], $target)) {
            return array('success' => false, 'error' => 'Impossible d’enregistrer l’image.');
        }
        @chmod($target, 0664);
        return array('success' => true, 'error' => '', 'file' => $target, 'ext' => $check['ext']);
    }
}

if (!function_exists('dmd_media_public_url')) {
    function dmd_media_public_url($absoluteFile) {
        $absoluteFile = str_replace('\\', '/', (string)$absoluteFile);
        $root = str_replace('\\', '/', rtrim(DMD_MEDIA_ROOT, '/\\')) . '/';
        if ($absoluteFile === '' || strpos($absoluteFile, $root) !== 0) return '';
        $relative = substr($absoluteFile, strlen($root));
        $segments = array_map('rawurlencode', explode('/', $relative));
        $url = '/domydesk/' . implode('/', $segments);
        if (is_file($absoluteFile)) $url .= '?v=' . (int)@filemtime($absoluteFile);
        return $url;
    }
}

if (!function_exists('dmd_user_media_dir')) {
    function dmd_user_media_dir($email, $create = false) {
        $safe = dmd_media_safe_email($email);
        if ($safe === '') return '';
        $dir = DMD_MEDIA_ROOT . '/users/profiles/' . $safe . '/avatarban/';
        if ($create && !is_dir($dir)) {
            @mkdir($dir, 0775, true);
            @chmod($dir, 0775);
        }
        return $dir;
    }
}

if (!function_exists('dmd_user_avatar_file')) {
    function dmd_user_avatar_file($email) {
        $safe = dmd_media_safe_email($email);
        if ($safe === '') return '';

        $mediaDir = dmd_user_media_dir($safe, false);
        $file = dmd_media_find_named($mediaDir, 'avatar');
        if ($file !== '') return $file;

        // Compatibilité 1.1/ancienne 1.2 : migration automatique de l'ancien
        // avatar situé à la racine du profil vers avatarban/.
        $legacyDir = DMD_MEDIA_ROOT . '/users/profiles/' . $safe . '/';
        $legacy = dmd_media_find_named($legacyDir, 'avatar');
        if ($legacy === '') return '';

        $targetDir = dmd_user_media_dir($safe, true);
        if ($targetDir !== '') {
            $ext = dmd_media_normalize_ext(pathinfo($legacy, PATHINFO_EXTENSION));
            $target = $targetDir . 'avatar.' . $ext;
            dmd_media_remove_named($targetDir, 'avatar');

            if (@rename($legacy, $target) || (@copy($legacy, $target) && @unlink($legacy))) {
                @chmod($target, 0664);
                return $target;
            }
        }

        return $legacy;
    }
}

if (!function_exists('dmd_user_banner_file')) {
    function dmd_user_banner_file($email) {
        return dmd_media_find_named(dmd_user_media_dir($email, false), 'baniere');
    }
}

if (!function_exists('dmd_site_asset_file')) {
    function dmd_site_asset_file($settings, $key) {
        if (!is_array($settings)) return '';
        $rel = trim((string)($settings[$key] ?? ''));
        if ($rel === '') return '';
        $rel = str_replace('\\', '/', $rel);
        if (strpos($rel, '..') !== false) return '';
        $file = DMD_MEDIA_ROOT . '/adm/' . ltrim($rel, '/');
        return is_file($file) ? $file : '';
    }
}

if (!function_exists('dmd_site_settings_read')) {
    function dmd_site_settings_read() {
        $file = DMD_MEDIA_ROOT . '/adm/settings.json';
        if (!is_file($file)) return array();
        $data = json_decode((string)@file_get_contents($file), true);
        return is_array($data) ? $data : array();
    }
}

if (!function_exists('dmd_effective_user_banner_file')) {
    function dmd_effective_user_banner_file($email, $settings = null) {
        $userBanner = dmd_user_banner_file($email);
        if ($userBanner !== '') return $userBanner;
        if ($settings === null) $settings = dmd_site_settings_read();
        return dmd_site_asset_file($settings, 'banner_path');
    }
}
