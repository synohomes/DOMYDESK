(function () {
    'use strict';

    const VIEW_KEY = 'dmd:view-mode';
    const FIRST_CHOICE_KEY = 'dmd:view-mode-chosen';
    let workspaceConfig = {};
    let currentModule = null;
    let moduleMenu = null;
    let viewChooser = null;
    let documentViewer = null;


    /* ========================================================
       Mémoire géométrique DoMyDesk
       - modules : conserve la dernière taille/position même après fermeture ;
       - popups : conserve une géométrie indépendante par fenêtre ;
       - stockage persistant : users/profiles/<email>/workspace_state.json.
       ======================================================== */
    let windowStateCache = {
        schema: 1,
        modules: {},
        module_defaults: {},
        popups: {}
    };
    let windowStatePromise = null;
    let highestWindowZIndex = 6600;

    function finiteNumber(value, fallback) {
        const n = Number(value);
        return Number.isFinite(n) ? n : fallback;
    }

    function cleanStateKey(value, fallback) {
        const key = String(value == null ? '' : value)
            .trim()
            .replace(/[^a-zA-Z0-9._:@-]+/g, '_')
            .replace(/^_+|_+$/g, '')
            .slice(0, 180);
        return key || fallback;
    }

    function stateEndpoint() {
        return safeText(workspaceConfig.windowStateUrl, 'users/workspace_state.php');
    }

    function normalizeWindowState(raw) {
        const state = raw && typeof raw === 'object' ? raw : {};
        return {
            schema: 1,
            modules: state.modules && typeof state.modules === 'object' ? state.modules : {},
            module_defaults: state.module_defaults && typeof state.module_defaults === 'object' ? state.module_defaults : {},
            popups: state.popups && typeof state.popups === 'object' ? state.popups : {}
        };
    }

    function loadWindowState() {
        if (windowStatePromise) return windowStatePromise;

        windowStatePromise = fetch(stateEndpoint(), {
            method: 'GET',
            cache: 'no-store',
            credentials: 'same-origin'
        })
            .then(r => r.json().then(data => ({ ok: r.ok, data })))
            .then(result => {
                if (!result.ok || !result.data || !result.data.ok) {
                    throw new Error('workspace_state_load_failed');
                }
                windowStateCache = normalizeWindowState(result.data.state);
                return windowStateCache;
            })
            .catch(err => {
                console.error('[DMDWorkspace state]', err);
                return windowStateCache;
            });

        return windowStatePromise;
    }

    function postWindowGeometry(payload) {
        fetch(stateEndpoint(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            cache: 'no-store',
            credentials: 'same-origin',
            body: JSON.stringify(payload)
        }).catch(err => console.error('[DMDWorkspace state save]', err));
    }

    function clampModuleGeometry(geometry) {
        const g = geometry && typeof geometry === 'object' ? geometry : {};
        return {
            x: Math.max(0, finiteNumber(g.x, 0)),
            y: Math.max(0, finiteNumber(g.y, 0)),
            width: Math.max(120, finiteNumber(g.width, 280)),
            height: Math.max(90, finiteNumber(g.height, 280))
        };
    }

    function moduleGeometryFromElement(moduleEl) {
        if (!moduleEl) return null;
        const width = finiteNumber(parseFloat(moduleEl.style.width), moduleEl.offsetWidth || 280);
        const height = finiteNumber(parseFloat(moduleEl.style.height), moduleEl.offsetHeight || 280);
        return clampModuleGeometry({
            x: finiteNumber(parseFloat(moduleEl.style.left), 0),
            y: finiteNumber(parseFloat(moduleEl.style.top), 0),
            width,
            height
        });
    }

    function rememberModuleGeometry(moduleEl, dashboardName) {
        if (!moduleEl || !moduleEl.dataset || !moduleEl.dataset.id || isMobileView()) return;
        if (moduleEl.classList.contains('dmd-module-fullscreen')) return;

        const moduleId = cleanStateKey(moduleEl.dataset.id, 'module');
        const dashboard = cleanStateKey(dashboardName || workspaceConfig.dashboardName, 'dashboard');
        const geometry = moduleGeometryFromElement(moduleEl);
        if (!geometry) return;

        if (!windowStateCache.modules[dashboard] || typeof windowStateCache.modules[dashboard] !== 'object') {
            windowStateCache.modules[dashboard] = {};
        }
        windowStateCache.modules[dashboard][moduleId] = Object.assign({}, geometry);
        windowStateCache.module_defaults[moduleId] = {
            width: geometry.width,
            height: geometry.height
        };

        postWindowGeometry({
            type: 'module',
            dashboard,
            module: moduleId,
            geometry
        });
    }

    async function getRememberedModuleGeometry(moduleId, dashboardName, fallback) {
        await loadWindowState();
        const id = cleanStateKey(moduleId, 'module');
        const dashboard = cleanStateKey(dashboardName || workspaceConfig.dashboardName, 'dashboard');
        const base = Object.assign({ x: 250, y: 280, width: 280, height: 280 }, fallback || {});
        const exact = windowStateCache.modules[dashboard] && windowStateCache.modules[dashboard][id];

        if (exact && typeof exact === 'object') {
            return clampModuleGeometry({
                x: finiteNumber(exact.x, base.x),
                y: finiteNumber(exact.y, base.y),
                width: finiteNumber(exact.width, base.width),
                height: finiteNumber(exact.height, base.height)
            });
        }

        const defaults = windowStateCache.module_defaults[id];
        if (defaults && typeof defaults === 'object') {
            base.width = Math.max(120, finiteNumber(defaults.width, base.width));
            base.height = Math.max(90, finiteNumber(defaults.height, base.height));
        }
        return clampModuleGeometry(base);
    }

    async function restoreModuleGeometry(moduleEl, dashboardName, fallback) {
        if (!moduleEl || isMobileView()) return fallback || null;
        const geometry = await getRememberedModuleGeometry(moduleEl.dataset.id, dashboardName, fallback);
        Object.assign(moduleEl.style, {
            left: geometry.x + 'px',
            top: geometry.y + 'px',
            width: geometry.width + 'px',
            height: geometry.height + 'px'
        });
        return geometry;
    }

    function workspaceElement() {
        return document.getElementById('dashboard');
    }

    function popupOverlay(windowEl) {
        if (!windowEl || !windowEl.closest) return null;
        return windowEl.closest(
            '.dmd-document-overlay, [class*="modal-overlay"], [class*="popup-overlay"], ' +
            '[class*="dialog-overlay"], [class~="overlay"], [class*="backdrop"]'
        );
    }

    function workspacePointFromViewport(x, y) {
        const ws = workspaceElement();
        if (!ws) return { x: Math.max(0, x), y: Math.max(0, y) };
        const wr = ws.getBoundingClientRect();
        return {
            x: Math.max(0, x - wr.left + ws.scrollLeft),
            y: Math.max(0, y - wr.top + ws.scrollTop)
        };
    }

    function normalizePopupGeometry(geometry) {
        const g = geometry && typeof geometry === 'object' ? geometry : {};
        return {
            x: Math.max(0, finiteNumber(g.x, 0)),
            y: Math.max(0, finiteNumber(g.y, 0)),
            width: Math.max(220, finiteNumber(g.width, 440)),
            height: Math.max(120, finiteNumber(g.height, 320))
        };
    }

    function popupGeometryFromElement(windowEl) {
        if (!windowEl) return null;
        const rect = windowEl.getBoundingClientRect();
        const width = finiteNumber(parseFloat(windowEl.style.width), rect.width);
        const height = finiteNumber(parseFloat(windowEl.style.height), rect.height);
        if (!width || !height) return null;

        if (windowEl.classList.contains('dmd-workspace-positioned')) {
            return normalizePopupGeometry({
                x: finiteNumber(parseFloat(windowEl.style.left), 0),
                y: finiteNumber(parseFloat(windowEl.style.top), 0),
                width,
                height
            });
        }

        const point = workspacePointFromViewport(rect.left, rect.top);
        return normalizePopupGeometry({ x: point.x, y: point.y, width, height });
    }

    function popupWindowKey(windowEl, options) {
        const opts = options || {};
        if (opts.key) return cleanStateKey(opts.key, 'popup');
        if (windowEl.dataset && windowEl.dataset.dmdWindowKey) {
            return cleanStateKey(windowEl.dataset.dmdWindowKey, 'popup');
        }

        const moduleOwner = windowEl.closest && windowEl.closest('.module[data-id]');
        const titleEl = windowEl.querySelector && windowEl.querySelector('h1, h2, h3, strong, [class*="title"]');
        const title = titleEl ? safeText(titleEl.textContent, '') : '';
        const classes = Array.from(windowEl.classList || []).slice(0, 4).join('.');
        const localKey = windowEl.id || (classes || 'popup') + (title ? ':' + title.toLowerCase().replace(/\s+/g, '-') : '');

        if (moduleOwner && moduleOwner.dataset.id) {
            return cleanStateKey('module:' + moduleOwner.dataset.id + ':' + localKey, 'popup');
        }

        if (windowEl.id) return cleanStateKey(windowEl.id, 'popup');

        const owner = windowEl.closest && windowEl.closest('[id]');
        if (owner && owner.id) return cleanStateKey(owner.id + ':' + localKey, 'popup');
        return cleanStateKey(localKey, 'popup');
    }

    function popupHandle(windowEl, options) {
        const opts = options || {};
        if (opts.handle && typeof opts.handle === 'string') {
            const explicit = windowEl.querySelector(opts.handle);
            if (explicit) return explicit;
        }
        return windowEl.querySelector(
            '[data-dmd-window-handle], .dmd-document-head, ' +
            '.dmd-window-head, .modal-header, .popupHeader, .popup-header, .dialog-header, ' +
            '.window-header, .panel-header, .titlebar, [data-drag-handle], ' +
            '[class*="modal-head"], [class*="popup-head"], [class*="window-head"], [class*="dialog-head"]'
        );
    }

    function requestWorkspaceExpansion() {
        if (typeof window.DMDExpandDashboardCanvas === 'function') {
            window.requestAnimationFrame(() => window.DMDExpandDashboardCanvas());
        }
    }

    function portalPopupToWorkspace(windowEl) {
        const ws = workspaceElement();
        if (!ws || !windowEl || !windowEl.isConnected) return null;

        const overlay = popupOverlay(windowEl);
        const host = overlay || windowEl;

        if (host !== ws && host.parentElement !== ws) {
            ws.appendChild(host);
        }

        if (overlay) {
            if (overlay.dataset.dmdWorkspaceOverlay !== '1') {
                overlay.dataset.dmdWorkspaceOverlay = '1';
            }
            if (!overlay.classList.contains('dmd-workspace-overlay')) {
                overlay.classList.add('dmd-workspace-overlay');
            }
        }

        if (windowEl.dataset.dmdWorkspaceWindow !== '1') {
            windowEl.dataset.dmdWorkspaceWindow = '1';
        }
        if (!windowEl.classList.contains('dmd-workspace-window')) {
            windowEl.classList.add('dmd-workspace-window');
        }
        requestWorkspaceExpansion();
        return ws;
    }

    function applyPopupGeometry(windowEl, geometry) {
        if (!windowEl) return null;
        portalPopupToWorkspace(windowEl);
        const next = normalizePopupGeometry(geometry);
        windowEl.classList.add('dmd-workspace-positioned');
        Object.assign(windowEl.style, {
            position: 'absolute',
            left: next.x + 'px',
            top: next.y + 'px',
            right: 'auto',
            bottom: 'auto',
            width: next.width + 'px',
            height: next.height + 'px',
            maxWidth: 'none',
            maxHeight: 'none',
            transform: 'none'
        });
        requestWorkspaceExpansion();
        return next;
    }

    function seedPopupGeometry(windowEl) {
        if (!windowEl || windowEl.classList.contains('dmd-workspace-positioned')) return null;
        const rect = windowEl.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;
        const point = workspacePointFromViewport(rect.left, rect.top);
        return applyPopupGeometry(windowEl, {
            x: point.x,
            y: point.y,
            width: rect.width,
            height: rect.height
        });
    }

    function rememberPopupGeometry(windowEl) {
        if (!windowEl || isMobileView()) return;
        const key = popupWindowKey(windowEl);
        const geometry = popupGeometryFromElement(windowEl);
        if (!geometry) return;
        windowStateCache.popups[key] = Object.assign({}, geometry);
        postWindowGeometry({ type: 'popup', popup: key, geometry });
    }

    async function restorePopupGeometry(windowEl) {
        if (!windowEl || isMobileView()) return null;
        await loadWindowState();
        const key = popupWindowKey(windowEl);
        const saved = windowStateCache.popups[key];
        if (!saved || typeof saved !== 'object') return null;

        const geometry = normalizePopupGeometry(saved);
        return applyPopupGeometry(windowEl, geometry);
    }

    function bringWindowToFront(windowEl) {
        if (!windowEl) return;
        highestWindowZIndex++;
        windowEl.style.zIndex = highestWindowZIndex;

        const overlay = popupOverlay(windowEl);
        if (overlay && overlay !== windowEl) overlay.style.zIndex = highestWindowZIndex - 1;
    }

    function registerPopup(windowEl, options) {
        if (!windowEl || windowEl.nodeType !== 1 || isMobileView()) return windowEl;
        if (windowEl.dataset && windowEl.dataset.dmdWindowIgnore === '1') return windowEl;
        if (windowEl.classList.contains('dmd-view-chooser')) return windowEl;

        const handle = popupHandle(windowEl, options);
        if (!handle) return windowEl;

        if (windowEl.dataset.dmdWindowManaged === '1') {
            return windowEl;
        }

        windowEl.dataset.dmdWindowManaged = '1';
        windowEl.dataset.dmdWindowKey = popupWindowKey(windowEl, options);
        windowEl.classList.add('dmd-managed-window');
        handle.setAttribute('data-dmd-window-handle', '1');
        portalPopupToWorkspace(windowEl);

        windowEl.addEventListener('pointerdown', function () {
            bringWindowToFront(windowEl);
        }, true);

        restorePopupGeometry(windowEl);

        if (typeof interact === 'function') {
            interact(windowEl)
                .draggable({
                    allowFrom: '[data-dmd-window-handle]',
                    ignoreFrom: 'button, select, input, textarea, a, iframe',
                    listeners: {
                        start(e) {
                            const t = e.target;
                            t.classList.add('dmd-window-dragging');
                            seedPopupGeometry(t);
                            bringWindowToFront(t);
                        },
                        move(e) {
                            const t = e.target;
                            const rect = t.getBoundingClientRect();
                            const next = normalizePopupGeometry({
                                x: finiteNumber(parseFloat(t.style.left), 0) + e.dx,
                                y: finiteNumber(parseFloat(t.style.top), 0) + e.dy,
                                width: finiteNumber(parseFloat(t.style.width), rect.width),
                                height: finiteNumber(parseFloat(t.style.height), rect.height)
                            });
                            t.style.left = next.x + 'px';
                            t.style.top = next.y + 'px';
                            requestWorkspaceExpansion();
                        },
                        end(e) {
                            e.target.classList.remove('dmd-window-dragging');
                            rememberPopupGeometry(e.target);
                        }
                    }
                })
                .resizable({
                    edges: { left: true, top: true, right: true, bottom: true },
                    listeners: {
                        start(e) {
                            const t = e.target;
                            t.classList.add('dmd-window-resizing');
                            seedPopupGeometry(t);
                            bringWindowToFront(t);
                        },
                        move(e) {
                            const t = e.target;
                            const currentX = finiteNumber(parseFloat(t.style.left), 0);
                            const currentY = finiteNumber(parseFloat(t.style.top), 0);
                            const next = normalizePopupGeometry({
                                x: currentX + e.deltaRect.left,
                                y: currentY + e.deltaRect.top,
                                width: e.rect.width,
                                height: e.rect.height
                            });
                            t.style.left = next.x + 'px';
                            t.style.top = next.y + 'px';
                            t.style.width = next.width + 'px';
                            t.style.height = next.height + 'px';
                            requestWorkspaceExpansion();
                        },
                        end(e) {
                            e.target.classList.remove('dmd-window-resizing');
                            rememberPopupGeometry(e.target);
                        }
                    }
                });
        }

        return windowEl;
    }

    function automaticPopupVisibilityShell(el) {
        if (!el || !el.closest) return null;
        const shell = el.closest('[aria-hidden], [hidden]');
        if (!shell) return null;

        const cls = String(shell.className || '');
        const role = String(shell.getAttribute('role') || '').toLowerCase();
        if (/modal|popup|dialog|overlay|backdrop|layer/i.test(cls) || role === 'dialog') {
            return shell;
        }
        return null;
    }

    function decorateWindows(root) {
        if (!root || isMobileView()) return;
        const candidates = [];
        if (root.matches && root.matches('[data-dmd-window], [role="dialog"], .modal, .popup, .dialog, [class*="-modal"], [class*="-popup"], [class*="-window"], [class*="-dialog"]')) {
            candidates.push(root);
        }
        if (root.querySelectorAll) {
            root.querySelectorAll('[data-dmd-window], [role="dialog"], .modal, .popup, .dialog, [class*="-modal"], [class*="-popup"], [class*="-window"], [class*="-dialog"]').forEach(el => candidates.push(el));
        }

        candidates.forEach(el => {
            const cls = String(el.className || '');
            if (/overlay|backdrop/i.test(cls)) return;

            /*
             * Ne jamais arracher automatiquement une fenêtre de son conteneur
             * de visibilité (hidden / aria-hidden). Plusieurs modules gèrent
             * eux-mêmes ces modales : les sortir de leur parent les rend visibles
             * en permanence et superpose leurs contenus dans le dashboard.
             * Les services qui veulent la gestion Workspace peuvent toujours
             * appeler explicitement DMDWorkspace.registerPopup().
             */
            if (automaticPopupVisibilityShell(el)) return;

            registerPopup(el);
        });
    }

    function q(sel, root) {
        return (root || document).querySelector(sel);
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function safeText(value, fallback) {
        const s = String(value == null ? '' : value).trim();
        return s || (fallback || '');
    }

    function getViewMode() {
        return document.documentElement.classList.contains('dmd-view-mobile') ? 'mobile' : 'desktop';
    }

    function isMobileView() {
        return getViewMode() === 'mobile';
    }

    function setViewMode(mode, reload) {
        const clean = mode === 'mobile' ? 'mobile' : 'desktop';
        try {
            localStorage.setItem(VIEW_KEY, clean);
            localStorage.setItem(FIRST_CHOICE_KEY, '1');
        } catch (e) {}

        document.documentElement.classList.toggle('dmd-view-mobile', clean === 'mobile');
        document.documentElement.classList.toggle('dmd-view-desktop', clean !== 'mobile');
        document.documentElement.dataset.dmdViewMode = clean;
        syncViewButton();
        closeViewChooser();

        document.dispatchEvent(new CustomEvent('dmd:view-mode-changed', { detail: { mode: clean } }));

        if (reload !== false) {
            if (typeof workspaceConfig.onModeChanged === 'function') {
                workspaceConfig.onModeChanged(clean);
            } else {
                location.reload();
            }
        }
    }

    function syncViewButton() {
        const btn = document.getElementById('dmdViewModeBtn');
        if (!btn) return;
        const mobile = isMobileView();
        btn.textContent = mobile ? '📱' : '🖥️';
        btn.title = mobile ? 'Vue mobile active — changer l’affichage' : 'Vue bureau active — changer l’affichage';
        btn.setAttribute('aria-label', btn.title);
    }

    function ensureViewChooser() {
        if (viewChooser) return viewChooser;

        const overlay = document.createElement('div');
        overlay.className = 'dmd-view-chooser-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.innerHTML = `
            <div class="dmd-view-chooser">
                <div class="dmd-view-chooser-head">
                    <strong>Affichage DoMyDesk</strong>
                    <button class="dmd-view-chooser-close" type="button" aria-label="Fermer">×</button>
                </div>
                <div class="dmd-view-chooser-body">
                    <p class="dmd-view-chooser-help">Ce choix est mémorisé uniquement sur cet appareil / navigateur. Votre PC peut rester en Bureau pendant que votre téléphone reste en Mobile.</p>
                    <div class="dmd-view-chooser-grid">
                        <button class="dmd-view-choice" type="button" data-view="mobile">
                            <span class="dmd-view-choice-icon">📱</span>
                            <strong>Mobile</strong>
                            <small>Modules empilés, utilisation au doigt, plein écran facile.</small>
                        </button>
                        <button class="dmd-view-choice" type="button" data-view="desktop">
                            <span class="dmd-view-choice-icon">🖥️</span>
                            <strong>Bureau</strong>
                            <small>Positions, tailles, déplacement et redimensionnement libres.</small>
                        </button>
                    </div>
                </div>
            </div>`;

        document.body.appendChild(overlay);
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay || e.target.closest('.dmd-view-chooser-close')) {
                closeViewChooser();
                return;
            }
            const choice = e.target.closest('.dmd-view-choice');
            if (choice) {
                setViewMode(choice.dataset.view || 'desktop', true);
            }
        });
        viewChooser = overlay;
        return overlay;
    }

    function openViewChooser() {
        const overlay = ensureViewChooser();
        overlay.querySelectorAll('.dmd-view-choice').forEach(btn => {
            btn.classList.toggle('is-current', btn.dataset.view === getViewMode());
        });
        overlay.classList.add('is-open');
    }

    function closeViewChooser() {
        if (viewChooser) viewChooser.classList.remove('is-open');
    }

    function maybePromptViewChoice() {
        let chosen = false;
        try {
            chosen = localStorage.getItem(FIRST_CHOICE_KEY) === '1' || localStorage.getItem(VIEW_KEY) !== null;
        } catch (e) {}
        if (chosen) return;

        const coarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
        const compact = window.innerWidth <= 1100;
        if (coarse || compact) {
            window.setTimeout(openViewChooser, 250);
        }
    }

    function toast(message) {
        const old = q('.dmd-toast');
        if (old) old.remove();
        const el = document.createElement('div');
        el.className = 'dmd-toast';
        el.textContent = message;
        document.body.appendChild(el);
        window.setTimeout(() => el.remove(), 2200);
    }

    function ensureModuleMenu() {
        if (moduleMenu) return moduleMenu;

        const menu = document.createElement('div');
        menu.className = 'dmd-module-menu';
        menu.setAttribute('role', 'menu');
        menu.innerHTML = `
            <div class="dmd-module-menu-title">Module</div>
            <button type="button" data-action="fullscreen"><span>⛶</span><span>Ouvrir en grand</span></button>
            <button type="button" data-action="refresh"><span>🔄</span><span>Actualiser</span></button>
            <button type="button" data-action="move" class="dmd-desktop-only"><span>↔️</span><span>Déplacer</span></button>
            <button type="button" data-action="up" class="dmd-mobile-only"><span>⬆️</span><span>Monter</span></button>
            <button type="button" data-action="down" class="dmd-mobile-only"><span>⬇️</span><span>Descendre</span></button>
            <button type="button" data-action="close" class="dmd-danger"><span>✖</span><span>Fermer</span></button>`;
        document.body.appendChild(menu);
        menu.addEventListener('click', function (e) {
            const btn = e.target.closest('button[data-action]');
            if (!btn || !currentModule) return;
            const action = btn.dataset.action;
            if (action === 'fullscreen') toggleFullscreen(currentModule);
            if (action === 'refresh') currentModule.dispatchEvent(new CustomEvent('dmd:module-refresh', { bubbles: true }));
            if (action === 'move') {
                currentModule.dispatchEvent(new CustomEvent('dmd:module-move-request', { bubbles: true }));
                toast('Faites glisser l’en-tête du module pour le déplacer.');
            }
            if (action === 'up') moveMobile(currentModule, -1);
            if (action === 'down') moveMobile(currentModule, 1);
            if (action === 'close') currentModule.dispatchEvent(new CustomEvent('dmd:module-close', { bubbles: true }));
            closeModuleMenu();
        });
        moduleMenu = menu;
        return menu;
    }

    function openModuleMenu(moduleEl, anchor) {
        currentModule = moduleEl;
        const menu = ensureModuleMenu();
        const title = safeText(q('.module-title', moduleEl)?.textContent, moduleEl.dataset.id || 'Module');
        q('.dmd-module-menu-title', menu).textContent = title;
        menu.classList.add('is-open');

        if (isMobileView()) {
            menu.style.left = '8px';
            menu.style.right = '8px';
            menu.style.top = 'auto';
            menu.style.bottom = '8px';
            return;
        }

        const r = anchor.getBoundingClientRect();
        const width = 220;
        const left = Math.max(8, Math.min(window.innerWidth - width - 8, r.right - width));
        const top = Math.max(8, Math.min(window.innerHeight - 240, r.bottom + 5));
        menu.style.left = left + 'px';
        menu.style.right = 'auto';
        menu.style.top = top + 'px';
        menu.style.bottom = 'auto';
    }

    function closeModuleMenu() {
        if (moduleMenu) moduleMenu.classList.remove('is-open');
        currentModule = null;
    }

    function toggleFullscreen(moduleEl) {
        const opening = !moduleEl.classList.contains('dmd-module-fullscreen');
        document.querySelectorAll('.module.dmd-module-fullscreen').forEach(el => {
            if (el !== moduleEl) el.classList.remove('dmd-module-fullscreen');
        });
        moduleEl.classList.toggle('dmd-module-fullscreen', opening);
        document.body.classList.toggle('dmd-module-fullscreen-open', opening);
        if (opening) {
            moduleEl.dataset.dmdFullscreen = '1';
        } else {
            delete moduleEl.dataset.dmdFullscreen;
        }
    }

    function mobileOrderKey() {
        const scope = workspaceConfig.quickSessionView ? 'quick-session' : ('dashboard:' + (workspaceConfig.dashboardName || 'dashboard'));
        return 'dmd:mobile-order:' + scope;
    }

    function saveMobileOrder(container) {
        if (!container) return;
        const ids = Array.from(container.children)
            .filter(el => el.classList && el.classList.contains('module') && el.dataset.id)
            .map(el => el.dataset.id);
        try {
            localStorage.setItem(mobileOrderKey(), JSON.stringify(ids));
        } catch (e) {}
    }

    function applyMobileOrder(container) {
        if (!isMobileView() || !container) return;
        let ids = [];
        try {
            const raw = localStorage.getItem(mobileOrderKey());
            ids = raw ? JSON.parse(raw) : [];
        } catch (e) {
            ids = [];
        }
        if (!Array.isArray(ids) || !ids.length) return;
        const modules = Array.from(container.children).filter(el => el.classList && el.classList.contains('module'));
        const byId = new Map(modules.map(el => [el.dataset.id, el]));
        ids.forEach(id => {
            const el = byId.get(id);
            if (el) container.appendChild(el);
        });
    }

    function moveMobile(moduleEl, direction) {
        if (!isMobileView()) return;
        const sibling = direction < 0 ? moduleEl.previousElementSibling : moduleEl.nextElementSibling;
        if (!sibling || !sibling.classList.contains('module')) return;
        const parent = moduleEl.parentNode;
        if (direction < 0) {
            parent.insertBefore(moduleEl, sibling);
        } else {
            parent.insertBefore(sibling, moduleEl);
        }
        saveMobileOrder(parent);
        if (typeof workspaceConfig.onMobileOrderChanged === 'function') {
            workspaceConfig.onMobileOrderChanged();
        }
    }

    function ensureDocumentViewer() {
        if (documentViewer) return documentViewer;
        const overlay = document.createElement('div');
        overlay.className = 'dmd-document-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.innerHTML = `
            <div class="dmd-document-window">
                <div class="dmd-document-head">
                    <strong>Document</strong>
                    <button class="dmd-document-close" type="button" aria-label="Fermer">×</button>
                </div>
                <div class="dmd-document-body"><iframe title="Document DoMyDesk"></iframe></div>
            </div>`;
        document.body.appendChild(overlay);
        registerPopup(q('.dmd-document-window', overlay), { key: 'core:document-viewer', handle: '.dmd-document-head' });
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay || e.target.closest('.dmd-document-close')) closeDocument();
        });
        documentViewer = overlay;
        return overlay;
    }

    function openDocument(url, title) {
        const overlay = ensureDocumentViewer();
        q('.dmd-document-head strong', overlay).textContent = safeText(title, 'Document');
        q('iframe', overlay).src = url;
        overlay.classList.add('is-open');
    }

    function closeDocument() {
        if (!documentViewer) return;
        documentViewer.classList.remove('is-open');
        q('iframe', documentViewer).src = 'about:blank';
    }

    document.addEventListener('click', function (e) {
        const moduleTrigger = e.target.closest('.dmd-module-menu-trigger');
        if (moduleTrigger) {
            e.preventDefault();
            e.stopPropagation();
            const moduleEl = moduleTrigger.closest('.module');
            if (moduleEl) openModuleMenu(moduleEl, moduleTrigger);
            return;
        }

        if (moduleMenu && moduleMenu.classList.contains('is-open') && !e.target.closest('.dmd-module-menu')) {
            closeModuleMenu();
        }

        const docLink = e.target.closest('.dmd-document-link, [data-dmd-document-url]');
        if (docLink) {
            const url = docLink.dataset.dmdDocumentUrl || docLink.getAttribute('href');
            if (url) {
                e.preventDefault();
                openDocument(url, docLink.dataset.dmdDocumentTitle || docLink.textContent.trim());
            }
        }
    }, true);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeModuleMenu();
            closeViewChooser();
            closeDocument();
            const fs = q('.module.dmd-module-fullscreen');
            if (fs) toggleFullscreen(fs);
        }
    });

    let viewportRefreshFrame = null;
    window.addEventListener('resize', function () {
        if (isMobileView()) return;
        if (viewportRefreshFrame) cancelAnimationFrame(viewportRefreshFrame);
        viewportRefreshFrame = requestAnimationFrame(function () {
            viewportRefreshFrame = null;
            document.querySelectorAll('.dmd-managed-window').forEach(function (windowEl) {
                if (!windowEl.isConnected) return;
                portalPopupToWorkspace(windowEl);
                if (!windowEl.classList.contains('dmd-workspace-positioned')) {
                    seedPopupGeometry(windowEl);
                }
            });
            requestWorkspaceExpansion();
        });
    });

    const Workspace = {
        configure: function (config) {
            workspaceConfig = Object.assign({}, workspaceConfig, config || {});
            loadWindowState();
            syncViewButton();
            const btn = document.getElementById('dmdViewModeBtn');
            if (btn && !btn.dataset.dmdBound) {
                btn.dataset.dmdBound = '1';
                btn.addEventListener('click', openViewChooser);
            }
            maybePromptViewChoice();
        },
        getViewMode,
        isMobileView,
        setViewMode,
        openViewChooser,
        openDocument,
        applyMobileOrder,
        toast,
        loadWindowState,
        rememberModuleGeometry,
        getRememberedModuleGeometry,
        restoreModuleGeometry,
        registerPopup,
        rememberPopupGeometry,
        restorePopupGeometry,
        decorateWindows
    };

    window.DMDWorkspace = Workspace;

    /* ========================================================
       Décoration générique des fenêtres ajoutées dynamiquement.
       Les services spécialisés possèdent leurs propres observers dans leurs dossiers.
       ======================================================== */
    const workspaceObserver = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            mutation.addedNodes.forEach(function (node) {
                if (node.nodeType === 1) {
                    decorateWindows(node);
                }
            });

            if (mutation.type === 'attributes' && mutation.target && mutation.target.nodeType === 1) {
                const target = mutation.target;
                if (target.classList && target.classList.contains('dmd-managed-window')) {
                    portalPopupToWorkspace(target);
                    seedPopupGeometry(target);
                } else if (target.querySelectorAll) {
                    target.querySelectorAll('.dmd-managed-window').forEach(function (windowEl) {
                        portalPopupToWorkspace(windowEl);
                        seedPopupGeometry(windowEl);
                    });
                }
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        if (document.body) {
            workspaceObserver.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class', 'style', 'hidden', 'open']
            });
        }
        decorateWindows(document);
    });
})();
