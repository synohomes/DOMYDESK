<?php
/*
 * DoMyDesk 1.2.0 - Contrat d'installation des modules
 *
 * Ce fichier centralise les règles communes du Market :
 * - manifeste obligatoire pour toute nouvelle installation 1.2.0 ;
 * - compatibilité de version ;
 * - structure exacte du paquet lorsque package.strict=true ;
 * - points d'entrée déclarés ;
 * - préparation du stockage runtime ;
 * - migration sûre d'anciens chemins runtime contenus dans /modules/<id>/.
 *
 * Il ne charge aucun module et ne dépend d'aucune base de données.
 */

if (!function_exists('dmd_module_contract_slug')) {
    function dmd_module_contract_slug($value) {
        $value = preg_replace('~[^a-zA-Z0-9._-]+~', '-', (string)$value);
        return trim((string)$value, '-');
    }
}

if (!function_exists('dmd_module_contract_safe_relative_path')) {
    function dmd_module_contract_safe_relative_path($path) {
        $path = str_replace('\\', '/', trim((string)$path));
        if ($path === '' || substr($path, 0, 1) === '/' || preg_match('~^[a-zA-Z]:/~', $path)) {
            return false;
        }
        if (preg_match('~(^|/)\.\.(/|$)~', $path) || strpos($path, "\0") !== false) {
            return false;
        }
        $parts = explode('/', $path);
        foreach ($parts as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                return false;
            }
        }
        return true;
    }
}

if (!function_exists('dmd_module_contract_read_json')) {
    function dmd_module_contract_read_json($file) {
        if (!is_file($file)) {
            return null;
        }
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') {
            return null;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }
}

if (!function_exists('dmd_module_contract_current_version')) {
    function dmd_module_contract_current_version($baseDir) {
        if (function_exists('dmd_version_read')) {
            $value = dmd_version_read($baseDir);
            if (is_string($value) && preg_match('~^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', trim($value))) {
                return trim($value);
            }
        }
        $file = rtrim((string)$baseDir, '/\\') . '/data/version.txt';
        if (is_file($file)) {
            $value = trim((string)@file_get_contents($file));
            if (preg_match('~^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', $value)) {
                return $value;
            }
        }
        return '';
    }
}

if (!function_exists('dmd_module_contract_package_root')) {
    function dmd_module_contract_package_root($extractDir, &$errors) {
        $extractDir = rtrim((string)$extractDir, '/\\');
        if (is_file($extractDir . '/dmd_module.json')) {
            return $extractDir;
        }

        $children = @scandir($extractDir);
        if (!is_array($children)) {
            $errors[] = 'Dossier temporaire du module illisible.';
            return false;
        }

        $realChildren = [];
        foreach ($children as $child) {
            if ($child === '.' || $child === '..' || $child === '__MACOSX' || $child === '.DS_Store') {
                continue;
            }
            $realChildren[] = $child;
        }

        if (count($realChildren) === 1) {
            $candidate = $extractDir . '/' . $realChildren[0];
            if (is_dir($candidate) && is_file($candidate . '/dmd_module.json')) {
                return $candidate;
            }
        }

        $errors[] = 'Le ZIP doit contenir dmd_module.json à sa racine (ou dans un unique dossier racine).';
        return false;
    }
}

if (!function_exists('dmd_module_contract_collect_files')) {
    function dmd_module_contract_collect_files($root) {
        $root = rtrim((string)$root, '/\\');
        $files = [];
        if (!is_dir($root)) {
            return $files;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($iterator as $item) {
            $full = $item->getPathname();
            if ($item->isLink() || is_link($full)) {
                $rel = ltrim(str_replace('\\', '/', substr($full, strlen($root))), '/');
                $files[] = '__SYMLINK__:' . $rel;
                continue;
            }
            if (!$item->isFile()) {
                continue;
            }
            $rel = ltrim(str_replace('\\', '/', substr($full, strlen($root))), '/');
            $files[] = $rel;
        }

        sort($files, SORT_STRING);
        return $files;
    }
}

if (!function_exists('dmd_module_contract_validate_manifest')) {
    function dmd_module_contract_validate_manifest($moduleDir, $expectedId, $baseDir, &$errors) {
        $moduleDir = rtrim((string)$moduleDir, '/\\');
        $manifestFile = $moduleDir . '/dmd_module.json';

        if (!is_file($manifestFile)) {
            $errors[] = 'dmd_module.json est obligatoire pour un module DoMyDesk 1.2.0.';
            return false;
        }

        $manifest = dmd_module_contract_read_json($manifestFile);
        if (!is_array($manifest)) {
            $errors[] = 'dmd_module.json est invalide ou n’est pas un JSON exploitable.';
            return false;
        }

        $schema = isset($manifest['schema']) ? (int)$manifest['schema'] : 0;
        if ($schema !== 1) {
            $errors[] = 'Version de contrat inconnue : schema doit être égal à 1.';
            return false;
        }

        $requiredStringFields = ['id', 'name', 'version', 'min_domydesk', 'storage_scope', 'default_access', 'entrypoint'];
        foreach ($requiredStringFields as $field) {
            if (!isset($manifest[$field]) || !is_string($manifest[$field]) || trim($manifest[$field]) === '') {
                $errors[] = 'Champ obligatoire manquant dans dmd_module.json : ' . $field . '.';
            }
        }
        if (!empty($errors)) {
            return false;
        }

        $id = dmd_module_contract_slug($manifest['id']);
        if ($id === '') {
            $errors[] = 'Le champ id du manifeste est invalide.';
            return false;
        }

        $expectedId = dmd_module_contract_slug($expectedId);
        if ($expectedId !== '' && strcasecmp($id, $expectedId) !== 0) {
            $errors[] = 'Le module reçu déclare l’ID « ' . $id . ' » alors que le Market attend « ' . $expectedId . ' ».';
            return false;
        }

        if (!preg_match('~^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', trim($manifest['version']))) {
            $errors[] = 'Le champ version doit être une version exploitable (ex. 2.2.0).';
            return false;
        }
        if (!preg_match('~^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', trim($manifest['min_domydesk']))) {
            $errors[] = 'Le champ min_domydesk doit être une version exploitable (ex. 1.2.0).';
            return false;
        }

        $scope = strtolower(trim($manifest['storage_scope']));
        if (!in_array($scope, ['system', 'user', 'hybrid'], true)) {
            $errors[] = 'storage_scope doit être system, user ou hybrid pour un module 1.2.0.';
            return false;
        }

        $defaultAccess = strtolower(trim($manifest['default_access']));
        if (!in_array($defaultAccess, ['controlled', 'everyone'], true)) {
            $errors[] = 'default_access doit être controlled ou everyone.';
            return false;
        }

        $entrypoint = str_replace('\\', '/', trim($manifest['entrypoint']));
        if (!dmd_module_contract_safe_relative_path($entrypoint) || strtolower(pathinfo($entrypoint, PATHINFO_EXTENSION)) !== 'php') {
            $errors[] = 'entrypoint est invalide.';
            return false;
        }
        if (!is_file($moduleDir . '/' . $entrypoint)) {
            $errors[] = 'Le point d’entrée déclaré est absent du ZIP : ' . $entrypoint . '.';
            return false;
        }

        $configEntrypoint = '';
        if (isset($manifest['config_entrypoint']) && $manifest['config_entrypoint'] !== null && $manifest['config_entrypoint'] !== '') {
            if (!is_string($manifest['config_entrypoint'])) {
                $errors[] = 'config_entrypoint doit être une chaîne ou null.';
                return false;
            }
            $configEntrypoint = str_replace('\\', '/', trim($manifest['config_entrypoint']));
            if (!dmd_module_contract_safe_relative_path($configEntrypoint) || strtolower(pathinfo($configEntrypoint, PATHINFO_EXTENSION)) !== 'php') {
                $errors[] = 'config_entrypoint est invalide.';
                return false;
            }
            if (!is_file($moduleDir . '/' . $configEntrypoint)) {
                $errors[] = 'Le point de configuration déclaré est absent du ZIP : ' . $configEntrypoint . '.';
                return false;
            }
        }

        $capabilities = [];
        if (isset($manifest['capabilities'])) {
            if (!is_array($manifest['capabilities'])) {
                $errors[] = 'capabilities doit être un tableau.';
                return false;
            }
            foreach ($manifest['capabilities'] as $capability) {
                if (!is_string($capability) || trim($capability) === '' || !preg_match('~^[a-zA-Z0-9._:-]+$~', trim($capability))) {
                    $errors[] = 'Une capacité déclarée dans dmd_module.json est invalide.';
                    return false;
                }
                $capabilities[] = trim($capability);
            }
            $capabilities = array_values(array_unique($capabilities));
        }

        if (!isset($manifest['package']) || !is_array($manifest['package'])) {
            $errors[] = 'Le bloc package est obligatoire dans le contrat module 1.2.0.';
            return false;
        }
        $package = $manifest['package'];
        $strict = !empty($package['strict']);
        $declaredFiles = [];

        if (!$strict) {
            $errors[] = 'package.strict doit être true : le Market 1.2.0 n’installe pas de paquet non strict.';
            return false;
        }

        if ($strict) {
            if (empty($package['files']) || !is_array($package['files'])) {
                $errors[] = 'package.strict=true exige package.files.';
                return false;
            }

            foreach ($package['files'] as $file) {
                if (!is_string($file)) {
                    $errors[] = 'package.files contient une entrée invalide.';
                    return false;
                }
                $file = str_replace('\\', '/', trim($file));
                if (!dmd_module_contract_safe_relative_path($file) || $file === 'dmd_module.json') {
                    $errors[] = 'Chemin invalide dans package.files : ' . $file . '.';
                    return false;
                }
                if (!is_file($moduleDir . '/' . $file)) {
                    $errors[] = 'Fichier obligatoire absent du ZIP : ' . $file . '.';
                    return false;
                }
                $declaredFiles[] = $file;
            }
            $declaredFiles = array_values(array_unique($declaredFiles));
            sort($declaredFiles, SORT_STRING);

            if (!in_array($entrypoint, $declaredFiles, true)) {
                $errors[] = 'entrypoint doit aussi être déclaré dans package.files.';
                return false;
            }
            if ($configEntrypoint !== '' && !in_array($configEntrypoint, $declaredFiles, true)) {
                $errors[] = 'config_entrypoint doit aussi être déclaré dans package.files.';
                return false;
            }

            $actualFiles = dmd_module_contract_collect_files($moduleDir);
            foreach ($actualFiles as $actual) {
                if (strpos($actual, '__SYMLINK__:') === 0) {
                    $errors[] = 'Les liens symboliques sont interdits dans les modules : ' . substr($actual, 12) . '.';
                    return false;
                }
            }
            $expectedFiles = $declaredFiles;
            $expectedFiles[] = 'dmd_module.json';
            sort($expectedFiles, SORT_STRING);

            if ($actualFiles !== $expectedFiles) {
                $missing = array_values(array_diff($expectedFiles, $actualFiles));
                $extra = array_values(array_diff($actualFiles, $expectedFiles));
                if ($missing) {
                    $errors[] = 'Fichier(s) manquant(s) dans le paquet : ' . implode(', ', $missing) . '.';
                }
                if ($extra) {
                    $errors[] = 'Fichier(s) non déclaré(s) dans le paquet : ' . implode(', ', $extra) . '.';
                }
                return false;
            }
        }

        if (!isset($manifest['data_policy']) || !is_array($manifest['data_policy'])) {
            $errors[] = 'Le bloc data_policy est obligatoire : le module doit déclarer comment ses données runtime sont créées et préservées.';
            return false;
        }
        $dataPolicy = $manifest['data_policy'];
        if (!array_key_exists('create', $dataPolicy) || !array_key_exists('preserve_on_update', $dataPolicy)) {
            $errors[] = 'data_policy doit contenir create et preserve_on_update.';
            return false;
        }
        if (!is_bool($dataPolicy['preserve_on_update'])) {
            $errors[] = 'data_policy.preserve_on_update doit être un booléen.';
            return false;
        }
        $createMode = strtolower(trim((string)$dataPolicy['create']));
        if (!in_array($createMode, ['install', 'lazy'], true)) {
            $errors[] = 'data_policy.create doit être install ou lazy.';
            return false;
        }
        $preserveOnUpdate = !array_key_exists('preserve_on_update', $dataPolicy) || !empty($dataPolicy['preserve_on_update']);
        $protectHttp = !array_key_exists('protect_http', $dataPolicy) || !empty($dataPolicy['protect_http']);
        if (array_key_exists('protect_http', $dataPolicy) && !is_bool($dataPolicy['protect_http'])) {
            $errors[] = 'data_policy.protect_http doit être un booléen.';
            return false;
        }
        $runtimeDirectories = [];
        if (isset($dataPolicy['directories'])) {
            if (!is_array($dataPolicy['directories'])) {
                $errors[] = 'data_policy.directories doit être un tableau.';
                return false;
            }
            foreach ($dataPolicy['directories'] as $dir) {
                $dir = str_replace('\\', '/', trim((string)$dir));
                if (!dmd_module_contract_safe_relative_path($dir)) {
                    $errors[] = 'Dossier runtime invalide : ' . $dir . '.';
                    return false;
                }
                $runtimeDirectories[] = $dir;
            }
            $runtimeDirectories = array_values(array_unique($runtimeDirectories));
        }

        $generatedFiles = [];
        if (isset($dataPolicy['generated_files'])) {
            if (!is_array($dataPolicy['generated_files'])) {
                $errors[] = 'data_policy.generated_files doit être un tableau.';
                return false;
            }

            foreach ($dataPolicy['generated_files'] as $generated) {
                if (!is_array($generated)) {
                    $errors[] = 'Entrée data_policy.generated_files invalide.';
                    return false;
                }

                $path = str_replace('\\', '/', trim((string)($generated['path'] ?? '')));
                $generator = strtolower(trim((string)($generated['generator'] ?? 'random_bytes')));
                $bytes = isset($generated['bytes']) ? (int)$generated['bytes'] : 32;
                $encoding = strtolower(trim((string)($generated['encoding'] ?? 'raw')));
                $mode = trim((string)($generated['mode'] ?? '0600'));
                $preserve = !array_key_exists('preserve', $generated) || !empty($generated['preserve']);

                if (!dmd_module_contract_safe_relative_path($path)) {
                    $errors[] = 'Chemin de fichier généré invalide : ' . $path . '.';
                    return false;
                }
                if ($generator !== 'random_bytes') {
                    $errors[] = 'Générateur de fichier runtime inconnu : ' . $generator . '.';
                    return false;
                }
                if ($bytes < 16 || $bytes > 4096) {
                    $errors[] = 'Taille de fichier aléatoire invalide pour ' . $path . '.';
                    return false;
                }
                if (!in_array($encoding, ['raw', 'hex', 'base64'], true)) {
                    $errors[] = 'Encodage de fichier généré invalide pour ' . $path . '.';
                    return false;
                }
                if (!preg_match('~^0?[0-7]{3,4}$~', $mode)) {
                    $errors[] = 'Mode Unix invalide pour le fichier généré ' . $path . '.';
                    return false;
                }

                $generatedFiles[] = [
                    'path' => $path,
                    'generator' => $generator,
                    'bytes' => $bytes,
                    'encoding' => $encoding,
                    'mode' => $mode,
                    'preserve' => $preserve,
                ];
            }
        }

        $legacyMappings = [];
        if (isset($manifest['migration']['legacy_data'])) {
            if (!is_array($manifest['migration']['legacy_data'])) {
                $errors[] = 'migration.legacy_data doit être un tableau.';
                return false;
            }
            foreach ($manifest['migration']['legacy_data'] as $mapping) {
                if (!is_array($mapping)) {
                    $errors[] = 'Entrée migration.legacy_data invalide.';
                    return false;
                }
                $from = str_replace('\\', '/', trim((string)($mapping['from'] ?? '')));
                $to = str_replace('\\', '/', trim((string)($mapping['to'] ?? '')));
                if (!dmd_module_contract_safe_relative_path($from) || !dmd_module_contract_safe_relative_path($to)) {
                    $errors[] = 'Chemin de migration legacy invalide.';
                    return false;
                }
                $legacyMappings[] = ['from' => $from, 'to' => $to];
            }
        }

        // DMD-MyDesk 1.4.0 : contrat officiel et volontairement simple.
        // - mydesk_compatible=true signifie uniquement « ce module sait fonctionner dans MyDesk ».
        // - l'activation globale est décidée exclusivement dans /adm/agent/.
        // - les droits utilisateurs restent les droits normaux du module ; aucun droit MyDesk parallèle.
        if (isset($manifest['integrations']) && is_array($manifest['integrations']) && array_key_exists('mydesk', $manifest['integrations'])) {
            $errors[] = 'integrations.mydesk est obsolète en DMD-MyDesk 1.4.0. Utiliser mydesk_compatible et le bloc racine mydesk.';
            return false;
        }
        if (array_key_exists('mydesk_compatible', $manifest) && !is_bool($manifest['mydesk_compatible'])) {
            $errors[] = 'mydesk_compatible doit être un booléen.';
            return false;
        }
        $mydeskCompatible = !empty($manifest['mydesk_compatible']);
        if ($mydeskCompatible) {
            if (!isset($manifest['mydesk']) || !is_array($manifest['mydesk'])) {
                $errors[] = 'Un module avec mydesk_compatible=true doit déclarer un objet racine mydesk.';
                return false;
            }
            $mydesk = $manifest['mydesk'];
            $mydeskEntry = str_replace('\\', '/', trim((string)($mydesk['entrypoint'] ?? '')));
            if (!dmd_module_contract_safe_relative_path($mydeskEntry) || strtolower(pathinfo($mydeskEntry, PATHINFO_EXTENSION)) !== 'php' || !is_file($moduleDir . '/' . $mydeskEntry)) {
                $errors[] = 'mydesk.entrypoint est invalide ou absent.';
                return false;
            }
            if (!in_array($mydeskEntry, $declaredFiles, true)) {
                $errors[] = 'Le point d’entrée mydesk.entrypoint doit être déclaré dans package.files.';
                return false;
            }
            $presentation = strtolower(trim((string)($mydesk['presentation'] ?? 'window')));
            if (!in_array($presentation, ['window','browser'], true)) {
                $errors[] = 'mydesk.presentation est invalide.';
                return false;
            }
            $mydeskIcon = str_replace('\\', '/', trim((string)($mydesk['icon'] ?? '')));
            if ($mydeskIcon !== '' && (!dmd_module_contract_safe_relative_path($mydeskIcon) || !is_file($moduleDir . '/' . $mydeskIcon) || !in_array($mydeskIcon, $declaredFiles, true))) {
                $errors[] = 'mydesk.icon est invalide, absent ou non déclaré dans package.files.';
                return false;
            }
            if (isset($mydesk['min_runtime']) && (!is_string($mydesk['min_runtime']) || !preg_match('~^\\d+(?:\\.\\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', trim($mydesk['min_runtime'])))) {
                $errors[] = 'mydesk.min_runtime doit être une version exploitable (ex. 1.4.0).';
                return false;
            }
            if (isset($mydesk['features'])) {
                if (!is_array($mydesk['features'])) {
                    $errors[] = 'mydesk.features doit être un tableau.';
                    return false;
                }
                foreach ($mydesk['features'] as $feature) {
                    if (!is_string($feature) || !preg_match('~^[a-z0-9._-]{1,64}$~', trim($feature))) {
                        $errors[] = 'Une fonctionnalité mydesk.features est invalide.';
                        return false;
                    }
                }
            }
            if (isset($mydesk['default_view']) && strtolower(trim((string)$mydesk['default_view'])) !== 'compact') {
                $errors[] = 'mydesk.default_view doit être compact.';
                return false;
            }
            if (isset($mydesk['window'])) {
                if (!is_array($mydesk['window'])) {
                    $errors[] = 'mydesk.window doit être un objet.';
                    return false;
                }
                $window = $mydesk['window'];
                foreach (['width','height','min_width','min_height'] as $wf) {
                    if (!array_key_exists($wf, $window)) continue;
                    if (!is_int($window[$wf]) || $window[$wf] < 220 || $window[$wf] > 8192) {
                        $errors[] = 'mydesk.window.' . $wf . ' doit être un entier compris entre 220 et 8192.';
                        return false;
                    }
                }
                foreach (['resizable','single_instance'] as $wf) {
                    if (array_key_exists($wf, $window) && !is_bool($window[$wf])) {
                        $errors[] = 'mydesk.window.' . $wf . ' doit être un booléen.';
                        return false;
                    }
                }
                $width=(int)($window['width']??580); $height=(int)($window['height']??560);
                $minWidth=(int)($window['min_width']??360); $minHeight=(int)($window['min_height']??300);
                if ($minWidth>$width || $minHeight>$height) {
                    $errors[] = 'mydesk.window : les dimensions minimales ne peuvent pas dépasser la taille initiale.';
                    return false;
                }
            }
        }

        $currentVersion = dmd_module_contract_current_version($baseDir);
        if ($currentVersion !== '' && version_compare($currentVersion, trim($manifest['min_domydesk']), '<')) {
            $errors[] = 'Module incompatible : DoMyDesk ' . $manifest['min_domydesk'] . ' minimum requis (instance : ' . $currentVersion . ').';
            return false;
        }

        $manifest['id'] = $id;
        $manifest['name'] = trim($manifest['name']);
        $manifest['description'] = trim((string)($manifest['description'] ?? ''));
        $manifest['version'] = trim($manifest['version']);
        $manifest['min_domydesk'] = trim($manifest['min_domydesk']);
        $manifest['storage_scope'] = $scope;
        $manifest['default_access'] = $defaultAccess;
        $manifest['entrypoint'] = $entrypoint;
        $manifest['config_entrypoint'] = $configEntrypoint;
        $manifest['capabilities'] = $capabilities;
        $manifest['package'] = [
            'strict' => $strict,
            'files' => $declaredFiles,
        ];
        $manifest['data_policy'] = [
            'create' => $createMode,
            'preserve_on_update' => $preserveOnUpdate,
            'directories' => $runtimeDirectories,
            'generated_files' => $generatedFiles,
            'protect_http' => $protectHttp,
        ];
        $manifest['migration'] = ['legacy_data' => $legacyMappings];

        return $manifest;
    }
}

if (!function_exists('dmd_module_contract_copy_tree_without_overwrite')) {
    function dmd_module_contract_copy_tree_without_overwrite($source, $target, &$errors) {
        if (!file_exists($source)) {
            return true;
        }
        if (is_link($source)) {
            $errors[] = 'Migration refusée : lien symbolique détecté dans ' . $source . '.';
            return false;
        }
        if (is_file($source)) {
            @mkdir(dirname($target), 0750, true);
            if (is_file($target)) {
                if (@hash_file('sha256', $source) === @hash_file('sha256', $target)) {
                    return true;
                }
                $errors[] = 'Migration arrêtée : une donnée différente existe déjà dans ' . $target . '.';
                return false;
            }
            if (!@copy($source, $target)) {
                $errors[] = 'Impossible de migrer la donnée ' . $source . '.';
                return false;
            }
            @chmod($target, 0640);
            return true;
        }

        if (!is_dir($source)) {
            return true;
        }
        if (!is_dir($target) && !@mkdir($target, 0750, true) && !is_dir($target)) {
            $errors[] = 'Impossible de créer le dossier runtime ' . $target . '.';
            return false;
        }
        @chmod($target, 0750);
        foreach (array_diff((array)@scandir($source), ['.', '..']) as $item) {
            if (!dmd_module_contract_copy_tree_without_overwrite(
                rtrim($source, '/\\') . DIRECTORY_SEPARATOR . $item,
                rtrim($target, '/\\') . DIRECTORY_SEPARATOR . $item,
                $errors
            )) {
                return false;
            }
        }
        return true;
    }
}

if (!function_exists('dmd_module_contract_protect_runtime_http')) {
    function dmd_module_contract_protect_runtime_http($root, &$errors) {
        $root = rtrim((string)$root, '/\\');
        if ($root === '' || !is_dir($root)) {
            $errors[] = 'Impossible de protéger un stockage runtime inexistant.';
            return false;
        }

        $denyFile = $root . '/.htaccess';
        $content = "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n";

        if (is_file($denyFile)) {
            @chmod($denyFile, 0640);
            return true;
        }

        if (@file_put_contents($denyFile, $content, LOCK_EX) === false) {
            $errors[] = 'Impossible de protéger le stockage runtime contre l’accès HTTP.';
            return false;
        }
        @chmod($denyFile, 0640);
        return true;
    }
}

if (!function_exists('dmd_module_contract_generate_runtime_file')) {
    function dmd_module_contract_generate_runtime_file($root, $definition, &$errors) {
        $relative = str_replace('\\', '/', trim((string)($definition['path'] ?? '')));
        if (!dmd_module_contract_safe_relative_path($relative)) {
            $errors[] = 'Chemin runtime généré invalide : ' . $relative . '.';
            return false;
        }

        $target = rtrim((string)$root, '/\\') . '/' . $relative;
        $modeString = (string)($definition['mode'] ?? '0600');
        $mode = octdec($modeString);

        if (file_exists($target)) {
            if (!is_file($target)) {
                $errors[] = 'Le chemin runtime existe mais n’est pas un fichier : ' . $relative . '.';
                return false;
            }
            @chmod($target, $mode);
            return true;
        }

        $dir = dirname($target);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            $errors[] = 'Impossible de créer le dossier du fichier runtime : ' . $relative . '.';
            return false;
        }
        @chmod($dir, 0750);

        $generator = strtolower((string)($definition['generator'] ?? 'random_bytes'));
        $bytes = (int)($definition['bytes'] ?? 32);
        $encoding = strtolower((string)($definition['encoding'] ?? 'raw'));

        if ($generator !== 'random_bytes') {
            $errors[] = 'Générateur runtime non pris en charge : ' . $generator . '.';
            return false;
        }

        try {
            $content = random_bytes($bytes);
        } catch (Throwable $e) {
            $errors[] = 'Impossible de générer le fichier runtime ' . $relative . '.';
            return false;
        }

        if ($encoding === 'hex') {
            $content = bin2hex($content);
        } elseif ($encoding === 'base64') {
            $content = base64_encode($content);
        }

        $handle = @fopen($target, 'xb');
        if ($handle === false) {
            if (is_file($target)) {
                return true;
            }
            $errors[] = 'Impossible de créer le fichier runtime ' . $relative . '.';
            return false;
        }

        $written = fwrite($handle, $content);
        fclose($handle);

        if ($written !== strlen($content)) {
            @unlink($target);
            $errors[] = 'Écriture incomplète du fichier runtime ' . $relative . '.';
            return false;
        }

        @chmod($target, $mode);

        return true;
    }
}

if (!function_exists('dmd_module_contract_prepare_runtime')) {
    function dmd_module_contract_prepare_runtime($baseDir, $manifest, $oldModuleDir, &$createdRoot, &$errors) {
        $createdRoot = '';
        $scope = $manifest['storage_scope'] ?? 'user';
        $policy = $manifest['data_policy'] ?? [];
        $id = $manifest['id'] ?? '';

        if (!in_array($scope, ['system', 'hybrid'], true)) {
            return true;
        }

        $root = rtrim((string)$baseDir, '/\\') . '/data/modules/' . $id;
        $existed = is_dir($root);

        if (($policy['create'] ?? 'install') === 'install') {
            if (!is_dir($root) && !@mkdir($root, 0750, true) && !is_dir($root)) {
                $errors[] = 'Impossible de créer le stockage système du module.';
                return false;
            }
            @chmod($root, 0750);
            if (!$existed) {
                $createdRoot = $root;
            }

            if (!empty($policy['protect_http']) && !dmd_module_contract_protect_runtime_http($root, $errors)) {
                return false;
            }

            foreach ((array)($policy['directories'] ?? []) as $relative) {
                $dir = $root . '/' . $relative;
                if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
                    $errors[] = 'Impossible de créer le dossier runtime : ' . $relative . '.';
                    return false;
                }
                @chmod($dir, 0750);
            }
        }

        $oldModuleDir = rtrim((string)$oldModuleDir, '/\\');
        if ($oldModuleDir !== '' && is_dir($oldModuleDir)) {
            foreach ((array)($manifest['migration']['legacy_data'] ?? []) as $mapping) {
                $source = $oldModuleDir . '/' . $mapping['from'];
                $target = $root . '/' . $mapping['to'];
                if (!dmd_module_contract_copy_tree_without_overwrite($source, $target, $errors)) {
                    return false;
                }
            }
        }

        /*
         * Les fichiers générés sont créés APRÈS la migration legacy.
         * Ainsi une ancienne clé cryptographique est conservée si elle existe ;
         * une nouvelle clé n'est produite que pour une vraie première installation.
         */
        foreach ((array)($policy['generated_files'] ?? []) as $generated) {
            if (!dmd_module_contract_generate_runtime_file($root, $generated, $errors)) {
                return false;
            }
        }

        return true;
    }
}

if (!function_exists('dmd_module_contract_cleanup_created_runtime')) {
    function dmd_module_contract_cleanup_created_runtime($createdRoot) {
        $createdRoot = rtrim((string)$createdRoot, '/\\');
        if ($createdRoot === '' || !is_dir($createdRoot)) {
            return;
        }

        /*
         * Cette fonction ne reçoit qu'une racine qui n'existait pas avant
         * l'installation. En cas de rollback, on peut donc la retirer entièrement,
         * y compris les clés/fichiers générés pendant la tentative.
         */
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($createdRoot, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $item) {
            if ($item->isDir()) {
                @chmod($item->getPathname(), 0750);
                @rmdir($item->getPathname());
            } else {
                @chmod($item->getPathname(), 0640);
                @unlink($item->getPathname());
            }
        }
        @chmod($createdRoot, 0750);
        @rmdir($createdRoot);
    }
}
