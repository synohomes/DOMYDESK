<?php
/**
 * DoMyDesk - lecteur de licence SynoHomes (DMD-LICENSE-V1)
 *
 * Une licence est un conteneur JSON qui transporte le payload EXACT en base64url.
 * La signature Ed25519 porte sur les octets du payload, sans re-canonicalisation JSON.
 * La clé privée SynoHomes n'est jamais présente sur une instance cliente.
 */

if (!defined('DMD_LICENSE_ROOT_KEY_ID')) define('DMD_LICENSE_ROOT_KEY_ID', 'synohomes-license-root-2026-01');
if (!defined('DMD_LICENSE_ROOT_PUBLIC_KEY_B64')) define('DMD_LICENSE_ROOT_PUBLIC_KEY_B64', 'ul90NxMhHRcKn8mHcJmO0nFpjQkh/W+Eot8V4wE2+Rg=');
// Alias conservé pour les écrans/extensions 1.13.3 qui affichent encore la racine.
if (!defined('DMD_LICENSE_KEY_ID')) define('DMD_LICENSE_KEY_ID', DMD_LICENSE_ROOT_KEY_ID);
if (!defined('DMD_LICENSE_PUBLIC_KEY_B64')) define('DMD_LICENSE_PUBLIC_KEY_B64', DMD_LICENSE_ROOT_PUBLIC_KEY_B64);
if (!defined('DMD_LICENSE_LAUNCH_UNTIL')) define('DMD_LICENSE_LAUNCH_UNTIL', '2027-01-01T00:00:00Z');
if (!defined('DMD_LICENSE_LAUNCH_REMOTE_MAX')) define('DMD_LICENSE_LAUNCH_REMOTE_MAX', 5);
if (!defined('DMD_LICENSE_LAUNCH_MYDESK_MODULES_MAX')) define('DMD_LICENSE_LAUNCH_MYDESK_MODULES_MAX', 5);
if (!defined('DMD_LICENSE_LAUNCH_INSTANCES_MAX')) define('DMD_LICENSE_LAUNCH_INSTANCES_MAX', 2);
if (!defined('DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX')) define('DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX', 5);

if (!function_exists('dmd_license_root')) {
    function dmd_license_root() { return dirname(__DIR__); }
}
if (!function_exists('dmd_license_var_dir')) {
    function dmd_license_var_dir() { return dmd_license_root() . '/var/licenses'; }
}
if (!function_exists('dmd_license_file')) {
    function dmd_license_file() { return dmd_license_var_dir() . '/current.dmdlic'; }
}
if (!function_exists('dmd_license_instance_id')) {
    function dmd_license_instance_id() {
        $file = dmd_license_root() . '/data/id_domydesk.txt';
        return is_file($file) ? trim((string)@file_get_contents($file)) : '';
    }
}
if (!function_exists('dmd_license_b64url_decode')) {
    function dmd_license_b64url_decode($text) {
        $text = strtr((string)$text, '-_', '+/');
        $pad = strlen($text) % 4;
        if ($pad) $text .= str_repeat('=', 4 - $pad);
        return base64_decode($text, true);
    }
}
if (!function_exists('dmd_license_init_storage')) {
    function dmd_license_init_storage() {
        $dir = dmd_license_var_dir();
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);
        $ht = $dir . '/.htaccess';
        $deny = "Options -Indexes\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n";
        if (!is_file($ht)) @file_put_contents($ht, $deny, LOCK_EX);
        $marker = $dir . '/README-PRIVATE.txt';
        if (!is_file($marker)) @file_put_contents($marker, "PRIVATE DOMYDESK LICENSE DATA - HTTP ACCESS MUST BE DENIED.\n", LOCK_EX);
        return is_dir($dir);
    }
}
if (!function_exists('dmd_license_launch_status')) {
    function dmd_license_launch_status($now = null) {
        $ts = $now === null ? time() : (int)$now;
        $until = strtotime(DMD_LICENSE_LAUNCH_UNTIL);
        $active = $until !== false && $ts < $until;
        return array(
            'ok' => true,
            'verified' => false,
            'source' => $active ? 'launch' : 'missing',
            'state' => $active ? 'launch' : 'license_required',
            'license_id' => $active ? 'DMD-LAUNCH-2026' : '',
            'instance_id' => dmd_license_instance_id(),
            'issued_at' => '',
            'valid_until' => $active ? DMD_LICENSE_LAUNCH_UNTIL : '',
            'grace_until' => $active ? DMD_LICENSE_LAUNCH_UNTIL : '',
            'revision' => 0,
            'entitlements' => array(
                // DMD-Agent Core reste utilisable. Le quota concerne Remote.
                'dmd_agent' => array('enabled'=>true, 'remote_targets_max'=>$active ? DMD_LICENSE_LAUNCH_REMOTE_MAX : 0),
                // Offre de lancement : 5 modules MyDesk jusqu'en janvier 2027.
                'dmd_mydesk' => array('enabled'=>$active, 'modules_max'=>$active ? DMD_LICENSE_LAUNCH_MYDESK_MODULES_MAX : 0),
                // DMD-Instances représente le multi-instance : une instance reste la base sans licence.
                'dmd_instances' => array('enabled'=>true, 'instances_max'=>$active ? DMD_LICENSE_LAUNCH_INSTANCES_MAX : 1),
                'dmd_ticketing_external' => array('enabled'=>$active, 'clients_max'=>$active ? DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX : 0),
            ),
            'message' => $active
                ? 'Licence de lancement : Remote 5 PC cibles, DMD-MyDesk 5 modules, DMD-Instances 2 instances et DMD-Ticketing Support jusqu’à 5 entreprises clientes jusqu’en janvier 2027.'
                : 'Licence individuelle requise pour les fonctions sous licence.',
        );
    }
}
if (!function_exists('dmd_license_verify_signer_cert')) {
    function dmd_license_verify_signer_cert($cert) {
        if (!is_array($cert) || (int)($cert['schema'] ?? 0)!==1 || (string)($cert['format'] ?? '')!=='DMD-LICENSE-SIGNER-CERT-V1' || (string)($cert['root_key_id'] ?? '')!==DMD_LICENSE_ROOT_KEY_ID) {
            return array('ok'=>false,'error'=>'license_signer_cert_invalid');
        }
        $raw = dmd_license_b64url_decode((string)($cert['payload_b64'] ?? ''));
        $sig = dmd_license_b64url_decode((string)($cert['signature_b64'] ?? ''));
        $root = base64_decode(DMD_LICENSE_ROOT_PUBLIC_KEY_B64, true);
        if (!is_string($raw) || !is_string($sig) || !is_string($root) || strlen($root)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES) {
            return array('ok'=>false,'error'=>'license_signer_cert_encoding_invalid');
        }
        if (!sodium_crypto_sign_verify_detached($sig, $raw, $root)) return array('ok'=>false,'error'=>'license_signer_cert_signature_invalid');
        $p = json_decode($raw, true);
        if (!is_array($p) || (int)($p['schema'] ?? 0)!==1 || (string)($p['format'] ?? '')!=='DMD-LICENSE-SIGNER-V1' || trim((string)($p['key_id'] ?? ''))==='') {
            return array('ok'=>false,'error'=>'license_signer_payload_invalid');
        }
        $pub = base64_decode((string)($p['public_key_b64'] ?? ''), true);
        if (!is_string($pub) || strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return array('ok'=>false,'error'=>'license_signer_public_key_invalid');
        return array('ok'=>true,'payload'=>$p,'public_key'=>$pub);
    }
}
if (!function_exists('dmd_license_issued_within_signer')) {
    function dmd_license_issued_within_signer($payload, $signer) {
        $issuedText = trim((string)($payload['issued_at'] ?? ''));
        if ($issuedText==='') return false;
        $issued = strtotime($issuedText); if ($issued===false) return false;
        if (!empty($signer['valid_from'])) { $from=strtotime((string)$signer['valid_from']); if ($from===false || $issued<$from) return false; }
        if (!empty($signer['valid_until'])) { $until=strtotime((string)$signer['valid_until']); if ($until===false || $issued>$until) return false; }
        return true;
    }
}
if (!function_exists('dmd_license_verify_raw')) {
    function dmd_license_verify_raw($raw, $expectedInstanceId = '') {
        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'crypto_unavailable','error'=>'php_sodium_unavailable','entitlements'=>array());
        }
        $env = json_decode(trim((string)$raw), true);
        if (!is_array($env) || (string)($env['format'] ?? '') !== 'DMD-LICENSE-V1' || (int)($env['schema'] ?? 0) !== 1 || (string)($env['alg'] ?? '') !== 'Ed25519') {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_envelope_invalid','entitlements'=>array());
        }
        $keyId = trim((string)($env['key_id'] ?? ''));
        if ($keyId==='') return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_key_invalid','entitlements'=>array());
        $payloadRaw = dmd_license_b64url_decode((string)($env['payload_b64'] ?? ''));
        $sig = dmd_license_b64url_decode((string)($env['signature_b64'] ?? ''));
        if (!is_string($payloadRaw) || !is_string($sig) || strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES) {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_signature_encoding_invalid','entitlements'=>array());
        }
        $signerPayload = null;
        if ($keyId===DMD_LICENSE_ROOT_KEY_ID && empty($env['signer_cert'])) {
            $verifyKey = base64_decode(DMD_LICENSE_ROOT_PUBLIC_KEY_B64, true);
            if (!is_string($verifyKey) || strlen($verifyKey)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_root_key_invalid','entitlements'=>array());
        } else {
            $cert = dmd_license_verify_signer_cert(isset($env['signer_cert']) && is_array($env['signer_cert']) ? $env['signer_cert'] : null);
            if (empty($cert['ok'])) return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>$cert['error'] ?? 'license_signer_invalid','entitlements'=>array());
            $signerPayload = $cert['payload'];
            if (!hash_equals((string)($signerPayload['key_id'] ?? ''), $keyId)) return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_signer_key_mismatch','entitlements'=>array());
            $verifyKey = $cert['public_key'];
        }
        if (!sodium_crypto_sign_verify_detached($sig, $payloadRaw, $verifyKey)) {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_signature_invalid','entitlements'=>array());
        }
        $p = json_decode($payloadRaw, true);
        if (!is_array($p) || (int)($p['schema'] ?? 0)!==1 || (string)($p['format'] ?? '')!=='DMD-LICENSE-PAYLOAD-V1') {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_payload_invalid','entitlements'=>array());
        }
        if (is_array($signerPayload) && !dmd_license_issued_within_signer($p, $signerPayload)) {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_issued_outside_signer_validity','entitlements'=>array());
        }
        $instanceId = trim((string)($p['instance_id'] ?? ''));
        if ($expectedInstanceId === '') $expectedInstanceId = dmd_license_instance_id();
        if ($expectedInstanceId === '' || $instanceId === '' || !hash_equals((string)$expectedInstanceId, $instanceId)) {
            return array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'instance_mismatch','error'=>'license_instance_mismatch','entitlements'=>array());
        }
        $now = time();
        $validFrom = !empty($p['valid_from']) ? strtotime((string)$p['valid_from']) : false;
        $validUntil = !empty($p['valid_until']) ? strtotime((string)$p['valid_until']) : false;
        $graceUntil = !empty($p['grace_until']) ? strtotime((string)$p['grace_until']) : $validUntil;
        if ($validFrom !== false && $now < $validFrom) {
            return array('ok'=>false,'verified'=>true,'source'=>'file','state'=>'not_yet_valid','error'=>'license_not_yet_valid','payload'=>$p,'entitlements'=>array(),'signer_key_id'=>$keyId);
        }
        $state = 'active';
        if ($validUntil !== false && $now > $validUntil) $state = ($graceUntil !== false && $now <= $graceUntil) ? 'grace' : 'expired';
        $ent = isset($p['entitlements']) && is_array($p['entitlements']) ? $p['entitlements'] : array();
        if ($state === 'expired') {
            $ent['dmd_agent'] = array_merge(array('enabled'=>true), isset($ent['dmd_agent'])&&is_array($ent['dmd_agent'])?$ent['dmd_agent']:array(), array('remote_targets_max'=>0));
            $ent['dmd_mydesk'] = array_merge(isset($ent['dmd_mydesk'])&&is_array($ent['dmd_mydesk'])?$ent['dmd_mydesk']:array(), array('enabled'=>false,'modules_max'=>0));
            $ent['dmd_instances'] = array_merge(array('enabled'=>true), isset($ent['dmd_instances'])&&is_array($ent['dmd_instances'])?$ent['dmd_instances']:array(), array('instances_max'=>1));
            $ent['dmd_ticketing_external'] = array('enabled'=>false, 'clients_max'=>0);
        }
        return array(
            'ok'=>true,'verified'=>true,'source'=>'file','state'=>$state,'signer_key_id'=>$keyId,
            'license_id'=>(string)($p['license_id']??''), 'customer_id'=>(string)($p['customer_id']??''),
            'instance_id'=>$instanceId,'issued_at'=>(string)($p['issued_at']??''),
            'valid_from'=>(string)($p['valid_from']??''),'valid_until'=>(string)($p['valid_until']??''),
            'grace_until'=>(string)($p['grace_until']??''),'revision'=>(int)($p['revision']??0),
            'entitlements'=>$ent,'payload'=>$p,'envelope'=>$env,
        );
    }
}
if (!function_exists('dmd_license_status')) {
    function dmd_license_status($forceReload = false) {
        static $cache = null;
        if (!$forceReload && is_array($cache)) return $cache;
        dmd_license_init_storage();
        $file = dmd_license_file();
        if (!is_file($file)) return $cache = dmd_license_launch_status();
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return $cache = array('ok'=>false,'verified'=>false,'source'=>'file','state'=>'invalid','error'=>'license_read_failed','entitlements'=>array());
        return $cache = dmd_license_verify_raw($raw, dmd_license_instance_id());
    }
}
if (!function_exists('dmd_license_entitlement')) {
    function dmd_license_entitlement($product) {
        $s = dmd_license_status();
        $e = isset($s['entitlements'][$product]) && is_array($s['entitlements'][$product]) ? $s['entitlements'][$product] : array();
        return $e;
    }
}
if (!function_exists('dmd_license_quota')) {
    function dmd_license_quota($product, $field, $fallback = 0) {
        $e = dmd_license_entitlement($product);
        return array_key_exists($field, $e) ? (int)$e[$field] : (int)$fallback;
    }
}
if (!function_exists('dmd_license_feature_enabled')) {
    function dmd_license_feature_enabled($product) {
        $e = dmd_license_entitlement($product);
        return !empty($e['enabled']);
    }
}
if (!function_exists('dmd_license_install_raw')) {
    function dmd_license_install_raw($raw) {
        $raw = trim((string)$raw);
        if ($raw === '') return array('ok'=>false,'error'=>'license_empty');
        $status = dmd_license_verify_raw($raw, dmd_license_instance_id());
        if (empty($status['ok']) || empty($status['verified'])) return array('ok'=>false,'error'=>$status['error'] ?? 'license_invalid','status'=>$status);
        if (!dmd_license_init_storage()) return array('ok'=>false,'error'=>'license_storage_failed');
        $file = dmd_license_file(); $tmp = $file . '.new-' . bin2hex(random_bytes(6));
        if (@file_put_contents($tmp, $raw . "\n", LOCK_EX) === false) return array('ok'=>false,'error'=>'license_write_failed');
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return array('ok'=>false,'error'=>'license_replace_failed'); }
        $fresh = dmd_license_verify_raw((string)@file_get_contents($file), dmd_license_instance_id());
        return array('ok'=>!empty($fresh['ok']),'status'=>$fresh);
    }
}

if (!function_exists('dmd_license_raw_envelope')) {
    function dmd_license_raw_envelope() {
        $file = dmd_license_file();
        if (!is_file($file)) return '';
        $raw = @file_get_contents($file);
        return is_string($raw) ? trim($raw) : '';
    }
}
