<?php
/**
 * DoMyDesk - API publique DMD-MyDesk pour les modules.
 *
 * Ce fichier constitue la façade stable entre les modules DoMyDesk et le
 * sous-système DMD-Agent/MyDesk. Un module ne doit pas dépendre directement
 * de l'arborescence adm/agent ni du protocole Agent.
 */

if (!function_exists('dmd_mydesk_agent_core_load')) {
    function dmd_mydesk_agent_core_load() {
        if (function_exists('dmd_agent_mydesk_notify')) return true;
        $file = dirname(__DIR__) . '/adm/agent/includes/agent_core.php';
        if (!is_file($file)) return false;
        require_once $file;
        return function_exists('dmd_agent_mydesk_notify');
    }
}

if (!function_exists('dmd_mydesk_is_context')) {
    function dmd_mydesk_is_context() {
        return !empty($_SESSION['dmd_mydesk_context']) && is_array($_SESSION['dmd_mydesk_context']);
    }
}

if (!function_exists('dmd_mydesk_context')) {
    function dmd_mydesk_context() {
        return dmd_mydesk_is_context() ? $_SESSION['dmd_mydesk_context'] : array();
    }
}

if (!function_exists('dmd_mydesk_current_agent_id')) {
    function dmd_mydesk_current_agent_id() {
        $ctx = dmd_mydesk_context();
        return trim((string)($ctx['agent_id'] ?? ''));
    }
}

if (!function_exists('dmd_mydesk_notify_agent')) {
    function dmd_mydesk_notify_agent($agentId, $moduleId, $title, $message, $options = array()) {
        if (!dmd_mydesk_agent_core_load()) return array('ok'=>false,'error'=>'mydesk_unavailable');
        return dmd_agent_mydesk_notify($agentId, $moduleId, $title, $message, is_array($options) ? $options : array());
    }
}

if (!function_exists('dmd_mydesk_notify_user')) {
    function dmd_mydesk_notify_user($email, $moduleId, $title, $message, $options = array()) {
        if (!dmd_mydesk_agent_core_load()) return array('ok'=>false,'error'=>'mydesk_unavailable');
        $options = is_array($options) ? $options : array();
        $options['user_email'] = strtolower(trim((string)$email));
        return dmd_agent_mydesk_notify('', $moduleId, $title, $message, $options);
    }
}

if (!function_exists('dmd_mydesk_notify_current_agent')) {
    function dmd_mydesk_notify_current_agent($moduleId, $title, $message, $options = array()) {
        $agentId = dmd_mydesk_current_agent_id();
        if ($agentId === '') return array('ok'=>false,'error'=>'not_mydesk_context');
        return dmd_mydesk_notify_agent($agentId, $moduleId, $title, $message, $options);
    }
}
