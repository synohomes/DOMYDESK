<?php
if (!function_exists('dmd_theme_page_key')) {
    function dmd_theme_page_key(?string $script = null): string {
        $script = str_replace('\\', '/', $script ?: ($_SERVER['SCRIPT_FILENAME'] ?? $_SERVER['SCRIPT_NAME'] ?? ''));
        $map = [
            '/modules/modules.php' => 'modules',
            '/data/procedures_list.php' => 'procedures',
            '/adm/site_settings.php' => 'site_settings',
            '/adm/market/marketmodules.php' => 'marketmodules',
            '/adm/market/unofficial_themes.php' => 'unofficial_themes',
            '/adm/market/unofficial_modules.php' => 'unofficial_modules',
            '/adm/module_updates.php' => 'module_updates',
            '/adm/updates.php' => 'updates',
            '/adm/system_logs.php' => 'system_logs',
            '/adm/indexcfg.php' => 'indexcfg',
            '/adm/actionhub.php' => 'actionhub',
            '/adm/fix_all_rights.php' => 'fix_all_rights',
            '/Quick-Session/admin.php' => 'quick_session_admin',
            '/data/agents/agents_view.php' => 'agents',
            '/profile_edit.php' => 'profile_edit',
            '/profile_view.php' => 'profile_view',
            '/members.php' => 'members',
            '/dashboard.php' => 'dashboard',
            '/register.php' => 'register',
            '/login.php' => 'login',
            '/index.php' => 'index',
        ];
        foreach ($map as $needle => $key) if (str_ends_with($script, $needle)) return $key;
        return preg_replace('/[^a-z0-9_-]+/i', '_', pathinfo($script, PATHINFO_FILENAME)) ?: 'index';
    }

    function dmd_theme_extra_links(string $rootDir, string $themeHrefBase, string $theme, ?string $pageKey = null): string {
        $theme = basename($theme ?: 'default');
        $pageKey = $pageKey ?: dmd_theme_page_key();
        $dir = rtrim($rootDir, '/\\') . '/theme/' . $theme;
        $href = rtrim($themeHrefBase, '/');
        $links = [];
        foreach ([['popups.css','popups.css'], ['pages/' . $pageKey . '.css','pages/' . $pageKey . '.css']] as [$diskRel,$webRel]) {
            $file = $dir . '/' . $diskRel;
            if (is_file($file)) {
                $links[] = '<link rel="stylesheet" href="' . htmlspecialchars($href . '/' . $theme . '/' . $webRel, ENT_QUOTES, 'UTF-8') . '?v=' . (int)filemtime($file) . '">';
            }
        }
        $userCss = rtrim($rootDir, '/\\') . '/core/dmd_theme_user.css.php';
        if (is_file($userCss)) {
            $rootHref = ($href === 'theme') ? '.' : preg_replace('~/theme$~', '', $href);
            $links[] = '<link rel="stylesheet" href="' . htmlspecialchars($rootHref . '/core/dmd_theme_user.css.php', ENT_QUOTES, 'UTF-8') . '?v=' . (int)filemtime($userCss) . '">';
        }
        return implode("\n", $links);
    }
}
