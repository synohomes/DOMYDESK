<?php
require_once __DIR__ . '/dmd_security.php';
dmd_security_session_start();
header('Content-Type: text/css; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
$scale = 100;
$showIcons = true;
$email = isset($_SESSION['user']['email']) ? basename((string)$_SESSION['user']['email']) : '';
if ($email !== '') {
    $file = dirname(__DIR__) . '/users/profiles/' . $email . '/theme.json';
    if (is_file($file)) {
        $data = json_decode((string)@file_get_contents($file), true);
        if (is_array($data)) {
            if (isset($data['ui_scale']) && is_numeric($data['ui_scale'])) $scale = (int)$data['ui_scale'];
            if (array_key_exists('module_list_icons', $data)) $showIcons = (bool)$data['module_list_icons'];
        }
    }
}
$scale = max(60, min(150, $scale));
$rootPx = 14 * ($scale / 100);
?>
:root { --dmd-ui-scale: <?= $scale ?>%; --dmd-ui-scale-factor: <?= number_format($scale/100, 3, '.', '') ?>; }
html { font-size: <?= number_format($rootPx, 2, '.', '') ?>px !important; }
body { font-size: 1rem !important; }
.dmd-user-module-icon { display: <?= $showIcons ? 'block' : 'none' ?> !important; }
