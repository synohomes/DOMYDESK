<?php
/**
 * DoMyDesk 1.2.0 - réglages centraux des outils Core et des dashboards.
 *
 * - réglages globaux dans adm/settings.json ;
 * - préférences utilisateur dans users/profiles/<email>/ui.json ;
 * - aucun réglage de module ni de thème ici.
 */

if (!defined('DMD_UI_ROOT')) {
    define('DMD_UI_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_ui_tool_defaults')) {
    function dmd_ui_tool_defaults() {
        return array(
            'actionhub' => array(
                'enabled' => true,
                'default_location' => 'header',
                'icon' => '⚡',
                'label' => 'ActionHub',
            ),
            'quick_session' => array(
                'enabled' => true,
                'default_location' => 'header',
                'icon' => '🚨',
                'label' => 'Quick-Session',
            ),
        );
    }
}

if (!function_exists('dmd_ui_normalize_location')) {
    function dmd_ui_normalize_location($value, $fallback = 'header') {
        $value = strtolower(trim((string)$value));
        $allowed = array('header', 'vertical', 'hidden');
        if (in_array($value, $allowed, true)) {
            return $value;
        }
        $fallback = strtolower(trim((string)$fallback));
        return in_array($fallback, $allowed, true) ? $fallback : 'header';
    }
}

if (!function_exists('dmd_ui_normalize_icon')) {
    function dmd_ui_normalize_icon($value, $fallback = '⭐') {
        $value = trim(strip_tags((string)$value));
        $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
        if ($value === '') {
            $value = trim((string)$fallback);
        }
        if (function_exists('mb_substr')) {
            $value = mb_substr($value, 0, 8, 'UTF-8');
        } else {
            $value = substr($value, 0, 24);
        }
        return $value !== '' ? $value : '⭐';
    }
}

if (!function_exists('dmd_ui_settings_with_defaults')) {
    function dmd_ui_settings_with_defaults($settings) {
        if (!is_array($settings)) {
            $settings = array();
        }

        $defaults = dmd_ui_tool_defaults();
        $tools = isset($settings['core_tools']) && is_array($settings['core_tools'])
            ? $settings['core_tools']
            : array();

        foreach ($defaults as $toolId => $default) {
            $current = isset($tools[$toolId]) && is_array($tools[$toolId])
                ? $tools[$toolId]
                : array();

            $tools[$toolId] = array(
                'enabled' => array_key_exists('enabled', $current)
                    ? (bool)$current['enabled']
                    : (bool)$default['enabled'],
                'default_location' => dmd_ui_normalize_location(
                    isset($current['default_location']) ? $current['default_location'] : $default['default_location'],
                    $default['default_location']
                ),
                'icon' => dmd_ui_normalize_icon(
                    isset($current['icon']) ? $current['icon'] : $default['icon'],
                    $default['icon']
                ),
            );
        }

        $settings['core_tools'] = $tools;
        $settings['dashboard_limit'] = max(0, (int)(isset($settings['dashboard_limit']) ? $settings['dashboard_limit'] : 0));

        return $settings;
    }
}

if (!function_exists('dmd_ui_site_settings')) {
    function dmd_ui_site_settings() {
        $file = DMD_UI_ROOT . '/adm/settings.json';
        $settings = array();
        if (is_file($file)) {
            $decoded = json_decode((string)@file_get_contents($file), true);
            if (is_array($decoded)) {
                $settings = $decoded;
            }
        }
        return dmd_ui_settings_with_defaults($settings);
    }
}

if (!function_exists('dmd_ui_global_tool')) {
    function dmd_ui_global_tool($toolId, $settings = null) {
        $defaults = dmd_ui_tool_defaults();
        $toolId = trim((string)$toolId);
        if (!isset($defaults[$toolId])) {
            return null;
        }

        $settings = $settings === null
            ? dmd_ui_site_settings()
            : dmd_ui_settings_with_defaults($settings);

        $config = isset($settings['core_tools'][$toolId]) && is_array($settings['core_tools'][$toolId])
            ? $settings['core_tools'][$toolId]
            : array();

        return array(
            'id' => $toolId,
            'label' => $defaults[$toolId]['label'],
            'enabled' => !empty($config['enabled']),
            'default_location' => dmd_ui_normalize_location(
                isset($config['default_location']) ? $config['default_location'] : $defaults[$toolId]['default_location'],
                $defaults[$toolId]['default_location']
            ),
            'icon' => dmd_ui_normalize_icon(
                isset($config['icon']) ? $config['icon'] : $defaults[$toolId]['icon'],
                $defaults[$toolId]['icon']
            ),
        );
    }
}

if (!function_exists('dmd_ui_safe_email')) {
    function dmd_ui_safe_email($email) {
        $email = trim((string)$email);
        if ($email === '' || basename($email) !== $email) {
            return '';
        }
        if (strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) {
            return '';
        }
        return $email;
    }
}

if (!function_exists('dmd_ui_user_file')) {
    function dmd_ui_user_file($email) {
        $email = dmd_ui_safe_email($email);
        return $email === '' ? '' : DMD_UI_ROOT . '/users/profiles/' . $email . '/ui.json';
    }
}

if (!function_exists('dmd_ui_user_preferences')) {
    function dmd_ui_user_preferences($email) {
        $file = dmd_ui_user_file($email);
        if ($file === '' || !is_file($file)) {
            return array('core_tools' => array());
        }
        $decoded = json_decode((string)@file_get_contents($file), true);
        if (!is_array($decoded)) {
            return array('core_tools' => array());
        }
        if (!isset($decoded['core_tools']) || !is_array($decoded['core_tools'])) {
            $decoded['core_tools'] = array();
        }
        return $decoded;
    }
}

if (!function_exists('dmd_ui_write_json')) {
    function dmd_ui_write_json($file, array $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }

        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
            return false;
        }
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_ui_save_user_locations')) {
    function dmd_ui_save_user_locations($email, array $locations) {
        $file = dmd_ui_user_file($email);
        if ($file === '') {
            return false;
        }

        $prefs = dmd_ui_user_preferences($email);
        if (!isset($prefs['core_tools']) || !is_array($prefs['core_tools'])) {
            $prefs['core_tools'] = array();
        }

        foreach (dmd_ui_tool_defaults() as $toolId => $default) {
            if (!array_key_exists($toolId, $locations)) {
                continue;
            }
            $prefs['core_tools'][$toolId] = array(
                'location' => dmd_ui_normalize_location($locations[$toolId], $default['default_location']),
            );
        }

        $prefs['updated_at'] = time();
        $prefs['updated_at_iso'] = date('c', $prefs['updated_at']);

        return dmd_ui_write_json($file, $prefs);
    }
}

if (!function_exists('dmd_ui_user_location')) {
    function dmd_ui_user_location($email, $toolId, $settings = null) {
        $global = dmd_ui_global_tool($toolId, $settings);
        if (!$global) {
            return 'hidden';
        }

        $prefs = dmd_ui_user_preferences($email);
        $raw = isset($prefs['core_tools'][$toolId]['location'])
            ? $prefs['core_tools'][$toolId]['location']
            : $global['default_location'];

        return dmd_ui_normalize_location($raw, $global['default_location']);
    }
}

if (!function_exists('dmd_ui_effective_tool')) {
    function dmd_ui_effective_tool($email, $toolId, $settings = null) {
        $global = dmd_ui_global_tool($toolId, $settings);
        if (!$global) {
            return null;
        }

        $chosenLocation = dmd_ui_user_location($email, $toolId, $settings);
        $effectiveLocation = !empty($global['enabled']) ? $chosenLocation : 'hidden';

        $global['user_location'] = $chosenLocation;
        $global['location'] = $effectiveLocation;
        $global['visible'] = !empty($global['enabled']) && $effectiveLocation !== 'hidden';
        return $global;
    }
}

if (!function_exists('dmd_ui_dashboard_limit')) {
    function dmd_ui_dashboard_limit($settings = null) {
        $settings = $settings === null
            ? dmd_ui_site_settings()
            : dmd_ui_settings_with_defaults($settings);
        return max(0, (int)(isset($settings['dashboard_limit']) ? $settings['dashboard_limit'] : 0));
    }
}

if (!function_exists('dmd_ui_dashboard_limit_reached')) {
    function dmd_ui_dashboard_limit_reached($currentCount, $settings = null) {
        $limit = dmd_ui_dashboard_limit($settings);
        return $limit > 0 && (int)$currentCount >= $limit;
    }
}

if (!function_exists('dmd_ui_current_role')) {
    function dmd_ui_current_role() {
        if (function_exists('dmd_sys_current_role')) {
            return (string)dmd_sys_current_role();
        }
        if (!empty($_SESSION['user']['role_system'])) {
            return (string)$_SESSION['user']['role_system'];
        }
        if (!empty($_SESSION['role_system'])) {
            return (string)$_SESSION['role_system'];
        }
        return 'user';
    }
}

if (!function_exists('dmd_ui_tool_api_allowed')) {
    function dmd_ui_tool_api_allowed($toolId, $email = '') {
        $role = dmd_ui_current_role();
        $isAdmin = in_array($role, array('admin', 'superadmin'), true);
        $global = dmd_ui_global_tool($toolId);

        // Les pages d'administration doivent pouvoir gérer l'historique et
        // préparer une réactivation même lorsque le lanceur global est coupé.
        if ($isAdmin) {
            return true;
        }

        if (!$global || empty($global['enabled'])) {
            return false;
        }

        $email = $email !== '' ? $email : (isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : '');
        $effective = dmd_ui_effective_tool($email, $toolId);
        return is_array($effective) && !empty($effective['visible']);
    }
}
