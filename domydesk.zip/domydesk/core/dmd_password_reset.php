<?php
/**
 * DoMyDesk 1.2.0 - Réinitialisation de mot de passe par e-mail.
 *
 * Composant volontairement indépendant : il s'appuie uniquement sur les briques
 * existantes de DoMyDesk pour les profils, le MFA, l'Active Directory, les logs
 * et le transport e-mail central.
 */

require_once __DIR__ . '/dmd_permissions.php';
require_once __DIR__ . '/dmd_security.php';
require_once __DIR__ . '/dmd_mfa.php';
require_once __DIR__ . '/dmd_system_services.php';
require_once __DIR__ . '/dmd_notification_mail.php';
require_once __DIR__ . '/directory/dmd_ad_sync.php';

if (!defined('DMD_PASSWORD_RESET_ROOT')) {
    define('DMD_PASSWORD_RESET_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_password_reset_config')) {
    function dmd_password_reset_config() {
        return array(
            'token_ttl' => 900,              // 15 minutes
            'request_window' => 900,         // 15 minutes
            'max_requests_ip' => 8,
            'max_requests_identity' => 4,
            'max_mfa_attempts' => 5,
            'min_password_length' => 8,
        );
    }
}

if (!function_exists('dmd_password_reset_store_file')) {
    function dmd_password_reset_store_file() {
        return DMD_PASSWORD_RESET_ROOT . '/var/security/password_reset.json';
    }
}

if (!function_exists('dmd_password_reset_prepare_store_dir')) {
    function dmd_password_reset_prepare_store_dir() {
        $dir = dirname(dmd_password_reset_store_file());
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        @chmod($dir, 0750);
        return true;
    }
}

if (!function_exists('dmd_password_reset_store_default')) {
    function dmd_password_reset_store_default() {
        return array('version' => 1, 'tokens' => array(), 'requests' => array());
    }
}

if (!function_exists('dmd_password_reset_store_read')) {
    function dmd_password_reset_store_read() {
        $file = dmd_password_reset_store_file();
        if (!is_file($file)) return dmd_password_reset_store_default();
        $raw = @file_get_contents($file);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) return dmd_password_reset_store_default();
        if (!isset($data['tokens']) || !is_array($data['tokens'])) $data['tokens'] = array();
        if (!isset($data['requests']) || !is_array($data['requests'])) $data['requests'] = array();
        return $data;
    }
}

if (!function_exists('dmd_password_reset_store_write')) {
    function dmd_password_reset_store_write($data) {
        if (!is_array($data) || !dmd_password_reset_prepare_store_dir()) return false;
        $file = dmd_password_reset_store_file();
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;
        $ok = @file_put_contents($file, $json . "\n", LOCK_EX) !== false;
        if ($ok) @chmod($file, 0600);
        return $ok;
    }
}

if (!function_exists('dmd_password_reset_cleanup')) {
    function dmd_password_reset_cleanup($data) {
        if (!is_array($data)) $data = dmd_password_reset_store_default();
        $now = time();
        $requestKeepAfter = $now - 3600;
        $tokenKeepAfter = $now - 86400;

        $requests = array();
        foreach ((array)($data['requests'] ?? array()) as $request) {
            if (!is_array($request)) continue;
            if ((int)($request['at'] ?? 0) >= $requestKeepAfter) $requests[] = $request;
        }

        $tokens = array();
        foreach ((array)($data['tokens'] ?? array()) as $token) {
            if (!is_array($token)) continue;
            $created = (int)($token['created_at'] ?? 0);
            $expires = (int)($token['expires_at'] ?? 0);
            $used = !empty($token['used']);
            if (!$used && $expires >= $now) {
                $tokens[] = $token;
                continue;
            }
            if ($created >= $tokenKeepAfter) $tokens[] = $token;
        }

        $data['requests'] = array_slice($requests, -500);
        $data['tokens'] = array_slice($tokens, -200);
        return $data;
    }
}

if (!function_exists('dmd_password_reset_client_ip')) {
    function dmd_password_reset_client_ip() {
        return trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    }
}

if (!function_exists('dmd_password_reset_hash_key')) {
    function dmd_password_reset_hash_key($value) {
        return hash('sha256', strtolower(trim((string)$value)));
    }
}

if (!function_exists('dmd_password_reset_find_email')) {
    function dmd_password_reset_find_email($identity) {
        $identity = trim((string)$identity);
        if ($identity === '') return '';

        $resolved = dmd_directory_find_profile_email_by_login($identity);
        if ($resolved !== '' && is_file(dmd_profile_path($resolved, true))) return $resolved;

        if (filter_var($identity, FILTER_VALIDATE_EMAIL)) {
            $needle = strtolower($identity);
            foreach (glob(DMD_PASSWORD_RESET_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: array() as $dir) {
                $candidate = basename($dir);
                if (strtolower($candidate) === $needle && is_file(dmd_profile_path($candidate, true))) return $candidate;
            }
        }
        return '';
    }
}

if (!function_exists('dmd_password_reset_account_targets')) {
    function dmd_password_reset_account_targets($profile) {
        $profile = is_array($profile) ? $profile : array();
        $localHash = (string)($profile['motdepasse'] ?? ($profile['password'] ?? ''));
        $local = $localHash !== '';
        $ad = strtolower((string)($profile['auth_source'] ?? 'local')) === 'active_directory'
            && trim((string)($profile['ad']['distinguished_name'] ?? '')) !== '';
        return array('local' => $local, 'ad' => $ad);
    }
}

if (!function_exists('dmd_password_reset_safe_host')) {
    function dmd_password_reset_safe_host($value) {
        $value = trim((string)$value);
        if (strpos($value, ',') !== false) $value = trim(explode(',', $value, 2)[0]);
        if ($value === '' || strpos($value, "\r") !== false || strpos($value, "\n") !== false) return '';
        if (!preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/', $value)) return '';
        return $value;
    }
}

if (!function_exists('dmd_password_reset_forwarded_headers_trusted')) {
    function dmd_password_reset_forwarded_headers_trusted() {
        $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
        if ($ip === '127.0.0.1' || $ip === '::1') return true;
        if (preg_match('/^10\./', $ip) || preg_match('/^192\.168\./', $ip)) return true;
        if (preg_match('/^172\.(\d+)\./', $ip, $m)) {
            $n = (int)$m[1];
            if ($n >= 16 && $n <= 31) return true;
        }
        // Tailscale / RFC6598 : 100.64.0.0/10.
        if (preg_match('/^100\.(\d+)\./', $ip, $m)) {
            $n = (int)$m[1];
            if ($n >= 64 && $n <= 127) return true;
        }
        $lower = strtolower($ip);
        return strpos($lower, 'fc') === 0 || strpos($lower, 'fd') === 0 || strpos($lower, 'fe80:') === 0;
    }
}

if (!function_exists('dmd_password_reset_request_scheme')) {
    function dmd_password_reset_request_scheme() {
        $forwarded = dmd_password_reset_forwarded_headers_trusted()
            ? strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')))
            : '';
        if (strpos($forwarded, ',') !== false) $forwarded = trim(explode(',', $forwarded, 2)[0]);
        if ($forwarded === 'https' || $forwarded === 'http') return $forwarded;
        if (dmd_password_reset_forwarded_headers_trusted()) {
            $forwardedSsl = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_SSL'] ?? ($_SERVER['HTTP_FRONT_END_HTTPS'] ?? ''))));
            if (in_array($forwardedSsl, array('on', '1', 'https'), true)) return 'https';
            if ((int)($_SERVER['HTTP_X_FORWARDED_PORT'] ?? 0) === 443) return 'https';
        }
        if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return 'https';
        $scheme = strtolower(trim((string)($_SERVER['REQUEST_SCHEME'] ?? '')));
        if ($scheme === 'https' || $scheme === 'http') return $scheme;
        return ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443) ? 'https' : 'http';
    }
}

if (!function_exists('dmd_password_reset_base_path')) {
    function dmd_password_reset_base_path() {
        if (function_exists('dmd_mfa_guard_base_url')) return rtrim(dmd_mfa_guard_base_url(), '/');
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/'));
        $dir = rtrim(dirname($script), '/');
        return ($dir === '' || $dir === '.') ? '' : $dir;
    }
}

if (!function_exists('dmd_password_reset_instance_base_url')) {
    function dmd_password_reset_instance_base_url() {
        // Une URL explicitement configurée aura toujours priorité si elle est ajoutée plus tard.
        $candidates = array();
        $env = trim((string)getenv('DMD_INSTANCE_URL'));
        if ($env !== '') $candidates[] = $env;

        $settingsFile = DMD_PASSWORD_RESET_ROOT . '/adm/settings.json';
        if (is_file($settingsFile)) {
            $settings = json_decode((string)@file_get_contents($settingsFile), true);
            if (is_array($settings)) {
                foreach (array('instance_url', 'site_url', 'base_url') as $key) {
                    if (!empty($settings[$key])) $candidates[] = trim((string)$settings[$key]);
                }
            }
        }

        foreach ($candidates as $candidate) {
            if (preg_match('#^https?://#i', $candidate)) return rtrim($candidate, '/');
        }

        $host = dmd_password_reset_forwarded_headers_trusted()
            ? dmd_password_reset_safe_host($_SERVER['HTTP_X_FORWARDED_HOST'] ?? '')
            : '';
        if ($host === '') $host = dmd_password_reset_safe_host($_SERVER['HTTP_HOST'] ?? '');
        if ($host === '') $host = dmd_password_reset_safe_host($_SERVER['SERVER_NAME'] ?? '');
        if ($host === '') return '';

        return dmd_password_reset_request_scheme() . '://' . $host . dmd_password_reset_base_path();
    }
}

if (!function_exists('dmd_password_reset_mask_email')) {
    function dmd_password_reset_mask_email($email) {
        $email = trim((string)$email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'votre compte';
        list($local, $domain) = explode('@', $email, 2);
        $visible = substr($local, 0, min(2, strlen($local)));
        return $visible . str_repeat('*', max(3, strlen($local) - strlen($visible))) . '@' . $domain;
    }
}

if (!function_exists('dmd_password_reset_log')) {
    function dmd_password_reset_log($action, $email, $status, $details, $extra = array()) {
        if (function_exists('dmd_system_log')) {
            return dmd_system_log($action, (string)$email, $status, $details, is_array($extra) ? $extra : array());
        }
        return false;
    }
}

if (!function_exists('dmd_password_reset_rate_allowed')) {
    function dmd_password_reset_rate_allowed(&$data, $identity) {
        $cfg = dmd_password_reset_config();
        $now = time();
        $since = $now - (int)$cfg['request_window'];
        $ipHash = dmd_password_reset_hash_key(dmd_password_reset_client_ip());
        $identityHash = dmd_password_reset_hash_key($identity);
        $ipCount = 0;
        $identityCount = 0;

        foreach ((array)($data['requests'] ?? array()) as $request) {
            if (!is_array($request) || (int)($request['at'] ?? 0) < $since) continue;
            if (hash_equals((string)($request['ip_hash'] ?? ''), $ipHash)) $ipCount++;
            if (hash_equals((string)($request['identity_hash'] ?? ''), $identityHash)) $identityCount++;
        }

        $data['requests'][] = array('at' => $now, 'ip_hash' => $ipHash, 'identity_hash' => $identityHash);
        return $ipCount < (int)$cfg['max_requests_ip'] && $identityCount < (int)$cfg['max_requests_identity'];
    }
}

if (!function_exists('dmd_password_reset_send_mail')) {
    function dmd_password_reset_send_mail($to, $subject, $body, &$error) {
        $error = '';
        $config = dmd_notifications_config();
        $smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
        return dmd_notifications_transport_send($to, $subject, $body, $smtp, $error);
    }
}

if (!function_exists('dmd_password_reset_create_request')) {
    function dmd_password_reset_create_request($identity) {
        $identity = trim((string)$identity);
        $generic = array('ok' => true, 'public_message' => 'Si ce compte existe, un e-mail de réinitialisation vient d’être envoyé.');
        if ($identity === '') return $generic;

        $data = dmd_password_reset_cleanup(dmd_password_reset_store_read());
        $rateAllowed = dmd_password_reset_rate_allowed($data, $identity);
        dmd_password_reset_store_write($data);
        if (!$rateAllowed) {
            dmd_password_reset_log('password_reset_rate_limited', '', 'denied', 'Demande de réinitialisation limitée.', array('identity_hash' => dmd_password_reset_hash_key($identity)));
            return $generic;
        }

        $email = dmd_password_reset_find_email($identity);
        if ($email === '') {
            dmd_password_reset_log('password_reset_requested', '', 'info', 'Demande de réinitialisation pour un compte non résolu.', array('identity_hash' => dmd_password_reset_hash_key($identity)));
            return $generic;
        }

        $profile = dmd_read_profile($email);
        if (!$profile || strtolower((string)($profile['account_status'] ?? 'active')) !== 'active') {
            dmd_password_reset_log('password_reset_requested', $email, 'denied', 'Réinitialisation non envoyée : compte non actif.');
            return $generic;
        }

        $targets = dmd_password_reset_account_targets($profile);
        if (empty($targets['local']) && empty($targets['ad'])) {
            dmd_password_reset_log('password_reset_requested', $email, 'failed', 'Aucune source de mot de passe réinitialisable n’a été détectée.');
            return $generic;
        }

        try {
            $token = bin2hex(random_bytes(32));
            $recordId = 'PWD-' . strtoupper(bin2hex(random_bytes(8)));
        } catch (Throwable $e) {
            dmd_password_reset_log('password_reset_requested', $email, 'failed', 'Génération du jeton impossible.');
            return $generic;
        }

        $now = time();
        $cfg = dmd_password_reset_config();
        $data = dmd_password_reset_cleanup(dmd_password_reset_store_read());

        // Un nouveau lien invalide les liens encore actifs du même compte.
        foreach ($data['tokens'] as &$old) {
            if (is_array($old) && empty($old['used']) && strtolower((string)($old['email'] ?? '')) === strtolower($email)) {
                $old['used'] = true;
                $old['used_reason'] = 'superseded';
                $old['used_at'] = $now;
            }
        }
        unset($old);

        $data['tokens'][] = array(
            'id' => $recordId,
            'email' => $email,
            'token_hash' => hash('sha256', $token),
            'created_at' => $now,
            'expires_at' => $now + (int)$cfg['token_ttl'],
            'used' => false,
            'mfa_attempts' => 0,
            'request_ip_hash' => dmd_password_reset_hash_key(dmd_password_reset_client_ip()),
        );

        if (!dmd_password_reset_store_write($data)) {
            dmd_password_reset_log('password_reset_requested', $email, 'failed', 'Impossible d’enregistrer le jeton de réinitialisation.');
            return $generic;
        }

        $base = dmd_password_reset_instance_base_url();
        if ($base === '') {
            dmd_password_reset_log('password_reset_mail_failed', $email, 'failed', 'URL de l’instance impossible à déterminer.');
            return $generic;
        }

        $link = rtrim($base, '/') . '/reset_password.php?token=' . rawurlencode($token);
        $site = dmd_notifications_site_context();
        $instance = trim((string)($site['instance_name'] ?? 'DoMyDesk')) ?: 'DoMyDesk';
        $mfaEnabled = dmd_mfa_enabled($email);
        $subject = '[' . $instance . '] Réinitialisation de votre mot de passe';
        $body = "Une demande de réinitialisation du mot de passe de votre compte DoMyDesk a été effectuée.\n\n"
            . "Compte : " . dmd_password_reset_mask_email($email) . "\n\n"
            . "Ouvrez ce lien pour choisir un nouveau mot de passe :\n" . $link . "\n\n"
            . "Ce lien est valable pendant 15 minutes et ne peut être utilisé qu’une seule fois.\n";
        if ($mfaEnabled) {
            $body .= "Votre compte est protégé par MFA : votre code Microsoft Authenticator sera obligatoire avant la réinitialisation.\n";
        }
        $body .= "\nSi vous n’êtes pas à l’origine de cette demande, ignorez cet e-mail.";

        $mailError = '';
        if (dmd_password_reset_send_mail($email, $subject, $body, $mailError)) {
            dmd_password_reset_log('password_reset_mail_sent', $email, 'success', 'E-mail de réinitialisation envoyé.', array('mfa_required' => $mfaEnabled, 'targets' => $targets));
        } else {
            // Un lien non distribué ne doit pas rester actif.
            $fresh = dmd_password_reset_store_read();
            foreach ($fresh['tokens'] as &$stored) {
                if (is_array($stored) && (string)($stored['id'] ?? '') === $recordId) {
                    $stored['used'] = true;
                    $stored['used_reason'] = 'mail_failed';
                    $stored['used_at'] = time();
                }
            }
            unset($stored);
            dmd_password_reset_store_write($fresh);
            dmd_password_reset_log('password_reset_mail_failed', $email, 'failed', 'Échec de l’envoi du mail de réinitialisation.', array('mail_error' => $mailError));
        }

        return $generic;
    }
}

if (!function_exists('dmd_password_reset_find_record')) {
    function dmd_password_reset_find_record($token, &$data = null, &$index = null) {
        $token = trim((string)$token);
        $data = dmd_password_reset_cleanup(dmd_password_reset_store_read());
        $index = null;
        if ($token === '' || !preg_match('/^[a-f0-9]{64}$/i', $token)) return array();
        $hash = hash('sha256', $token);
        $now = time();
        foreach ($data['tokens'] as $i => $record) {
            if (!is_array($record)) continue;
            $storedHash = (string)($record['token_hash'] ?? '');
            if ($storedHash === '' || !hash_equals($storedHash, $hash)) continue;
            if (!empty($record['used']) || (int)($record['expires_at'] ?? 0) < $now) return array();
            $index = $i;
            return $record;
        }
        return array();
    }
}

if (!function_exists('dmd_password_reset_mfa_session_key')) {
    function dmd_password_reset_mfa_session_key($record) {
        return 'pwdreset:' . (string)($record['id'] ?? '');
    }
}

if (!function_exists('dmd_password_reset_mfa_is_verified')) {
    function dmd_password_reset_mfa_is_verified($record, $token) {
        if (session_status() === PHP_SESSION_NONE) @session_start();
        $key = dmd_password_reset_mfa_session_key($record);
        $proof = $_SESSION['dmd_password_reset_mfa'][$key] ?? null;
        if (!is_array($proof)) return false;
        if ((int)($proof['at'] ?? 0) < time() - 600) return false;
        $expected = hash('sha256', (string)$token);
        return !empty($proof['token_hash']) && hash_equals((string)$proof['token_hash'], $expected);
    }
}

if (!function_exists('dmd_password_reset_verify_mfa')) {
    function dmd_password_reset_verify_mfa($token, $code) {
        $data = null; $index = null;
        $record = dmd_password_reset_find_record($token, $data, $index);
        if (!$record) return array('ok' => false, 'error' => 'Lien invalide ou expiré.');
        $email = (string)$record['email'];
        if (!dmd_mfa_enabled($email)) return array('ok' => true, 'not_required' => true);

        $cfg = dmd_password_reset_config();
        $attempts = (int)($record['mfa_attempts'] ?? 0);
        if ($attempts >= (int)$cfg['max_mfa_attempts']) {
            $data['tokens'][$index]['used'] = true;
            $data['tokens'][$index]['used_reason'] = 'mfa_locked';
            $data['tokens'][$index]['used_at'] = time();
            dmd_password_reset_store_write($data);
            dmd_password_reset_log('password_reset_mfa_locked', $email, 'denied', 'Lien invalidé après trop de codes MFA incorrects.');
            return array('ok' => false, 'error' => 'Trop de codes incorrects. Demandez un nouveau lien de réinitialisation.', 'locked' => true);
        }

        // Réinitialisation de mot de passe : seul le TOTP courant est accepté.
        // Les codes de récupération MFA ne servent pas de contournement à cette procédure.
        if (!dmd_mfa_verify_totp($email, $code)) {
            $attempts++;
            $data['tokens'][$index]['mfa_attempts'] = $attempts;
            if ($attempts >= (int)$cfg['max_mfa_attempts']) {
                $data['tokens'][$index]['used'] = true;
                $data['tokens'][$index]['used_reason'] = 'mfa_locked';
                $data['tokens'][$index]['used_at'] = time();
            }
            dmd_password_reset_store_write($data);
            dmd_password_reset_log('password_reset_mfa_failed', $email, 'denied', 'Code MFA incorrect pendant une réinitialisation de mot de passe.', array('attempts' => $attempts));
            $remaining = max(0, (int)$cfg['max_mfa_attempts'] - $attempts);
            return array('ok' => false, 'error' => $remaining > 0 ? ('Code MFA incorrect. Tentatives restantes : ' . $remaining . '.') : 'Trop de codes incorrects. Demandez un nouveau lien de réinitialisation.', 'locked' => $remaining === 0);
        }

        if (session_status() === PHP_SESSION_NONE) @session_start();
        if (!isset($_SESSION['dmd_password_reset_mfa']) || !is_array($_SESSION['dmd_password_reset_mfa'])) $_SESSION['dmd_password_reset_mfa'] = array();
        $key = dmd_password_reset_mfa_session_key($record);
        $_SESSION['dmd_password_reset_mfa'][$key] = array('at' => time(), 'token_hash' => hash('sha256', (string)$token));
        dmd_password_reset_log('password_reset_mfa_verified', $email, 'success', 'MFA validé pour la réinitialisation du mot de passe.');
        return array('ok' => true);
    }
}

if (!function_exists('dmd_password_reset_ad_password')) {
    function dmd_password_reset_ad_password($profile, $newPassword) {
        $dn = trim((string)($profile['ad']['distinguished_name'] ?? ''));
        if ($dn === '') return array('ok' => false, 'error' => 'Identité Active Directory incomplète : DN absent.');

        $conn = dmd_directory_ldap_connect(null, true);
        if (empty($conn['ok']) || empty($conn['ldap'])) {
            return array('ok' => false, 'error' => (string)($conn['error'] ?? 'Connexion Active Directory impossible.'));
        }
        $ldap = $conn['ldap'];

        if (!function_exists('iconv')) {
            @ldap_unbind($ldap);
            return array('ok' => false, 'error' => 'Extension iconv indisponible : encodage du mot de passe Active Directory impossible.');
        }

        $quoted = '"' . (string)$newPassword . '"';
        $encoded = @iconv('UTF-8', 'UTF-16LE', $quoted);
        if ($encoded === false) {
            @ldap_unbind($ldap);
            return array('ok' => false, 'error' => 'Encodage UTF-16LE du mot de passe Active Directory impossible.');
        }

        $ok = @ldap_mod_replace($ldap, $dn, array('unicodePwd' => $encoded));
        if ($ok) {
            @ldap_unbind($ldap);
            return array('ok' => true);
        }

        $ldapError = dmd_directory_ldap_error_text($ldap);
        $diag = dmd_directory_ldap_diagnostic($ldap);
        $diagMessage = (string)($diag['message'] ?? '');
        @ldap_unbind($ldap);

        $combined = strtolower($ldapError . ' ' . $diagMessage);
        if (strpos($combined, '52d') !== false || strpos($combined, 'password restriction') !== false || strpos($combined, 'constraint') !== false) {
            return array('ok' => false, 'error' => 'Active Directory refuse ce mot de passe selon sa politique de complexité, d’historique ou d’âge minimal. Choisissez-en un autre.');
        }
        if (strpos($combined, 'insufficient') !== false || strpos($combined, '50') !== false) {
            return array('ok' => false, 'error' => 'Le compte de service DoMyDesk n’a pas le droit de réinitialiser ce mot de passe Active Directory.');
        }
        return array('ok' => false, 'error' => 'Active Directory a refusé la réinitialisation : ' . ($diagMessage !== '' ? $diagMessage : $ldapError));
    }
}

if (!function_exists('dmd_password_reset_validate_new_password')) {
    function dmd_password_reset_validate_new_password($password, $confirmation) {
        $cfg = dmd_password_reset_config();
        if ((string)$password !== (string)$confirmation) return array('ok' => false, 'error' => 'La confirmation du mot de passe ne correspond pas.');
        if (strlen((string)$password) < (int)$cfg['min_password_length']) return array('ok' => false, 'error' => 'Le mot de passe doit contenir au minimum ' . (int)$cfg['min_password_length'] . ' caractères.');
        if (strlen((string)$password) > 256) return array('ok' => false, 'error' => 'Le mot de passe est trop long.');
        return array('ok' => true);
    }
}

if (!function_exists('dmd_password_reset_apply')) {
    function dmd_password_reset_apply($token, $newPassword, $confirmation) {
        $validPassword = dmd_password_reset_validate_new_password($newPassword, $confirmation);
        if (empty($validPassword['ok'])) return $validPassword;

        $data = null; $index = null;
        $record = dmd_password_reset_find_record($token, $data, $index);
        if (!$record) return array('ok' => false, 'error' => 'Lien invalide ou expiré.');
        $email = dmd_safe_user_key((string)($record['email'] ?? ''));
        if ($email === '') return array('ok' => false, 'error' => 'Compte de réinitialisation invalide.');

        if (dmd_mfa_enabled($email) && !dmd_password_reset_mfa_is_verified($record, $token)) {
            dmd_password_reset_log('password_reset_mfa_required', $email, 'denied', 'Tentative de réinitialisation sans preuve MFA valide.');
            return array('ok' => false, 'error' => 'La validation MFA est obligatoire avant de choisir le nouveau mot de passe.', 'mfa_required' => true);
        }

        $profile = dmd_read_profile($email);
        if (!$profile) return array('ok' => false, 'error' => 'Compte utilisateur introuvable.');
        $targets = dmd_password_reset_account_targets($profile);
        if (empty($targets['local']) && empty($targets['ad'])) return array('ok' => false, 'error' => 'Aucune source de mot de passe réinitialisable n’a été détectée.');

        $originalProfile = $profile;
        $localUpdated = false;

        if (!empty($targets['local'])) {
            $hash = password_hash((string)$newPassword, PASSWORD_DEFAULT);
            if (!is_string($hash) || $hash === '') return array('ok' => false, 'error' => 'Impossible de générer le nouveau mot de passe local.');
            $profile['motdepasse'] = $hash;
            $profile['password'] = $hash;
            if (isset($profile['password_hash'])) unset($profile['password_hash']);
            if (!dmd_write_profile($email, $profile)) {
                return array('ok' => false, 'error' => 'Impossible d’enregistrer le nouveau mot de passe DoMyDesk.');
            }
            $localUpdated = true;
        }

        if (!empty($targets['ad'])) {
            $adResult = dmd_password_reset_ad_password($profile, (string)$newPassword);
            if (empty($adResult['ok'])) {
                // Si le compte est Local + AD, on remet immédiatement l'ancien hash local
                // afin de ne pas laisser deux mots de passe différents après un refus AD.
                $rollbackOk = true;
                if ($localUpdated) $rollbackOk = dmd_write_profile($email, $originalProfile);
                dmd_password_reset_log('password_reset_ad_failed', $email, 'failed', (string)($adResult['error'] ?? 'Échec Active Directory.'), array('targets' => $targets, 'local_rollback_ok' => $rollbackOk));
                if (!$rollbackOk) {
                    return array('ok' => false, 'error' => 'Active Directory a refusé la réinitialisation et DoMyDesk n’a pas pu restaurer automatiquement l’ancien hash local. Intervention administrateur requise.');
                }
                return array('ok' => false, 'error' => (string)($adResult['error'] ?? 'La réinitialisation Active Directory a échoué.'));
            }
        }

        // Consommation du lien uniquement après succès de toutes les sources.
        $fresh = dmd_password_reset_store_read();
        foreach ($fresh['tokens'] as &$stored) {
            if (is_array($stored) && (string)($stored['id'] ?? '') === (string)($record['id'] ?? '')) {
                $stored['used'] = true;
                $stored['used_reason'] = 'success';
                $stored['used_at'] = time();
            }
        }
        unset($stored);
        dmd_password_reset_store_write($fresh);

        if (session_status() === PHP_SESSION_NONE) @session_start();
        $sessionKey = dmd_password_reset_mfa_session_key($record);
        if (isset($_SESSION['dmd_password_reset_mfa'][$sessionKey])) unset($_SESSION['dmd_password_reset_mfa'][$sessionKey]);

        $targetLabel = !empty($targets['local']) && !empty($targets['ad']) ? 'DoMyDesk + Active Directory' : (!empty($targets['ad']) ? 'Active Directory' : 'DoMyDesk local');
        dmd_password_reset_log('password_reset_success', $email, 'success', 'Mot de passe réinitialisé par e-mail.', array('target' => $targetLabel, 'mfa_used' => dmd_mfa_enabled($email)));

        if (function_exists('dmd_notify_user')) {
            dmd_notify_user($email, 'security', 'Votre mot de passe a été réinitialisé', 'Le mot de passe de votre compte a été réinitialisé via la procédure de récupération par e-mail.', array('level' => 'warning'));
        }

        // E-mail de confirmation : son échec ne remet pas en cause le changement déjà effectué.
        $site = dmd_notifications_site_context();
        $instance = trim((string)($site['instance_name'] ?? 'DoMyDesk')) ?: 'DoMyDesk';
        $mailError = '';
        $confirmationBody = "Le mot de passe de votre compte DoMyDesk vient d’être réinitialisé avec succès.\n\n"
            . "Source mise à jour : " . $targetLabel . "\n"
            . "Date : " . date('d/m/Y H:i:s') . "\n\n"
            . "Si vous n’êtes pas à l’origine de cette opération, contactez immédiatement l’administrateur de cette instance.";
        if (!dmd_password_reset_send_mail($email, '[' . $instance . '] Mot de passe réinitialisé', $confirmationBody, $mailError)) {
            dmd_password_reset_log('password_reset_confirmation_mail_failed', $email, 'failed', 'Mot de passe modifié mais e-mail de confirmation non envoyé.', array('mail_error' => $mailError));
        }

        return array('ok' => true, 'targets' => $targets, 'target_label' => $targetLabel);
    }
}
