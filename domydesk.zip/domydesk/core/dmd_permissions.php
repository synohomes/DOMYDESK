<?php
/*
 * DoMyDesk 1.2.0 - Core des profils et autorisations modules.
 * PHP 7.3 compatible.
 */

if (!defined('DMD_ROOT')) {
    define('DMD_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_core_json_read')) {
    function dmd_core_json_read($file, $default = array()) {
        if (!is_file($file)) {
            return $default;
        }

        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') {
            return $default;
        }

        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }
}

if (!function_exists('dmd_core_json_write')) {
    function dmd_core_json_write($file, $data) {
        $dir = dirname($file);

        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        $json = json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        if ($json === false) {
            return false;
        }

        $ok = @file_put_contents($file, $json, LOCK_EX) !== false;

        if ($ok) {
            @chmod($file, 0640);
        }

        return $ok;
    }
}

if (!function_exists('dmd_safe_user_key')) {
    function dmd_safe_user_key($email) {
        $email = trim((string)$email);

        if (
            $email === '' ||
            strpos($email, '..') !== false ||
            strpos($email, '/') !== false ||
            strpos($email, '\\') !== false ||
            basename($email) !== $email
        ) {
            return '';
        }

        return $email;
    }
}

if (!function_exists('dmd_user_dir')) {
    function dmd_user_dir($email) {
        $safe = dmd_safe_user_key($email);
        return $safe === '' ? '' : DMD_ROOT . '/users/profiles/' . $safe . '/';
    }
}

if (!function_exists('dmd_user_private_dir')) {
    function dmd_user_private_dir($email) {
        $dir = dmd_user_dir($email);
        return $dir === '' ? '' : $dir . 'profile/';
    }
}

if (!function_exists('dmd_private_htaccess_content')) {
    function dmd_private_htaccess_content() {
        return "Options -Indexes\n"
            . "<IfModule mod_authz_core.c>\n"
            . "    Require all denied\n"
            . "</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n"
            . "    Order allow,deny\n"
            . "    Deny from all\n"
            . "</IfModule>\n";
    }
}

if (!function_exists('dmd_ensure_private_profile_dir')) {
    function dmd_ensure_private_profile_dir($email) {
        $dir = dmd_user_private_dir($email);

        if ($dir === '') {
            return false;
        }

        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }

        @chmod($dir, 0750);

        $htaccess = $dir . '.htaccess';
        $wanted = dmd_private_htaccess_content();

        if (!is_file($htaccess) || @file_get_contents($htaccess) !== $wanted) {
            @file_put_contents($htaccess, $wanted, LOCK_EX);
            @chmod($htaccess, 0640);
        }

        return true;
    }
}

if (!function_exists('dmd_profile_path')) {
    function dmd_profile_path($email, $migrate = true) {
        $userDir = dmd_user_dir($email);

        if ($userDir === '') {
            return '';
        }

        $privateDir = $userDir . 'profile/';
        $newFile = $privateDir . 'profile.json';
        $legacyFile = $userDir . 'profile.json';

        if (is_file($newFile)) {
            return $newFile;
        }

        if ($migrate && is_file($legacyFile) && dmd_ensure_private_profile_dir($email)) {
            $raw = @file_get_contents($legacyFile);

            if ($raw !== false && @file_put_contents($newFile, $raw, LOCK_EX) !== false) {
                @chmod($newFile, 0640);
                @unlink($legacyFile);
            }
        }

        return $newFile;
    }
}

if (!function_exists('dmd_default_user_modules_acl')) {
    function dmd_default_user_modules_acl() {
        return array(
            'version' => 2,
            'enabled' => array(),
            'overrides' => array(),
        );
    }
}

if (!function_exists('dmd_normalize_permissions')) {
    function dmd_normalize_permissions($permissions) {
        if (!is_array($permissions)) {
            $permissions = array($permissions);
        }

        $out = array();

        foreach ($permissions as $permission) {
            $permission = trim((string)$permission);

            if ($permission === '') {
                continue;
            }

            if (!in_array($permission, $out, true)) {
                $out[] = $permission;
            }
        }

        if (in_array('*', $out, true)) {
            return array('*');
        }

        return $out;
    }
}

if (!function_exists('dmd_migrate_legacy_modules_acl')) {
    function dmd_migrate_legacy_modules_acl($legacy) {
        if (
            is_array($legacy) &&
            isset($legacy['version']) &&
            isset($legacy['enabled']) &&
            isset($legacy['overrides'])
        ) {
            $legacy['version'] = 2;
            $legacy['enabled'] = is_array($legacy['enabled']) ? $legacy['enabled'] : array();
            $legacy['overrides'] = is_array($legacy['overrides']) ? $legacy['overrides'] : array();
            return $legacy;
        }

        $acl = dmd_default_user_modules_acl();

        if (!is_array($legacy)) {
            return $acl;
        }

        foreach ($legacy as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $id = trim((string)($entry['id'] ?? ''));

            if ($id === '') {
                continue;
            }

            $enabled = !empty($entry['enabled']);
            $acl['enabled'][$id] = $enabled;

            /*
             * Compatibilité 1.1.x :
             * un module que l'utilisateur possédait déjà reste autorisé
             * après migration, même avant configuration des rôles métier.
             */
            if ($enabled) {
                $acl['overrides'][$id] = array(
                    'state' => 'allow',
                    'permissions' => array('*'),
                    'migrated_from_1_1' => true,
                );
            }
        }

        return $acl;
    }
}

if (!function_exists('dmd_modules_acl_path')) {
    function dmd_modules_acl_path($email, $migrate = true) {
        $userDir = dmd_user_dir($email);

        if ($userDir === '') {
            return '';
        }

        $privateDir = $userDir . 'profile/';
        $newFile = $privateDir . 'modules.json';
        $legacyFile = $userDir . 'modules.json';

        if (is_file($newFile)) {
            return $newFile;
        }

        if (!$migrate) {
            return $newFile;
        }

        if (!dmd_ensure_private_profile_dir($email)) {
            return $newFile;
        }

        if (is_file($legacyFile)) {
            $legacy = dmd_core_json_read($legacyFile, array());
            $acl = dmd_migrate_legacy_modules_acl($legacy);

            if (dmd_core_json_write($newFile, $acl)) {
                @unlink($legacyFile);
            }
        } else {
            dmd_core_json_write($newFile, dmd_default_user_modules_acl());
        }

        return $newFile;
    }
}

/*
 * Schéma commun des profils DoMyDesk.
 *
 * Les données propres à l'installation (id_client, share_install, consent_at, etc.)
 * ne sont PAS ajoutées aux autres utilisateurs. Elles restent néanmoins conservées
 * lorsqu'elles existent déjà dans un profil (par exemple le compte créé à l'installation).
 */
if (!function_exists('dmd_profile_standard_defaults')) {
    function dmd_profile_standard_defaults($email = '', $createdAt = '') {
        return array(
            'email' => trim((string)$email),
            'prenom' => '',
            'nom' => '',
            'pseudo' => '',
            'role_system' => 'user',
            'role_metier' => '',
            'created_at' => trim((string)$createdAt),
            'auth_source' => 'local',
            'account_status' => 'active',
            'adresse' => '',
            'code_postal' => '',
            'ville' => '',
            'pays' => '',
            'telephone' => '',
            'whatsapp' => '',
            'facebook' => '',
            'groupe_facebook' => '',
            'linkedin' => '',
            'instagram' => '',
            'site_web' => '',
            'entreprise' => '',
            'poste' => '',
            'service' => '',
            'bio' => '',
            'autres_infos' => '',
            'notes_admin' => '',
        );
    }
}

if (!function_exists('dmd_profile_creation_date_from_logs')) {
    function dmd_profile_creation_date_from_logs($email) {
        $email = trim((string)$email);
        if ($email === '') {
            return '';
        }

        $files = glob(DMD_ROOT . '/data/sys_logs/*/*/*.json');
        if (!is_array($files) || !$files) {
            return '';
        }

        rsort($files, SORT_STRING);
        $creationActions = array(
            'user_created',
            'registration_requested',
            'ad_user_imported',
        );

        foreach ($files as $logFile) {
            $rows = dmd_core_json_read($logFile, array());
            if (!is_array($rows) || !$rows) {
                continue;
            }

            for ($i = count($rows) - 1; $i >= 0; $i--) {
                $row = $rows[$i] ?? null;
                if (!is_array($row)) {
                    continue;
                }

                if (strcasecmp(trim((string)($row['target'] ?? '')), $email) !== 0) {
                    continue;
                }

                if (!in_array((string)($row['action'] ?? ''), $creationActions, true)) {
                    continue;
                }

                $dateIso = trim((string)($row['date_iso'] ?? ''));
                if ($dateIso !== '') {
                    /* Conserver l'heure locale écrite dans le journal, sans conversion UTC. */
                    if (preg_match('/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})/', $dateIso, $dateParts)) {
                        return $dateParts[1] . ' ' . $dateParts[2];
                    }
                    $ts = strtotime($dateIso);
                    if ($ts !== false) {
                        return date('Y-m-d H:i:s', $ts);
                    }
                }

                $timestamp = (int)($row['timestamp'] ?? 0);
                if ($timestamp > 0) {
                    return date('Y-m-d H:i:s', $timestamp);
                }
            }
        }

        return '';
    }
}

if (!function_exists('dmd_normalize_profile')) {
    function dmd_normalize_profile($email, $profile, $file = '') {
        if (!is_array($profile)) {
            return array();
        }

        $email = trim((string)$email);
        $createdAt = trim((string)($profile['created_at'] ?? ''));

        if ($createdAt === '') {
            $createdAt = dmd_profile_creation_date_from_logs($email);
        }

        if ($createdAt === '' && $file !== '' && is_file($file)) {
            $mtime = @filemtime($file);
            if ($mtime !== false && $mtime > 0) {
                $createdAt = date('Y-m-d H:i:s', $mtime);
            }
        }

        if ($createdAt === '') {
            $createdAt = date('Y-m-d H:i:s');
        }

        $defaults = dmd_profile_standard_defaults($email, $createdAt);
        $normalized = array_merge($defaults, $profile);

        if (trim((string)($normalized['email'] ?? '')) === '') {
            $normalized['email'] = $email;
        }
        if (trim((string)($normalized['created_at'] ?? '')) === '') {
            $normalized['created_at'] = $createdAt;
        }

        /*
         * Les profils AD existants gardent leur source d'authentification.
         * Pour les anciens profils AD qui n'avaient pas encore auth_source,
         * la présence du bloc ad permet de les reconnaître sans les convertir en local.
         */
        if ((!isset($profile['auth_source']) || trim((string)$profile['auth_source']) === '') && !empty($profile['ad'])) {
            $normalized['auth_source'] = 'active_directory';
        }

        return $normalized;
    }
}

if (!function_exists('dmd_read_profile')) {
    function dmd_read_profile($email) {
        $file = dmd_profile_path($email, true);
        if ($file === '') {
            return array();
        }

        $profile = dmd_core_json_read($file, array());
        if (!is_array($profile) || !$profile) {
            return array();
        }

        $normalized = dmd_normalize_profile($email, $profile, $file);

        /* Migration silencieuse, une seule fois, des anciens profils incomplets. */
        if ($normalized !== $profile) {
            dmd_core_json_write($file, $normalized);
        }

        return $normalized;
    }
}

if (!function_exists('dmd_write_profile')) {
    function dmd_write_profile($email, $profile) {
        if (!is_array($profile)) {
            return false;
        }

        if (!dmd_ensure_private_profile_dir($email)) {
            return false;
        }

        $file = dmd_profile_path($email, false);

        if ($file === '') {
            return false;
        }

        /*
         * Ne jamais perdre la vraie date de création lors d'une mise à jour d'un profil.
         * Si l'ancien profil la possède, elle prévaut sur toute valeur absente du tableau reçu.
         */
        if (is_file($file) && trim((string)($profile['created_at'] ?? '')) === '') {
            $existing = dmd_core_json_read($file, array());
            if (trim((string)($existing['created_at'] ?? '')) !== '') {
                $profile['created_at'] = (string)$existing['created_at'];
            }
        }

        $profile = dmd_normalize_profile($email, $profile, $file);
        $ok = dmd_core_json_write($file, $profile);
        if ($ok) {
            $serviceFile = DMD_ROOT . '/core/dmd_system_services.php';
            if (!function_exists('dmd_notification_index_refresh_user') && is_file($serviceFile)) {
                require_once $serviceFile;
            }
            if (function_exists('dmd_notification_index_refresh_user')) {
                dmd_notification_index_refresh_user($email);
            }
        }
        return $ok;
    }
}

if (!function_exists('dmd_read_user_modules_acl')) {
    function dmd_read_user_modules_acl($email) {
        $file = dmd_modules_acl_path($email, true);

        if ($file === '') {
            return dmd_default_user_modules_acl();
        }

        $acl = dmd_core_json_read($file, dmd_default_user_modules_acl());
        return dmd_migrate_legacy_modules_acl($acl);
    }
}

if (!function_exists('dmd_write_user_modules_acl')) {
    function dmd_write_user_modules_acl($email, $acl) {
        if (!is_array($acl) || !dmd_ensure_private_profile_dir($email)) {
            return false;
        }

        $normalized = dmd_migrate_legacy_modules_acl($acl);
        $file = dmd_modules_acl_path($email, false);

        if ($file === '') {
            return false;
        }

        $ok = dmd_core_json_write($file, $normalized);
        if ($ok) {
            $serviceFile = DMD_ROOT . '/core/dmd_system_services.php';
            if (!function_exists('dmd_notification_index_refresh_user') && is_file($serviceFile)) {
                require_once $serviceFile;
            }
            if (function_exists('dmd_notification_index_refresh_user')) {
                dmd_notification_index_refresh_user($email);
            }
        }
        return $ok;
    }
}

if (!function_exists('dmd_roles_catalog')) {
    function dmd_roles_catalog() {
        $file = DMD_ROOT . '/data/roles_metier.json';
        $raw = dmd_core_json_read($file, array());
        $roles = array();

        foreach ($raw as $key => $value) {
            $name = '';

            if (is_string($value)) {
                $name = trim($value);
            } elseif (is_array($value)) {
                if (!empty($value['name'])) {
                    $name = trim((string)$value['name']);
                } elseif (!empty($value['label'])) {
                    $name = trim((string)$value['label']);
                } elseif (is_string($key)) {
                    $name = trim($key);
                }
            } elseif (is_string($key)) {
                $name = trim($key);
            }

            if ($name !== '' && !in_array($name, $roles, true)) {
                $roles[] = $name;
            }
        }

        sort($roles, SORT_NATURAL | SORT_FLAG_CASE);
        return $roles;
    }
}

if (!function_exists('dmd_roles_modules_file')) {
    function dmd_roles_modules_file() {
        return DMD_ROOT . '/data/secure/roles_modules.json';
    }
}

if (!function_exists('dmd_default_registration_role_from_list')) {
    function dmd_default_registration_role_from_list($roles) {
        foreach ($roles as $role) {
            if (strtoupper((string)$role) === 'USERS') {
                return (string)$role;
            }
        }

        return !empty($roles) ? (string)$roles[0] : '';
    }
}

if (!function_exists('dmd_read_roles_modules')) {
    function dmd_read_roles_modules() {
        $roles = dmd_roles_catalog();
        $file = dmd_roles_modules_file();
        $data = dmd_core_json_read($file, array());
        $changed = false;

        if (!isset($data['version']) || (int)$data['version'] < 2) {
            $data['version'] = 2;
            $changed = true;
        }

        if (!isset($data['roles']) || !is_array($data['roles'])) {
            $data['roles'] = array();
            $changed = true;
        }

        if (!isset($data['module_access']) || !is_array($data['module_access'])) {
            $data['module_access'] = array();
            $changed = true;
        }

        foreach ($roles as $role) {
            if (!isset($data['roles'][$role]) || !is_array($data['roles'][$role])) {
                $data['roles'][$role] = array('modules' => array());
                $changed = true;
            }

            if (!isset($data['roles'][$role]['modules']) || !is_array($data['roles'][$role]['modules'])) {
                $data['roles'][$role]['modules'] = array();
                $changed = true;
            }
        }

        foreach (array_keys($data['roles']) as $roleName) {
            if (!in_array($roleName, $roles, true)) {
                unset($data['roles'][$roleName]);
                $changed = true;
            }
        }

        $installedModules = dmd_installed_modules();

        foreach ($data['module_access'] as $moduleId => $mode) {
            $cleanId = trim((string)$moduleId);
            $cleanMode = strtolower(trim((string)$mode));

            if ($cleanId === '' || !isset($installedModules[$cleanId])) {
                /*
                 * Les règles d'un module absent sont conservées volontairement.
                 * Elles redeviennent actives si le module est réinstallé.
                 */
                continue;
            }

            if (!in_array($cleanMode, array('controlled', 'everyone'), true)) {
                $data['module_access'][$cleanId] = 'controlled';
                $changed = true;
            }
        }

        $defaultRole = trim((string)($data['default_role'] ?? ''));

        if ($defaultRole === '' || !in_array($defaultRole, $roles, true)) {
            $data['default_role'] = dmd_default_registration_role_from_list($roles);
            $changed = true;
        }

        if ($changed || !is_file($file)) {
            dmd_core_json_write($file, $data);
        }

        return $data;
    }
}

if (!function_exists('dmd_write_roles_modules')) {
    function dmd_write_roles_modules($data) {
        if (!is_array($data)) {
            return false;
        }

        $data['version'] = 2;
        return dmd_core_json_write(dmd_roles_modules_file(), $data);
    }
}

if (!function_exists('dmd_default_registration_role')) {
    function dmd_default_registration_role() {
        $data = dmd_read_roles_modules();
        return trim((string)($data['default_role'] ?? ''));
    }
}

if (!function_exists('dmd_set_default_registration_role')) {
    function dmd_set_default_registration_role($role) {
        $role = trim((string)$role);
        $roles = dmd_roles_catalog();

        if ($role === '' || !in_array($role, $roles, true)) {
            return false;
        }

        $data = dmd_read_roles_modules();
        $data['default_role'] = $role;
        return dmd_write_roles_modules($data);
    }
}

if (!function_exists('dmd_module_access_mode')) {
    function dmd_module_access_mode($moduleId) {
        $moduleId = trim((string)$moduleId);

        if ($moduleId === '') {
            return 'controlled';
        }

        $data = dmd_read_roles_modules();

        if (array_key_exists($moduleId, $data['module_access'])) {
            $mode = strtolower(trim((string)$data['module_access'][$moduleId]));

            return in_array($mode, array('controlled', 'everyone'), true)
                ? $mode
                : 'controlled';
        }

        return dmd_module_default_access($moduleId);
    }
}

if (!function_exists('dmd_set_module_access_mode')) {
    function dmd_set_module_access_mode($moduleId, $mode) {
        $moduleId = trim((string)$moduleId);
        $mode = strtolower(trim((string)$mode));
        $installed = dmd_installed_modules();

        if ($moduleId === '' || !isset($installed[$moduleId])) {
            return false;
        }

        if (!in_array($mode, array('controlled', 'everyone'), true)) {
            return false;
        }

        $data = dmd_read_roles_modules();
        $data['module_access'][$moduleId] = $mode;

        return dmd_write_roles_modules($data);
    }
}

if (!function_exists('dmd_set_module_access_modes')) {
    function dmd_set_module_access_modes($modes) {
        if (!is_array($modes)) {
            return false;
        }

        $installed = dmd_installed_modules();
        $data = dmd_read_roles_modules();

        foreach ($installed as $moduleId => $module) {
            $mode = strtolower(trim((string)($modes[$moduleId] ?? 'controlled')));

            if (!in_array($mode, array('controlled', 'everyone'), true)) {
                $mode = 'controlled';
            }

            $data['module_access'][$moduleId] = $mode;
        }

        return dmd_write_roles_modules($data);
    }
}


if (!function_exists('dmd_safe_module_id')) {
    function dmd_safe_module_id($moduleId) {
        $moduleId = trim((string)$moduleId);

        if (
            $moduleId === '' ||
            strpos($moduleId, '..') !== false ||
            strpos($moduleId, '/') !== false ||
            strpos($moduleId, '\\') !== false ||
            basename($moduleId) !== $moduleId ||
            !preg_match('/^[a-zA-Z0-9._-]+$/', $moduleId)
        ) {
            return '';
        }

        return $moduleId;
    }
}

if (!function_exists('dmd_module_manifest')) {
    function dmd_module_manifest($moduleId) {
        static $cache = array();

        $safeId = dmd_safe_module_id($moduleId);

        if ($safeId === '') {
            return array();
        }

        if (array_key_exists($safeId, $cache)) {
            return $cache[$safeId];
        }

        $file = DMD_ROOT . '/modules/' . $safeId . '/dmd_module.json';
        $manifest = dmd_core_json_read($file, array());

        if (empty($manifest) || !is_array($manifest)) {
            $cache[$safeId] = array();
            return $cache[$safeId];
        }

        $manifestId = trim((string)($manifest['id'] ?? ''));

        if ($manifestId !== '' && strcasecmp($manifestId, $safeId) !== 0) {
            $cache[$safeId] = array();
            return $cache[$safeId];
        }

        $scope = strtolower(trim((string)($manifest['storage_scope'] ?? 'legacy')));
        if (!in_array($scope, array('system', 'user', 'hybrid', 'legacy'), true)) {
            $scope = 'legacy';
        }

        $defaultAccess = strtolower(trim((string)($manifest['default_access'] ?? 'controlled')));
        if (!in_array($defaultAccess, array('controlled', 'everyone'), true)) {
            $defaultAccess = 'controlled';
        }

        $manifest['id'] = $safeId;
        $manifest['storage_scope'] = $scope;
        $manifest['default_access'] = $defaultAccess;

        $cache[$safeId] = $manifest;
        return $cache[$safeId];
    }
}


if (!function_exists('dmd_module_display_name')) {
    function dmd_module_display_name($moduleId, $fallback = '') {
        $safeId = dmd_safe_module_id($moduleId);

        if ($safeId === '') {
            return trim((string)$fallback);
        }

        $manifest = dmd_module_manifest($safeId);
        $manifestName = trim((string)($manifest['name'] ?? ''));

        if ($manifestName !== '') {
            return $manifestName;
        }

        $list = dmd_core_json_read(DMD_ROOT . '/modules/list.json', array());

        foreach ($list as $module) {
            if (!is_array($module)) {
                continue;
            }

            if (strcasecmp((string)($module['id'] ?? ''), $safeId) !== 0) {
                continue;
            }

            $listName = trim((string)($module['name'] ?? ''));
            if ($listName !== '') {
                return $listName;
            }
        }

        $fallback = trim((string)$fallback);
        return $fallback !== '' ? $fallback : $safeId;
    }
}

if (!function_exists('dmd_normalize_module_permission_id')) {
    function dmd_normalize_module_permission_id($moduleId, $permission) {
        $moduleId = trim((string)$moduleId);
        $permission = trim((string)$permission);

        if ($permission === '') {
            return '';
        }

        if ($permission === '*') {
            return '*';
        }

        $prefix = $moduleId !== '' ? $moduleId . '.' : '';
        if ($prefix !== '' && stripos($permission, $prefix) === 0) {
            $permission = substr($permission, strlen($prefix));
        }

        if ($permission === 'use') {
            return 'use';
        }

        if (!preg_match('/^[a-zA-Z0-9._:-]+$/', $permission)) {
            return '';
        }

        return $permission;
    }
}

if (!function_exists('dmd_module_permission_definitions')) {
    function dmd_module_permission_definitions($moduleId) {
        static $cache = array();

        $safeId = dmd_safe_module_id($moduleId);
        if ($safeId === '') {
            return array();
        }
        if (array_key_exists($safeId, $cache)) {
            return $cache[$safeId];
        }

        $manifest = dmd_module_manifest($safeId);
        $raw = isset($manifest['permissions']) && is_array($manifest['permissions'])
            ? $manifest['permissions']
            : array();

        $definitions = array();
        $position = 0;

        foreach ($raw as $key => $value) {
            $position++;
            $id = '';
            $label = '';
            $group = 'Actions';
            $description = '';
            $dangerous = false;
            $order = $position;

            if (is_string($value)) {
                if (is_string($key) && !is_numeric($key)) {
                    $id = (string)$key;
                    $label = (string)$value;
                } else {
                    $id = (string)$value;
                    $label = (string)$value;
                }
            } elseif (is_array($value)) {
                $id = trim((string)($value['id'] ?? (is_string($key) ? $key : '')));
                $label = trim((string)($value['label'] ?? $id));
                $group = trim((string)($value['group'] ?? 'Actions'));
                $description = trim((string)($value['description'] ?? ''));
                $dangerous = !empty($value['dangerous']);
                if (isset($value['order']) && is_numeric($value['order'])) {
                    $order = (int)$value['order'];
                }
            } elseif (is_string($key) && !is_numeric($key)) {
                $id = (string)$key;
                $label = (string)$key;
            }

            $id = dmd_normalize_module_permission_id($safeId, $id);
            if ($id === '' || $id === '*' || $id === 'use') {
                continue;
            }

            if ($label === '') {
                $label = $id;
            }
            if ($group === '') {
                $group = 'Actions';
            }

            $definitions[$id] = array(
                'id' => $id,
                'label' => $label,
                'group' => $group,
                'description' => $description,
                'dangerous' => $dangerous,
                'order' => $order,
            );
        }

        uasort($definitions, function ($a, $b) {
            $ga = strtolower((string)($a['group'] ?? ''));
            $gb = strtolower((string)($b['group'] ?? ''));
            if ($ga !== $gb) {
                return strcmp($ga, $gb);
            }
            $oa = (int)($a['order'] ?? 0);
            $ob = (int)($b['order'] ?? 0);
            if ($oa !== $ob) {
                return $oa < $ob ? -1 : 1;
            }
            return strcasecmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
        });

        $cache[$safeId] = $definitions;
        return $cache[$safeId];
    }
}

if (!function_exists('dmd_module_permission_groups')) {
    function dmd_module_permission_groups($moduleId) {
        $groups = array();
        foreach (dmd_module_permission_definitions($moduleId) as $id => $definition) {
            $group = trim((string)($definition['group'] ?? 'Actions'));
            if ($group === '') {
                $group = 'Actions';
            }
            if (!isset($groups[$group])) {
                $groups[$group] = array();
            }
            $groups[$group][$id] = $definition;
        }
        return $groups;
    }
}

if (!function_exists('dmd_filter_known_module_permissions')) {
    function dmd_filter_known_module_permissions($moduleId, $permissions, $allowWildcard = true) {
        $safeId = dmd_safe_module_id($moduleId);
        if ($safeId === '') {
            return array();
        }

        $permissions = dmd_normalize_permissions($permissions);
        if ($allowWildcard && in_array('*', $permissions, true)) {
            return array('*');
        }

        $definitions = dmd_module_permission_definitions($safeId);
        if (empty($definitions)) {
            // Module legacy : on conserve les permissions déclarées pour compatibilité.
            $out = array();
            foreach ($permissions as $permission) {
                $clean = dmd_normalize_module_permission_id($safeId, $permission);
                if ($clean !== '' && $clean !== '*' && $clean !== 'use' && !in_array($clean, $out, true)) {
                    $out[] = $clean;
                }
            }
            return $out;
        }

        $out = array();
        foreach ($permissions as $permission) {
            $clean = dmd_normalize_module_permission_id($safeId, $permission);
            if ($clean !== '' && isset($definitions[$clean]) && !in_array($clean, $out, true)) {
                $out[] = $clean;
            }
        }

        return $out;
    }
}

if (!function_exists('dmd_module_storage_scope')) {
    function dmd_module_storage_scope($moduleId) {
        $safeId = dmd_safe_module_id($moduleId);

        if ($safeId === '') {
            return 'legacy';
        }

        $manifest = dmd_module_manifest($safeId);
        if (!empty($manifest['storage_scope'])) {
            return (string)$manifest['storage_scope'];
        }

        $list = dmd_core_json_read(DMD_ROOT . '/modules/list.json', array());
        foreach ($list as $module) {
            if (!is_array($module) || strcasecmp((string)($module['id'] ?? ''), $safeId) !== 0) {
                continue;
            }

            $scope = strtolower(trim((string)($module['storage_scope'] ?? 'legacy')));
            return in_array($scope, array('system', 'user', 'hybrid', 'legacy'), true)
                ? $scope
                : 'legacy';
        }

        return 'legacy';
    }
}

if (!function_exists('dmd_module_default_access')) {
    function dmd_module_default_access($moduleId) {
        $safeId = dmd_safe_module_id($moduleId);

        if ($safeId === '') {
            return 'controlled';
        }

        $manifest = dmd_module_manifest($safeId);
        if (!empty($manifest['default_access'])) {
            return (string)$manifest['default_access'];
        }

        $list = dmd_core_json_read(DMD_ROOT . '/modules/list.json', array());
        foreach ($list as $module) {
            if (!is_array($module) || strcasecmp((string)($module['id'] ?? ''), $safeId) !== 0) {
                continue;
            }

            $mode = strtolower(trim((string)($module['default_access'] ?? 'controlled')));
            return in_array($mode, array('controlled', 'everyone'), true)
                ? $mode
                : 'controlled';
        }

        return 'controlled';
    }
}

if (!function_exists('dmd_data_htaccess_content')) {
    function dmd_data_htaccess_content() {
        return "Options -Indexes\n"
            . "<IfModule mod_authz_core.c>\n"
            . "    Require all denied\n"
            . "</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n"
            . "    Order allow,deny\n"
            . "    Deny from all\n"
            . "</IfModule>\n";
    }
}

if (!function_exists('dmd_ensure_denied_directory')) {
    function dmd_ensure_denied_directory($dir) {
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        @chmod($dir, 0775);

        $htaccess = rtrim($dir, '/\\') . '/.htaccess';
        $wanted = dmd_data_htaccess_content();

        if (!is_file($htaccess) || @file_get_contents($htaccess) !== $wanted) {
            @file_put_contents($htaccess, $wanted, LOCK_EX);
            @chmod($htaccess, 0640);
        }

        return true;
    }
}

if (!function_exists('dmd_module_system_data_dir')) {
    function dmd_module_system_data_dir($moduleId, $create = true) {
        $safeId = dmd_safe_module_id($moduleId);

        if ($safeId === '') {
            return '';
        }

        $root = DMD_ROOT . '/data/modules/';
        $dir = $root . $safeId . '/';

        if ($create) {
            if (!dmd_ensure_denied_directory($root)) {
                return '';
            }

            if (!dmd_ensure_denied_directory($dir)) {
                return '';
            }
        }

        return $dir;
    }
}

if (!function_exists('dmd_user_module_data_dir')) {
    function dmd_user_module_data_dir($email, $moduleId, $create = true) {
        $userDir = dmd_user_dir($email);
        $safeId = dmd_safe_module_id($moduleId);

        if ($userDir === '' || $safeId === '') {
            return '';
        }

        $dir = $userDir . $safeId . '/';

        if ($create && !dmd_ensure_denied_directory($dir)) {
            return '';
        }

        return $dir;
    }
}

if (!function_exists('dmd_installed_modules')) {
    function dmd_installed_modules() {
        $list = dmd_core_json_read(DMD_ROOT . '/modules/list.json', array());
        $out = array();

        foreach ($list as $module) {
            if (!is_array($module)) {
                continue;
            }

            $id = dmd_safe_module_id($module['id'] ?? '');

            if ($id === '') {
                continue;
            }

            $manifest = dmd_module_manifest($id);

            if (!empty($manifest)) {
                foreach (array('name', 'description', 'storage_scope', 'default_access') as $key) {
                    if (isset($manifest[$key]) && trim((string)$manifest[$key]) !== '') {
                        $module[$key] = $manifest[$key];
                    }
                }
            }

            $module['name'] = dmd_module_display_name(
                $id,
                isset($module['name']) ? (string)$module['name'] : $id
            );

            if (empty($module['storage_scope'])) {
                $module['storage_scope'] = 'legacy';
            }

            if (empty($module['default_access'])) {
                $module['default_access'] = 'controlled';
            }

            $out[$id] = $module;
        }

        uasort($out, function ($a, $b) {
            return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        });

        return $out;
    }
}

if (!function_exists('dmd_set_role_module_rules')) {
    function dmd_set_role_module_rules($role, $moduleRules) {
        $role = trim((string)$role);
        $roles = dmd_roles_catalog();

        if ($role === '' || !in_array($role, $roles, true)) {
            return false;
        }

        if (!is_array($moduleRules)) {
            $moduleRules = array();
        }

        $installed = dmd_installed_modules();
        $modules = array();

        foreach ($moduleRules as $id => $rule) {
            $id = trim((string)$id);
            if ($id === '' || !isset($installed[$id])) {
                continue;
            }

            if (!is_array($rule)) {
                $rule = array('enabled' => !empty($rule), 'permissions' => array('*'));
            }

            $enabled = !empty($rule['enabled']);
            if (!$enabled) {
                continue;
            }

            $definitions = dmd_module_permission_definitions($id);
            $permissions = dmd_normalize_permissions($rule['permissions'] ?? array());

            if (in_array('*', $permissions, true)) {
                $permissions = array('*');
            } elseif (!empty($definitions)) {
                $permissions = dmd_filter_known_module_permissions($id, $permissions, false);
            } elseif (empty($permissions)) {
                // Un module ancien sans catalogue de droits garde le comportement historique.
                $permissions = array('*');
            }

            $modules[$id] = array(
                'enabled' => true,
                'permissions' => $permissions,
            );
        }

        $data = dmd_read_roles_modules();
        if (!isset($data['roles'][$role]) || !is_array($data['roles'][$role])) {
            $data['roles'][$role] = array();
        }
        $data['roles'][$role]['modules'] = $modules;

        return dmd_write_roles_modules($data);
    }
}

if (!function_exists('dmd_set_role_modules')) {
    function dmd_set_role_modules($role, $moduleIds) {
        if (!is_array($moduleIds)) {
            $moduleIds = array();
        }

        $rules = array();
        foreach ($moduleIds as $id) {
            $id = trim((string)$id);
            if ($id !== '') {
                $rules[$id] = array('enabled' => true, 'permissions' => array('*'));
            }
        }

        return dmd_set_role_module_rules($role, $rules);
    }
}

if (!function_exists('dmd_role_module_rule')) {
    function dmd_role_module_rule($role, $moduleId) {
        $role = trim((string)$role);
        $moduleId = trim((string)$moduleId);
        $data = dmd_read_roles_modules();

        if (
            $role === '' ||
            $moduleId === '' ||
            empty($data['roles'][$role]['modules'][$moduleId]) ||
            !is_array($data['roles'][$role]['modules'][$moduleId])
        ) {
            return array(
                'enabled' => false,
                'permissions' => array(),
            );
        }

        $rule = $data['roles'][$role]['modules'][$moduleId];
        $rule['enabled'] = !empty($rule['enabled']);
        $rule['permissions'] = dmd_normalize_permissions($rule['permissions'] ?? array());

        if ($rule['enabled'] && empty($rule['permissions']) && empty(dmd_module_permission_definitions($moduleId))) {
            $rule['permissions'] = array('*');
        }

        return $rule;
    }
}

if (!function_exists('dmd_is_system_admin_profile')) {
    function dmd_is_system_admin_profile($profile) {
        if (!is_array($profile)) {
            return false;
        }

        return in_array(
            strtolower((string)($profile['role_system'] ?? 'user')),
            array('admin', 'superadmin'),
            true
        );
    }
}

if (!function_exists('dmd_effective_module_access')) {
    function dmd_effective_module_access($email, $moduleId) {
        $moduleId = trim((string)$moduleId);
        $profile = dmd_read_profile($email);

        $result = array(
            'allowed' => false,
            'permissions' => array(),
            'source' => 'none',
            'role_metier' => trim((string)($profile['role_metier'] ?? '')),
            'override' => 'inherit',
        );

        if ($moduleId === '' || empty($profile)) {
            return $result;
        }

        if (dmd_is_system_admin_profile($profile)) {
            $result['allowed'] = true;
            $result['permissions'] = array('*');
            $result['source'] = 'system_admin';
            return $result;
        }

        $accessMode = dmd_module_access_mode($moduleId);

        if ($accessMode === 'everyone') {
            $result['allowed'] = true;
            $result['permissions'] = array('*');
            $result['source'] = 'everyone';
        } else {
            $role = $result['role_metier'];
            $roleRule = dmd_role_module_rule($role, $moduleId);

            if (!empty($roleRule['enabled'])) {
                $result['allowed'] = true;
                $result['permissions'] = dmd_normalize_permissions($roleRule['permissions']);
                $result['source'] = 'role';
            }
        }

        $acl = dmd_read_user_modules_acl($email);
        $override = $acl['overrides'][$moduleId] ?? array();

        if (is_array($override)) {
            $state = strtolower(trim((string)($override['state'] ?? 'inherit')));

            if (!in_array($state, array('inherit', 'allow', 'deny'), true)) {
                $state = 'inherit';
            }

            $result['override'] = $state;

            if ($state === 'allow') {
                $result['allowed'] = true;
                $permissions = dmd_normalize_permissions($override['permissions'] ?? array('*'));
                $result['permissions'] = empty($permissions) ? array('*') : $permissions;
                $result['source'] = 'user_allow';
            } elseif ($state === 'deny') {
                $result['allowed'] = false;
                $result['permissions'] = array();
                $result['source'] = 'user_deny';
            }
        }

        return $result;
    }
}

if (!function_exists('dmd_user_can_use_module')) {
    function dmd_user_can_use_module($email, $moduleId) {
        $access = dmd_effective_module_access($email, $moduleId);
        return !empty($access['allowed']);
    }
}

if (!function_exists('dmd_user_has_module_permission')) {
    function dmd_user_has_module_permission($email, $moduleId, $permission = 'use') {
        $access = dmd_effective_module_access($email, $moduleId);

        if (empty($access['allowed'])) {
            return false;
        }

        $permission = dmd_normalize_module_permission_id($moduleId, $permission);

        if ($permission === '' || $permission === 'use') {
            return true;
        }

        $permissions = dmd_normalize_permissions($access['permissions'] ?? array());

        return in_array('*', $permissions, true) || in_array($permission, $permissions, true);
    }
}

if (!function_exists('dmd_current_user_has_module_permission')) {
    function dmd_current_user_has_module_permission($moduleId, $permission = 'use') {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $email = $_SESSION['user']['email'] ?? '';
        return $email !== '' && dmd_user_has_module_permission($email, $moduleId, $permission);
    }
}

if (!function_exists('dmd_require_module_access')) {
    function dmd_require_module_access($moduleId, $permission = 'use') {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $email = $_SESSION['user']['email'] ?? '';

        if ($email === '' || !dmd_user_has_module_permission($email, $moduleId, $permission)) {
            http_response_code(403);
            exit('Accès refusé à ce module.');
        }
    }
}

if (!function_exists('dmd_user_module_is_enabled')) {
    function dmd_user_module_is_enabled($email, $moduleId) {
        if (!dmd_user_can_use_module($email, $moduleId)) {
            return false;
        }

        $acl = dmd_read_user_modules_acl($email);

        if (array_key_exists($moduleId, $acl['enabled'])) {
            return (bool)$acl['enabled'][$moduleId];
        }

        /*
         * Autorisation != activation.
         * Un module nouvellement autorisé apparaît dans le listing Modules,
         * mais l'utilisateur doit l'activer lui-même pour l'ajouter à son espace.
         * Les anciens états 1.1.x restent conservés dans enabled lors de la migration.
         */
        return false;
    }
}

if (!function_exists('dmd_set_user_module_enabled')) {
    function dmd_set_user_module_enabled($email, $moduleId, $enabled) {
        $moduleId = trim((string)$moduleId);

        if ($moduleId === '' || !dmd_user_can_use_module($email, $moduleId)) {
            return false;
        }

        $acl = dmd_read_user_modules_acl($email);
        $acl['enabled'][$moduleId] = (bool)$enabled;

        return dmd_write_user_modules_acl($email, $acl);
    }
}

if (!function_exists('dmd_set_user_module_override')) {
    function dmd_set_user_module_override($email, $moduleId, $state, $permissions = array('*')) {
        $moduleId = trim((string)$moduleId);
        $state = strtolower(trim((string)$state));

        if ($moduleId === '' || !in_array($state, array('inherit', 'allow', 'deny'), true)) {
            return false;
        }

        $acl = dmd_read_user_modules_acl($email);

        if ($state === 'inherit') {
            unset($acl['overrides'][$moduleId]);
        } else {
            $acl['overrides'][$moduleId] = array(
                'state' => $state,
                'permissions' => $state === 'allow'
                    ? dmd_normalize_permissions($permissions)
                    : array(),
            );

            if ($state === 'allow' && empty($acl['overrides'][$moduleId]['permissions'])) {
                $acl['overrides'][$moduleId]['permissions'] = array('*');
            }
        }

        return dmd_write_user_modules_acl($email, $acl);
    }
}

if (!function_exists('dmd_replace_user_module_overrides_detailed')) {
    function dmd_replace_user_module_overrides_detailed($email, $rules) {
        if (!is_array($rules)) {
            $rules = array();
        }

        $installed = dmd_installed_modules();
        $acl = dmd_read_user_modules_acl($email);
        $newOverrides = array();

        foreach ($installed as $id => $module) {
            $rule = isset($rules[$id]) && is_array($rules[$id]) ? $rules[$id] : array();
            $state = strtolower(trim((string)($rule['state'] ?? 'inherit')));
            if (!in_array($state, array('inherit', 'allow', 'deny'), true) || $state === 'inherit') {
                continue;
            }

            if ($state === 'deny') {
                $newOverrides[$id] = array(
                    'state' => 'deny',
                    'permissions' => array(),
                );
                continue;
            }

            $definitions = dmd_module_permission_definitions($id);
            $permissions = dmd_normalize_permissions($rule['permissions'] ?? array());
            if (in_array('*', $permissions, true)) {
                $permissions = array('*');
            } elseif (!empty($definitions)) {
                $permissions = dmd_filter_known_module_permissions($id, $permissions, false);
            } elseif (empty($permissions)) {
                $permissions = array('*');
            }

            $newOverrides[$id] = array(
                'state' => 'allow',
                'permissions' => $permissions,
            );
        }

        $acl['overrides'] = $newOverrides;
        return dmd_write_user_modules_acl($email, $acl);
    }
}

if (!function_exists('dmd_replace_user_module_overrides')) {
    function dmd_replace_user_module_overrides($email, $states) {
        if (!is_array($states)) {
            $states = array();
        }

        $installed = dmd_installed_modules();
        $acl = dmd_read_user_modules_acl($email);
        $newOverrides = array();

        foreach ($installed as $id => $module) {
            $state = strtolower(trim((string)($states[$id] ?? 'inherit')));

            if ($state === 'allow') {
                $newOverrides[$id] = array(
                    'state' => 'allow',
                    'permissions' => array('*'),
                );
            } elseif ($state === 'deny') {
                $newOverrides[$id] = array(
                    'state' => 'deny',
                    'permissions' => array(),
                );
            }
        }

        /*
         * Conserve les règles de modules temporairement absents du catalogue.
         * Elles pourront redevenir actives après réinstallation du module.
         */
        foreach ($acl['overrides'] as $id => $rule) {
            if (!isset($installed[$id])) {
                $newOverrides[$id] = $rule;
            }
        }

        $acl['overrides'] = $newOverrides;

        return dmd_write_user_modules_acl($email, $acl);
    }
}

if (!function_exists('dmd_user_module_matrix')) {
    function dmd_user_module_matrix($email) {
        $installed = dmd_installed_modules();
        $profile = dmd_read_profile($email);
        $role = trim((string)($profile['role_metier'] ?? ''));
        $acl = dmd_read_user_modules_acl($email);
        $matrix = array();

        foreach ($installed as $id => $module) {
            $roleRule = dmd_role_module_rule($role, $id);
            $effective = dmd_effective_module_access($email, $id);
            $override = 'inherit';

            if (!empty($acl['overrides'][$id]) && is_array($acl['overrides'][$id])) {
                $candidate = strtolower(trim((string)($acl['overrides'][$id]['state'] ?? 'inherit')));

                if (in_array($candidate, array('inherit', 'allow', 'deny'), true)) {
                    $override = $candidate;
                }
            }

            $matrix[$id] = array(
                'id' => $id,
                'name' => (string)($module['name'] ?? $id),
                'description' => (string)($module['description'] ?? ''),
                'access_mode' => dmd_module_access_mode($id),
                'role_allowed' => !empty($roleRule['enabled']),
                'override' => $override,
                'effective' => !empty($effective['allowed']),
                'source' => (string)($effective['source'] ?? 'none'),
                'enabled' => dmd_user_module_is_enabled($email, $id),
                'permissions' => $effective['permissions'] ?? array(),
            );
        }

        return $matrix;
    }
}

if (!function_exists('dmd_effective_modules')) {
    function dmd_effective_modules($email, $respectEnabled = true) {
        $installed = dmd_installed_modules();
        $result = array();

        foreach ($installed as $id => $module) {
            $access = dmd_effective_module_access($email, $id);

            if (empty($access['allowed'])) {
                continue;
            }

            $enabled = dmd_user_module_is_enabled($email, $id);

            if ($respectEnabled && !$enabled) {
                continue;
            }

            $module['_enabled'] = $enabled;
            $module['_access_source'] = $access['source'];
            $module['_permissions'] = $access['permissions'];
            $result[$id] = $module;
        }

        return $result;
    }
}

/* ==========================================================
   Pages du Core : catalogue, rôles et exceptions utilisateurs
   ========================================================== */

if (!function_exists('dmd_pages_catalog_file')) {
    function dmd_pages_catalog_file() {
        return DMD_ROOT . '/data/pages_catalog.json';
    }
}

if (!function_exists('dmd_page_catalog')) {
    function dmd_page_catalog() {
        $data = dmd_core_json_read(dmd_pages_catalog_file(), array());
        $rawPages = isset($data['pages']) && is_array($data['pages']) ? $data['pages'] : array();
        $pages = array();

        foreach ($rawPages as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $id = strtolower(trim((string)($entry['id'] ?? '')));
            $path = str_replace('\\', '/', ltrim(trim((string)($entry['path'] ?? '')), '/'));
            $label = trim((string)($entry['label'] ?? $id));
            $description = trim((string)($entry['description'] ?? ''));
            $access = strtolower(trim((string)($entry['access'] ?? 'controlled')));
            $defaultAccess = strtolower(trim((string)($entry['default_access'] ?? 'controlled')));

            if (
                $id === '' ||
                !preg_match('/^[a-z0-9._-]+$/', $id) ||
                $path === '' ||
                strpos($path, '..') !== false ||
                substr($path, -4) !== '.php'
            ) {
                continue;
            }

            if (!in_array($access, array('always', 'controlled'), true)) {
                $access = 'controlled';
            }

            if (!in_array($defaultAccess, array('controlled', 'everyone'), true)) {
                $defaultAccess = 'controlled';
            }

            $pages[$id] = array(
                'id' => $id,
                'label' => $label !== '' ? $label : $id,
                'path' => $path,
                'description' => $description,
                'access' => $access,
                'default_access' => $access === 'always' ? 'always' : $defaultAccess,
            );
        }

        return $pages;
    }
}

if (!function_exists('dmd_page_id_from_link')) {
    function dmd_page_id_from_link($link) {
        $link = trim((string)$link);

        if ($link === '' || preg_match('#^https?://#i', $link)) {
            return '';
        }

        $path = parse_url($link, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            $path = $link;
        }

        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path);
        $path = ltrim((string)$path, '/');

        foreach (dmd_page_catalog() as $id => $page) {
            $candidate = ltrim((string)$page['path'], '/');

            if ($path === $candidate) {
                return $id;
            }

            $suffix = '/' . $candidate;
            if (strlen($path) >= strlen($suffix) && substr($path, -strlen($suffix)) === $suffix) {
                return $id;
            }
        }

        return '';
    }
}

if (!function_exists('dmd_pages_access_file')) {
    function dmd_pages_access_file() {
        return DMD_ROOT . '/data/secure/pages_access.json';
    }
}

if (!function_exists('dmd_read_pages_access')) {
    function dmd_read_pages_access() {
        $roles = dmd_roles_catalog();
        $catalog = dmd_page_catalog();
        $file = dmd_pages_access_file();
        $data = dmd_core_json_read($file, array());
        $changed = false;

        if (!isset($data['version'])) {
            $data['version'] = 1;
            $changed = true;
        }

        if (!isset($data['page_access']) || !is_array($data['page_access'])) {
            $data['page_access'] = array();
            $changed = true;
        }

        if (!isset($data['roles']) || !is_array($data['roles'])) {
            $data['roles'] = array();
            $changed = true;
        }

        foreach ($catalog as $pageId => $page) {
            if (($page['access'] ?? 'controlled') !== 'controlled') {
                continue;
            }

            $mode = strtolower(trim((string)($data['page_access'][$pageId] ?? '')));
            if (!in_array($mode, array('controlled', 'everyone'), true)) {
                $data['page_access'][$pageId] = ($page['default_access'] ?? 'controlled') === 'everyone'
                    ? 'everyone'
                    : 'controlled';
                $changed = true;
            }
        }

        foreach ($roles as $role) {
            if (!isset($data['roles'][$role]) || !is_array($data['roles'][$role])) {
                $data['roles'][$role] = array('pages' => array());
                $changed = true;
            }

            if (!isset($data['roles'][$role]['pages']) || !is_array($data['roles'][$role]['pages'])) {
                $data['roles'][$role]['pages'] = array();
                $changed = true;
            }
        }

        foreach (array_keys($data['roles']) as $roleName) {
            if (!in_array($roleName, $roles, true)) {
                unset($data['roles'][$roleName]);
                $changed = true;
            }
        }

        if ($changed || !is_file($file)) {
            dmd_core_json_write($file, $data);
        }

        return $data;
    }
}

if (!function_exists('dmd_write_pages_access')) {
    function dmd_write_pages_access($data) {
        if (!is_array($data)) {
            return false;
        }

        $data['version'] = 1;
        return dmd_core_json_write(dmd_pages_access_file(), $data);
    }
}

if (!function_exists('dmd_page_access_mode')) {
    function dmd_page_access_mode($pageId) {
        $catalog = dmd_page_catalog();

        if (!isset($catalog[$pageId])) {
            return 'unknown';
        }

        if (($catalog[$pageId]['access'] ?? 'controlled') === 'always') {
            return 'always';
        }

        $data = dmd_read_pages_access();
        $mode = strtolower(trim((string)($data['page_access'][$pageId] ?? 'controlled')));

        return in_array($mode, array('controlled', 'everyone'), true) ? $mode : 'controlled';
    }
}

if (!function_exists('dmd_set_page_access_modes')) {
    function dmd_set_page_access_modes($modes) {
        if (!is_array($modes)) {
            $modes = array();
        }

        $catalog = dmd_page_catalog();
        $data = dmd_read_pages_access();

        foreach ($catalog as $pageId => $page) {
            if (($page['access'] ?? 'controlled') !== 'controlled') {
                continue;
            }

            $mode = strtolower(trim((string)($modes[$pageId] ?? 'controlled')));
            if (!in_array($mode, array('controlled', 'everyone'), true)) {
                $mode = 'controlled';
            }

            $data['page_access'][$pageId] = $mode;
        }

        return dmd_write_pages_access($data);
    }
}

if (!function_exists('dmd_set_role_pages')) {
    function dmd_set_role_pages($role, $pageIds) {
        $role = trim((string)$role);
        $roles = dmd_roles_catalog();

        if ($role === '' || !in_array($role, $roles, true)) {
            return false;
        }

        if (!is_array($pageIds)) {
            $pageIds = array();
        }

        $catalog = dmd_page_catalog();
        $data = dmd_read_pages_access();
        $rules = array();

        foreach ($pageIds as $pageId) {
            $pageId = strtolower(trim((string)$pageId));

            if (
                isset($catalog[$pageId]) &&
                ($catalog[$pageId]['access'] ?? 'controlled') === 'controlled'
            ) {
                $rules[$pageId] = array('enabled' => true);
            }
        }

        $data['roles'][$role]['pages'] = $rules;
        return dmd_write_pages_access($data);
    }
}

if (!function_exists('dmd_role_page_rule')) {
    function dmd_role_page_rule($role, $pageId) {
        $data = dmd_read_pages_access();
        $rule = $data['roles'][$role]['pages'][$pageId] ?? array();

        return array(
            'enabled' => !empty($rule['enabled']),
        );
    }
}

if (!function_exists('dmd_default_user_pages_acl')) {
    function dmd_default_user_pages_acl() {
        return array(
            'version' => 1,
            'overrides' => array(),
        );
    }
}

if (!function_exists('dmd_pages_acl_path')) {
    function dmd_pages_acl_path($email, $migrate = true) {
        $userDir = dmd_user_dir($email);

        if ($userDir === '') {
            return '';
        }

        $privateDir = $userDir . 'profile/';
        $newFile = $privateDir . 'pages.json';
        $legacyFile = $userDir . 'pages.json';

        if (is_file($newFile)) {
            return $newFile;
        }

        if (!dmd_ensure_private_profile_dir($email)) {
            return $newFile;
        }

        $acl = dmd_default_user_pages_acl();

        if ($migrate && is_file($legacyFile)) {
            $legacy = dmd_core_json_read($legacyFile, array());

            if (isset($legacy['version']) && isset($legacy['overrides']) && is_array($legacy['overrides'])) {
                $acl = $legacy;
                $acl['version'] = 1;
            } elseif (is_array($legacy)) {
                foreach ($legacy as $legacyPath) {
                    if (!is_string($legacyPath)) {
                        continue;
                    }

                    $pageId = dmd_page_id_from_link($legacyPath);
                    $catalog = dmd_page_catalog();

                    if (
                        $pageId !== '' &&
                        isset($catalog[$pageId]) &&
                        ($catalog[$pageId]['access'] ?? 'controlled') === 'controlled'
                    ) {
                        $acl['overrides'][$pageId] = array('state' => 'allow');
                    }
                }
            }
        }

        if (dmd_core_json_write($newFile, $acl)) {
            @chmod($newFile, 0640);

            if ($migrate && is_file($legacyFile)) {
                @unlink($legacyFile);
            }
        }

        return $newFile;
    }
}

if (!function_exists('dmd_read_user_pages_acl')) {
    function dmd_read_user_pages_acl($email) {
        $path = dmd_pages_acl_path($email, true);
        $acl = dmd_core_json_read($path, dmd_default_user_pages_acl());

        if (!isset($acl['overrides']) || !is_array($acl['overrides'])) {
            $acl['overrides'] = array();
        }

        $acl['version'] = 1;
        return $acl;
    }
}

if (!function_exists('dmd_write_user_pages_acl')) {
    function dmd_write_user_pages_acl($email, $acl) {
        if (!is_array($acl) || !dmd_ensure_private_profile_dir($email)) {
            return false;
        }

        if (!isset($acl['overrides']) || !is_array($acl['overrides'])) {
            $acl['overrides'] = array();
        }

        $acl['version'] = 1;
        return dmd_core_json_write(dmd_pages_acl_path($email, false), $acl);
    }
}

if (!function_exists('dmd_effective_page_access')) {
    function dmd_effective_page_access($email, $pageIdOrLink) {
        $catalog = dmd_page_catalog();
        $pageId = isset($catalog[$pageIdOrLink]) ? $pageIdOrLink : dmd_page_id_from_link($pageIdOrLink);
        $result = array(
            'page_id' => $pageId,
            'allowed' => false,
            'source' => 'unknown',
            'override' => 'inherit',
        );

        if ($pageId === '' || !isset($catalog[$pageId])) {
            return $result;
        }

        $profile = dmd_read_profile($email);

        if (dmd_is_system_admin_profile($profile)) {
            $result['allowed'] = true;
            $result['source'] = 'admin';
            return $result;
        }

        if (($catalog[$pageId]['access'] ?? 'controlled') === 'always') {
            $result['allowed'] = true;
            $result['source'] = 'always';
            return $result;
        }

        $acl = dmd_read_user_pages_acl($email);
        $override = $acl['overrides'][$pageId] ?? array();
        $state = is_array($override)
            ? strtolower(trim((string)($override['state'] ?? 'inherit')))
            : 'inherit';

        if (!in_array($state, array('inherit', 'allow', 'deny'), true)) {
            $state = 'inherit';
        }

        $result['override'] = $state;

        if ($state === 'deny') {
            $result['allowed'] = false;
            $result['source'] = 'user_deny';
            return $result;
        }

        if ($state === 'allow') {
            $result['allowed'] = true;
            $result['source'] = 'user_allow';
            return $result;
        }

        if (dmd_page_access_mode($pageId) === 'everyone') {
            $result['allowed'] = true;
            $result['source'] = 'everyone';
            return $result;
        }

        $role = trim((string)($profile['role_metier'] ?? ''));
        $roleRule = dmd_role_page_rule($role, $pageId);

        if (!empty($roleRule['enabled'])) {
            $result['allowed'] = true;
            $result['source'] = 'role';
            return $result;
        }

        $result['source'] = 'none';
        return $result;
    }
}

if (!function_exists('dmd_user_can_access_page')) {
    function dmd_user_can_access_page($email, $pageIdOrLink) {
        $access = dmd_effective_page_access($email, $pageIdOrLink);
        return !empty($access['allowed']);
    }
}

if (!function_exists('dmd_require_page_access')) {
    function dmd_require_page_access($pageIdOrLink) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $email = $_SESSION['user']['email'] ?? '';

        if ($email === '' || !dmd_user_can_access_page($email, $pageIdOrLink)) {
            http_response_code(403);
            exit('Accès refusé à cette page.');
        }
    }
}

if (!function_exists('dmd_replace_user_page_overrides')) {
    function dmd_replace_user_page_overrides($email, $states) {
        if (!is_array($states)) {
            $states = array();
        }

        $catalog = dmd_page_catalog();
        $acl = dmd_read_user_pages_acl($email);
        $newOverrides = array();

        foreach ($catalog as $pageId => $page) {
            if (($page['access'] ?? 'controlled') !== 'controlled') {
                continue;
            }

            $state = strtolower(trim((string)($states[$pageId] ?? 'inherit')));

            if ($state === 'allow') {
                $newOverrides[$pageId] = array('state' => 'allow');
            } elseif ($state === 'deny') {
                $newOverrides[$pageId] = array('state' => 'deny');
            }
        }

        $acl['overrides'] = $newOverrides;
        return dmd_write_user_pages_acl($email, $acl);
    }
}

if (!function_exists('dmd_user_available_pages')) {
    function dmd_user_available_pages($email) {
        $catalog = dmd_page_catalog();
        $result = array();

        foreach ($catalog as $pageId => $page) {
            if (dmd_user_can_access_page($email, $pageId)) {
                $page['_access'] = dmd_effective_page_access($email, $pageId);
                $result[$pageId] = $page;
            }
        }

        return $result;
    }
}

if (!function_exists('dmd_user_page_matrix')) {
    function dmd_user_page_matrix($email) {
        $catalog = dmd_page_catalog();
        $profile = dmd_read_profile($email);
        $role = trim((string)($profile['role_metier'] ?? ''));
        $acl = dmd_read_user_pages_acl($email);
        $matrix = array();

        foreach ($catalog as $pageId => $page) {
            $roleRule = dmd_role_page_rule($role, $pageId);
            $effective = dmd_effective_page_access($email, $pageId);
            $override = 'inherit';

            if (!empty($acl['overrides'][$pageId]) && is_array($acl['overrides'][$pageId])) {
                $candidate = strtolower(trim((string)($acl['overrides'][$pageId]['state'] ?? 'inherit')));
                if (in_array($candidate, array('inherit', 'allow', 'deny'), true)) {
                    $override = $candidate;
                }
            }

            $matrix[$pageId] = array(
                'id' => $pageId,
                'label' => (string)($page['label'] ?? $pageId),
                'description' => (string)($page['description'] ?? ''),
                'path' => (string)($page['path'] ?? ''),
                'access' => (string)($page['access'] ?? 'controlled'),
                'access_mode' => dmd_page_access_mode($pageId),
                'role_allowed' => !empty($roleRule['enabled']),
                'override' => $override,
                'effective' => !empty($effective['allowed']),
                'source' => (string)($effective['source'] ?? 'none'),
            );
        }

        return $matrix;
    }
}

if (!function_exists('dmd_migrate_user_security_files')) {
    function dmd_migrate_user_security_files($email) {
        $safe = dmd_safe_user_key($email);

        if ($safe === '' || !is_dir(dmd_user_dir($safe))) {
            return false;
        }

        dmd_ensure_private_profile_dir($safe);
        $profilePath = dmd_profile_path($safe, true);
        $modulesPath = dmd_modules_acl_path($safe, true);
        $pagesPath = dmd_pages_acl_path($safe, true);

        return is_file($profilePath) && is_file($modulesPath) && is_file($pagesPath);
    }
}

if (!function_exists('dmd_migrate_all_user_security_files')) {
    function dmd_migrate_all_user_security_files() {
        $profilesDir = DMD_ROOT . '/users/profiles/';
        $result = array(
            'total' => 0,
            'migrated' => 0,
            'failed' => array(),
        );

        if (!is_dir($profilesDir)) {
            return $result;
        }

        foreach (glob($profilesDir . '*', GLOB_ONLYDIR) ?: array() as $dir) {
            $email = basename($dir);
            $result['total']++;

            if (dmd_migrate_user_security_files($email)) {
                $result['migrated']++;
            } else {
                $result['failed'][] = $email;
            }
        }

        dmd_read_roles_modules();
        dmd_read_pages_access();

        return $result;
    }
}

if (!function_exists('dmd_is_protected_user_relative_path')) {
    function dmd_is_protected_user_relative_path($relativePath) {
        $path = str_replace('\\', '/', ltrim((string)$relativePath, '/'));
        $path = preg_replace('#/+#', '/', $path);

        return $path === 'profile'
            || strpos($path, 'profile/') === 0
            || basename($path) === 'profile.json'
            || basename($path) === 'modules.json'
            || basename($path) === 'pages.json';
    }
}

/*
 * Garde d'accès MFA globale.
 * Toutes les pages/modules qui passent par le Core des permissions héritent
 * automatiquement de la politique MFA centrale.
 */
if (empty($GLOBALS['dmd_mfa_bootstrapping'])) {
    $dmdMfaCore = __DIR__ . '/dmd_mfa.php';
    if (is_file($dmdMfaCore)) {
        require_once $dmdMfaCore;
    }
    if (function_exists('dmd_mfa_enforce_access_policy')) {
        dmd_mfa_enforce_access_policy();
    }
}
?>
