<?php
/*
 * DoMyDesk 1.2.0 - Installation de composants non officiels.
 * Aucune validation fonctionnelle du module/theme n'est effectuee ici.
 * Seules les protections de chemin ZIP et d'ecriture hors cible sont appliquees.
 * PHP 7.3 compatible.
 */

if (!defined('DMD_ROOT')) {
    define('DMD_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_unofficial_safe_slug')) {
    function dmd_unofficial_safe_slug($value) {
        $value = trim((string)$value);
        $value = preg_replace('~\.zip$~i', '', $value);
        $value = preg_replace('~[^a-zA-Z0-9._-]+~', '-', $value);
        return trim($value, '-.');
    }
}

if (!function_exists('dmd_unofficial_json_read')) {
    function dmd_unofficial_json_read($file, $default = array()) {
        if (!is_file($file)) {
            return $default;
        }
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') {
            return $default;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }
}

if (!function_exists('dmd_unofficial_json_write')) {
    function dmd_unofficial_json_write($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }
        $ok = @file_put_contents($file, $json, LOCK_EX) !== false;
        if ($ok) {
            @chmod($file, 0664);
        }
        return $ok;
    }
}

if (!function_exists('dmd_unofficial_remove_dir')) {
    function dmd_unofficial_remove_dir($dir) {
        if (is_link($dir)) {
            @unlink($dir);
            return;
        }
        if (!is_dir($dir)) {
            return;
        }
        $items = @scandir($dir);
        if (!is_array($items)) {
            return;
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $path = rtrim($dir, '/\\') . '/' . $item;
            if (is_link($path)) {
                @unlink($path);
            } elseif (is_dir($path)) {
                dmd_unofficial_remove_dir($path);
            } else {
                @chmod($path, 0664);
                @unlink($path);
            }
        }
        @chmod($dir, 0775);
        @rmdir($dir);
    }
}

if (!function_exists('dmd_unofficial_chmod_tree')) {
    function dmd_unofficial_chmod_tree($path) {
        if (!file_exists($path)) {
            return;
        }
        if (is_file($path)) {
            @chmod($path, 0664);
            return;
        }
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            @chmod($item->getPathname(), $item->isDir() ? 0775 : 0664);
        }
        @chmod($path, 0775);
    }
}

if (!function_exists('dmd_unofficial_zip_layout')) {
    function dmd_unofficial_zip_layout(ZipArchive $zip, &$error) {
        $error = '';
        $topLevels = array();
        $hasRootFile = false;

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name === false || $name === '') {
                continue;
            }

            $name = str_replace('\\', '/', $name);
            $name = ltrim($name, './');

            if ($name === '' || strpos($name, '__MACOSX/') === 0) {
                continue;
            }

            if (
                substr($name, 0, 1) === '/' ||
                preg_match('~(^|/)\.\.(/|$)~', $name) ||
                preg_match('~^[a-zA-Z]:/~', $name) ||
                strpos($name, "\0") !== false
            ) {
                $error = 'ZIP refuse : chemin dangereux detecte.';
                return false;
            }

            $trimmed = rtrim($name, '/');
            if ($trimmed === '') {
                continue;
            }

            $parts = explode('/', $trimmed);
            $top = $parts[0];
            if ($top === '' || $top === '.' || $top === '..') {
                $error = 'ZIP refuse : structure invalide.';
                return false;
            }

            $topLevels[$top] = true;
            if (count($parts) === 1 && substr($name, -1) !== '/') {
                $hasRootFile = true;
            }
        }

        if (empty($topLevels)) {
            $error = 'ZIP vide.';
            return false;
        }

        $singleRoot = (!$hasRootFile && count($topLevels) === 1) ? key($topLevels) : '';
        return array(
            'single_root' => $singleRoot,
            'top_levels' => array_keys($topLevels),
        );
    }
}

if (!function_exists('dmd_unofficial_register_module')) {
    function dmd_unofficial_register_module($moduleId) {
        $listFile = DMD_ROOT . '/modules/list.json';
        $list = dmd_unofficial_json_read($listFile, array());
        if (!is_array($list)) {
            $list = array();
        }

        foreach ($list as $entry) {
            if (is_array($entry) && strcasecmp((string)($entry['id'] ?? ''), $moduleId) === 0) {
                return true;
            }
        }

        $list[] = array(
            'id' => $moduleId,
            'name' => $moduleId,
            'description' => 'Module non officiel installe manuellement.',
            'icon' => 'modules/' . $moduleId . '/icon.png',
            'enabled' => false,
            'storage_scope' => 'legacy',
            'default_access' => 'controlled',
            'source' => 'unofficial'
        );

        return dmd_unofficial_json_write($listFile, $list);
    }
}

if (!function_exists('dmd_unofficial_record_source')) {
    function dmd_unofficial_record_source($type, $id, $originalName) {
        $file = DMD_ROOT . '/data/market/' . ($type === 'theme' ? 'themes_sources.json' : 'modules_sources.json');
        $data = dmd_unofficial_json_read($file, array());
        if (!is_array($data)) {
            $data = array();
        }
        $data[$id] = array(
            'source' => 'unofficial',
            'install_method' => 'zip',
            'archive_name' => basename((string)$originalName),
            'installed_at' => date('c')
        );
        return dmd_unofficial_json_write($file, $data);
    }
}

if (!function_exists('dmd_install_unofficial_zip')) {
    function dmd_install_unofficial_zip($type, $upload, &$error) {
        $error = '';
        $type = $type === 'theme' ? 'theme' : 'module';

        if (!class_exists('ZipArchive')) {
            $error = 'ZipArchive n\'est pas disponible sur le serveur.';
            return false;
        }

        if (!is_array($upload) || (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $error = 'Aucun ZIP valide recu.';
            return false;
        }

        $originalName = basename((string)($upload['name'] ?? ''));
        if (strtolower(pathinfo($originalName, PATHINFO_EXTENSION)) !== 'zip') {
            $error = 'Le fichier doit etre un ZIP.';
            return false;
        }

        $fallbackId = dmd_unofficial_safe_slug(pathinfo($originalName, PATHINFO_FILENAME));
        if ($fallbackId === '') {
            $error = 'Nom de ZIP invalide.';
            return false;
        }

        $uploadRoot = DMD_ROOT . '/uploads/unofficial/' . ($type === 'theme' ? 'themes' : 'modules') . '/';
        if (!is_dir($uploadRoot) && !@mkdir($uploadRoot, 0775, true) && !is_dir($uploadRoot)) {
            $error = 'Impossible de preparer le dossier temporaire.';
            return false;
        }

        try {
            $random = bin2hex(random_bytes(8));
        } catch (Exception $e) {
            $random = uniqid('', true);
        }

        $zipFile = $uploadRoot . 'upload_' . preg_replace('~[^a-zA-Z0-9._-]+~', '_', $random) . '.zip';
        $stage = $uploadRoot . 'extract_' . preg_replace('~[^a-zA-Z0-9._-]+~', '_', $random) . '/';

        if (!@move_uploaded_file((string)$upload['tmp_name'], $zipFile)) {
            $error = 'Impossible de stocker temporairement le ZIP.';
            return false;
        }
        @chmod($zipFile, 0664);
        @mkdir($stage, 0775, true);

        $zip = new ZipArchive();
        if ($zip->open($zipFile) !== true) {
            @unlink($zipFile);
            dmd_unofficial_remove_dir($stage);
            $error = 'Impossible d\'ouvrir le ZIP.';
            return false;
        }

        $layoutError = '';
        $layout = dmd_unofficial_zip_layout($zip, $layoutError);
        if ($layout === false) {
            $zip->close();
            @unlink($zipFile);
            dmd_unofficial_remove_dir($stage);
            $error = $layoutError;
            return false;
        }

        if (!$zip->extractTo($stage)) {
            $zip->close();
            @unlink($zipFile);
            dmd_unofficial_remove_dir($stage);
            $error = 'Extraction du ZIP impossible.';
            return false;
        }
        $zip->close();
        @unlink($zipFile);

        $singleRoot = (string)($layout['single_root'] ?? '');
        $targetId = dmd_unofficial_safe_slug($singleRoot !== '' ? $singleRoot : $fallbackId);
        if ($targetId === '') {
            dmd_unofficial_remove_dir($stage);
            $error = 'Nom de dossier cible invalide.';
            return false;
        }

        $targetRoot = DMD_ROOT . ($type === 'theme' ? '/theme/' : '/modules/');
        $target = $targetRoot . $targetId;

        if (file_exists($target) || is_link($target)) {
            dmd_unofficial_remove_dir($stage);
            $error = 'Un ' . ($type === 'theme' ? 'theme' : 'module') . ' portant ce nom existe deja : ' . $targetId . '.';
            return false;
        }

        if ($type === 'module') {
            $list = dmd_unofficial_json_read(DMD_ROOT . '/modules/list.json', array());
            foreach ($list as $entry) {
                if (is_array($entry) && strcasecmp((string)($entry['id'] ?? ''), $targetId) === 0) {
                    dmd_unofficial_remove_dir($stage);
                    $error = 'Un module portant cet identifiant existe deja dans modules/list.json : ' . $targetId . '.';
                    return false;
                }
            }
        }

        $source = $singleRoot !== '' ? $stage . $singleRoot : rtrim($stage, '/');

        if (!@rename($source, $target)) {
            dmd_unofficial_remove_dir($stage);
            $error = 'Impossible d\'installer le contenu dans ' . ($type === 'theme' ? '/theme/' : '/modules/') . '.';
            return false;
        }

        if ($singleRoot !== '') {
            dmd_unofficial_remove_dir($stage);
        }
        dmd_unofficial_chmod_tree($target);

        if ($type === 'module' && !dmd_unofficial_register_module($targetId)) {
            dmd_unofficial_remove_dir($target);
            $error = 'Module extrait mais impossible de l\'enregistrer dans modules/list.json.';
            return false;
        }

        dmd_unofficial_record_source($type, $targetId, $originalName);

        return array(
            'id' => $targetId,
            'type' => $type,
            'path' => $target,
            'archive_name' => $originalName
        );
    }
}
