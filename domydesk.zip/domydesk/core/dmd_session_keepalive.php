<?php
/**
 * DoMyDesk 1.2.0 - maintien de la session web authentifiée.
 */
require_once __DIR__ . '/dmd_security.php';
dmd_security_session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

$email = isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
if ($email === '') {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'unauthorized'));
    exit;
}

/*
 * Force une écriture de session afin de renouveler son activité côté serveur.
 * On réémet aussi le cookie comme cookie de session : cela neutralise un éventuel
 * session.cookie_lifetime=600 imposé par l'hébergement, y compris pour une session
 * qui existait déjà avant l'installation du correctif.
 */
$_SESSION['dmd_last_activity_ts'] = time();

$cookie = session_get_cookie_params();
$cookieOptions = array(
    'expires' => 0,
    'path' => isset($cookie['path']) ? (string)$cookie['path'] : '/',
    'domain' => isset($cookie['domain']) ? (string)$cookie['domain'] : '',
    'secure' => !empty($cookie['secure']),
    'httponly' => !empty($cookie['httponly']),
);
if (isset($cookie['samesite']) && (string)$cookie['samesite'] !== '') {
    $cookieOptions['samesite'] = (string)$cookie['samesite'];
}
@setcookie(session_name(), session_id(), $cookieOptions);

session_write_close();

echo json_encode(array('ok' => true, 'ts' => time()));
