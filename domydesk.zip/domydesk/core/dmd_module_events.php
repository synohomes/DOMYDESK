<?php
/**
 * DoMyDesk 1.2.0 - Contrat événementiel commun des modules.
 *
 * Une action réussie (ou échouée) est publiée une seule fois ici :
 * 1) journal opérationnel du module ;
 * 2) index d'activité de la ressource ;
 * 3) le bus d'activité permet aux services (Quick-Session, etc.) de réagir.
 */

if (!function_exists('dmd_module_event')) {
    function dmd_module_event($moduleId, $action, $resource, $options = array()) {
        $options = is_array($options) ? $options : array();
        $email = trim((string)($options['email'] ?? ''));
        if ($email === '' && function_exists('dmd_sys_current_email')) $email = dmd_sys_current_email();
        if (function_exists('dmd_sys_safe_email')) $email = dmd_sys_safe_email($email);

        $result = array('ok' => false, 'logged' => false, 'activity' => false, 'event' => null);
        $resource = function_exists('dmd_activity_normalize_resource') ? dmd_activity_normalize_resource($resource) : $resource;
        $systemScope = strtolower(trim((string)($options['scope'] ?? 'user'))) === 'system';
        if (!is_array($resource) || ($email === '' && !$systemScope)) {
            $result['error'] = 'invalid_event';
            return $result;
        }
        if ($email === '' && $systemScope && !array_key_exists('activity', $options)) {
            // Un événement planifié sans utilisateur n'alimente ni ActionHub personnel
            // ni Quick-Session ; il reste cependant journalisé côté module système.
            $options['activity'] = false;
        }

        if (!array_key_exists('log', $options) || $options['log'] !== false) {
            $logOptions = $options;
            $logOptions['email'] = $email;
            $logEntry = dmd_module_log($moduleId, $action, $resource, $logOptions);
            $result['logged'] = $logEntry !== false;
            if ($logEntry !== false) $result['log_entry'] = $logEntry;
        } else {
            $result['logged'] = true;
        }

        if (!array_key_exists('activity', $options) || $options['activity'] !== false) {
            $activityOptions = array(
                'label' => $options['label'] ?? $action,
                'target' => $options['target'] ?? ($resource['name'] ?? ($resource['label'] ?? '')),
                'status' => $options['status'] ?? 'success',
                'details' => is_scalar($options['details'] ?? '') ? (string)($options['details'] ?? '') : '',
                'meta' => is_array($options['meta'] ?? null) ? $options['meta'] : array(),
            );
            if (!empty($options['changes']) && function_exists('dmd_changes_normalize')) {
                $activityOptions['meta']['changes'] = dmd_changes_normalize($options['changes']);
            }
            $activity = dmd_activity_publish($email, $moduleId, $action, $resource, $activityOptions);
            $result['activity'] = !empty($activity['ok']);
            if (!empty($activity['event'])) $result['event'] = $activity['event'];
        } else {
            $result['activity'] = true;
        }

        $result['ok'] = $result['logged'] && $result['activity'];

        // Le même événement que celui utilisé par ActionHub devient le point
        // d'entrée des notifications configurables. Aucun câblage SMTP n'est
        // nécessaire dans les API des modules.
        if (!array_key_exists('notify', $options) || $options['notify'] !== false) {
            if (!function_exists('dmd_notification_emit')) {
                $notificationFile = __DIR__ . '/dmd_notification_mail.php';
                if (is_file($notificationFile)) {
                    require_once $notificationFile;
                }
            }

            if (function_exists('dmd_notification_emit')) {
                $resourceName = trim((string)($resource['name'] ?? ($resource['label'] ?? ($resource['id'] ?? ''))));
                $notificationContext = array(
                    'user' => $email,
                    'target' => $resourceName,
                    'module_id' => (string)$moduleId,
                    'status' => (string)($options['status'] ?? 'success'),
                    'details' => is_scalar($options['details'] ?? '') ? (string)($options['details'] ?? '') : '',
                    'resource_type' => (string)($resource['type'] ?? ''),
                    'resource_id' => (string)($resource['id'] ?? ''),
                    'resource_name' => $resourceName,
                    'resource_source' => (string)($resource['source'] ?? $moduleId),
                    'meta' => is_array($options['meta'] ?? null) ? $options['meta'] : array(),
                    'changes' => is_array($options['changes'] ?? null) ? $options['changes'] : array(),
                );
                try {
                    $result['notification'] = dmd_notification_emit(
                        strtolower(trim((string)$moduleId)) . '.' . strtolower(trim((string)$action)),
                        $notificationContext,
                        array('level' => (($options['status'] ?? 'success') === 'error' ? 'danger' : 'info'))
                    );
                } catch (Throwable $e) {
                    // Une panne e-mail ne doit jamais casser l'action du module.
                    $result['notification'] = array('ok' => false, 'reason' => 'notification_exception');
                }
            }
        }

        return $result;
    }
}
