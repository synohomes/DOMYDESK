<?php
/**
 * DoMyDesk - MFA TOTP (Microsoft Authenticator / RFC 6238 compatible)
 * PHP 7.3+
 */

/* Évite la boucle d'amorçage lorsque dmd_permissions.php charge à son tour le moteur MFA. */
$GLOBALS['dmd_mfa_bootstrapping'] = true;
require_once __DIR__ . '/dmd_permissions.php';
$GLOBALS['dmd_mfa_bootstrapping'] = false;

if (!function_exists('dmd_mfa_private_root')) {
    function dmd_mfa_private_root() {
        $primary = DMD_ROOT . '/var/security/';
        $fallback = DMD_ROOT . '/data/secure/mfa/';

        foreach (array($primary, $fallback) as $candidate) {
            if (is_file($candidate . 'mfa_master.key') || is_file($candidate . 'mfa_policy.json')) {
                return $candidate;
            }
        }

        if (is_dir($primary)) {
            if (is_writable($primary)) return $primary;
        } elseif (@mkdir($primary, 0750, true) || is_dir($primary)) {
            return $primary;
        }

        if (is_dir($fallback)) {
            return $fallback;
        }
        if (@mkdir($fallback, 0750, true) || is_dir($fallback)) {
            return $fallback;
        }

        return $primary;
    }
}

if (!function_exists('dmd_mfa_ensure_private_root')) {
    function dmd_mfa_ensure_private_root() {
        $dir = dmd_mfa_private_root();
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }
        if (!is_writable($dir)) {
            return false;
        }
        @chmod($dir, 0750);

        $htaccess = $dir . '.htaccess';
        $wanted = "Options -Indexes\n"
            . "<IfModule mod_authz_core.c>\n"
            . "    Require all denied\n"
            . "</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n"
            . "    Order allow,deny\n"
            . "    Deny from all\n"
            . "</IfModule>\n";
        if (!is_file($htaccess) || @file_get_contents($htaccess) !== $wanted) {
            @file_put_contents($htaccess, $wanted, LOCK_EX);
            @chmod($htaccess, 0640);
        }
        return true;
    }
}

if (!function_exists('dmd_mfa_master_key')) {
    function dmd_mfa_master_key() {
        if (!dmd_mfa_ensure_private_root()) return false;
        $file = dmd_mfa_private_root() . 'mfa_master.key';

        if (is_file($file)) {
            $key = @file_get_contents($file);
            if (is_string($key) && strlen($key) === 32) return $key;
            return false;
        }

        try {
            $key = random_bytes(32);
        } catch (Exception $e) {
            return false;
        }

        $tmp = $file . '.tmp.' . bin2hex(random_bytes(6));
        if (@file_put_contents($tmp, $key, LOCK_EX) === false) return false;
        @chmod($tmp, 0600);

        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            if (is_file($file)) {
                $existing = @file_get_contents($file);
                return is_string($existing) && strlen($existing) === 32 ? $existing : false;
            }
            return false;
        }
        @chmod($file, 0600);
        return $key;
    }
}

if (!function_exists('dmd_mfa_config_path')) {
    function dmd_mfa_config_path($email) {
        $safe = dmd_safe_user_key($email);
        if ($safe === '' || !dmd_ensure_private_profile_dir($safe)) return '';
        return dmd_user_private_dir($safe) . 'mfa.json';
    }
}

if (!function_exists('dmd_mfa_read')) {
    function dmd_mfa_read($email) {
        $path = dmd_mfa_config_path($email);
        if ($path === '' || !is_file($path)) return array('version' => 1, 'enabled' => false);
        $raw = @file_get_contents($path);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        return is_array($data) ? $data : array('version' => 1, 'enabled' => false);
    }
}

if (!function_exists('dmd_mfa_write')) {
    function dmd_mfa_write($email, $data) {
        $path = dmd_mfa_config_path($email);
        if ($path === '') return false;
        if (!is_array($data)) return false;
        $data['version'] = 1;
        $data['updated_at'] = date('c');
        return dmd_core_json_write($path, $data);
    }
}

if (!function_exists('dmd_mfa_enabled')) {
    function dmd_mfa_enabled($email) {
        $cfg = dmd_mfa_read($email);
        return !empty($cfg['enabled']) && !empty($cfg['secret_enc']);
    }
}

if (!function_exists('dmd_mfa_encrypt_secret')) {
    function dmd_mfa_encrypt_secret($plain) {
        $key = dmd_mfa_master_key();
        if ($key === false) return false;
        $plain = (string)$plain;

        if (function_exists('sodium_crypto_secretbox')) {
            try {
                $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $cipher = sodium_crypto_secretbox($plain, $nonce, $key);
                return 'sodium:' . base64_encode($nonce . $cipher);
            } catch (Exception $e) {
                return false;
            }
        }

        if (function_exists('openssl_encrypt')) {
            try {
                $iv = random_bytes(12);
                $tag = '';
                $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
                if ($cipher === false) return false;
                return 'aesgcm:' . base64_encode($iv . $tag . $cipher);
            } catch (Exception $e) {
                return false;
            }
        }

        return false;
    }
}

if (!function_exists('dmd_mfa_decrypt_secret')) {
    function dmd_mfa_decrypt_secret($encoded) {
        $key = dmd_mfa_master_key();
        if ($key === false) return false;
        $encoded = (string)$encoded;

        if (strpos($encoded, 'sodium:') === 0 && function_exists('sodium_crypto_secretbox_open')) {
            $raw = base64_decode(substr($encoded, 7), true);
            if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return false;
            $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $plain = sodium_crypto_secretbox_open($cipher, $nonce, $key);
            return $plain === false ? false : $plain;
        }

        if (strpos($encoded, 'aesgcm:') === 0 && function_exists('openssl_decrypt')) {
            $raw = base64_decode(substr($encoded, 7), true);
            if (!is_string($raw) || strlen($raw) <= 28) return false;
            $iv = substr($raw, 0, 12);
            $tag = substr($raw, 12, 16);
            $cipher = substr($raw, 28);
            $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '');
            return $plain === false ? false : $plain;
        }

        return false;
    }
}

if (!function_exists('dmd_mfa_base32_encode')) {
    function dmd_mfa_base32_encode($data) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $bits = '';
        $len = strlen($data);
        for ($i = 0; $i < $len; $i++) {
            $bits .= str_pad(decbin(ord($data[$i])), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        for ($i = 0, $blen = strlen($bits); $i < $blen; $i += 5) {
            $chunk = substr($bits, $i, 5);
            if (strlen($chunk) < 5) $chunk = str_pad($chunk, 5, '0', STR_PAD_RIGHT);
            $out .= $alphabet[bindec($chunk)];
        }
        return $out;
    }
}

if (!function_exists('dmd_mfa_base32_decode')) {
    function dmd_mfa_base32_decode($value) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $value = strtoupper(preg_replace('/[^A-Z2-7]/i', '', (string)$value));
        if ($value === '') return '';
        $bits = '';
        $len = strlen($value);
        for ($i = 0; $i < $len; $i++) {
            $pos = strpos($alphabet, $value[$i]);
            if ($pos === false) return false;
            $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        for ($i = 0, $blen = strlen($bits); $i + 8 <= $blen; $i += 8) {
            $out .= chr(bindec(substr($bits, $i, 8)));
        }
        return $out;
    }
}

if (!function_exists('dmd_mfa_generate_secret')) {
    function dmd_mfa_generate_secret() {
        try {
            return dmd_mfa_base32_encode(random_bytes(20));
        } catch (Exception $e) {
            return false;
        }
    }
}

if (!function_exists('dmd_mfa_counter_bytes')) {
    function dmd_mfa_counter_bytes($counter) {
        $counter = (int)$counter;
        $high = ($counter >> 32) & 0xFFFFFFFF;
        $low = $counter & 0xFFFFFFFF;
        return pack('N2', $high, $low);
    }
}

if (!function_exists('dmd_mfa_hotp')) {
    function dmd_mfa_hotp($secret, $counter, $digits = 6) {
        $key = dmd_mfa_base32_decode($secret);
        if ($key === false || $key === '') return false;
        $hash = hash_hmac('sha1', dmd_mfa_counter_bytes($counter), $key, true);
        $offset = ord(substr($hash, -1)) & 0x0F;
        $binary = ((ord($hash[$offset]) & 0x7F) << 24)
            | ((ord($hash[$offset + 1]) & 0xFF) << 16)
            | ((ord($hash[$offset + 2]) & 0xFF) << 8)
            | (ord($hash[$offset + 3]) & 0xFF);
        $mod = pow(10, (int)$digits);
        return str_pad((string)($binary % $mod), (int)$digits, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('dmd_mfa_totp')) {
    function dmd_mfa_totp($secret, $time = null) {
        if ($time === null) $time = time();
        return dmd_mfa_hotp($secret, (int)floor(((int)$time) / 30), 6);
    }
}

if (!function_exists('dmd_mfa_verify_totp_secret')) {
    function dmd_mfa_verify_totp_secret($secret, $code, $window = 1) {
        $code = preg_replace('/\D+/', '', (string)$code);
        if (strlen($code) !== 6) return false;
        $now = time();
        for ($i = -abs((int)$window); $i <= abs((int)$window); $i++) {
            $expected = dmd_mfa_totp($secret, $now + ($i * 30));
            if (is_string($expected) && hash_equals($expected, $code)) return true;
        }
        return false;
    }
}

if (!function_exists('dmd_mfa_verify_totp')) {
    function dmd_mfa_verify_totp($email, $code) {
        $cfg = dmd_mfa_read($email);
        if (empty($cfg['enabled']) || empty($cfg['secret_enc'])) return false;
        $secret = dmd_mfa_decrypt_secret($cfg['secret_enc']);
        if ($secret === false) return false;
        return dmd_mfa_verify_totp_secret($secret, $code, 1);
    }
}

if (!function_exists('dmd_mfa_otpauth_uri')) {
    function dmd_mfa_otpauth_uri($email, $secret) {
        $issuer = 'DoMyDesk';
        $label = $issuer . ':' . trim((string)$email);
        return 'otpauth://totp/' . rawurlencode($label)
            . '?secret=' . rawurlencode((string)$secret)
            . '&issuer=' . rawurlencode($issuer)
            . '&algorithm=SHA1&digits=6&period=30';
    }
}

if (!function_exists('dmd_mfa_recovery_code_normalize')) {
    function dmd_mfa_recovery_code_normalize($code) {
        return strtoupper(preg_replace('/[^A-Z0-9]/i', '', (string)$code));
    }
}

if (!function_exists('dmd_mfa_generate_recovery_codes')) {
    function dmd_mfa_generate_recovery_codes($count = 10) {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $out = array();
        try {
            for ($n = 0; $n < (int)$count; $n++) {
                $raw = '';
                for ($i = 0; $i < 12; $i++) {
                    $raw .= $alphabet[random_int(0, strlen($alphabet) - 1)];
                }
                $out[] = 'DMD-' . substr($raw, 0, 4) . '-' . substr($raw, 4, 4) . '-' . substr($raw, 8, 4);
            }
        } catch (Exception $e) {
            return array();
        }
        return $out;
    }
}

if (!function_exists('dmd_mfa_hash_recovery_codes')) {
    function dmd_mfa_hash_recovery_codes($codes) {
        $hashes = array();
        foreach ((array)$codes as $code) {
            $norm = dmd_mfa_recovery_code_normalize($code);
            if ($norm === '') continue;
            $hashes[] = password_hash($norm, PASSWORD_DEFAULT);
        }
        return $hashes;
    }
}

if (!function_exists('dmd_mfa_verify_recovery_code')) {
    function dmd_mfa_verify_recovery_code($email, $code, $consume = true) {
        $norm = dmd_mfa_recovery_code_normalize($code);
        if ($norm === '') return false;
        $cfg = dmd_mfa_read($email);
        $hashes = isset($cfg['recovery_hashes']) && is_array($cfg['recovery_hashes']) ? $cfg['recovery_hashes'] : array();
        foreach ($hashes as $idx => $hash) {
            if (is_string($hash) && password_verify($norm, $hash)) {
                if ($consume) {
                    unset($hashes[$idx]);
                    $cfg['recovery_hashes'] = array_values($hashes);
                    $cfg['last_recovery_use_at'] = date('c');
                    if (!dmd_mfa_write($email, $cfg)) return false;
                }
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('dmd_mfa_verify_user_code')) {
    function dmd_mfa_verify_user_code($email, $code, &$usedRecovery) {
        $usedRecovery = false;
        if (dmd_mfa_verify_totp($email, $code)) return true;
        if (dmd_mfa_verify_recovery_code($email, $code, true)) {
            $usedRecovery = true;
            return true;
        }
        return false;
    }
}

if (!function_exists('dmd_mfa_disable')) {
    function dmd_mfa_disable($email, $approvedBy = '') {
        $cfg = dmd_mfa_read($email);
        $cfg['enabled'] = false;
        $cfg['secret_enc'] = '';
        $cfg['recovery_hashes'] = array();
        $cfg['disabled_at'] = date('c');
        $cfg['disabled_by'] = dmd_safe_user_key($approvedBy);
        unset($cfg['disable_request']);
        return dmd_mfa_write($email, $cfg);
    }
}

/* ==========================================================
   Demande de désactivation MFA avec validation Superadmin
   ========================================================== */

if (!function_exists('dmd_mfa_disable_request')) {
    function dmd_mfa_disable_request($email) {
        $cfg = dmd_mfa_read($email);
        $request = isset($cfg['disable_request']) && is_array($cfg['disable_request']) ? $cfg['disable_request'] : array();
        if (empty($request['pending']) || empty($request['request_id'])) return array();
        return $request;
    }
}

if (!function_exists('dmd_mfa_disable_request_pending')) {
    function dmd_mfa_disable_request_pending($email) {
        return !empty(dmd_mfa_disable_request($email));
    }
}

if (!function_exists('dmd_mfa_request_disable')) {
    function dmd_mfa_request_disable($email, $requestedBy = '') {
        $email = dmd_safe_user_key($email);
        if ($email === '' || !dmd_mfa_enabled($email)) return false;

        $cfg = dmd_mfa_read($email);
        $existing = isset($cfg['disable_request']) && is_array($cfg['disable_request']) ? $cfg['disable_request'] : array();
        if (!empty($existing['pending']) && !empty($existing['request_id'])) {
            return $existing;
        }

        try {
            $requestId = 'MFAOFF-' . date('Ymd-His') . '-' . strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
        } catch (Exception $e) {
            return false;
        }

        $cfg['disable_request'] = array(
            'pending' => true,
            'request_id' => $requestId,
            'requested_at' => date('c'),
            'requested_by' => dmd_safe_user_key($requestedBy !== '' ? $requestedBy : $email),
        );

        if (!dmd_mfa_write($email, $cfg)) return false;
        return $cfg['disable_request'];
    }
}

if (!function_exists('dmd_mfa_clear_disable_request')) {
    function dmd_mfa_clear_disable_request($email, $requestId = '') {
        $email = dmd_safe_user_key($email);
        if ($email === '') return false;
        $cfg = dmd_mfa_read($email);
        $request = isset($cfg['disable_request']) && is_array($cfg['disable_request']) ? $cfg['disable_request'] : array();
        if (empty($request['pending'])) return true;
        if ($requestId !== '' && !hash_equals((string)($request['request_id'] ?? ''), (string)$requestId)) return false;
        unset($cfg['disable_request']);
        return dmd_mfa_write($email, $cfg);
    }
}

if (!function_exists('dmd_mfa_pending_disable_requests')) {
    function dmd_mfa_pending_disable_requests() {
        $items = array();
        $pattern = DMD_ROOT . '/users/profiles/*/profile/mfa.json';
        foreach (glob($pattern) ?: array() as $file) {
            $email = basename(dirname(dirname($file)));
            $email = dmd_safe_user_key($email);
            if ($email === '') continue;
            $cfg = dmd_mfa_read($email);
            $request = isset($cfg['disable_request']) && is_array($cfg['disable_request']) ? $cfg['disable_request'] : array();
            if (empty($cfg['enabled']) || empty($cfg['secret_enc']) || empty($request['pending']) || empty($request['request_id'])) continue;
            $profile = dmd_read_profile($email);
            $items[] = array(
                'email' => $email,
                'request_id' => (string)$request['request_id'],
                'requested_at' => (string)($request['requested_at'] ?? ''),
                'requested_by' => (string)($request['requested_by'] ?? $email),
                'first_name' => (string)($profile['prenom'] ?? ($profile['first_name'] ?? '')),
                'last_name' => (string)($profile['nom'] ?? ($profile['last_name'] ?? '')),
                'role_system' => (string)($profile['role_system'] ?? 'user'),
            );
        }
        usort($items, function ($a, $b) {
            return strcmp((string)($a['requested_at'] ?? ''), (string)($b['requested_at'] ?? ''));
        });
        return $items;
    }
}

/* ==========================================================
   Politique MFA centrale DoMyDesk
   - global : optional | required | disabled
   - roles/users : inherit | optional | required | disabled
   Aucune lecture de politique ne crée de clé MFA.
   ========================================================== */

if (!function_exists('dmd_mfa_policy_path')) {
    function dmd_mfa_policy_path() {
        return dmd_mfa_private_root() . 'mfa_policy.json';
    }
}

if (!function_exists('dmd_mfa_policy_normalize_state')) {
    function dmd_mfa_policy_normalize_state($state, $allowInherit = false) {
        $state = strtolower(trim((string)$state));
        $allowed = $allowInherit
            ? array('inherit', 'optional', 'required', 'disabled')
            : array('optional', 'required', 'disabled');
        return in_array($state, $allowed, true) ? $state : ($allowInherit ? 'inherit' : 'optional');
    }
}

if (!function_exists('dmd_mfa_policy_default')) {
    function dmd_mfa_policy_default() {
        return array(
            'version' => 1,
            'global' => 'optional',
            'roles' => array(),
            'users' => array(),
        );
    }
}

if (!function_exists('dmd_mfa_policy_read')) {
    function dmd_mfa_policy_read() {
        $default = dmd_mfa_policy_default();
        $file = dmd_mfa_policy_path();
        if (!is_file($file)) return $default;

        $raw = @file_get_contents($file);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) return $default;

        $out = $default;
        $out['global'] = dmd_mfa_policy_normalize_state($data['global'] ?? 'optional', false);

        foreach (array('roles', 'users') as $bucket) {
            $source = isset($data[$bucket]) && is_array($data[$bucket]) ? $data[$bucket] : array();
            foreach ($source as $key => $state) {
                $key = trim((string)$key);
                if ($key === '') continue;
                $normalized = dmd_mfa_policy_normalize_state($state, true);
                if ($normalized !== 'inherit') $out[$bucket][$key] = $normalized;
            }
        }

        if (!empty($data['updated_at'])) $out['updated_at'] = (string)$data['updated_at'];
        if (!empty($data['updated_by'])) $out['updated_by'] = dmd_safe_user_key((string)$data['updated_by']);
        return $out;
    }
}

if (!function_exists('dmd_mfa_policy_write')) {
    function dmd_mfa_policy_write($policy, $updatedBy = '') {
        if (!is_array($policy) || !dmd_mfa_ensure_private_root()) return false;

        $clean = dmd_mfa_policy_default();
        $clean['global'] = dmd_mfa_policy_normalize_state($policy['global'] ?? 'optional', false);

        foreach (array('roles', 'users') as $bucket) {
            $source = isset($policy[$bucket]) && is_array($policy[$bucket]) ? $policy[$bucket] : array();
            foreach ($source as $key => $state) {
                $key = trim((string)$key);
                if ($key === '') continue;
                $normalized = dmd_mfa_policy_normalize_state($state, true);
                if ($normalized !== 'inherit') $clean[$bucket][$key] = $normalized;
            }
            ksort($clean[$bucket], SORT_NATURAL | SORT_FLAG_CASE);
        }

        $clean['updated_at'] = date('c');
        $clean['updated_by'] = dmd_safe_user_key($updatedBy);
        $file = dmd_mfa_policy_path();
        $json = json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;

        try {
            $suffix = bin2hex(random_bytes(5));
        } catch (Exception $e) {
            return false;
        }

        $tmp = $file . '.tmp.' . $suffix;
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);

        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }
        @chmod($file, 0640);
        clearstatcache(true, $file);

        $raw = @file_get_contents($file);
        $saved = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($saved)) return false;

        if (dmd_mfa_policy_normalize_state($saved['global'] ?? 'optional', false) !== $clean['global']) {
            return false;
        }

        foreach (array('roles', 'users') as $bucket) {
            $savedBucket = isset($saved[$bucket]) && is_array($saved[$bucket]) ? $saved[$bucket] : array();
            $normalizedBucket = array();
            foreach ($savedBucket as $key => $state) {
                $key = trim((string)$key);
                if ($key === '') continue;
                $normalized = dmd_mfa_policy_normalize_state($state, true);
                if ($normalized !== 'inherit') $normalizedBucket[$key] = $normalized;
            }
            ksort($normalizedBucket, SORT_NATURAL | SORT_FLAG_CASE);
            if ($normalizedBucket !== $clean[$bucket]) return false;
        }

        return true;
    }
}

if (!function_exists('dmd_mfa_effective_policy')) {
    function dmd_mfa_effective_policy($email, $profile = null) {
        $email = dmd_safe_user_key($email);
        $policy = dmd_mfa_policy_read();
        if ($email === '') return (string)$policy['global'];

        if (isset($policy['users'][$email])) {
            return dmd_mfa_policy_normalize_state($policy['users'][$email], false);
        }

        if (!is_array($profile)) $profile = dmd_read_profile($email);
        $roleMetier = trim((string)($profile['role_metier'] ?? ''));
        if ($roleMetier !== '' && isset($policy['roles'][$roleMetier])) {
            return dmd_mfa_policy_normalize_state($policy['roles'][$roleMetier], false);
        }

        return dmd_mfa_policy_normalize_state($policy['global'] ?? 'optional', false);
    }
}

if (!function_exists('dmd_mfa_policy_requires_setup')) {
    function dmd_mfa_policy_requires_setup($email, $profile = null) {
        return dmd_mfa_effective_policy($email, $profile) === 'required' && !dmd_mfa_enabled($email);
    }
}

if (!function_exists('dmd_mfa_policy_login_uses_mfa')) {
    function dmd_mfa_policy_login_uses_mfa($email, $profile = null) {
        return dmd_mfa_effective_policy($email, $profile) !== 'disabled' && dmd_mfa_enabled($email);
    }
}

if (!function_exists('dmd_mfa_policy_allows_setup')) {
    function dmd_mfa_policy_allows_setup($email, $profile = null) {
        return dmd_mfa_effective_policy($email, $profile) !== 'disabled';
    }
}

if (!function_exists('dmd_mfa_policy_allows_disable')) {
    function dmd_mfa_policy_allows_disable($email, $profile = null) {
        return dmd_mfa_effective_policy($email, $profile) !== 'required';
    }
}

/* ==========================================================
   Garde MFA centrale
   Une politique "required" est une condition d'accès au Core :
   - sans MFA configuré => configuration obligatoire ;
   - MFA configuré mais session non vérifiée => challenge MFA ;
   - aucun module/page utilisant le Core ne peut contourner la règle.
   ========================================================== */

if (!function_exists('dmd_mfa_access_state')) {
    function dmd_mfa_access_state($email, $profile = null) {
        $email = dmd_safe_user_key($email);
        if ($email === '') return 'anonymous';

        if (dmd_mfa_effective_policy($email, $profile) !== 'required') {
            return 'ok';
        }

        if (!dmd_mfa_enabled($email)) {
            return 'setup_required';
        }

        $authenticatedAt = isset($_SESSION['dmd_mfa_authenticated_at'])
            ? (int)$_SESSION['dmd_mfa_authenticated_at']
            : 0;

        return $authenticatedAt > 0 ? 'ok' : 'verify_required';
    }
}

if (!function_exists('dmd_mfa_guard_base_url')) {
    function dmd_mfa_guard_base_url() {
        $documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
        $root = realpath(DMD_ROOT);

        if ($documentRoot !== false && $root !== false) {
            $doc = rtrim(str_replace('\\', '/', $documentRoot), '/');
            $app = rtrim(str_replace('\\', '/', $root), '/');
            if ($doc !== '' && ($app === $doc || strpos($app, $doc . '/') === 0)) {
                $relative = trim(substr($app, strlen($doc)), '/');
                return '/' . ($relative !== '' ? $relative . '/' : '');
            }
        }

        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        foreach (array('/modules/', '/adm/', '/users/', '/ActionHub/', '/Quick-Session/', '/core/') as $marker) {
            $pos = strpos($script, $marker);
            if ($pos !== false) {
                return rtrim(substr($script, 0, $pos), '/') . '/';
            }
        }

        $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
        return ($dir === '' || $dir === '.') ? '/' : $dir . '/';
    }
}

if (!function_exists('dmd_mfa_guard_is_exempt')) {
    function dmd_mfa_guard_is_exempt() {
        $script = basename((string)($_SERVER['SCRIPT_FILENAME'] ?? ($_SERVER['SCRIPT_NAME'] ?? '')));
        return in_array($script, array(
            'login.php',
            'logout.php',
            'mfa_setup.php',
            'mfa_qr.php',
            'mfa_verify.php',
        ), true);
    }
}

if (!function_exists('dmd_mfa_guard_wants_json')) {
    function dmd_mfa_guard_wants_json() {
        $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
        $xhr = strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''));
        $script = strtolower(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')));

        return strpos($accept, 'application/json') !== false
            || $xhr === 'xmlhttprequest'
            || substr($script, -8) === '_api.php'
            || $script === 'api.php';
    }
}

if (!function_exists('dmd_mfa_guard_safe_return_uri')) {
    function dmd_mfa_guard_safe_return_uri() {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? 'dashboard.php');
        if ($uri === '' || strpos($uri, "\r") !== false || strpos($uri, "\n") !== false || preg_match('#^https?://#i', $uri)) {
            return 'dashboard.php';
        }
        return $uri;
    }
}

if (!function_exists('dmd_mfa_enforce_access_policy')) {
    function dmd_mfa_enforce_access_policy() {
        if (PHP_SAPI === 'cli') return true;
        if (defined('DMD_MFA_ACCESS_GUARD_CHECKED')) return true;
        define('DMD_MFA_ACCESS_GUARD_CHECKED', true);

        if (dmd_mfa_guard_is_exempt()) return true;

        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            @session_start();
        }
        if (session_status() !== PHP_SESSION_ACTIVE) return true;

        $email = dmd_safe_user_key((string)($_SESSION['user']['email'] ?? ''));
        if ($email === '') return true;

        $profile = dmd_read_profile($email);
        $state = dmd_mfa_access_state($email, $profile);
        if ($state === 'ok' || $state === 'anonymous') return true;

        $base = dmd_mfa_guard_base_url();
        $returnUri = dmd_mfa_guard_safe_return_uri();

        if ($state === 'setup_required') {
            $redirect = $base . 'mfa_setup.php?required=1';
            $_SESSION['dmd_mfa_required_return'] = $returnUri;
            $error = 'mfa_setup_required';
        } else {
            $redirect = $base . 'mfa_verify.php?required=1';
            $_SESSION['dmd_mfa_pending'] = array(
                'email' => $email,
                'user' => isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : array(),
                'role_system' => (string)($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? 'user')),
                'redirect' => $returnUri,
                'issued_at' => time(),
                'attempts' => 0,
                'step_up' => true,
            );
            $error = 'mfa_verification_required';
        }

        if (dmd_mfa_guard_wants_json()) {
            if (!headers_sent()) {
                http_response_code(403);
                header('Content-Type: application/json; charset=utf-8');
                header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            }
            echo json_encode(array(
                'ok' => false,
                'error' => $error,
                'mfa_required' => true,
                'redirect' => $redirect,
            ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Location: ' . $redirect, true, 302);
            exit;
        }

        http_response_code(403);
        exit('MFA DoMyDesk obligatoire.');
    }
}

/* Si ce fichier a été chargé directement, applique immédiatement la politique. */
dmd_mfa_enforce_access_policy();

