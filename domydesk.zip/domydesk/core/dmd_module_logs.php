<?php
/**
 * DoMyDesk 1.2.0 - Journal opérationnel commun des modules.
 *
 * Ce fichier est général : il ne connait ni Quick-Session ni ActionHub.
 * Les modules écrivent leurs événements hors de /modules/<id>/.
 */

if (!defined('DMD_MODULE_LOG_ROOT')) {
    define('DMD_MODULE_LOG_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_module_log_safe_id')) {
    function dmd_module_log_safe_id($value) {
        $value = trim((string)$value);
        $value = preg_replace('/[^a-zA-Z0-9._-]+/', '_', $value);
        return trim((string)$value, '._-');
    }
}

if (!function_exists('dmd_module_log_secret_key')) {
    function dmd_module_log_secret_key($key) {
        $key = strtolower(trim((string)$key));
        if ($key === '') return false;
        foreach (array('password', 'passwd', 'motdepasse', 'mot_de_passe', 'secret', 'token', 'api_key', 'apikey', 'access_token', 'refresh_token', 'authorization', 'cookie', 'private_key') as $needle) {
            if (strpos($key, $needle) !== false) return true;
        }
        return false;
    }
}

if (!function_exists('dmd_module_log_sanitize')) {
    function dmd_module_log_sanitize($value, $key = '', $depth = 0) {
        if ($depth > 8) return '[profondeur limitée]';
        if (dmd_module_log_secret_key($key)) return '[masqué]';
        if (is_array($value)) {
            $clean = array();
            $count = 0;
            foreach ($value as $k => $v) {
                if ($count++ >= 200) {
                    $clean['__truncated__'] = true;
                    break;
                }
                $clean[$k] = dmd_module_log_sanitize($v, (string)$k, $depth + 1);
            }
            return $clean;
        }
        if (is_object($value)) return '[objet]';
        if (is_resource($value)) return '[ressource PHP]';
        if (is_string($value)) {
            $value = trim($value);
            if (function_exists('mb_substr')) return mb_substr($value, 0, 4000, 'UTF-8');
            return substr($value, 0, 4000);
        }
        if (is_scalar($value) || $value === null) return $value;
        return '';
    }
}

if (!function_exists('dmd_module_log_actor')) {
    function dmd_module_log_actor($email = '') {
        $email = trim((string)$email);
        if ($email === '' && function_exists('dmd_sys_current_email')) $email = (string)dmd_sys_current_email();
        $profile = ($email !== '' && function_exists('dmd_sys_profile')) ? dmd_sys_profile($email) : array();
        $name = trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? ''));
        return array(
            'email' => $email,
            'name' => $name,
            'role_system' => (string)($profile['role_system'] ?? ''),
            'role_metier' => (string)($profile['role_metier'] ?? ''),
        );
    }
}

if (!function_exists('dmd_module_log_dir')) {
    function dmd_module_log_dir($moduleId, $email = '', $scope = 'user', $create = true) {
        $moduleId = dmd_module_log_safe_id($moduleId);
        if ($moduleId === '') return '';
        $scope = strtolower(trim((string)$scope));
        if ($scope === 'system') {
            $dir = DMD_MODULE_LOG_ROOT . '/data/modules/' . $moduleId . '/logs';
        } else {
            $email = function_exists('dmd_sys_safe_email') ? dmd_sys_safe_email($email) : trim((string)$email);
            if ($email === '') return '';
            $dir = DMD_MODULE_LOG_ROOT . '/users/profiles/' . $email . '/logs/' . $moduleId;
        }
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir) && function_exists('dmd_ensure_denied_directory')) dmd_ensure_denied_directory($dir);
        return $dir;
    }
}

if (!function_exists('dmd_module_log_file')) {
    function dmd_module_log_file($moduleId, $email = '', $scope = 'user', $timestamp = null) {
        $dir = dmd_module_log_dir($moduleId, $email, $scope, true);
        if ($dir === '') return '';
        $ts = $timestamp === null ? time() : (int)$timestamp;
        return $dir . '/' . date('Y-m-d', $ts) . '.json';
    }
}

if (!function_exists('dmd_module_log')) {
    function dmd_module_log($moduleId, $action, $resource = array(), $options = array()) {
        $moduleId = dmd_module_log_safe_id($moduleId);
        $action = trim((string)$action);
        $options = is_array($options) ? $options : array();
        if ($moduleId === '' || $action === '') return false;

        $actorEmail = trim((string)($options['email'] ?? ''));
        if ($actorEmail === '' && function_exists('dmd_sys_current_email')) $actorEmail = dmd_sys_current_email();
        if (function_exists('dmd_sys_safe_email')) $actorEmail = dmd_sys_safe_email($actorEmail);
        $scope = strtolower(trim((string)($options['scope'] ?? 'user')));
        if ($scope !== 'system') $scope = 'user';
        if ($scope === 'user' && $actorEmail === '') return false;

        $resource = is_array($resource) ? $resource : array();
        if (function_exists('dmd_activity_normalize_resource')) {
            $normalized = dmd_activity_normalize_resource($resource);
            if ($normalized) $resource = $normalized;
        }

        $ts = time();
        try { $suffix = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)); }
        catch (Exception $e) { $suffix = strtoupper(substr(md5(uniqid('', true)), 0, 8)); }

        $changes = array();
        if (function_exists('dmd_changes_normalize')) $changes = dmd_changes_normalize($options['changes'] ?? array());

        $entry = array(
            'id' => 'MOD-' . date('Ymd-His', $ts) . '-' . $suffix,
            'timestamp' => $ts,
            'date_iso' => date('c', $ts),
            'module' => $moduleId,
            'actor' => dmd_module_log_actor($actorEmail),
            'action' => $action,
            'status' => trim((string)($options['status'] ?? 'success')) ?: 'success',
            'label' => trim((string)($options['label'] ?? $action)),
            'resource' => dmd_module_log_sanitize($resource),
            'target' => trim((string)($options['target'] ?? ($resource['name'] ?? ($resource['label'] ?? ($resource['id'] ?? ''))))),
            'details' => dmd_module_log_sanitize($options['details'] ?? ''),
            'changes' => $changes,
            'meta' => dmd_module_log_sanitize($options['meta'] ?? array()),
            'ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
        );

        $file = dmd_module_log_file($moduleId, $actorEmail, $scope, $ts);
        if ($file === '') return false;
        $fp = @fopen($file, 'c+');
        if (!$fp) return false;
        $ok = false;
        if (@flock($fp, LOCK_EX)) {
            rewind($fp);
            $raw = stream_get_contents($fp);
            $logs = array();
            if (is_string($raw) && trim($raw) !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) $logs = $decoded;
            }
            $logs[] = $entry;
            $json = json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json !== false) {
                rewind($fp);
                ftruncate($fp, 0);
                $ok = fwrite($fp, $json) !== false;
                fflush($fp);
            }
            flock($fp, LOCK_UN);
        }
        fclose($fp);
        @chmod($file, 0640);
        return $ok ? $entry : false;
    }
}

if (!function_exists('dmd_module_log_list')) {
    function dmd_module_log_list($moduleId, $email = '', $scope = 'user', $limit = 200) {
        $dir = dmd_module_log_dir($moduleId, $email, $scope, false);
        if ($dir === '' || !is_dir($dir)) return array();
        $files = glob($dir . '/*.json') ?: array();
        rsort($files, SORT_STRING);
        $out = array();
        foreach ($files as $file) {
            $data = json_decode((string)@file_get_contents($file), true);
            if (!is_array($data)) continue;
            for ($i = count($data) - 1; $i >= 0; $i--) {
                if (is_array($data[$i])) $out[] = $data[$i];
                if (count($out) >= max(1, min(5000, (int)$limit))) return $out;
            }
        }
        return $out;
    }
}
