<?php
// Compatibilité 1.2.0 : l'export Quick-Session est désormais isolé dans /Quick-Session/.
require_once dirname(__DIR__) . '/Quick-Session/dmd_quick_session_pdf.php';
