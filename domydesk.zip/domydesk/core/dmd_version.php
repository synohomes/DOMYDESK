<?php
declare(strict_types=1);

/**
 * DoMyDesk - source unique de version du Core.
 *
 * La version officielle est stockée dans /data/version.txt afin qu'une mise
 * à jour système puisse la remplacer sans modifier du code PHP.
 */
function dmd_version_file(?string $rootDir = null): string
{
    $rootDir = $rootDir ?: dirname(__DIR__);
    return rtrim($rootDir, '/\\') . '/data/version.txt';
}

function dmd_version_read(?string $rootDir = null): string
{
    $file = dmd_version_file($rootDir);

    if (!is_file($file) || !is_readable($file)) {
        return 'Inconnue';
    }

    $version = trim((string)@file_get_contents($file));
    if ($version === '') {
        return 'Inconnue';
    }

    // Accepte SemVer classique et variantes simples : 1.2.0, 1.2.0-beta.1, etc.
    if (strlen($version) > 40 || !preg_match('/^[0-9A-Za-z][0-9A-Za-z._+\-]*$/', $version)) {
        return 'Inconnue';
    }

    return $version;
}
