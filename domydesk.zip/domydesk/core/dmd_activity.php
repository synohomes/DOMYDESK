<?php
/**
 * DoMyDesk 1.2.0 - Bus d'événements + index léger d'activité des ressources.
 *
 * But : un module publie UNE activité ciblée au moment où elle arrive.
 * Aucun scan périodique de logs. Les services spécialisés peuvent s'abonner
 * au bus dans la requête courante.
 */

if (!defined('DMD_ACTIVITY_ROOT')) {
    define('DMD_ACTIVITY_ROOT', dirname(__DIR__));
}

if (!isset($GLOBALS['DMD_EVENT_LISTENERS']) || !is_array($GLOBALS['DMD_EVENT_LISTENERS'])) {
    $GLOBALS['DMD_EVENT_LISTENERS'] = array();
}

if (!function_exists('dmd_event_on')) {
    function dmd_event_on($eventName, $listener) {
        $eventName = strtolower(trim((string)$eventName));
        if ($eventName === '' || !is_callable($listener)) {
            return false;
        }
        if (!isset($GLOBALS['DMD_EVENT_LISTENERS'][$eventName]) || !is_array($GLOBALS['DMD_EVENT_LISTENERS'][$eventName])) {
            $GLOBALS['DMD_EVENT_LISTENERS'][$eventName] = array();
        }
        $GLOBALS['DMD_EVENT_LISTENERS'][$eventName][] = $listener;
        return true;
    }
}

if (!function_exists('dmd_event_emit')) {
    function dmd_event_emit($eventName, $payload = array()) {
        $eventName = strtolower(trim((string)$eventName));
        $listeners = isset($GLOBALS['DMD_EVENT_LISTENERS'][$eventName]) && is_array($GLOBALS['DMD_EVENT_LISTENERS'][$eventName])
            ? $GLOBALS['DMD_EVENT_LISTENERS'][$eventName]
            : array();
        $results = array();
        foreach ($listeners as $listener) {
            try {
                $results[] = call_user_func($listener, $payload);
            } catch (Throwable $e) {
                $results[] = false;
            }
        }
        return $results;
    }
}

if (!function_exists('dmd_activity_safe_email')) {
    function dmd_activity_safe_email($email) {
        $email = trim((string)$email);
        if ($email === '' || basename($email) !== $email || strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) {
            return '';
        }
        return $email;
    }
}

if (!function_exists('dmd_activity_clean_text')) {
    function dmd_activity_clean_text($value, $maxLen = 240) {
        $value = trim(strip_tags((string)$value));
        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, $maxLen, 'UTF-8');
        }
        return substr($value, 0, $maxLen);
    }
}

if (!function_exists('dmd_activity_normalize_resource')) {
    function dmd_activity_normalize_resource($resource) {
        if (!is_array($resource)) {
            return null;
        }
        $type = strtolower(dmd_activity_clean_text($resource['type'] ?? 'object', 80));
        $type = preg_replace('/[^a-z0-9._-]+/', '_', $type);
        $id = dmd_activity_clean_text($resource['id'] ?? '', 180);
        if ($id === '') {
            return null;
        }
        $name = dmd_activity_clean_text($resource['name'] ?? ($resource['label'] ?? $id), 180);
        $source = dmd_activity_clean_text($resource['source'] ?? ($resource['module'] ?? ''), 100);
        $tags = array();
        foreach ((array)($resource['tags'] ?? array()) as $tag) {
            $tag = dmd_activity_clean_text($tag, 80);
            if ($tag !== '' && !in_array($tag, $tags, true)) {
                $tags[] = $tag;
            }
            if (count($tags) >= 20) break;
        }
        return array(
            'type' => $type !== '' ? $type : 'object',
            'id' => $id,
            'name' => $name !== '' ? $name : $id,
            'label' => $name !== '' ? $name : $id,
            'source' => $source,
            'tags' => $tags,
        );
    }
}

if (!function_exists('dmd_activity_dir')) {
    function dmd_activity_dir($email, $create = true) {
        $email = dmd_activity_safe_email($email);
        if ($email === '') return '';
        $dir = DMD_ACTIVITY_ROOT . '/users/profiles/' . $email . '/activity';
        if ($create && !is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
        if ($create && is_dir($dir)) {
            $ht = $dir . '/.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n", LOCK_EX);
            }
        }
        return $dir;
    }
}

if (!function_exists('dmd_activity_read_json')) {
    function dmd_activity_read_json($file, $fallback = array()) {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false) return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}

if (!function_exists('dmd_activity_write_json')) {
    function dmd_activity_write_json($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000,9999);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_activity_publish')) {
    function dmd_activity_publish($email, $moduleId, $action, $resource, $options = array()) {
        $email = dmd_activity_safe_email($email);
        $moduleId = preg_replace('/[^a-zA-Z0-9._-]+/', '_', trim((string)$moduleId));
        $action = preg_replace('/[^a-zA-Z0-9._-]+/', '_', trim((string)$action));
        $resource = dmd_activity_normalize_resource($resource);
        if ($email === '' || $moduleId === '' || $action === '' || !$resource) {
            return array('ok' => false, 'error' => 'invalid_activity');
        }

        $ts = time();
        try { $rand = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)); }
        catch (Exception $e) { $rand = strtoupper(substr(md5(uniqid('', true)), 0, 8)); }

        $event = array(
            'id' => 'ACT-' . date('Ymd-His', $ts) . '-' . $rand,
            'timestamp' => $ts,
            'date_iso' => date('c', $ts),
            'user' => $email,
            'module' => $moduleId,
            'action' => $action,
            'label' => dmd_activity_clean_text($options['label'] ?? $action, 180),
            'target' => dmd_activity_clean_text($options['target'] ?? $resource['name'], 180),
            'status' => dmd_activity_clean_text($options['status'] ?? 'success', 40),
            'details' => dmd_activity_clean_text($options['details'] ?? '', 1000),
            'resource' => $resource,
            'meta' => isset($options['meta']) && is_array($options['meta']) ? $options['meta'] : array(),
        );

        $dir = dmd_activity_dir($email, true);
        if ($dir === '') return array('ok' => false, 'error' => 'activity_dir');

        // Un seul verrou par utilisateur protège le read/modify/write de l’index
        // et des historiques de ressources. L’événement est émis après libération
        // du verrou afin qu’un listener (Quick-Session notamment) ne bloque jamais
        // une nouvelle publication d’activité.
        $lockFile = $dir . '/.write.lock';
        $lockHandle = @fopen($lockFile, 'c+');
        $locked = $lockHandle && @flock($lockHandle, LOCK_EX);
        if ($lockHandle) @chmod($lockFile, 0640);

        $stored = false;
        if ($locked) {
            $resourceKey = sha1(strtolower($resource['type'] . '|' . $resource['source'] . '|' . $resource['id']));
            $resourceDir = $dir . '/resources/' . $resource['type'];
            $resourceFile = $resourceDir . '/' . $resourceKey . '.json';
            $record = dmd_activity_read_json($resourceFile, array(
                'resource' => $resource,
                'first_seen' => $ts,
                'last_seen' => $ts,
                'events' => array(),
            ));
            $record['resource'] = $resource;
            $record['last_seen'] = $ts;
            if (!isset($record['events']) || !is_array($record['events'])) $record['events'] = array();
            $record['events'][] = $event;
            if (count($record['events']) > 50) $record['events'] = array_slice($record['events'], -50);
            $resourceStored = dmd_activity_write_json($resourceFile, $record);

            $indexFile = $dir . '/index.json';
            $index = dmd_activity_read_json($indexFile, array('version' => 1, 'updated_at' => 0, 'resources' => array()));
            if (!isset($index['resources']) || !is_array($index['resources'])) $index['resources'] = array();
            $index['resources'][$resourceKey] = array(
                'resource' => $resource,
                'module' => $moduleId,
                'last_action' => $action,
                'last_status' => $event['status'],
                'last_seen' => $ts,
            );
            uasort($index['resources'], function($a, $b) {
                return (int)($b['last_seen'] ?? 0) <=> (int)($a['last_seen'] ?? 0);
            });
            if (count($index['resources']) > 250) {
                $index['resources'] = array_slice($index['resources'], 0, 250, true);
            }
            $index['updated_at'] = $ts;
            $indexStored = dmd_activity_write_json($indexFile, $index);
            $stored = $resourceStored && $indexStored;
        }

        if ($locked) @flock($lockHandle, LOCK_UN);
        if ($lockHandle) @fclose($lockHandle);

        dmd_event_emit('dmd.activity', $event);
        return array('ok' => true, 'stored' => $stored, 'event' => $event);
    }
}

if (!function_exists('dmd_activity_recent_resources')) {
    function dmd_activity_recent_resources($email, $limit = 100) {
        $dir = dmd_activity_dir($email, false);
        if ($dir === '') return array();
        $index = dmd_activity_read_json($dir . '/index.json', array());
        $items = isset($index['resources']) && is_array($index['resources']) ? array_values($index['resources']) : array();
        usort($items, function($a, $b) { return (int)($b['last_seen'] ?? 0) <=> (int)($a['last_seen'] ?? 0); });
        return array_slice($items, 0, max(1, min(250, (int)$limit)));
    }
}

/* =========================================================
   CORBEILLE ACTIONHUB
   Une ressource retirée par l'utilisateur quitte l'index actif mais son
   historique est archivé ici jusqu'à purge explicite par le Superadmin.
   Une nouvelle activité sur le même objet recrée naturellement un historique
   actif neuf, sans faire réapparaître l'ancienne archive.
   ========================================================= */
if (!function_exists('dmd_activity_resource_key')) {
    function dmd_activity_resource_key($resource) {
        $resource = dmd_activity_normalize_resource($resource);
        if (!$resource) return '';
        return sha1(strtolower($resource['type'] . '|' . $resource['source'] . '|' . $resource['id']));
    }
}

if (!function_exists('dmd_activity_trash_dir')) {
    function dmd_activity_trash_dir($email, $create = true) {
        $dir = dmd_activity_dir($email, $create);
        if ($dir === '') return '';
        $trash = $dir . '/trash';
        if ($create && !is_dir($trash)) {
            @mkdir($trash . '/records', 0750, true);
        }
        if ($create && is_dir($trash)) {
            $ht = $trash . '/.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n", LOCK_EX);
                @chmod($ht, 0640);
            }
            if (!is_dir($trash . '/records')) @mkdir($trash . '/records', 0750, true);
        }
        return $trash;
    }
}

if (!function_exists('dmd_activity_trash_resource')) {
    function dmd_activity_trash_resource($email, $resource) {
        $email = dmd_activity_safe_email($email);
        $resource = dmd_activity_normalize_resource($resource);
        if ($email === '' || !$resource) {
            return array('ok' => false, 'error' => 'invalid_resource');
        }

        $dir = dmd_activity_dir($email, false);
        if ($dir === '' || !is_dir($dir)) {
            return array('ok' => true, 'removed' => false, 'trashed' => false);
        }

        $key = dmd_activity_resource_key($resource);
        if ($key === '') return array('ok' => false, 'error' => 'invalid_resource');

        $lockFile = $dir . '/.write.lock';
        $lockHandle = @fopen($lockFile, 'c+');
        if (!$lockHandle || !@flock($lockHandle, LOCK_EX)) {
            if ($lockHandle) @fclose($lockHandle);
            return array('ok' => false, 'error' => 'activity_locked');
        }
        @chmod($lockFile, 0640);

        $result = array('ok' => false, 'error' => 'write_failed');
        try {
            $indexFile = $dir . '/index.json';
            $index = dmd_activity_read_json($indexFile, array('version' => 1, 'updated_at' => 0, 'resources' => array()));
            if (!isset($index['resources']) || !is_array($index['resources'])) $index['resources'] = array();

            $entry = isset($index['resources'][$key]) && is_array($index['resources'][$key]) ? $index['resources'][$key] : null;
            $resourceFile = $dir . '/resources/' . $resource['type'] . '/' . $key . '.json';
            $record = is_file($resourceFile) ? dmd_activity_read_json($resourceFile, array()) : array();

            if (!$entry && empty($record)) {
                $result = array('ok' => true, 'removed' => false, 'trashed' => false, 'resource' => $resource);
            } else {
                $ts = time();
                try { $rand = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)); }
                catch (Exception $e) { $rand = strtoupper(substr(md5(uniqid('', true)), 0, 8)); }
                $trashId = 'TRASH-' . date('Ymd-His', $ts) . '-' . $rand . '-' . strtoupper(substr($key, 0, 8));

                if (!$entry) {
                    $entry = array(
                        'resource' => $resource,
                        'module' => $resource['source'],
                        'last_action' => '',
                        'last_status' => '',
                        'last_seen' => isset($record['last_seen']) ? (int)$record['last_seen'] : $ts,
                    );
                }
                if (empty($record)) {
                    $record = array(
                        'resource' => $resource,
                        'first_seen' => isset($entry['last_seen']) ? (int)$entry['last_seen'] : $ts,
                        'last_seen' => isset($entry['last_seen']) ? (int)$entry['last_seen'] : $ts,
                        'events' => array(),
                    );
                }
                if (!isset($record['events']) || !is_array($record['events'])) $record['events'] = array();

                $trashDir = dmd_activity_trash_dir($email, true);
                if ($trashDir === '' || !is_dir($trashDir)) {
                    $result = array('ok' => false, 'error' => 'trash_dir');
                } else {
                    $trashRecordFile = $trashDir . '/records/' . $trashId . '.json';
                    $trashRecord = array(
                        'version' => 1,
                        'trash_id' => $trashId,
                        'owner' => $email,
                        'trashed_at' => $ts,
                        'resource_key' => $key,
                        'entry' => $entry,
                        'record' => $record,
                    );

                    $trashIndexFile = $trashDir . '/index.json';
                    $trashIndex = dmd_activity_read_json($trashIndexFile, array('version' => 1, 'updated_at' => 0, 'items' => array()));
                    if (!isset($trashIndex['items']) || !is_array($trashIndex['items'])) $trashIndex['items'] = array();

                    $summary = array(
                        'trash_id' => $trashId,
                        'file' => basename($trashRecordFile),
                        'trashed_at' => $ts,
                        'resource' => isset($entry['resource']) && is_array($entry['resource']) ? $entry['resource'] : $resource,
                        'module' => isset($entry['module']) ? (string)$entry['module'] : $resource['source'],
                        'last_action' => isset($entry['last_action']) ? (string)$entry['last_action'] : '',
                        'last_status' => isset($entry['last_status']) ? (string)$entry['last_status'] : '',
                        'last_seen' => isset($entry['last_seen']) ? (int)$entry['last_seen'] : (int)($record['last_seen'] ?? 0),
                        'first_seen' => isset($record['first_seen']) ? (int)$record['first_seen'] : 0,
                        'event_count' => count($record['events']),
                    );

                    if (!dmd_activity_write_json($trashRecordFile, $trashRecord)) {
                        $result = array('ok' => false, 'error' => 'trash_record_write_failed');
                    } else {
                        $trashIndex['items'][$trashId] = $summary;
                        $trashIndex['updated_at'] = $ts;
                        if (!dmd_activity_write_json($trashIndexFile, $trashIndex)) {
                            @unlink($trashRecordFile);
                            $result = array('ok' => false, 'error' => 'trash_index_write_failed');
                        } else {
                            if (isset($index['resources'][$key])) unset($index['resources'][$key]);
                            $index['updated_at'] = $ts;
                            if (!dmd_activity_write_json($indexFile, $index)) {
                                unset($trashIndex['items'][$trashId]);
                                $trashIndex['updated_at'] = time();
                                dmd_activity_write_json($trashIndexFile, $trashIndex);
                                @unlink($trashRecordFile);
                                $result = array('ok' => false, 'error' => 'active_index_write_failed');
                            } else {
                                if (is_file($resourceFile)) @unlink($resourceFile);
                                $result = array(
                                    'ok' => true,
                                    'removed' => true,
                                    'trashed' => true,
                                    'trash_id' => $trashId,
                                    'resource' => $resource,
                                    'event_count' => count($record['events']),
                                );
                            }
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            $result = array('ok' => false, 'error' => 'trash_failed');
        }

        @flock($lockHandle, LOCK_UN);
        @fclose($lockHandle);
        return $result;
    }
}

if (!function_exists('dmd_activity_trash_items')) {
    function dmd_activity_trash_items($email, $limit = 250, $includeEvents = false) {
        $email = dmd_activity_safe_email($email);
        if ($email === '') return array();
        $trashDir = dmd_activity_trash_dir($email, false);
        if ($trashDir === '' || !is_dir($trashDir)) return array();

        $index = dmd_activity_read_json($trashDir . '/index.json', array());
        $items = isset($index['items']) && is_array($index['items']) ? array_values($index['items']) : array();
        usort($items, function($a, $b) {
            return (int)($b['trashed_at'] ?? 0) <=> (int)($a['trashed_at'] ?? 0);
        });
        $items = array_slice($items, 0, max(1, min(500, (int)$limit)));

        if ($includeEvents) {
            foreach ($items as &$item) {
                $file = basename((string)($item['file'] ?? ''));
                $record = $file !== '' ? dmd_activity_read_json($trashDir . '/records/' . $file, array()) : array();
                $activity = isset($record['record']) && is_array($record['record']) ? $record['record'] : array();
                $events = isset($activity['events']) && is_array($activity['events']) ? $activity['events'] : array();
                $item['events'] = $events;
                $item['event_count'] = count($events);
                if (isset($activity['first_seen'])) $item['first_seen'] = (int)$activity['first_seen'];
                if (isset($activity['last_seen'])) $item['last_seen'] = (int)$activity['last_seen'];
            }
            unset($item);
        }
        return $items;
    }
}

if (!function_exists('dmd_activity_trash_summary')) {
    function dmd_activity_trash_summary($email) {
        $items = dmd_activity_trash_items($email, 500, false);
        $last = 0;
        foreach ($items as $item) $last = max($last, (int)($item['trashed_at'] ?? 0));
        return array('count' => count($items), 'last_trashed_at' => $last);
    }
}

if (!function_exists('dmd_activity_remove_tree')) {
    function dmd_activity_remove_tree($path) {
        if (!file_exists($path)) return true;
        if (is_file($path) || is_link($path)) return @unlink($path);
        $ok = true;
        $entries = @scandir($path);
        if (!is_array($entries)) return false;
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            if (!dmd_activity_remove_tree($path . '/' . $entry)) $ok = false;
        }
        return @rmdir($path) && $ok;
    }
}

if (!function_exists('dmd_activity_purge_trash')) {
    function dmd_activity_purge_trash($email) {
        $email = dmd_activity_safe_email($email);
        if ($email === '') return array('ok' => false, 'error' => 'invalid_user');

        $dir = dmd_activity_dir($email, false);
        if ($dir === '' || !is_dir($dir)) return array('ok' => true, 'deleted' => 0);

        $lockFile = $dir . '/.write.lock';
        $lockHandle = @fopen($lockFile, 'c+');
        if (!$lockHandle || !@flock($lockHandle, LOCK_EX)) {
            if ($lockHandle) @fclose($lockHandle);
            return array('ok' => false, 'error' => 'activity_locked');
        }
        @chmod($lockFile, 0640);

        $trashDir = dmd_activity_trash_dir($email, false);
        $deleted = 0;
        $ok = true;
        if ($trashDir !== '' && is_dir($trashDir)) {
            $summary = dmd_activity_trash_summary($email);
            $deleted = (int)$summary['count'];
            $ok = dmd_activity_remove_tree($trashDir);
        }

        @flock($lockHandle, LOCK_UN);
        @fclose($lockHandle);
        return $ok ? array('ok' => true, 'deleted' => $deleted) : array('ok' => false, 'error' => 'purge_failed', 'deleted' => $deleted);
    }
}
