<?php
/**
 * DoMyDesk 1.2.0 - Services Core : logs système + notifications.
 *
 * Principes :
 * - aucune base de données ;
 * - aucune boucle serveur permanente ;
 * - écritures uniquement lorsqu'un événement se produit ;
 * - index utilisateurs persistant afin d'éviter de scanner tous les profils ;
 * - compteur de notifications séparé de la boîte complète.
 */

if (!defined('DMD_SYSTEM_ROOT')) {
    define('DMD_SYSTEM_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_sys_json_read')) {
    function dmd_sys_json_read($file, $fallback = array()) {
        if (!is_file($file)) {
            return $fallback;
        }
        $raw = @file_get_contents($file);
        if ($raw === false) {
            return $fallback;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}

if (!function_exists('dmd_sys_json_write')) {
    function dmd_sys_json_write($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }

        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
            return false;
        }
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_sys_safe_email')) {
    function dmd_sys_safe_email($email) {
        $email = trim((string)$email);
        if ($email === '' || basename($email) !== $email) {
            return '';
        }
        if (strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) {
            return '';
        }
        return $email;
    }
}

if (!function_exists('dmd_sys_current_email')) {
    function dmd_sys_current_email() {
        return dmd_sys_safe_email(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : '');
    }
}

if (!function_exists('dmd_sys_profile')) {
    function dmd_sys_profile($email) {
        $email = dmd_sys_safe_email($email);
        if ($email === '') {
            return array();
        }

        if (function_exists('dmd_read_profile')) {
            $profile = dmd_read_profile($email);
            return is_array($profile) ? $profile : array();
        }

        $paths = array(
            DMD_SYSTEM_ROOT . '/users/profiles/' . $email . '/private/profile.json',
            DMD_SYSTEM_ROOT . '/users/profiles/' . $email . '/profile.json',
        );
        foreach ($paths as $path) {
            if (is_file($path)) {
                return dmd_sys_json_read($path, array());
            }
        }
        return array();
    }
}

if (!function_exists('dmd_sys_current_role')) {
    function dmd_sys_current_role() {
        $email = dmd_sys_current_email();
        if ($email !== '') {
            $profile = dmd_sys_profile($email);
            if (!empty($profile['role_system'])) {
                return (string)$profile['role_system'];
            }
        }
        if (!empty($_SESSION['user']['role_system'])) {
            return (string)$_SESSION['user']['role_system'];
        }
        if (!empty($_SESSION['role_system'])) {
            return (string)$_SESSION['role_system'];
        }
        return 'user';
    }
}

/* =========================================================
   LOGS SYSTÈME
   /data/sys_logs/YYYY/MM/MMDD.json
   ========================================================= */
if (!function_exists('dmd_system_log_file')) {
    function dmd_system_log_file($timestamp = null) {
        $ts = $timestamp === null ? time() : (int)$timestamp;
        return DMD_SYSTEM_ROOT . '/data/sys_logs/' . date('Y', $ts) . '/' . date('m', $ts) . '/' . date('md', $ts) . '.json';
    }
}

if (!function_exists('dmd_system_log')) {
    function dmd_system_log($action, $target = '', $status = 'success', $details = '', $extra = array()) {
        $action = trim((string)$action);
        if ($action === '') {
            return false;
        }

        $email = dmd_sys_current_email();
        $profile = $email !== '' ? dmd_sys_profile($email) : array();
        $name = trim((string)(isset($profile['prenom']) ? $profile['prenom'] : '') . ' ' . (string)(isset($profile['nom']) ? $profile['nom'] : ''));
        if ($name === '') {
            $name = isset($_SESSION['user']['prenom']) ? (string)$_SESSION['user']['prenom'] : '';
        }

        $ts = time();
        $entry = array(
            'id' => 'SYS-' . date('Ymd-His', $ts) . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8)),
            'timestamp' => $ts,
            'date_iso' => date('c', $ts),
            'user' => $email,
            'user_name' => $name,
            'role_system' => dmd_sys_current_role(),
            'action' => $action,
            'target' => trim((string)$target),
            'status' => trim((string)$status) !== '' ? trim((string)$status) : 'info',
            'details' => is_scalar($details) ? (string)$details : json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : '',
            'extra' => is_array($extra) ? $extra : array(),
        );

        $file = dmd_system_log_file($ts);
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }

        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return false;
        }

        $ok = false;
        if (@flock($fp, LOCK_EX)) {
            rewind($fp);
            $raw = stream_get_contents($fp);
            $logs = array();
            if ($raw !== false && trim($raw) !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $logs = $decoded;
                }
            }
            $logs[] = $entry;
            $json = json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json !== false) {
                rewind($fp);
                ftruncate($fp, 0);
                $ok = fwrite($fp, $json) !== false;
                fflush($fp);
            }
            flock($fp, LOCK_UN);
        }
        fclose($fp);
        @chmod($file, 0640);

        // Le journal système est le bus Core des notifications configurables.
        // Les actions existantes (utilisateurs, modules, droits...) n'ont donc
        // pas besoin d'être recâblées une par une.
        if ($ok && function_exists('dmd_notifications_dispatch_system_log')) {
            try {
                dmd_notifications_dispatch_system_log($entry);
            } catch (Throwable $e) {
                // Une panne de notification ne doit jamais faire échouer l'action métier.
            }
        }

        return $ok;
    }
}

/* =========================================================
   INDEX NOTIFICATIONS
   Une construction initiale, puis mises à jour ciblées.
   ========================================================= */
if (!function_exists('dmd_notification_index_file')) {
    function dmd_notification_index_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notification_index.json';
    }
}

if (!function_exists('dmd_notification_user_modules')) {
    function dmd_notification_user_modules($email) {
        if (function_exists('dmd_effective_modules')) {
            $modules = dmd_effective_modules($email, true);
            if (is_array($modules)) {
                return array_values(array_unique(array_map('strval', array_keys($modules))));
            }
        }
        return array();
    }
}

if (!function_exists('dmd_notification_build_index')) {
    function dmd_notification_build_index() {
        $profilesDir = DMD_SYSTEM_ROOT . '/users/profiles/';
        $index = array(
            'version' => 1,
            'updated_at' => time(),
            'users' => array(),
            'role_system' => array(),
            'role_metier' => array(),
            'modules' => array(),
        );

        foreach (glob($profilesDir . '*', GLOB_ONLYDIR) ?: array() as $folder) {
            $email = dmd_sys_safe_email(basename($folder));
            if ($email === '') {
                continue;
            }
            $profile = dmd_sys_profile($email);
            if (!$profile) {
                continue;
            }
            $roleSystem = trim((string)(isset($profile['role_system']) ? $profile['role_system'] : 'user'));
            $roleMetier = trim((string)(isset($profile['role_metier']) ? $profile['role_metier'] : ''));
            $modules = dmd_notification_user_modules($email);

            $index['users'][$email] = array(
                'role_system' => $roleSystem,
                'role_metier' => $roleMetier,
                'modules' => $modules,
            );

            if (!isset($index['role_system'][$roleSystem])) {
                $index['role_system'][$roleSystem] = array();
            }
            $index['role_system'][$roleSystem][] = $email;

            if ($roleMetier !== '') {
                if (!isset($index['role_metier'][$roleMetier])) {
                    $index['role_metier'][$roleMetier] = array();
                }
                $index['role_metier'][$roleMetier][] = $email;
            }

            foreach ($modules as $moduleId) {
                if (!isset($index['modules'][$moduleId])) {
                    $index['modules'][$moduleId] = array();
                }
                $index['modules'][$moduleId][] = $email;
            }
        }

        foreach (array('role_system', 'role_metier', 'modules') as $group) {
            foreach ($index[$group] as $key => $emails) {
                $emails = array_values(array_unique(array_filter(array_map('strval', $emails))));
                sort($emails, SORT_NATURAL | SORT_FLAG_CASE);
                $index[$group][$key] = $emails;
            }
        }

        dmd_sys_json_write(dmd_notification_index_file(), $index);
        return $index;
    }
}

if (!function_exists('dmd_notification_index')) {
    function dmd_notification_index() {
        $file = dmd_notification_index_file();
        $index = dmd_sys_json_read($file, array());
        if (empty($index['users']) || !is_array($index['users'])) {
            $index = dmd_notification_build_index();
        }
        return $index;
    }
}

if (!function_exists('dmd_notification_index_refresh_user')) {
    function dmd_notification_index_refresh_user($email) {
        $email = dmd_sys_safe_email($email);
        if ($email === '') {
            return false;
        }
        $index = dmd_notification_index();

        // Retirer l'utilisateur de tous les groupes existants.
        foreach (array('role_system', 'role_metier', 'modules') as $group) {
            if (empty($index[$group]) || !is_array($index[$group])) {
                $index[$group] = array();
            }
            foreach ($index[$group] as $key => $emails) {
                if (!is_array($emails)) {
                    $emails = array();
                }
                $index[$group][$key] = array_values(array_diff($emails, array($email)));
                if (!$index[$group][$key]) {
                    unset($index[$group][$key]);
                }
            }
        }

        $profile = dmd_sys_profile($email);
        if (!$profile) {
            unset($index['users'][$email]);
        } else {
            $roleSystem = trim((string)(isset($profile['role_system']) ? $profile['role_system'] : 'user'));
            $roleMetier = trim((string)(isset($profile['role_metier']) ? $profile['role_metier'] : ''));
            $modules = dmd_notification_user_modules($email);
            $index['users'][$email] = array(
                'role_system' => $roleSystem,
                'role_metier' => $roleMetier,
                'modules' => $modules,
            );
            if (!isset($index['role_system'][$roleSystem])) {
                $index['role_system'][$roleSystem] = array();
            }
            $index['role_system'][$roleSystem][] = $email;
            if ($roleMetier !== '') {
                if (!isset($index['role_metier'][$roleMetier])) {
                    $index['role_metier'][$roleMetier] = array();
                }
                $index['role_metier'][$roleMetier][] = $email;
            }
            foreach ($modules as $moduleId) {
                if (!isset($index['modules'][$moduleId])) {
                    $index['modules'][$moduleId] = array();
                }
                $index['modules'][$moduleId][] = $email;
            }
        }

        foreach (array('role_system', 'role_metier', 'modules') as $group) {
            foreach ($index[$group] as $key => $emails) {
                $index[$group][$key] = array_values(array_unique($emails));
                sort($index[$group][$key], SORT_NATURAL | SORT_FLAG_CASE);
            }
        }
        $index['updated_at'] = time();
        return dmd_sys_json_write(dmd_notification_index_file(), $index);
    }
}

if (!function_exists('dmd_notification_index_remove_user')) {
    function dmd_notification_index_remove_user($email) {
        $email = dmd_sys_safe_email($email);
        if ($email === '') return false;
        $index = dmd_notification_index();
        unset($index['users'][$email]);
        foreach (array('role_system', 'role_metier', 'modules') as $group) {
            foreach ($index[$group] as $key => $emails) {
                $index[$group][$key] = array_values(array_diff(is_array($emails) ? $emails : array(), array($email)));
                if (!$index[$group][$key]) unset($index[$group][$key]);
            }
        }
        $index['updated_at'] = time();
        return dmd_sys_json_write(dmd_notification_index_file(), $index);
    }
}

/* =========================================================
   BOÎTE DE NOTIFICATIONS UTILISATEUR
   ========================================================= */
if (!function_exists('dmd_notification_dir')) {
    function dmd_notification_dir($email) {
        $email = dmd_sys_safe_email($email);
        return $email === '' ? '' : DMD_SYSTEM_ROOT . '/users/profiles/' . $email . '/notifications/';
    }
}

if (!function_exists('dmd_notification_ensure_dir')) {
    function dmd_notification_ensure_dir($email) {
        $dir = dmd_notification_dir($email);
        if ($dir === '') return '';
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return '';
        @chmod($dir, 0750);
        $htaccess = $dir . '.htaccess';
        $deny = "Options -Indexes
<IfModule mod_authz_core.c>
    Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
</IfModule>
";
        if (!is_file($htaccess) || @file_get_contents($htaccess) !== $deny) {
            @file_put_contents($htaccess, $deny, LOCK_EX);
            @chmod($htaccess, 0640);
        }
        return $dir;
    }
}

if (!function_exists('dmd_notification_state')) {
    function dmd_notification_state($email) {
        $dir = dmd_notification_ensure_dir($email);
        if ($dir === '') return array('unread' => 0, 'unread_ids' => array());
        $state = dmd_sys_json_read($dir . 'state.json', array('unread' => 0, 'unread_ids' => array()));
        if (!isset($state['unread_ids']) || !is_array($state['unread_ids'])) {
            $state['unread_ids'] = array();
        }
        $state['unread_ids'] = array_values(array_unique(array_map('strval', $state['unread_ids'])));
        $state['unread'] = count($state['unread_ids']);
        return $state;
    }
}

if (!function_exists('dmd_notification_write_state')) {
    function dmd_notification_write_state($email, $state) {
        $dir = dmd_notification_ensure_dir($email);
        if ($dir === '') return false;
        if (!isset($state['unread_ids']) || !is_array($state['unread_ids'])) {
            $state['unread_ids'] = array();
        }
        $state['unread_ids'] = array_values(array_unique(array_map('strval', $state['unread_ids'])));
        $state['unread'] = count($state['unread_ids']);
        $state['updated_at'] = time();
        return dmd_sys_json_write($dir . 'state.json', $state);
    }
}

if (!function_exists('dmd_notify_user')) {
    function dmd_notify_user($email, $type, $title, $message = '', $options = array()) {
        $email = dmd_sys_safe_email($email);
        if ($email === '' || !is_dir(DMD_SYSTEM_ROOT . '/users/profiles/' . $email)) {
            return false;
        }

        $dir = dmd_notification_ensure_dir($email);
        if ($dir === '') {
            return false;
        }

        $ts = time();
        $id = 'NTF-' . date('Ymd-His', $ts) . '-' . strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
        $level = isset($options['level']) ? (string)$options['level'] : 'info';
        if (!in_array($level, array('info', 'warning', 'danger', 'success'), true)) {
            $level = 'info';
        }
        $entry = array(
            'id' => $id,
            'timestamp' => $ts,
            'date_iso' => date('c', $ts),
            'type' => trim((string)$type),
            'level' => $level,
            'title' => trim((string)$title),
            'message' => trim((string)$message),
            'actor' => dmd_sys_current_email(),
            'action_url' => isset($options['action_url']) ? trim((string)$options['action_url']) : '',
            'action_label' => isset($options['action_label']) ? trim((string)$options['action_label']) : '',
            'requires_superadmin' => !empty($options['requires_superadmin']),
            'meta' => isset($options['meta']) && is_array($options['meta']) ? $options['meta'] : array(),
        );

        $line = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($line === false || @file_put_contents($dir . 'inbox.jsonl', $line . "\n", FILE_APPEND | LOCK_EX) === false) {
            return false;
        }
        @chmod($dir . 'inbox.jsonl', 0640);

        $state = dmd_notification_state($email);
        $state['unread_ids'][] = $id;
        return dmd_notification_write_state($email, $state);
    }
}

if (!function_exists('dmd_notify_many')) {
    function dmd_notify_many($emails, $type, $title, $message = '', $options = array()) {
        $count = 0;
        foreach (array_values(array_unique(is_array($emails) ? $emails : array())) as $email) {
            if (dmd_notify_user($email, $type, $title, $message, $options)) {
                $count++;
            }
        }
        return $count;
    }
}

if (!function_exists('dmd_notify_all')) {
    function dmd_notify_all($type, $title, $message = '', $options = array()) {
        $index = dmd_notification_index();
        return dmd_notify_many(array_keys(isset($index['users']) && is_array($index['users']) ? $index['users'] : array()), $type, $title, $message, $options);
    }
}

if (!function_exists('dmd_notify_system_role')) {
    function dmd_notify_system_role($role, $type, $title, $message = '', $options = array()) {
        $index = dmd_notification_index();
        $emails = isset($index['role_system'][$role]) && is_array($index['role_system'][$role]) ? $index['role_system'][$role] : array();
        return dmd_notify_many($emails, $type, $title, $message, $options);
    }
}

if (!function_exists('dmd_notify_metier')) {
    function dmd_notify_metier($role, $type, $title, $message = '', $options = array()) {
        $index = dmd_notification_index();
        $emails = isset($index['role_metier'][$role]) && is_array($index['role_metier'][$role]) ? $index['role_metier'][$role] : array();
        return dmd_notify_many($emails, $type, $title, $message, $options);
    }
}

if (!function_exists('dmd_notify_module_users')) {
    function dmd_notify_module_users($moduleId, $type, $title, $message = '', $options = array()) {
        $index = dmd_notification_index();
        $emails = isset($index['modules'][$moduleId]) && is_array($index['modules'][$moduleId]) ? $index['modules'][$moduleId] : array();
        return dmd_notify_many($emails, $type, $title, $message, $options);
    }
}

if (!function_exists('dmd_notify_superadmin_required')) {
    function dmd_notify_superadmin_required($title, $message, $actionUrl = '', $actionLabel = 'Ouvrir') {
        $options = array(
            'level' => 'danger',
            'action_url' => $actionUrl,
            'action_label' => $actionLabel,
            'requires_superadmin' => true,
        );
        $count = 0;
        $count += dmd_notify_system_role('admin', 'superadmin_required', $title, $message, $options);
        $count += dmd_notify_system_role('superadmin', 'superadmin_required', $title, $message, $options);
        return $count;
    }
}

if (!function_exists('dmd_notification_list')) {
    function dmd_notification_list($email, $limit = 80) {
        $dir = dmd_notification_ensure_dir($email);
        if ($dir === '' || !is_file($dir . 'inbox.jsonl')) {
            return array();
        }
        $lines = @file($dir . 'inbox.jsonl', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) {
            return array();
        }
        $limit = max(1, min(250, (int)$limit));
        $lines = array_slice($lines, -$limit);
        $lines = array_reverse($lines);
        $state = dmd_notification_state($email);
        $unread = array_fill_keys($state['unread_ids'], true);
        $items = array();
        foreach ($lines as $line) {
            $item = json_decode($line, true);
            if (!is_array($item) || empty($item['id'])) continue;
            $item['read'] = !isset($unread[$item['id']]);
            $items[] = $item;
        }
        return $items;
    }
}

if (!function_exists('dmd_notification_mark_read')) {
    function dmd_notification_mark_read($email, $id) {
        $id = trim((string)$id);
        if ($id === '') return false;
        $state = dmd_notification_state($email);
        $state['unread_ids'] = array_values(array_diff($state['unread_ids'], array($id)));
        return dmd_notification_write_state($email, $state);
    }
}

if (!function_exists('dmd_notification_mark_all_read')) {
    function dmd_notification_mark_all_read($email) {
        return dmd_notification_write_state($email, array('unread_ids' => array()));
    }
}


if (!function_exists('dmd_notification_clear')) {
    function dmd_notification_clear($email) {
        $dir = dmd_notification_ensure_dir($email);
        if ($dir === '') {
            return false;
        }

        $inbox = $dir . 'inbox.jsonl';
        $ok = true;

        if (is_file($inbox)) {
            $fp = @fopen($inbox, 'c+');
            if (!$fp) {
                $ok = false;
            } else {
                if (@flock($fp, LOCK_EX)) {
                    rewind($fp);
                    if (!@ftruncate($fp, 0)) {
                        $ok = false;
                    }
                    @fflush($fp);
                    @flock($fp, LOCK_UN);
                } else {
                    $ok = false;
                }
                @fclose($fp);
            }
        }

        if (!dmd_notification_write_state($email, array('unread_ids' => array()))) {
            $ok = false;
        }

        return $ok;
    }
}


/* Couche optionnelle e-mail / notifications administrables. */
$__dmdNotificationMailFile = __DIR__ . '/dmd_notification_mail.php';
if (is_file($__dmdNotificationMailFile)) {
    require_once $__dmdNotificationMailFile;
}
unset($__dmdNotificationMailFile);
