<?php
/**
 * DoMyDesk 1.2.0 - Authentification mail adaptée aux installations NAS/locales.
 *
 * - Gmail : SMTP smtp.gmail.com + mot de passe d'application Google.
 * - Microsoft : OAuth 2.0 Device Code Flow + Microsoft Graph Mail.Send.
 *
 * Aucun domaine public, callback OAuth ou serveur DoMyDesk externe n'est requis.
 */

if (!defined('DMD_SYSTEM_ROOT')) {
    define('DMD_SYSTEM_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_mail_oauth_store_file')) {
    function dmd_mail_oauth_store_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_oauth.json';
    }
}
if (!function_exists('dmd_mail_oauth_pending_file')) {
    function dmd_mail_oauth_pending_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_oauth_pending.json';
    }
}
if (!function_exists('dmd_mail_oauth_key_file')) {
    function dmd_mail_oauth_key_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_oauth.key';
    }
}
if (!function_exists('dmd_mail_oauth_key')) {
    function dmd_mail_oauth_key() {
        $file = dmd_mail_oauth_key_file();
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            if (is_string($raw) && strlen($raw) === 32) return $raw;
        }
        try { $raw = random_bytes(32); } catch (Throwable $e) { return ''; }
        if (@file_put_contents($file, $raw, LOCK_EX) === false) return '';
        @chmod($file, 0600);
        return $raw;
    }
}
if (!function_exists('dmd_mail_oauth_encrypt')) {
    function dmd_mail_oauth_encrypt($plain) {
        $plain = (string)$plain;
        if ($plain === '') return '';
        $key = dmd_mail_oauth_key();
        if ($key !== '' && function_exists('openssl_encrypt')) {
            try { $iv = random_bytes(12); } catch (Throwable $e) { $iv = ''; }
            if ($iv !== '') {
                $tag = '';
                $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
                if ($cipher !== false && $tag !== '') {
                    return 'gcm:' . base64_encode($iv) . ':' . base64_encode($tag) . ':' . base64_encode($cipher);
                }
            }
        }
        return 'plain:' . base64_encode($plain);
    }
}
if (!function_exists('dmd_mail_oauth_decrypt')) {
    function dmd_mail_oauth_decrypt($value) {
        $value = (string)$value;
        if ($value === '') return '';
        if (strpos($value, 'plain:') === 0) {
            $decoded = base64_decode(substr($value, 6), true);
            return $decoded === false ? '' : $decoded;
        }
        if (strpos($value, 'gcm:') === 0 && function_exists('openssl_decrypt')) {
            $parts = explode(':', $value, 4);
            if (count($parts) !== 4) return '';
            $iv = base64_decode($parts[1], true);
            $tag = base64_decode($parts[2], true);
            $cipher = base64_decode($parts[3], true);
            $key = dmd_mail_oauth_key();
            if ($iv === false || $tag === false || $cipher === false || $key === '') return '';
            $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            return $plain === false ? '' : $plain;
        }
        return '';
    }
}
if (!function_exists('dmd_mail_oauth_read_store')) {
    function dmd_mail_oauth_read_store() {
        $data = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(dmd_mail_oauth_store_file(), array()) : array();
        if (!is_array($data)) $data = array();
        if (!isset($data['providers']) || !is_array($data['providers'])) $data['providers'] = array();
        return $data;
    }
}
if (!function_exists('dmd_mail_oauth_write_store')) {
    function dmd_mail_oauth_write_store($data) {
        if (!function_exists('dmd_sys_json_write')) return false;
        $ok = dmd_sys_json_write(dmd_mail_oauth_store_file(), is_array($data) ? $data : array());
        if ($ok) @chmod(dmd_mail_oauth_store_file(), 0600);
        return $ok;
    }
}
if (!function_exists('dmd_mail_oauth_read_pending')) {
    function dmd_mail_oauth_read_pending() {
        $data = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(dmd_mail_oauth_pending_file(), array()) : array();
        return is_array($data) ? $data : array();
    }
}
if (!function_exists('dmd_mail_oauth_write_pending')) {
    function dmd_mail_oauth_write_pending($data) {
        if (!function_exists('dmd_sys_json_write')) return false;
        $ok = dmd_sys_json_write(dmd_mail_oauth_pending_file(), is_array($data) ? $data : array());
        if ($ok) @chmod(dmd_mail_oauth_pending_file(), 0600);
        return $ok;
    }
}


/* ---------------- Sélection du transport actif ---------------- */
if (!function_exists('dmd_mail_set_active_transport')) {
    function dmd_mail_set_active_transport($transport, $fromEmail = '', &$error = '') {
        $error = '';
        $transport = strtolower(trim((string)$transport));
        if (!in_array($transport, array('smtp', 'mail', 'gmail_app', 'microsoft_device'), true)) {
            $error = 'Transport mail invalide.';
            return false;
        }
        if (!function_exists('dmd_notifications_config') || !function_exists('dmd_notifications_save_config')) {
            $error = 'Configuration des notifications indisponible.';
            return false;
        }
        $config = dmd_notifications_config();
        if (!isset($config['smtp']) || !is_array($config['smtp'])) $config['smtp'] = array();
        $config['smtp']['transport'] = $transport;
        $fromEmail = trim((string)$fromEmail);
        if ($fromEmail !== '' && filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            $config['smtp']['from_email'] = $fromEmail;
            $config['smtp']['username'] = $fromEmail;
        }
        if (!dmd_notifications_save_config($config)) {
            $error = 'Impossible d’activer le transport mail.';
            return false;
        }
        return true;
    }
}

/* ---------------- Gmail / mot de passe d'application ---------------- */
if (!function_exists('dmd_mail_gmail_config')) {
    function dmd_mail_gmail_config() {
        $store = dmd_mail_oauth_read_store();
        $raw = isset($store['providers']['gmail']) && is_array($store['providers']['gmail']) ? $store['providers']['gmail'] : array();
        return array(
            'email' => trim((string)($raw['email'] ?? '')),
            'has_app_password' => !empty($raw['app_password']),
            'app_password' => dmd_mail_oauth_decrypt((string)($raw['app_password'] ?? '')),
            'updated_at' => trim((string)($raw['updated_at'] ?? '')),
        );
    }
}
if (!function_exists('dmd_mail_gmail_save_config')) {
    function dmd_mail_gmail_save_config($email, $appPassword, &$error) {
        $error = '';
        $email = strtolower(trim((string)$email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Adresse Gmail invalide.';
            return false;
        }
        $store = dmd_mail_oauth_read_store();
        $old = isset($store['providers']['gmail']) && is_array($store['providers']['gmail']) ? $store['providers']['gmail'] : array();
        $secret = trim(preg_replace('/\s+/', '', (string)$appPassword));
        if ($secret === '' && empty($old['app_password'])) {
            $error = 'Mot de passe d’application Google obligatoire.';
            return false;
        }
        $store['providers']['gmail'] = array(
            'email' => $email,
            'app_password' => $secret !== '' ? dmd_mail_oauth_encrypt($secret) : (string)($old['app_password'] ?? ''),
            'updated_at' => date('c'),
        );
        if (!dmd_mail_oauth_write_store($store)) {
            $error = 'Impossible d’enregistrer la configuration Gmail.';
            return false;
        }
        $transportError = '';
        if (!dmd_mail_set_active_transport('gmail_app', $email, $transportError)) {
            $error = $transportError !== '' ? $transportError : 'Gmail est enregistré mais n’a pas pu être activé.';
            return false;
        }
        return true;
    }
}
if (!function_exists('dmd_mail_gmail_clear')) {
    function dmd_mail_gmail_clear() {
        $store = dmd_mail_oauth_read_store();
        unset($store['providers']['gmail']);
        if (!dmd_mail_oauth_write_store($store)) return false;
        if (function_exists('dmd_notifications_config') && function_exists('dmd_notifications_save_config')) {
            $config = dmd_notifications_config();
            if (($config['smtp']['transport'] ?? 'smtp') === 'gmail_app') {
                $config['smtp']['transport'] = 'smtp';
                dmd_notifications_save_config($config);
            }
        }
        return true;
    }
}
if (!function_exists('dmd_mail_gmail_smtp')) {
    function dmd_mail_gmail_smtp($baseSmtp, &$error) {
        $error = '';
        $cfg = dmd_mail_gmail_config();
        if (!filter_var($cfg['email'], FILTER_VALIDATE_EMAIL) || !$cfg['has_app_password'] || $cfg['app_password'] === '') {
            $error = 'Gmail n’est pas configuré : adresse et mot de passe d’application requis.';
            return false;
        }
        $smtp = is_array($baseSmtp) ? $baseSmtp : array();
        $smtp['host'] = 'smtp.gmail.com';
        $smtp['port'] = 587;
        $smtp['encryption'] = 'tls';
        $smtp['auth'] = true;
        $smtp['auth_method'] = 'login';
        $smtp['verify_peer'] = true;
        $smtp['username'] = $cfg['email'];
        $smtp['password'] = $cfg['app_password'];
        $smtp['from_email'] = $cfg['email'];
        return $smtp;
    }
}

/* ---------------- HTTP helpers Microsoft Device Code ---------------- */
if (!function_exists('dmd_mail_oauth_http_form_raw')) {
    function dmd_mail_oauth_http_form_raw($url, $fields, &$error, &$httpCode) {
        $error = '';
        $httpCode = 0;
        $body = http_build_query(is_array($fields) ? $fields : array(), '', '&', PHP_QUERY_RFC3986);
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'),
                CURLOPT_USERAGENT => 'DoMyDesk-Mail/1.2.0',
            ));
            $raw = curl_exec($ch);
            $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($raw === false) { $error = 'Connexion Microsoft impossible : ' . $curlError; return false; }
            $data = json_decode((string)$raw, true);
            if (!is_array($data)) { $error = 'Réponse Microsoft invalide.'; return false; }
            return $data;
        }
        $ctx = stream_context_create(array('http' => array(
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\nUser-Agent: DoMyDesk-Mail/1.2.0\r\n",
            'content' => $body,
            'timeout' => 25,
            'ignore_errors' => true,
        )));
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) { $error = 'Connexion Microsoft impossible.'; return false; }
        foreach ((array)($http_response_header ?? array()) as $header) {
            if (preg_match('~^HTTP/\S+\s+(\d+)~', $header, $m)) { $httpCode = (int)$m[1]; break; }
        }
        $data = json_decode((string)$raw, true);
        if (!is_array($data)) { $error = 'Réponse Microsoft invalide.'; return false; }
        return $data;
    }
}
if (!function_exists('dmd_mail_oauth_http_get_json')) {
    function dmd_mail_oauth_http_get_json($url, $token, &$error) {
        $error = '';
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_HTTPHEADER => array('Authorization: Bearer ' . $token, 'Accept: application/json'),
                CURLOPT_USERAGENT => 'DoMyDesk-Mail/1.2.0',
            ));
            $raw = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($raw === false) { $error = 'Connexion Microsoft Graph impossible : ' . $curlError; return false; }
            $data = json_decode((string)$raw, true);
            if ($code < 200 || $code >= 300) {
                $error = 'Microsoft Graph HTTP ' . $code;
                if (is_array($data) && !empty($data['error']['message'])) $error .= ' : ' . (string)$data['error']['message'];
                return false;
            }
            return is_array($data) ? $data : array();
        }
        $ctx = stream_context_create(array('http' => array(
            'method' => 'GET',
            'header' => "Authorization: Bearer " . $token . "\r\nAccept: application/json\r\nUser-Agent: DoMyDesk-Mail/1.2.0\r\n",
            'timeout' => 25,
            'ignore_errors' => true,
        )));
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) { $error = 'Connexion Microsoft Graph impossible.'; return false; }
        $data = json_decode((string)$raw, true);
        if (!is_array($data)) { $error = 'Réponse Microsoft Graph invalide.'; return false; }
        return $data;
    }
}
if (!function_exists('dmd_mail_oauth_http_json')) {
    function dmd_mail_oauth_http_json($url, $method, $payload, &$error, $headers = array()) {
        $error = '';
        $body = json_encode(is_array($payload) ? $payload : array(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($body === false) { $error = 'JSON invalide.'; return false; }
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_CUSTOMREQUEST => strtoupper((string)$method),
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => array_merge(array('Content-Type: application/json', 'Accept: application/json'), (array)$headers),
                CURLOPT_USERAGENT => 'DoMyDesk-Mail/1.2.0',
            ));
            $raw = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($raw === false) { $error = 'Connexion Microsoft Graph impossible : ' . $curlError; return false; }
            $data = json_decode((string)$raw, true);
            if ($code < 200 || $code >= 300) {
                $error = 'Microsoft Graph HTTP ' . $code;
                if (is_array($data) && !empty($data['error']['message'])) $error .= ' : ' . (string)$data['error']['message'];
                return false;
            }
            return is_array($data) ? $data : array('ok'=>true);
        }
        $ctx = stream_context_create(array('http' => array(
            'method' => strtoupper((string)$method),
            'header' => implode("\r\n", array_merge(array('Content-Type: application/json','Accept: application/json','User-Agent: DoMyDesk-Mail/1.2.0'), (array)$headers)) . "\r\n",
            'content' => $body,
            'timeout' => 25,
            'ignore_errors' => true,
        )));
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw === false) { $error = 'Connexion Microsoft Graph impossible.'; return false; }
        $status = 0;
        foreach ((array)($http_response_header ?? array()) as $header) {
            if (preg_match('~^HTTP/\S+\s+(\d+)~', $header, $m)) { $status = (int)$m[1]; break; }
        }
        if ($status < 200 || $status >= 300) { $error = 'Microsoft Graph HTTP ' . $status; return false; }
        $data = json_decode((string)$raw, true);
        return is_array($data) ? $data : array('ok'=>true);
    }
}

if (!function_exists('dmd_mail_microsoft_config')) {
    function dmd_mail_microsoft_config() {
        $config = function_exists('dmd_notifications_config') ? dmd_notifications_config() : array();
        $raw = isset($config['oauth']['microsoft']) && is_array($config['oauth']['microsoft']) ? $config['oauth']['microsoft'] : array();
        return array(
            'client_id' => trim((string)($raw['client_id'] ?? '')),
            'tenant' => trim((string)($raw['tenant'] ?? 'common')) ?: 'common',
        );
    }
}
if (!function_exists('dmd_mail_microsoft_save_config')) {
    function dmd_mail_microsoft_save_config($clientId, $tenant, &$error) {
        $error = '';
        $clientId = trim((string)$clientId);
        $tenant = trim((string)$tenant);
        if ($clientId === '') { $error = 'Application (Client) ID Microsoft obligatoire.'; return false; }
        if ($tenant === '') $tenant = 'common';
        if (!preg_match('/^[a-zA-Z0-9._-]+$/', $tenant)) { $error = 'Tenant Microsoft invalide.'; return false; }
        if (!function_exists('dmd_notifications_config') || !function_exists('dmd_notifications_save_config')) { $error = 'Configuration indisponible.'; return false; }
        $config = dmd_notifications_config();
        if (!isset($config['oauth']) || !is_array($config['oauth'])) $config['oauth'] = array();
        $config['oauth']['microsoft'] = array('client_id'=>$clientId,'tenant'=>$tenant);
        return dmd_notifications_save_config($config);
    }
}
if (!function_exists('dmd_mail_microsoft_status')) {
    function dmd_mail_microsoft_status() {
        $cfg = dmd_mail_microsoft_config();
        $store = dmd_mail_oauth_read_store();
        $item = isset($store['providers']['microsoft']) && is_array($store['providers']['microsoft']) ? $store['providers']['microsoft'] : array();
        return array(
            'configured' => $cfg['client_id'] !== '',
            'connected' => !empty($item['refresh_token']),
            'email' => trim((string)($item['email'] ?? '')),
            'display_name' => trim((string)($item['display_name'] ?? '')),
            'connected_at' => trim((string)($item['connected_at'] ?? '')),
        );
    }
}
if (!function_exists('dmd_mail_microsoft_disconnect')) {
    function dmd_mail_microsoft_disconnect() {
        $store = dmd_mail_oauth_read_store();
        unset($store['providers']['microsoft']);
        dmd_mail_oauth_write_pending(array());
        if (!dmd_mail_oauth_write_store($store)) return false;
        if (function_exists('dmd_notifications_config') && function_exists('dmd_notifications_save_config')) {
            $config = dmd_notifications_config();
            if (($config['smtp']['transport'] ?? 'smtp') === 'microsoft_device') {
                $config['smtp']['transport'] = 'smtp';
                dmd_notifications_save_config($config);
            }
        }
        return true;
    }
}
if (!function_exists('dmd_mail_microsoft_device_start')) {
    function dmd_mail_microsoft_device_start(&$error) {
        $error = '';
        $cfg = dmd_mail_microsoft_config();
        if ($cfg['client_id'] === '') { $error = 'Configure d’abord le Client ID Microsoft.'; return false; }
        $scope = 'offline_access https://graph.microsoft.com/User.Read https://graph.microsoft.com/Mail.Send';
        $code = 0;
        $reply = dmd_mail_oauth_http_form_raw(
            'https://login.microsoftonline.com/' . rawurlencode($cfg['tenant']) . '/oauth2/v2.0/devicecode',
            array('client_id'=>$cfg['client_id'],'scope'=>$scope),
            $error,
            $code
        );
        if ($reply === false || $code < 200 || $code >= 300 || empty($reply['device_code']) || empty($reply['user_code']) || empty($reply['verification_uri'])) {
            if ($error === '' && is_array($reply)) $error = (string)($reply['error_description'] ?? $reply['error'] ?? 'Impossible de démarrer la connexion Microsoft.');
            return false;
        }
        $pending = array(
            'device_code' => dmd_mail_oauth_encrypt((string)$reply['device_code']),
            'user_code' => (string)$reply['user_code'],
            'verification_uri' => (string)$reply['verification_uri'],
            'expires_at' => time() + max(60, (int)($reply['expires_in'] ?? 900)),
            'interval' => max(5, (int)($reply['interval'] ?? 5)),
            'tenant' => $cfg['tenant'],
            'client_id' => $cfg['client_id'],
            'scope' => $scope,
            'started_at' => time(),
        );
        if (!dmd_mail_oauth_write_pending($pending)) { $error = 'Impossible d’enregistrer la connexion Microsoft en attente.'; return false; }
        return array(
            'user_code'=>$pending['user_code'],
            'verification_uri'=>$pending['verification_uri'],
            'expires_in'=>max(0, $pending['expires_at'] - time()),
            'interval'=>$pending['interval'],
            'message'=>(string)($reply['message'] ?? ''),
        );
    }
}
if (!function_exists('dmd_mail_microsoft_device_poll')) {
    function dmd_mail_microsoft_device_poll(&$error) {
        $error = '';
        $pending = dmd_mail_oauth_read_pending();
        if (empty($pending['device_code']) || empty($pending['client_id']) || empty($pending['tenant'])) {
            $error = 'Aucune connexion Microsoft en attente.';
            return array('status'=>'missing');
        }
        if ((int)($pending['expires_at'] ?? 0) <= time()) {
            dmd_mail_oauth_write_pending(array());
            $error = 'Le code Microsoft a expiré. Recommence la connexion.';
            return array('status'=>'expired');
        }
        $deviceCode = dmd_mail_oauth_decrypt((string)$pending['device_code']);
        if ($deviceCode === '') { $error = 'Code Microsoft illisible.'; return array('status'=>'error'); }
        $httpCode = 0;
        $reply = dmd_mail_oauth_http_form_raw(
            'https://login.microsoftonline.com/' . rawurlencode((string)$pending['tenant']) . '/oauth2/v2.0/token',
            array(
                'grant_type'=>'urn:ietf:params:oauth:grant-type:device_code',
                'client_id'=>(string)$pending['client_id'],
                'device_code'=>$deviceCode,
            ),
            $error,
            $httpCode
        );
        if ($reply === false) return array('status'=>'error');
        if (!empty($reply['error'])) {
            $kind = (string)$reply['error'];
            if ($kind === 'authorization_pending') return array('status'=>'pending','interval'=>(int)($pending['interval'] ?? 5));
            if ($kind === 'slow_down') return array('status'=>'pending','interval'=>max(5,(int)($pending['interval'] ?? 5)+5));
            if ($kind === 'authorization_declined') { dmd_mail_oauth_write_pending(array()); $error = 'Connexion Microsoft refusée.'; return array('status'=>'declined'); }
            if ($kind === 'expired_token' || $kind === 'bad_verification_code') { dmd_mail_oauth_write_pending(array()); $error = 'Code Microsoft expiré ou invalide.'; return array('status'=>'expired'); }
            $error = (string)($reply['error_description'] ?? $kind);
            return array('status'=>'error');
        }
        if (empty($reply['access_token']) || empty($reply['refresh_token'])) {
            $error = 'Microsoft n’a pas renvoyé les jetons attendus.';
            return array('status'=>'error');
        }
        $access = (string)$reply['access_token'];
        $profile = dmd_mail_oauth_http_get_json('https://graph.microsoft.com/v1.0/me?$select=mail,userPrincipalName,displayName', $access, $error);
        if ($profile === false) return array('status'=>'error');
        $email = trim((string)($profile['mail'] ?? $profile['userPrincipalName'] ?? ''));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $error = 'Adresse du compte Microsoft introuvable.'; return array('status'=>'error'); }
        $store = dmd_mail_oauth_read_store();
        $store['providers']['microsoft'] = array(
            'email'=>$email,
            'display_name'=>trim((string)($profile['displayName'] ?? '')),
            'access_token'=>dmd_mail_oauth_encrypt($access),
            'refresh_token'=>dmd_mail_oauth_encrypt((string)$reply['refresh_token']),
            'expires_at'=>time()+max(60,(int)($reply['expires_in'] ?? 3600)),
            'scope'=>trim((string)($reply['scope'] ?? '')),
            'connected_at'=>date('c'),
        );
        if (!dmd_mail_oauth_write_store($store)) { $error = 'Impossible d’enregistrer les jetons Microsoft.'; return array('status'=>'error'); }
        $transportError = '';
        if (!dmd_mail_set_active_transport('microsoft_device', $email, $transportError)) {
            $error = $transportError !== '' ? $transportError : 'Microsoft est connecté mais n’a pas pu être activé.';
            return array('status'=>'error');
        }
        dmd_mail_oauth_write_pending(array());
        return array('status'=>'connected','email'=>$email,'display_name'=>trim((string)($profile['displayName'] ?? '')));
    }
}
if (!function_exists('dmd_mail_microsoft_access_token')) {
    function dmd_mail_microsoft_access_token(&$error) {
        $error = '';
        $store = dmd_mail_oauth_read_store();
        $item = isset($store['providers']['microsoft']) && is_array($store['providers']['microsoft']) ? $store['providers']['microsoft'] : array();
        if (empty($item['refresh_token'])) { $error = 'Compte Microsoft non connecté.'; return ''; }
        $access = dmd_mail_oauth_decrypt((string)($item['access_token'] ?? ''));
        if ($access !== '' && (int)($item['expires_at'] ?? 0) > time()+120) return $access;
        $refresh = dmd_mail_oauth_decrypt((string)$item['refresh_token']);
        if ($refresh === '') { $error = 'Jeton Microsoft illisible.'; return ''; }
        $cfg = dmd_mail_microsoft_config();
        if ($cfg['client_id'] === '') { $error = 'Client ID Microsoft absent.'; return ''; }
        $httpCode = 0;
        $reply = dmd_mail_oauth_http_form_raw(
            'https://login.microsoftonline.com/' . rawurlencode($cfg['tenant']) . '/oauth2/v2.0/token',
            array(
                'client_id'=>$cfg['client_id'],
                'refresh_token'=>$refresh,
                'grant_type'=>'refresh_token',
                'scope'=>'offline_access https://graph.microsoft.com/User.Read https://graph.microsoft.com/Mail.Send',
            ),
            $error,
            $httpCode
        );
        if ($reply === false || $httpCode < 200 || $httpCode >= 300 || empty($reply['access_token'])) {
            if ($error === '' && is_array($reply)) $error = (string)($reply['error_description'] ?? $reply['error'] ?? 'Renouvellement Microsoft impossible.');
            return '';
        }
        $item['access_token'] = dmd_mail_oauth_encrypt((string)$reply['access_token']);
        $item['expires_at'] = time()+max(60,(int)($reply['expires_in'] ?? 3600));
        if (!empty($reply['refresh_token'])) $item['refresh_token'] = dmd_mail_oauth_encrypt((string)$reply['refresh_token']);
        if (!empty($reply['scope'])) $item['scope'] = trim((string)$reply['scope']);
        $store['providers']['microsoft'] = $item;
        dmd_mail_oauth_write_store($store);
        return (string)$reply['access_token'];
    }
}
if (!function_exists('dmd_mail_microsoft_send')) {
    function dmd_mail_microsoft_send($to, $subject, $body, $smtp, &$error) {
        $error = '';
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) { $error = 'Destinataire invalide.'; return false; }
        $token = dmd_mail_microsoft_access_token($error);
        if ($token === '') return false;
        $reply = dmd_mail_oauth_http_json(
            'https://graph.microsoft.com/v1.0/me/sendMail',
            'POST',
            array(
                'message'=>array(
                    'subject'=>(string)$subject,
                    'body'=>array('contentType'=>'Text','content'=>(string)$body),
                    'toRecipients'=>array(array('emailAddress'=>array('address'=>$to))),
                ),
                'saveToSentItems'=>true,
            ),
            $error,
            array('Authorization: Bearer '.$token)
        );
        return $reply !== false;
    }
}
