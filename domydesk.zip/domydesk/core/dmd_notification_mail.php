<?php
/**
 * DoMyDesk 1.2.0 - Moteur central de notifications configurables + e-mail.
 *
 * Aucun module ne stocke de paramètres SMTP : il déclare uniquement ses événements
 * dans dmd_module.json et appelle dmd_notification_emit().
 */

if (!defined('DMD_SYSTEM_ROOT')) {
    define('DMD_SYSTEM_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_notifications_config_file')) {
    function dmd_notifications_config_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_config.json';
    }
}

if (!function_exists('dmd_notifications_secret_key_file')) {
    function dmd_notifications_secret_key_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_mail.key';
    }
}

if (!function_exists('dmd_notifications_secret_key')) {
    function dmd_notifications_secret_key($create = true) {
        $file = dmd_notifications_secret_key_file();
        if (is_file($file)) {
            $key = @file_get_contents($file);
            if (is_string($key) && strlen($key) === 32) {
                @chmod($file, 0600);
                return $key;
            }
            return false;
        }
        if (!$create) return false;
        if (!function_exists('random_bytes')) return false;
        try {
            $key = random_bytes(32);
        } catch (Throwable $e) {
            return false;
        }
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        @chmod($dir, 0750);
        $handle = @fopen($file, 'xb');
        if ($handle === false) {
            if (is_file($file)) {
                $existing = @file_get_contents($file);
                return is_string($existing) && strlen($existing) === 32 ? $existing : false;
            }
            return false;
        }
        $written = @fwrite($handle, $key);
        @fclose($handle);
        if ($written !== 32) {
            @unlink($file);
            return false;
        }
        @chmod($file, 0600);
        return $key;
    }
}

if (!function_exists('dmd_notifications_secret_is_encrypted')) {
    function dmd_notifications_secret_is_encrypted($value) {
        return is_string($value) && strpos($value, 'ENCv1:') === 0;
    }
}

if (!function_exists('dmd_notifications_secret_encrypt')) {
    function dmd_notifications_secret_encrypt($plain) {
        $plain = (string)$plain;
        if ($plain === '') return '';
        if (dmd_notifications_secret_is_encrypted($plain)) return $plain;
        if (!function_exists('openssl_encrypt')) return false;
        $key = dmd_notifications_secret_key(true);
        if ($key === false) return false;
        try {
            $iv = random_bytes(12);
        } catch (Throwable $e) {
            return false;
        }
        $tag = '';
        $cipher = @openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
        if ($cipher === false || !is_string($tag) || strlen($tag) !== 16) return false;
        return 'ENCv1:' . base64_encode($iv . $tag . $cipher);
    }
}

if (!function_exists('dmd_notifications_secret_decrypt')) {
    function dmd_notifications_secret_decrypt($stored) {
        $stored = (string)$stored;
        if ($stored === '') return '';
        if (!dmd_notifications_secret_is_encrypted($stored)) return $stored;
        if (!function_exists('openssl_decrypt')) return false;
        $key = dmd_notifications_secret_key(false);
        if ($key === false) return false;
        $raw = base64_decode(substr($stored, 6), true);
        if ($raw === false || strlen($raw) < 29) return false;
        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $cipher = substr($raw, 28);
        $plain = @openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '');
        return $plain === false ? false : $plain;
    }
}

if (!function_exists('dmd_notifications_storage_prepare')) {
    function dmd_notifications_storage_prepare($config) {
        if (!is_array($config)) return false;
        if (!isset($config['smtp']) || !is_array($config['smtp'])) $config['smtp'] = array();
        $password = (string)($config['smtp']['password'] ?? '');
        if ($password !== '') {
            $encrypted = dmd_notifications_secret_encrypt($password);
            if ($encrypted === false) return false;
            $config['smtp']['password'] = $encrypted;
        } else {
            $config['smtp']['password'] = '';
        }
        return $config;
    }
}

if (!function_exists('dmd_notifications_queue_file')) {
    function dmd_notifications_queue_file() {
        return DMD_SYSTEM_ROOT . '/data/secure/notifications_mail_queue.json';
    }
}

if (!function_exists('dmd_notifications_mail_log_file')) {
    function dmd_notifications_mail_log_file() {
        return DMD_SYSTEM_ROOT . '/data/sys_logs/notifications_mail.jsonl';
    }
}

if (!function_exists('dmd_notifications_default_config')) {
    function dmd_notifications_default_config() {
        return array(
            'version' => 1,
            'global_enabled' => true,
            'internal_enabled' => true,
            'email_enabled' => false,
            'instance_urls' => array(
                'public_url' => '',
                'internal_url' => '',
            ),
            'smtp' => array(
                'transport' => 'smtp',
                'provider' => 'custom',
                'host' => '',
                'port' => 587,
                'encryption' => 'tls',
                'auth' => true,
                'auth_method' => 'auto',
                'verify_peer' => true,
                'username' => '',
                'password' => '',
                'from_email' => '',
                'from_name' => 'DoMyDesk',
                'timeout' => 15,
            ),
            'events' => array(),
            'updated_at' => '',
            'updated_by' => '',
        );
    }
}

if (!function_exists('dmd_notifications_merge_assoc')) {
    function dmd_notifications_merge_assoc($base, $override) {
        if (!is_array($base)) $base = array();
        if (!is_array($override)) return $base;
        foreach ($override as $key => $value) {
            if (isset($base[$key]) && is_array($base[$key]) && is_array($value)) {
                $base[$key] = dmd_notifications_merge_assoc($base[$key], $value);
            } else {
                $base[$key] = $value;
            }
        }
        return $base;
    }
}

if (!function_exists('dmd_notifications_prune_orphan_events')) {
    /**
     * Supprime de la configuration les réglages d'événements qui ne sont plus
     * déclarés par le Core ni par aucun dmd_module.json actuellement installé.
     *
     * Cela évite que notifications_config.json conserve indéfiniment les anciennes
     * actions après suppression/renommage d'une action ou désinstallation d'un module.
     */
    function dmd_notifications_prune_orphan_events($config, $registry = null, &$removed = array()) {
        $removed = array();
        if (!is_array($config)) return array();
        if (!isset($config['events']) || !is_array($config['events'])) {
            $config['events'] = array();
            return $config;
        }

        if ($registry === null) {
            $registry = function_exists('dmd_notifications_registry')
                ? dmd_notifications_registry()
                : array();
        }
        if (!is_array($registry) || !$registry) return $config;

        $valid = array_fill_keys(array_map('strval', array_keys($registry)), true);
        foreach (array_keys($config['events']) as $eventKey) {
            $eventKey = (string)$eventKey;
            if (!isset($valid[$eventKey])) {
                unset($config['events'][$eventKey]);
                $removed[] = $eventKey;
            }
        }
        return $config;
    }
}

if (!function_exists('dmd_notifications_config')) {
    function dmd_notifications_config() {
        $defaults = dmd_notifications_default_config();
        $file = dmd_notifications_config_file();
        $stored = function_exists('dmd_sys_json_read') ? dmd_sys_json_read($file, array()) : array();
        if (!is_array($stored)) $stored = array();

        // Migration automatique : un ancien mot de passe SMTP en clair est chiffré
        // immédiatement dans notifications_config.json. La valeur déchiffrée n'existe
        // ensuite qu'en mémoire pour la durée de la requête PHP.
        $storedPassword = isset($stored['smtp']) && is_array($stored['smtp'])
            ? (string)($stored['smtp']['password'] ?? '')
            : '';
        $runtimePassword = '';
        if ($storedPassword !== '') {
            if (dmd_notifications_secret_is_encrypted($storedPassword)) {
                $decrypted = dmd_notifications_secret_decrypt($storedPassword);
                $runtimePassword = $decrypted === false ? '' : $decrypted;
            } else {
                $runtimePassword = $storedPassword;
                $migrated = $stored;
                if (!isset($migrated['smtp']) || !is_array($migrated['smtp'])) $migrated['smtp'] = array();
                $encrypted = dmd_notifications_secret_encrypt($storedPassword);
                if ($encrypted !== false && function_exists('dmd_sys_json_write')) {
                    $migrated['smtp']['password'] = $encrypted;
                    if (dmd_sys_json_write($file, $migrated)) @chmod($file, 0600);
                }
            }
        }

        // Nettoyage automatique des anciennes actions/événements devenus orphelins.
        // On travaille sur la version stockée (mot de passe encore chiffré) afin de
        // ne jamais réécrire le secret SMTP en clair pendant ce ménage.
        $removedEvents = array();
        $cleanStored = dmd_notifications_prune_orphan_events($stored, null, $removedEvents);
        if ($removedEvents && function_exists('dmd_sys_json_write')) {
            if (dmd_sys_json_write($file, $cleanStored)) {
                @chmod($file, 0600);
                $stored = $cleanStored;
            }
        }

        // Migration ciblée du tout premier modèle « Utilisateur créé ».
        // On ne remplace que le texte historique exact afin de ne jamais écraser
        // un modèle personnalisé par l'administrateur.
        $legacyUserCreatedBody = "Un compte DoMyDesk vient d’être créé.\n\nUtilisateur : {target}\nNom : {prenom} {nom}\nRôle système : {role_system}\nRôle métier : {role_metier}\nCréé par : {user}\nDate : {date} {time}";
        $modernUserCreatedBody = "Un nouveau compte DoMyDesk vient d’être créé sur {instance_name}.\n\nINFORMATIONS DU COMPTE\nUtilisateur : {target}\nNom : {prenom} {nom}\nRôle système : {role_system}\nRôle métier : {role_metier}\n\nACCÈS À DOMYDESK\n{access_urls}\n\nCréé par : {user_name} ({user})\nDate : {date} à {time}\n\nVous pouvez vous connecter à DoMyDesk avec l’une des adresses ci-dessus selon votre emplacement.";
        if (isset($stored['events']['core.user_created']['email_body'])) {
            $storedBody = str_replace("\r\n", "\n", (string)$stored['events']['core.user_created']['email_body']);
            if ($storedBody === $legacyUserCreatedBody) {
                $stored['events']['core.user_created']['email_body'] = $modernUserCreatedBody;
                if (function_exists('dmd_sys_json_write') && dmd_sys_json_write($file, $stored)) @chmod($file, 0600);
            }
        }

        $config = dmd_notifications_merge_assoc($defaults, $stored);
        if (!isset($config['smtp']) || !is_array($config['smtp'])) $config['smtp'] = $defaults['smtp'];
        $config['smtp']['password'] = $runtimePassword;

        $legacyTransport = strtolower(trim((string)($config['smtp']['transport'] ?? 'smtp')));
        if (in_array($legacyTransport, array('gmail_app','google_oauth'), true)) {
            $config['smtp']['transport'] = 'smtp';
            $config['smtp']['provider'] = 'gmail';
        } elseif (in_array($legacyTransport, array('microsoft_device','microsoft_oauth'), true)) {
            $config['smtp']['transport'] = 'smtp';
            $config['smtp']['provider'] = 'microsoft';
        } elseif (!in_array($legacyTransport, array('smtp','mail'), true)) {
            $config['smtp']['transport'] = 'smtp';
        }
        if (empty($config['smtp']['provider'])) $config['smtp']['provider'] = 'custom';
        return $config;
    }
}

if (!function_exists('dmd_notifications_save_config')) {
    function dmd_notifications_save_config($config) {
        if (!is_array($config)) return false;
        // Même protection lors d'un enregistrement manuel : seules les entrées
        // encore présentes dans le registre courant sont persistées.
        $removedEvents = array();
        $config = dmd_notifications_prune_orphan_events($config, null, $removedEvents);

        $config['version'] = 1;
        $config['updated_at'] = date('c');
        $config['updated_by'] = function_exists('dmd_sys_current_email') ? dmd_sys_current_email() : '';
        if (!function_exists('dmd_sys_json_write')) return false;

        $storageConfig = dmd_notifications_storage_prepare($config);
        if ($storageConfig === false) return false;

        $ok = dmd_sys_json_write(dmd_notifications_config_file(), $storageConfig);
        if ($ok) @chmod(dmd_notifications_config_file(), 0600);
        return $ok;
    }
}



if (!function_exists('dmd_notifications_definition')) {
    function dmd_notifications_definition($key, $moduleId, $moduleName, $id, $label, $description = '', $variables = array(), $defaults = array()) {
        $baseVariables = array(
            'instance_name','instance_id','instance_url','instance_url_internet','instance_url_internal','access_urls',
            'module','module_id','event','event_id',
            'user','user_name','role_system','target','target_user','status','details',
            'date','time','recipient','source','version','storage_scope','meta','changes','extra'
        );
        $variables = array_values(array_unique(array_merge($baseVariables, array_map('strval', is_array($variables) ? $variables : array()))));
        $defaults = dmd_notifications_merge_assoc(array(
            'internal' => false,
            'email' => false,
            'recipients' => array('admins','superadmins'),
            'custom_emails' => '',
            'internal_title' => $label,
            'internal_message' => '{user} : ' . $label . ' — {target}',
            'email_subject' => '[{instance_name}] ' . $label,
            'email_body' => "Événement : {event}\nCible : {target}\nUtilisateur : {user}\nDate : {date} {time}\n\n{details}",
        ), is_array($defaults) ? $defaults : array());

        return array(
            'key' => strtolower(trim((string)$key)),
            'module_id' => trim((string)$moduleId),
            'module_name' => trim((string)$moduleName),
            'id' => trim((string)$id),
            'label' => trim((string)$label),
            'description' => trim((string)$description),
            'variables' => $variables,
            'defaults' => $defaults,
        );
    }
}

if (!function_exists('dmd_notifications_builtin_registry')) {
    function dmd_notifications_builtin_registry() {
        $events = array(
            'user_created' => array('Utilisateurs', 'Utilisateur créé', 'Déclenché après la création réussie d’un compte DoMyDesk.', array('prenom','nom','role_metier')),
            'user_deleted' => array('Utilisateurs', 'Utilisateur supprimé', 'Déclenché après la suppression réussie d’un compte DoMyDesk.', array('prenom','nom','role_metier')),
            'user_roles_updated' => array('Utilisateurs', 'Rôles d’un utilisateur modifiés', 'Déclenché après une modification des rôles système ou métier.', array('role_metier')),
            'users_roles_bulk_updated' => array('Utilisateurs', 'Rôles utilisateurs modifiés', 'Déclenché après l’enregistrement groupé des rôles utilisateurs.', array('users')),
            'user_module_permissions_updated' => array('Droits', 'Droits modules d’un utilisateur modifiés', 'Déclenché après une modification des exceptions modules d’un utilisateur.', array('rules','changes')),
            'role_module_permissions_updated' => array('Droits', 'Droits modules d’un rôle modifiés', 'Déclenché après une modification des droits modules d’un rôle métier.', array('rules','changes')),
            'global_module_rights_updated' => array('Droits', 'Droits globaux des modules modifiés', 'Déclenché après une modification des règles globales d’accès aux modules.', array('global_modules')),
            'user_page_permissions_updated' => array('Droits', 'Droits pages d’un utilisateur modifiés', 'Déclenché après une modification des exceptions de pages d’un utilisateur.', array('overrides')),
            'role_page_permissions_updated' => array('Droits', 'Droits pages d’un rôle modifiés', 'Déclenché après une modification des pages autorisées d’un rôle métier.', array('pages')),
            'global_page_rights_updated' => array('Droits', 'Droits globaux des pages modifiés', 'Déclenché après une modification des règles globales d’accès aux pages.', array('global_pages')),
            'business_role_added' => array('Utilisateurs', 'Rôle métier créé', 'Déclenché lorsqu’un rôle métier est créé.', array()),
            'business_role_deleted' => array('Utilisateurs', 'Rôle métier supprimé', 'Déclenché lorsqu’un rôle métier est supprimé.', array()),
            'default_business_role_updated' => array('Utilisateurs', 'Rôle métier par défaut modifié', 'Déclenché lorsque le rôle métier attribué par défaut est modifié.', array()),
            'registration_pending' => array('Utilisateurs', 'Nouvelle inscription à valider', 'Déclenché lorsqu’un utilisateur s’inscrit et que la validation administrateur est requise.', array('prenom','nom','role_metier')),
            'registration_pending_user' => array('Utilisateurs', 'Inscription reçue — en attente', 'Déclenché pour informer l’utilisateur que son inscription a bien été reçue et attend une validation.', array('prenom','nom','role_metier')),
            'registration_activated_user' => array('Utilisateurs', 'Inscription activée automatiquement', 'Déclenché pour informer l’utilisateur que son compte a été activé immédiatement après son inscription.', array('prenom','nom','role_metier')),
            'registration_approved_user' => array('Utilisateurs', 'Inscription validée', 'Déclenché lorsqu’un administrateur valide une inscription en attente.', array('prenom','nom','role_metier')),
            'registration_refused_user' => array('Utilisateurs', 'Inscription refusée — utilisateur', 'Déclenché lorsqu’un administrateur refuse une inscription en attente et informe l’utilisateur.', array('prenom','nom','role_metier')),
            'registration_refused_admin' => array('Utilisateurs', 'Inscription refusée — Superadmin', 'Déclenché lorsqu’un administrateur refuse une inscription et que le compte est supprimé.', array('prenom','nom','role_metier')),
            'module_installed' => array('Modules', 'Module installé', 'Déclenché après l’installation réussie d’un module.', array('storage_scope')),
            'module_removed' => array('Modules', 'Module supprimé', 'Déclenché après la désinstallation réussie d’un module.', array('mode','storage_scope')),
            'module_deleted' => array('Modules', 'Module supprimé depuis l’administration', 'Déclenché après la suppression réussie d’un module depuis l’administration.', array()),
            'module_update_installed' => array('Modules', 'Module mis à jour', 'Déclenché après une mise à jour de module installée depuis le catalogue.', array('titre','modules','versions','files')),
            'module_update_installed_manual' => array('Modules', 'Module mis à jour manuellement', 'Déclenché après une mise à jour de module installée depuis un ZIP manuel.', array('modules','versions','files')),
        );

        $registry = array();
        foreach ($events as $action => $info) {
            $category = $info[0];
            $label = $info[1];
            $description = $info[2];
            $variables = $info[3];
            $key = 'core.' . strtolower($action);
            $defaults = array();
            if ($action === 'user_created') {
                $defaults = array(
                    'recipients' => array('admins','superadmins'),
                    'internal_title' => 'Nouvel utilisateur : {target}',
                    'internal_message' => '{user} a créé le compte {target}.',
                    'email_subject' => '[{instance_name}] Nouvel utilisateur : {target}',
                    'email_body' => "Un nouveau compte DoMyDesk vient d’être créé sur {instance_name}.\n\nINFORMATIONS DU COMPTE\nUtilisateur : {target}\nNom : {prenom} {nom}\nRôle système : {role_system}\nRôle métier : {role_metier}\n\nACCÈS À DOMYDESK\n{access_urls}\n\nCréé par : {user_name} ({user})\nDate : {date} à {time}\n\nVous pouvez vous connecter à DoMyDesk avec l’une des adresses ci-dessus selon votre emplacement.",
                );
            } elseif ($action === 'user_deleted') {
                $defaults = array(
                    'recipients' => array('admins','superadmins'),
                    'internal_title' => 'Utilisateur supprimé : {target}',
                    'internal_message' => '{user} a supprimé le compte {target}.',
                    'email_subject' => '[{instance_name}] Utilisateur supprimé : {target}',
                    'email_body' => "Un compte DoMyDesk vient d’être supprimé.\n\nUtilisateur : {target}\nNom : {prenom} {nom}\nRôle système : {role_system}\nRôle métier : {role_metier}\nSupprimé par : {user}\nDate : {date} {time}",
                );
            } elseif ($action === 'registration_pending') {
                $defaults = array(
                    'internal' => true,
                    'email' => true,
                    'recipients' => array('admins','superadmins'),
                    'internal_title' => 'Nouvelle inscription à valider : {target}',
                    'internal_message' => '{prenom} {nom} ({target}) attend la validation d’un administrateur.',
                    'email_subject' => '[{instance_name}] Nouvelle inscription à valider : {target}',
                    'email_body' => "Une nouvelle inscription DoMyDesk attend une validation.

Utilisateur : {target}
Nom : {prenom} {nom}
Rôle métier : {role_metier}
Date : {date} à {time}

Accès DoMyDesk :
{access_urls}",
                );
            } elseif ($action === 'registration_pending_user') {
                $defaults = array(
                    'internal' => false,
                    'email' => true,
                    'recipients' => array('target_user'),
                    'email_subject' => '[{instance_name}] Votre inscription a bien été reçue',
                    'email_body' => "Bonjour {prenom},

Votre inscription à {instance_name} a bien été enregistrée.

Votre compte est actuellement en attente de validation par un administrateur. Vous recevrez un nouvel e-mail lorsque votre demande aura été traitée.

Accès DoMyDesk :
{access_urls}

Date de la demande : {date} à {time}",
                );
            } elseif ($action === 'registration_activated_user') {
                $defaults = array(
                    'internal' => false,
                    'email' => true,
                    'recipients' => array('target_user'),
                    'email_subject' => '[{instance_name}] Votre compte DoMyDesk est actif',
                    'email_body' => "Bonjour {prenom},

Votre inscription à {instance_name} est terminée et votre compte est actif. Vous pouvez maintenant vous connecter.

Accès DoMyDesk :
{access_urls}

Date : {date} à {time}",
                );
            } elseif ($action === 'registration_approved_user') {
                $defaults = array(
                    'internal' => true,
                    'email' => true,
                    'recipients' => array('target_user'),
                    'internal_title' => 'Votre compte DoMyDesk est activé',
                    'internal_message' => 'Votre inscription a été validée par un administrateur. Vous pouvez maintenant vous connecter.',
                    'email_subject' => '[{instance_name}] Votre inscription a été validée',
                    'email_body' => "Bonjour {prenom},

Votre inscription à {instance_name} a été validée par un administrateur. Votre compte est maintenant actif.

Accès DoMyDesk :
{access_urls}

Date : {date} à {time}",
                );
            } elseif ($action === 'registration_refused_user') {
                $defaults = array(
                    // Le compte est détruit immédiatement après le refus : une
                    // notification interne serait supprimée avec son dossier.
                    // L'information utilisateur est donc envoyée par e-mail.
                    'internal' => false,
                    'email' => true,
                    'recipients' => array('target_user'),
                    'internal_title' => 'Votre inscription DoMyDesk a été refusée',
                    'internal_message' => 'Un administrateur a refusé votre demande d’inscription.',
                    'email_subject' => '[{instance_name}] Votre inscription a été refusée',
                    'email_body' => "Bonjour {prenom},

Votre demande d’inscription à {instance_name} a été refusée par un administrateur.
Le compte et les données liés à cette demande ont été supprimés.

Date : {date} à {time}",
                );
            } elseif ($action === 'registration_refused_admin') {
                $defaults = array(
                    'internal' => true,
                    'email' => true,
                    'recipients' => array('superadmins'),
                    'internal_title' => 'Inscription refusée : {target}',
                    'internal_message' => '{user} a refusé l’inscription de {prenom} {nom} ({target}). Le compte et ses données ont été supprimés.',
                    'email_subject' => '[{instance_name}] Inscription refusée : {target}',
                    'email_body' => "Une demande d’inscription DoMyDesk a été refusée.

Utilisateur : {target}
Nom : {prenom} {nom}
Rôle métier : {role_metier}
Décision prise par : {user_name} ({user})
Date : {date} à {time}

Le compte et l’ensemble de ses données utilisateur ont été supprimés. Le journal système de la décision est conservé.",
                );
            } elseif (strpos($action, 'module_') === 0) {
                $defaults = array(
                    'recipients' => array('admins','superadmins'),
                    'internal_title' => $label . ' : {target}',
                    'internal_message' => '{user} — ' . $label . ' : {target}.',
                    'email_subject' => '[{instance_name}] ' . $label . ' : {target}',
                    'email_body' => $label . " sur {instance_name}.\n\nModule(s) : {target}\nDétails : {details}\nPar : {user}\nDate : {date} {time}",
                );
            }
            $def = dmd_notifications_definition($key, 'core', 'DoMyDesk — ' . $category, $action, $label, $description, $variables, $defaults);
            $registry[$key] = $def;
        }
        return $registry;
    }
}

if (!function_exists('dmd_notifications_normalize_event_definition')) {
    function dmd_notifications_normalize_event_definition($moduleId, $moduleName, $event, $eventKeyHint = '') {
        if (!is_array($event)) return null;

        $moduleKey = strtolower(trim((string)$moduleId));
        if ($moduleKey === '') return null;

        $id = trim((string)($event['id'] ?? ''));
        if ($id === '') {
            $hint = trim((string)$eventKeyHint);
            if ($hint !== '') {
                $prefix = $moduleKey . '.';
                if (stripos($hint, $prefix) === 0) $hint = substr($hint, strlen($prefix));
                $id = $hint;
            }
        }

        if ($id === '' || !preg_match('/^[a-zA-Z0-9._:-]+$/', $id)) return null;

        // Si un manifeste fournit par erreur l'ID complet "module.event",
        // on retire le préfixe module pour éviter "module.module.event".
        $prefix = $moduleKey . '.';
        if (stripos($id, $prefix) === 0) $id = substr($id, strlen($prefix));

        $key = $moduleKey . '.' . strtolower($id);
        $label = trim((string)($event['label'] ?? $id));
        $description = trim((string)($event['description'] ?? ''));
        $variables = isset($event['variables']) && is_array($event['variables']) ? $event['variables'] : array();
        $defaults = isset($event['defaults']) && is_array($event['defaults']) ? $event['defaults'] : array();
        if (!isset($defaults['recipients'])) $defaults['recipients'] = array('module_users');

        $definition = dmd_notifications_definition($key, $moduleId, $moduleName, $id, $label, $description, $variables, $defaults);

        if (isset($event['variable_labels']) && is_array($event['variable_labels'])) {
            $definition['variable_labels'] = $event['variable_labels'];
        }
        if (isset($event['variable_descriptions']) && is_array($event['variable_descriptions'])) {
            $definition['variable_descriptions'] = $event['variable_descriptions'];
        }
        if (isset($event['variable_examples']) && is_array($event['variable_examples'])) {
            $definition['variable_examples'] = $event['variable_examples'];
        }

        return $definition;
    }
}

if (!function_exists('dmd_notifications_actionhub_definition')) {
    function dmd_notifications_actionhub_definition($moduleId, $moduleName, $action) {
        if (!is_array($action)) return null;
        $id = trim((string)($action['id'] ?? ''));
        if ($id === '' || !preg_match('/^[a-zA-Z0-9._:-]+$/', $id)) return null;
        $label = trim((string)($action['label'] ?? $id));
        if ($label === '') $label = $id;
        $description = trim((string)($action['description'] ?? 'Action déclarée dans ActionHub.'));
        $key = strtolower(trim((string)$moduleId)) . '.' . strtolower($id);
        $defaults = array(
            'recipients' => array('module_users'),
            'internal_title' => $label . ' — {resource_name}',
            'internal_message' => '{user} a exécuté « ' . $label . ' » sur {resource_name}. {details}',
            'email_subject' => '[{instance_name}] ' . $label . ' — {resource_name}',
            'email_body' => "Action : {event}\nModule : {module}\nRessource : {resource_name}\nUtilisateur : {user}\nÉtat : {status}\nDate : {date} {time}\n\n{details}",
        );
        return dmd_notifications_definition(
            $key,
            $moduleId,
            $moduleName,
            $id,
            $label,
            $description,
            array('resource_type','resource_id','resource_name','resource_source','scope','dangerous'),
            $defaults
        );
    }
}


if (!function_exists('dmd_notifications_definition_merge')) {
    /**
     * Fusionne deux définitions du même événement.
     * L'événement explicite du module garde son libellé/texte, tandis que
     * les variables ActionHub (resource_*) restent disponibles.
     */
    function dmd_notifications_definition_merge($base, $override) {
        if (!is_array($base)) return is_array($override) ? $override : array();
        if (!is_array($override)) return $base;

        $merged = $base;
        foreach (array('key','module_id','module_name','id','label','description') as $field) {
            if (isset($override[$field]) && trim((string)$override[$field]) !== '') $merged[$field] = $override[$field];
        }

        $baseVars = isset($base['variables']) && is_array($base['variables']) ? $base['variables'] : array();
        $overrideVars = isset($override['variables']) && is_array($override['variables']) ? $override['variables'] : array();
        $merged['variables'] = array_values(array_unique(array_merge($baseVars, $overrideVars)));

        $merged['defaults'] = dmd_notifications_merge_assoc(
            isset($base['defaults']) && is_array($base['defaults']) ? $base['defaults'] : array(),
            isset($override['defaults']) && is_array($override['defaults']) ? $override['defaults'] : array()
        );

        $merged['variable_labels'] = array_merge(
            isset($base['variable_labels']) && is_array($base['variable_labels']) ? $base['variable_labels'] : array(),
            isset($override['variable_labels']) && is_array($override['variable_labels']) ? $override['variable_labels'] : array()
        );

        $merged['variable_descriptions'] = array_merge(
            isset($base['variable_descriptions']) && is_array($base['variable_descriptions']) ? $base['variable_descriptions'] : array(),
            isset($override['variable_descriptions']) && is_array($override['variable_descriptions']) ? $override['variable_descriptions'] : array()
        );

        $merged['variable_examples'] = array_merge(
            isset($base['variable_examples']) && is_array($base['variable_examples']) ? $base['variable_examples'] : array(),
            isset($override['variable_examples']) && is_array($override['variable_examples']) ? $override['variable_examples'] : array()
        );

        return $merged;
    }
}

if (!function_exists('dmd_notifications_registry')) {
    function dmd_notifications_registry() {
        $registry = dmd_notifications_builtin_registry();
        $modulesDir = DMD_SYSTEM_ROOT . '/modules/';

        foreach (glob($modulesDir . '*', GLOB_ONLYDIR) ?: array() as $moduleDir) {
            $manifestFile = $moduleDir . '/dmd_module.json';
            if (!is_file($manifestFile)) continue;
            $raw = @file_get_contents($manifestFile);
            $manifest = $raw !== false ? json_decode($raw, true) : null;
            if (!is_array($manifest)) continue;

            $moduleId = trim((string)($manifest['id'] ?? basename($moduleDir)));
            if ($moduleId === '') continue;
            $moduleName = trim((string)($manifest['name'] ?? $moduleId));
            if ($moduleName === '') $moduleName = $moduleId;

            $actionhub = isset($manifest['actionhub']) && is_array($manifest['actionhub']) ? $manifest['actionhub'] : array();
            if (!array_key_exists('enabled', $actionhub) || !empty($actionhub['enabled'])) {
                foreach ((array)($actionhub['actions'] ?? array()) as $action) {
                    $definition = dmd_notifications_actionhub_definition($moduleId, $moduleName, $action);
                    if ($definition) $registry[$definition['key']] = $definition;
                }
            }

            /*
             * Événements de notification déclarés par les modules.
             * On accepte les listes classiques ET les maps associatives :
             *
             * "events": {
             *   "module.event": { ... }
             * }
             *
             * ainsi que l'ancien bloc "notification_events".
             */
            $eventSources = array();

            if (isset($manifest['notifications']['events']) && is_array($manifest['notifications']['events'])) {
                $eventSources[] = $manifest['notifications']['events'];
            }
            if (isset($manifest['integrations']['notifications']['events']) && is_array($manifest['integrations']['notifications']['events'])) {
                $eventSources[] = $manifest['integrations']['notifications']['events'];
            }
            if (isset($manifest['notification_events']) && is_array($manifest['notification_events'])) {
                $eventSources[] = $manifest['notification_events'];
            }

            foreach ($eventSources as $events) {
                foreach ($events as $eventHint => $event) {
                    if (!is_array($event)) continue;
                    $hint = is_string($eventHint) ? $eventHint : '';
                    $definition = dmd_notifications_normalize_event_definition($moduleId, $moduleName, $event, $hint);
                    if (!$definition) continue;

                    $key = $definition['key'];
                    if (isset($registry[$key]) && is_array($registry[$key])) {
                        $registry[$key] = dmd_notifications_definition_merge($registry[$key], $definition);
                    } else {
                        $registry[$key] = $definition;
                    }
                }
            }
        }

        uasort($registry, function($a, $b) {
            $cmp = strnatcasecmp((string)($a['module_name'] ?? ''), (string)($b['module_name'] ?? ''));
            if ($cmp !== 0) return $cmp;
            return strnatcasecmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
        });
        return $registry;
    }
}

if (!function_exists('dmd_notifications_event_settings')) {
    function dmd_notifications_event_settings($eventKey, $definition, $config) {
        $defaults = isset($definition['defaults']) && is_array($definition['defaults']) ? $definition['defaults'] : array();
        $stored = isset($config['events'][$eventKey]) && is_array($config['events'][$eventKey]) ? $config['events'][$eventKey] : array();
        $settings = dmd_notifications_merge_assoc($defaults, $stored);
        if (!isset($settings['recipients']) || !is_array($settings['recipients'])) $settings['recipients'] = array();
        return $settings;
    }
}

if (!function_exists('dmd_notifications_url_normalize')) {
    function dmd_notifications_url_normalize($value) {
        $value = trim((string)$value);
        if ($value === '' || strpos($value, "\r") !== false || strpos($value, "\n") !== false) return '';
        if (!preg_match('#^https?://#i', $value)) return '';
        $parts = @parse_url($value);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) return '';
        $scheme = strtolower((string)$parts['scheme']);
        if ($scheme !== 'http' && $scheme !== 'https') return '';
        $host = trim((string)$parts['host']);
        if ($host === '' || preg_match('/[\s<>"\']/', $host)) return '';
        $port = isset($parts['port']) ? (int)$parts['port'] : 0;
        if ($port < 0 || $port > 65535) return '';
        $authority = (strpos($host, ':') !== false && $host[0] !== '[') ? '[' . $host . ']' : $host;
        if ($port > 0 && !(($scheme === 'http' && $port === 80) || ($scheme === 'https' && $port === 443))) $authority .= ':' . $port;
        $path = isset($parts['path']) ? (string)$parts['path'] : '';
        $path = preg_replace('#/{2,}#', '/', $path);
        $path = rtrim((string)$path, '/');
        return $scheme . '://' . $authority . $path;
    }
}

if (!function_exists('dmd_notifications_host_is_internal')) {
    function dmd_notifications_host_is_internal($host) {
        $host = strtolower(trim((string)$host, "[] \t\r\n"));
        if ($host === '' || $host === 'localhost') return true;
        if (preg_match('/\.(?:local|lan|home|internal|localdomain)$/i', $host)) return true;
        if (strpos($host, '.') === false && strpos($host, ':') === false) return true;
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if (preg_match('/^100\.(\d+)\./', $host, $m)) {
                $n = (int)$m[1];
                if ($n >= 64 && $n <= 127) return true; // Tailscale / RFC6598.
            }
            return filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false;
        }
        return false;
    }
}

if (!function_exists('dmd_notifications_forwarded_headers_trusted')) {
    function dmd_notifications_forwarded_headers_trusted() {
        $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
        if ($ip === '127.0.0.1' || $ip === '::1') return true;
        if (preg_match('/^10\./', $ip) || preg_match('/^192\.168\./', $ip)) return true;
        if (preg_match('/^172\.(\d+)\./', $ip, $m)) {
            $n = (int)$m[1];
            if ($n >= 16 && $n <= 31) return true;
        }
        if (preg_match('/^100\.(\d+)\./', $ip, $m)) {
            $n = (int)$m[1];
            if ($n >= 64 && $n <= 127) return true;
        }
        $lower = strtolower($ip);
        return strpos($lower, 'fc') === 0 || strpos($lower, 'fd') === 0 || strpos($lower, 'fe80:') === 0;
    }
}

if (!function_exists('dmd_notifications_request_base_url')) {
    function dmd_notifications_request_base_url() {
        $host = dmd_notifications_forwarded_headers_trusted() ? trim((string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? '')) : '';
        if (strpos($host, ',') !== false) $host = trim(explode(',', $host, 2)[0]);
        if ($host === '') $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
        if ($host === '') $host = trim((string)($_SERVER['SERVER_NAME'] ?? ''));
        if ($host === '' || !preg_match('/^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]{1,5})?$/', $host)) return '';

        $scheme = dmd_notifications_forwarded_headers_trusted() ? strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))) : '';
        if (strpos($scheme, ',') !== false) $scheme = trim(explode(',', $scheme, 2)[0]);
        if ($scheme !== 'http' && $scheme !== 'https') {
            $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ? 'https' : 'http';
        }
        $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $path = '';
        if ($script !== '') {
            $marker = '/domydesk/';
            $pos = stripos($script, $marker);
            if ($pos !== false) $path = substr($script, 0, $pos) . '/domydesk';
            else {
                $dir = rtrim(dirname($script), '/');
                $path = ($dir === '' || $dir === '.') ? '' : $dir;
            }
        }
        return dmd_notifications_url_normalize($scheme . '://' . $host . $path);
    }
}

if (!function_exists('dmd_notifications_instance_urls')) {
    function dmd_notifications_instance_urls($config = array()) {
        $config = is_array($config) ? $config : array();
        $public = '';
        $internal = '';
        $configured = isset($config['instance_urls']) && is_array($config['instance_urls']) ? $config['instance_urls'] : array();
        $public = dmd_notifications_url_normalize($configured['public_url'] ?? '');
        $internal = dmd_notifications_url_normalize($configured['internal_url'] ?? '');

        $candidates = array();
        foreach (array('DMD_PUBLIC_URL','DMD_INSTANCE_URL','DMD_INTERNAL_URL') as $envKey) {
            $v = dmd_notifications_url_normalize(getenv($envKey));
            if ($v !== '') $candidates[] = $v;
        }

        $settings = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(DMD_SYSTEM_ROOT . '/adm/settings.json', array()) : array();
        if (is_array($settings)) {
            foreach (array('public_url','external_url','internet_url','instance_url','site_url','base_url','internal_url','local_url') as $key) {
                $v = dmd_notifications_url_normalize($settings[$key] ?? '');
                if ($v !== '') $candidates[] = $v;
            }
        }



        foreach (array('domyco_sync_last.json','domyco_heartbeat_last.json','domyco_register.json') as $name) {
            $row = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(DMD_SYSTEM_ROOT . '/data/' . $name, array()) : array();
            if (!is_array($row)) continue;
            $payload = isset($row['payload']) && is_array($row['payload']) ? $row['payload'] : (isset($row['sync_result']['payload']) && is_array($row['sync_result']['payload']) ? $row['sync_result']['payload'] : array());
            $v = dmd_notifications_url_normalize($payload['install_url'] ?? '');
            if ($v !== '') $candidates[] = $v;
        }

        $requestUrl = dmd_notifications_request_base_url();
        if ($requestUrl !== '') $candidates[] = $requestUrl;

        foreach ($candidates as $url) {
            $parts = @parse_url($url);
            $host = is_array($parts) ? (string)($parts['host'] ?? '') : '';
            if ($host === '') continue;
            if (dmd_notifications_host_is_internal($host)) {
                if ($internal === '') $internal = $url;
            } else {
                if ($public === '') $public = $url;
            }
        }



        $primary = $public !== '' ? $public : $internal;
        $lines = array();
        if ($public !== '') $lines[] = 'Internet : ' . $public;
        if ($internal !== '') $lines[] = 'Réseau interne : ' . $internal;
        if (!$lines) $lines[] = 'Adresse non détectée automatiquement.';

        return array(
            'public_url' => $public,
            'internal_url' => $internal,
            'primary_url' => $primary,
            'access_urls' => implode("\n", $lines),
        );
    }
}

if (!function_exists('dmd_notifications_site_context')) {
    function dmd_notifications_site_context($config = array()) {
        $settings = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(DMD_SYSTEM_ROOT . '/adm/settings.json', array()) : array();
        $name = trim((string)(isset($settings['site_name']) ? $settings['site_name'] : 'DoMyDesk'));
        if ($name === '') $name = 'DoMyDesk';
        $instanceId = is_file(DMD_SYSTEM_ROOT . '/data/id_domydesk.txt') ? trim((string)@file_get_contents(DMD_SYSTEM_ROOT . '/data/id_domydesk.txt')) : '';
        $urls = dmd_notifications_instance_urls(is_array($config) ? $config : array());
        return array(
            'instance_name' => $name,
            'instance_id' => $instanceId,
            'instance_url' => (string)$urls['primary_url'],
            'instance_url_internet' => (string)$urls['public_url'],
            'instance_url_internal' => (string)$urls['internal_url'],
            'access_urls' => (string)$urls['access_urls'],
        );
    }
}


if (!function_exists('dmd_notifications_variable_help')) {
    /**
     * Documentation générique des variables de notification.
     *
     * Le Core ne connaît aucun module particulier.
     * Les modules documentent leurs variables dans dmd_module.json via :
     * - variable_labels
     * - variable_descriptions
     * - variable_examples
     */
    function dmd_notifications_variable_help($variable, $definition = array()) {
        $variable = trim((string)$variable);
        $definition = is_array($definition) ? $definition : array();

        $generic = array(
            'instance_name'   => array('Nom de l’instance DoMyDesk', 'Nom configuré de cette installation DoMyDesk.', 'DoMyDesk'),
            'instance_id'     => array('ID de l’instance DoMyDesk', 'Identifiant unique de cette installation DoMyDesk.', 'DMD-AB12CD34'),
            'instance_url'    => array('Adresse principale DoMyDesk', 'Adresse Internet si elle est connue, sinon adresse interne.', 'https://dmd.exemple.fr/domydesk'),
            'instance_url_internet' => array('Adresse Internet DoMyDesk', 'URL publique / reverse proxy détectée ou configurée.', 'https://dmd.exemple.fr/domydesk'),
            'instance_url_internal' => array('Adresse interne DoMyDesk', 'URL LAN / privée détectée ou configurée.', 'http://192.168.1.20/domydesk'),
            'access_urls'     => array('Adresses d’accès DoMyDesk', 'Bloc prêt à afficher contenant l’adresse Internet et/ou l’adresse interne disponibles.', "Internet : https://dmd.exemple.fr/domydesk\nRéseau interne : http://192.168.1.20/domydesk"),
            'module'          => array('Nom du module', 'Nom lisible du module qui a produit l’événement.', 'DMD-Exemple'),
            'module_id'       => array('ID du module', 'Identifiant technique du module.', 'dmd-exemple'),
            'event'           => array('Nom de l’événement', 'Libellé lisible de l’événement.', 'Action terminée'),
            'event_id'        => array('ID de l’événement', 'Identifiant technique de l’événement.', 'item.action'),
            'user'            => array('Utilisateur à l’origine', 'E-mail ou identifiant de l’utilisateur ayant déclenché l’action.', 'admin@domaine.fr'),
            'user_name'       => array('Nom de l’utilisateur', 'Nom affiché de l’utilisateur ayant déclenché l’action.', 'Jean Dupont'),
            'role_system'     => array('Rôle système', 'Rôle système DoMyDesk de l’utilisateur.', 'superadmin'),
            'target'          => array('Cible', 'Cible générale et lisible de l’événement ou de l’action.', 'Ressource A'),
            'target_user'     => array('Utilisateur cible', 'Utilisateur concerné lorsque l’événement vise un compte.', 'user@domaine.fr'),
            'status'          => array('État / résultat', 'Résultat ou état communiqué par la source.', 'success'),
            'details'         => array('Détails', 'Texte détaillé fourni pour cet événement.', 'Action terminée.'),
            'date'            => array('Date', 'Date locale au moment de l’émission de la notification.', '10/08/2026'),
            'time'            => array('Heure', 'Heure locale au moment de l’émission de la notification.', '13:25:14'),
            'recipient'       => array('Destinataire', 'Adresse e-mail du destinataire actuellement traité.', 'admin@domaine.fr'),
            'source'          => array('Source', 'Origine de l’action fournie par la source.', 'actionhub'),
            'version'         => array('Version', 'Version fournie par la source lorsqu’elle existe.', '1.0.0'),
            'storage_scope'   => array('Portée de stockage', 'Emplacement logique utilisé pour les données concernées.', 'system'),
            'meta'            => array('Métadonnées', 'Bloc complet de métadonnées, affiché sous forme JSON.', '{"id":123}'),
            'changes'         => array('Modifications', 'Anciennes/nouvelles valeurs ou changements fournis par l’événement.', '{"status":"ok"}'),
            'extra'           => array('Données supplémentaires', 'Bloc complet de données supplémentaires, affiché sous forme JSON.', '{"key":"value"}'),
            'resource_type'   => array('Type de ressource', 'Type de ressource ActionHub concernée.', 'device'),
            'resource_id'     => array('ID de ressource', 'Identifiant technique ActionHub de la ressource.', 'device:123'),
            'resource_name'   => array('Nom de ressource', 'Nom lisible de la ressource ActionHub.', 'Ressource A'),
            'resource_source' => array('Source de ressource', 'Provider ou origine ayant fourni la ressource à ActionHub.', 'Module'),
            'scope'           => array('Portée ActionHub', 'Indique si l’action vise le module ou une ressource précise.', 'module'),
            'dangerous'       => array('Action sensible', 'Indique si ActionHub considère l’action comme potentiellement dangereuse.', 'Non'),
        );

        $labels = isset($definition['variable_labels']) && is_array($definition['variable_labels'])
            ? $definition['variable_labels'] : array();
        $descriptions = isset($definition['variable_descriptions']) && is_array($definition['variable_descriptions'])
            ? $definition['variable_descriptions'] : array();
        $examples = isset($definition['variable_examples']) && is_array($definition['variable_examples'])
            ? $definition['variable_examples'] : array();

        if (isset($generic[$variable])) {
            $data = $generic[$variable];
        } else {
            $human = trim(str_replace(array('_','-'), ' ', $variable));
            $data = array(
                $human !== '' ? ucfirst($human) : 'Variable du module',
                'Variable spécifique déclarée par le module pour cet événement.',
                ''
            );
        }

        if (isset($labels[$variable]) && trim((string)$labels[$variable]) !== '') {
            $data[0] = trim((string)$labels[$variable]);
        }
        if (isset($descriptions[$variable]) && trim((string)$descriptions[$variable]) !== '') {
            $data[1] = trim((string)$descriptions[$variable]);
        }
        if (isset($examples[$variable]) && trim((string)$examples[$variable]) !== '') {
            $data[2] = trim((string)$examples[$variable]);
        }

        return array(
            'variable' => $variable,
            'label' => (string)$data[0],
            'description' => (string)$data[1],
            'example' => (string)$data[2],
        );
    }
}

if (!function_exists('dmd_notifications_context_expand')) {
    /**
     * Rend directement utilisables dans les modèles les clés contenues dans
     * context.extra et context.meta, sans écraser les valeurs explicites.
     *
     * Exemple :
     *   context['meta']['custom_id'] = 123
     * devient aussi :
     *   context['custom_id'] = 123
     * et permet donc l'utilisation de {custom_id}.
     */
    function dmd_notifications_context_expand($context) {
        $context = is_array($context) ? $context : array();

        foreach (array('extra', 'meta') as $containerKey) {
            if (!isset($context[$containerKey]) || !is_array($context[$containerKey])) continue;
            foreach ($context[$containerKey] as $key => $value) {
                $key = trim((string)$key);
                if ($key === '' || array_key_exists($key, $context)) continue;
                $context[$key] = $value;
            }
        }

        return $context;
    }
}

if (!function_exists('dmd_notifications_template_render')) {
    function dmd_notifications_template_render($template, $context) {
        $text = (string)$template;
        if (!is_array($context)) return $text;
        $replace = array();
        foreach ($context as $key => $value) {
            if (is_bool($value)) $value = $value ? 'Oui' : 'Non';
            if (is_array($value) || is_object($value)) $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($value === null) $value = '';
            if (is_scalar($value)) $replace['{' . $key . '}'] = (string)$value;
        }
        return strtr($text, $replace);
    }
}

if (!function_exists('dmd_notifications_email_list')) {
    function dmd_notifications_email_list($value) {
        if (is_array($value)) $items = $value;
        else $items = preg_split('/[\s,;]+/', (string)$value, -1, PREG_SPLIT_NO_EMPTY);
        $out = array();
        foreach ($items ?: array() as $email) {
            $email = strtolower(trim((string)$email));
            if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) $out[] = $email;
        }
        return array_values(array_unique($out));
    }
}

if (!function_exists('dmd_notifications_resolve_recipients')) {
    function dmd_notifications_resolve_recipients($modes, $context, $customEmails) {
        $modes = is_array($modes) ? $modes : array();
        $context = is_array($context) ? $context : array();
        $index = function_exists('dmd_notification_index') ? dmd_notification_index() : array();
        $out = array();

        foreach ($modes as $mode) {
            switch ((string)$mode) {
                case 'all_users':
                    if (isset($index['users']) && is_array($index['users'])) $out = array_merge($out, array_keys($index['users']));
                    break;
                case 'admins':
                    $out = array_merge($out, isset($index['role_system']['admin']) && is_array($index['role_system']['admin']) ? $index['role_system']['admin'] : array());
                    break;
                case 'superadmins':
                    $out = array_merge($out, isset($index['role_system']['superadmin']) && is_array($index['role_system']['superadmin']) ? $index['role_system']['superadmin'] : array());
                    break;
                case 'actor':
                    if (!empty($context['user'])) $out[] = (string)$context['user'];
                    break;
                case 'target_user':
                    if (!empty($context['target_user'])) $out[] = (string)$context['target_user'];
                    break;
                case 'context':
                    $out = array_merge($out, dmd_notifications_email_list($context['recipient_emails'] ?? array()));
                    break;
                case 'module_users':
                    $moduleId = (string)($context['module_id'] ?? ($context['module'] ?? ''));
                    if ($moduleId !== '') {
                        foreach ((array)($index['modules'] ?? array()) as $indexedModuleId => $emails) {
                            if (strcasecmp((string)$indexedModuleId, $moduleId) === 0 && is_array($emails)) {
                                $out = array_merge($out, $emails);
                                break;
                            }
                        }
                    }
                    break;
                case 'custom':
                    $out = array_merge($out, dmd_notifications_email_list($customEmails));
                    break;
            }
        }

        $out = dmd_notifications_email_list($out);
        if (!empty($context['exclude_actor']) && !empty($context['user'])) {
            $actor = strtolower(trim((string)$context['user']));
            $out = array_values(array_filter($out, function($email) use ($actor) { return strtolower((string)$email) !== $actor; }));
        }
        return $out;
    }
}

if (!function_exists('dmd_notifications_log_mail')) {
    function dmd_notifications_log_mail($entry) {
        $file = dmd_notifications_mail_log_file();
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        if (!is_array($entry)) $entry = array('details' => (string)$entry);
        $entry['at'] = date('c');
        $line = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($line !== false) @file_put_contents($file, $line . "\n", FILE_APPEND | LOCK_EX);
        @chmod($file, 0640);
    }
}

if (!function_exists('dmd_notifications_smtp_read')) {
    function dmd_notifications_smtp_read($fp, &$error) {
        $error = '';
        $response = '';
        while (($line = fgets($fp, 4096)) !== false) {
            $response .= $line;
            if (strlen($line) >= 4 && preg_match('/^\d{3} /', $line)) break;
            if (strlen($line) < 4) break;
        }
        if ($response === '') {
            $meta = stream_get_meta_data($fp);
            $error = !empty($meta['timed_out']) ? 'Délai dépassé pendant la réponse SMTP.' : 'Aucune réponse du serveur SMTP.';
        }
        return $response;
    }
}

if (!function_exists('dmd_notifications_smtp_response_code')) {
    function dmd_notifications_smtp_response_code($response) {
        return preg_match('/^(\d{3})/', (string)$response, $m) ? (int)$m[1] : 0;
    }
}

if (!function_exists('dmd_notifications_smtp_friendly_error')) {
    function dmd_notifications_smtp_friendly_error($response) {
        $flat = trim(preg_replace('/\s+/', ' ', (string)$response));
        $code = dmd_notifications_smtp_response_code($response);
        if ($code === 534 && stripos($flat, 'Application-specific password required') !== false) {
            return 'Google refuse le mot de passe du compte : un mot de passe d’application Google est obligatoire.';
        }
        if ($code === 535) return 'Authentification SMTP refusée : identifiant ou mot de passe incorrect, ou authentification SMTP interdite par le fournisseur.';
        if ($code === 530) return 'Le serveur SMTP exige une authentification ou une connexion chiffrée.';
        if ($code === 550 || $code === 553) return 'Le serveur SMTP refuse l’adresse expéditeur ou le destinataire.';
        return 'SMTP ' . ($code ?: '?') . ' : ' . $flat;
    }
}

if (!function_exists('dmd_notifications_smtp_command')) {
    function dmd_notifications_smtp_command($fp, $command, $codes, &$error, &$response = '') {
        $error = '';
        $response = '';
        if (@fwrite($fp, $command . "\r\n") === false) {
            $error = 'Impossible d’écrire vers le serveur SMTP.';
            return false;
        }
        $response = dmd_notifications_smtp_read($fp, $error);
        if ($response === '') return false;
        $code = dmd_notifications_smtp_response_code($response);
        $codes = is_array($codes) ? $codes : array($codes);
        if (!in_array($code, $codes, true)) {
            $error = dmd_notifications_smtp_friendly_error($response);
            return false;
        }
        return true;
    }
}

if (!function_exists('dmd_notifications_header_encode')) {
    function dmd_notifications_header_encode($value) {
        $value = str_replace(array("\r", "\n"), '', (string)$value);
        if (function_exists('mb_encode_mimeheader')) return mb_encode_mimeheader($value, 'UTF-8', 'B', "\r\n");
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }
}

if (!function_exists('dmd_notifications_smtp_auth_methods')) {
    function dmd_notifications_smtp_auth_methods($ehloResponse) {
        $methods = array();
        if (preg_match_all('/^250[- ]AUTH\s+(.+)$/mi', (string)$ehloResponse, $matches)) {
            foreach ($matches[1] as $line) {
                foreach (preg_split('/\s+/', trim($line)) as $method) {
                    $method = strtoupper(trim($method));
                    if ($method !== '' && !in_array($method, $methods, true)) $methods[] = $method;
                }
            }
        }
        return $methods;
    }
}

if (!function_exists('dmd_notifications_html_linkify')) {
    function dmd_notifications_html_linkify($text) {
        $escaped = htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
        return preg_replace_callback('#https?://[^\s<]+#iu', function($m) {
            $url = (string)$m[0];
            return '<a href="' . $url . '" style="color:#b77900;text-decoration:none;font-weight:700;word-break:break-all">' . $url . '</a>';
        }, $escaped);
    }
}

if (!function_exists('dmd_notifications_html_message')) {
    function dmd_notifications_html_message($subject, $body) {
        $subjectEsc = htmlspecialchars((string)$subject, ENT_QUOTES, 'UTF-8');
        $lines = preg_split('/\r\n|\r|\n/', (string)$body);
        if (!is_array($lines)) $lines = array((string)$body);
        $content = '';
        $tableOpen = false;
        $closeTable = function() use (&$content, &$tableOpen) {
            if ($tableOpen) {
                $content .= '</table>';
                $tableOpen = false;
            }
        };

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                $closeTable();
                $content .= '<div style="height:10px;line-height:10px">&nbsp;</div>';
                continue;
            }
            if (preg_match('/^[A-ZÀ-ÖØ-Þ0-9][A-ZÀ-ÖØ-Þ0-9 ’\'\-]{2,}$/u', $line) && strpos($line, ':') === false) {
                $closeTable();
                $content .= '<div style="font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#8a6400;margin:12px 0 7px">' . htmlspecialchars($line, ENT_QUOTES, 'UTF-8') . '</div>';
                continue;
            }
            if (preg_match('/^([^:]{1,42})\s*:\s*(.*)$/u', $line, $m)) {
                if (!$tableOpen) {
                    $content .= '<table role="presentation" cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;border:1px solid #dde3ea;border-radius:8px;overflow:hidden">';
                    $tableOpen = true;
                }
                $label = htmlspecialchars(trim((string)$m[1]), ENT_QUOTES, 'UTF-8');
                $valueRaw = trim((string)$m[2]);
                $value = $valueRaw === '' ? '—' : dmd_notifications_html_linkify($valueRaw);
                $content .= '<tr><td style="width:34%;padding:9px 11px;background:#f5f7f9;border-bottom:1px solid #e5e9ee;font-size:13px;color:#5e6874;font-weight:700;vertical-align:top">' . $label . '</td><td style="padding:9px 11px;border-bottom:1px solid #e5e9ee;font-size:13px;color:#17202a;vertical-align:top">' . $value . '</td></tr>';
                continue;
            }
            $closeTable();
            $content .= '<p style="margin:0 0 9px;font-size:14px;line-height:1.6;color:#28323c">' . dmd_notifications_html_linkify($line) . '</p>';
        }
        $closeTable();

        return '<!doctype html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#eef1f4;font-family:Arial,Helvetica,sans-serif;color:#17202a">'
            . '<table role="presentation" cellspacing="0" cellpadding="0" width="100%" style="width:100%;background:#eef1f4;padding:24px 10px"><tr><td align="center">'
            . '<table role="presentation" cellspacing="0" cellpadding="0" width="680" style="width:100%;max-width:680px;background:#ffffff;border:1px solid #d9e0e7;border-radius:12px;overflow:hidden;box-shadow:0 4px 18px rgba(17,24,39,.08)">'
            . '<tr><td style="background:#111820;padding:18px 22px;border-bottom:3px solid #d6a900"><div style="font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#f1c93b;font-weight:800;margin-bottom:5px">DoMyDesk</div><div style="font-size:20px;line-height:1.3;color:#ffffff;font-weight:700">' . $subjectEsc . '</div></td></tr>'
            . '<tr><td style="padding:22px">' . $content . '</td></tr>'
            . '<tr><td style="padding:14px 22px;background:#f7f8fa;border-top:1px solid #e1e6eb;font-size:11px;line-height:1.5;color:#75808c">Message automatique envoyé par DoMyDesk. Merci de ne pas répondre directement à cette notification.</td></tr>'
            . '</table></td></tr></table></body></html>';
    }
}

if (!function_exists('dmd_notifications_smtp_send')) {
    function dmd_notifications_smtp_send($to, $subject, $body, $smtp, &$error) {
        $error = '';
        $to = trim((string)$to);
        $host = trim((string)($smtp['host'] ?? ''));
        $port = max(1, min(65535, (int)($smtp['port'] ?? 587)));
        $encryption = strtolower(trim((string)($smtp['encryption'] ?? 'tls')));
        /*
         * Le timeout configuré pilote la connexion TCP. Une réponse SMTP peut
         * légitimement prendre davantage de temps (notamment avec Gmail après
         * STARTTLS/AUTH ou après DATA). Ne pas considérer un destinataire en
         * échec simplement parce que le serveur met plus de quelques secondes
         * à confirmer la commande.
         */
        $connectTimeout = max(2, min(30, (int)($smtp['timeout'] ?? 15)));
        $responseTimeout = max(20, min(60, $connectTimeout * 2));
        $fromEmail = trim((string)($smtp['from_email'] ?? ''));
        $fromName = trim((string)($smtp['from_name'] ?? 'DoMyDesk'));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) { $error = 'Destinataire invalide.'; return false; }
        if ($host === '') { $error = 'Hôte SMTP manquant.'; return false; }
        if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) { $error = 'Adresse expéditeur invalide.'; return false; }
        if (!in_array($encryption, array('none','tls','ssl'), true)) $encryption = 'tls';

        $verifyPeer = !array_key_exists('verify_peer', $smtp) || !empty($smtp['verify_peer']);
        $ssl = array('verify_peer'=>$verifyPeer,'verify_peer_name'=>$verifyPeer,'allow_self_signed'=>!$verifyPeer,'SNI_enabled'=>true,'peer_name'=>$host);
        $context = stream_context_create(array('ssl'=>$ssl));
        $remote = ($encryption === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $errno = 0; $errstr = '';
        $fp = @stream_socket_client($remote, $errno, $errstr, $connectTimeout, STREAM_CLIENT_CONNECT, $context);
        if (!$fp) { $error = 'Connexion SMTP impossible vers ' . $host . ':' . $port . ' : ' . ($errstr !== '' ? $errstr : ('erreur ' . $errno)); return false; }
        stream_set_timeout($fp, $responseTimeout);

        $response = dmd_notifications_smtp_read($fp, $error);
        if (dmd_notifications_smtp_response_code($response) !== 220) { $error = $response !== '' ? dmd_notifications_smtp_friendly_error($response) : $error; fclose($fp); return false; }

        $hostname = 'domydesk.local';
        if (!empty($_SERVER['SERVER_NAME'])) {
            $candidate = preg_replace('/[^A-Za-z0-9.:-]/', '', (string)$_SERVER['SERVER_NAME']);
            if ($candidate !== '') $hostname = $candidate;
        }
        $ehlo = '';
        if (!dmd_notifications_smtp_command($fp, 'EHLO ' . $hostname, 250, $error, $ehlo)) { fclose($fp); return false; }

        if ($encryption === 'tls') {
            if (stripos($ehlo, 'STARTTLS') === false) { $error = 'Le serveur SMTP ne propose pas STARTTLS.'; fclose($fp); return false; }
            if (!dmd_notifications_smtp_command($fp, 'STARTTLS', 220, $error, $response)) { fclose($fp); return false; }
            $cryptoMethod = defined('STREAM_CRYPTO_METHOD_TLS_CLIENT') ? STREAM_CRYPTO_METHOD_TLS_CLIENT : true;
            if (!@stream_socket_enable_crypto($fp, true, $cryptoMethod)) { $error = 'Négociation TLS SMTP impossible.'; fclose($fp); return false; }
            $ehlo = '';
            if (!dmd_notifications_smtp_command($fp, 'EHLO ' . $hostname, 250, $error, $ehlo)) { fclose($fp); return false; }
        }

        if (!empty($smtp['auth'])) {
            $user = trim((string)($smtp['username'] ?? ''));
            $pass = (string)($smtp['password'] ?? '');
            if ($user === '') { $error = 'Identifiant SMTP manquant.'; fclose($fp); return false; }
            if ($pass === '') { $error = 'Mot de passe SMTP manquant.'; fclose($fp); return false; }
            $requested = strtolower(trim((string)($smtp['auth_method'] ?? 'auto')));
            if (!in_array($requested, array('auto','login','plain'), true)) $requested = 'auto';
            $advertised = dmd_notifications_smtp_auth_methods($ehlo);
            $method = $requested;
            if ($method === 'auto') {
                if (in_array('LOGIN', $advertised, true)) $method = 'login';
                elseif (in_array('PLAIN', $advertised, true)) $method = 'plain';
                else $method = 'login';
            }

            if ($method === 'plain') {
                if (!dmd_notifications_smtp_command($fp, 'AUTH PLAIN ' . base64_encode("\0" . $user . "\0" . $pass), 235, $error, $response)) { fclose($fp); return false; }
            } else {
                if (!dmd_notifications_smtp_command($fp, 'AUTH LOGIN', 334, $error, $response) ||
                    !dmd_notifications_smtp_command($fp, base64_encode($user), 334, $error, $response) ||
                    !dmd_notifications_smtp_command($fp, base64_encode($pass), 235, $error, $response)) { fclose($fp); return false; }
            }
        }

        if (!dmd_notifications_smtp_command($fp, 'MAIL FROM:<' . $fromEmail . '>', 250, $error, $response) ||
            !dmd_notifications_smtp_command($fp, 'RCPT TO:<' . $to . '>', array(250,251), $error, $response) ||
            !dmd_notifications_smtp_command($fp, 'DATA', 354, $error, $response)) { fclose($fp); return false; }

        $html = dmd_notifications_html_message($subject, $body);
        $messageIdHost = preg_replace('/[^A-Za-z0-9.-]/', '', $host) ?: 'domydesk.local';
        $headers = array(
            'Date: ' . date(DATE_RFC2822),
            'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $messageIdHost . '>',
            'From: ' . dmd_notifications_header_encode($fromName) . ' <' . $fromEmail . '>',
            'To: <' . $to . '>',
            'Subject: ' . dmd_notifications_header_encode($subject),
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: 8bit',
        );
        $message = implode("\r\n", $headers) . "\r\n\r\n" . $html;
        $message = preg_replace('/(?m)^\./', '..', $message);
        if (@fwrite($fp, $message . "\r\n.\r\n") === false) { $error = 'Écriture du message SMTP impossible.'; fclose($fp); return false; }
        $response = dmd_notifications_smtp_read($fp, $error);
        if (dmd_notifications_smtp_response_code($response) !== 250) {
            if ($response !== '') {
                $error = dmd_notifications_smtp_friendly_error($response);
            } elseif ($error === 'Délai dépassé pendant la réponse SMTP.') {
                $error = 'Délai dépassé pendant la confirmation SMTP après envoi du message.';
            }
            fclose($fp);
            return false;
        }
        @fwrite($fp, "QUIT\r\n");
        fclose($fp);
        return true;
    }
}

if (!function_exists('dmd_notifications_transport_send')) {
    function dmd_notifications_transport_send($to, $subject, $body, $smtp, &$error) {
        $transport = strtolower(trim((string)($smtp['transport'] ?? 'smtp')));
        if ($transport === 'mail') {
            $fromEmail = trim((string)($smtp['from_email'] ?? ''));
            $fromName = trim((string)($smtp['from_name'] ?? 'DoMyDesk'));
            if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) { $error = 'Adresse expéditeur invalide.'; return false; }
            $headers = array('MIME-Version: 1.0','Content-Type: text/html; charset=UTF-8','From: ' . dmd_notifications_header_encode($fromName) . ' <' . $fromEmail . '>');
            $html = dmd_notifications_html_message($subject, $body);
            $ok = @mail($to, dmd_notifications_header_encode($subject), $html, implode("\r\n", $headers));
            if (!$ok) $error = 'PHP mail() a refusé l’envoi.';
            return $ok;
        }
        return dmd_notifications_smtp_send($to, $subject, $body, $smtp, $error);
    }
}

if (!function_exists('dmd_notifications_queue_read')) {
    function dmd_notifications_queue_read() {
        $queue = function_exists('dmd_sys_json_read') ? dmd_sys_json_read(dmd_notifications_queue_file(), array()) : array();
        return is_array($queue) ? array_values(array_filter($queue, 'is_array')) : array();
    }
}

if (!function_exists('dmd_notifications_queue_write')) {
    function dmd_notifications_queue_write($queue) {
        if (!is_array($queue)) $queue = array();
        if (count($queue) > 500) $queue = array_slice($queue, -500);
        if (!function_exists('dmd_sys_json_write')) return false;
        $ok = dmd_sys_json_write(dmd_notifications_queue_file(), array_values($queue));
        if ($ok) @chmod(dmd_notifications_queue_file(), 0600);
        return $ok;
    }
}

if (!function_exists('dmd_notifications_queue_add')) {
    function dmd_notifications_queue_add($mail, $error) {
        $queue = dmd_notifications_queue_read();
        $mail['id'] = 'MAILQ-' . date('Ymd-His') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $mail['created_at'] = date('c');
        $mail['attempts'] = 1;
        $mail['last_error'] = (string)$error;
        $queue[] = $mail;
        dmd_notifications_queue_write($queue);
        return $mail['id'];
    }
}

if (!function_exists('dmd_notifications_queue_retry')) {
    function dmd_notifications_queue_retry($limit) {
        $limit = max(1, min(50, (int)$limit));
        $config = dmd_notifications_config();
        $smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
        $queue = dmd_notifications_queue_read();
        $remaining = array(); $sent = 0; $failed = 0; $processed = 0;
        foreach ($queue as $mail) {
            if ($processed >= $limit) { $remaining[] = $mail; continue; }
            $processed++;
            $error = '';
            $ok = dmd_notifications_transport_send((string)$mail['to'], (string)$mail['subject'], (string)$mail['body'], $smtp, $error);
            if ($ok) {
                $sent++;
                dmd_notifications_log_mail(array('status'=>'sent_retry','event'=>(string)($mail['event'] ?? ''),'to'=>(string)$mail['to'],'subject'=>(string)$mail['subject'],'queue_id'=>(string)($mail['id'] ?? '')));
            } else {
                $failed++;
                $mail['attempts'] = (int)(isset($mail['attempts']) ? $mail['attempts'] : 0) + 1;
                $mail['last_error'] = $error;
                $mail['last_attempt_at'] = date('c');
                $remaining[] = $mail;
            }
        }
        dmd_notifications_queue_write($remaining);
        return array('processed'=>$processed,'sent'=>$sent,'failed'=>$failed,'remaining'=>count($remaining));
    }
}

if (!function_exists('dmd_notifications_mail_logs')) {
    function dmd_notifications_mail_logs($limit) {
        $file = dmd_notifications_mail_log_file();
        if (!is_file($file)) return array();
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) return array();
        $lines = array_slice($lines, -max(1, min(300, (int)$limit)));
        $out = array();
        foreach (array_reverse($lines) as $line) {
            $item = json_decode($line, true);
            if (is_array($item)) $out[] = $item;
        }
        return $out;
    }
}

if (!function_exists('dmd_notifications_test_mail')) {
    function dmd_notifications_test_mail($to, &$error) {
        $config = dmd_notifications_config();
        $smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
        $site = dmd_notifications_site_context($config);
        $subject = '[' . $site['instance_name'] . '] Test des notifications e-mail';
        $body = "Ceci est un e-mail de test envoyé depuis DoMyDesk.\n\nINSTANCE\nNom : " . $site['instance_name'] . "\nID : " . $site['instance_id'] . "\n\nACCÈS À DOMYDESK\n" . $site['access_urls'] . "\n\nDate : " . date('d/m/Y H:i:s');
        return dmd_notifications_transport_send($to, $subject, $body, $smtp, $error);
    }
}

if (!function_exists('dmd_notifications_module_name')) {
    function dmd_notifications_module_name($moduleId) {
        $moduleId = trim((string)$moduleId);
        if ($moduleId === '') return '';
        $modulesDir = DMD_SYSTEM_ROOT . '/modules/';
        foreach (glob($modulesDir . '*', GLOB_ONLYDIR) ?: array() as $dir) {
            if (strcasecmp(basename($dir), $moduleId) !== 0) {
                $manifest = @json_decode((string)@file_get_contents($dir . '/dmd_module.json'), true);
                if (!is_array($manifest) || strcasecmp((string)($manifest['id'] ?? ''), $moduleId) !== 0) continue;
            } else {
                $manifest = @json_decode((string)@file_get_contents($dir . '/dmd_module.json'), true);
            }
            if (is_array($manifest) && trim((string)($manifest['name'] ?? '')) !== '') return trim((string)$manifest['name']);
            return $moduleId;
        }
        return $moduleId;
    }
}

if (!function_exists('dmd_notifications_context_add_extra')) {
    function dmd_notifications_context_add_extra($context, $extra) {
        $context = is_array($context) ? $context : array();
        $extra = is_array($extra) ? $extra : array();
        $context['extra'] = $extra;
        foreach ($extra as $key => $value) {
            $key = trim((string)$key);
            if ($key === '' || array_key_exists($key, $context)) continue;
            $context[$key] = $value;
        }
        return function_exists('dmd_notifications_context_expand')
            ? dmd_notifications_context_expand($context)
            : $context;
    }
}

if (!function_exists('dmd_notifications_dispatch_system_log')) {
    function dmd_notifications_dispatch_system_log($entry) {
        if (!is_array($entry)) return array('ok' => false, 'reason' => 'invalid_log_entry');
        $action = strtolower(trim((string)($entry['action'] ?? '')));
        if ($action === '') return array('ok' => false, 'reason' => 'missing_action');

        /*
         * Certaines voies de création utilisent un nom de log plus précis que
         * l'événement fonctionnel affiché dans l'administration. Un import AD
         * crée bien un compte DoMyDesk : il doit donc déclencher le même événement
         * configurable « core.user_created » qu'une création locale.
         */
        $notificationAction = $action === 'ad_user_imported' ? 'user_created' : $action;
        $eventKey = 'core.' . $notificationAction;
        $registry = dmd_notifications_registry();
        if (!isset($registry[$eventKey])) return array('ok' => true, 'reason' => 'unmanaged_event', 'event' => $eventKey);

        $target = trim((string)($entry['target'] ?? ''));
        $extra = isset($entry['extra']) && is_array($entry['extra']) ? $entry['extra'] : array();
        $targetUser = filter_var($target, FILTER_VALIDATE_EMAIL) ? $target : '';
        $moduleId = '';
        if (strpos($action, 'module_') === 0 && $target !== '') {
            $moduleId = strpos($target, ',') === false ? $target : '';
        }

        $context = array(
            'user' => trim((string)($entry['user'] ?? '')),
            'user_name' => trim((string)($entry['user_name'] ?? '')),
            'role_system' => trim((string)($entry['role_system'] ?? '')),
            'target' => $target,
            'target_user' => $targetUser,
            'status' => trim((string)($entry['status'] ?? '')),
            'details' => (string)($entry['details'] ?? ''),
            'action' => $action,
            'module_id' => $moduleId !== '' ? $moduleId : 'core',
            'module_name' => $moduleId !== '' ? dmd_notifications_module_name($moduleId) : 'DoMyDesk Core',
            'source' => (string)($extra['source'] ?? ''),
            'version' => (string)($extra['version'] ?? ''),
            'storage_scope' => (string)($extra['storage_scope'] ?? ''),
        );
        $context = dmd_notifications_context_add_extra($context, $extra);

        /*
         * Pour « Utilisateur créé », les variables {prenom}, {nom},
         * {role_system} et {role_metier} décrivent le compte créé, pas le compte
         * administrateur qui a effectué l'action. On relit donc le profil cible.
         * On expose aussi sa propre adresse dans recipient_emails afin que le mode
         * « Utilisateurs concernés » fonctionne pour cette création.
         */
        if ($eventKey === 'core.user_created' && $targetUser !== '') {
            $targetProfile = function_exists('dmd_sys_profile') ? dmd_sys_profile($targetUser) : array();
            if (is_array($targetProfile) && $targetProfile) {
                $context['prenom'] = (string)($targetProfile['prenom'] ?? '');
                $context['nom'] = (string)($targetProfile['nom'] ?? '');
                $context['role_system'] = (string)($targetProfile['role_system'] ?? 'user');
                $context['role_metier'] = (string)($targetProfile['role_metier'] ?? '');
            }
            $context['recipient_emails'] = array($targetUser);
            if ($action === 'ad_user_imported' && empty($context['source'])) {
                $context['source'] = 'active_directory';
            }
        }

        return dmd_notification_emit($eventKey, $context, array('level' => (($entry['status'] ?? '') === 'error' ? 'danger' : 'info')));
    }
}


if (!function_exists('dmd_notifications_user_identity')) {
    /**
     * Résout l'identité lisible d'un utilisateur à partir de son e-mail.
     * Cela rend enfin {user_name} et {role_system} fiables pour tous les modules.
     */
    function dmd_notifications_user_identity($email) {
        $email = trim((string)$email);
        $result = array(
            'user_name' => $email,
            'role_system' => '',
        );
        if ($email === '') return $result;

        $profile = array();

        if (function_exists('dmd_read_profile')) {
            try {
                $candidate = dmd_read_profile($email);
                if (is_array($candidate)) $profile = $candidate;
            } catch (Throwable $e) {}
        }

        if (!$profile) {
            $base = DMD_SYSTEM_ROOT . '/users/profiles/' . basename($email);
            foreach (array($base . '/profile.json', $base . '/profile/profile.json') as $file) {
                if (!is_file($file)) continue;
                $candidate = json_decode((string)@file_get_contents($file), true);
                if (is_array($candidate)) {
                    $profile = $candidate;
                    break;
                }
            }
        }

        if ($profile) {
            $first = trim((string)($profile['prenom'] ?? $profile['first_name'] ?? $profile['firstname'] ?? ''));
            $last  = trim((string)($profile['nom'] ?? $profile['last_name'] ?? $profile['lastname'] ?? ''));
            $full = trim($first . ' ' . $last);

            if ($full === '') {
                foreach (array('display_name','user_name','name','username') as $field) {
                    if (!empty($profile[$field]) && is_scalar($profile[$field])) {
                        $full = trim((string)$profile[$field]);
                        if ($full !== '') break;
                    }
                }
            }

            if ($full !== '') $result['user_name'] = $full;
            $result['role_system'] = trim((string)($profile['role_system'] ?? $profile['role'] ?? ''));
        }

        return $result;
    }
}

if (!function_exists('dmd_notifications_context_enrich_actor')) {
    function dmd_notifications_context_enrich_actor($context, $actor) {
        $context = is_array($context) ? $context : array();
        $actor = trim((string)$actor);
        $identity = dmd_notifications_user_identity($actor);

        if (empty($context['user_name'])) {
            $context['user_name'] = (string)$identity['user_name'];
        }
        if (empty($context['role_system'])) {
            $context['role_system'] = (string)$identity['role_system'];
        }

        // Compatibilité silencieuse des anciens templates.
        if (!array_key_exists('actor', $context) || trim((string)$context['actor']) === '') {
            $context['actor'] = $actor;
        }
        if (!array_key_exists('message', $context) || (is_scalar($context['message']) && trim((string)$context['message']) === '')) {
            $context['message'] = isset($context['details']) && is_scalar($context['details'])
                ? (string)$context['details']
                : '';
        }

        return $context;
    }
}

if (!function_exists('dmd_notification_emit')) {
    function dmd_notification_emit($eventKey, $context = array(), $options = array()) {
        $eventKey = strtolower(trim((string)$eventKey));
        $context = is_array($context) ? $context : array();
        $context = dmd_notifications_context_expand($context);
        $options = is_array($options) ? $options : array();
        $registry = dmd_notifications_registry();
        if (!isset($registry[$eventKey])) {
            return array('ok'=>false,'reason'=>'unknown_event','event'=>$eventKey,'internal'=>0,'emails_sent'=>0,'emails_queued'=>0);
        }
        $definition = $registry[$eventKey];

        /*
         * Normalisation centrale de l'événement de création utilisateur.
         * Ainsi, qu'il soit déclenché directement ou via le bus des logs, les
         * destinataires et variables reposent toujours sur le compte réellement créé.
         */
        if ($eventKey === 'core.user_created') {
            $targetUser = trim((string)($context['target_user'] ?? ($context['target'] ?? '')));
            if (filter_var($targetUser, FILTER_VALIDATE_EMAIL)) {
                $targetProfile = function_exists('dmd_sys_profile') ? dmd_sys_profile($targetUser) : array();
                if (is_array($targetProfile) && $targetProfile) {
                    $context['prenom'] = (string)($targetProfile['prenom'] ?? ($context['prenom'] ?? ''));
                    $context['nom'] = (string)($targetProfile['nom'] ?? ($context['nom'] ?? ''));
                    $context['role_system'] = (string)($targetProfile['role_system'] ?? ($context['role_system'] ?? 'user'));
                    $context['role_metier'] = (string)($targetProfile['role_metier'] ?? ($context['role_metier'] ?? ''));
                }
                $context['target'] = $targetUser;
                $context['target_user'] = $targetUser;
                $affected = dmd_notifications_email_list($context['recipient_emails'] ?? array());
                $affected[] = strtolower($targetUser);
                $context['recipient_emails'] = array_values(array_unique($affected));
            }
        }

        $config = dmd_notifications_config();
        if (empty($config['global_enabled'])) {
            return array('ok'=>true,'reason'=>'global_disabled','event'=>$eventKey,'internal'=>0,'emails_sent'=>0,'emails_queued'=>0);
        }
        $settings = dmd_notifications_event_settings($eventKey, $definition, $config);
        $site = dmd_notifications_site_context($config);
        $actor = isset($context['user']) ? trim((string)$context['user']) : '';
        if ($actor === '' && function_exists('dmd_sys_current_email')) $actor = dmd_sys_current_email();

        /*
         * Le Core garantit les variables d'identité annoncées :
         * {user} = identifiant/e-mail ; {user_name} = nom lisible.
         */
        $context = dmd_notifications_context_enrich_actor($context, $actor);

        $baseContext = array_merge($site, array(
            'module' => (string)$definition['module_name'],
            'module_id' => (string)$definition['module_id'],
            'event' => (string)$definition['label'],
            'event_id' => (string)$definition['id'],
            'user' => $actor,
            'date' => date('d/m/Y'),
            'time' => date('H:i:s'),
        ), $context);
        $recipients = dmd_notifications_resolve_recipients($settings['recipients'], $baseContext, isset($settings['custom_emails']) ? $settings['custom_emails'] : '');
        $result = array('ok'=>true,'event'=>$eventKey,'recipients'=>$recipients,'internal'=>0,'emails_sent'=>0,'emails_queued'=>0,'errors'=>array());

        if (!empty($config['internal_enabled']) && !empty($settings['internal'])) {
            foreach ($recipients as $recipient) {
                if (!is_dir(DMD_SYSTEM_ROOT . '/users/profiles/' . $recipient)) continue;
                $ctx = $baseContext; $ctx['recipient'] = $recipient;
                $title = dmd_notifications_template_render((string)$settings['internal_title'], $ctx);
                $message = dmd_notifications_template_render((string)$settings['internal_message'], $ctx);
                if (function_exists('dmd_notify_user') && dmd_notify_user($recipient, (string)$definition['id'], $title, $message, array(
                    'level' => isset($options['level']) ? (string)$options['level'] : 'info',
                    'action_url' => isset($options['action_url']) ? (string)$options['action_url'] : '',
                    'action_label' => isset($options['action_label']) ? (string)$options['action_label'] : '',
                    'meta' => array('notification_event'=>$eventKey,'module'=>(string)$definition['module_id'],'context'=>$context),
                    '_mail_dispatch' => true,
                ))) $result['internal']++;
            }
        }

        if (!empty($config['email_enabled']) && !empty($settings['email'])) {
            $smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
            foreach ($recipients as $recipient) {
                $ctx = $baseContext; $ctx['recipient'] = $recipient;
                $subject = dmd_notifications_template_render((string)$settings['email_subject'], $ctx);
                $body = dmd_notifications_template_render((string)$settings['email_body'], $ctx);
                $error = '';
                $mail = array('event'=>$eventKey,'to'=>$recipient,'subject'=>$subject,'body'=>$body);
                if (dmd_notifications_transport_send($recipient, $subject, $body, $smtp, $error)) {
                    $result['emails_sent']++;
                    dmd_notifications_log_mail(array('status'=>'sent','event'=>$eventKey,'to'=>$recipient,'subject'=>$subject));
                } else {
                    $result['emails_queued']++;
                    $queueId = dmd_notifications_queue_add($mail, $error);
                    $result['errors'][] = $recipient . ' : ' . $error;
                    dmd_notifications_log_mail(array('status'=>'queued','event'=>$eventKey,'to'=>$recipient,'subject'=>$subject,'error'=>$error,'queue_id'=>$queueId));
                }
            }
        }
        return $result;
    }
}
