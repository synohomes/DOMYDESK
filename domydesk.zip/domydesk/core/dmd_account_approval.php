<?php
require_once __DIR__ . '/dmd_permissions.php';
if (is_file(__DIR__ . '/dmd_system_services.php')) require_once __DIR__ . '/dmd_system_services.php';

if (!function_exists('dmd_account_status')) {
    function dmd_account_status(array $profile): string {
        $status = strtolower(trim((string)($profile['account_status'] ?? 'active')));
        return in_array($status, ['pending','active','suspended','refused'], true) ? $status : 'active';
    }
}

if (!function_exists('dmd_account_can_login')) {
    function dmd_account_can_login(array $profile): bool {
        return dmd_account_status($profile) === 'active';
    }
}

if (!function_exists('dmd_account_pending_registrations')) {
    function dmd_account_pending_registrations(): array {
        $items = [];
        foreach (glob(DMD_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $email = basename($dir);
            $profile = dmd_read_profile($email);
            if (dmd_account_status($profile) !== 'pending') continue;
            $items[$email] = $profile;
        }
        uasort($items, static function($a, $b) {
            return strcmp((string)($a['registration_requested_at'] ?? $a['created_at'] ?? ''), (string)($b['registration_requested_at'] ?? $b['created_at'] ?? ''));
        });
        return $items;
    }
}

if (!function_exists('dmd_account_approve')) {
    function dmd_account_approve(string $email, string $actor): array {
        $profile = dmd_read_profile($email);
        if (!$profile) return ['ok' => false, 'error' => 'Compte introuvable.'];
        if (dmd_account_status($profile) !== 'pending') return ['ok' => false, 'error' => 'Ce compte n’est plus en attente.'];
        $profile['account_status'] = 'active';
        $profile['approved_at'] = date('c');
        $profile['approved_by'] = $actor;
        unset($profile['refused_at'], $profile['refused_by']);
        if (!dmd_write_profile($email, $profile)) return ['ok' => false, 'error' => 'Impossible d’activer le compte.'];
        if (function_exists('dmd_system_log')) dmd_system_log('registration_approved', $email, 'success', 'Inscription validée par un administrateur.', ['actor' => $actor]);
        if (function_exists('dmd_notification_emit')) {
            dmd_notification_emit('core.registration_approved_user', [
                'user' => $actor,
                'target' => $email,
                'target_user' => $email,
                'prenom' => (string)($profile['prenom'] ?? ''),
                'nom' => (string)($profile['nom'] ?? ''),
                'role_system' => (string)($profile['role_system'] ?? 'user'),
                'role_metier' => (string)($profile['role_metier'] ?? ''),
                'status' => 'active',
            ], ['level' => 'success', 'action_url' => 'login.php', 'action_label' => 'Se connecter']);
        }
        return ['ok' => true];
    }
}

if (!function_exists('dmd_account_remove_tree')) {
    function dmd_account_remove_tree(string $dir): bool {
        if ($dir === '' || !file_exists($dir)) return true;
        if (is_link($dir) || is_file($dir)) return @unlink($dir);
        $items = @scandir($dir);
        if ($items === false) return false;
        $ok = true;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path) && !is_link($path)) {
                if (!dmd_account_remove_tree($path)) $ok = false;
            } elseif (!@unlink($path)) {
                $ok = false;
            }
        }
        return @rmdir($dir) && $ok;
    }
}

if (!function_exists('dmd_account_refuse')) {
    function dmd_account_refuse(string $email, string $actor): array {
        $profile = dmd_read_profile($email);
        if (!$profile) return ['ok' => false, 'error' => 'Compte introuvable.'];
        if (dmd_account_status($profile) !== 'pending') return ['ok' => false, 'error' => 'Ce compte n’est plus en attente.'];

        $context = [
            'user' => $actor,
            'target' => $email,
            'target_user' => $email,
            'recipient_emails' => [$email],
            'prenom' => (string)($profile['prenom'] ?? ''),
            'nom' => (string)($profile['nom'] ?? ''),
            'role_system' => (string)($profile['role_system'] ?? 'user'),
            'role_metier' => (string)($profile['role_metier'] ?? ''),
            'status' => 'refused',
        ];

        // La décision destinée à l'utilisateur doit partir AVANT la suppression
        // de son dossier. L'e-mail reste donc envoyable même si le compte disparaît
        // immédiatement après le refus.
        if (function_exists('dmd_notification_emit')) {
            dmd_notification_emit('core.registration_refused_user', $context, ['level' => 'warning']);
            dmd_notification_emit('core.registration_refused_admin', $context, ['level' => 'warning']);
        }

        // Le journal système est volontairement conservé : il constitue la trace
        // administrative du refus même après destruction complète du compte.
        if (function_exists('dmd_system_log')) {
            dmd_system_log('registration_refused', $email, 'warning', 'Inscription refusée et compte supprimé.', [
                'actor' => $actor,
                'prenom' => (string)($profile['prenom'] ?? ''),
                'nom' => (string)($profile['nom'] ?? ''),
                'role_system' => (string)($profile['role_system'] ?? 'user'),
                'role_metier' => (string)($profile['role_metier'] ?? ''),
            ]);
        }

        $userDir = DMD_ROOT . '/users/profiles/' . basename($email);
        if (!dmd_account_remove_tree($userDir)) {
            return ['ok' => false, 'error' => 'Le refus a été enregistré, mais le dossier utilisateur n’a pas pu être supprimé complètement.'];
        }
        if (function_exists('dmd_notification_index_remove_user')) {
            dmd_notification_index_remove_user($email);
        }

        return ['ok' => true];
    }
}
