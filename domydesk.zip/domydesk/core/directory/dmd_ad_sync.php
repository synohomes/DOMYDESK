<?php
require_once __DIR__ . '/dmd_ldap.php';
require_once dirname(__DIR__) . '/dmd_permissions.php';
if (is_file(dirname(__DIR__) . '/dmd_media.php')) require_once dirname(__DIR__) . '/dmd_media.php';
if (is_file(dirname(__DIR__) . '/dmd_system_services.php')) require_once dirname(__DIR__) . '/dmd_system_services.php';

if (!function_exists('dmd_directory_profile_is_ad')) {
    function dmd_directory_profile_is_ad(array $profile): bool {
        return strtolower((string)($profile['auth_source'] ?? 'local')) === 'active_directory';
    }
}

if (!function_exists('dmd_directory_find_profile_email_by_login')) {
    function dmd_directory_find_profile_email_by_login(string $identity): string {
        $identity = trim($identity);
        if ($identity === '') return '';

        // Adresse DoMyDesk exacte : on la résout même si le compte est lié à AD.
        $emailNeedle = strtolower($identity);
        if (filter_var($identity, FILTER_VALIDATE_EMAIL)) {
            foreach (glob(DMD_DIRECTORY_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
                $folderEmail = basename($dir);
                if (strcasecmp($folderEmail, $identity) === 0) return $folderEmail;
                $profile = dmd_read_profile($folderEmail);
                if (strcasecmp((string)($profile['email'] ?? ''), $identity) === 0) return $folderEmail;
            }
        }

        $needle = strtolower($identity);
        $slashSam = '';
        $slashDomain = '';
        if (strpos($identity, '\\') !== false) {
            [$slashDomain, $slashSam] = array_pad(explode('\\', $identity, 2), 2, '');
            $slashDomain = strtolower(trim($slashDomain));
            $slashSam = strtolower(trim($slashSam));
        }

        foreach (glob(DMD_DIRECTORY_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $email = basename($dir);
            $profile = dmd_read_profile($email);
            if (!dmd_directory_profile_is_ad($profile)) continue;
            $ad = is_array($profile['ad'] ?? null) ? $profile['ad'] : [];

            $sam = strtolower(trim((string)($ad['sam_account_name'] ?? '')));
            $upn = strtolower(trim((string)($ad['user_principal_name'] ?? '')));
            $sourceMail = strtolower(trim((string)($ad['source_mail'] ?? '')));
            $netbios = strtolower(trim((string)($ad['netbios_domain'] ?? ($ad['domain_netbios'] ?? ($ad['netbios_name'] ?? '')))));
            $dnsDomain = '';
            if ($upn !== '' && strpos($upn, '@') !== false) {
                $dnsDomain = strtolower((string)substr(strrchr($upn, '@'), 1));
            }

            $values = array_values(array_filter([
                strtolower((string)$email),
                strtolower((string)($profile['email'] ?? '')),
                $sam,
                $upn,
                $sourceMail,
                ($netbios !== '' && $sam !== '') ? $netbios . '\\' . $sam : '',
                ($dnsDomain !== '' && $sam !== '') ? $dnsDomain . '\\' . $sam : '',
            ]));

            if (in_array($needle, $values, true)) return $email;

            // Un seul annuaire AD est configuré par instance. Si DOMAIN\utilisateur est saisi
            // et que le profil ne possède pas encore le NetBIOS synchronisé, le sAMAccountName
            // reste suffisant pour retrouver le compte (unique dans le domaine AD).
            if ($slashSam !== '' && $sam !== '' && hash_equals($sam, $slashSam)) {
                return $email;
            }
        }
        return '';
    }
}

if (!function_exists('dmd_directory_find_profile_by_guid')) {
    function dmd_directory_find_profile_by_guid(string $guid): string {
        $guid = strtolower(trim($guid));
        if ($guid === '') return '';
        foreach (glob(DMD_DIRECTORY_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $email = basename($dir);
            $profile = dmd_read_profile($email);
            if (!dmd_directory_profile_is_ad($profile)) continue;
            $stored = strtolower((string)($profile['ad']['object_guid'] ?? ''));
            if ($stored !== '' && hash_equals($stored, $guid)) return $email;
        }
        return '';
    }
}

if (!function_exists('dmd_directory_initialize_user_files')) {
    function dmd_directory_initialize_user_files(string $email): bool {
        $folder = DMD_DIRECTORY_ROOT . '/users/profiles/' . $email . '/';
        if (!is_dir($folder) && !@mkdir($folder, 0775, true)) return false;
        if (!dmd_ensure_private_profile_dir($email)) return false;
        dmd_write_user_modules_acl($email, dmd_default_user_modules_acl());
        dmd_write_user_pages_acl($email, dmd_default_user_pages_acl());
        $defaults = [
            'dashboard.json' => [],
            'dashboards.json' => ['dashboard'],
            'menu.json' => [],
            'theme.json' => ['theme' => 'default'],
        ];
        foreach ($defaults as $name => $data) {
            $file = $folder . $name;
            if (!is_file($file)) {
                $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                @file_put_contents($file, $json . "\n", LOCK_EX);
                @chmod($file, 0664);
            }
        }
        if (is_file(DMD_DIRECTORY_ROOT . '/data/Logo_2025_Mini.png') && function_exists('dmd_user_media_dir')) {
            $mediaDir = dmd_user_media_dir($email, true);
            if ($mediaDir !== '' && !is_file($mediaDir . 'avatar.png')) {
                @copy(DMD_DIRECTORY_ROOT . '/data/Logo_2025_Mini.png', $mediaDir . 'avatar.png');
                @chmod($mediaDir . 'avatar.png', 0664);
            }
        }
        @chmod(dmd_profile_path($email, false), 0640);
        @chmod(dmd_modules_acl_path($email, false), 0640);
        @chmod(dmd_pages_acl_path($email, false), 0640);
        return true;
    }
}

if (!function_exists('dmd_directory_import_user')) {
    function dmd_directory_import_user(array $adUser, string $domydeskEmail, string $roleMetier, string $actor = '', bool $mergeExisting = false): array {
        $domydeskEmail = strtolower(trim($domydeskEmail));
        if (!filter_var($domydeskEmail, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'error' => 'Adresse email DoMyDesk obligatoire et invalide.'];
        $roles = dmd_roles_catalog();
        if ($roleMetier === '' || !in_array($roleMetier, $roles, true)) return ['ok' => false, 'error' => 'Rôle métier DoMyDesk invalide.'];
        $dn = trim((string)($adUser['dn'] ?? ''));
        $guid = trim((string)($adUser['object_guid'] ?? ''));
        if ($dn === '' || $guid === '') return ['ok' => false, 'error' => 'Objet Active Directory incomplet (DN/GUID manquant).'];

        $guidOwner = dmd_directory_find_profile_by_guid($guid);
        if ($guidOwner !== '' && strcasecmp($guidOwner, $domydeskEmail) !== 0) {
            return ['ok' => false, 'error' => 'Cet utilisateur AD est déjà lié au compte DoMyDesk ' . $guidOwner . '.'];
        }

        $existingDir = DMD_DIRECTORY_ROOT . '/users/profiles/' . $domydeskEmail;
        $existingProfile = [];
        $isExisting = is_dir($existingDir);
        $isMerge = false;

        if ($isExisting) {
            $existingProfile = dmd_read_profile($domydeskEmail);
            if (!is_array($existingProfile)) $existingProfile = [];
            $existingGuid = strtolower(trim((string)($existingProfile['ad']['object_guid'] ?? '')));
            $sameGuid = $existingGuid !== '' && hash_equals($existingGuid, strtolower($guid));

            if ($sameGuid) {
                return ['ok' => false, 'error' => 'Ce compte DoMyDesk est déjà lié à cet utilisateur Active Directory. Utilisez la synchronisation.'];
            }
            if (dmd_directory_profile_is_ad($existingProfile)) {
                return ['ok' => false, 'error' => 'Cette adresse email appartient déjà à un compte DoMyDesk lié à un autre utilisateur Active Directory. Fusion refusée.'];
            }
            if (!$mergeExisting) {
                return ['ok' => false, 'error' => 'Un compte DoMyDesk existe déjà avec cette adresse email. Cochez « Fusionner avec le compte DoMyDesk existant » pour conserver le compte et le lier à Active Directory.'];
            }
            $isMerge = true;
        }

        $cfg = dmd_directory_config_read(false);
        $nowIso = date('c');
        $adData = [
            'domain' => (string)($cfg['domain'] ?? ''),
            'netbios_domain' => trim((string)($adUser['netbios_domain'] ?? '')),
            'distinguished_name' => $dn,
            'object_guid' => $guid,
            'object_sid' => (string)($adUser['object_sid'] ?? ''),
            'sam_account_name' => (string)($adUser['sam_account_name'] ?? ''),
            'user_principal_name' => (string)($adUser['user_principal_name'] ?? ''),
            'source_mail' => (string)($adUser['mail'] ?? ''),
            'enabled' => !empty($adUser['enabled']),
            'member_of' => is_array($adUser['member_of'] ?? null) ? array_values($adUser['member_of']) : [],
            'last_sync_at' => $nowIso,
            'sync_state' => 'ok',
        ];

        if ($isMerge) {
            // Fusion non destructive : on conserve le profil et tous les fichiers existants
            // (dashboard, modules, droits, MFA, préférences, média, historique, etc.).
            // Seules les informations nécessaires pour lier l'identité à AD sont ajoutées/mises à jour.
            $profile = $existingProfile;
            $previousAuthSource = strtolower((string)($profile['auth_source'] ?? 'local')) ?: 'local';
            $profile['email'] = $domydeskEmail;
            $profile['auth_source'] = 'active_directory';
            $profile['account_status'] = !empty($adUser['enabled']) ? 'active' : 'suspended';

            // Ne remplace pas les rôles/droits existants lors d'une fusion.
            if (empty($profile['role_system'])) $profile['role_system'] = 'user';
            if (empty($profile['role_metier'])) $profile['role_metier'] = $roleMetier;
            if (empty($profile['created_at'])) $profile['created_at'] = date('Y-m-d H:i:s');

            // Ne remplace pas le nom/prénom personnalisé du compte existant ; complète seulement les champs vides.
            if (trim((string)($profile['prenom'] ?? '')) === '') $profile['prenom'] = trim((string)($adUser['given_name'] ?? ''));
            if (trim((string)($profile['nom'] ?? '')) === '') $profile['nom'] = trim((string)($adUser['surname'] ?? ''));
            if (trim((string)($profile['prenom'] ?? '')) === '' && trim((string)($profile['nom'] ?? '')) === '') {
                $profile['prenom'] = trim((string)($adUser['display_name'] ?? $adUser['sam_account_name'] ?? 'Utilisateur AD'));
            }

            $previousAd = is_array($profile['ad'] ?? null) ? $profile['ad'] : [];
            $profile['ad'] = array_merge($previousAd, $adData, [
                'linked_at' => (string)($previousAd['linked_at'] ?? $nowIso),
                'linked_by' => $actor,
                'merge_existing_account' => true,
                'previous_auth_source' => $previousAuthSource,
            ]);

            if (!dmd_write_profile($domydeskEmail, $profile)) {
                return ['ok' => false, 'error' => 'Impossible de lier le compte DoMyDesk existant à Active Directory.'];
            }

            if (function_exists('dmd_notification_index_refresh_user')) dmd_notification_index_refresh_user($domydeskEmail);
            if (function_exists('dmd_system_log')) dmd_system_log('ad_user_merged', $domydeskEmail, 'success', 'Compte DoMyDesk existant lié à Active Directory sans suppression de ses données.', ['actor' => $actor, 'sam_account_name' => $profile['ad']['sam_account_name'], 'object_guid' => $guid]);
            if (function_exists('dmd_notify_user')) dmd_notify_user($domydeskEmail, 'account_directory_linked', 'Votre compte DoMyDesk est maintenant lié à Active Directory', 'Votre compte DoMyDesk existant a été lié à Active Directory. Vos données, modules, préférences et droits DoMyDesk sont conservés. Utilisez désormais votre identifiant/mot de passe AD pour vous connecter.', ['level' => 'success', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
            return ['ok' => true, 'email' => $domydeskEmail, 'merged' => true];
        }

        if (!dmd_directory_initialize_user_files($domydeskEmail)) return ['ok' => false, 'error' => 'Impossible de créer les fichiers utilisateur DoMyDesk.'];
        $profile = [
            'prenom' => trim((string)($adUser['given_name'] ?? '')),
            'nom' => trim((string)($adUser['surname'] ?? '')),
            'email' => $domydeskEmail,
            'role_system' => 'user',
            'role_metier' => $roleMetier,
            'created_at' => date('Y-m-d H:i:s'),
            'auth_source' => 'active_directory',
            'account_status' => !empty($adUser['enabled']) ? 'active' : 'suspended',
            'ad' => array_merge($adData, [
                'linked_at' => $nowIso,
                'linked_by' => $actor,
                'merge_existing_account' => false,
            ]),
        ];
        if ($profile['prenom'] === '' && $profile['nom'] === '') {
            $display = trim((string)($adUser['display_name'] ?? $adUser['sam_account_name'] ?? 'Utilisateur AD'));
            $profile['prenom'] = $display;
        }
        if (!dmd_write_profile($domydeskEmail, $profile)) return ['ok' => false, 'error' => 'Impossible d’enregistrer le profil DoMyDesk.'];
        if (function_exists('dmd_notification_index_refresh_user')) dmd_notification_index_refresh_user($domydeskEmail);
        if (function_exists('dmd_system_log')) dmd_system_log('ad_user_imported', $domydeskEmail, 'success', 'Utilisateur Active Directory importé dans DoMyDesk.', ['actor' => $actor, 'sam_account_name' => $profile['ad']['sam_account_name'], 'object_guid' => $guid]);
        if (function_exists('dmd_notify_user')) dmd_notify_user($domydeskEmail, 'account_created', 'Votre compte DoMyDesk est lié à Active Directory', 'Votre compte DoMyDesk a été importé depuis Active Directory. Utilisez votre identifiant/mot de passe AD pour vous connecter.', ['level' => 'success', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
        return ['ok' => true, 'email' => $domydeskEmail, 'merged' => false];
    }
}

if (!function_exists('dmd_directory_sync_imported_user')) {
    function dmd_directory_sync_imported_user(string $email): array {
        $profile = dmd_read_profile($email);
        if (!dmd_directory_profile_is_ad($profile)) return ['ok' => false, 'error' => 'Compte non Active Directory.'];
        $dn = trim((string)($profile['ad']['distinguished_name'] ?? ''));
        if ($dn === '') return ['ok' => false, 'error' => 'DN Active Directory absent.'];
        $read = dmd_directory_read_ad_user($dn);
        if (empty($read['ok'])) {
            $profile['account_status'] = 'suspended';
            $profile['ad']['sync_state'] = 'not_found';
            $profile['ad']['last_sync_at'] = date('c');
            dmd_write_profile($email, $profile);
            return ['ok' => false, 'error' => $read['error'] ?? 'Utilisateur introuvable', 'suspended' => true];
        }
        $adUser = $read['user'];
        $profile['prenom'] = trim((string)($adUser['given_name'] ?? $profile['prenom'] ?? '')) ?: (string)($profile['prenom'] ?? '');
        $profile['nom'] = trim((string)($adUser['surname'] ?? $profile['nom'] ?? '')) ?: (string)($profile['nom'] ?? '');
        $profile['account_status'] = !empty($adUser['enabled']) ? 'active' : 'suspended';
        $profile['ad'] = array_merge(is_array($profile['ad'] ?? null) ? $profile['ad'] : [], [
            'netbios_domain' => trim((string)($adUser['netbios_domain'] ?? dmd_directory_netbios_domain_name())),
            'distinguished_name' => (string)$adUser['dn'],
            'object_guid' => (string)$adUser['object_guid'],
            'object_sid' => (string)$adUser['object_sid'],
            'sam_account_name' => (string)$adUser['sam_account_name'],
            'user_principal_name' => (string)$adUser['user_principal_name'],
            'source_mail' => (string)$adUser['mail'],
            'enabled' => !empty($adUser['enabled']),
            'member_of' => is_array($adUser['member_of'] ?? null) ? array_values($adUser['member_of']) : [],
            'last_sync_at' => date('c'),
            'sync_state' => 'ok',
        ]);
        return ['ok' => dmd_write_profile($email, $profile), 'active' => $profile['account_status'] === 'active'];
    }
}

if (!function_exists('dmd_directory_sync_all_imported_users')) {
    function dmd_directory_sync_all_imported_users(): array {
        $result = ['ok' => true, 'total' => 0, 'updated' => 0, 'suspended' => 0, 'failed' => 0, 'errors' => []];
        foreach (glob(DMD_DIRECTORY_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $email = basename($dir);
            $profile = dmd_read_profile($email);
            if (!dmd_directory_profile_is_ad($profile)) continue;
            $result['total']++;
            $sync = dmd_directory_sync_imported_user($email);
            if (!empty($sync['ok'])) $result['updated']++;
            else {
                $result['failed']++;
                if (!empty($sync['suspended'])) $result['suspended']++;
                $result['errors'][] = $email . ' : ' . ($sync['error'] ?? 'échec');
            }
        }
        return $result;
    }
}

if (!function_exists('dmd_directory_sync_role_to_ad')) {
    function dmd_directory_sync_role_to_ad(string $role): array {
        $raw = dmd_directory_config_read_raw();
        $map = is_array($raw['role_group_map'][$role] ?? null) ? $raw['role_group_map'][$role] : [];
        $groupDn = trim((string)($map['group_dn'] ?? ''));
        if ($groupDn === '') return ['ok' => false, 'error' => 'Ce rôle DoMyDesk n’est lié à aucun groupe AD géré.'];
        $dns = [];
        $skipped = [];
        foreach (glob(DMD_DIRECTORY_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dir) {
            $email = basename($dir);
            $profile = dmd_read_profile($email);
            if ((string)($profile['role_metier'] ?? '') !== $role) continue;
            if (!dmd_directory_profile_is_ad($profile)) { $skipped[] = $email; continue; }
            $dn = trim((string)($profile['ad']['distinguished_name'] ?? ''));
            if ($dn !== '' && ($profile['account_status'] ?? 'active') === 'active') $dns[] = $dn;
        }
        $replace = dmd_directory_replace_group_members($groupDn, $dns);
        if (empty($replace['ok'])) return $replace;
        return ['ok' => true, 'count' => count($dns), 'skipped_local_accounts' => $skipped];
    }
}
