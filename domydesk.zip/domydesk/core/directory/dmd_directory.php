<?php
/**
 * DoMyDesk - Annuaire / Active Directory
 * Stockage de configuration, chiffrement des secrets et détection locale.
 */

if (!defined('DMD_DIRECTORY_ROOT')) {
    define('DMD_DIRECTORY_ROOT', dirname(__DIR__, 2));
}

if (!function_exists('dmd_directory_private_dir')) {
    function dmd_directory_private_dir(): string {
        $dir = DMD_DIRECTORY_ROOT . '/var/directory/';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);
        $htaccess = $dir . '.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "Options -Indexes\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n", LOCK_EX);
            @chmod($htaccess, 0640);
        }
        return $dir;
    }
}

if (!function_exists('dmd_directory_security_dir')) {
    function dmd_directory_security_dir(): string {
        $dir = DMD_DIRECTORY_ROOT . '/var/security/';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);
        $htaccess = $dir . '.htaccess';
        if (!is_file($htaccess)) {
            @file_put_contents($htaccess, "Options -Indexes\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n", LOCK_EX);
            @chmod($htaccess, 0640);
        }
        return $dir;
    }
}

if (!function_exists('dmd_directory_config_file')) {
    function dmd_directory_config_file(): string {
        return dmd_directory_private_dir() . 'config.json';
    }
}

if (!function_exists('dmd_directory_key_file')) {
    function dmd_directory_key_file(): string {
        return dmd_directory_security_dir() . 'directory_master.key';
    }
}



if (!function_exists('dmd_directory_ca_dir')) {
    function dmd_directory_ca_dir(): string {
        $dir = dmd_directory_private_dir() . 'certificates/';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);
        return $dir;
    }
}

if (!function_exists('dmd_directory_ca_file')) {
    function dmd_directory_ca_file(): string {
        return dmd_directory_ca_dir() . 'ad-ca.pem';
    }
}

if (!function_exists('dmd_directory_ca_exists')) {
    function dmd_directory_ca_exists(): bool {
        return is_file(dmd_directory_ca_file()) && is_readable(dmd_directory_ca_file());
    }
}

if (!function_exists('dmd_directory_certificate_to_pem')) {
    function dmd_directory_certificate_to_pem(string $raw) {
        if ($raw === '' || trim($raw) === '') return false;

        if (preg_match('/-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----/s', $raw, $m)) {
            $pem = trim($m[0]) . "\n";
        } else {
            // Un .CER Windows peut être DER binaire. L'encapsuler en PEM ne modifie pas le certificat.
            $pem = "-----BEGIN CERTIFICATE-----\n"
                . chunk_split(base64_encode($raw), 64, "\n")
                . "-----END CERTIFICATE-----\n";
        }

        if (!function_exists('openssl_x509_read')) return false;
        $cert = @openssl_x509_read($pem);
        if ($cert === false) return false;
        return $pem;
    }
}

if (!function_exists('dmd_directory_ca_info')) {
    function dmd_directory_ca_info(): array {
        $file = dmd_directory_ca_file();
        if (!is_file($file) || !is_readable($file)) return ['installed' => false];
        $pem = @file_get_contents($file);
        if (!is_string($pem) || $pem === '' || !function_exists('openssl_x509_read')) return ['installed' => false, 'error' => 'Certificat CA illisible.'];
        $cert = @openssl_x509_read($pem);
        if ($cert === false) return ['installed' => false, 'error' => 'Certificat CA invalide.'];
        $parsed = @openssl_x509_parse($cert, true);
        if (!is_array($parsed)) return ['installed' => false, 'error' => 'Impossible de lire le certificat CA.'];

        $fingerprint = '';
        if (function_exists('openssl_x509_fingerprint')) {
            $fp = @openssl_x509_fingerprint($cert, 'sha256');
            if (is_string($fp)) $fingerprint = strtoupper(implode(':', str_split($fp, 2)));
        }

        return [
            'installed' => true,
            'subject_cn' => (string)($parsed['subject']['CN'] ?? ''),
            'issuer_cn' => (string)($parsed['issuer']['CN'] ?? ''),
            'valid_from' => !empty($parsed['validFrom_time_t']) ? date('c', (int)$parsed['validFrom_time_t']) : '',
            'valid_to' => !empty($parsed['validTo_time_t']) ? date('c', (int)$parsed['validTo_time_t']) : '',
            'fingerprint_sha256' => $fingerprint,
            'basic_constraints' => (string)($parsed['extensions']['basicConstraints'] ?? ''),
            'file' => $file,
        ];
    }
}

if (!function_exists('dmd_directory_ca_import')) {
    function dmd_directory_ca_import(string $sourceFile, string $originalName = ''): array {
        if (!extension_loaded('openssl') || !function_exists('openssl_x509_read')) {
            return ['ok' => false, 'error' => 'Extension OpenSSL PHP absente : impossible de valider le certificat CA.'];
        }
        if (!is_file($sourceFile) || !is_readable($sourceFile)) return ['ok' => false, 'error' => 'Fichier certificat introuvable.'];
        $size = @filesize($sourceFile);
        if ($size === false || $size < 1 || $size > 1048576) return ['ok' => false, 'error' => 'Le certificat CA doit faire entre 1 octet et 1 Mo.'];

        if ($originalName !== '') {
            $ext = strtolower((string)pathinfo($originalName, PATHINFO_EXTENSION));
            if ($ext !== '' && !in_array($ext, ['cer', 'crt', 'pem'], true)) {
                return ['ok' => false, 'error' => 'Format refusé. Utilisez un certificat .cer, .crt ou .pem.'];
            }
        }

        $raw = @file_get_contents($sourceFile);
        if (!is_string($raw) || $raw === '') return ['ok' => false, 'error' => 'Impossible de lire le certificat CA.'];
        $pem = dmd_directory_certificate_to_pem($raw);
        if (!is_string($pem) || $pem === '') return ['ok' => false, 'error' => 'Le fichier fourni n’est pas un certificat X.509 valide.'];

        $cert = @openssl_x509_read($pem);
        $parsed = $cert !== false ? @openssl_x509_parse($cert, true) : false;
        if (!is_array($parsed)) return ['ok' => false, 'error' => 'Impossible d’analyser le certificat X.509.'];

        $now = time();
        if (!empty($parsed['validFrom_time_t']) && (int)$parsed['validFrom_time_t'] > $now + 300) {
            return ['ok' => false, 'error' => 'Le certificat CA n’est pas encore valide.'];
        }
        if (!empty($parsed['validTo_time_t']) && (int)$parsed['validTo_time_t'] < $now) {
            return ['ok' => false, 'error' => 'Le certificat CA est expiré.'];
        }
        $constraints = (string)($parsed['extensions']['basicConstraints'] ?? '');
        if ($constraints !== '' && stripos($constraints, 'CA:TRUE') === false) {
            return ['ok' => false, 'error' => 'Le certificat fourni n’est pas marqué comme autorité de certification (CA:TRUE).'];
        }

        $target = dmd_directory_ca_file();
        $tmp = $target . '.tmp.' . bin2hex(random_bytes(6));
        if (@file_put_contents($tmp, $pem, LOCK_EX) === false) return ['ok' => false, 'error' => 'Impossible d’enregistrer le certificat CA dans DoMyDesk.'];
        @chmod($tmp, 0640);
        if (!@rename($tmp, $target)) {
            @unlink($tmp);
            return ['ok' => false, 'error' => 'Impossible d’activer le certificat CA dans DoMyDesk.'];
        }
        @chmod($target, 0640);
        return ['ok' => true, 'info' => dmd_directory_ca_info()];
    }
}

if (!function_exists('dmd_directory_ca_delete')) {
    function dmd_directory_ca_delete(): bool {
        $file = dmd_directory_ca_file();
        return !is_file($file) || @unlink($file);
    }
}

if (!function_exists('dmd_directory_config_defaults')) {
    function dmd_directory_config_defaults(): array {
        return [
            'version' => 1,
            'enabled' => false,
            'authentication_enabled' => false,
            'write_enabled' => false,
            'host' => '',
            'port' => 636,
            'security' => 'ldaps',
            'verify_certificate' => true,
            'timeout' => 8,
            'domain' => '',
            'base_dn' => '',
            'user_base_dn' => '',
            'group_base_dn' => '',
            'managed_ou_dn' => '',
            'bind_user' => '',
            'bind_password' => '',
            'role_group_map' => [],
            'last_updated_at' => '',
            'last_updated_by' => '',
        ];
    }
}

if (!function_exists('dmd_directory_json_read')) {
    function dmd_directory_json_read(string $file, array $fallback = []): array {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false) return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}

if (!function_exists('dmd_directory_json_write')) {
    function dmd_directory_json_write(string $file, array $data): bool {
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $ok = @file_put_contents($file, $json . "\n", LOCK_EX) !== false;
        if ($ok) @chmod($file, 0640);
        return $ok;
    }
}

if (!function_exists('dmd_directory_master_key')) {
    function dmd_directory_master_key(): string {
        $file = dmd_directory_key_file();
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            if (is_string($raw) && strlen($raw) === 32) return $raw;
            $decoded = is_string($raw) ? base64_decode(trim($raw), true) : false;
            if (is_string($decoded) && strlen($decoded) === 32) return $decoded;
        }
        $key = random_bytes(32);
        if (@file_put_contents($file, $key, LOCK_EX) === false) return '';
        @chmod($file, 0600);
        return $key;
    }
}

if (!function_exists('dmd_directory_secret_encrypt')) {
    function dmd_directory_secret_encrypt(string $plain) {
        if ($plain === '') return '';
        $key = dmd_directory_master_key();
        if ($key === '') return false;

        if (function_exists('sodium_crypto_secretbox')) {
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = sodium_crypto_secretbox($plain, $nonce, $key);
            return 'sodium:' . base64_encode($nonce . $cipher);
        }

        if (function_exists('openssl_encrypt')) {
            $iv = random_bytes(12);
            $tag = '';
            $cipher = @openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
            if ($cipher !== false) return 'gcm:' . base64_encode($iv . $tag . $cipher);
        }
        return false;
    }
}

if (!function_exists('dmd_directory_secret_decrypt')) {
    function dmd_directory_secret_decrypt(string $stored) {
        if ($stored === '') return '';
        $key = dmd_directory_master_key();
        if ($key === '') return false;

        if (str_starts_with($stored, 'sodium:') && function_exists('sodium_crypto_secretbox_open')) {
            $raw = base64_decode(substr($stored, 7), true);
            if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return false;
            $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            return sodium_crypto_secretbox_open($cipher, $nonce, $key);
        }

        if (str_starts_with($stored, 'gcm:') && function_exists('openssl_decrypt')) {
            $raw = base64_decode(substr($stored, 4), true);
            if (!is_string($raw) || strlen($raw) <= 28) return false;
            $iv = substr($raw, 0, 12);
            $tag = substr($raw, 12, 16);
            $cipher = substr($raw, 28);
            return @openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '');
        }
        return false;
    }
}

if (!function_exists('dmd_directory_normalize_dn')) {
    function dmd_directory_normalize_dn(string $dn): string {
        $parts = preg_split('/\s*,\s*/', trim($dn));
        return strtolower(implode(',', array_filter(array_map('trim', $parts))));
    }
}

if (!function_exists('dmd_directory_dn_is_within')) {
    function dmd_directory_dn_is_within(string $dn, string $baseDn): bool {
        $dn = dmd_directory_normalize_dn($dn);
        $baseDn = dmd_directory_normalize_dn($baseDn);
        if ($dn === '' || $baseDn === '') return false;
        return $dn === $baseDn || str_ends_with($dn, ',' . $baseDn);
    }
}

if (!function_exists('dmd_directory_domain_to_base_dn')) {
    function dmd_directory_domain_to_base_dn(string $domain): string {
        $domain = trim($domain, " .\t\r\n");
        if ($domain === '' || !str_contains($domain, '.')) return '';
        $labels = array_values(array_filter(explode('.', $domain), static fn($v) => $v !== ''));
        return implode(',', array_map(static fn($v) => 'DC=' . $v, $labels));
    }
}

if (!function_exists('dmd_directory_config_read_raw')) {
    function dmd_directory_config_read_raw(): array {
        $defaults = dmd_directory_config_defaults();
        $raw = dmd_directory_json_read(dmd_directory_config_file(), []);
        $cfg = array_replace($defaults, $raw);
        // Active Directory DoMyDesk fonctionne désormais uniquement en LDAPS.
        // Toute ancienne configuration StartTLS/389 est normalisée à la lecture,
        // sans attendre que le Superadmin réenregistre le formulaire.
        $cfg['security'] = 'ldaps';
        $cfg['port'] = 636;
        $cfg['verify_certificate'] = true;
        $cfg['role_group_map'] = is_array($cfg['role_group_map'] ?? null) ? $cfg['role_group_map'] : [];
        return $cfg;
    }
}

if (!function_exists('dmd_directory_config_read')) {
    function dmd_directory_config_read(bool $withSecret = false): array {
        $cfg = dmd_directory_config_read_raw();
        if ($withSecret) {
            $decrypted = dmd_directory_secret_decrypt((string)($cfg['bind_password'] ?? ''));
            $cfg['bind_password'] = is_string($decrypted) ? $decrypted : '';
        } else {
            $cfg['bind_password'] = '';
            $cfg['has_bind_password'] = (string)($cfg['bind_password_encrypted'] ?? '') !== '';
            // Compatibilité : le secret est historiquement stocké dans bind_password du fichier brut.
            $raw = dmd_directory_config_read_raw();
            $cfg['has_bind_password'] = trim((string)($raw['bind_password'] ?? '')) !== '';
        }
        return $cfg;
    }
}

if (!function_exists('dmd_directory_config_write')) {
    function dmd_directory_config_write(array $input, string $actor = ''): array {
        $oldRaw = dmd_directory_config_read_raw();
        $cfg = dmd_directory_config_defaults();

        $cfg['enabled'] = !empty($input['enabled']);
        $cfg['authentication_enabled'] = !empty($input['authentication_enabled']);
        $cfg['write_enabled'] = !empty($input['write_enabled']);
        $cfg['host'] = trim((string)($input['host'] ?? ''));
        // DoMyDesk n'accepte plus StartTLS/389 pour Active Directory :
        // le transport est fixé à LDAPS/636 afin d'éviter toute divergence entre
        // l'interface, la configuration enregistrée et le moteur LDAP.
        $cfg['security'] = 'ldaps';
        $cfg['port'] = 636;
        // La vérification TLS est obligatoire : une CA privée peut être importée directement dans DoMyDesk.
        $cfg['verify_certificate'] = true;
        $cfg['timeout'] = max(2, min(30, (int)($input['timeout'] ?? 8)));
        $cfg['domain'] = trim((string)($input['domain'] ?? ''));
        $cfg['base_dn'] = trim((string)($input['base_dn'] ?? ''));
        if ($cfg['base_dn'] === '' && $cfg['domain'] !== '') $cfg['base_dn'] = dmd_directory_domain_to_base_dn($cfg['domain']);
        // La lecture AD est toujours effectuée depuis la Base DN et parcourt récursivement toutes les OU.
        // Ces clés sont conservées pour compatibilité avec les anciennes configurations uniquement.
        $cfg['user_base_dn'] = $cfg['base_dn'];
        $cfg['group_base_dn'] = $cfg['base_dn'];
        $cfg['managed_ou_dn'] = trim((string)($input['managed_ou_dn'] ?? ''));
        $cfg['bind_user'] = trim((string)($input['bind_user'] ?? ''));
        $cfg['role_group_map'] = is_array($oldRaw['role_group_map'] ?? null) ? $oldRaw['role_group_map'] : [];
        $cfg['last_updated_at'] = date('c');
        $cfg['last_updated_by'] = $actor;

        $newPassword = (string)($input['bind_password'] ?? '');
        if ($newPassword !== '') {
            $encrypted = dmd_directory_secret_encrypt($newPassword);
            if (!is_string($encrypted) || $encrypted === '') return ['ok' => false, 'error' => 'Impossible de chiffrer le mot de passe du compte LDAP.'];
            $cfg['bind_password'] = $encrypted;
        } else {
            $cfg['bind_password'] = (string)($oldRaw['bind_password'] ?? '');
        }

        if ($cfg['enabled'] && ($cfg['host'] === '' || $cfg['base_dn'] === '' || $cfg['bind_user'] === '')) {
            return ['ok' => false, 'error' => 'Serveur, Base DN et compte LDAP sont obligatoires quand l’annuaire est activé.'];
        }
        if ($cfg['enabled'] && trim((string)$cfg['bind_password']) === '') {
            return ['ok' => false, 'error' => 'Le mot de passe du compte LDAP est obligatoire lors de la première configuration.'];
        }
        if ($cfg['write_enabled'] && $cfg['managed_ou_dn'] === '') {
            return ['ok' => false, 'error' => 'Une OU gérée est obligatoire avant d’autoriser les écritures Active Directory.'];
        }

        if (!dmd_directory_json_write(dmd_directory_config_file(), $cfg)) {
            return ['ok' => false, 'error' => 'Impossible d’enregistrer la configuration Active Directory.'];
        }
        return ['ok' => true, 'config' => dmd_directory_config_read(false)];
    }
}

if (!function_exists('dmd_directory_set_role_group_map')) {
    function dmd_directory_set_role_group_map(string $role, string $groupDn, string $groupName, string $actor = ''): bool {
        $raw = dmd_directory_config_read_raw();
        if (!is_array($raw['role_group_map'] ?? null)) $raw['role_group_map'] = [];
        $raw['role_group_map'][$role] = [
            'group_dn' => $groupDn,
            'group_name' => $groupName,
            'managed' => true,
            'updated_at' => date('c'),
            'updated_by' => $actor,
        ];
        $raw['last_updated_at'] = date('c');
        $raw['last_updated_by'] = $actor;
        return dmd_directory_json_write(dmd_directory_config_file(), $raw);
    }
}

if (!function_exists('dmd_directory_remove_role_group_map')) {
    function dmd_directory_remove_role_group_map(string $role, string $actor = ''): bool {
        $raw = dmd_directory_config_read_raw();
        if (isset($raw['role_group_map'][$role])) unset($raw['role_group_map'][$role]);
        $raw['last_updated_at'] = date('c');
        $raw['last_updated_by'] = $actor;
        return dmd_directory_json_write(dmd_directory_config_file(), $raw);
    }
}

if (!function_exists('dmd_directory_detect_local_domain')) {
    /**
     * Détecte/propose un contrôleur AD.
     *
     * IMPORTANT : le domaine saisi dans le formulaire est prioritaire. L'ancienne
     * version ignorait cet argument et tentait uniquement de déduire le domaine
     * depuis l'OS hôte, ce qui échouait sur un NAS/Linux non joint au domaine.
     */
    function dmd_directory_detect_local_domain(string $domainHint = '', string $hostHint = ''): array {
        $domains = [];
        $domainHint = strtolower(trim($domainHint, " .\t\r\n"));
        $hostHint = rtrim(trim($hostHint), '.');

        if ($domainHint !== '' && str_contains($domainHint, '.')) {
            $domains[] = $domainHint;
        }

        // Si aucun indice n'est fourni, réutiliser aussi la configuration déjà
        // enregistrée avant d'essayer de déduire quoi que ce soit depuis l'hôte.
        $stored = dmd_directory_config_read_raw();
        $storedDomain = strtolower(trim((string)($stored['domain'] ?? ''), " .\t\r\n"));
        $storedHost = rtrim(trim((string)($stored['host'] ?? '')), '.');
        if ($storedDomain !== '' && str_contains($storedDomain, '.')) $domains[] = $storedDomain;
        if ($hostHint === '' && $storedHost !== '') $hostHint = $storedHost;

        foreach (['USERDNSDOMAIN', 'DNSDOMAIN', 'DOMAIN'] as $key) {
            $v = strtolower(trim((string)getenv($key), " .\t\r\n"));
            if ($v !== '' && str_contains($v, '.')) $domains[] = $v;
        }

        $files = ['/etc/krb5.conf', '/etc/sssd/sssd.conf', '/etc/samba/smb.conf'];
        foreach ($files as $file) {
            if (!is_readable($file)) continue;
            $raw = (string)@file_get_contents($file);
            if ($raw === '') continue;
            if (preg_match_all('/^\s*(?:default_realm|realm|ad_domain)\s*=\s*([^#;\r\n]+)/mi', $raw, $m)) {
                foreach ($m[1] as $candidate) {
                    $candidate = strtolower(trim((string)$candidate, " \t\"'"));
                    if ($candidate !== '' && str_contains($candidate, '.')) $domains[] = $candidate;
                }
            }
        }

        $domains = array_values(array_unique(array_filter($domains)));
        $domain = $domains[0] ?? '';
        $controllers = [];

        if ($domain !== '' && function_exists('dns_get_record')) {
            $queries = ['_ldap._tcp.dc._msdcs.' . $domain, '_ldap._tcp.' . $domain];
            foreach ($queries as $q) {
                $records = @dns_get_record($q, DNS_SRV);
                if (!is_array($records)) continue;
                // Priorité la plus basse puis poids le plus élevé.
                usort($records, static function ($a, $b) {
                    $pa = (int)($a['pri'] ?? $a['priority'] ?? 0);
                    $pb = (int)($b['pri'] ?? $b['priority'] ?? 0);
                    if ($pa !== $pb) return $pa <=> $pb;
                    $wa = (int)($a['weight'] ?? 0);
                    $wb = (int)($b['weight'] ?? 0);
                    return $wb <=> $wa;
                });
                foreach ($records as $record) {
                    $target = rtrim((string)($record['target'] ?? ''), '.');
                    if ($target !== '' && !in_array($target, $controllers, true)) $controllers[] = $target;
                }
                if ($controllers) break;
            }
        }

        // Un hébergeur DoMyDesk n'est pas forcément membre du domaine et peut ne
        // pas utiliser le DNS AD pour les requêtes SRV. Si le Superadmin a déjà
        // saisi un FQDN de contrôleur, ne le jetez pas : validez sa résolution A/AAAA
        // et utilisez-le comme proposition de contrôleur.
        $hostHintResolved = false;
        if ($hostHint !== '' && !filter_var($hostHint, FILTER_VALIDATE_IP)) {
            $ips = [];
            if (function_exists('dns_get_record')) {
                $records = @dns_get_record($hostHint, DNS_A | DNS_AAAA);
                if (is_array($records)) {
                    foreach ($records as $record) {
                        foreach (['ip', 'ipv6'] as $key) {
                            $ip = trim((string)($record[$key] ?? ''));
                            if ($ip !== '') $ips[] = $ip;
                        }
                    }
                }
            }
            if (!$ips && function_exists('gethostbynamel')) {
                $fallbackIps = @gethostbynamel($hostHint);
                if (is_array($fallbackIps)) $ips = array_merge($ips, $fallbackIps);
            }
            $hostHintResolved = !empty(array_filter($ips));
            if ($hostHintResolved && !in_array($hostHint, $controllers, true)) {
                array_unshift($controllers, $hostHint);
            }
        }

        $host = $controllers[0] ?? '';
        $source = '';
        if ($host !== '') {
            $source = ($hostHint !== '' && strcasecmp($host, $hostHint) === 0) ? 'configured_host' : 'dns_srv';
        } elseif ($domain !== '') {
            $source = 'domain_only';
        }

        return [
            'detected' => $domain !== '' || $host !== '',
            'domain' => $domain,
            'base_dn' => dmd_directory_domain_to_base_dn($domain),
            'controllers' => $controllers,
            'host' => $host,
            'source' => $source,
            'host_hint_resolved' => $hostHintResolved,
        ];
    }
}
