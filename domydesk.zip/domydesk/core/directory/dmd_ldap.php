<?php
require_once __DIR__ . '/dmd_directory.php';

if (!function_exists('dmd_directory_ldap_available')) {
    function dmd_directory_ldap_available(): bool {
        return extension_loaded('ldap') && function_exists('ldap_connect') && function_exists('ldap_bind');
    }
}

if (!function_exists('dmd_directory_ldap_error_text')) {
    function dmd_directory_ldap_error_text($ldap = null): string {
        if ($ldap && function_exists('ldap_error')) {
            $err = @ldap_error($ldap);
            if (is_string($err) && $err !== '') return $err;
        }
        return 'Erreur LDAP inconnue';
    }
}


if (!function_exists('dmd_directory_ldap_diagnostic')) {
    function dmd_directory_ldap_diagnostic($ldap): array {
        $message = '';
        if ($ldap && defined('LDAP_OPT_DIAGNOSTIC_MESSAGE')) {
            $diag = '';
            if (@ldap_get_option($ldap, LDAP_OPT_DIAGNOSTIC_MESSAGE, $diag) && is_string($diag)) {
                $message = trim($diag);
            }
        }
        $code = '';
        if ($message !== '' && preg_match('/(?:data\s+)([0-9a-fA-F]{3,4})\b/i', $message, $m)) {
            $code = strtolower($m[1]);
        }
        $labels = [
            '525' => 'Compte Active Directory introuvable.',
            '52e' => 'Identifiant ou mot de passe incorrect.',
            '530' => 'Connexion interdite à cette heure pour ce compte.',
            '531' => 'Connexion interdite depuis cette machine pour ce compte.',
            '532' => 'Mot de passe Active Directory expiré.',
            '533' => 'Compte Active Directory désactivé.',
            '701' => 'Compte Active Directory expiré.',
            '773' => 'Le compte doit changer son mot de passe à la prochaine ouverture de session. Pour un compte de service DoMyDesk, désactivez cette obligation puis définissez un mot de passe dédié définitif.',
            '775' => 'Compte Active Directory verrouillé.',
        ];
        return [
            'code' => $code,
            'message' => $message,
            'friendly' => $labels[$code] ?? '',
        ];
    }
}

if (!function_exists('dmd_directory_service_bind_candidates')) {
    function dmd_directory_service_bind_candidates(array $cfg): array {
        $entered = trim((string)($cfg['bind_user'] ?? ''));
        if ($entered === '') return [];
        $out = [];
        $add = static function (string $value) use (&$out): void {
            $value = trim($value);
            if ($value !== '' && !in_array($value, $out, true)) $out[] = $value;
        };
        $add($entered);

        // DN explicite : ne pas inventer d'autres formes si l'administrateur l'a fourni.
        if (str_contains($entered, '=')) return $out;

        $domain = trim((string)($cfg['domain'] ?? ''));
        $sam = $entered;
        if (str_contains($sam, '@')) $sam = strstr($sam, '@', true) ?: $sam;
        if (str_contains($sam, '\\')) {
            $parts = explode('\\', $sam, 2);
            $sam = (string)($parts[1] ?? $sam);
        }
        $sam = trim($sam);

        if ($sam !== '' && $domain !== '') {
            $add($sam . '@' . $domain);
            $netbios = strtoupper((string)(explode('.', $domain)[0] ?? ''));
            if ($netbios !== '') $add($netbios . '\\' . $sam);
        }

        // Cas courant DoMyDesk : le compte de service est rangé dans l'OU renseignée
        // pour les utilisateurs. Cette tentative évite d'imposer un format UPN particulier.
        $userBase = trim((string)($cfg['user_base_dn'] ?? ''));
        if ($sam !== '' && $userBase !== '') {
            $add('CN=' . dmd_directory_ldap_escape_dn_value($sam) . ',' . $userBase);
        }
        return $out;
    }
}

if (!function_exists('dmd_directory_ldap_bind_service')) {
    /**
     * Tente le bind du compte de service avec plusieurs formes d'identité.
     * Après un échec d'authentification, Active Directory peut laisser la
     * connexion LDAP dans un état inutilisable selon le transport/libldap.
     * Chaque forme suivante est donc testée sur une NOUVELLE connexion.
     */
    function dmd_directory_ldap_bind_service($ldap, array $cfg): array {
        $password = (string)($cfg['bind_password'] ?? '');
        if ($password === '') return ['ok' => false, 'error' => 'Mot de passe du compte LDAP manquant.'];
        $candidates = dmd_directory_service_bind_candidates($cfg);
        if (!$candidates) return ['ok' => false, 'error' => 'Compte LDAP manquant.'];

        $host = trim((string)($cfg['connect_host'] ?? $cfg['effective_host'] ?? $cfg['host'] ?? ''));
        $security = 'ldaps';
        $port = 636;
        $timeout = max(2, (int)($cfg['timeout'] ?? 8));

        $lastError = 'Invalid credentials';
        $lastDiag = ['code' => '', 'message' => '', 'friendly' => ''];
        $attempts = [];
        $current = $ldap;

        foreach ($candidates as $idx => $identity) {
            // Le premier essai utilise la connexion déjà préparée par le moteur.
            // Tous les suivants repartent d'une nouvelle session LDAP/TLS.
            if ($idx > 0) {
                if ($current) @ldap_unbind($current);
                $tlsTrust = dmd_directory_ldap_prepare_tls_trust($cfg);
                if (empty($tlsTrust['ok'])) {
                    $attempts[] = ['identity' => $identity, 'error' => (string)($tlsTrust['error'] ?? 'configuration TLS impossible')];
                    $lastError = (string)($tlsTrust['error'] ?? 'Configuration TLS impossible');
                    continue;
                }
                $uri = 'ldaps://' . $host . ':636';
                $current = dmd_directory_ldap_open($uri, $timeout);
                if ($current === false) {
                    $attempts[] = ['identity' => $identity, 'error' => 'connexion LDAP impossible'];
                    $lastError = 'Connexion LDAP impossible';
                    continue;
                }
            }

            if ($current && @ldap_bind($current, $identity, $password)) {
                // Si une nouvelle connexion a réussi, l'appelant doit continuer
                // avec celle-ci car elle porte maintenant le bind valide.
                return ['ok' => true, 'identity' => $identity, 'ldap' => $current];
            }

            $lastError = $current ? dmd_directory_ldap_error_text($current) : 'Connexion LDAP impossible';
            $diag = $current ? dmd_directory_ldap_diagnostic($current) : ['code' => '', 'message' => '', 'friendly' => ''];
            // Ne jamais écraser un vrai code Active Directory (ex. 52e, 533, 775)
            // par une erreur de transport générique provenant d'une tentative suivante.
            if (!empty($diag['code'])) {
                $lastDiag = $diag;
            } elseif (empty($lastDiag['code']) && !empty($diag['message'])) {
                $lastDiag = $diag;
            }
            $attempts[] = [
                'identity' => $identity,
                'error' => $lastError,
                'code' => (string)($diag['code'] ?? ''),
            ];
        }

        if ($current) @ldap_unbind($current);

        $detail = trim((string)($lastDiag['friendly'] ?? ''));
        if ($detail === '') $detail = $lastError;
        $code = trim((string)($lastDiag['code'] ?? ''));
        if ($code !== '') $detail .= ' (AD data ' . $code . ')';
        if ($code === '52e') {
            $detail .= ' Le contrôleur est bien joignable : Active Directory refuse le secret transmis pour ce compte de service.';
        }
        return [
            'ok' => false,
            'error' => $detail,
            'ldap_error' => $lastError,
            'diagnostic' => (string)($lastDiag['message'] ?? ''),
            'code' => $code,
            'tried' => $candidates,
            'attempts' => $attempts,
        ];
    }
}

if (!function_exists('dmd_directory_ldap_escape_filter')) {
    function dmd_directory_ldap_escape_filter(string $value): string {
        if (function_exists('ldap_escape') && defined('LDAP_ESCAPE_FILTER')) return ldap_escape($value, '', LDAP_ESCAPE_FILTER);
        return strtr($value, ["\\" => '\\5c', '*' => '\\2a', '(' => '\\28', ')' => '\\29', "\0" => '\\00']);
    }
}

if (!function_exists('dmd_directory_ldap_escape_dn_value')) {
    function dmd_directory_ldap_escape_dn_value(string $value): string {
        if (function_exists('ldap_escape') && defined('LDAP_ESCAPE_DN')) return ldap_escape($value, '', LDAP_ESCAPE_DN);
        return addcslashes($value, ',=+<>#;\\"');
    }
}

if (!function_exists('dmd_directory_bind_identity')) {
    function dmd_directory_bind_identity(array $cfg): string {
        $user = trim((string)($cfg['bind_user'] ?? ''));
        if ($user === '') return '';
        if (str_contains($user, '=') || str_contains($user, '@') || str_contains($user, '\\')) return $user;
        $domain = trim((string)($cfg['domain'] ?? ''));
        return $domain !== '' ? $user . '@' . $domain : $user;
    }
}

if (!function_exists('dmd_directory_ldap_resolve_host')) {
    function dmd_directory_ldap_resolve_host(string $host): array {
        $host = trim($host);
        if ($host === '') return [];
        if (filter_var($host, FILTER_VALIDATE_IP)) return [$host];

        $out = [];
        if (function_exists('dns_get_record')) {
            $records = @dns_get_record($host, DNS_A | DNS_AAAA);
            if (is_array($records)) {
                foreach ($records as $record) {
                    foreach (['ip', 'ipv6'] as $key) {
                        $ip = trim((string)($record[$key] ?? ''));
                        if ($ip !== '' && !in_array($ip, $out, true)) $out[] = $ip;
                    }
                }
            }
        }
        if (!$out && function_exists('gethostbynamel')) {
            $ips = @gethostbynamel($host);
            if (is_array($ips)) {
                foreach ($ips as $ip) if ($ip !== '' && !in_array($ip, $out, true)) $out[] = $ip;
            }
        }
        return $out;
    }
}

if (!function_exists('dmd_directory_ldap_socket_host')) {
    function dmd_directory_ldap_socket_host(string $host): string {
        return filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? '[' . $host . ']' : $host;
    }
}

if (!function_exists('dmd_directory_ldap_tcp_probe')) {
    function dmd_directory_ldap_tcp_probe(string $host, int $port, int $timeout = 8): array {
        $socketHost = dmd_directory_ldap_socket_host($host);
        $errno = 0;
        $errstr = '';
        $socket = @stream_socket_client('tcp://' . $socketHost . ':' . $port, $errno, $errstr, max(2, $timeout), STREAM_CLIENT_CONNECT);
        if (!is_resource($socket)) {
            return ['ok' => false, 'error' => trim($errstr) !== '' ? trim($errstr) : ('erreur réseau ' . $errno)];
        }
        @fclose($socket);
        return ['ok' => true];
    }
}

if (!function_exists('dmd_directory_stream_socket_probe')) {
    function dmd_directory_stream_socket_probe(string $transport, string $host, int $port, array $sslOptions, int $timeout = 8): array {
        $warnings = [];
        $handler = static function ($severity, $message) use (&$warnings) {
            $warnings[] = trim((string)$message);
            return true;
        };
        set_error_handler($handler);
        try {
            $context = stream_context_create(['ssl' => $sslOptions]);
            $socketHost = dmd_directory_ldap_socket_host($host);
            $errno = 0;
            $errstr = '';
            $socket = stream_socket_client($transport . '://' . $socketHost . ':' . $port, $errno, $errstr, max(2, $timeout), STREAM_CLIENT_CONNECT, $context);
        } finally {
            restore_error_handler();
        }
        if (!is_resource($socket)) {
            $detail = trim($errstr);
            if ($detail === '' && $warnings) $detail = trim((string)end($warnings));
            if ($detail === '') $detail = 'négociation TLS impossible (' . (int)$errno . ')';
            return ['ok' => false, 'error' => $detail, 'warnings' => $warnings];
        }

        $params = @stream_context_get_params($socket);
        $certInfo = [];
        if (is_array($params) && !empty($params['options']['ssl']['peer_certificate']) && function_exists('openssl_x509_parse')) {
            $parsed = @openssl_x509_parse($params['options']['ssl']['peer_certificate'], false);
            if (is_array($parsed)) {
                $certInfo = [
                    'subject_cn' => (string)($parsed['subject']['CN'] ?? ''),
                    'issuer_cn' => (string)($parsed['issuer']['CN'] ?? ''),
                    'valid_from' => !empty($parsed['validFrom_time_t']) ? date('c', (int)$parsed['validFrom_time_t']) : '',
                    'valid_to' => !empty($parsed['validTo_time_t']) ? date('c', (int)$parsed['validTo_time_t']) : '',
                ];
            }
        }
        @fclose($socket);
        return ['ok' => true, 'certificate' => $certInfo, 'warnings' => $warnings];
    }
}

if (!function_exists('dmd_directory_ldap_tls_probe')) {
    function dmd_directory_ldap_tls_probe(string $host, int $port, bool $verifyCertificate, int $timeout = 8): array {
        if (!extension_loaded('openssl')) return ['ok' => false, 'error' => 'Extension OpenSSL PHP absente.'];

        $base = [
            'peer_name' => $host,
            'SNI_enabled' => true,
            'capture_peer_cert' => true,
        ];
        if (dmd_directory_ca_exists()) $base['cafile'] = dmd_directory_ca_file();

        $strict = dmd_directory_stream_socket_probe('ssl', $host, $port, $base + [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ], $timeout);
        if (!empty($strict['ok'])) {
            $strict['verified'] = true;
            return $strict;
        }

        // Diagnostic uniquement : ne sert jamais à établir la vraie session LDAP.
        $relaxed = dmd_directory_stream_socket_probe('ssl', $host, $port, $base + [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ], $timeout);
        if (!empty($relaxed['ok'])) {
            return [
                'ok' => false,
                'tls_ok_without_verification' => true,
                'error' => (string)($strict['error'] ?? 'certificat TLS non approuvé'),
                'certificate' => $relaxed['certificate'] ?? [],
            ];
        }
        return [
            'ok' => false,
            'tls_ok_without_verification' => false,
            'error' => (string)($strict['error'] ?? $relaxed['error'] ?? 'négociation TLS impossible'),
            'relaxed_error' => (string)($relaxed['error'] ?? ''),
        ];
    }
}

if (!function_exists('dmd_directory_ip_is_private')) {
    function dmd_directory_ip_is_private(string $ip): bool {
        $ip = trim($ip);
        if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP) === false) return false;
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            if (preg_match('/^10\./', $ip)) return true;
            if (preg_match('/^192\.168\./', $ip)) return true;
            if (preg_match('/^172\.(\d+)\./', $ip, $m)) {
                $n = (int)$m[1];
                return $n >= 16 && $n <= 31;
            }
            return false;
        }
        $lower = strtolower($ip);
        return str_starts_with($lower, 'fc') || str_starts_with($lower, 'fd') || str_starts_with($lower, 'fe80:');
    }
}

if (!function_exists('dmd_directory_ldap_private_target')) {
    function dmd_directory_ldap_private_target(array $addresses): bool {
        if (!$addresses) return false;
        foreach ($addresses as $ip) {
            if (dmd_directory_ip_is_private((string)$ip)) return true;
        }
        return false;
    }
}

if (!function_exists('dmd_directory_ldap_private_addresses')) {
    function dmd_directory_ldap_private_addresses(array $addresses): array {
        $out = [];
        foreach ($addresses as $ip) {
            $ip = trim((string)$ip);
            if ($ip !== '' && dmd_directory_ip_is_private($ip) && !in_array($ip, $out, true)) $out[] = $ip;
        }
        return $out;
    }
}

if (!function_exists('dmd_directory_ldap_probe_addresses')) {
    /**
     * Teste les adresses une par une au lieu de laisser le résolveur système
     * choisir arbitrairement une IP du FQDN. Les IP privées sont prioritaires.
     */
    function dmd_directory_ldap_probe_addresses(array $addresses, int $port, int $timeout = 8, bool $preferPrivate = true): array {
        $ordered = [];
        if ($preferPrivate) {
            foreach ($addresses as $ip) if (dmd_directory_ip_is_private((string)$ip)) $ordered[] = (string)$ip;
            foreach ($addresses as $ip) if (!dmd_directory_ip_is_private((string)$ip)) $ordered[] = (string)$ip;
        } else {
            foreach ($addresses as $ip) $ordered[] = (string)$ip;
        }
        $ordered = array_values(array_unique(array_filter(array_map('trim', $ordered))));
        $attempts = [];
        foreach ($ordered as $ip) {
            $probe = dmd_directory_ldap_tcp_probe($ip, $port, $timeout);
            $attempts[] = ['address' => $ip, 'ok' => !empty($probe['ok']), 'error' => (string)($probe['error'] ?? '')];
            if (!empty($probe['ok'])) return ['ok' => true, 'address' => $ip, 'attempts' => $attempts];
        }
        return ['ok' => false, 'address' => '', 'attempts' => $attempts];
    }
}

if (!function_exists('dmd_directory_ldap_prepare_tls_trust')) {
    /**
     * Configure libldap pour utiliser la CA importée dans DoMyDesk, sans modifier
     * le magasin de certificats du système hôte.
     */
    function dmd_directory_ldap_prepare_tls_trust(array $cfg): array {
        $caFile = dmd_directory_ca_exists() ? dmd_directory_ca_file() : '';

        // OpenLDAP prend aussi en charge ces variables dans le processus courant.
        // Elles n'écrivent rien dans la configuration du NAS/Linux/Windows hôte.
        @putenv('LDAPTLS_REQCERT=demand');
        if ($caFile !== '') @putenv('LDAPTLS_CACERT=' . $caFile);

        if (defined('LDAP_OPT_X_TLS_REQUIRE_CERT') && defined('LDAP_OPT_X_TLS_DEMAND')) {
            if (@ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_DEMAND) === false) {
                return ['ok' => false, 'error' => 'PHP LDAP n’a pas pu imposer la vérification du certificat TLS.'];
            }
        }

        if ($caFile !== '' && defined('LDAP_OPT_X_TLS_CACERTFILE')) {
            if (@ldap_set_option(null, LDAP_OPT_X_TLS_CACERTFILE, $caFile) === false) {
                return ['ok' => false, 'error' => 'PHP LDAP n’a pas pu charger le certificat CA importé dans DoMyDesk.'];
            }
        }

        // OpenLDAP met en cache son contexte TLS dans les processus PHP persistants.
        // Le reconstruire permet de prendre immédiatement en compte une CA importée/remplacée.
        if (defined('LDAP_OPT_X_TLS_NEWCTX')) {
            @ldap_set_option(null, LDAP_OPT_X_TLS_NEWCTX, 0);
        }

        return ['ok' => true, 'ca_file' => $caFile];
    }
}

if (!function_exists('dmd_directory_ldap_open')) {
    function dmd_directory_ldap_open(string $uri, int $timeout) {
        $ldap = @ldap_connect($uri);
        if ($ldap === false) return false;
        @ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        @ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
        if (defined('LDAP_OPT_NETWORK_TIMEOUT')) @ldap_set_option($ldap, LDAP_OPT_NETWORK_TIMEOUT, $timeout);
        return $ldap;
    }
}

if (!function_exists('dmd_directory_ldap_connect')) {
    function dmd_directory_ldap_connect(?array $config = null, bool $serviceBind = true): array {
        if (!dmd_directory_ldap_available()) {
            return ['ok' => false, 'error' => 'Extension PHP LDAP absente. Installez/activez php-ldap sur le serveur DoMyDesk.'];
        }

        $cfg = $config ?: dmd_directory_config_read(true);
        $host = rtrim(trim((string)($cfg['host'] ?? '')), '.');
        $timeout = max(2, (int)($cfg['timeout'] ?? 8));

        if ($host === '') {
            return ['ok' => false, 'error' => 'Contrôleur Active Directory non configuré. Indiquez son FQDN.'];
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return ['ok' => false, 'error' => 'LDAPS exige le FQDN du contrôleur présent dans son certificat TLS, pas son adresse IP.'];
        }

        // Mode unique et obligatoire. Toute ancienne valeur StartTLS/389 est ignorée.
        $cfg['security'] = 'ldaps';
        $cfg['effective_security'] = 'ldaps';
        $cfg['port'] = 636;
        $cfg['verify_certificate'] = true;
        $cfg['connect_host'] = $host;
        $cfg['effective_host'] = $host;

        if (!dmd_directory_ca_exists()) {
            return ['ok' => false, 'error' => 'Aucune autorité de certification Active Directory n’est importée dans DoMyDesk. Importez le certificat public de la CA qui a signé le certificat LDAPS du contrôleur.'];
        }

        $addresses = dmd_directory_ldap_resolve_host($host);
        if (!$addresses) {
            return ['ok' => false, 'error' => 'Le contrôleur « ' . $host . ' » ne se résout pas en DNS depuis l’hébergeur DoMyDesk.'];
        }

        $tcp = dmd_directory_ldap_probe_addresses($addresses, 636, $timeout, true);
        if (empty($tcp['ok'])) {
            $details = [];
            foreach (($tcp['attempts'] ?? []) as $a) {
                $details[] = (string)($a['address'] ?? '?') . ': ' . ((string)($a['error'] ?? '') ?: 'inaccessible');
            }
            return ['ok' => false, 'error' => 'Le contrôleur ' . $host . ' est résolu (' . implode(', ', $addresses) . ') mais aucune adresse ne répond sur LDAPS/636' . ($details ? ' : ' . implode(' ; ', $details) : '') . '.'];
        }

        // Les options TLS doivent être posées globalement AVANT ldap_connect() pour LDAPS.
        $trust = dmd_directory_ldap_prepare_tls_trust($cfg);
        if (empty($trust['ok'])) return $trust;

        // Diagnostic TLS indépendant de libldap, avec la même CA DoMyDesk.
        $tlsProbe = dmd_directory_ldap_tls_probe($host, 636, true, $timeout);
        if (empty($tlsProbe['ok'])) {
            if (!empty($tlsProbe['tls_ok_without_verification'])) {
                return ['ok' => false, 'error' => 'LDAPS/636 répond, mais le certificat du contrôleur n’est pas validé par la CA importée dans DoMyDesk : ' . (string)($tlsProbe['error'] ?? 'certificat non approuvé') . '.'];
            }
            return ['ok' => false, 'error' => 'La négociation LDAPS sur ' . $host . ':636 a échoué : ' . (string)($tlsProbe['error'] ?? 'erreur TLS inconnue') . '.'];
        }

        // Le FQDN est conservé dans l'URI pour que la validation du nom du certificat fonctionne.
        $uri = 'ldaps://' . $host . ':636';
        $ldap = dmd_directory_ldap_open($uri, $timeout);
        if ($ldap === false) {
            return ['ok' => false, 'error' => 'Impossible d’initialiser la connexion LDAPS vers ' . $uri . '.'];
        }

        if ($serviceBind) {
            $bind = dmd_directory_ldap_bind_service($ldap, $cfg);
            if (empty($bind['ok'])) {
                @ldap_unbind($ldap);
                return ['ok' => false, 'error' => 'Authentification du compte LDAP refusée en LDAPS : ' . (string)($bind['error'] ?? $bind['ldap_error'] ?? 'erreur inconnue') . '.'];
            }
            $ldap = $bind['ldap'] ?? $ldap;
            $cfg['effective_bind_identity'] = (string)($bind['identity'] ?? '');
        }

        return [
            'ok' => true,
            'ldap' => $ldap,
            'config' => $cfg,
            'uri' => $uri,
            'addresses' => $addresses,
            'selected_address' => (string)($tcp['address'] ?? ''),
            'effective_security' => 'ldaps',
            'ca_file' => (string)($trust['ca_file'] ?? ''),
        ];
    }
}

if (!function_exists('dmd_directory_test_connection')) {
    function dmd_directory_test_connection(?array $config = null): array {
        $result = dmd_directory_ldap_connect($config, true);
        if (empty($result['ok'])) return $result;
        $cfg = $result['config'];
        $ldap = $result['ldap'];
        $base = trim((string)($cfg['base_dn'] ?? ''));
        $search = $base !== '' ? @ldap_read($ldap, $base, '(objectClass=*)', ['distinguishedName']) : false;
        if ($search === false) return ['ok' => false, 'error' => 'Connexion et authentification LDAP réussies, mais la Base DN « ' . $base . ' » est inaccessible : ' . dmd_directory_ldap_error_text($ldap)];
        $effective = strtoupper((string)($result['effective_security'] ?? $cfg['effective_security'] ?? $cfg['security'] ?? 'ldaps'));
        $ca = dmd_directory_ca_info();
        $caLabel = !empty($ca['installed']) ? (' CA DoMyDesk : ' . ((string)($ca['subject_cn'] ?? '') ?: 'certificat importé') . '.') : '';
        return ['ok' => true, 'message' => 'Connexion Active Directory validée en ' . $effective . ' : DNS, port ' . (int)($cfg['port'] ?? 0) . ', certificat TLS, compte de service et Base DN sont accessibles.' . $caLabel];
    }
}

if (!function_exists('dmd_directory_guid_to_string')) {
    function dmd_directory_guid_to_string(string $binary): string {
        if (strlen($binary) !== 16) return '';
        $hex = bin2hex($binary);
        return strtolower(substr($hex, 6, 2) . substr($hex, 4, 2) . substr($hex, 2, 2) . substr($hex, 0, 2) . '-' . substr($hex, 10, 2) . substr($hex, 8, 2) . '-' . substr($hex, 14, 2) . substr($hex, 12, 2) . '-' . substr($hex, 16, 4) . '-' . substr($hex, 20, 12));
    }
}

if (!function_exists('dmd_directory_sid_to_string')) {
    function dmd_directory_sid_to_string(string $sid): string {
        $len = strlen($sid);
        if ($len < 8) return '';
        $revision = ord($sid[0]);
        $count = ord($sid[1]);
        $authority = 0;
        for ($i = 2; $i < 8; $i++) $authority = ($authority << 8) | ord($sid[$i]);
        $parts = ['S', (string)$revision, (string)$authority];
        $offset = 8;
        for ($i = 0; $i < $count && $offset + 4 <= $len; $i++, $offset += 4) {
            $v = unpack('V', substr($sid, $offset, 4));
            $parts[] = (string)($v[1] ?? 0);
        }
        return implode('-', $parts);
    }
}

if (!function_exists('dmd_directory_entry_first')) {
    function dmd_directory_entry_first(array $entry, string $key): string {
        $key = strtolower($key);
        if (!isset($entry[$key])) return '';
        $v = $entry[$key];
        if (is_array($v)) return isset($v[0]) && is_string($v[0]) ? $v[0] : '';
        return is_string($v) ? $v : '';
    }
}

if (!function_exists('dmd_directory_entry_values')) {
    function dmd_directory_entry_values(array $entry, string $key): array {
        $key = strtolower($key);
        if (!isset($entry[$key]) || !is_array($entry[$key])) return [];
        $out = [];
        $count = isset($entry[$key]['count']) ? (int)$entry[$key]['count'] : count($entry[$key]);
        for ($i = 0; $i < $count; $i++) if (isset($entry[$key][$i]) && is_string($entry[$key][$i])) $out[] = $entry[$key][$i];
        return $out;
    }
}

if (!function_exists('dmd_directory_parse_ad_user_entry')) {
    function dmd_directory_parse_ad_user_entry(array $entry): array {
        $uac = (int)dmd_directory_entry_first($entry, 'useraccountcontrol');
        $guidRaw = dmd_directory_entry_first($entry, 'objectguid');
        $sidRaw = dmd_directory_entry_first($entry, 'objectsid');
        $dn = (string)($entry['dn'] ?? dmd_directory_entry_first($entry, 'distinguishedname'));
        return [
            'dn' => $dn,
            'object_guid' => $guidRaw !== '' ? dmd_directory_guid_to_string($guidRaw) : '',
            'object_sid' => $sidRaw !== '' ? dmd_directory_sid_to_string($sidRaw) : '',
            'sam_account_name' => dmd_directory_entry_first($entry, 'samaccountname'),
            'user_principal_name' => dmd_directory_entry_first($entry, 'userprincipalname'),
            'mail' => dmd_directory_entry_first($entry, 'mail'),
            'given_name' => dmd_directory_entry_first($entry, 'givenname'),
            'surname' => dmd_directory_entry_first($entry, 'sn'),
            'display_name' => dmd_directory_entry_first($entry, 'displayname'),
            'enabled' => (($uac & 2) === 0),
            'user_account_control' => $uac,
            'member_of' => dmd_directory_entry_values($entry, 'memberof'),
        ];
    }
}

if (!function_exists('dmd_directory_netbios_domain_name')) {
    function dmd_directory_netbios_domain_name($ldap = null, ?array $cfg = null): string {
        static $cache = [];

        $cfg = is_array($cfg) ? $cfg : dmd_directory_config_read(true);
        $baseDn = trim((string)($cfg['base_dn'] ?? ''));
        if ($baseDn === '') return '';

        $cacheKey = strtolower(dmd_directory_normalize_dn($baseDn));
        if (array_key_exists($cacheKey, $cache)) return (string)$cache[$cacheKey];
        $cache[$cacheKey] = '';

        if ($ldap === null) {
            $conn = dmd_directory_ldap_connect($cfg, true);
            if (empty($conn['ok'])) return '';
            $ldap = $conn['ldap'];
            $cfg = $conn['config'];
        }

        $rootSearch = @ldap_read($ldap, '', '(objectClass=*)', ['configurationNamingContext']);
        if ($rootSearch === false) return '';
        $rootEntries = @ldap_get_entries($ldap, $rootSearch);
        if (!is_array($rootEntries) || (int)($rootEntries['count'] ?? 0) < 1) return '';

        $configurationDn = dmd_directory_entry_first($rootEntries[0], 'configurationnamingcontext');
        if ($configurationDn === '') return '';

        $partitionsDn = 'CN=Partitions,' . $configurationDn;
        $filter = '(&(objectClass=crossRef)(nCName=' . dmd_directory_ldap_escape_filter($baseDn) . '))';
        $search = @ldap_search($ldap, $partitionsDn, $filter, ['nETBIOSName'], 0, 2);
        if ($search === false) return '';

        $entries = @ldap_get_entries($ldap, $search);
        if (!is_array($entries) || (int)($entries['count'] ?? 0) < 1) return '';

        $netbios = trim((string)dmd_directory_entry_first($entries[0], 'netbiosname'));
        if ($netbios !== '') $cache[$cacheKey] = $netbios;
        return $netbios;
    }
}

if (!function_exists('dmd_directory_list_users')) {
    function dmd_directory_list_users(string $query = ''): array {
        $conn = dmd_directory_ldap_connect(null, true);
        if (empty($conn['ok'])) return $conn;
        $cfg = $conn['config'];
        $ldap = $conn['ldap'];
        $base = trim((string)($cfg['base_dn'] ?? ''));
        if ($base === '') return ['ok' => false, 'error' => 'Base DN Active Directory absente.'];
        $filter = '(&(objectCategory=person)(objectClass=user))';
        if ($query !== '') {
            $q = dmd_directory_ldap_escape_filter($query);
            $filter = '(&(objectCategory=person)(objectClass=user)(|(sAMAccountName=*' . $q . '*)(userPrincipalName=*' . $q . '*)(mail=*' . $q . '*)(displayName=*' . $q . '*)))';
        }
        $attrs = ['distinguishedName','objectGUID','objectSid','sAMAccountName','userPrincipalName','mail','givenName','sn','displayName','userAccountControl','memberOf'];
        $search = @ldap_search($ldap, $base, $filter, $attrs, 0, 2000);
        if ($search === false) return ['ok' => false, 'error' => 'Recherche utilisateurs AD impossible : ' . dmd_directory_ldap_error_text($ldap)];
        $entries = @ldap_get_entries($ldap, $search);
        if (!is_array($entries)) return ['ok' => false, 'error' => 'Réponse LDAP utilisateurs invalide.'];
        $users = [];
        $netbiosDomain = dmd_directory_netbios_domain_name($ldap, $cfg);
        $count = (int)($entries['count'] ?? 0);
        for ($i = 0; $i < $count; $i++) {
            if (!isset($entries[$i]) || !is_array($entries[$i])) continue;
            $user = dmd_directory_parse_ad_user_entry($entries[$i]);
            $user['netbios_domain'] = $netbiosDomain;
            $users[] = $user;
        }
        usort($users, static fn($a, $b) => strnatcasecmp(($a['display_name'] ?: $a['sam_account_name']), ($b['display_name'] ?: $b['sam_account_name'])));
        return ['ok' => true, 'users' => $users, 'count' => count($users)];
    }
}

if (!function_exists('dmd_directory_read_ad_user')) {
    function dmd_directory_read_ad_user(string $dn): array {
        $conn = dmd_directory_ldap_connect(null, true);
        if (empty($conn['ok'])) return $conn;
        $attrs = ['distinguishedName','objectGUID','objectSid','sAMAccountName','userPrincipalName','mail','givenName','sn','displayName','userAccountControl','memberOf'];
        $search = @ldap_read($conn['ldap'], $dn, '(objectClass=user)', $attrs);
        if ($search === false) return ['ok' => false, 'error' => 'Utilisateur AD introuvable : ' . dmd_directory_ldap_error_text($conn['ldap'])];
        $entries = @ldap_get_entries($conn['ldap'], $search);
        if (!is_array($entries) || (int)($entries['count'] ?? 0) < 1) return ['ok' => false, 'error' => 'Utilisateur AD introuvable.'];
        $user = dmd_directory_parse_ad_user_entry($entries[0]);
        $user['netbios_domain'] = dmd_directory_netbios_domain_name($conn['ldap'], $conn['config']);
        return ['ok' => true, 'user' => $user];
    }
}

if (!function_exists('dmd_directory_authenticate_ad_profile')) {
    function dmd_directory_authenticate_ad_profile(array $profile, string $password): array {
        $cfg = dmd_directory_config_read(true);
        if (empty($cfg['enabled']) || empty($cfg['authentication_enabled'])) return ['ok' => false, 'error' => 'Authentification Active Directory désactivée.'];
        if ($password === '') return ['ok' => false, 'error' => 'Mot de passe vide.'];
        if (($profile['account_status'] ?? 'active') !== 'active') return ['ok' => false, 'error' => 'Compte DoMyDesk suspendu ou en attente.'];
        $ad = is_array($profile['ad'] ?? null) ? $profile['ad'] : [];
        if (array_key_exists('enabled', $ad) && empty($ad['enabled'])) return ['ok' => false, 'error' => 'Compte Active Directory désactivé.'];

        $conn = dmd_directory_ldap_connect($cfg, false);
        if (empty($conn['ok'])) return $conn;
        $identity = trim((string)($ad['user_principal_name'] ?? ''));
        if ($identity === '') {
            $sam = trim((string)($ad['sam_account_name'] ?? ''));
            $domain = trim((string)($cfg['domain'] ?? ''));
            if ($sam !== '') $identity = $domain !== '' ? $sam . '@' . $domain : $sam;
        }
        if ($identity === '') $identity = trim((string)($ad['distinguished_name'] ?? ''));
        if ($identity === '') return ['ok' => false, 'error' => 'Identité AD absente du profil DoMyDesk.'];

        if (!@ldap_bind($conn['ldap'], $identity, $password)) {
            $err = dmd_directory_ldap_error_text($conn['ldap']);
            if (stripos($err, 'strong') !== false || stripos($err, 'confidentiality') !== false || stripos($err, 'sign') !== false) {
                return ['ok' => false, 'error' => 'Le contrôleur Active Directory exige une session LDAP signée/TLS pour vérifier le mot de passe. Vérifiez le certificat LDAPS du contrôleur et la CA importée dans DoMyDesk.'];
            }
            return ['ok' => false, 'error' => 'Identifiant ou mot de passe Active Directory incorrect.'];
        }
        return ['ok' => true, 'warning' => (string)($conn['warning'] ?? '')];
    }
}

if (!function_exists('dmd_directory_list_groups')) {
    function dmd_directory_list_groups(): array {
        $conn = dmd_directory_ldap_connect(null, true);
        if (empty($conn['ok'])) return $conn;
        $cfg = $conn['config'];
        $base = trim((string)($cfg['base_dn'] ?? ''));
        if ($base === '') return ['ok' => false, 'error' => 'Base DN Active Directory absente.'];
        $search = @ldap_search($conn['ldap'], $base, '(objectClass=group)', ['cn','sAMAccountName','distinguishedName','member','groupType'], 0, 2000);
        if ($search === false) return ['ok' => false, 'error' => 'Recherche groupes AD impossible : ' . dmd_directory_ldap_error_text($conn['ldap'])];
        $entries = @ldap_get_entries($conn['ldap'], $search);
        $groups = [];
        $count = is_array($entries) ? (int)($entries['count'] ?? 0) : 0;
        for ($i=0; $i<$count; $i++) {
            $e = $entries[$i];
            $groups[] = [
                'dn' => (string)($e['dn'] ?? dmd_directory_entry_first($e, 'distinguishedname')),
                'cn' => dmd_directory_entry_first($e, 'cn'),
                'sam_account_name' => dmd_directory_entry_first($e, 'samaccountname'),
                'members' => dmd_directory_entry_values($e, 'member'),
                'group_type' => (int)dmd_directory_entry_first($e, 'grouptype'),
            ];
        }
        usort($groups, static fn($a,$b) => strnatcasecmp($a['cn'], $b['cn']));
        return ['ok' => true, 'groups' => $groups, 'count' => count($groups)];
    }
}

if (!function_exists('dmd_directory_dn_exists')) {
    function dmd_directory_dn_exists($ldap, string $dn): bool {
        $r = @ldap_read($ldap, $dn, '(objectClass=*)', ['distinguishedName']);
        return $r !== false;
    }
}

if (!function_exists('dmd_directory_create_ou')) {
    function dmd_directory_create_ou(string $ouDn): array {
        $cfg = dmd_directory_config_read(true);
        if (empty($cfg['write_enabled'])) return ['ok' => false, 'error' => 'Écritures Active Directory désactivées.'];
        $managed = trim((string)($cfg['managed_ou_dn'] ?? ''));
        if ($managed === '') return ['ok' => false, 'error' => 'OU gérée non configurée.'];
        // Autorise la création de l’OU gérée elle-même ou d’une OU enfant.
        if (strcasecmp(dmd_directory_normalize_dn($ouDn), dmd_directory_normalize_dn($managed)) !== 0 && !dmd_directory_dn_is_within($ouDn, $managed)) {
            return ['ok' => false, 'error' => 'Création refusée hors de l’OU gérée DoMyDesk.'];
        }
        $conn = dmd_directory_ldap_connect($cfg, true);
        if (empty($conn['ok'])) return $conn;
        if (dmd_directory_dn_exists($conn['ldap'], $ouDn)) return ['ok' => true, 'message' => 'OU déjà existante.'];
        $first = trim(explode(',', $ouDn, 2)[0] ?? '');
        if (!preg_match('/^OU=(.+)$/i', $first, $m)) return ['ok' => false, 'error' => 'DN d’OU invalide.'];
        $ouName = trim($m[1]);
        $entry = ['objectClass' => ['top','organizationalUnit'], 'ou' => $ouName];
        if (!@ldap_add($conn['ldap'], $ouDn, $entry)) return ['ok' => false, 'error' => 'Création OU refusée : ' . dmd_directory_ldap_error_text($conn['ldap'])];
        return ['ok' => true, 'message' => 'OU créée dans Active Directory.'];
    }
}

if (!function_exists('dmd_directory_create_group')) {
    function dmd_directory_create_group(string $name, string $scope = 'global', ?string $ouDn = null): array {
        $cfg = dmd_directory_config_read(true);
        if (empty($cfg['write_enabled'])) return ['ok' => false, 'error' => 'Écritures Active Directory désactivées.'];
        $ouDn = trim((string)($ouDn ?: ($cfg['managed_ou_dn'] ?? '')));
        if ($ouDn === '' || !dmd_directory_dn_is_within($ouDn, (string)($cfg['managed_ou_dn'] ?? ''))) return ['ok' => false, 'error' => 'OU cible refusée.'];
        $name = trim($name);
        if ($name === '' || preg_match('/[\\\/,\[\]:;|=+*?<>]/', $name)) return ['ok' => false, 'error' => 'Nom de groupe AD invalide.'];
        $conn = dmd_directory_ldap_connect($cfg, true);
        if (empty($conn['ok'])) return $conn;
        $dn = 'CN=' . dmd_directory_ldap_escape_dn_value($name) . ',' . $ouDn;
        if (dmd_directory_dn_exists($conn['ldap'], $dn)) return ['ok' => false, 'error' => 'Ce groupe existe déjà dans Active Directory.'];
        $types = ['global' => '-2147483646', 'domain_local' => '-2147483644', 'universal' => '-2147483640'];
        $groupType = $types[$scope] ?? $types['global'];
        $entry = [
            'objectClass' => ['top','group'],
            'cn' => $name,
            'sAMAccountName' => substr($name, 0, 20),
            'groupType' => $groupType,
        ];
        if (!@ldap_add($conn['ldap'], $dn, $entry)) return ['ok' => false, 'error' => 'Création du groupe AD refusée : ' . dmd_directory_ldap_error_text($conn['ldap'])];
        return ['ok' => true, 'dn' => $dn, 'name' => $name];
    }
}

if (!function_exists('dmd_directory_replace_group_members')) {
    function dmd_directory_replace_group_members(string $groupDn, array $memberDns): array {
        $cfg = dmd_directory_config_read(true);
        if (empty($cfg['write_enabled'])) return ['ok' => false, 'error' => 'Écritures Active Directory désactivées.'];
        if (!dmd_directory_dn_is_within($groupDn, (string)($cfg['managed_ou_dn'] ?? ''))) return ['ok' => false, 'error' => 'Modification d’un groupe hors OU gérée refusée.'];
        $conn = dmd_directory_ldap_connect($cfg, true);
        if (empty($conn['ok'])) return $conn;
        $memberDns = array_values(array_unique(array_filter(array_map('trim', $memberDns))));
        $mods = [['attrib' => 'member', 'modtype' => LDAP_MODIFY_BATCH_REPLACE, 'values' => $memberDns]];
        if (!$memberDns) $mods = [['attrib' => 'member', 'modtype' => LDAP_MODIFY_BATCH_REMOVE_ALL]];
        if (!@ldap_modify_batch($conn['ldap'], $groupDn, $mods)) return ['ok' => false, 'error' => 'Synchronisation des membres refusée : ' . dmd_directory_ldap_error_text($conn['ldap'])];
        return ['ok' => true, 'count' => count($memberDns)];
    }
}
