<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_security.php';
require_once __DIR__ . '/core/dmd_mfa.php';
require_once __DIR__ . '/core/dmd_system_services.php';

$enrollPending = isset($_SESSION['dmd_mfa_enroll_pending']) && is_array($_SESSION['dmd_mfa_enroll_pending'])
    ? $_SESSION['dmd_mfa_enroll_pending'] : array();
$pendingIssuedAt = (int)($enrollPending['issued_at'] ?? 0);
$pendingEmail = dmd_safe_user_key((string)($enrollPending['email'] ?? ''));
$forcedSetup = empty($_SESSION['user']['email']) && $pendingEmail !== '';

if ($forcedSetup && ($pendingIssuedAt <= 0 || time() - $pendingIssuedAt > 600)) {
    unset($_SESSION['dmd_mfa_enroll_pending']);
    header('Location: login.php?mfa=expired');
    exit;
}

$email = !empty($_SESSION['user']['email'])
    ? dmd_safe_user_key($_SESSION['user']['email'])
    : $pendingEmail;

if ($email === '') {
    header('Location: login.php');
    exit;
}

$profile = dmd_read_profile($email);
$currentPolicy = dmd_mfa_effective_policy($email, $profile);
if ($forcedSetup && $currentPolicy !== 'required') {
    unset($_SESSION['dmd_mfa_enroll_pending']);
    header('Location: login.php');
    exit;
}
$policySetupAllowed = ($currentPolicy !== 'disabled');
$theme = 'default';
$themePath = dmd_user_dir($email) . 'theme.json';
if (is_file($themePath)) {
    $themeData = json_decode((string)file_get_contents($themePath), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file(__DIR__ . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    }
}

$message = '';
$messageType = '';
$csrf = dmd_csrf_token('mfa_setup');

$setup = isset($_SESSION['dmd_mfa_setup']) && is_array($_SESSION['dmd_mfa_setup']) ? $_SESSION['dmd_mfa_setup'] : array();
if (!empty($setup) && ((string)($setup['email'] ?? '') !== $email || time() - (int)($setup['created_at'] ?? 0) > 900)) {
    unset($_SESSION['dmd_mfa_setup']);
    $setup = array();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'mfa_setup')) {
        $message = 'Formulaire expiré. Rechargez la page.';
        $messageType = 'error';
    } elseif (isset($_POST['begin_setup'])) {
        if (!$policySetupAllowed) {
            $message = 'Le MFA est désactivé pour ce compte par la politique DoMyDesk.';
            $messageType = 'error';
        } elseif (dmd_mfa_enabled($email)) {
            $message = 'Microsoft Authenticator est déjà activé sur ce compte.';
            $messageType = 'error';
        } else {
            $secret = dmd_mfa_generate_secret();
            if ($secret === false) {
                $message = 'Impossible de générer le secret MFA.';
                $messageType = 'error';
            } else {
                $_SESSION['dmd_mfa_setup'] = array(
                    'email' => $email,
                    'secret' => $secret,
                    'created_at' => time(),
                );
                $setup = $_SESSION['dmd_mfa_setup'];
                $message = 'Scannez le QR code puis confirmez avec le code à 6 chiffres.';
                $messageType = 'success';
            }
        }
    } elseif (isset($_POST['cancel_setup'])) {
        unset($_SESSION['dmd_mfa_setup']);
        $setup = array();
        if ($forcedSetup) {
            unset($_SESSION['dmd_mfa_enroll_pending']);
            header('Location: login.php');
            exit;
        }
        $message = 'Configuration annulée.';
        $messageType = 'success';
    } elseif (isset($_POST['confirm_setup'])) {
        $setup = isset($_SESSION['dmd_mfa_setup']) && is_array($_SESSION['dmd_mfa_setup']) ? $_SESSION['dmd_mfa_setup'] : array();
        $secret = (string)($setup['secret'] ?? '');
        $code = (string)($_POST['totp_code'] ?? '');

        if ($secret === '' || (string)($setup['email'] ?? '') !== $email || time() - (int)($setup['created_at'] ?? 0) > 900) {
            unset($_SESSION['dmd_mfa_setup']);
            $setup = array();
            $message = 'La configuration a expiré. Recommencez.';
            $messageType = 'error';
        } elseif (!dmd_mfa_verify_totp_secret($secret, $code, 1)) {
            $message = 'Code Microsoft Authenticator incorrect.';
            $messageType = 'error';
        } else {
            $secretEnc = dmd_mfa_encrypt_secret($secret);
            $recoveryCodes = dmd_mfa_generate_recovery_codes(10);
            if ($secretEnc === false || count($recoveryCodes) !== 10) {
                $message = 'Impossible de protéger les données MFA sur le serveur.';
                $messageType = 'error';
            } else {
                $cfg = array(
                    'version' => 1,
                    'enabled' => true,
                    'method' => 'totp',
                    'issuer' => 'DoMyDesk',
                    'algorithm' => 'SHA1',
                    'digits' => 6,
                    'period' => 30,
                    'secret_enc' => $secretEnc,
                    'recovery_hashes' => dmd_mfa_hash_recovery_codes($recoveryCodes),
                    'created_at' => date('c'),
                );
                if (!dmd_mfa_write($email, $cfg)) {
                    $message = 'Impossible d’enregistrer la configuration MFA.';
                    $messageType = 'error';
                } else {
                    unset($_SESSION['dmd_mfa_setup']);
                    $_SESSION['dmd_mfa_recovery_once'] = array('email' => $email, 'codes' => $recoveryCodes);
                    $setup = array();
                    $message = 'Microsoft Authenticator est activé.';
                    $messageType = 'success';
                    if (function_exists('dmd_system_log')) {
                        dmd_system_log('mfa_enabled', $email, 'success', 'Authentification multifacteur TOTP activée.');
                    }
                    if (function_exists('dmd_notify_user')) {
                        dmd_notify_user($email, 'security', 'Authentification multifacteur activée', 'Microsoft Authenticator est désormais requis après votre mot de passe.', array('level' => 'success'));
                    }

                    /* La validation du premier code TOTP constitue déjà une preuve MFA pour la session courante. */
                    if (!empty($_SESSION['user']['email']) && dmd_safe_user_key((string)$_SESSION['user']['email']) === $email) {
                        $_SESSION['dmd_mfa_authenticated_at'] = time();
                    }

                    if ($forcedSetup) {
                        $pendingUser = isset($enrollPending['user']) && is_array($enrollPending['user']) ? $enrollPending['user'] : array();
                        $pendingRole = (string)($enrollPending['role_system'] ?? ($pendingUser['role_system'] ?? 'user'));
                        $pendingRedirect = (string)($enrollPending['redirect'] ?? 'dashboard.php');
                        unset($_SESSION['dmd_mfa_enroll_pending']);
                        session_regenerate_id(true);
                        $_SESSION['user'] = $pendingUser;
                        $_SESSION['role_system'] = $pendingRole;
                        $_SESSION['dmd_mfa_authenticated_at'] = time();
                        $_SESSION['dmd_mfa_after_setup_redirect'] = $pendingRedirect !== '' ? $pendingRedirect : 'dashboard.php';
                        $forcedSetup = false;
                    }
                }
            }
        }
    } elseif (isset($_POST['cancel_disable_request'])) {
        $request = dmd_mfa_disable_request($email);
        if (empty($request)) {
            $message = 'Aucune demande de désactivation MFA n’est en attente.';
            $messageType = 'error';
        } elseif (!dmd_mfa_clear_disable_request($email, (string)($request['request_id'] ?? ''))) {
            $message = 'Impossible d’annuler la demande de désactivation.';
            $messageType = 'error';
        } else {
            $message = 'Demande de désactivation annulée. Le MFA reste actif.';
            $messageType = 'success';
            if (function_exists('dmd_system_log')) {
                dmd_system_log('mfa_disable_request_cancelled', $email, 'success', 'Demande de désactivation MFA annulée par l’utilisateur.');
            }
        }
    } elseif (isset($_POST['regenerate_recovery']) || isset($_POST['disable_mfa'])) {
        if (!dmd_mfa_enabled($email)) {
            $message = 'Le MFA n’est pas activé sur ce compte.';
            $messageType = 'error';
        } else {
            $password = (string)($_POST['current_password'] ?? '');
            $code = (string)($_POST['mfa_code'] ?? '');
            $hash = (string)($profile['motdepasse'] ?? ($profile['password'] ?? ''));
            $usedRecovery = false;

            if ($hash === '' || !password_verify($password, $hash)) {
                $message = 'Mot de passe actuel incorrect.';
                $messageType = 'error';
            } elseif (!dmd_mfa_verify_user_code($email, $code, $usedRecovery)) {
                $message = 'Code Authenticator ou code de secours incorrect.';
                $messageType = 'error';
            } elseif (isset($_POST['disable_mfa'])) {
                /*
                 * Une politique "required" interdit une désactivation directe,
                 * mais elle n'interdit jamais à l'utilisateur d'en faire la demande.
                 * Le Superadmin décidera ensuite ; s'il approuve alors que le MFA
                 * est imposé, une exception utilisateur "disabled" sera créée.
                 */
                $request = dmd_mfa_request_disable($email, $email);
                if ($request === false) {
                    $message = 'Impossible d’enregistrer la demande de désactivation MFA.';
                    $messageType = 'error';
                } else {
                    $message = $currentPolicy === 'required'
                        ? 'Demande envoyée au Superadmin. Le MFA reste actif. Si la demande est approuvée, une exception utilisateur sera créée pour autoriser sa désactivation malgré la politique obligatoire.'
                        : 'Demande envoyée au Superadmin. Le MFA reste actif jusqu’à sa validation.';
                    $messageType = 'success';
                    if (function_exists('dmd_system_log')) {
                        dmd_system_log('mfa_disable_requested', $email, 'warning', 'Désactivation MFA demandée ; validation Superadmin requise.', array('request_id' => (string)($request['request_id'] ?? '')));
                    }
                    if (function_exists('dmd_notify_system_role')) {
                        dmd_notify_system_role('superadmin', 'mfa_disable_requested', 'Validation MFA requise', 'Le compte ' . $email . ' demande la désactivation de son MFA.', array(
                            'level' => 'warning',
                            'action_url' => 'adm/mfa_requests.php',
                            'action_label' => 'Examiner',
                            'requires_superadmin' => true,
                            'meta' => array('target_user' => $email, 'request_id' => (string)($request['request_id'] ?? '')),
                        ));
                    }
                    if (function_exists('dmd_notify_user')) {
                        dmd_notify_user($email, 'security', 'Demande de désactivation MFA envoyée', 'Votre MFA reste actif jusqu’à validation par un Superadmin.', array('level' => 'warning'));
                    }
                }
            } else {
                $codes = dmd_mfa_generate_recovery_codes(10);
                $cfg = dmd_mfa_read($email);
                $cfg['recovery_hashes'] = dmd_mfa_hash_recovery_codes($codes);
                $cfg['recovery_regenerated_at'] = date('c');
                if (count($codes) !== 10 || !dmd_mfa_write($email, $cfg)) {
                    $message = 'Impossible de régénérer les codes de secours.';
                    $messageType = 'error';
                } else {
                    $_SESSION['dmd_mfa_recovery_once'] = array('email' => $email, 'codes' => $codes);
                    $message = 'Nouveaux codes de secours générés. Les anciens sont invalides.';
                    $messageType = 'success';
                    if (function_exists('dmd_system_log')) {
                        dmd_system_log('mfa_recovery_regenerated', $email, 'success', 'Codes de récupération MFA régénérés.');
                    }
                }
            }
        }
    }
}

$enabled = dmd_mfa_enabled($email);
$disableRequest = dmd_mfa_disable_request($email);
$cfg = dmd_mfa_read($email);
$recoveryRemaining = isset($cfg['recovery_hashes']) && is_array($cfg['recovery_hashes']) ? count($cfg['recovery_hashes']) : 0;
$once = isset($_SESSION['dmd_mfa_recovery_once']) && is_array($_SESSION['dmd_mfa_recovery_once']) && (string)($_SESSION['dmd_mfa_recovery_once']['email'] ?? '') === $email
    ? $_SESSION['dmd_mfa_recovery_once'] : array();
if (!empty($once)) unset($_SESSION['dmd_mfa_recovery_once']);
$afterSetupRedirect = isset($_SESSION['dmd_mfa_after_setup_redirect']) ? (string)$_SESSION['dmd_mfa_after_setup_redirect'] : '';
if ($afterSetupRedirect !== '' && !empty($_SESSION['user']['email'])) {
    unset($_SESSION['dmd_mfa_after_setup_redirect']);
}
$currentPolicy = dmd_mfa_effective_policy($email, $profile);
$policySetupAllowed = ($currentPolicy !== 'disabled');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Microsoft Authenticator - DoMyDesk</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <?php
    require_once __DIR__ . '/core/dmd_theme_assets.php';
    echo dmd_theme_extra_links(__DIR__, 'theme', $theme, 'login');
    ?>
    <style>
        .dmd-mfa-wrap{max-width:720px;margin:32px auto;padding:0 16px}.dmd-mfa-card{padding:24px}.dmd-mfa-row{display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap}.dmd-mfa-qr{width:220px;max-width:100%;height:auto;background:#fff;padding:8px;border-radius:10px}.dmd-mfa-secret{word-break:break-all;font-family:monospace}.dmd-mfa-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.dmd-mfa-codes{columns:2;column-gap:28px;font-family:monospace}.dmd-mfa-codes div{break-inside:avoid;margin:5px 0}.dmd-mfa-status{font-weight:700}.dmd-mfa-form{display:grid;gap:12px}.dmd-mfa-form input{width:100%}.dmd-mfa-back{display:inline-block;margin-bottom:14px}
    </style>
</head>
<body>
<main class="dmd-mfa-wrap">
    <?php if ($afterSetupRedirect !== ''): ?>
        <a class="dmd-mfa-back" href="<?= htmlspecialchars($afterSetupRedirect, ENT_QUOTES, 'UTF-8') ?>">→ Continuer vers DoMyDesk</a>
    <?php elseif (!$forcedSetup): ?>
        <a class="dmd-mfa-back" href="profile_edit.php">← Retour au profil</a>
    <?php endif; ?>
    <section class="login-card dmd-mfa-card">
        <h1>Microsoft Authenticator</h1>
        <p class="subtitle">Deuxième facteur TOTP pour votre compte DoMyDesk.</p>

        <?php if ($message !== ''): ?>
            <div class="<?= $messageType === 'error' ? 'error-message' : 'message' ?>"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <p class="dmd-mfa-status">État : <?= $enabled ? '✅ Activé' : '⚪ Désactivé' ?></p>
        <p class="dmd-mfa-status">Politique DoMyDesk : <?= $currentPolicy === 'required' ? '🔒 Obligatoire' : ($currentPolicy === 'disabled' ? '⛔ Désactivé par le Superadmin' : '⚪ Facultatif') ?></p>

        <?php if ($currentPolicy === 'disabled' && !$enabled): ?>
            <p>Le MFA est désactivé pour votre compte par la politique centrale. Une configuration existante est conservée mais n’est pas utilisée à la connexion tant que cette politique reste active.</p>
        <?php elseif (!$enabled && empty($setup)): ?>
            <form method="post" class="dmd-mfa-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="begin_setup" value="1">
                <p>DoMyDesk va générer un QR code à scanner dans Microsoft Authenticator. Le secret reste sur votre DoMyDesk et n’est envoyé à aucun service externe.</p>
                <button type="submit" class="btn">Configurer Microsoft Authenticator</button>
            </form>
        <?php elseif (!$enabled && !empty($setup)): ?>
            <div class="dmd-mfa-row">
                <img class="dmd-mfa-qr" src="mfa_qr.php?v=<?= (int)$setup['created_at'] ?>" alt="QR code Microsoft Authenticator">
                <div style="flex:1;min-width:240px">
                    <p><strong>1.</strong> Ouvrez Microsoft Authenticator → + → Autre compte → Scanner un QR code.</p>
                    <p><strong>2.</strong> Si le scan est impossible, saisissez manuellement cette clé :</p>
                    <p class="dmd-mfa-secret"><?= htmlspecialchars((string)$setup['secret'], ENT_QUOTES, 'UTF-8') ?></p>
                    <p><strong>3.</strong> Entrez le code à 6 chiffres affiché par l’application.</p>
                    <form method="post" class="dmd-mfa-form" autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="confirm_setup" value="1">
                        <label for="totp_code">Code Authenticator</label>
                        <input id="totp_code" name="totp_code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required autofocus>
                        <button type="submit" class="btn">Activer</button>
                    </form>
                    <?php if (!$forcedSetup): ?>
                    <form method="post" class="dmd-mfa-actions">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" name="cancel_setup" value="1">Annuler</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <p>Codes de secours encore disponibles : <strong><?= (int)$recoveryRemaining ?>/10</strong>.</p>
            <p>Pour une opération sensible, DoMyDesk redemande votre mot de passe et votre code Authenticator.</p>

            <h3>Régénérer les codes de secours</h3>
            <form method="post" class="dmd-mfa-form" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="regenerate_recovery" value="1">
                <label>Mot de passe actuel</label>
                <input type="password" name="current_password" required>
                <label>Code Authenticator</label>
                <input name="mfa_code" autocomplete="one-time-code" required>
                <button type="submit" class="btn">Régénérer</button>
            </form>

            <hr>
            <h3>Désactiver Microsoft Authenticator</h3>
            <?php if (!empty($disableRequest)): ?>
                <p><strong>⏳ Demande en attente de validation Superadmin.</strong></p>
                <p>Le MFA reste pleinement actif tant que la demande n’a pas été approuvée.</p>
                <?php if ($currentPolicy === 'required'): ?>
                    <p>🔒 La politique actuelle impose le MFA. Si le Superadmin approuve la demande, DoMyDesk créera automatiquement une exception utilisateur « Désactivé » pour que la décision soit réellement applicable.</p>
                <?php endif; ?>
                <form method="post" class="dmd-mfa-actions">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                    <button type="submit" name="cancel_disable_request" value="1">Annuler ma demande</button>
                </form>
            <?php else: ?>
                <p>La désactivation n’est jamais immédiate : après vérification de votre mot de passe et de votre code MFA, une demande est envoyée au Superadmin. Votre MFA reste actif jusqu’à sa validation.</p>
                <?php if ($currentPolicy === 'required'): ?>
                    <p>🔒 Le MFA est actuellement obligatoire pour votre compte. Vous pouvez quand même demander sa désactivation ; si le Superadmin l’approuve, une exception utilisateur « Désactivé » sera créée automatiquement.</p>
                <?php endif; ?>
                <form method="post" class="dmd-mfa-form" autocomplete="off" onsubmit="return confirm('Envoyer une demande de désactivation MFA au Superadmin ?');">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="disable_mfa" value="1">
                    <label>Mot de passe actuel</label>
                    <input type="password" name="current_password" required>
                    <label>Code Authenticator ou code de secours</label>
                    <input name="mfa_code" required>
                    <button type="submit">Demander la désactivation</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (!empty($once['codes']) && is_array($once['codes'])): ?>
            <hr>
            <h2>Codes de secours</h2>
            <p><strong>Copiez-les maintenant.</strong> Ils ne seront plus affichés après avoir quitté cette page. Chaque code ne fonctionne qu’une seule fois.</p>
            <div class="dmd-mfa-codes">
                <?php foreach ($once['codes'] as $recoveryCode): ?>
                    <div><?= htmlspecialchars((string)$recoveryCode, ENT_QUOTES, 'UTF-8') ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
