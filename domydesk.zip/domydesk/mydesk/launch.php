<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once dirname(__DIR__) . '/adm/agent/includes/agent_core.php';
require_once dirname(__DIR__) . '/core/dmd_permissions.php';
require_once __DIR__ . '/session_policy.php';

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function dmd_mydesk_launch_session_user($email) {
    $email = strtolower(trim((string)$email));
    if ($email === '') return false;
    $profilePath = dmd_profile_path($email, true);
    if ($profilePath === '' || !is_file($profilePath)) return false;
    $profile = dmd_read_profile($email);
    if (!is_array($profile) || !$profile) return false;
    $resolved = strtolower(trim((string)($profile['email'] ?? $email)));
    if ($resolved === '') return false;
    session_regenerate_id(true);
    $_SESSION['user'] = array(
        'email' => $resolved,
        'prenom' => $profile['prenom'] ?? '',
        'nom' => $profile['nom'] ?? '',
        'role_system' => $profile['role_system'] ?? '',
        'role_metier' => $profile['role_metier'] ?? '',
    );
    $_SESSION['role_system'] = (string)($profile['role_system'] ?? 'user');
    return true;
}

function dmd_mydesk_launch_auth($token, $resume) {
    if ($resume) header('Location: auth.php?resume=1');
    else header('Location: auth.php?token=' . rawurlencode($token));
    exit;
}

$resume = isset($_GET['resume']) && (string)$_GET['resume'] === '1';
$token = trim((string)($_GET['token'] ?? ''));
$row = array();

if ($resume) {
    $ctx = isset($_SESSION['dmd_mydesk_context']) && is_array($_SESSION['dmd_mydesk_context']) ? $_SESSION['dmd_mydesk_context'] : array();
    if (!$ctx || empty($ctx['agent_id']) || empty($ctx['module_id']) || empty($ctx['resume_nonce'])) {
        http_response_code(410);
        exit('Session MyDesk expirée. Relance le module depuis DMD-MyDesk.');
    }
    $row = array(
        'agent_id' => (string)$ctx['agent_id'],
        'hostname' => (string)($ctx['hostname'] ?? ''),
        'module_id' => (string)$ctx['module_id'],
    );
} else {
    $row = dmd_agent_mydesk_launch_token_peek($token);
    if (!$row) {
        http_response_code(410);
        ?><!doctype html><html lang="fr"><meta charset="utf-8"><title>DMD-MyDesk</title><body><p>Ce lancement DMD-MyDesk a expiré. Relance le module depuis l’icône DMD-MyDesk.</p></body></html><?php
        exit;
    }
}

$agentId = trim((string)($row['agent_id'] ?? ''));
if ($agentId === '') {
    http_response_code(403);
    exit('Identité DMD-Agent absente.');
}

/* Une session Agent déjà authentifiée est réutilisée entre toutes les fenêtres MyDesk. */
if (empty($_SESSION['user']['email'])) {
    $linkedEmail = dmd_mydesk_policy_restore_email($agentId);
    if ($linkedEmail === '' || !dmd_mydesk_launch_session_user($linkedEmail)) {
        dmd_mydesk_launch_auth($token, $resume);
    }
} else {
    $emailNow = strtolower(trim((string)$_SESSION['user']['email']));
    $state = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
    if ($state && dmd_mydesk_policy_is_locked($state)) {
        $freshMfaSetup = !empty($_SESSION['dmd_mfa_authenticated_at']) && (time() - (int)$_SESSION['dmd_mfa_authenticated_at']) <= 120;
        if ($freshMfaSetup) {
            dmd_mydesk_policy_authenticate($agentId, $emailNow);
            $state = dmd_mydesk_policy_read($agentId);
        } else {
            unset($_SESSION['user'], $_SESSION['role_system']);
            dmd_mydesk_launch_auth($token, $resume);
        }
    }
    if (!$state || strtolower(trim((string)($state['user_email'] ?? ''))) !== $emailNow) {
        dmd_mydesk_policy_authenticate($agentId, $emailNow);
    }
}

$email = strtolower(trim((string)($_SESSION['user']['email'] ?? '')));
if ($email === '') dmd_mydesk_launch_auth($token, $resume);

$catalog = dmd_agent_mydesk_manifest_modules();
$moduleId = (string)($row['module_id'] ?? '');
if (!isset($catalog[$moduleId]) || !dmd_agent_mydesk_module_enabled($catalog[$moduleId])) {
    http_response_code(403);
    exit('Module MyDesk non autorisé.');
}
$module = $catalog[$moduleId];
if (function_exists('dmd_user_can_use_module') && !dmd_user_can_use_module($email, $moduleId)) {
    http_response_code(403);
    exit('Accès à ce module non autorisé.');
}

if (!$resume) {
    $consumed = dmd_agent_mydesk_launch_token_consume($token);
    if (!$consumed) {
        http_response_code(410);
        exit('Ce lancement DMD-MyDesk a expiré.');
    }
    $row = array_merge($row, $consumed);
}

$windowId = '';
if ($resume && !empty($_SESSION['dmd_mydesk_context']['window_id'])) {
    $windowId = (string)$_SESSION['dmd_mydesk_context']['window_id'];
}
if ($windowId === '') {
    try { $windowId = 'WIN-' . strtoupper(bin2hex(random_bytes(12))); }
    catch (Throwable $e) { $windowId = 'WIN-' . strtoupper(substr(hash('sha256', uniqid('', true) . mt_rand()), 0, 24)); }
}
try { $resumeNonce = bin2hex(random_bytes(24)); }
catch (Throwable $e) { $resumeNonce = hash('sha256', uniqid('', true) . mt_rand()); }

$entrypoint = str_replace('%2F', '/', rawurlencode((string)$module['entrypoint']));
$target = '../modules/' . rawurlencode((string)$module['folder']) . '/' . $entrypoint;
$target .= (strpos($target, '?') === false ? '?' : '&') . 'dmd_view=compact';

$_SESSION['dmd_mydesk_context'] = array(
    'schema' => 3,
    'agent_id' => $agentId,
    'hostname' => (string)($row['hostname'] ?? ''),
    'module_id' => $moduleId,
    'user_email' => $email,
    'window_id' => $windowId,
    'resume_nonce' => $resumeNonce,
    'target_url' => $target,
    'launched_at' => gmdate('c'),
    'expires_ts' => time() + 28800,
);
if (empty($_SESSION['dmd_mydesk_presence_csrf'])) {
    try { $_SESSION['dmd_mydesk_presence_csrf'] = bin2hex(random_bytes(24)); }
    catch (Throwable $e) { $_SESSION['dmd_mydesk_presence_csrf'] = hash('sha256', session_id() . microtime(true)); }
}
$presenceCsrf = (string)$_SESSION['dmd_mydesk_presence_csrf'];
unset($_SESSION['dmd_mydesk_reauth_required']);

dmd_mydesk_policy_register_window($agentId, $windowId, $email);
if (function_exists('dmd_agent_mydesk_session_link')) dmd_agent_mydesk_session_link($agentId, $email, 28800);
?>
<!doctype html>
<html lang="fr" data-dmd-context="mydesk-module-shell">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title><?= htmlspecialchars((string)($module['label'] ?? $moduleId), ENT_QUOTES, 'UTF-8') ?></title>
<style>
html,body{width:100%;height:100%;margin:0;padding:0;overflow:hidden;background:transparent}#dmd-mydesk-frame{display:block;width:100%;height:100%;border:0;margin:0;padding:0;background:transparent}
</style>
</head>
<body>
<iframe id="dmd-mydesk-frame" src="<?= htmlspecialchars($target, ENT_QUOTES, 'UTF-8') ?>" title="<?= htmlspecialchars((string)($module['label'] ?? $moduleId), ENT_QUOTES, 'UTF-8') ?>"></iframe>
<script>
(() => {
  const frame = document.getElementById('dmd-mydesk-frame');
  const endpoint = 'session.php';
  const csrf = <?= json_encode($presenceCsrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const windowId = <?= json_encode($windowId, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  let activityPending = true;
  let locked = false;
  let lastMove = 0;

  const markActivity = () => { activityPending = true; };
  const markMove = () => {
    const now = Date.now();
    if (now - lastMove > 1000) { lastMove = now; activityPending = true; }
  };

  ['pointerdown','keydown','touchstart','wheel'].forEach(name => window.addEventListener(name, markActivity, {passive:true,capture:true}));
  window.addEventListener('mousemove', markMove, {passive:true,capture:true});
  window.addEventListener('focus', markActivity, {passive:true});

  try {
    frame.addEventListener('load', () => {
      try {
        if (window.DMDMyDesk && frame.contentWindow && !frame.contentWindow.DMDMyDesk) {
          Object.defineProperty(frame.contentWindow, 'DMDMyDesk', {value:window.DMDMyDesk, configurable:true});
        }
      } catch (_) {}
      try {
        const doc = frame.contentDocument;
        if (!doc) return;
        ['pointerdown','keydown','touchstart','wheel'].forEach(name => doc.addEventListener(name, markActivity, {passive:true,capture:true}));
        doc.addEventListener('mousemove', markMove, {passive:true,capture:true});
      } catch (_) {}
    });
  } catch (_) {}

  async function heartbeat() {
    if (locked) return;
    const active = activityPending;
    activityPending = false;
    try {
      const res = await fetch(endpoint, {
        method:'POST',
        cache:'no-store',
        credentials:'same-origin',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({action:'heartbeat',window_id:windowId,active:active?1:0,csrf})
      });
      const data = await res.json().catch(() => ({}));
      if (data && data.locked) {
        locked = true;
        try { frame.src = 'about:blank'; } catch (_) {}
        location.replace('auth.php?resume=1');
      }
    } catch (_) {
      /* Une coupure réseau ne doit pas fermer brutalement le module. */
    }
  }

  function closePresence() {
    if (locked) return;
    const body = new URLSearchParams({action:'close',window_id:windowId,csrf});
    try { navigator.sendBeacon(endpoint, body); } catch (_) {}
  }

  heartbeat();
  const timer = setInterval(heartbeat, 15000);
  window.addEventListener('pagehide', () => { clearInterval(timer); closePresence(); }, {once:true});
  window.addEventListener('beforeunload', closePresence, {once:true});
})();
</script>
</body>
</html>
