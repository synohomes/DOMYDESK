<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once dirname(__DIR__) . '/adm/agent/includes/agent_core.php';
require_once dirname(__DIR__) . '/core/dmd_permissions.php';
require_once dirname(__DIR__) . '/core/dmd_mfa.php';
require_once dirname(__DIR__) . '/core/directory/dmd_ad_sync.php';
require_once dirname(__DIR__) . '/core/dmd_media.php';
require_once dirname(__DIR__) . '/core/dmd_system_services.php';
require_once __DIR__ . '/session_policy.php';

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function dmd_mydesk_auth_json_read($file, $fallback = array()) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    $data = json_decode((string)$raw, true);
    return is_array($data) ? $data : $fallback;
}
function dmd_mydesk_auth_token($value) {
    $value = trim((string)$value);
    return preg_match('/^[A-Za-z0-9_-]{30,100}$/', $value) ? $value : '';
}
function dmd_mydesk_auth_redirect($token, $resume = false) {
    if ($resume) header('Location: launch.php?resume=1');
    else header('Location: launch.php?token=' . rawurlencode($token));
    exit;
}
function dmd_mydesk_auth_profile_theme($email) {
    $email = trim((string)$email);
    if ($email === '') return 'default';
    $file = dirname(__DIR__) . '/users/profiles/' . $email . '/theme.json';
    if (!is_file($file)) return 'default';
    $data = dmd_mydesk_auth_json_read($file, array());
    $candidate = basename((string)($data['theme'] ?? ''));
    return $candidate !== '' && is_file(dirname(__DIR__) . '/theme/' . $candidate . '/style.css') ? $candidate : 'default';
}
function dmd_mydesk_auth_avatar_url($email) {
    $email = trim((string)$email);
    if ($email === '' || !function_exists('dmd_user_avatar_file') || !function_exists('dmd_media_public_url')) return '';
    $file = dmd_user_avatar_file($email);
    return $file !== '' ? dmd_media_public_url($file) : '';
}
function dmd_mydesk_auth_initial($profile, $email) {
    $source = trim((string)($profile['prenom'] ?? $profile['pseudo'] ?? $email));
    return $source !== '' ? strtoupper(substr($source, 0, 1)) : '?';
}

$resume = ((string)($_GET['resume'] ?? $_POST['resume'] ?? '') === '1');
$token = dmd_mydesk_auth_token($_GET['token'] ?? $_POST['token'] ?? '');
$row = array();
$authRef = '';
if ($resume) {
    $ctx = isset($_SESSION['dmd_mydesk_context']) && is_array($_SESSION['dmd_mydesk_context']) ? $_SESSION['dmd_mydesk_context'] : array();
    if (!$ctx || empty($ctx['agent_id']) || empty($ctx['module_id']) || empty($ctx['resume_nonce'])) {
        http_response_code(410);
        ?><!doctype html><html lang="fr"><meta charset="utf-8"><title>DMD-MyDesk</title><body><p>Cette session MyDesk a expiré. Relance le module depuis DMD-MyDesk.</p></body></html><?php
        exit;
    }
    $row = array('agent_id'=>(string)$ctx['agent_id'], 'module_id'=>(string)$ctx['module_id'], 'hostname'=>(string)($ctx['hostname'] ?? ''));
    $authRef = 'resume:' . (string)$ctx['resume_nonce'];
} else {
    $row = $token !== '' ? dmd_agent_mydesk_launch_token_peek($token) : array();
    if (!$row) {
        http_response_code(410);
        ?><!doctype html><html lang="fr"><meta charset="utf-8"><title>DMD-MyDesk</title><body><p>Ce lancement DMD-MyDesk a expiré. Relance le module depuis DMD-MyDesk.</p></body></html><?php
        exit;
    }
    $authRef = 'token:' . $token;
}

if (!empty($_SESSION['user']['email']) && empty($_SESSION['dmd_mydesk_reauth_required'])) dmd_mydesk_auth_redirect($token, $resume);

$pending = isset($_SESSION['dmd_mydesk_auth']) && is_array($_SESSION['dmd_mydesk_auth']) ? $_SESSION['dmd_mydesk_auth'] : array();
if (($pending['auth_ref'] ?? '') !== $authRef || time() - (int)($pending['issued_at'] ?? 0) > 900) {
    $pending = array('auth_ref' => $authRef, 'token' => $token, 'resume' => $resume, 'step' => 'identity', 'issued_at' => time(), 'attempts' => 0);
    $_SESSION['dmd_mydesk_auth'] = $pending;
}

$step = (string)($pending['step'] ?? 'identity');
if (!in_array($step, array('identity','password','mfa'), true)) $step = 'identity';
$error = '';
$identity = (string)($pending['identity'] ?? '');
$email = (string)($pending['email'] ?? '');
$profile = $email !== '' ? dmd_read_profile($email) : array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'back') {
        $pending = array('auth_ref'=>$authRef,'token'=>$token,'resume'=>$resume,'step'=>'identity','issued_at'=>time(),'attempts'=>0);
        $_SESSION['dmd_mydesk_auth'] = $pending;
        $step = 'identity'; $identity = ''; $email = ''; $profile = array();
    }

    if ($action === 'identity') {
        $identity = trim((string)($_POST['identity'] ?? ''));
        if ($identity === '') {
            $error = 'Saisissez votre identifiant.';
        } else {
            $resolved = dmd_directory_find_profile_email_by_login($identity);
            if ($resolved === '' && filter_var($identity, FILTER_VALIDATE_EMAIL)) $resolved = strtolower($identity);
            $profilePath = $resolved !== '' ? dmd_profile_path($resolved, true) : '';
            if ($profilePath === '' || !is_file($profilePath)) {
                $error = 'Utilisateur introuvable.';
            } else {
                $profile = dmd_read_profile($resolved);
                $email = (string)($profile['email'] ?? $resolved);
                $pending = array('auth_ref'=>$authRef,'token'=>$token,'resume'=>$resume,'step'=>'password','issued_at'=>time(),'identity'=>$identity,'email'=>$email,'attempts'=>0);
                $_SESSION['dmd_mydesk_auth'] = $pending;
                $step = 'password';
            }
        }
    }

    if ($action === 'password' && $step === 'password') {
        $password = (string)($_POST['password'] ?? '');
        $identity = (string)($pending['identity'] ?? '');
        $email = (string)($pending['email'] ?? '');
        $profilePath = $email !== '' ? dmd_profile_path($email, true) : '';
        $profile = $profilePath !== '' && is_file($profilePath) ? dmd_read_profile($email) : array();
        $authOk = false;
        if (!$profile) {
            $error = 'Utilisateur introuvable.';
        } else {
            $authSource = strtolower((string)($profile['auth_source'] ?? 'local'));
            if ($authSource === 'active_directory') {
                $ad = is_array($profile['ad'] ?? null) ? $profile['ad'] : array();
                $hash = (string)($profile['motdepasse'] ?? $profile['password'] ?? '');
                $isMergedLocalAccount = !empty($ad['merge_existing_account']) || strtolower((string)($ad['previous_auth_source'] ?? '')) === 'local';
                $loginLooksLikeEmail = filter_var($identity, FILTER_VALIDATE_EMAIL) !== false;
                $localAuthOk = $isMergedLocalAccount && $loginLooksLikeEmail && $hash !== '' && password_verify($password, $hash);
                if ($localAuthOk) {
                    $authOk = true;
                } else {
                    $adAuth = dmd_directory_authenticate_ad_profile($profile, $password);
                    $authOk = !empty($adAuth['ok']);
                    if (!$authOk) $error = (string)($adAuth['error'] ?? 'Authentification Active Directory refusée.');
                }
            } else {
                $hash = (string)($profile['motdepasse'] ?? $profile['password'] ?? '');
                $authOk = $hash !== '' && password_verify($password, $hash);
                if (!$authOk) $error = 'Mot de passe incorrect.';
            }
        }

        if ($authOk) {
            $email = (string)($profile['email'] ?? $email);
            $user = array(
                'email'=>$email,
                'prenom'=>$profile['prenom'] ?? '',
                'nom'=>$profile['nom'] ?? '',
                'role_system'=>$profile['role_system'] ?? '',
                'role_metier'=>$profile['role_metier'] ?? ''
            );
            $roleSystem = (string)($profile['role_system'] ?? 'user');
            $mfaPolicy = dmd_mfa_effective_policy($email, $profile);

            if ($mfaPolicy === 'required' && !dmd_mfa_enabled($email)) {
                unset($_SESSION['dmd_mydesk_auth']);
                session_regenerate_id(true);
                $_SESSION['dmd_mfa_enroll_pending'] = array(
                    'email'=>$email,
                    'user'=>$user,
                    'role_system'=>$roleSystem,
                    'redirect'=>$resume ? 'mydesk/launch.php?resume=1' : ('mydesk/launch.php?token=' . rawurlencode($token)),
                    'issued_at'=>time(),
                    'mydesk'=>true,
                );
                header('Location: ../mfa_setup.php?required=1&mydesk=1');
                exit;
            }

            if (dmd_mfa_policy_login_uses_mfa($email, $profile)) {
                $pending = array('auth_ref'=>$authRef,'token'=>$token,'resume'=>$resume,'step'=>'mfa','issued_at'=>time(),'identity'=>$identity,'email'=>$email,'attempts'=>0,'user'=>$user,'role_system'=>$roleSystem);
                $_SESSION['dmd_mydesk_auth'] = $pending;
                $step = 'mfa';
            } else {
                unset($_SESSION['dmd_mydesk_auth']);
                session_regenerate_id(true);
                $_SESSION['user'] = $user;
                $_SESSION['role_system'] = $roleSystem;
                unset($_SESSION['dmd_mydesk_reauth_required']);
                if (!empty($row['agent_id'])) dmd_mydesk_policy_authenticate((string)$row['agent_id'], $email);
                dmd_mydesk_auth_redirect($token, $resume);
            }
        }
    }

    if ($action === 'mfa' && $step === 'mfa') {
        $pending = isset($_SESSION['dmd_mydesk_auth']) && is_array($_SESSION['dmd_mydesk_auth']) ? $_SESSION['dmd_mydesk_auth'] : array();
        $email = (string)($pending['email'] ?? '');
        $attempts = (int)($pending['attempts'] ?? 0);
        if ($attempts >= 5) {
            $pending = array('auth_ref'=>$authRef,'token'=>$token,'resume'=>$resume,'step'=>'identity','issued_at'=>time(),'attempts'=>0);
            $_SESSION['dmd_mydesk_auth'] = $pending;
            $step = 'identity'; $error = 'Trop de codes incorrects. Recommencez la connexion.';
        } else {
            $code = trim((string)($_POST['mfa_code'] ?? ''));
            $usedRecovery = false;
            if ($email !== '' && dmd_mfa_verify_user_code($email, $code, $usedRecovery)) {
                $user = isset($pending['user']) && is_array($pending['user']) ? $pending['user'] : array();
                $roleSystem = (string)($pending['role_system'] ?? ($user['role_system'] ?? 'user'));
                unset($_SESSION['dmd_mydesk_auth']);
                session_regenerate_id(true);
                $_SESSION['user'] = $user;
                $_SESSION['role_system'] = $roleSystem;
                $_SESSION['dmd_mfa_authenticated_at'] = time();
                unset($_SESSION['dmd_mydesk_reauth_required']);
                if (!empty($row['agent_id'])) dmd_mydesk_policy_authenticate((string)$row['agent_id'], $email);
                if (function_exists('dmd_system_log')) dmd_system_log($usedRecovery ? 'mfa_login_recovery' : 'mfa_login', $email, 'success', 'Connexion MFA DMD-MyDesk validée.');
                dmd_mydesk_auth_redirect($token, $resume);
            }
            $pending['attempts'] = $attempts + 1;
            $_SESSION['dmd_mydesk_auth'] = $pending;
            $error = 'Code incorrect. Tentatives restantes : ' . max(0, 5 - (int)$pending['attempts']) . '.';
        }
    }
}

$pending = isset($_SESSION['dmd_mydesk_auth']) && is_array($_SESSION['dmd_mydesk_auth']) ? $_SESSION['dmd_mydesk_auth'] : $pending;
$step = (string)($pending['step'] ?? $step);
$identity = (string)($pending['identity'] ?? $identity);
$email = (string)($pending['email'] ?? $email);
$profile = $email !== '' ? dmd_read_profile($email) : array();
$theme = dmd_mydesk_auth_profile_theme($email);
$avatarUrl = dmd_mydesk_auth_avatar_url($email);
$initial = dmd_mydesk_auth_initial($profile, $email !== '' ? $email : $identity);
?>
<!doctype html>
<html lang="fr" data-dmd-context="mydesk-auth">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-MyDesk · Connexion</title>
<link rel="stylesheet" href="../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="auth.css?v=<?= is_file(__DIR__.'/auth.css') ? (int)filemtime(__DIR__.'/auth.css') : 1 ?>">
</head>
<body class="dmd-mydesk-auth dmd-mydesk-auth-<?= htmlspecialchars($step, ENT_QUOTES, 'UTF-8') ?>">
<main class="dmd-ma-shell">
  <section class="dmd-ma-card" aria-live="polite">
    <div class="dmd-ma-avatars" aria-hidden="true">
      <div class="dmd-ma-avatar dmd-ma-brand"><img src="../adm/uploads/logo.png" alt="" onerror="this.style.display='none';this.parentNode.textContent='DMD';"></div>
      <span class="dmd-ma-link">↔</span>
      <div class="dmd-ma-avatar dmd-ma-user">
        <?php if ($avatarUrl !== ''): ?><img src="<?= htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?><span><?= htmlspecialchars($initial, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
      </div>
    </div>

    <?php if ($step === 'identity'): ?>
      <h1>Connexion MyDesk</h1>
      <form method="post" autocomplete="on">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($resume): ?><input type="hidden" name="resume" value="1"><?php endif; ?>
        <input type="hidden" name="action" value="identity">
        <label for="identity">Identifiant</label>
        <input id="identity" name="identity" type="text" autocomplete="username" autofocus required value="<?= htmlspecialchars($identity, ENT_QUOTES, 'UTF-8') ?>" placeholder="E-mail ou identifiant AD">
        <?php if ($error !== ''): ?><div class="dmd-ma-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
        <button type="submit">Suivant <span>↵</span></button>
      </form>
    <?php elseif ($step === 'password'): ?>
      <div class="dmd-ma-account"><?= htmlspecialchars($identity, ENT_QUOTES, 'UTF-8') ?></div>
      <h1>Mot de passe</h1>
      <form method="post" autocomplete="on">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($resume): ?><input type="hidden" name="resume" value="1"><?php endif; ?>
        <input type="hidden" name="action" value="password">
        <label for="password">Mot de passe</label>
        <input id="password" name="password" type="password" autocomplete="current-password" autofocus required placeholder="••••••••">
        <?php if ($error !== ''): ?><div class="dmd-ma-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
        <button type="submit">Se connecter <span>↵</span></button>
      </form>
      <form method="post" class="dmd-ma-back"><input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($resume): ?><input type="hidden" name="resume" value="1"><?php endif; ?><input type="hidden" name="action" value="back"><button type="submit">← Changer d’identifiant</button></form>
    <?php else: ?>
      <div class="dmd-ma-account"><?= htmlspecialchars($identity, ENT_QUOTES, 'UTF-8') ?></div>
      <h1>Code MFA</h1>
      <form method="post" autocomplete="off">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
        <?php if ($resume): ?><input type="hidden" name="resume" value="1"><?php endif; ?>
        <input type="hidden" name="action" value="mfa">
        <label for="mfa_code">Authenticator ou code de secours</label>
        <input id="mfa_code" name="mfa_code" inputmode="numeric" autocomplete="one-time-code" autofocus required placeholder="000000">
        <?php if ($error !== ''): ?><div class="dmd-ma-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
        <button type="submit">Valider <span>↵</span></button>
      </form>
    <?php endif; ?>
  </section>
</main>
<script>
(() => {
  const fit = () => {
    if (!window.DMDMyDesk?.resize) return;
    const card = document.querySelector('.dmd-ma-card');
    const h = Math.max(270, Math.min(440, Math.ceil((card?.getBoundingClientRect().height || 270) + 28)));
    window.DMDMyDesk.resize(390, h, 340, 280);
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(fit, 30), {once:true});
  else setTimeout(fit, 30);
})();
</script>
</body>
</html>
