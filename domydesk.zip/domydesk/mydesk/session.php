<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once dirname(__DIR__) . '/adm/agent/includes/agent_core.php';
require_once __DIR__ . '/session_policy.php';

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    http_response_code(405);
    echo json_encode(array('ok'=>false,'error'=>'method_not_allowed'));
    exit;
}

$payload = array();
$contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
if (strpos($contentType, 'application/json') !== false) {
    $raw = (string)file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) $payload = $decoded;
} else {
    $payload = $_POST;
}

$csrf = trim((string)($payload['csrf'] ?? ''));
$expected = trim((string)($_SESSION['dmd_mydesk_presence_csrf'] ?? ''));
if ($csrf === '' || $expected === '' || !hash_equals($expected, $csrf)) {
    http_response_code(403);
    echo json_encode(array('ok'=>false,'error'=>'csrf'));
    exit;
}

$ctx = isset($_SESSION['dmd_mydesk_context']) && is_array($_SESSION['dmd_mydesk_context']) ? $_SESSION['dmd_mydesk_context'] : array();
$agentId = trim((string)($ctx['agent_id'] ?? ''));
$windowId = trim((string)($payload['window_id'] ?? ($ctx['window_id'] ?? '')));
if ($agentId === '' || $windowId === '' || !preg_match('/^[A-Za-z0-9_-]{12,120}$/', $windowId)) {
    http_response_code(403);
    echo json_encode(array('ok'=>false,'error'=>'context_missing'));
    exit;
}

$action = strtolower(trim((string)($payload['action'] ?? 'heartbeat')));
if ($action === 'close') {
    dmd_mydesk_policy_close_window($agentId, $windowId);
    echo json_encode(array('ok'=>true,'closed'=>true));
    exit;
}

if ($action !== 'heartbeat') {
    http_response_code(400);
    echo json_encode(array('ok'=>false,'error'=>'action_invalid'));
    exit;
}

$active = !empty($payload['active']);
$result = dmd_mydesk_policy_heartbeat($agentId, $windowId, $active);
if (!empty($result['locked'])) {
    unset($_SESSION['user'], $_SESSION['role_system']);
    $_SESSION['dmd_mydesk_reauth_required'] = true;
}
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
