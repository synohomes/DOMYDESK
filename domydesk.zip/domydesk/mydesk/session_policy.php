<?php
/* DMD-MyDesk - politique de session partagée entre les fenêtres MyDesk. */

if (!defined('DMD_MYDESK_IDLE_TTL')) define('DMD_MYDESK_IDLE_TTL', 300);      // 5 minutes
if (!defined('DMD_MYDESK_CLOSE_GRACE')) define('DMD_MYDESK_CLOSE_GRACE', 600); // 10 minutes
if (!defined('DMD_MYDESK_WINDOW_STALE')) define('DMD_MYDESK_WINDOW_STALE', 50); // heartbeat 15 s

if (!function_exists('dmd_mydesk_policy_state_file')) {
    function dmd_mydesk_policy_state_file($agentId) {
        $agentId = trim((string)$agentId);
        if ($agentId === '' || !defined('DMD_AGENT_VAR')) return '';
        $dir = DMD_AGENT_VAR . '/mydesk/auth_sessions';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);
        return $dir . '/AUT-' . strtoupper(hash('sha256', $agentId)) . '.php';
    }
}

if (!function_exists('dmd_mydesk_policy_read')) {
    function dmd_mydesk_policy_read($agentId) {
        $file = dmd_mydesk_policy_state_file($agentId);
        if ($file === '' || !is_file($file) || !function_exists('dmd_agent_json_read')) return array();
        $row = dmd_agent_json_read($file, array());
        if (!is_array($row) || (string)($row['agent_id'] ?? '') !== (string)$agentId) return array();
        if (!isset($row['windows']) || !is_array($row['windows'])) $row['windows'] = array();
        return $row;
    }
}

if (!function_exists('dmd_mydesk_policy_write')) {
    function dmd_mydesk_policy_write($agentId, $row) {
        $file = dmd_mydesk_policy_state_file($agentId);
        if ($file === '' || !function_exists('dmd_agent_json_write')) return false;
        $row = is_array($row) ? $row : array();
        $row['schema'] = 2;
        $row['agent_id'] = (string)$agentId;
        $row['updated_ts'] = time();
        $row['updated_at'] = gmdate('c');
        return dmd_agent_json_write($file, $row, 0640);
    }
}

if (!function_exists('dmd_mydesk_policy_cleanup')) {
    function dmd_mydesk_policy_cleanup($agentId, $row) {
        $row = is_array($row) ? $row : array();
        if (!isset($row['windows']) || !is_array($row['windows'])) $row['windows'] = array();
        $now = time();
        $removedLastSeen = 0;
        foreach ($row['windows'] as $windowId => $window) {
            if (!is_array($window)) {
                unset($row['windows'][$windowId]);
                continue;
            }
            $lastSeen = (int)($window['last_seen_ts'] ?? 0);
            if ($lastSeen <= 0 || ($now - $lastSeen) > DMD_MYDESK_WINDOW_STALE) {
                $removedLastSeen = max($removedLastSeen, $lastSeen);
                unset($row['windows'][$windowId]);
            }
        }
        if ($removedLastSeen > 0 && empty($row['windows'])) {
            $row['last_closed_ts'] = max((int)($row['last_closed_ts'] ?? 0), $removedLastSeen);
        }
        return $row;
    }
}

if (!function_exists('dmd_mydesk_policy_latest_activity')) {
    function dmd_mydesk_policy_latest_activity($row) {
        $latest = (int)($row['last_activity_ts'] ?? 0);
        foreach ((array)($row['windows'] ?? array()) as $window) {
            if (is_array($window)) $latest = max($latest, (int)($window['last_activity_ts'] ?? 0));
        }
        return $latest;
    }
}

if (!function_exists('dmd_mydesk_policy_is_locked')) {
    function dmd_mydesk_policy_is_locked($row) {
        return (int)($row['locked_ts'] ?? 0) > (int)($row['authenticated_ts'] ?? 0);
    }
}

if (!function_exists('dmd_mydesk_policy_authenticate')) {
    function dmd_mydesk_policy_authenticate($agentId, $email) {
        $agentId = trim((string)$agentId);
        $email = strtolower(trim((string)$email));
        if ($agentId === '' || $email === '') return false;
        $now = time();
        $row = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
        $row['user_email'] = $email;
        $row['authenticated_ts'] = $now;
        $row['last_activity_ts'] = $now;
        $row['last_closed_ts'] = 0;
        $row['locked_ts'] = 0;
        $row['windows'] = array();
        return dmd_mydesk_policy_write($agentId, $row);
    }
}

if (!function_exists('dmd_mydesk_policy_restore_email')) {
    function dmd_mydesk_policy_restore_email($agentId) {
        $agentId = trim((string)$agentId);
        if ($agentId === '') return '';
        $row = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
        if (!$row || dmd_mydesk_policy_is_locked($row)) {
            if ($row) dmd_mydesk_policy_write($agentId, $row);
            return '';
        }
        $email = strtolower(trim((string)($row['user_email'] ?? '')));
        if ($email === '') {
            dmd_mydesk_policy_write($agentId, $row);
            return '';
        }
        $now = time();
        if (!empty($row['windows'])) {
            $latestActivity = dmd_mydesk_policy_latest_activity($row);
            if ($latestActivity <= 0 || ($now - $latestActivity) > DMD_MYDESK_IDLE_TTL) {
                $row['locked_ts'] = $now;
                dmd_mydesk_policy_write($agentId, $row);
                return '';
            }
            dmd_mydesk_policy_write($agentId, $row);
            return $email;
        }
        $lastClosed = (int)($row['last_closed_ts'] ?? 0);
        $authenticated = (int)($row['authenticated_ts'] ?? 0);
        $reference = $lastClosed > 0 ? $lastClosed : $authenticated;
        if ($reference > 0 && ($now - $reference) <= DMD_MYDESK_CLOSE_GRACE) {
            dmd_mydesk_policy_write($agentId, $row);
            return $email;
        }
        $row['locked_ts'] = $now;
        dmd_mydesk_policy_write($agentId, $row);
        return '';
    }
}

if (!function_exists('dmd_mydesk_policy_register_window')) {
    function dmd_mydesk_policy_register_window($agentId, $windowId, $email) {
        $agentId = trim((string)$agentId);
        $windowId = trim((string)$windowId);
        $email = strtolower(trim((string)$email));
        if ($agentId === '' || $windowId === '' || $email === '') return false;
        $row = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
        if (!$row || !hash_equals((string)($row['user_email'] ?? ''), $email) || dmd_mydesk_policy_is_locked($row)) return false;
        $now = time();
        $row['windows'][$windowId] = array(
            'opened_ts' => $now,
            'last_seen_ts' => $now,
            'last_activity_ts' => $now,
        );
        $row['last_activity_ts'] = $now;
        $row['last_closed_ts'] = 0;
        return dmd_mydesk_policy_write($agentId, $row);
    }
}

if (!function_exists('dmd_mydesk_policy_heartbeat')) {
    function dmd_mydesk_policy_heartbeat($agentId, $windowId, $active) {
        $agentId = trim((string)$agentId);
        $windowId = trim((string)$windowId);
        $row = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
        if (!$row || dmd_mydesk_policy_is_locked($row)) return array('ok'=>false, 'locked'=>true);
        $now = time();
        if (!isset($row['windows'][$windowId]) || !is_array($row['windows'][$windowId])) {
            $row['windows'][$windowId] = array('opened_ts'=>$now,'last_seen_ts'=>$now,'last_activity_ts'=>$now);
        }
        $row['windows'][$windowId]['last_seen_ts'] = $now;
        if ($active) {
            $row['windows'][$windowId]['last_activity_ts'] = $now;
            $row['last_activity_ts'] = $now;
        }
        $latestActivity = dmd_mydesk_policy_latest_activity($row);
        if ($latestActivity <= 0 || ($now - $latestActivity) > DMD_MYDESK_IDLE_TTL) {
            $row['locked_ts'] = $now;
            dmd_mydesk_policy_write($agentId, $row);
            return array('ok'=>false, 'locked'=>true);
        }
        dmd_mydesk_policy_write($agentId, $row);
        return array('ok'=>true, 'locked'=>false, 'idle_remaining'=>max(0, DMD_MYDESK_IDLE_TTL - ($now - $latestActivity)));
    }
}

if (!function_exists('dmd_mydesk_policy_close_window')) {
    function dmd_mydesk_policy_close_window($agentId, $windowId) {
        $agentId = trim((string)$agentId);
        $windowId = trim((string)$windowId);
        $row = dmd_mydesk_policy_cleanup($agentId, dmd_mydesk_policy_read($agentId));
        if (!$row) return false;
        if (isset($row['windows'][$windowId])) unset($row['windows'][$windowId]);
        if (empty($row['windows'])) $row['last_closed_ts'] = time();
        return dmd_mydesk_policy_write($agentId, $row);
    }
}
