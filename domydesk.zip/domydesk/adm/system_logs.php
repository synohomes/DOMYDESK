<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = isset($_SESSION['user']['email']) ? dmd_sys_safe_email($_SESSION['user']['email']) : '';
$profile = $email !== '' ? dmd_sys_profile($email) : array();
if ($email === '' || (string)(isset($profile['role_system']) ? $profile['role_system'] : '') !== 'superadmin') {
    http_response_code(403);
    echo '<!doctype html><html lang="fr"><meta charset="utf-8"><body><p>Accès réservé au Superadmin.</p></body></html>';
    exit;
}

if (empty($_SESSION['csrf_syslogs'])) {
    $_SESSION['csrf_syslogs'] = bin2hex(random_bytes(24));
}

$root = $baseDir . '/data/sys_logs/';
if (!is_dir($root)) @mkdir($root, 0775, true);

function dmd_syslogs_safe_year($value) {
    $value = preg_replace('/[^0-9]/', '', (string)$value);
    return preg_match('/^20[0-9]{2}$/', $value) ? $value : '';
}
function dmd_syslogs_safe_month($value) {
    $value = preg_replace('/[^0-9]/', '', (string)$value);
    return preg_match('/^(0[1-9]|1[0-2])$/', $value) ? $value : '';
}
function dmd_syslogs_remove_dir($dir) {
    if (!is_dir($dir)) return true;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $path) {
        $ok = $path->isDir() ? @rmdir($path->getPathname()) : @unlink($path->getPathname());
        if (!$ok && file_exists($path->getPathname())) return false;
    }
    return @rmdir($dir) || !is_dir($dir);
}

$message = '';
$error = '';

$selectedYear = dmd_syslogs_safe_year(isset($_GET['year']) ? $_GET['year'] : date('Y'));
if ($selectedYear === '') $selectedYear = date('Y');
$selectedMonth = dmd_syslogs_safe_month(isset($_GET['month']) ? $_GET['month'] : date('m'));
if ($selectedMonth === '') $selectedMonth = date('m');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
    if (!hash_equals((string)$_SESSION['csrf_syslogs'], $token)) {
        $error = 'Formulaire expiré ou invalide.';
    } else {
        $action = isset($_POST['action']) ? (string)$_POST['action'] : '';
        $year = dmd_syslogs_safe_year(isset($_POST['year']) ? $_POST['year'] : '');
        $month = dmd_syslogs_safe_month(isset($_POST['month']) ? $_POST['month'] : '');
        if ($action === 'delete_month' && $year !== '' && $month !== '') {
            $target = $root . $year . '/' . $month . '/';
            if (dmd_syslogs_remove_dir($target)) {
                @rmdir($root . $year);
                $message = 'Logs du mois ' . $month . '/' . $year . ' supprimés.';
            } else {
                $error = 'Impossible de supprimer tous les logs de ce mois.';
            }
            $selectedYear = $year;
            $selectedMonth = $month;
        } elseif ($action === 'delete_year' && $year !== '') {
            $target = $root . $year . '/';
            if (dmd_syslogs_remove_dir($target)) {
                $message = 'Logs de l’année ' . $year . ' supprimés.';
            } else {
                $error = 'Impossible de supprimer tous les logs de cette année.';
            }
            $selectedYear = $year;
        }
    }
}

$years = array();
foreach (glob($root . '*', GLOB_ONLYDIR) ?: array() as $dir) {
    $y = basename($dir);
    if (dmd_syslogs_safe_year($y) !== '') $years[] = $y;
}
if (!in_array(date('Y'), $years, true)) $years[] = date('Y');
rsort($years, SORT_STRING);

$months = array();
$yearDir = $root . $selectedYear . '/';
foreach (glob($yearDir . '*', GLOB_ONLYDIR) ?: array() as $dir) {
    $m = basename($dir);
    if (dmd_syslogs_safe_month($m) !== '') $months[] = $m;
}
if ($selectedYear === date('Y') && !in_array(date('m'), $months, true)) $months[] = date('m');
sort($months, SORT_STRING);
if (!$months) $months = array($selectedMonth);
if (!in_array($selectedMonth, $months, true)) $selectedMonth = end($months);

$logs = array();
$monthDir = $root . $selectedYear . '/' . $selectedMonth . '/';
$files = glob($monthDir . '*.json') ?: array();
sort($files, SORT_STRING);
foreach ($files as $file) {
    $items = dmd_sys_json_read($file, array());
    if (!is_array($items)) continue;
    foreach ($items as $item) {
        if (is_array($item)) $logs[] = $item;
    }
}
usort($logs, function($a, $b) {
    return ((int)(isset($b['timestamp']) ? $b['timestamp'] : 0)) <=> ((int)(isset($a['timestamp']) ? $a['timestamp'] : 0));
});

$theme = 'default';
$themeFile = $baseDir . '/users/profiles/' . $email . '/theme.json';
$themeData = dmd_sys_json_read($themeFile, array());
if (!empty($themeData['theme']) && is_file($baseDir . '/theme/' . basename($themeData['theme']) . '/style.css')) {
    $theme = basename($themeData['theme']);
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Logs système</title>
<link rel="stylesheet" href="../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="../core/dmd_system_logs.css?v=120">
<?php require_once $baseDir . '/core/dmd_theme_assets.php'; echo dmd_theme_extra_links($baseDir, '../theme', $theme, 'system_logs'); ?>
</head>
<body>
<div class="dmd-syslogs-page">
    <?php if ($message !== ''): ?><div class="dmd-syslogs-msg ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="dmd-syslogs-msg error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

    <form method="get" class="dmd-syslogs-toolbar">
        <label>Année
            <select name="year" onchange="this.form.submit()">
                <?php foreach ($years as $year): ?>
                    <option value="<?= htmlspecialchars($year, ENT_QUOTES, 'UTF-8') ?>" <?= $year === $selectedYear ? 'selected' : '' ?>><?= htmlspecialchars($year, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Mois
            <select name="month" onchange="this.form.submit()">
                <?php foreach ($months as $month): ?>
                    <option value="<?= htmlspecialchars($month, ENT_QUOTES, 'UTF-8') ?>" <?= $month === $selectedMonth ? 'selected' : '' ?>><?= htmlspecialchars($month, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </form>

    <form method="post" class="dmd-syslogs-toolbar" onsubmit="return confirm(this.dataset.confirm || 'Confirmer ?');">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_syslogs'], ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="year" value="<?= htmlspecialchars($selectedYear, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="month" value="<?= htmlspecialchars($selectedMonth, ENT_QUOTES, 'UTF-8') ?>">
        <button class="danger" type="submit" name="action" value="delete_month" onclick="this.form.dataset.confirm='Supprimer tous les logs de <?= htmlspecialchars($selectedMonth . '/' . $selectedYear, ENT_QUOTES, 'UTF-8') ?> ?';">Supprimer ce mois</button>
        <button class="danger" type="submit" name="action" value="delete_year" onclick="this.form.dataset.confirm='Supprimer tous les logs de l’année <?= htmlspecialchars($selectedYear, ENT_QUOTES, 'UTF-8') ?> ?';">Supprimer l’année</button>
    </form>

    <p class="dmd-syslogs-summary"><?= count($logs) ?> événement(s) pour <?= htmlspecialchars($selectedMonth . '/' . $selectedYear, ENT_QUOTES, 'UTF-8') ?>.</p>

    <div class="dmd-syslogs-table-wrap">
        <?php if (!$logs): ?>
            <div class="dmd-syslogs-empty">Aucun log système pour cette période.</div>
        <?php else: ?>
            <table class="dmd-syslogs-table">
                <thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Cible</th><th>État</th></tr></thead>
                <tbody>
                <?php foreach ($logs as $log):
                    $payload = htmlspecialchars(json_encode($log, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
                    $status = (string)(isset($log['status']) ? $log['status'] : 'info');
                ?>
                    <tr data-log="<?= $payload ?>">
                        <td><?= htmlspecialchars(isset($log['date_iso']) ? date('d/m/Y H:i:s', (int)$log['timestamp']) : '', ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)(isset($log['user']) ? $log['user'] : ''), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)(isset($log['action']) ? $log['action'] : ''), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)(isset($log['target']) ? $log['target'] : ''), ENT_QUOTES, 'UTF-8') ?></td>
                        <td class="dmd-syslogs-status-<?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<div id="dmd-syslog-modal" class="dmd-syslogs-modal" aria-hidden="true">
    <div class="dmd-syslogs-modal-card">
        <div class="dmd-syslogs-modal-head"><h2>Détail du log système</h2><button type="button" id="dmd-syslog-close">Fermer</button></div>
        <dl id="dmd-syslog-detail" class="dmd-syslogs-detail"></dl>
    </div>
</div>
<script>
(function(){
    const modal = document.getElementById('dmd-syslog-modal');
    const detail = document.getElementById('dmd-syslog-detail');
    const close = document.getElementById('dmd-syslog-close');
    function add(label, value) {
        const dt = document.createElement('dt'); dt.textContent = label;
        const dd = document.createElement('dd');
        if (value && typeof value === 'object') dd.textContent = JSON.stringify(value, null, 2);
        else dd.textContent = value == null ? '' : String(value);
        detail.append(dt, dd);
    }
    document.querySelectorAll('[data-log]').forEach(row => row.addEventListener('click', () => {
        let log = {}; try { log = JSON.parse(row.dataset.log || '{}'); } catch(e) {}
        detail.textContent = '';
        add('Date', log.timestamp ? new Date(log.timestamp * 1000).toLocaleString('fr-FR') : '');
        add('Utilisateur', log.user || '');
        add('Nom', log.user_name || '');
        add('Rôle système', log.role_system || '');
        add('Action', log.action || '');
        add('Cible', log.target || '');
        add('État', log.status || '');
        add('Détails', log.details || '');
        add('IP', log.ip || '');
        add('User-Agent', log.user_agent || '');
        add('Extra', log.extra || {});
        modal.classList.add('is-open'); modal.setAttribute('aria-hidden','false');
    }));
    function hide(){ modal.classList.remove('is-open'); modal.setAttribute('aria-hidden','true'); }
    close.addEventListener('click', hide);
    modal.addEventListener('click', e => { if (e.target === modal) hide(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') hide(); });
})();
</script>
</body>
</html>
