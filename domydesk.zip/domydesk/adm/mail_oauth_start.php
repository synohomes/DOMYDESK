<?php
session_start();
$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = trim((string)($_SESSION['user']['email'] ?? ''));
if ($email === '') { header('Location: ../login.php'); exit; }
$profile = dmd_read_profile($email);
$role = strtolower(trim((string)($profile['role_system'] ?? 'user')));
if (!in_array($role, array('admin','superadmin'), true)) { header('Location: ../dashboard.php'); exit; }

$provider = strtolower(trim((string)($_GET['provider'] ?? '')));
$error = '';
$url = function_exists('dmd_mail_oauth_start_url') ? dmd_mail_oauth_start_url($provider, $error) : '';
if ($url === '') {
    $_SESSION['dmd_mail_oauth_flash'] = array('type'=>'error','message'=>$error !== '' ? $error : 'Moteur OAuth indisponible.');
    header('Location: notifications.php');
    exit;
}
header('Location: ' . $url, true, 302);
exit;
