<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
if ($email === '') { header('Location: ../login.php'); exit; }
$profile = dmd_read_profile($email);
$role = strtolower(trim((string)(isset($profile['role_system']) ? $profile['role_system'] : 'user')));
if (!in_array($role, array('admin','superadmin'), true)) { header('Location: ../dashboard.php'); exit; }
if (empty($_SESSION['csrf_notifications_admin'])) $_SESSION['csrf_notifications_admin'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_notifications_admin'];

function dmd_na_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmd_na_checked($v) { return !empty($v) ? ' checked' : ''; }
function dmd_na_event_field($key) { return str_replace(array('.', '-'), array('__DOT__','__DASH__'), (string)$key); }
function dmd_na_event_key($field) { return str_replace(array('__DOT__','__DASH__'), array('.','-'), (string)$field); }

$message = ''; $error = '';
$config = dmd_notifications_config();
$registry = dmd_notifications_registry();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
    if (!hash_equals($csrf, $token)) {
        $error = 'Formulaire expiré ou invalide.';
    } else {
        $action = isset($_POST['action']) ? (string)$_POST['action'] : '';

        if ($action === 'save_general') {
            $smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
            $previousProvider = strtolower(trim((string)($smtp['provider'] ?? 'custom')));
            $provider = strtolower(trim((string)($_POST['smtp_provider'] ?? 'custom')));
            if (!in_array($provider, array('gmail','microsoft','custom','phpmail'), true)) $provider = 'custom';

            $config['global_enabled'] = !empty($_POST['global_enabled']);
            $config['internal_enabled'] = !empty($_POST['internal_enabled']);
            $config['email_enabled'] = !empty($_POST['email_enabled']);
            $smtp['provider'] = $provider;
            $smtp['transport'] = $provider === 'phpmail' ? 'mail' : 'smtp';
            $smtp['from_name'] = trim((string)($_POST['from_name'] ?? 'DoMyDesk')) ?: 'DoMyDesk';
            $smtp['timeout'] = max(3, min(30, (int)($_POST['smtp_timeout'] ?? 8)));
            $smtp['username'] = trim((string)($_POST['smtp_username'] ?? ''));
            $smtp['from_email'] = trim((string)($_POST['from_email'] ?? ''));
            $password = (string)($_POST['smtp_password'] ?? '');

            if ($provider === 'gmail') {
                $smtp['host'] = 'smtp.gmail.com';
                $smtp['port'] = 587;
                $smtp['encryption'] = 'tls';
                $smtp['auth'] = true;
                $smtp['auth_method'] = 'login';
                $smtp['verify_peer'] = true;
                if ($smtp['from_email'] === '') $smtp['from_email'] = $smtp['username'];
                $password = preg_replace('/\s+/', '', $password);
                if ($password !== '') $smtp['password'] = $password;
                elseif ($previousProvider !== 'gmail') $smtp['password'] = '';
                $savedPassword = preg_replace('/\s+/', '', (string)($smtp['password'] ?? ''));
                if (!filter_var($smtp['username'], FILTER_VALIDATE_EMAIL)) $error = 'Gmail : adresse/identifiant invalide.';
                elseif (!filter_var($smtp['from_email'], FILTER_VALIDATE_EMAIL)) $error = 'Gmail : adresse expéditeur invalide.';
                elseif (strlen($savedPassword) !== 16) $error = 'Gmail : renseigne le mot de passe d’application Google à 16 caractères, pas le mot de passe du compte.';
            } elseif ($provider === 'microsoft') {
                $smtp['host'] = 'smtp.office365.com';
                $smtp['port'] = 587;
                $smtp['encryption'] = 'tls';
                $smtp['auth'] = true;
                $smtp['auth_method'] = 'login';
                $smtp['verify_peer'] = true;
                if ($smtp['from_email'] === '') $smtp['from_email'] = $smtp['username'];
                if ($password !== '') $smtp['password'] = $password;
                elseif ($previousProvider !== 'microsoft') $smtp['password'] = '';
                if (!filter_var($smtp['username'], FILTER_VALIDATE_EMAIL)) $error = 'Microsoft : adresse/identifiant invalide.';
                elseif (!filter_var($smtp['from_email'], FILTER_VALIDATE_EMAIL)) $error = 'Microsoft : adresse expéditeur invalide.';
                elseif ((string)($smtp['password'] ?? '') === '') $error = 'Microsoft : mot de passe SMTP manquant.';
            } elseif ($provider === 'custom') {
                $smtp['host'] = trim((string)($_POST['smtp_host'] ?? ''));
                $smtp['port'] = max(1, min(65535, (int)($_POST['smtp_port'] ?? 587)));
                $enc = strtolower(trim((string)($_POST['smtp_encryption'] ?? 'tls')));
                $smtp['encryption'] = in_array($enc, array('none','tls','ssl'), true) ? $enc : 'tls';
                $smtp['auth'] = !empty($_POST['smtp_auth']);
                $authMethod = strtolower(trim((string)($_POST['smtp_auth_method'] ?? 'auto')));
                $smtp['auth_method'] = in_array($authMethod, array('auto','login','plain'), true) ? $authMethod : 'auto';
                $smtp['verify_peer'] = !empty($_POST['smtp_verify_peer']);
                if ($password !== '') $smtp['password'] = $password;
                elseif ($previousProvider !== 'custom') $smtp['password'] = '';
                if ($smtp['host'] === '') $error = 'SMTP : hôte manquant.';
                elseif (!filter_var($smtp['from_email'], FILTER_VALIDATE_EMAIL)) $error = 'SMTP : adresse expéditeur invalide.';
                elseif (!empty($smtp['auth']) && $smtp['username'] === '') $error = 'SMTP : identifiant manquant.';
                elseif (!empty($smtp['auth']) && (string)($smtp['password'] ?? '') === '') $error = 'SMTP : mot de passe manquant.';
            } else {
                $smtp['auth'] = false;
                $smtp['verify_peer'] = true;
                if (!filter_var($smtp['from_email'], FILTER_VALIDATE_EMAIL)) $error = 'PHP mail() : adresse expéditeur invalide.';
            }

            $publicUrlRaw = trim((string)($_POST['instance_public_url'] ?? ''));
            $internalUrlRaw = trim((string)($_POST['instance_internal_url'] ?? ''));
            $publicUrl = dmd_notifications_url_normalize($publicUrlRaw);
            $internalUrl = dmd_notifications_url_normalize($internalUrlRaw);
            if ($error === '' && $publicUrlRaw !== '' && $publicUrl === '') $error = 'URL Internet DoMyDesk invalide (http:// ou https:// attendu).';
            if ($error === '' && $internalUrlRaw !== '' && $internalUrl === '') $error = 'URL interne DoMyDesk invalide (http:// ou https:// attendu).';

            $config['instance_urls'] = array(
                'public_url' => $publicUrl,
                'internal_url' => $internalUrl,
            );
            $config['smtp'] = $smtp;
            if ($error === '') {
                if (dmd_notifications_save_config($config)) {
                    $message = 'Configuration e-mail enregistrée.';
                    dmd_system_log('notifications_config_updated', 'notifications', 'success', 'Configuration e-mail modifiée.', array('provider'=>$provider));
                } else {
                    $error = 'Impossible d’enregistrer la configuration.';
                }
            }

        } elseif ($action === 'save_events') {
            $posted = isset($_POST['events']) && is_array($_POST['events']) ? $_POST['events'] : array();
            if (!isset($config['events']) || !is_array($config['events'])) $config['events'] = array();
            foreach ($registry as $eventKey => $definition) {
                $fieldKey = dmd_na_event_field($eventKey);
                $row = isset($posted[$fieldKey]) && is_array($posted[$fieldKey]) ? $posted[$fieldKey] : array();
                $defaults = isset($definition['defaults']) && is_array($definition['defaults']) ? $definition['defaults'] : array();
                $allowedRecipients = array('all_users','admins','superadmins','actor','target_user','context','module_users','custom');
                $recipients = isset($row['recipients']) && is_array($row['recipients']) ? array_values(array_intersect($allowedRecipients, array_map('strval', $row['recipients']))) : array();
                $config['events'][$eventKey] = array(
                    'internal' => !empty($row['internal']),
                    'email' => !empty($row['email']),
                    'recipients' => $recipients,
                    'custom_emails' => trim((string)($row['custom_emails'] ?? '')),
                    'internal_title' => (string)($row['internal_title'] ?? ($defaults['internal_title'] ?? '')),
                    'internal_message' => (string)($row['internal_message'] ?? ($defaults['internal_message'] ?? '')),
                    'email_subject' => (string)($row['email_subject'] ?? ($defaults['email_subject'] ?? '')),
                    'email_body' => (string)($row['email_body'] ?? ($defaults['email_body'] ?? '')),
                );
            }
            if (dmd_notifications_save_config($config)) {
                $message = 'Événements et textes enregistrés.';
                dmd_system_log('notifications_events_updated', 'notifications', 'success', 'Configuration des événements de notification modifiée.');
            } else $error = 'Impossible d’enregistrer les événements.';

        } elseif ($action === 'test_mail') {
            $to = trim((string)($_POST['test_email'] ?? ''));
            if (!filter_var($to, FILTER_VALIDATE_EMAIL)) $error = 'Adresse de test invalide.';
            else {
                $why = '';
                if (dmd_notifications_test_mail($to, $why)) {
                    $message = 'E-mail de test envoyé à ' . $to . '.';
                    dmd_notifications_log_mail(array('status'=>'test_sent','event'=>'admin.test','to'=>$to,'subject'=>'Test DoMyDesk'));
                } else {
                    $error = 'Échec du test : ' . $why;
                    dmd_notifications_log_mail(array('status'=>'test_failed','event'=>'admin.test','to'=>$to,'error'=>$why));
                }
            }

        } elseif ($action === 'retry_queue') {
            $result = dmd_notifications_queue_retry(25);
            $message = 'File traitée : ' . (int)$result['sent'] . ' envoyé(s), ' . (int)$result['failed'] . ' échec(s), ' . (int)$result['remaining'] . ' restant(s).';
        } elseif ($action === 'clear_queue') {
            dmd_notifications_queue_write(array());
            $message = 'File d’attente vidée.';
        } elseif ($action === 'clear_history') {
            $logFile = function_exists('dmd_notifications_mail_log_file') ? dmd_notifications_mail_log_file() : '';
            $cleared = false;

            if ($logFile === '') {
                $error = 'Historique e-mail introuvable.';
            } elseif (!is_file($logFile)) {
                $cleared = true;
            } else {
                $fp = @fopen($logFile, 'c+');
                if ($fp && @flock($fp, LOCK_EX)) {
                    rewind($fp);
                    $cleared = @ftruncate($fp, 0);
                    @fflush($fp);
                    @flock($fp, LOCK_UN);
                    @fclose($fp);
                    @chmod($logFile, 0640);
                } else {
                    if ($fp) @fclose($fp);
                }
            }

            if ($cleared) {
                $message = 'Historique e-mail vidé.';
                dmd_system_log('notifications_mail_history_cleared', 'notifications', 'success', 'Historique e-mail vidé depuis l’administration.');
            } else {
                $error = 'Impossible de vider l’historique e-mail.';
            }
        }
    }
    $config = dmd_notifications_config();
}

$theme = 'default';
$themeFile = $baseDir . '/users/profiles/' . basename($email) . '/theme.json';
if (is_file($themeFile)) {
    $td = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($td) && !empty($td['theme']) && is_file($baseDir . '/theme/' . basename((string)$td['theme']) . '/style.css')) $theme = basename((string)$td['theme']);
}
$smtp = isset($config['smtp']) && is_array($config['smtp']) ? $config['smtp'] : array();
$smtpProvider = strtolower(trim((string)($smtp['provider'] ?? 'custom')));
if (!in_array($smtpProvider, array('gmail','microsoft','custom','phpmail'), true)) $smtpProvider = 'custom';
$configuredInstanceUrls = isset($config['instance_urls']) && is_array($config['instance_urls']) ? $config['instance_urls'] : array();
$detectedInstanceUrls = dmd_notifications_instance_urls($config);
$queue = dmd_notifications_queue_read();
$logs = dmd_notifications_mail_logs(100);

$registryGroups = array();
foreach ($registry as $eventKey => $definition) {
    $groupKey = trim((string)($definition['module_id'] ?? ''));
    if ($groupKey === '') $groupKey = trim((string)($definition['module_name'] ?? 'DoMyDesk Core'));
    if ($groupKey === '') $groupKey = 'DoMyDesk Core';
    if (!isset($registryGroups[$groupKey])) {
        $registryGroups[$groupKey] = array('name'=>trim((string)($definition['module_name'] ?? $groupKey)),'events'=>array());
    }
    $registryGroups[$groupKey]['events'][$eventKey] = $definition;
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Notifications - Administration DoMyDesk</title>
<link rel="stylesheet" href="../theme/<?= dmd_na_h($theme) ?>/style.css">
<link rel="stylesheet" href="../core/dmd_notifications_admin.css?v=130">
<style>
.dmd-notif-section-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px}.dmd-notif-section-head .dmd-notif-section-title{margin:0}.dmd-notif-history-clear{border:1px solid var(--border-color);background:var(--button-bg,var(--panel-bg));color:var(--text-color);padding:6px 10px;border-radius:8px;cursor:pointer}
.dmd-notif-vars{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.dmd-notif-vars-help-btn{width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--border-color);border-radius:50%;background:var(--button-bg,var(--panel-bg));color:var(--text-color);font-weight:800;cursor:pointer;padding:0;line-height:1}
.dmd-notif-vars-help-btn:hover{filter:brightness(1.12)}
.dmd-notif-vars-help{width:100%;margin-top:8px;border:1px solid var(--border-color);border-radius:9px;background:var(--panel-bg);overflow:hidden}
.dmd-notif-vars-help-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:8px 10px;border-bottom:1px solid var(--border-color)}
.dmd-notif-vars-help-head strong{font-size:12px}
.dmd-notif-vars-help-head button{border:1px solid var(--border-color);background:var(--button-bg,var(--panel-bg));color:var(--text-color);border-radius:7px;padding:4px 8px;cursor:pointer}
.dmd-notif-vars-help-scroll{max-height:280px;overflow:auto}
.dmd-notif-vars-help table{width:100%;border-collapse:collapse;font-size:11px}
.dmd-notif-vars-help th,.dmd-notif-vars-help td{padding:7px 9px;text-align:left;vertical-align:top;border-bottom:1px solid var(--border-color)}
.dmd-notif-vars-help tr:last-child td{border-bottom:0}
.dmd-notif-vars-help th{position:sticky;top:0;background:var(--panel-bg);z-index:1}
.dmd-notif-vars-help code{white-space:nowrap}
.dmd-notif-vars-help-example{opacity:.8}
.dmd-notif-url-fields{display:grid;grid-template-columns:minmax(280px,1fr) minmax(280px,1fr) auto;gap:8px;align-items:end;margin-top:7px;padding-top:7px;border-top:1px solid var(--border-color)}
.dmd-notif-url-fields .dmd-notif-compact-field input{width:100%}
.dmd-notif-url-note{font-size:10px;line-height:1.35;opacity:.78;padding:0 2px 7px;max-width:360px}
@media(max-width:900px){.dmd-notif-url-fields{grid-template-columns:1fr}.dmd-notif-url-note{max-width:none;padding-bottom:2px}}

</style>
</head>
<body>
<?php include $baseDir . '/header.php'; ?>
<main class="dmd-notif-page">
  <div class="dmd-notif-head"><div><h1>Notifications</h1><p>Configuration centrale des notifications internes et des e-mails DoMyDesk.</p></div><a class="dmd-notif-back" href="site_settings.php">← Administration</a></div>
  <?php if ($message !== ''): ?><div class="dmd-notif-message ok">✅ <?= dmd_na_h($message) ?></div><?php endif; ?>
  <?php if ($error !== ''): ?><div class="dmd-notif-message err">❌ <?= dmd_na_h($error) ?></div><?php endif; ?>

  <form method="post" class="dmd-notif-general-form" id="dmdNotifGeneralForm">
    <input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>">
    <input type="hidden" name="action" value="save_general">
    <section class="dmd-notif-general">
      <div class="dmd-notif-general-bar">
        <strong>Configuration</strong>
        <div class="dmd-notif-checks dmd-notif-general-checks">
          <label><input type="checkbox" name="global_enabled" value="1"<?= dmd_na_checked($config['global_enabled']) ?>> Moteur</label>
          <label><input type="checkbox" name="internal_enabled" value="1"<?= dmd_na_checked($config['internal_enabled']) ?>> Interne</label>
          <label><input type="checkbox" name="email_enabled" value="1"<?= dmd_na_checked($config['email_enabled']) ?>> E-mail</label>
        </div>
        <button type="button" class="dmd-mail-help-btn" id="dmdMailHelpOpen" title="Aide pour configurer l’envoi e-mail" aria-label="Aide pour configurer l’envoi e-mail">?</button>
        <button type="submit" class="dmd-notif-primary-mini">Enregistrer</button>
		
      </div>
      <div class="dmd-notif-general-fields dmd-mail-simple-fields">
        <label class="dmd-notif-compact-field dmd-mail-provider-field"><span>Fournisseur</span><select name="smtp_provider" id="dmdSmtpProvider"><option value="gmail"<?= $smtpProvider==='gmail'?' selected':'' ?>>Gmail</option><option value="microsoft"<?= $smtpProvider==='microsoft'?' selected':'' ?>>Microsoft / Outlook SMTP</option><option value="custom"<?= $smtpProvider==='custom'?' selected':'' ?>>Autre SMTP</option><option value="phpmail"<?= $smtpProvider==='phpmail'?' selected':'' ?>>PHP mail()</option></select></label>
        <label class="dmd-notif-compact-field dmd-notif-field-host"><span>Hôte SMTP</span><input type="text" id="dmdSmtpHost" name="smtp_host" value="<?= dmd_na_h($smtp['host'] ?? '') ?>" placeholder="smtp.exemple.fr"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-port"><span>Port</span><input type="number" id="dmdSmtpPort" name="smtp_port" min="1" max="65535" value="<?= (int)($smtp['port'] ?? 587) ?>"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-enc"><span>Chiffrement</span><select id="dmdSmtpEncryption" name="smtp_encryption"><option value="tls"<?= (($smtp['encryption'] ?? 'tls')==='tls'?' selected':'') ?>>STARTTLS</option><option value="ssl"<?= (($smtp['encryption'] ?? '')==='ssl'?' selected':'') ?>>SSL/TLS</option><option value="none"<?= (($smtp['encryption'] ?? '')==='none'?' selected':'') ?>>Aucun</option></select></label>
        <label class="dmd-notif-compact-field dmd-notif-field-user"><span>Identifiant</span><input type="text" name="smtp_username" autocomplete="off" value="<?= dmd_na_h($smtp['username'] ?? '') ?>"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-pass"><span>Mot de passe</span><input type="password" id="dmdSmtpPassword" name="smtp_password" autocomplete="new-password" value="" placeholder="Vide = conserver"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-from"><span>Expéditeur</span><input type="email" name="from_email" value="<?= dmd_na_h($smtp['from_email'] ?? '') ?>"></label>
        <label class="dmd-notif-compact-field dmd-mail-name-field"><span>Nom</span><input type="text" name="from_name" value="<?= dmd_na_h($smtp['from_name'] ?? 'DoMyDesk') ?>"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-timeout"><span>Timeout</span><input type="number" name="smtp_timeout" min="3" max="30" value="<?= (int)($smtp['timeout'] ?? 8) ?>"></label>
        <label class="dmd-notif-compact-field dmd-notif-field-auth"><span>AUTH</span><select name="smtp_auth_method"><option value="auto"<?= (($smtp['auth_method'] ?? 'auto')==='auto'?' selected':'') ?>>Auto</option><option value="login"<?= (($smtp['auth_method'] ?? '')==='login'?' selected':'') ?>>LOGIN</option><option value="plain"<?= (($smtp['auth_method'] ?? '')==='plain'?' selected':'') ?>>PLAIN</option></select></label>
        <label class="dmd-notif-mini-check dmd-smtp-toggle"><input type="checkbox" name="smtp_auth" value="1"<?= dmd_na_checked($smtp['auth'] ?? true) ?>> Auth SMTP</label>
        <label class="dmd-notif-mini-check dmd-smtp-toggle"><input type="checkbox" name="smtp_verify_peer" value="1"<?= dmd_na_checked(array_key_exists('verify_peer',$smtp)?$smtp['verify_peer']:true) ?>> TLS vérifié</label>
      </div>
      <div class="dmd-notif-url-fields">
        <label class="dmd-notif-compact-field"><span>URL Internet DoMyDesk</span><input type="url" name="instance_public_url" value="<?= dmd_na_h($configuredInstanceUrls['public_url'] ?? '') ?>" placeholder="<?= dmd_na_h($detectedInstanceUrls['public_url'] ?: 'Détection automatique') ?>"></label>
        <label class="dmd-notif-compact-field"><span>URL interne DoMyDesk</span><input type="url" name="instance_internal_url" value="<?= dmd_na_h($configuredInstanceUrls['internal_url'] ?? '') ?>" placeholder="<?= dmd_na_h($detectedInstanceUrls['internal_url'] ?: 'Détection automatique') ?>"></label>
        <div class="dmd-notif-url-note">Laisse vide pour la détection automatique à partir de l’accès courant et des informations connues de l’instance. Les deux adresses sont ajoutées au mail lorsqu’elles sont disponibles.</div>
      </div>
      <div class="dmd-mail-provider-note" id="dmdMailProviderNote"></div>
    </section>
  </form>

  <div class="dmd-mail-help-modal" id="dmdMailHelpModal" hidden aria-hidden="true">
    <button type="button" class="dmd-mail-help-backdrop" data-mail-help-close tabindex="-1" aria-label="Fermer l’aide"></button>
    <div class="dmd-mail-help-dialog" role="dialog" aria-modal="true" aria-labelledby="dmdMailHelpTitle">
      <div class="dmd-mail-help-head">
        <div><strong id="dmdMailHelpTitle">Aide — Configuration e-mail</strong><span>Choisis ton fournisseur et suis uniquement sa procédure.</span></div>
        <button type="button" class="dmd-mail-help-close" data-mail-help-close aria-label="Fermer">×</button>
      </div>

      <div class="dmd-mail-help-tabs" role="tablist" aria-label="Fournisseurs e-mail">
        <button type="button" class="is-active" data-mail-help-tab="gmail">Gmail</button>
        <button type="button" data-mail-help-tab="m365">Microsoft 365</button>
        <button type="button" data-mail-help-tab="outlook">Outlook.com</button>
        <button type="button" data-mail-help-tab="ovh">OVHcloud</button>
        <button type="button" data-mail-help-tab="other">Autre SMTP</button>
      </div>

      <div class="dmd-mail-help-body">
        <section class="dmd-mail-help-panel is-active" data-mail-help-panel="gmail">
          <h3>Gmail</h3>
          <div class="dmd-mail-help-settings"><b>Hôte</b><code>smtp.gmail.com</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code><b>AUTH</b><code>Oui</code></div>
          <ol>
            <li>Dans DoMyDesk, mets ton <b>adresse Gmail complète</b> comme Identifiant et Expéditeur.</li>
            <li>Dans ton compte Google, active <b>Validation en deux étapes</b>.</li>
            <li>Ouvre ensuite <b>Mots de passe des applications</b> et crée un mot de passe nommé <b>DoMyDesk</b>.</li>
            <li>Google fournit un code de <b>16 caractères</b>. Mets ce code dans <b>Mot de passe</b> de DoMyDesk — pas ton mot de passe Gmail habituel.</li>
            <li>Enregistre puis utilise <b>Test e-mail</b>.</li>
          </ol>
          <p class="dmd-mail-help-warning">Si « Mots de passe des applications » n’existe pas, Google peut le masquer pour certains comptes d’organisation, la Protection Avancée ou certaines configurations de clés de sécurité.</p>
          <button type="button" class="dmd-mail-help-apply" data-mail-apply="gmail">Appliquer les paramètres Gmail</button>
        </section>

        <section class="dmd-mail-help-panel" data-mail-help-panel="m365" hidden>
          <h3>Microsoft 365 / Exchange Online</h3>
          <div class="dmd-mail-help-settings"><b>Hôte</b><code>smtp.office365.com</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code><b>AUTH</b><code>Oui</code></div>
          <ol>
            <li>Utilise l’<b>adresse complète de la boîte Microsoft 365</b> comme Identifiant et Expéditeur.</li>
            <li>Le compte doit autoriser <b>SMTP AUTH</b>. Sur Microsoft 365, cette option peut être désactivée au niveau du tenant ou de la boîte.</li>
            <li>Entre le mot de passe autorisé pour l’envoi SMTP, enregistre puis teste.</li>
          </ol>
          <p class="dmd-mail-help-warning">Microsoft fait évoluer SMTP AUTH vers OAuth. En 2026, l’authentification Basic reste inchangée jusqu’à fin décembre 2026, puis elle sera désactivée par défaut. Si ton tenant la refuse déjà, le SMTP identifiant/mot de passe de cette version de DoMyDesk ne pourra pas contourner cette politique.</p>
          <button type="button" class="dmd-mail-help-apply" data-mail-apply="m365">Appliquer Microsoft 365</button>
        </section>

        <section class="dmd-mail-help-panel" data-mail-help-panel="outlook" hidden>
          <h3>Outlook.com / Hotmail / Live personnel</h3>
          <div class="dmd-mail-help-settings"><b>Hôte</b><code>smtp-mail.outlook.com</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code><b>Auth officielle</b><code>OAuth2</code></div>
          <p>Microsoft documente actuellement <b>OAuth2 / Modern Auth</b> pour Outlook.com. Le moteur SMTP actuel de DoMyDesk utilise une authentification SMTP classique par identifiant/mot de passe : un compte Outlook.com peut donc refuser cette méthode.</p>
          <p class="dmd-mail-help-warning">Si le test échoue avec une erreur d’authentification, ne change pas les ports au hasard : c’est probablement la méthode d’authentification qui est refusée.</p>
          <button type="button" class="dmd-mail-help-apply" data-mail-apply="outlook">Préremplir le serveur Outlook.com</button>
        </section>

        <section class="dmd-mail-help-panel" data-mail-help-panel="ovh" hidden>
          <h3>OVHcloud</h3>
          <div class="dmd-mail-help-subgrid">
            <div>
              <h4>MX Plan — Europe</h4>
              <div class="dmd-mail-help-settings"><b>Hôte</b><code>smtp.mail.ovh.net</code><b>Alternative</b><code>ssl0.ovh.net</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code></div>
              <p>Identifiant : adresse e-mail complète. Mot de passe : mot de passe normal de la boîte. AUTH SMTP activée.</p>
              <button type="button" class="dmd-mail-help-apply" data-mail-apply="ovh-mx">Appliquer OVH MX Plan</button>
            </div>
            <div>
              <h4>Email Pro</h4>
              <div class="dmd-mail-help-settings"><b>Hôte</b><code>pro?.mail.ovh.net</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code></div>
              <p>Remplace <b>?</b> par le numéro du serveur indiqué par OVHcloud. Identifiant : adresse complète. Mot de passe normal.</p>
            </div>
            <div>
              <h4>Exchange OVHcloud</h4>
              <div class="dmd-mail-help-settings"><b>Hôte</b><code>ex?.mail.ovh.net</code><b>Port</b><code>587</code><b>Chiffrement</b><code>STARTTLS</code></div>
              <p>Le nom exact du serveur est indiqué dans les informations générales de ta plateforme Exchange OVHcloud.</p>
            </div>
          </div>
        </section>

        <section class="dmd-mail-help-panel" data-mail-help-panel="other" hidden>
          <h3>Autre fournisseur SMTP</h3>
          <ol>
            <li>Récupère chez ton fournisseur : <b>serveur SMTP</b>, <b>port</b>, <b>STARTTLS ou SSL/TLS</b>, méthode AUTH et identifiant.</li>
            <li>Dans DoMyDesk sélectionne <b>Autre SMTP</b>.</li>
            <li>Renseigne exactement ces valeurs. En général l’identifiant est l’adresse e-mail complète.</li>
            <li>Laisse <b>TLS vérifié</b> activé. Ne le désactive que pour diagnostiquer un serveur interne avec certificat non reconnu.</li>
            <li>Enregistre puis utilise <b>Test e-mail</b>. Le message d’erreur permet de distinguer DNS, TLS, authentification ou refus du serveur.</li>
          </ol>
        </section>
      </div>

      <div class="dmd-mail-help-foot">
        <span>Cette aide ne modifie rien tant que tu ne cliques pas sur « Appliquer » puis « Enregistrer ».</span>
        <button type="button" data-mail-help-close>Fermer</button>
      </div>
    </div>
  </div>
<br>
  <section class="dmd-notif-testbar">
    <form method="post" class="dmd-notif-testbar-form">
      <input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>">
      <input type="hidden" name="action" value="test_mail">
      <strong>Test e-mail</strong>
      <span>Utilise les paramètres enregistrés.</span>
      <input type="email" name="test_email" value="<?= dmd_na_h($email) ?>" required aria-label="Destinataire du test">
      <button type="submit">Envoyer</button>
    </form>
  </section>
<br>
  <div class="dmd-notif-events-toolbar">
    <h2 class="dmd-notif-section-title">Événements et textes</h2>
    <div class="dmd-notif-events-search"><label for="dmdNotifSearch">Rechercher</label><input type="search" id="dmdNotifSearch" placeholder="Module, action, utilisateur, impression…"></div>
    <button type="submit" form="dmdNotifEventsForm" class="dmd-notif-events-save">Enregistrer</button>
  </div>

  <form method="post" id="dmdNotifEventsForm">
    <input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>">
    <input type="hidden" name="action" value="save_events">

    <div class="dmd-notif-modules">
    <?php foreach ($registryGroups as $groupKey => $group): ?>
      <section class="dmd-notif-module" data-notif-module>
        <button type="button" class="dmd-notif-module-head" data-module-toggle aria-expanded="false">
          <span class="dmd-notif-module-head-copy">
            <strong><?= dmd_na_h($group['name']) ?></strong>
            <small><?= count($group['events']) ?></small>
          </span>
          <span class="dmd-notif-module-caret" aria-hidden="true">▸</span>
        </button>

        <div class="dmd-notif-action-list" data-module-body hidden>
        <?php foreach ($group['events'] as $eventKey => $definition):
          $eventSettings = dmd_notifications_event_settings($eventKey, $definition, $config);
          $fieldKey = dmd_na_event_field($eventKey);
          $recips = $eventSettings['recipients'];
          $eventDefaults = $definition['defaults'];
        ?>
          <div class="dmd-notif-action-row" data-notif-event data-search="<?= dmd_na_h(strtolower($definition['module_name'] . ' ' . $definition['label'] . ' ' . $eventKey)) ?>">
            <div class="dmd-notif-action-main">
              <strong><?= dmd_na_h($definition['label']) ?></strong>
              <small><?= dmd_na_h($eventKey) ?></small>
            </div>

            <label class="dmd-notif-mini-check"><input type="checkbox" name="events[<?= dmd_na_h($fieldKey) ?>][internal]" value="1"<?= dmd_na_checked($eventSettings['internal']) ?>> Interne</label>
            <label class="dmd-notif-mini-check"><input type="checkbox" name="events[<?= dmd_na_h($fieldKey) ?>][email]" value="1"<?= dmd_na_checked($eventSettings['email']) ?>> E-mail</label>
            <button type="button" class="dmd-notif-config-btn" data-config-event aria-expanded="false">Configurer</button>

            <div class="dmd-notif-action-config" data-event-config-panel hidden aria-hidden="true">
              <button type="button" class="dmd-notif-modal-backdrop" data-config-close tabindex="-1" aria-label="Fermer"></button>
              <div class="dmd-notif-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="notif-title-<?= dmd_na_h($fieldKey) ?>">
                <div class="dmd-notif-modal-head">
                  <div>
                    <small><?= dmd_na_h($definition['module_name']) ?></small>
                    <h3 id="notif-title-<?= dmd_na_h($fieldKey) ?>"><?= dmd_na_h($definition['label']) ?></h3>
                    <code><?= dmd_na_h($eventKey) ?></code>
                  </div>
                  <button type="button" class="dmd-notif-modal-close" data-config-close aria-label="Fermer">×</button>
                </div>

                <div class="dmd-notif-modal-body">
                  <div class="dmd-notif-config-head">
                    <div><?php if (!empty($definition['description'])): ?><p><?= dmd_na_h($definition['description']) ?></p><?php endif; ?></div>
                    <button type="button" data-reset-event>Texte par défaut</button>
                  </div>

                  <div class="dmd-notif-field full">
                    <label>Destinataires</label>
                    <div class="dmd-notif-recipient-grid">
                    <?php
                      $recipientLabels = array(
                        'all_users'=>'Tous les utilisateurs', 'admins'=>'Admins', 'superadmins'=>'Superadmins',
                        'actor'=>'Utilisateur à l’origine', 'target_user'=>'Utilisateur cible', 'context'=>'Utilisateurs concernés',
                        'module_users'=>'Utilisateurs du module', 'custom'=>'Adresses personnalisées'
                      );
                      foreach ($recipientLabels as $rid => $rlabel):
                    ?>
                      <label><input type="checkbox" name="events[<?= dmd_na_h($fieldKey) ?>][recipients][]" value="<?= dmd_na_h($rid) ?>"<?= in_array($rid,$recips,true)?' checked':'' ?>> <?= dmd_na_h($rlabel) ?></label>
                    <?php endforeach; ?>
                    </div>
                  </div>

                  <div class="dmd-notif-event-grid">
                    <div class="dmd-notif-field full"><label>Adresses personnalisées</label><input type="text" name="events[<?= dmd_na_h($fieldKey) ?>][custom_emails]" value="<?= dmd_na_h($eventSettings['custom_emails'] ?? '') ?>" placeholder="mail1@domaine.fr; mail2@domaine.fr"></div>
                    <div class="dmd-notif-field"><label>Titre notification interne</label><input type="text" name="events[<?= dmd_na_h($fieldKey) ?>][internal_title]" value="<?= dmd_na_h($eventSettings['internal_title']) ?>" data-default="<?= dmd_na_h($eventDefaults['internal_title'] ?? '') ?>"></div>
                    <div class="dmd-notif-field"><label>Objet e-mail</label><input type="text" name="events[<?= dmd_na_h($fieldKey) ?>][email_subject]" value="<?= dmd_na_h($eventSettings['email_subject']) ?>" data-default="<?= dmd_na_h($eventDefaults['email_subject'] ?? '') ?>"></div>
                    <div class="dmd-notif-field"><label>Texte notification interne</label><textarea name="events[<?= dmd_na_h($fieldKey) ?>][internal_message]" data-default="<?= dmd_na_h($eventDefaults['internal_message'] ?? '') ?>"><?= dmd_na_h($eventSettings['internal_message']) ?></textarea></div>
                    <div class="dmd-notif-field"><label>Texte e-mail</label><textarea name="events[<?= dmd_na_h($fieldKey) ?>][email_body]" data-default="<?= dmd_na_h($eventDefaults['email_body'] ?? '') ?>"><?= dmd_na_h($eventSettings['email_body']) ?></textarea></div>
                  </div>

                  <div class="dmd-notif-vars">
                    <strong>Variables :</strong>
                    <button type="button" class="dmd-notif-vars-help-btn" data-vars-help-toggle title="À quoi correspondent ces variables ?" aria-label="Aide sur les variables" aria-expanded="false">?</button>
                    <?php foreach ($definition['variables'] as $var): ?><code>{<?= dmd_na_h($var) ?>}</code> <?php endforeach; ?>

                    <div class="dmd-notif-vars-help" data-vars-help-panel hidden>
                      <div class="dmd-notif-vars-help-head">
                        <strong>Aide — Variables disponibles pour cet événement</strong>
                        <button type="button" data-vars-help-close>Fermer</button>
                      </div>
                      <div class="dmd-notif-vars-help-scroll">
                        <table>
                          <thead>
                            <tr>
                              <th>Variable</th>
                              <th>Correspond à</th>
                              <th>Description</th>
                              <th>Exemple</th>
                            </tr>
                          </thead>
                          <tbody>
                          <?php foreach ($definition['variables'] as $var):
                            $varHelp = function_exists('dmd_notifications_variable_help')
                              ? dmd_notifications_variable_help($var, $definition)
                              : array(
                                  'label'=>'Variable du module',
                                  'description'=>'Valeur fournie par cet événement.',
                                  'example'=>''
                                );
                          ?>
                            <tr>
                              <td><code>{<?= dmd_na_h($var) ?>}</code></td>
                              <td><strong><?= dmd_na_h($varHelp['label'] ?? '') ?></strong></td>
                              <td><?= dmd_na_h($varHelp['description'] ?? '') ?></td>
                              <td class="dmd-notif-vars-help-example"><?= dmd_na_h($varHelp['example'] ?? '') ?></td>
                            </tr>
                          <?php endforeach; ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="dmd-notif-modal-foot">
                  <span>« Terminer » enregistre immédiatement les destinataires et les textes de cet événement.</span>
                  <button type="submit" form="dmdNotifEventsForm">Terminer et enregistrer</button>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
    </div>

  </form>
<br>
  <h2 class="dmd-notif-section-title">File d’attente e-mail</h2>
  <section class="dmd-notif-card"><p><?= count($queue) ?> e-mail(s) en attente après un échec de transport.</p><div class="dmd-notif-actions"><form method="post"><input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>"><input type="hidden" name="action" value="retry_queue"><button type="submit">Réessayer jusqu’à 25</button></form><form method="post" onsubmit="return confirm('Vider définitivement la file d’attente ?');"><input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>"><input type="hidden" name="action" value="clear_queue"><button type="submit">Vider la file</button></form></div>
  <?php if ($queue): ?><div class="dmd-notif-table-wrap"><table class="dmd-notif-table"><thead><tr><th>Date</th><th>Événement</th><th>Destinataire</th><th>Essais</th><th>Dernière erreur</th></tr></thead><tbody><?php foreach(array_reverse(array_slice($queue,-80)) as $q): ?><tr><td><?= dmd_na_h($q['created_at'] ?? '') ?></td><td><?= dmd_na_h($q['event'] ?? '') ?></td><td><?= dmd_na_h($q['to'] ?? '') ?></td><td><?= (int)($q['attempts'] ?? 0) ?></td><td><?= dmd_na_h($q['last_error'] ?? '') ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<br>
  <div class="dmd-notif-section-head">
    <h2 class="dmd-notif-section-title">Historique e-mail</h2>
    <form method="post" onsubmit="return confirm('Vider définitivement tout l’historique e-mail ?');">
      <input type="hidden" name="csrf_token" value="<?= dmd_na_h($csrf) ?>">
      <input type="hidden" name="action" value="clear_history"><br>
      <button type="submit" class="dmd-notif-history-clear">Vider l’historique</button>
    </form>
  </div><br>
  <section class="dmd-notif-card"><?php if (!$logs): ?><p>Aucun envoi enregistré.</p><?php else: ?><div class="dmd-notif-table-wrap"><table class="dmd-notif-table"><thead><tr><th>Date</th><th>État</th><th>Événement</th><th>Destinataire</th><th>Objet / erreur</th></tr></thead><tbody><?php foreach($logs as $log): $ok=in_array(($log['status']??''),array('sent','sent_retry','test_sent'),true); ?><tr><td><?= dmd_na_h($log['at'] ?? '') ?></td><td class="<?= $ok?'dmd-notif-status-ok':'dmd-notif-status-bad' ?>"><?= dmd_na_h($log['status'] ?? '') ?></td><td><?= dmd_na_h($log['event'] ?? '') ?></td><td><?= dmd_na_h($log['to'] ?? '') ?></td><td><?= dmd_na_h(($log['subject'] ?? '') . (($log['error'] ?? '')!==''?' — '.$log['error']:'')) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
</main>
<script>
(function(){
  const search = document.getElementById('dmdNotifSearch');
  const events = Array.from(document.querySelectorAll('[data-notif-event]'));
  const modules = Array.from(document.querySelectorAll('[data-notif-module]'));
  let lastSearch = '';
  let activePanel = null;
  let activeButton = null;

  const mailHelpOpen = document.getElementById('dmdMailHelpOpen');
  const mailHelpModal = document.getElementById('dmdMailHelpModal');
  const mailHelpTabs = Array.from(document.querySelectorAll('[data-mail-help-tab]'));
  const mailHelpPanels = Array.from(document.querySelectorAll('[data-mail-help-panel]'));

  function setMailHelpTab(id){
    mailHelpTabs.forEach(function(tab){
      const active = tab.dataset.mailHelpTab === id;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    mailHelpPanels.forEach(function(panel){
      const active = panel.dataset.mailHelpPanel === id;
      panel.hidden = !active;
      panel.classList.toggle('is-active', active);
    });
  }

  function openMailHelp(){
    if (!mailHelpModal) return;
    mailHelpModal.hidden = false;
    mailHelpModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('dmd-mail-help-open');
    setMailHelpTab('gmail');
    const close = mailHelpModal.querySelector('.dmd-mail-help-close');
    if (close) close.focus();
  }

  function closeMailHelp(){
    if (!mailHelpModal) return;
    mailHelpModal.hidden = true;
    mailHelpModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('dmd-mail-help-open');
    if (mailHelpOpen) mailHelpOpen.focus();
  }

  if (mailHelpOpen) mailHelpOpen.addEventListener('click', openMailHelp);
  document.querySelectorAll('[data-mail-help-close]').forEach(function(button){ button.addEventListener('click', closeMailHelp); });
  mailHelpTabs.forEach(function(tab){ tab.addEventListener('click', function(){ setMailHelpTab(tab.dataset.mailHelpTab || 'gmail'); }); });

  const provider = document.getElementById('dmdSmtpProvider');
  const host = document.getElementById('dmdSmtpHost');
  const port = document.getElementById('dmdSmtpPort');
  const enc = document.getElementById('dmdSmtpEncryption');
  const pass = document.getElementById('dmdSmtpPassword');
  const providerNote = document.getElementById('dmdMailProviderNote');
  function syncProvider(){
    if (!provider) return;
    const value = provider.value;
    const preset = value === 'gmail' || value === 'microsoft';
    if (value === 'gmail') {
      if (host) host.value = 'smtp.gmail.com'; if (port) port.value = '587'; if (enc) enc.value = 'tls';
      if (pass) pass.placeholder = 'Mot de passe d’application Google (16 caractères)';
      if (providerNote) providerNote.textContent = 'Gmail : mot de passe d’application Google obligatoire. Le mot de passe normal du compte ne fonctionne pas.';
    } else if (value === 'microsoft') {
      if (host) host.value = 'smtp.office365.com'; if (port) port.value = '587'; if (enc) enc.value = 'tls';
      if (pass) pass.placeholder = 'Mot de passe SMTP';
      if (providerNote) providerNote.textContent = 'Microsoft : fonctionne uniquement si SMTP AUTH est autorisé pour ce compte.';
    } else if (value === 'phpmail') {
      if (pass) pass.placeholder = 'Non utilisé';
      if (providerNote) providerNote.textContent = 'PHP mail() utilise la configuration mail du NAS/serveur.';
    } else {
      if (pass) pass.placeholder = 'Vide = conserver';
      if (providerNote) providerNote.textContent = 'SMTP personnalisé.';
    }
    if (host) host.readOnly = preset;
    if (port) port.readOnly = preset;
  }
  if (provider) provider.addEventListener('change', syncProvider);
  syncProvider();

  document.querySelectorAll('[data-mail-apply]').forEach(function(button){
    button.addEventListener('click', function(){
      const type = button.dataset.mailApply || '';
      if (!provider) return;
      if (type === 'gmail') {
        provider.value = 'gmail';
        syncProvider();
      } else if (type === 'm365') {
        provider.value = 'microsoft';
        syncProvider();
      } else if (type === 'outlook') {
        provider.value = 'custom';
        syncProvider();
        if (host) host.value = 'smtp-mail.outlook.com';
        if (port) port.value = '587';
        if (enc) enc.value = 'tls';
        if (providerNote) providerNote.textContent = 'Outlook.com : serveur prérempli, mais Microsoft exige officiellement OAuth2/Modern Auth ; le mode mot de passe peut être refusé.';
      } else if (type === 'ovh-mx') {
        provider.value = 'custom';
        syncProvider();
        if (host) host.value = 'smtp.mail.ovh.net';
        if (port) port.value = '587';
        if (enc) enc.value = 'tls';
        if (providerNote) providerNote.textContent = 'OVHcloud MX Plan Europe : smtp.mail.ovh.net, port 587, STARTTLS, adresse complète + mot de passe de la boîte.';
      }
      closeMailHelp();
      const form = document.getElementById('dmdNotifGeneralForm');
      if (form) form.scrollIntoView({behavior:'smooth', block:'start'});
    });
  });

  function setModuleOpen(module, open){
    const toggle = module.querySelector('[data-module-toggle]');
    const body = module.querySelector('[data-module-body]');
    if (!toggle || !body) return;
    body.hidden = !open;
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    module.classList.toggle('is-open', open);
  }

  modules.forEach(function(module){
    setModuleOpen(module, false);
    const toggle = module.querySelector('[data-module-toggle]');
    if (toggle) {
      toggle.addEventListener('click', function(){
        setModuleOpen(module, toggle.getAttribute('aria-expanded') !== 'true');
      });
    }
  });

  function applySearch(){
    const q = search ? (search.value || '').toLocaleLowerCase('fr').trim() : '';
    const startingSearch = !!q && !lastSearch;
    const endingSearch = !q && !!lastSearch;

    modules.forEach(function(module){
      if (startingSearch) module.dataset.openBeforeSearch = module.classList.contains('is-open') ? '1' : '0';
    });

    events.forEach(function(row){
      row.hidden = !!q && !(row.dataset.search || '').includes(q);
    });

    modules.forEach(function(module){
      const matching = Array.from(module.querySelectorAll('[data-notif-event]')).some(function(row){ return !row.hidden; });
      module.hidden = !!q && !matching;
      if (q && matching) setModuleOpen(module, true);
      if (endingSearch) {
        setModuleOpen(module, module.dataset.openBeforeSearch === '1');
        delete module.dataset.openBeforeSearch;
      }
    });

    lastSearch = q;
  }

  if (search) search.addEventListener('input', applySearch);

  function closeConfig(){
    if (!activePanel) return;
    activePanel.hidden = true;
    activePanel.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('dmd-notif-modal-open');
    if (activeButton) {
      activeButton.setAttribute('aria-expanded', 'false');
      activeButton.focus();
    }
    activePanel = null;
    activeButton = null;
  }

  document.querySelectorAll('[data-config-event]').forEach(function(button){
    button.addEventListener('click', function(){
      const row = button.closest('[data-notif-event]');
      const panel = row ? row.querySelector('[data-event-config-panel]') : null;
      if (!panel) return;
      if (activePanel && activePanel !== panel) closeConfig();
      activePanel = panel;
      activeButton = button;
      panel.hidden = false;
      panel.setAttribute('aria-hidden', 'false');
      button.setAttribute('aria-expanded', 'true');
      document.body.classList.add('dmd-notif-modal-open');
      const close = panel.querySelector('.dmd-notif-modal-close');
      if (close) close.focus();
    });
  });

  document.querySelectorAll('[data-config-close]').forEach(function(button){
    button.addEventListener('click', closeConfig);
  });

  document.querySelectorAll('[data-reset-event]').forEach(function(button){
    button.addEventListener('click', function(){
      const panel = button.closest('[data-event-config-panel]');
      if (!panel) return;
      panel.querySelectorAll('[data-default]').forEach(function(field){ field.value = field.dataset.default || ''; });
    });
  });


  document.querySelectorAll('[data-vars-help-toggle]').forEach(function(button){
    button.addEventListener('click', function(){
      const vars = button.closest('.dmd-notif-vars');
      const panel = vars ? vars.querySelector('[data-vars-help-panel]') : null;
      if (!panel) return;
      const opening = panel.hidden;
      panel.hidden = !opening;
      button.setAttribute('aria-expanded', opening ? 'true' : 'false');
    });
  });

  document.querySelectorAll('[data-vars-help-close]').forEach(function(button){
    button.addEventListener('click', function(){
      const panel = button.closest('[data-vars-help-panel]');
      if (!panel) return;
      panel.hidden = true;
      const vars = panel.closest('.dmd-notif-vars');
      const toggle = vars ? vars.querySelector('[data-vars-help-toggle]') : null;
      if (toggle) {
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  });

  document.addEventListener('keydown', function(event){
    if (event.key !== 'Escape') return;
    if (mailHelpModal && !mailHelpModal.hidden) { closeMailHelp(); return; }
    if (activePanel) closeConfig();
  });

  applySearch();
})();
</script>
</body></html>
