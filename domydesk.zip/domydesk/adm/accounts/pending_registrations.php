<?php if (!$isSuperadmin) { http_response_code(403); exit('Accès réservé au Superadmin.'); } ?>
<div class="dmd-security-panel">
    <p class="pe-note">Toute inscription créée depuis la page publique d’inscription reste bloquée jusqu’à validation du Superadmin. Les comptes créés directement par un administrateur et les imports Active Directory validés par le Superadmin sont actifs immédiatement.</p>
    <?php if (!$dmdPendingRegistrations): ?>
        <p>Aucune inscription en attente.</p>
    <?php else: ?>
        <div class="table-wrap"><table class="roles-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Rôle prévu</th><th>Demande</th><th>Action</th></tr></thead><tbody>
        <?php foreach ($dmdPendingRegistrations as $pendingEmail => $pending): ?>
            <tr>
                <td><strong><?= htmlspecialchars(trim((string)($pending['prenom'] ?? '') . ' ' . (string)($pending['nom'] ?? '')), ENT_QUOTES, 'UTF-8') ?></strong></td>
                <td><?= htmlspecialchars($pendingEmail, ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($pending['role_metier'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars((string)($pending['registration_requested_at'] ?? $pending['created_at'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></td>
                <td>
                    <form method="post" style="display:inline">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="registration_email" value="<?= htmlspecialchars($pendingEmail, ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" name="approve_registration" value="1">Valider</button>
                        <button type="submit" name="refuse_registration" value="1" class="btn-del" onclick="return confirm('Refuser cette inscription ?')">Refuser</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</div>
