<?php
require_once $baseDir . '/core/dmd_account_approval.php';
$dmdPendingRegistrations = dmd_account_pending_registrations();
$dmdAccountApprovalAction = isset($_POST['approve_registration']) || isset($_POST['refuse_registration']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dmdAccountApprovalAction) {
    $reopenPopup = 'popup-security-admin';
    if (!$isSuperadmin) {
        $errors[] = 'Validation d’inscription réservée au Superadmin.';
    } elseif (!hash_equals((string)($_SESSION['csrf_site_settings'] ?? ''), (string)($_POST['csrf_token'] ?? ''))) {
        $errors[] = 'Validation refusée : formulaire expiré ou invalide.';
    } else {
        $target = strtolower(trim((string)($_POST['registration_email'] ?? '')));
        if (isset($_POST['approve_registration'])) {
            $result = dmd_account_approve($target, $email);
            if (!empty($result['ok'])) { $success = true; $message = 'Inscription de ' . $target . ' validée.'; }
            else $errors[] = (string)($result['error'] ?? 'Validation impossible.');
        } else {
            $result = dmd_account_refuse($target, $email);
            if (!empty($result['ok'])) { $success = true; $message = 'Inscription de ' . $target . ' refusée.'; }
            else $errors[] = (string)($result['error'] ?? 'Refus impossible.');
        }
    }
    $dmdPendingRegistrations = dmd_account_pending_registrations();
}
