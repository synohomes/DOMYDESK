<?php
// Compatibilité avec les anciens favoris / liens directs.
// Toute l'interface de liaison vit désormais dans adm/site_settings.php.
$target = './site_settings.php?open=popup-security-admin&section=domysocial';
header('Location: ' . $target, true, 302);
exit;
