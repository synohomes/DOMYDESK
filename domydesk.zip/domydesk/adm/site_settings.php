<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../login.php');
    exit;
}

$baseDir = dirname(__DIR__); 
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_media.php';
require_once $baseDir . '/core/dmd_ui_features.php';
require_once $baseDir . '/core/dmd_version.php';
require_once $baseDir . '/core/dmd_sources.php';
require_once $baseDir . '/core/dmd_mfa.php';
require_once $baseDir . '/core/dmd_domysocial_bridge.php';
require_once $baseDir . '/core/dmd_license.php';
$dmdTicketingLibFile = $baseDir . '/modules/dmd-ticketing/dmd-ticketing_lib.php';
$dmdTicketingAvailable = is_file($dmdTicketingLibFile);
if ($dmdTicketingAvailable) require_once $dmdTicketingLibFile;
$profilesDir = $baseDir . '/users/profiles/';
$profileFile = dmd_profile_path($email, true);

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);
if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$roleSystemReal = $profileData['role_system'] ?? 'user';

if (!in_array($roleSystemReal, ['admin', 'superadmin'], true)) {
    header('Location: ../profile_view.php');
    exit;
}

$isAdmin = true;
$isSuperadmin = ($roleSystemReal === 'superadmin');
$mfaDisablePendingCount = $isSuperadmin ? count(dmd_mfa_pending_disable_requests()) : 0;
$dmdVersion = dmd_version_read($baseDir);
$dmdVersionLabel = $dmdVersion === 'Inconnue' ? 'Version inconnue' : ('V.' . $dmdVersion);
$migrationReport = dmd_migrate_all_user_security_files();

if (empty($_SESSION['csrf_site_settings'])) {
    $_SESSION['csrf_site_settings'] = bin2hex(random_bytes(32));
}

$settingsFile = $baseDir . '/adm/settings.json';
$languagesDir = $baseDir . '/lang/';
$rolesFile = $baseDir . '/data/roles_metier.json';
$rolesModulesFile = $baseDir . '/data/secure/roles_modules.json';
$idFile = $baseDir . '/data/id_domydesk.txt';
$heartbeatFile = $baseDir . '/data/domyco_heartbeat.php';
$heartbeatLockFile = $baseDir . '/data/domyco_heartbeat.lock';
$heartbeatLastFile = $baseDir . '/data/domyco_heartbeat_last.json';
$themeMarketSourceError = '';
$themeMarketUrl = dmd_source_url($baseDir, 'themes', $themeMarketSourceError);
$themesDir = $baseDir . '/theme/';
$themeUploadDir = $baseDir . '/uploads/themes/';
@mkdir($themesDir, 0775, true);
@mkdir($themeUploadDir, 0775, true);

$success = false;
$errors = [];
$message = '';
$reopenPopup = '';
$requestedPopup = trim((string)($_GET['open'] ?? ''));
$allowedRequestedPopups = ['popup-site-settings','popup-core-interface','popup-site-maintenance','popup-security-admin','popup-index-settings','popup-theme-market','popup-unofficial-themes','popup-news','popup-market-inline','popup-unofficial-modules','popup-module-rights','popup-user-add','popup-user-roles','popup-registration','popup-page-rights','popup-metiers','popup-updates','popup-system-logs','popup-module-updates'];
if ($requestedPopup !== '' && in_array($requestedPopup, $allowedRequestedPopups, true)) {
    if (!in_array($requestedPopup, ['popup-updates','popup-system-logs','popup-module-updates','popup-security-admin'], true) || $isSuperadmin) {
        $reopenPopup = $requestedPopup;
    }
}
if ($isSuperadmin && (string)($_GET['mfa_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Politique MFA centrale enregistrée et relue avec succès.';
}
if ($isSuperadmin && (string)($_GET['dms_bridge_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Code d’appairage DoMySocial créé. Copiez-le maintenant : il ne sera affiché qu’une seule fois.';
}
if ($isSuperadmin && (string)($_GET['dms_bridge_revoked'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Liaison DoMySocial révoquée.';
}
if ($isSuperadmin && (string)($_GET['license_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Licence signée installée et vérifiée pour cette instance.';
}
if ($isSuperadmin && (string)($_GET['license_removed'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Licence signée retirée. Le mode de lancement s’applique à nouveau tant qu’il est disponible.';
}
if ($isSuperadmin && (string)($_GET['ticketing_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Configuration du récepteur DMD-Ticketing enregistrée.';
}
if ($isSuperadmin && (string)($_GET['ticketing_client_created'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Entreprise cliente créée. Le fichier de liaison peut maintenant être téléchargé.';
}
if ($isSuperadmin && (string)($_GET['ticketing_action_done'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Action DMD-Ticketing effectuée.';
}
$idDoMyDesk = is_file($idFile) ? trim((string)file_get_contents($idFile)) : '';

/* Centre de commande public SynoHomes. Une seule ligne à modifier si l'URL publique change. */
$dmdLicenseOrderUrl = 'https://synohomes.com/licences/commande.php';

function dmd_admin_license_state_label($state) {
    $map = array(
        'active' => 'Active',
        'grace' => 'Période de grâce',
        'expired' => 'Expirée',
        'not_yet_valid' => 'Pas encore active',
        'launch' => 'Licence de lancement',
        'license_required' => 'Licence requise',
        'invalid' => 'Invalide',
        'instance_mismatch' => 'Mauvaise instance',
        'crypto_unavailable' => 'Cryptographie indisponible',
    );
    return $map[(string)$state] ?? ((string)$state !== '' ? strtoupper((string)$state) : 'Inconnu');
}
function dmd_admin_license_quota($value, $suffix = '') {
    $value = (int)$value;
    if ($value < 0) return 'Illimité';
    return (string)$value . ($suffix !== '' ? ' ' . $suffix : '');
}


function dmd_admin_ticketing_base_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';

    if (!preg_match('~^https?://~i', $value)) {
        $value = 'https://' . $value;
    }

    $parts = @parse_url($value);
    if (!is_array($parts) || empty($parts['host'])) return '';

    $scheme = strtolower((string)($parts['scheme'] ?? 'https'));
    if (!in_array($scheme, ['http', 'https'], true)) $scheme = 'https';

    $path = (string)($parts['path'] ?? '/');
    $path = preg_replace('~/+~', '/', $path);

    $endpointSuffix = '/modules/dmd-ticketing/dmd-ticketing_external.php';
    if (str_ends_with(strtolower($path), strtolower($endpointSuffix))) {
        $path = substr($path, 0, -strlen($endpointSuffix));
    }

    $path = '/' . trim($path, '/');
    if ($path === '/') {
        $path = '/';
    } else {
        $path .= '/';
    }

    return $scheme . '://' . (string)$parts['host']
        . (!empty($parts['port']) ? ':' . (int)$parts['port'] : '')
        . $path;
}

function dmd_admin_ticketing_endpoint_from_base(string $value): string {
    $base = dmd_admin_ticketing_base_url($value);
    if ($base === '') return '';

    return rtrim($base, '/') . '/modules/dmd-ticketing/dmd-ticketing_external.php';
}

$theme = 'default';
if ($email) {
    $themeJson = $profilesDir . $email . '/theme.json';
    if (is_file($themeJson)) {
        $themeData = json_decode((string)file_get_contents($themeJson), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidateTheme = basename((string)$themeData['theme']);
            if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
                $theme = $candidateTheme;
            }
        }
    }
}
$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';
if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

function dmd_json_read(string $file, $default = []) {
    if (!is_file($file)) return $default;
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function dmd_json_write(string $file, array $data): bool {
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ok = file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) !== false;
    if ($ok) @chmod($file, 0664);
    return $ok;
}

function dmd_remove_dir(string $dir): bool {
    if (!is_dir($dir)) return false;
    $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
    $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($ri as $file) {
        if ($file->isDir()) {
            @chmod($file->getPathname(), 0775);
            @rmdir($file->getPathname());
        } else {
            @chmod($file->getPathname(), 0664);
            @unlink($file->getPathname());
        }
    }
    @chmod($dir, 0775);
    return @rmdir($dir);
}

function dmd_set_permissions(string $path): void {
    if (!file_exists($path)) return;
    if (is_dir($path)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $item) {
            $normalized = str_replace('\\', '/', $item->getPathname());
            $isPrivateProfile = strpos($normalized, '/profile/') !== false || substr($normalized, -8) === '/profile';
            @chmod($item->getPathname(), $item->isDir() ? ($isPrivateProfile ? 0750 : 0775) : ($isPrivateProfile ? 0640 : 0664));
        }
        @chmod($path, 0775);
    } else {
        @chmod($path, 0664);
    }
}
function dmd_horizontal_menu_emojis(): array {
    return [
        '🖥️','🌎','🔅','⭐','🏃','✅','❌','📜','🛠️','🎫',
        '🏠','👤','👥','⚙️','🔐','📁','📂','📝','📌','📊',
        '📈','📉','💬','📧','🔔','🔍','🧰','🗂️','🧾','💾',
        '🖨️','🌐','🔗','🚀','⚡','💡','❤️','🔒','🔓','🧪',
        '🧭','📡','🖱️','⌨️','📱','💻','🖧','🧱','🧩','📦',
        '🛒','🎨','🧑‍💻','🗃️','🕘','📣'
    ];
}

function dmd_default_horizontal_menu(): array {
    return [
        ['title' => 'Dashboard', 'icon' => '🖥️', 'url' => '/domydesk/dashboard.php', 'type' => 'page'],
        ['title' => 'DoMyDesk public', 'icon' => '🌎', 'url' => 'https://domydesk.com/', 'type' => 'external'],
        ['title' => 'Votre DoMySocial', 'icon' => '🔅', 'url' => '/domysocial/index.php', 'type' => 'page'],
        ['title' => 'Accueil', 'icon' => '⭐', 'url' => '/domydesk/index.php', 'type' => 'page'],
        ['title' => 'Profil', 'icon' => '🏃', 'url' => '/domydesk/profile_view.php', 'type' => 'page'],
        ['title' => 'Se connecter', 'icon' => '✅', 'url' => '/domydesk/login.php', 'type' => 'page'],
        ['title' => 'Déconnexion', 'icon' => '❌', 'url' => '/domydesk/logout.php', 'type' => 'page'],
        ['title' => 'Aide', 'icon' => '📜', 'url' => '/domydesk/data/procedures/procedures_list.php', 'type' => 'page'],
        ['title' => 'Administration', 'icon' => '🛠️', 'url' => '/domydesk/adm/site_settings.php', 'type' => 'page'],
    ];
}

function dmd_normalize_horizontal_url(string $url, string $type): string {
    $url = trim($url);
    if ($url === '') return '';
    if (strlen($url) > 255) return '';

    if ($type === 'external') {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return '';
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true) ? $url : '';
    }

    if (preg_match('~^https?://~i', $url)) return '';
    $url = str_replace('\\', '/', $url);
    if (str_contains($url, '..')) return '';
    if (str_starts_with($url, '//')) return '';
    if (!str_starts_with($url, '/')) {
        $url = '/domydesk/' . ltrim($url, '/');
    }
    return $url;
}

function dmd_normalize_horizontal_menu_from_post(array $post, array $allowedEmojis): array {
    $titles = $post['menu_title'] ?? [];
    $icons  = $post['menu_icon'] ?? [];
    $types  = $post['menu_type'] ?? [];
    $urls   = $post['menu_url'] ?? [];
    $delete = $post['menu_delete'] ?? [];

    if (!is_array($titles) || !is_array($icons) || !is_array($types) || !is_array($urls)) {
        return [];
    }

    $items = [];
    $count = min(count($titles), 30);

    for ($i = 0; $i < $count; $i++) {
        if (isset($delete[$i])) continue;

        $title = trim((string)($titles[$i] ?? ''));
        $icon  = trim((string)($icons[$i] ?? ''));
        $type  = ((string)($types[$i] ?? 'page')) === 'external' ? 'external' : 'page';
        $url   = dmd_normalize_horizontal_url((string)($urls[$i] ?? ''), $type);

        if ($title === '' && $url === '') continue;
        if ($title === '' || $url === '') continue;

        if (function_exists('mb_substr')) {
            $title = mb_substr($title, 0, 80, 'UTF-8');
        } else {
            $title = substr($title, 0, 80);
        }

        if (!in_array($icon, $allowedEmojis, true)) {
            $icon = '⭐';
        }

        $items[] = [
            'title' => $title,
            'icon'  => $icon,
            'url'   => $url,
            'type'  => $type,
        ];
    }

    return $items;
}

function dmd_horizontal_menu_to_html(array $items): string {
    $html = '';
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $title = trim((string)($item['title'] ?? ''));
        $icon  = trim((string)($item['icon'] ?? ''));
        $url   = trim((string)($item['url'] ?? ''));
        $type  = ((string)($item['type'] ?? 'page')) === 'external' ? 'external' : 'page';

        if ($title === '' || $icon === '' || $url === '') continue;

        $target = $type === 'external' ? ' target="_blank" rel="noopener noreferrer"' : '';
        $html .= '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="icon-link" title="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"' . $target . '>' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '</a>' . "
";
    }
    return $html;
}

function dmd_theme_github_to_raw(string $url): string {
    $url = trim($url);
    if ($url === '') return '';

    $url = preg_replace('~\?.*$~', '', $url);
    $url = preg_replace('~/refs/heads/([^/]+)/~', '/$1/', $url);

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    return $url;
}

function dmd_theme_slug(string $value): string {
    $value = basename($value);
    $value = preg_replace('~\.zip$~i', '', $value);
    $value = preg_replace('~[^a-zA-Z0-9._-]+~', '-', $value);
    return trim($value, '-');
}

function dmd_theme_folder_from_url(string $url, string $fallbackName): string {
    $path = parse_url($url, PHP_URL_PATH);
    $folder = $path ? dmd_theme_slug(pathinfo($path, PATHINFO_FILENAME)) : '';
    if ($folder === '') $folder = dmd_theme_slug($fallbackName);
    return $folder;
}

function dmd_theme_http_get(string $url, ?string &$why = null) {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 40,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ('cURL : ' . $err) : ('HTTP ' . $code);
            return false;
        }

        return $body;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-ThemeMarket/1.0\r\n",
            'timeout' => 40,
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        $why = 'file_get_contents impossible.';
        return false;
    }

    return $body;
}

function dmd_theme_http_download(string $url, string $dest, ?string &$why = null): bool {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $fp = @fopen($dest, 'wb');
        if (!$fp) {
            $why = 'Écriture du ZIP impossible.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 60,
        ]);
        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        fclose($fp);

        if (!$ok || $code < 200 || $code >= 300 || !filesize($dest)) {
            @unlink($dest);
            $why = 'HTTP ' . $code . ($err ? ' - ' . $err : '');
            return false;
        }

        @chmod($dest, 0664);
        return true;
    }

    $data = @file_get_contents($url);
    if ($data === false || $data === '') {
        $why = 'Téléchargement impossible ou fichier vide.';
        return false;
    }

    if (@file_put_contents($dest, $data) === false) {
        $why = 'Écriture du ZIP impossible.';
        return false;
    }

    @chmod($dest, 0664);
    return true;
}

function dmd_theme_safe_extract_zip(ZipArchive $zip, string $extractDir, array &$errors): bool {
    @mkdir($extractDir, 0775, true);
    $extractReal = realpath($extractDir);

    if ($extractReal === false) {
        $errors[] = 'Dossier temporaire du thème invalide.';
        return false;
    }

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === false || $name === '') continue;

        $name = str_replace('\\', '/', $name);

        if (
            str_starts_with($name, '/') ||
            preg_match('~(^|/)\.\.(/|$)~', $name) ||
            preg_match('~^[a-zA-Z]:/~', $name)
        ) {
            $errors[] = 'ZIP thème refusé : chemin dangereux détecté.';
            return false;
        }
    }

    if (!$zip->extractTo($extractDir)) {
        $errors[] = 'Extraction du thème impossible.';
        return false;
    }

    dmd_set_permissions($extractDir);
    return true;
}

function dmd_theme_normalize_extract(string $extractDir): bool {
    $extractDir = rtrim($extractDir, '/') . '/';
    if (is_file($extractDir . 'style.css')) return true;

    $children = array_values(array_filter(scandir($extractDir) ?: [], fn($x) => $x !== '.' && $x !== '..' && $x !== '__MACOSX'));
    $candidates = [];

    foreach ($children as $child) {
        $childPath = $extractDir . $child;
        if (is_dir($childPath) && is_file($childPath . '/style.css')) {
            $candidates[] = $childPath;
        }
    }

    if (count($candidates) !== 1) return false;

    $source = rtrim($candidates[0], '/') . '/';
    foreach (array_diff(scandir($source), ['.', '..']) as $item) {
        @rename($source . $item, $extractDir . $item);
    }
    @rmdir($source);

    return is_file($extractDir . 'style.css');
}

function dmd_theme_installed_list(string $themesDir): array {
    $items = [];
    foreach (glob(rtrim($themesDir, '/') . '/*', GLOB_ONLYDIR) ?: [] as $folder) {
        if (is_file($folder . '/style.css')) {
            $items[] = basename($folder);
        }
    }
    sort($items, SORT_NATURAL | SORT_FLAG_CASE);
    return $items;
}


function dmd_rights_notification_permission_labels($moduleId, $permissions, $definitions) {
    if (!is_array($permissions)) {
        $permissions = array();
    }

    if (in_array('*', $permissions, true)) {
        return array('Toutes les actions');
    }

    $moduleDefinitions = isset($definitions[$moduleId]) && is_array($definitions[$moduleId])
        ? $definitions[$moduleId]
        : array();
    $labels = array();

    foreach ($permissions as $permissionId) {
        $permissionId = trim((string)$permissionId);
        if ($permissionId === '') {
            continue;
        }
        $labels[] = isset($moduleDefinitions[$permissionId]['label']) && trim((string)$moduleDefinitions[$permissionId]['label']) !== ''
            ? (string)$moduleDefinitions[$permissionId]['label']
            : $permissionId;
    }

    $labels = array_values(array_unique($labels));
    sort($labels, SORT_NATURAL | SORT_FLAG_CASE);
    return $labels;
}

function dmd_user_module_rights_notification_changes($beforeAcl, $afterAcl, $modules, $definitions) {
    $beforeOverrides = isset($beforeAcl['overrides']) && is_array($beforeAcl['overrides']) ? $beforeAcl['overrides'] : array();
    $afterOverrides = isset($afterAcl['overrides']) && is_array($afterAcl['overrides']) ? $afterAcl['overrides'] : array();
    $moduleIds = array_values(array_unique(array_merge(array_keys($beforeOverrides), array_keys($afterOverrides))));
    sort($moduleIds, SORT_NATURAL | SORT_FLAG_CASE);
    $changes = array();

    foreach ($moduleIds as $moduleId) {
        $beforeRule = isset($beforeOverrides[$moduleId]) && is_array($beforeOverrides[$moduleId]) ? $beforeOverrides[$moduleId] : array();
        $afterRule = isset($afterOverrides[$moduleId]) && is_array($afterOverrides[$moduleId]) ? $afterOverrides[$moduleId] : array();
        $beforeState = strtolower(trim((string)($beforeRule['state'] ?? 'inherit')));
        $afterState = strtolower(trim((string)($afterRule['state'] ?? 'inherit')));
        if (!in_array($beforeState, array('inherit', 'allow', 'deny'), true)) $beforeState = 'inherit';
        if (!in_array($afterState, array('inherit', 'allow', 'deny'), true)) $afterState = 'inherit';

        $beforePermissions = $beforeState === 'allow' && isset($beforeRule['permissions']) && is_array($beforeRule['permissions'])
            ? array_values($beforeRule['permissions'])
            : array();
        $afterPermissions = $afterState === 'allow' && isset($afterRule['permissions']) && is_array($afterRule['permissions'])
            ? array_values($afterRule['permissions'])
            : array();
        sort($beforePermissions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($afterPermissions, SORT_NATURAL | SORT_FLAG_CASE);

        if ($beforeState === $afterState && $beforePermissions === $afterPermissions) {
            continue;
        }

        $changes[$moduleId] = array(
            'label' => isset($modules[$moduleId]['name']) ? (string)$modules[$moduleId]['name'] : $moduleId,
            'before' => $beforeState,
            'after' => $afterState,
            'permissions_before' => dmd_rights_notification_permission_labels($moduleId, $beforePermissions, $definitions),
            'permissions_after' => dmd_rights_notification_permission_labels($moduleId, $afterPermissions, $definitions),
        );
    }

    return $changes;
}

function dmd_role_module_rights_notification_changes($beforeRules, $afterRules, $modules, $definitions) {
    $beforeRules = is_array($beforeRules) ? $beforeRules : array();
    $afterRules = is_array($afterRules) ? $afterRules : array();
    $moduleIds = array_values(array_unique(array_merge(array_keys($beforeRules), array_keys($afterRules))));
    sort($moduleIds, SORT_NATURAL | SORT_FLAG_CASE);
    $changes = array();

    foreach ($moduleIds as $moduleId) {
        $beforeRule = isset($beforeRules[$moduleId]) && is_array($beforeRules[$moduleId]) ? $beforeRules[$moduleId] : array();
        $afterRule = isset($afterRules[$moduleId]) && is_array($afterRules[$moduleId]) ? $afterRules[$moduleId] : array();
        $beforeEnabled = !empty($beforeRule['enabled']);
        $afterEnabled = !empty($afterRule['enabled']);
        $beforePermissions = $beforeEnabled && isset($beforeRule['permissions']) && is_array($beforeRule['permissions']) ? array_values($beforeRule['permissions']) : array();
        $afterPermissions = $afterEnabled && isset($afterRule['permissions']) && is_array($afterRule['permissions']) ? array_values($afterRule['permissions']) : array();
        sort($beforePermissions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($afterPermissions, SORT_NATURAL | SORT_FLAG_CASE);

        if ($beforeEnabled === $afterEnabled && $beforePermissions === $afterPermissions) {
            continue;
        }

        $changes[$moduleId] = array(
            'label' => isset($modules[$moduleId]['name']) ? (string)$modules[$moduleId]['name'] : $moduleId,
            'before' => $beforeEnabled ? 'allow' : 'deny',
            'after' => $afterEnabled ? 'allow' : 'deny',
            'permissions_before' => dmd_rights_notification_permission_labels($moduleId, $beforePermissions, $definitions),
            'permissions_after' => dmd_rights_notification_permission_labels($moduleId, $afterPermissions, $definitions),
        );
    }

    return $changes;
}

$settings = dmd_ui_settings_with_defaults(dmd_json_read($settingsFile, []));

$availableLanguages = [];
if (is_dir($languagesDir)) {
    foreach (scandir($languagesDir) ?: [] as $languageFolder) {
        if ($languageFolder === '.' || $languageFolder === '..' || str_starts_with($languageFolder, '.')) {
            continue;
        }

        $languagePath = rtrim($languagesDir, "/\\") . '/' . $languageFolder;
        if (!is_dir($languagePath)) {
            continue;
        }

        // Le nom affiché et la valeur enregistrée correspondent directement
        // au nom réel du dossier présent dans /lang/.
        $availableLanguages[$languageFolder] = $languageFolder;
    }
}
uksort($availableLanguages, 'strnatcasecmp');

$currentLanguage = (string)($settings['language'] ?? '');
if ($currentLanguage === '' || !isset($availableLanguages[$currentLanguage])) {
    $currentLanguage = $availableLanguages ? (string)array_key_first($availableLanguages) : '';
}
$settings['language'] = $currentLanguage;
if (!array_key_exists('banner_path', $settings)) {
    $settings['banner_path'] = '';
}
if (!array_key_exists('vertical_menu_brand_mode', $settings)) {
    $settings['vertical_menu_brand_mode'] = 'none';
}
if (!array_key_exists('domyco_heartbeat_enabled', $settings)) {
    $settings['domyco_heartbeat_enabled'] = true;
}
$settings['domyco_heartbeat_interval'] = 300;
if (!isset($settings['registration_approval_mode']) || !in_array((string)$settings['registration_approval_mode'], ['automatic', 'approval'], true)) {
    $settings['registration_approval_mode'] = 'approval';
}
$metiers = dmd_roles_catalog();
require_once $baseDir . '/adm/directory/directory_actions.php';
$mfaPolicy = dmd_mfa_policy_read();
$rolesModulesData = dmd_read_roles_modules();
$permissionModules = dmd_installed_modules();
$modulePermissionDefinitions = [];
foreach ($permissionModules as $modulePermissionId => $modulePermissionInfo) {
    $modulePermissionDefinitions[$modulePermissionId] = dmd_module_permission_definitions($modulePermissionId);
}
$pageCatalog = dmd_page_catalog();
$pageRightsData = dmd_read_pages_access();
$alwaysPages = array_filter($pageCatalog, fn($pageInfo) => (($pageInfo['access'] ?? 'controlled') === 'always'));
$permissionPages = array_filter($pageCatalog, fn($pageInfo) => (($pageInfo['access'] ?? 'controlled') === 'controlled'));
$pagesScan = array_values(array_map(fn($pageInfo) => (string)($pageInfo['path'] ?? ''), $pageCatalog));
$pagesScan[] = 'adm/site_settings.php';
$pagesScan = array_values(array_unique(array_filter($pagesScan)));
sort($pagesScan, SORT_NATURAL | SORT_FLAG_CASE);

$dmdHorizontalMenuEmojis = dmd_horizontal_menu_emojis();
if (empty($settings['menu_horizontal']) || !is_array($settings['menu_horizontal'])) {
    $settings['menu_horizontal'] = dmd_default_horizontal_menu();
}
$settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);

$settingsBeforePost = $settings;
$themeMarketRawOverride = null;

$dmdDmsBridgeNewToken = '';
if ($isSuperadmin && isset($_SESSION['dmd_dms_bridge_new_token'])) {
    $dmdDmsBridgeNewToken = (string)$_SESSION['dmd_dms_bridge_new_token'];
    unset($_SESSION['dmd_dms_bridge_new_token']);
}
$dmdDmsBridgeCfg = $isSuperadmin ? dmd_domysocial_bridge_read() : array('tokens' => array());
$dmdDmsBridgeTokens = isset($dmdDmsBridgeCfg['tokens']) && is_array($dmdDmsBridgeCfg['tokens']) ? $dmdDmsBridgeCfg['tokens'] : array();

require_once $baseDir . '/core/dmd_account_approval.php';
$dmdPendingRegistrations = dmd_account_pending_registrations();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($isAdmin && isset($_POST['save_registration_settings'])) {
        $reopenPopup = 'popup-registration';
        $token = (string)($_POST['csrf_token'] ?? '');
        if (!hash_equals((string)($_SESSION['csrf_site_settings'] ?? ''), $token)) {
            $errors[] = 'Réglage des inscriptions : formulaire expiré ou invalide.';
        } else {
            $mode = (string)($_POST['registration_approval_mode'] ?? 'approval');
            if (!in_array($mode, ['automatic', 'approval'], true)) {
                $errors[] = 'Mode de validation des inscriptions invalide.';
            } else {
                $settings['registration_approval_mode'] = $mode;
                if (dmd_json_write($settingsFile, $settings)) {
                    $success = true;
                    $message = $mode === 'automatic'
                        ? 'Les nouvelles inscriptions sont maintenant activées automatiquement.'
                        : 'Les nouvelles inscriptions doivent maintenant être validées par un administrateur.';
                    dmd_system_log('registration_approval_mode_updated', 'adm/settings.json', 'success', $message, ['mode' => $mode, 'actor' => $email]);
                } else {
                    $errors[] = 'Impossible d’enregistrer le mode de validation des inscriptions.';
                }
            }
        }
    }

    if ($isAdmin && (isset($_POST['approve_registration']) || isset($_POST['refuse_registration']))) {
        $reopenPopup = 'popup-registration';
        $token = (string)($_POST['csrf_token'] ?? '');
        if (!hash_equals((string)($_SESSION['csrf_site_settings'] ?? ''), $token)) {
            $errors[] = 'Validation d’inscription : formulaire expiré ou invalide.';
        } else {
            $target = strtolower(trim((string)($_POST['registration_email'] ?? '')));
            $result = isset($_POST['approve_registration'])
                ? dmd_account_approve($target, $email)
                : dmd_account_refuse($target, $email);
            if (!empty($result['ok'])) {
                $success = true;
                $message = isset($_POST['approve_registration'])
                    ? 'Inscription de ' . $target . ' validée.'
                    : 'Inscription de ' . $target . ' refusée.';
            } else {
                $errors[] = (string)($result['error'] ?? 'Action impossible sur cette inscription.');
            }
        }
        $dmdPendingRegistrations = dmd_account_pending_registrations();
    }

    if ($isSuperadmin && $dmdTicketingAvailable && (
        isset($_POST['dmd_ticketing_support_save']) || isset($_POST['dmd_ticketing_support_key_regenerate']) ||
        isset($_POST['dmd_ticketing_client_create']) || isset($_POST['dmd_ticketing_client_revoke']) ||
        isset($_POST['dmd_ticketing_client_reactivate']) || isset($_POST['dmd_ticketing_client_token_regenerate']) ||
        isset($_POST['dmd_ticketing_client_download'])
    )) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'DMD-Ticketing : formulaire expiré ou invalide.';
        } else {
            try {
                $tkLicense = dmdtk_external_license_status();
                if (empty($tkLicense['enabled'])) throw new RuntimeException('Licence DMD-Ticketing Support requise pour administrer le récepteur.');
                $tkCfg = dmdtk_config();
                $tkReceive = isset($tkCfg['external_receive']) && is_array($tkCfg['external_receive']) ? $tkCfg['external_receive'] : array();

                if (isset($_POST['dmd_ticketing_support_save'])) {
                    $supportName = trim((string)($_POST['dmd_ticketing_support_name'] ?? ''));
                    $supportBaseUrl = trim((string)($_POST['dmd_ticketing_support_endpoint'] ?? ''));
                    $enabledRequested = !empty($_POST['dmd_ticketing_support_enabled']);
                    if ($supportName === '') throw new RuntimeException('Indiquez le nom de l’entreprise Support.');
                    if ($supportBaseUrl === '') throw new RuntimeException('Indiquez l’adresse publique de DoMyDesk.');
                    $endpoint = dmd_admin_ticketing_endpoint_from_base($supportBaseUrl);
                    if ($endpoint === '') throw new RuntimeException('Adresse publique DoMyDesk invalide.');
                    $globalKey = trim((string)($tkReceive['token'] ?? ''));
                    if ($globalKey === '') $globalKey = bin2hex(random_bytes(32));
                    $nextReceive = array('enabled'=>$enabledRequested,'name'=>$supportName,'endpoint'=>$endpoint,'token'=>$globalKey,'owner'=>$email);
                    $saved = dmdtk_save_config($tkCfg['categories'] ?? array(), $tkCfg['priorities'] ?? array(), $email, array('external_support'=>$tkCfg['external_support'] ?? array(),'external_receive'=>$nextReceive));
                    if ($saved === false) throw new RuntimeException('Impossible d’enregistrer la configuration du récepteur.');
                    dmdtk_log($email, 'receiver_configure', 'config', 'success', array('endpoint'=>$endpoint,'enabled'=>$enabledRequested));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_saved=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_support_key_regenerate'])) {
                    $tkReceive['token'] = bin2hex(random_bytes(32));
                    if (trim((string)($tkReceive['owner'] ?? '')) === '') $tkReceive['owner'] = $email;
                    $saved = dmdtk_save_config($tkCfg['categories'] ?? array(), $tkCfg['priorities'] ?? array(), $email, array('external_support'=>$tkCfg['external_support'] ?? array(),'external_receive'=>$tkReceive));
                    if ($saved === false) throw new RuntimeException('Impossible de régénérer la clé Support.');
                    dmdtk_log($email, 'receiver_key_regenerate', 'config', 'warning', array());
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_client_create'])) {
                    $clientName = trim((string)($_POST['dmd_ticketing_client_name'] ?? ''));
                    $clientInstance = trim((string)($_POST['dmd_ticketing_client_instance'] ?? ''));
                    $created = dmdtk_external_client_create($clientName, $clientInstance, $email);
                    if (empty($created['ok'])) {
                        $err = (string)($created['error'] ?? 'CLIENT_CREATE_FAILED');
                        if ($err === 'CLIENT_LIMIT_REACHED') throw new RuntimeException('Limite de la licence atteinte : ' . (int)($created['clients_max'] ?? 0) . ' entreprises clientes actives maximum.');
                        if ($err === 'CLIENT_ALREADY_EXISTS') throw new RuntimeException('Cette instance DoMyDesk est déjà enregistrée comme cliente.');
                        throw new RuntimeException('Création du client impossible : ' . $err);
                    }
                    dmdtk_log($email, 'external_client_create', $clientInstance, 'success', array('client_name'=>$clientName));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_client_created=1'); exit;
                }

                foreach (array('dmd_ticketing_client_revoke'=>'revoked','dmd_ticketing_client_reactivate'=>'active') as $field=>$status) {
                    if (isset($_POST[$field])) {
                        $clientInstance = trim((string)$_POST[$field]);
                        $result = dmdtk_external_client_set_status($clientInstance, $status, $email);
                        if (empty($result['ok'])) {
                            if (($result['error'] ?? '') === 'CLIENT_LIMIT_REACHED') throw new RuntimeException('Impossible de réactiver : quota de clients atteint.');
                            throw new RuntimeException('Impossible de modifier cette entreprise cliente.');
                        }
                        dmdtk_log($email, $status==='revoked'?'external_client_revoke':'external_client_reactivate', $clientInstance, 'success', array());
                        header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                    }
                }

                if (isset($_POST['dmd_ticketing_client_token_regenerate'])) {
                    $clientInstance = trim((string)$_POST['dmd_ticketing_client_token_regenerate']);
                    $result = dmdtk_external_client_regenerate_token($clientInstance, $email);
                    if (empty($result['ok'])) throw new RuntimeException('Impossible de régénérer le jeton de cette entreprise.');
                    dmdtk_log($email, 'external_client_token_regenerate', $clientInstance, 'warning', array());
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_client_download'])) {
                    $clientInstance = trim((string)$_POST['dmd_ticketing_client_download']);
                    $link = dmdtk_link_export_raw($clientInstance);
                    if (empty($link['ok'])) throw new RuntimeException('Impossible de générer le fichier de liaison : ' . (string)($link['error'] ?? 'erreur inconnue'));
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . str_replace('"','',(string)$link['filename']) . '"');
                    header('Cache-Control: no-store');
                    echo (string)$link['raw']; exit;
                }
            } catch (Throwable $e) {
                $errors[] = 'DMD-Ticketing : ' . $e->getMessage();
            }
        }
    }

    if ($isSuperadmin && (isset($_POST['install_dmd_license']) || isset($_POST['remove_dmd_license']))) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Licence refusée : formulaire expiré ou invalide.';
        } else {
            try {
                $licenseInstanceId = dmd_license_instance_id();
                if ($licenseInstanceId === '') throw new RuntimeException('ID DoMyDesk introuvable.');
                if (!dmd_license_init_storage()) throw new RuntimeException('Impossible d’initialiser var/licenses/.');
                $licenseEngineFile = dmd_license_file();

                if (isset($_POST['install_dmd_license'])) {
                    if (!isset($_FILES['license_file']) || !is_array($_FILES['license_file'])) throw new RuntimeException('Aucun fichier de licence reçu.');
                    $upload = $_FILES['license_file'];
                    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Erreur d’envoi du fichier .dmdlic (code ' . (int)($upload['error'] ?? -1) . ').');
                    if (($upload['size'] ?? 0) <= 0 || ($upload['size'] ?? 0) > 1024 * 1024) throw new RuntimeException('Taille du fichier de licence invalide.');
                    $uploadName = (string)($upload['name'] ?? '');
                    if (strtolower(pathinfo($uploadName, PATHINFO_EXTENSION)) !== 'dmdlic') throw new RuntimeException('Le fichier doit être un .dmdlic.');
                    $raw = @file_get_contents((string)$upload['tmp_name']);
                    if ($raw === false || trim($raw) === '') throw new RuntimeException('Impossible de lire le fichier envoyé.');

                    $incoming = dmd_license_verify_raw($raw, $licenseInstanceId);
                    if (empty($incoming['ok']) || empty($incoming['verified'])) {
                        throw new RuntimeException('Licence refusée : ' . (string)($incoming['error'] ?? 'signature ou instance invalide'));
                    }

                    if (is_file($licenseEngineFile)) {
                        $backup = dirname($licenseEngineFile) . '/previous-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.dmdlic';
                        if (!@copy($licenseEngineFile, $backup)) throw new RuntimeException('Impossible de sauvegarder la licence actuelle avant remplacement.');
                        @chmod($backup, 0640);
                    }

                    $install = dmd_license_install_raw($raw);
                    if (empty($install['ok'])) throw new RuntimeException('Installation impossible : ' . (string)($install['error'] ?? 'erreur inconnue'));
                    if (!is_file($licenseEngineFile)) throw new RuntimeException('Le moteur n’a pas créé var/licenses/current.dmdlic.');

                    $writtenRaw = (string)@file_get_contents($licenseEngineFile);
                    $written = dmd_license_verify_raw($writtenRaw, $licenseInstanceId);
                    if (empty($written['ok']) || empty($written['verified'])) throw new RuntimeException('La licence écrite dans var/licenses est invalide.');
                    if ((string)($written['license_id'] ?? '') !== (string)($incoming['license_id'] ?? '')) throw new RuntimeException('Contrôle après écriture : license_id différent.');

                    $legacyFile = $baseDir . '/data/.dmd-license/current.dmdlic';
                    if (is_file($legacyFile)) {
                        $legacyArchive = dirname($legacyFile) . '/OBSOLETE-current-' . gmdate('Ymd-His') . '.dmdlic';
                        @rename($legacyFile, $legacyArchive);
                        @chmod($legacyArchive, 0640);
                    }

                    dmd_system_log('license_installed', (string)($written['license_id'] ?? 'licence'), 'success', 'Licence signée installée depuis Sécurité & administration.', array(
                        'updated_by' => $email,
                        'instance_id' => $licenseInstanceId,
                        'revision' => (int)($written['revision'] ?? 0),
                    ));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&license_saved=1');
                    exit;
                }

                if (isset($_POST['remove_dmd_license'])) {
                    if (is_file($licenseEngineFile)) {
                        $backup = dirname($licenseEngineFile) . '/removed-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.dmdlic';
                        if (!@copy($licenseEngineFile, $backup)) throw new RuntimeException('Impossible de sauvegarder la licence avant retrait.');
                        @chmod($backup, 0640);
                        if (!@unlink($licenseEngineFile)) throw new RuntimeException('Impossible de retirer var/licenses/current.dmdlic.');
                    }
                    dmd_system_log('license_removed', $licenseInstanceId, 'warning', 'Licence signée retirée depuis Sécurité & administration.', array('updated_by' => $email));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&license_removed=1');
                    exit;
                }
            } catch (Throwable $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
    if ($isSuperadmin && (isset($_POST['generate_dms_bridge']) || isset($_POST['revoke_dms_bridge']))) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Liaison DoMySocial refusée : formulaire expiré ou invalide.';
        } elseif (isset($_POST['generate_dms_bridge'])) {
            $label = trim((string)($_POST['dms_bridge_label'] ?? 'DoMySocial'));
            if ($label === '') $label = 'DoMySocial';
            if (function_exists('mb_substr')) $label = mb_substr($label, 0, 120, 'UTF-8');
            else $label = substr($label, 0, 120);
            $generated = dmd_domysocial_bridge_generate_token($label);
            if ($generated === false) {
                $errors[] = 'Impossible de générer le code d’appairage DoMySocial.';
            } else {
                $_SESSION['dmd_dms_bridge_new_token'] = (string)($generated['token'] ?? '');
                dmd_system_log('domysocial_bridge_created', 'DoMySocial', 'warning', 'Nouvel appairage DoMySocial créé.', array(
                    'updated_by' => $email,
                    'label' => $label,
                    'bridge_id' => (string)($generated['id'] ?? ''),
                ));
                header('Location: site_settings.php?open=popup-security-admin&section=domysocial&dms_bridge_saved=1');
                exit;
            }
        } elseif (isset($_POST['revoke_dms_bridge'])) {
            $bridgeId=trim((string)($_POST['dms_bridge_id'] ?? ''));
            $revokedRow=null;
            foreach ($dmdDmsBridgeTokens as $row) {
                if (is_array($row) && hash_equals((string)($row['id'] ?? ''),$bridgeId)) { $revokedRow=$row; break; }
            }
            if ($bridgeId!=='' && dmd_domysocial_bridge_revoke_token($bridgeId)) {
                dmd_system_log('domysocial_bridge_revoked', 'DoMySocial', 'warning', 'Liaison DoMySocial révoquée.', array(
                    'updated_by' => $email,
                    'bridge_id' => $bridgeId,
                    'domysocial_uid' => (string)($revokedRow['dms_instance_uid'] ?? ''),
                    'label' => (string)($revokedRow['label'] ?? 'DoMySocial'),
                ));
                header('Location: site_settings.php?open=popup-security-admin&section=domysocial&dms_bridge_revoked=1');
                exit;
            }
            $errors[] = 'Impossible de révoquer cette liaison DoMySocial.';
        }
        $dmdDmsBridgeCfg = dmd_domysocial_bridge_read();
        $dmdDmsBridgeTokens = isset($dmdDmsBridgeCfg['tokens']) && is_array($dmdDmsBridgeCfg['tokens']) ? $dmdDmsBridgeCfg['tokens'] : array();
    }

    if ($isSuperadmin && isset($_POST['save_mfa_policy'])) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        $password = (string)($_POST['mfa_admin_password'] ?? '');
        $adminCode = trim((string)($_POST['mfa_admin_code'] ?? ''));
        $hash = (string)($profileData['motdepasse'] ?? ($profileData['password'] ?? ''));

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Politique MFA refusée : formulaire expiré ou invalide.';
        } elseif ($hash === '' || !password_verify($password, $hash)) {
            $errors[] = 'Politique MFA refusée : mot de passe Superadmin incorrect.';
        } else {
            $adminMfaOk = true;
            if (dmd_mfa_enabled($email)) {
                $usedRecovery = false;
                $adminMfaOk = dmd_mfa_verify_user_code($email, $adminCode, $usedRecovery);
                if (!$adminMfaOk) $errors[] = 'Politique MFA refusée : code MFA Superadmin incorrect.';
            }

            if ($adminMfaOk) {
                $newPolicy = array(
                    'global' => dmd_mfa_policy_normalize_state($_POST['mfa_global_policy'] ?? 'optional', false),
                    'roles' => array(),
                    'users' => array(),
                );

                $rolePolicies = isset($_POST['mfa_role_policy']) && is_array($_POST['mfa_role_policy']) ? $_POST['mfa_role_policy'] : array();
                foreach ($metiers as $roleName) {
                    $state = dmd_mfa_policy_normalize_state($rolePolicies[$roleName] ?? 'inherit', true);
                    if ($state !== 'inherit') $newPolicy['roles'][$roleName] = $state;
                }

                $userPolicies = isset($_POST['mfa_user_policy']) && is_array($_POST['mfa_user_policy']) ? $_POST['mfa_user_policy'] : array();
                foreach ($userPolicies as $userMailRaw => $stateRaw) {
                    $userMail = dmd_safe_user_key((string)$userMailRaw);
                    if ($userMail === '' || !is_file(dmd_profile_path($userMail, false))) continue;
                    $state = dmd_mfa_policy_normalize_state($stateRaw, true);
                    if ($state !== 'inherit') $newPolicy['users'][$userMail] = $state;
                }

                $beforePolicy = dmd_mfa_policy_read();
                if (dmd_mfa_policy_write($newPolicy, $email)) {
                    $mfaPolicy = dmd_mfa_policy_read();

                    $expectedRoles = $newPolicy['roles'];
                    $expectedUsers = $newPolicy['users'];
                    $savedRoles = isset($mfaPolicy['roles']) && is_array($mfaPolicy['roles']) ? $mfaPolicy['roles'] : array();
                    $savedUsers = isset($mfaPolicy['users']) && is_array($mfaPolicy['users']) ? $mfaPolicy['users'] : array();
                    ksort($expectedRoles, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($expectedUsers, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($savedRoles, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($savedUsers, SORT_NATURAL | SORT_FLAG_CASE);

                    $savedExactly = (($mfaPolicy['global'] ?? 'optional') === $newPolicy['global'])
                        && ($savedRoles === $expectedRoles)
                        && ($savedUsers === $expectedUsers);

                    if (!$savedExactly) {
                        $errors[] = 'Échec de sécurité : la politique MFA écrite ne correspond pas à la politique relue.';
                    } else {
                        $success = true;
                        $message = 'Politique MFA centrale enregistrée.';
                        dmd_system_log('mfa_policy_updated', 'MFA', 'warning', $message, array(
                            'updated_by' => $email,
                            'before' => $beforePolicy,
                            'after' => $mfaPolicy,
                            'storage' => dmd_mfa_policy_path(),
                        ));

                        if (dmd_mfa_enabled($email)) {
                            $_SESSION['dmd_mfa_authenticated_at'] = time();
                        }

                        $effectiveForAdmin = dmd_mfa_effective_policy($email, $profileData);
                        if ($effectiveForAdmin === 'required' && !dmd_mfa_enabled($email)) {
                            header('Location: ../mfa_setup.php?required=1&policy_saved=1');
                            exit;
                        }

                        header('Location: site_settings.php?open=popup-security-admin&mfa_saved=1');
                        exit;
                    }
                } else {
                    $errors[] = 'Impossible d’enregistrer la politique MFA centrale. Vérifiez les droits d’écriture de var/security ou data/secure/mfa.';
                }
            }
        }
    }

    if ($isAdmin && isset($_POST['refresh_theme_catalog'])) {
        $reopenPopup = 'popup-theme-market';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Rafraîchissement des thèmes refusé : formulaire expiré ou invalide.';
        } else {
            $refreshError = '';
            $refreshOk = false;
            $themeMarketRawOverride = dmd_source_load_raw($baseDir, 'themes', true, $refreshError, $refreshOk);
            if ($refreshOk) {
                $success = true;
                $message = 'Catalogue des thèmes rafraîchi directement depuis GitHub.';
            } else {
                $errors[] = 'Rafraîchissement GitHub impossible' . ($refreshError !== '' ? ' : ' . $refreshError : '.') . ' Le dernier cache valide est conservé.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_core_interface'])) {
        $reopenPopup = 'popup-core-interface';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des outils Core expiré ou invalide.';
        } else {
            $beforeCoreTools = $settings['core_tools'];
            $beforeDashboardLimit = (int)($settings['dashboard_limit'] ?? 0);

            $settings['core_tools']['actionhub'] = array(
                'enabled' => isset($_POST['actionhub_enabled']),
                'default_location' => dmd_ui_normalize_location($_POST['actionhub_default_location'] ?? 'header', 'header'),
                'icon' => dmd_ui_normalize_icon($_POST['actionhub_icon'] ?? '⚡', '⚡'),
            );
            $settings['core_tools']['quick_session'] = array(
                'enabled' => isset($_POST['quick_session_enabled']),
                'default_location' => dmd_ui_normalize_location($_POST['quick_session_default_location'] ?? 'header', 'header'),
                'icon' => dmd_ui_normalize_icon($_POST['quick_session_icon'] ?? '🚨', '🚨'),
            );
            $settings['dashboard_limit'] = max(0, (int)($_POST['dashboard_limit'] ?? 0));

            if (dmd_json_write($settingsFile, $settings)) {
                $success = true;
                $message = 'Outils Core et limite des dashboards enregistrés.';
                dmd_system_log('core_interface_settings_updated', 'adm/settings.json', 'success', $message, array(
                    'core_tools_before' => $beforeCoreTools,
                    'core_tools_after' => $settings['core_tools'],
                    'dashboard_limit_before' => $beforeDashboardLimit,
                    'dashboard_limit_after' => $settings['dashboard_limit'],
                ));
            } else {
                $errors[] = 'Impossible d’enregistrer les réglages des outils Core.';
            }
        }
    }

    if (isset($_POST['save_site'])) {
        $reopenPopup = 'popup-site-settings';
        $settings['site_name'] = trim((string)($_POST['site_name'] ?? ($settings['site_name'] ?? 'DoMyDesk')));
        if ($settings['site_name'] === '') {
            $settings['site_name'] = 'DoMyDesk';
        }

        $requestedLanguage = trim((string)($_POST['site_language'] ?? ($settings['language'] ?? '')));
        if ($requestedLanguage !== '' && isset($availableLanguages[$requestedLanguage])) {
            $settings['language'] = $requestedLanguage;
        }

        $menuHorizontal = dmd_normalize_horizontal_menu_from_post($_POST, $dmdHorizontalMenuEmojis);
        if ($menuHorizontal) {
            $settings['menu_horizontal'] = $menuHorizontal;
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($menuHorizontal);
        } elseif (!empty($settings['menu_horizontal']) && is_array($settings['menu_horizontal'])) {
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        } else {
            $settings['menu_horizontal'] = dmd_default_horizontal_menu();
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        }

        $siteUploadDir = $baseDir . '/adm/uploads/';
        if (!is_dir($siteUploadDir)) @mkdir($siteUploadDir, 0775, true);

        if (!empty($_POST['remove_site_logo'])) {
            dmd_media_remove_named($siteUploadDir, 'logo');
            $settings['logo_path'] = '';
        }

        if (!empty($_POST['remove_site_banner'])) {
            dmd_media_remove_named($siteUploadDir, 'banner');
            $settings['banner_path'] = '';
        }

        if (!empty($_FILES['logo']) && ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $storedLogo = dmd_media_store_upload($_FILES['logo'], $siteUploadDir, 'logo', true);
            if (!empty($storedLogo['success'])) {
                $settings['logo_path'] = 'uploads/' . basename((string)$storedLogo['file']);
            } else {
                $errors[] = (string)($storedLogo['error'] ?? "Impossible d'envoyer l'avatar/logo du site.");
            }
        }

        if (!empty($_FILES['site_banner']) && ($_FILES['site_banner']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $storedBanner = dmd_media_store_upload($_FILES['site_banner'], $siteUploadDir, 'banner', true);
            if (!empty($storedBanner['success'])) {
                $settings['banner_path'] = 'uploads/' . basename((string)$storedBanner['file']);
            } else {
                $errors[] = (string)($storedBanner['error'] ?? "Impossible d'envoyer la bannière du site.");
            }
        }

        $brandMode = trim((string)($_POST['vertical_menu_brand_mode'] ?? 'none'));
        if (!in_array($brandMode, array('none', 'avatar', 'banner'), true)) {
            $brandMode = 'none';
        }
        $hasSiteAvatar = dmd_site_asset_file($settings, 'logo_path') !== '';
        $hasSiteBanner = dmd_site_asset_file($settings, 'banner_path') !== '';
        if (($brandMode === 'avatar' && !$hasSiteAvatar) || ($brandMode === 'banner' && !$hasSiteBanner)) {
            $brandMode = 'none';
        }
        $settings['vertical_menu_brand_mode'] = $brandMode;

        if (!$errors && dmd_json_write($settingsFile, $settings)) {
            $success = true;
            $message = 'Paramètres du site enregistrés.';
            $changes = [];
            if (($settingsBeforePost['site_name'] ?? '') !== ($settings['site_name'] ?? '')) {
                $changes['site_name'] = ['avant' => $settingsBeforePost['site_name'] ?? '', 'apres' => $settings['site_name'] ?? ''];
            }
            if (($settingsBeforePost['language'] ?? '') !== ($settings['language'] ?? '')) {
                $changes['language'] = ['avant' => $settingsBeforePost['language'] ?? '', 'apres' => $settings['language'] ?? ''];
            }
            if (($settingsBeforePost['menu_horizontal'] ?? []) !== ($settings['menu_horizontal'] ?? [])) {
                $changes['menu_horizontal'] = ['avant_count' => count($settingsBeforePost['menu_horizontal'] ?? []), 'apres_count' => count($settings['menu_horizontal'] ?? [])];
            }
            if (($settingsBeforePost['logo_path'] ?? '') !== ($settings['logo_path'] ?? '')) {
                $changes['logo_path'] = ['avant' => $settingsBeforePost['logo_path'] ?? '', 'apres' => $settings['logo_path'] ?? ''];
            }
            if (($settingsBeforePost['banner_path'] ?? '') !== ($settings['banner_path'] ?? '')) {
                $changes['banner_path'] = ['avant' => $settingsBeforePost['banner_path'] ?? '', 'apres' => $settings['banner_path'] ?? ''];
            }
            if (($settingsBeforePost['vertical_menu_brand_mode'] ?? 'none') !== ($settings['vertical_menu_brand_mode'] ?? 'none')) {
                $changes['vertical_menu_brand_mode'] = ['avant' => $settingsBeforePost['vertical_menu_brand_mode'] ?? 'none', 'apres' => $settings['vertical_menu_brand_mode'] ?? 'none'];
            }
            dmd_system_log('site_settings_updated', 'adm/settings.json', 'success', 'Paramètres du site enregistrés.', $changes);
        }
    }

    if ($isAdmin && isset($_POST['save_domyco_heartbeat'])) {
        $reopenPopup = 'popup-site-maintenance';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire DomyCo expiré ou invalide.';
        } else {
            $settings['domyco_heartbeat_enabled'] = isset($_POST['domyco_heartbeat_enabled']);
            $settings['domyco_heartbeat_interval'] = 300;

            if (dmd_json_write($settingsFile, $settings)) {
                $success = true;
                $message = !empty($settings['domyco_heartbeat_enabled'])
                    ? 'Synchronisation DomyCo activée : un heartbeat toutes les 5 minutes.'
                    : 'Synchronisation DomyCo désactivée.';
                dmd_system_log('domyco_heartbeat_setting', 'DomyCo', 'success', $message, ['enabled' => !empty($settings['domyco_heartbeat_enabled'])]);
            } else {
                $errors[] = 'Impossible d’enregistrer le réglage DomyCo.';
            }
        }
    }

    if ($isAdmin && isset($_POST['send_domyco_heartbeat_now'])) {
        $reopenPopup = 'popup-site-maintenance';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire DomyCo expiré ou invalide.';
        } elseif (!is_file($heartbeatFile)) {
            $errors[] = 'Fichier data/domyco_heartbeat.php introuvable.';
        } else {
            require_once $heartbeatFile;

            if (!function_exists('dmd_hb_run')) {
                $errors[] = 'Moteur heartbeat DomyCo indisponible.';
            } else {
                $heartbeatManualResult = dmd_hb_run(true, $baseDir);

                if (!empty($heartbeatManualResult['success'])) {
                    $success = true;
                    $message = 'Synchronisation DomyCo envoyée manuellement.';
                    dmd_system_log('domyco_heartbeat_manual', 'DomyCo', 'success', $message);
                } else {
                    $errors[] = 'Échec de la synchronisation DomyCo : '
                        . (($heartbeatManualResult['curl_error'] ?? '') ?: ($heartbeatManualResult['error'] ?? 'erreur inconnue'));
                }
            }
        }
    }

    if ($isAdmin && isset($_POST['install_theme_market'])) {
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire thème expiré ou invalide.';
        } else {
            $themeName = trim((string)($_POST['theme_name'] ?? ''));
            $themeDl = dmd_theme_github_to_raw(trim((string)($_POST['theme_dl'] ?? '')));
            $themeFolder = dmd_theme_folder_from_url($themeDl, $themeName);

            if ($themeDl === '' || $themeFolder === '') {
                $errors[] = 'Thème invalide.';
            } elseif (!class_exists('ZipArchive')) {
                $errors[] = 'ZipArchive n’est pas disponible sur le serveur.';
            } else {
                $zipTmp = rtrim($themeUploadDir, '/') . '/' . $themeFolder . '.zip';
                $tmpExtract = rtrim($themeUploadDir, '/') . '/extract_' . $themeFolder . '_' . time() . '/';
                $targetThemeDir = rtrim($themesDir, '/') . '/' . $themeFolder . '/';
                $why = '';

                if (!dmd_theme_http_download($themeDl, $zipTmp, $why)) {
                    $errors[] = 'Téléchargement du thème impossible : ' . $why;
                } else {
                    $zip = new ZipArchive();
                    if ($zip->open($zipTmp) === true) {
                        if (dmd_theme_safe_extract_zip($zip, $tmpExtract, $errors) && dmd_theme_normalize_extract($tmpExtract)) {
                            $zip->close();
                            @unlink($zipTmp);

                            if (is_dir($targetThemeDir)) dmd_remove_dir($targetThemeDir);

                            if (@rename($tmpExtract, $targetThemeDir)) {
                                dmd_set_permissions($targetThemeDir);
                                $success = true;
                                $message = 'Thème installé : ' . $themeFolder;
                                dmd_system_log('theme_installed', $themeFolder, 'success', $message);
                            } else {
                                $errors[] = 'Impossible de placer le thème dans le dossier /theme/.';
                                dmd_remove_dir($tmpExtract);
                            }
                        } else {
                            $zip->close();
                            @unlink($zipTmp);
                            dmd_remove_dir($tmpExtract);
                            if (!$errors) $errors[] = 'Le ZIP du thème ne contient pas de style.css utilisable.';
                        }
                    } else {
                        @unlink($zipTmp);
                        $errors[] = 'Impossible d’ouvrir le ZIP du thème.';
                    }
                }
            }
        }
    }

    if ($isAdmin && isset($_POST['delete_module'])) {
        $mod = basename((string)$_POST['delete_module']);
        $notificationIndexBeforeDelete = dmd_notification_index();
        $affectedModuleUsers = isset($notificationIndexBeforeDelete['modules'][$mod]) && is_array($notificationIndexBeforeDelete['modules'][$mod])
            ? $notificationIndexBeforeDelete['modules'][$mod]
            : [];
        if (!$isSuperadmin) {
            $errors[] = 'La suppression d’un module est réservée au Superadmin.';
            dmd_system_log('module_delete_denied', $mod, 'denied', 'Tentative de suppression de module avec un compte Admin.');
        } elseif ($mod !== '' && dmd_remove_dir($baseDir . '/modules/' . $mod)) {
            $success = true;
            $message = 'Module supprimé.';
            dmd_system_log('module_deleted', $mod, 'success', $message);
            dmd_notify_many($affectedModuleUsers, 'module_removed', 'Un module que vous utilisiez a été supprimé', 'Le module ' . $mod . ' a été supprimé de cette instance DoMyDesk par un Superadmin.', ['level' => 'warning']);
            dmd_notification_build_index();
        } else {
            $errors[] = 'Impossible de supprimer ce module.';
            dmd_system_log('module_delete_failed', $mod, 'error', 'Impossible de supprimer le module.');
        }
    }

    if ($isAdmin && isset($_POST['add_metier'])) {
        $new = trim($_POST['new_metier'] ?? '');
        if ($new !== '' && !in_array($new, $metiers, true)) {
            $metiers[] = $new;
            sort($metiers, SORT_NATURAL | SORT_FLAG_CASE);
            dmd_json_write($rolesFile, array_values($metiers));
            $metiers = dmd_roles_catalog();
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle ajouté.';
            dmd_system_log('business_role_added', $new, 'success', $message);
        }
    }

    if ($isAdmin && isset($_POST['delete_metier'])) {
        $del = trim($_POST['del_metier'] ?? '');
        if ($del !== '') {
            $metiers = array_values(array_filter($metiers, fn($m) => $m !== $del));
            dmd_json_write($rolesFile, $metiers);
            $metiers = dmd_roles_catalog();
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle supprimé.';
            dmd_system_log('business_role_deleted', $del, 'success', $message);
        }
    }

    if ($isAdmin && isset($_POST['save_module_access_modes'])) {
        $moduleAccessModes = isset($_POST['module_access_mode']) && is_array($_POST['module_access_mode'])
            ? $_POST['module_access_mode']
            : [];

        if (dmd_set_module_access_modes($moduleAccessModes)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Modes d’accès des modules enregistrés.';
            dmd_system_log('module_access_modes_updated', 'modules', 'success', $message);
        } else {
            $errors[] = 'Impossible d’enregistrer les modes d’accès des modules.';
        }
    }

    if ($isAdmin && isset($_POST['save_role_modules'])) {
        $roleAccess = trim((string)($_POST['access_role'] ?? ''));
        $roleModules = isset($_POST['role_modules']) && is_array($_POST['role_modules'])
            ? $_POST['role_modules']
            : [];

        if (!in_array($roleAccess, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (dmd_set_role_modules($roleAccess, $roleModules)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Modules du rôle enregistrés.';
            dmd_system_log('role_modules_updated', $roleAccess, 'success', $message, ['modules' => array_values($roleModules)]);
            dmd_notify_metier($roleAccess, 'permissions_changed', 'Vos accès modules ont changé', 'Les modules autorisés pour votre rôle métier ont été modifiés.', ['level' => 'warning', 'action_url' => 'profile_edit.php', 'action_label' => 'Voir mon profil']);
        } else {
            $errors[] = 'Impossible d’enregistrer les modules du rôle.';
        }
    }

    if ($isAdmin && isset($_POST['save_global_module_rights'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $globalModules = isset($_POST['global_modules']) && is_array($_POST['global_modules'])
            ? array_values(array_map('strval', $_POST['global_modules']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } else {
            $moduleAccessModes = [];
            foreach ($permissionModules as $moduleId => $moduleInfo) {
                $moduleAccessModes[$moduleId] = in_array($moduleId, $globalModules, true) ? 'everyone' : 'controlled';
            }

            if (dmd_set_module_access_modes($moduleAccessModes)) {
                $rolesModulesData = dmd_read_roles_modules();
                $success = true;
                $message = 'Modules accessibles à tout le monde enregistrés.';
                dmd_system_log('global_module_rights_updated', 'modules', 'success', $message, ['global_modules' => $globalModules]);
                dmd_notify_all('permissions_changed', 'Accès aux modules modifiés', 'Les règles globales d’accès aux modules DoMyDesk ont été mises à jour.', ['level' => 'warning', 'action_url' => 'profile_edit.php', 'action_label' => 'Voir mes modules']);
            } else {
                $errors[] = 'Impossible d’enregistrer les droits globaux.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_role_module_rights'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsRole = trim((string)($_POST['rights_role'] ?? ''));
        $roleModules = isset($_POST['role_modules']) && is_array($_POST['role_modules'])
            ? array_values(array_map('strval', $_POST['role_modules']))
            : [];
        $roleAllModules = isset($_POST['role_all_modules']) && is_array($_POST['role_all_modules'])
            ? array_values(array_map('strval', $_POST['role_all_modules']))
            : [];
        $rolePermissionTokens = isset($_POST['role_permission_tokens']) && is_array($_POST['role_permission_tokens'])
            ? array_values(array_map('strval', $_POST['role_permission_tokens']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } elseif (!in_array($rightsRole, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } else {
            $permissionMap = [];
            foreach ($rolePermissionTokens as $tokenValue) {
                $parts = explode('|', $tokenValue, 2);
                if (count($parts) !== 2) {
                    continue;
                }
                $moduleId = trim((string)$parts[0]);
                $permissionId = trim((string)$parts[1]);
                if ($moduleId === '' || $permissionId === '') {
                    continue;
                }
                if (!isset($permissionMap[$moduleId])) {
                    $permissionMap[$moduleId] = [];
                }
                $permissionMap[$moduleId][] = $permissionId;
            }

            $rules = [];
            foreach ($roleModules as $moduleId) {
                $moduleId = trim((string)$moduleId);
                if ($moduleId === '' || !isset($permissionModules[$moduleId])) {
                    continue;
                }

                $definitions = $modulePermissionDefinitions[$moduleId] ?? [];
                if (empty($definitions) || in_array($moduleId, $roleAllModules, true)) {
                    $permissions = ['*'];
                } else {
                    $permissions = $permissionMap[$moduleId] ?? [];
                }

                $rules[$moduleId] = [
                    'enabled' => true,
                    'permissions' => $permissions,
                ];
            }

            $roleRulesBefore = isset($rolesModulesData['roles'][$rightsRole]['modules']) && is_array($rolesModulesData['roles'][$rightsRole]['modules'])
                ? $rolesModulesData['roles'][$rightsRole]['modules']
                : array();

            if (dmd_set_role_module_rules($rightsRole, $rules)) {
                $rolesModulesData = dmd_read_roles_modules();
                $roleRulesAfter = isset($rolesModulesData['roles'][$rightsRole]['modules']) && is_array($rolesModulesData['roles'][$rightsRole]['modules'])
                    ? $rolesModulesData['roles'][$rightsRole]['modules']
                    : array();
                $roleRightsChanges = dmd_role_module_rights_notification_changes($roleRulesBefore, $roleRulesAfter, $permissionModules, $modulePermissionDefinitions);
                $success = true;
                $message = 'Droits fins du rôle ' . $rightsRole . ' enregistrés.';
                dmd_system_log('role_module_permissions_updated', $rightsRole, 'success', $message, ['rules' => $rules, 'changes' => $roleRightsChanges]);
                if ($roleRightsChanges) {
                    dmd_notify_metier(
                        $rightsRole,
                        'permissions_changed',
                        'Vos droits sur les modules ont changé',
                        count($roleRightsChanges) . ' module(s) ont été modifié(s) pour votre rôle métier.',
                        [
                            'level' => 'warning',
                            'action_url' => 'profile_edit.php',
                            'action_label' => 'Voir mes accès',
                            'meta' => [
                                'scope' => 'modules',
                                'role_metier' => $rightsRole,
                                'changes' => $roleRightsChanges,
                            ],
                        ]
                    );
                }
            } else {
                $errors[] = 'Impossible d’enregistrer les droits de ce rôle.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_user_module_exceptions'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsUser = trim((string)($_POST['rights_user'] ?? ''));
        $overrideStateTokens = isset($_POST['user_override_state']) && is_array($_POST['user_override_state'])
            ? array_values(array_map('strval', $_POST['user_override_state']))
            : [];
        $userAllModules = isset($_POST['user_all_modules']) && is_array($_POST['user_all_modules'])
            ? array_values(array_map('strval', $_POST['user_all_modules']))
            : [];
        $userPermissionTokens = isset($_POST['user_permission_tokens']) && is_array($_POST['user_permission_tokens'])
            ? array_values(array_map('strval', $_POST['user_permission_tokens']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } elseif ($rightsUser === '' || !is_dir($profilesDir . $rightsUser)) {
            $errors[] = 'Utilisateur invalide.';
        } else {
            $rightsUserProfile = dmd_read_profile($rightsUser);
            if (dmd_is_system_admin_profile($rightsUserProfile)) {
                $success = true;
                $message = 'Un administrateur possède déjà tous les droits sur les modules.';
            } else {
                $stateMap = [];
                foreach ($overrideStateTokens as $stateToken) {
                    $parts = explode('|', $stateToken, 2);
                    if (count($parts) !== 2) {
                        continue;
                    }
                    $moduleId = trim((string)$parts[0]);
                    $state = strtolower(trim((string)$parts[1]));
                    if ($moduleId !== '' && in_array($state, ['inherit', 'allow', 'deny'], true)) {
                        $stateMap[$moduleId] = $state;
                    }
                }

                $permissionMap = [];
                foreach ($userPermissionTokens as $tokenValue) {
                    $parts = explode('|', $tokenValue, 2);
                    if (count($parts) !== 2) {
                        continue;
                    }
                    $moduleId = trim((string)$parts[0]);
                    $permissionId = trim((string)$parts[1]);
                    if ($moduleId === '' || $permissionId === '') {
                        continue;
                    }
                    if (!isset($permissionMap[$moduleId])) {
                        $permissionMap[$moduleId] = [];
                    }
                    $permissionMap[$moduleId][] = $permissionId;
                }

                $rules = [];
                foreach ($permissionModules as $moduleId => $moduleInfo) {
                    $state = $stateMap[$moduleId] ?? 'inherit';
                    if ($state === 'inherit') {
                        continue;
                    }

                    $permissions = [];
                    if ($state === 'allow') {
                        $definitions = $modulePermissionDefinitions[$moduleId] ?? [];
                        if (empty($definitions) || in_array($moduleId, $userAllModules, true)) {
                            $permissions = ['*'];
                        } else {
                            $permissions = $permissionMap[$moduleId] ?? [];
                        }
                    }

                    $rules[$moduleId] = [
                        'state' => $state,
                        'permissions' => $permissions,
                    ];
                }

                $userAclBefore = dmd_read_user_modules_acl($rightsUser);

                if (dmd_replace_user_module_overrides_detailed($rightsUser, $rules)) {
                    $userAclAfter = dmd_read_user_modules_acl($rightsUser);
                    $userRightsChanges = dmd_user_module_rights_notification_changes($userAclBefore, $userAclAfter, $permissionModules, $modulePermissionDefinitions);
                    $success = true;
                    $message = 'Exceptions fines de ' . $rightsUser . ' enregistrées.';
                    dmd_notification_index_refresh_user($rightsUser);
                    dmd_system_log('user_module_permissions_updated', $rightsUser, 'success', $message, ['rules' => $rules, 'changes' => $userRightsChanges]);
                    if ($userRightsChanges) {
                        dmd_notify_user(
                            $rightsUser,
                            'permissions_changed',
                            'Vos droits sur les modules ont changé',
                            count($userRightsChanges) . ' module(s) ont été modifié(s) par un administrateur.',
                            [
                                'level' => 'warning',
                                'action_url' => 'profile_edit.php',
                                'action_label' => 'Voir mes accès',
                                'meta' => [
                                    'scope' => 'modules',
                                    'target' => $rightsUser,
                                    'changes' => $userRightsChanges,
                                ],
                            ]
                        );
                    }
                } else {
                    $errors[] = 'Impossible d’enregistrer les exceptions de cet utilisateur.';
                }
            }
        }
    }

    if ($isAdmin && isset($_POST['save_global_page_rights'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $globalPages = isset($_POST['global_pages']) && is_array($_POST['global_pages'])
            ? array_values(array_map('strval', $_POST['global_pages']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } else {
            $pageAccessModes = [];
            foreach ($permissionPages as $pageId => $pageInfo) {
                $pageAccessModes[$pageId] = in_array($pageId, $globalPages, true) ? 'everyone' : 'controlled';
            }

            if (dmd_set_page_access_modes($pageAccessModes)) {
                $pageRightsData = dmd_read_pages_access();
                $success = true;
                $message = 'Pages accessibles à tout le monde enregistrées.';
                dmd_system_log('global_page_rights_updated', 'pages', 'success', $message, ['global_pages' => $globalPages]);
                dmd_notify_all('permissions_changed', 'Accès aux pages modifiés', 'Les règles globales d’accès aux pages DoMyDesk ont été mises à jour.', ['level' => 'warning']);
            } else {
                $errors[] = 'Impossible d’enregistrer les droits globaux des pages.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_role_page_rights'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsRole = trim((string)($_POST['page_rights_role'] ?? ''));
        $rolePages = isset($_POST['role_pages']) && is_array($_POST['role_pages'])
            ? array_values(array_map('strval', $_POST['role_pages']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } elseif (!in_array($rightsRole, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (dmd_set_role_pages($rightsRole, $rolePages)) {
            $pageRightsData = dmd_read_pages_access();
            $success = true;
            $message = 'Pages du rôle ' . $rightsRole . ' enregistrées.';
            dmd_system_log('role_page_permissions_updated', $rightsRole, 'success', $message, ['pages' => $rolePages]);
            dmd_notify_metier($rightsRole, 'permissions_changed', 'Vos accès aux pages ont changé', 'Les pages autorisées pour votre rôle métier ont été mises à jour.', ['level' => 'warning']);
        } else {
            $errors[] = 'Impossible d’enregistrer les pages de ce rôle.';
        }
    }

    if ($isAdmin && isset($_POST['save_user_page_exceptions'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsUser = trim((string)($_POST['page_rights_user'] ?? ''));
        $userOverrides = isset($_POST['page_overrides']) && is_array($_POST['page_overrides'])
            ? $_POST['page_overrides']
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } elseif ($rightsUser === '' || !is_dir($profilesDir . $rightsUser)) {
            $errors[] = 'Utilisateur invalide.';
        } else {
            $rightsUserProfile = dmd_read_profile($rightsUser);
            if (dmd_is_system_admin_profile($rightsUserProfile)) {
                $success = true;
                $message = 'Un administrateur possède déjà toutes les pages DoMyDesk.';
            } elseif (dmd_replace_user_page_overrides($rightsUser, $userOverrides)) {
                $success = true;
                $message = 'Exceptions de pages de ' . $rightsUser . ' enregistrées.';
                dmd_system_log('user_page_permissions_updated', $rightsUser, 'success', $message, ['overrides' => $userOverrides]);
                dmd_notify_user($rightsUser, 'permissions_changed', 'Vos accès aux pages ont changé', 'Un administrateur a modifié vos exceptions individuelles d’accès aux pages.', ['level' => 'warning']);
            } else {
                $errors[] = 'Impossible d’enregistrer les exceptions de pages de cet utilisateur.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_default_role'])) {
        $defaultRole = trim((string)($_POST['default_registration_role'] ?? ''));

        if (dmd_set_default_registration_role($defaultRole)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle par défaut des nouvelles inscriptions enregistré.';
            dmd_system_log('default_business_role_updated', $defaultRole, 'success', $message);
        } else {
            $errors[] = 'Rôle par défaut invalide.';
        }
    }

    if ($isAdmin && isset($_POST['add_user'])) {
        $prenom = trim($_POST['prenom'] ?? '');
        $nom = trim($_POST['nom'] ?? '');
        $emailNew = trim($_POST['email'] ?? '');
        $roleMetier = trim($_POST['role_metier'] ?? '');
        $roleSystem = trim($_POST['role_system'] ?? 'user');
        $password = $_POST['password'] ?? '';
        if (!$prenom || !$nom || !$emailNew || !$roleMetier || !$password || !$roleSystem) {
            $errors[] = 'Tous les champs utilisateur sont obligatoires.';
        } elseif (!filter_var($emailNew, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email invalide.';
        } elseif (!in_array($roleMetier, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (!in_array($roleSystem, $isSuperadmin ? ['user','admin','superadmin'] : ['user','admin'], true)) {
            $errors[] = 'Rôle système invalide.';
        } elseif (is_dir($profilesDir . $emailNew)) {
            $errors[] = "L'utilisateur existe déjà.";
        } else {
            $folder = $profilesDir . $emailNew . '/';
            @mkdir($folder, 0775, true);
            dmd_write_profile($emailNew, [
                'prenom' => $prenom,
                'nom' => $nom,
                'email' => $emailNew,
                'role_system' => $roleSystem,
                'role_metier' => $roleMetier,
                'motdepasse' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            dmd_write_user_modules_acl($emailNew, dmd_default_user_modules_acl());
            dmd_write_user_pages_acl($emailNew, dmd_default_user_pages_acl());
            dmd_json_write($folder . 'dashboard.json', []);
            dmd_json_write($folder . 'menu.json', []);
            if (is_file($baseDir . '/data/Logo_2025_Mini.png')) {
                $newUserMediaDir = dmd_user_media_dir($emailNew, true);
                if ($newUserMediaDir !== '') {
                    @copy($baseDir . '/data/Logo_2025_Mini.png', $newUserMediaDir . 'avatar.png');
                    @chmod($newUserMediaDir . 'avatar.png', 0664);
                }
            }
            dmd_set_permissions($folder);
            dmd_ensure_private_profile_dir($emailNew);
            @chmod(dmd_profile_path($emailNew, false), 0640);
            @chmod(dmd_modules_acl_path($emailNew, false), 0640);
            @chmod(dmd_pages_acl_path($emailNew, false), 0640);
            $success = true;
            $message = 'Utilisateur ajouté.';
            dmd_notification_index_refresh_user($emailNew);
            dmd_system_log('user_created', $emailNew, 'success', $message, ['prenom' => $prenom, 'nom' => $nom, 'role_system' => $roleSystem, 'role_metier' => $roleMetier]);
            dmd_notify_user($emailNew, 'account_created', 'Votre compte DoMyDesk a été créé', 'Un administrateur a créé votre compte DoMyDesk.', ['level' => 'success', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
        }
    }

    if ($isAdmin && isset($_POST['update_user_roles'])) {
        $userMail = trim($_POST['user_email'] ?? '');
        $roleSys = trim($_POST['new_role_system'] ?? 'user');
        $roleMetier = trim($_POST['new_role_metier'] ?? '');
        $profileFile = dmd_profile_path($userMail, true);
        if (is_file($profileFile)) {
            $data = dmd_json_read($profileFile, []);
            $beforeRoleSystem = (string)($data['role_system'] ?? 'user');
            $beforeRoleMetier = (string)($data['role_metier'] ?? '');
            $currentTargetRole = $beforeRoleSystem;
            $allowedTargetRoles = $isSuperadmin ? ['superadmin','admin','user'] : ['admin','user'];
            $denyRoleChange = false;
            if ($currentTargetRole === 'superadmin' && !$isSuperadmin) {
                $errors[] = 'Un compte Admin ne peut pas modifier un Superadmin.';
                dmd_system_log('superadmin_role_change_denied', $userMail, 'denied', 'Tentative de modification des rôles d’un Superadmin.');
                $denyRoleChange = true;
            }
            if (!$denyRoleChange) {
                if (in_array($roleSys, $allowedTargetRoles, true)) {
                    if ($currentTargetRole === 'superadmin' && $roleSys !== 'superadmin') {
                        $idx = dmd_notification_index();
                        $superadmins = $idx['role_system']['superadmin'] ?? [];
                        if (count($superadmins) <= 1) {
                            $roleSys = 'superadmin';
                            $errors[] = 'Le dernier Superadmin ne peut pas être rétrogradé.';
                        }
                    }
                    $data['role_system'] = $roleSys;
                }
                if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
                dmd_write_profile($userMail, $data);
                dmd_notification_index_refresh_user($userMail);
                $success = true;
                $message = 'Rôles mis à jour.';
                dmd_system_log('user_roles_updated', $userMail, 'success', $message, ['role_system' => $data['role_system'] ?? 'user', 'role_metier' => $data['role_metier'] ?? '']);
                $roleChanges = [];
                if (($data['role_system'] ?? 'user') !== $beforeRoleSystem) {
                    $roleChanges['role_system'] = ['label' => 'Rôle système', 'before' => $beforeRoleSystem, 'after' => (string)($data['role_system'] ?? 'user')];
                }
                if (($data['role_metier'] ?? '') !== $beforeRoleMetier) {
                    $roleChanges['role_metier'] = ['label' => 'Rôle métier', 'before' => $beforeRoleMetier, 'after' => (string)($data['role_metier'] ?? '')];
                }
                dmd_notify_user($userMail, 'profile_changed', 'Vos rôles DoMyDesk ont changé', 'Un administrateur a modifié vos rôles DoMyDesk.', [
                    'level' => 'warning',
                    'action_url' => 'profile_view.php',
                    'action_label' => 'Voir mon profil',
                    'meta' => ['scope' => 'profile', 'target' => $userMail, 'changes' => $roleChanges],
                ]);
            }
        }
    }

    if ($isAdmin && isset($_POST['save_user_roles'])) {
        $roleSystems = $_POST['role_systems'] ?? [];
        $roleMetiers = $_POST['role_metiers'] ?? [];
        if (is_array($roleSystems) && is_array($roleMetiers)) {
            $changedUsers = [];
            foreach ($roleSystems as $userMail => $roleSys) {
                $userMail = trim((string)$userMail);
                $roleSys = trim((string)$roleSys);
                $roleMetier = trim((string)($roleMetiers[$userMail] ?? ''));
                $profileFile = dmd_profile_path($userMail, true);
                if (!is_file($profileFile)) continue;
                $data = dmd_json_read($profileFile, []);
                $beforeSys = $data['role_system'] ?? 'user';
                $beforeMetier = $data['role_metier'] ?? '';
                if ($beforeSys === 'superadmin' && !$isSuperadmin) {
                    continue;
                }
                $allowedTargetRoles = $isSuperadmin ? ['superadmin','admin','user'] : ['admin','user'];
                if (in_array($roleSys, $allowedTargetRoles, true)) {
                    if ($beforeSys === 'superadmin' && $roleSys !== 'superadmin') {
                        $idx = dmd_notification_index();
                        $superadmins = $idx['role_system']['superadmin'] ?? [];
                        if (count($superadmins) <= 1) {
                            $roleSys = 'superadmin';
                        }
                    }
                    $data['role_system'] = $roleSys;
                }
                if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
                if (($data['role_system'] ?? 'user') !== $beforeSys || ($data['role_metier'] ?? '') !== $beforeMetier) {
                    dmd_write_profile($userMail, $data);
                    dmd_notification_index_refresh_user($userMail);
                    $changedUsers[] = $userMail;
                    $roleChanges = [];
                    if (($data['role_system'] ?? 'user') !== $beforeSys) {
                        $roleChanges['role_system'] = ['label' => 'Rôle système', 'before' => (string)$beforeSys, 'after' => (string)($data['role_system'] ?? 'user')];
                    }
                    if (($data['role_metier'] ?? '') !== $beforeMetier) {
                        $roleChanges['role_metier'] = ['label' => 'Rôle métier', 'before' => (string)$beforeMetier, 'after' => (string)($data['role_metier'] ?? '')];
                    }
                    dmd_notify_user($userMail, 'profile_changed', 'Vos rôles DoMyDesk ont changé', 'Un administrateur a modifié vos rôles DoMyDesk.', [
                        'level' => 'warning',
                        'action_url' => 'profile_view.php',
                        'action_label' => 'Voir mon profil',
                        'meta' => ['scope' => 'profile', 'target' => $userMail, 'changes' => $roleChanges],
                    ]);
                }
            }
            $success = true;
            $message = 'Rôles utilisateurs enregistrés.';
            dmd_system_log('users_roles_bulk_updated', 'utilisateurs', 'success', $message, ['users' => $changedUsers]);
        }
    }

    if ($isAdmin && isset($_POST['delete_user'])) {
        $userMail = trim($_POST['delete_user'] ?? ($_POST['user_email'] ?? ''));
        $targetProfile = $userMail !== '' ? dmd_read_profile($userMail) : [];
        $targetSystemRole = (string)($targetProfile['role_system'] ?? 'user');
        $idx = dmd_notification_index();
        $superadmins = $idx['role_system']['superadmin'] ?? [];
        if ($targetSystemRole === 'superadmin' && !$isSuperadmin) {
            $errors[] = 'Un compte Admin ne peut pas supprimer un Superadmin.';
            dmd_system_log('superadmin_delete_denied', $userMail, 'denied', 'Tentative de suppression d’un compte Superadmin.');
        } elseif ($targetSystemRole === 'superadmin' && count($superadmins) <= 1) {
            $errors[] = 'Le dernier Superadmin ne peut pas être supprimé.';
        } elseif ($userMail !== '' && $userMail !== $email && is_dir($profilesDir . $userMail)) {
            dmd_remove_dir($profilesDir . $userMail);
            dmd_notification_index_remove_user($userMail);
            $success = true;
            $message = 'Utilisateur supprimé.';
            dmd_system_log('user_deleted', $userMail, 'success', $message, ['prenom' => (string)($targetProfile['prenom'] ?? ''), 'nom' => (string)($targetProfile['nom'] ?? ''), 'role_system' => $targetSystemRole, 'role_metier' => (string)($targetProfile['role_metier'] ?? '')]);
        } else {
            $errors[] = "Impossible de supprimer l'utilisateur courant ou un dossier introuvable.";
        }
    }

}

$heartbeatEnabled = !empty($settings['domyco_heartbeat_enabled']);
$heartbeatInterval = 300;
$heartbeatLast = dmd_json_read($heartbeatLastFile, []);
$heartbeatLastAttempt = is_file($heartbeatLockFile) ? (int)trim((string)@file_get_contents($heartbeatLockFile)) : 0;
$heartbeatLastAttemptText = $heartbeatLastAttempt > 0 ? date('d/m/Y H:i:s', $heartbeatLastAttempt) : 'Jamais';
$heartbeatNextText = $heartbeatLastAttempt > 0 ? date('d/m/Y H:i:s', $heartbeatLastAttempt + $heartbeatInterval) : 'Au prochain chargement après activation';
$heartbeatLastSuccess = !empty($heartbeatLast['success']) && empty($heartbeatLast['skipped']);
$heartbeatLastHttp = $heartbeatLast['http_code'] ?? ($heartbeatLast['sync_result']['http_code'] ?? null);

$users = [];
$userRoles = [];
$userProfiles = [];
foreach (glob($profilesDir . '*', GLOB_ONLYDIR) ?: [] as $folder) {
    $mail = basename($folder);
    $profile = dmd_read_profile($mail);
    $users[] = $mail;
    $userProfiles[$mail] = $profile;
    $userRoles[$mail] = $profile['role_system'] ?? 'user';
}
sort($users, SORT_NATURAL | SORT_FLAG_CASE);
$superadminTotal = 0;
foreach ($userProfiles as $pUser) { if (($pUser['role_system'] ?? 'user') === 'superadmin') $superadminTotal++; }

// Données légères nécessaires à la matrice des droits modules.
// On ne précharge pas les droits effectifs complets : le navigateur les calcule
// à partir du rôle métier, du mode d'accès et des seules exceptions utilisateur.
$userModuleOverridesMap = [];
$userRightsMeta = [];
foreach ($users as $u) {
    $acl = dmd_read_user_modules_acl($u);
    $profile = $userProfiles[$u] ?? [];
    $userModuleOverridesMap[$u] = is_array($acl['overrides'] ?? null) ? $acl['overrides'] : [];
    $userRightsMeta[$u] = [
        'role_system' => (string)($profile['role_system'] ?? 'user'),
        'role_metier' => (string)($profile['role_metier'] ?? ''),
        'name' => trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? '')),
    ];
}

$selectedRightsRole = trim((string)($_POST['rights_role'] ?? ($metiers[0] ?? '')));
if (!in_array($selectedRightsRole, $metiers, true)) {
    $selectedRightsRole = (string)($metiers[0] ?? '');
}
$selectedRightsUser = trim((string)($_POST['rights_user'] ?? ''));
if ($selectedRightsUser !== '' && !in_array($selectedRightsUser, $users, true)) {
    $selectedRightsUser = '';
}


$userPageOverridesMap = [];
foreach ($users as $u) {
    $pageAcl = dmd_read_user_pages_acl($u);
    $userPageOverridesMap[$u] = is_array($pageAcl['overrides'] ?? null) ? $pageAcl['overrides'] : [];
}

$selectedPageRightsRole = trim((string)($_POST['page_rights_role'] ?? ($metiers[0] ?? '')));
if (!in_array($selectedPageRightsRole, $metiers, true)) {
    $selectedPageRightsRole = (string)($metiers[0] ?? '');
}
$selectedPageRightsUser = trim((string)($_POST['page_rights_user'] ?? ''));
if ($selectedPageRightsUser !== '' && !in_array($selectedPageRightsUser, $users, true)) {
    $selectedPageRightsUser = '';
}

$modDir = $baseDir . '/modules';
$allModules = array_values(array_filter(glob($modDir . '/*') ?: [], 'is_dir'));
$totalModules = count($allModules);
$perPage = 40;
$page = max(1, (int)($_GET['mpage'] ?? 1));
$pagesCount = max(1, (int)ceil($totalModules / $perPage));
$page = min($page, $pagesCount);
$modulesPage = array_slice($allModules, ($page - 1) * $perPage, $perPage);

$themeMarketWhy = $themeMarketSourceError;
$themeMarketRefreshed = false;
$themeMarketRaw = $themeMarketRawOverride;
if ($themeMarketRaw === null) {
    $themeMarketRaw = dmd_source_load_raw($baseDir, 'themes', false, $themeMarketWhy, $themeMarketRefreshed);
}
$themeMarketItems = [];
if ($themeMarketRaw !== false) {
    $decodedThemeMarket = json_decode($themeMarketRaw, true);
    if (is_array($decodedThemeMarket)) $themeMarketItems = $decodedThemeMarket;
}
$installedThemes = dmd_theme_installed_list($themesDir);

/* État de licence relu après toute action d’administration. */
$dmdLicenseStatus = $isSuperadmin ? dmd_license_status(true) : array();
$dmdLicenseEntitlements = isset($dmdLicenseStatus['entitlements']) && is_array($dmdLicenseStatus['entitlements']) ? $dmdLicenseStatus['entitlements'] : array();
$dmdLicenseAgent = isset($dmdLicenseEntitlements['dmd_agent']) && is_array($dmdLicenseEntitlements['dmd_agent']) ? $dmdLicenseEntitlements['dmd_agent'] : array();
$dmdLicenseMyDesk = isset($dmdLicenseEntitlements['dmd_mydesk']) && is_array($dmdLicenseEntitlements['dmd_mydesk']) ? $dmdLicenseEntitlements['dmd_mydesk'] : array();
$dmdLicenseInstances = isset($dmdLicenseEntitlements['dmd_instances']) && is_array($dmdLicenseEntitlements['dmd_instances']) ? $dmdLicenseEntitlements['dmd_instances'] : array();
$dmdLicenseTicketing = isset($dmdLicenseEntitlements['dmd_ticketing_external']) && is_array($dmdLicenseEntitlements['dmd_ticketing_external']) ? $dmdLicenseEntitlements['dmd_ticketing_external'] : array();
$dmdLicenseHasSignedFile = !empty($dmdLicenseStatus['verified']) && (string)($dmdLicenseStatus['source'] ?? '') === 'file';
$dmdLicenseEngineFile = dmd_license_file();
$dmdLicenseOrderHref = $dmdLicenseOrderUrl . '?instance=' . rawurlencode((string)dmd_license_instance_id());
$dmdTicketingLicense = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_license_status() : array('enabled'=>false,'clients_max'=>0);
$dmdTicketingConfig = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_config() : array();
$dmdTicketingReceive = isset($dmdTicketingConfig['external_receive']) && is_array($dmdTicketingConfig['external_receive']) ? $dmdTicketingConfig['external_receive'] : array();
$dmdTicketingSupportBaseUrl = dmd_admin_ticketing_base_url((string)($dmdTicketingReceive['endpoint'] ?? ''));
$dmdTicketingClients = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_client_list() : array();
$dmdTicketingActiveClients = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_active_client_count() : 0;
$dmdTicketingClientsMax = (int)($dmdTicketingLicense['clients_max'] ?? 0);
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars((string)($settings['language'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administration systeme</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeCssHref) ?>">
<link rel="stylesheet" href="../core/dmd_permissions_admin.css?v=120">
<link rel="stylesheet" href="../core/dmd_permissions_admin_compact.css?v=121">
<style>
.dmd-menu-order-col { width: 46px; text-align: center; }
.dmd-menu-drag-handle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    padding: 0;
    cursor: grab;
    user-select: none;
    touch-action: none;
    border: 1px solid var(--border-color);
    border-radius: 7px;
    background: var(--input-bg, transparent);
    color: var(--text-color);
}
.dmd-menu-drag-handle:active { cursor: grabbing; }
.dmd-menu-row.dmd-menu-dragging { opacity: .45; }
.dmd-menu-row.dmd-menu-drop-before td { box-shadow: inset 0 2px 0 var(--accent-color, currentColor); }
.dmd-menu-row.dmd-menu-drop-after td { box-shadow: inset 0 -2px 0 var(--accent-color, currentColor); }

.dmd-security-accordions{display:grid;gap:10px}.dmd-security-accordion{border:1px solid var(--border-color);border-radius:9px;background:var(--card-bg,transparent);overflow:hidden}.dmd-security-accordion>summary{cursor:pointer;padding:13px 15px;font-weight:700;list-style:none;display:flex;align-items:center;justify-content:space-between;gap:10px}.dmd-security-accordion>summary::-webkit-details-marker{display:none}.dmd-security-accordion>summary::after{content:'▾';opacity:.7;transition:transform .15s ease}.dmd-security-accordion[open]>summary::after{transform:rotate(180deg)}.dmd-security-panel{padding:0 15px 15px}.dmd-security-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.dmd-security-table{width:100%;border-collapse:collapse}.dmd-security-table th,.dmd-security-table td{padding:8px;border-bottom:1px solid var(--border-color);text-align:left;vertical-align:middle}.dmd-security-table select{width:100%}.dmd-security-status{font-size:.9em;opacity:.82}.dmd-security-actions{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.dmd-security-auth{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:14px}@media(max-width:850px){.dmd-security-grid,.dmd-security-auth{grid-template-columns:1fr}}
.dmd-license-summary-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:10px 0 12px}.dmd-license-summary-card{border:1px solid var(--border-color);border-radius:8px;padding:10px;background:var(--card-bg,transparent);min-width:0}.dmd-license-summary-card span{display:block;font-size:.78rem;opacity:.72;margin-bottom:3px}.dmd-license-summary-card strong{display:block;overflow-wrap:anywhere}.dmd-license-products{width:100%;border-collapse:collapse;margin-top:8px}.dmd-license-products th,.dmd-license-products td{padding:8px;border-bottom:1px solid var(--border-color);text-align:left}.dmd-license-products th{font-size:.78rem;opacity:.75}.dmd-license-tools{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(260px,.8fr);gap:10px;margin-top:12px}.dmd-license-box{border:1px solid var(--border-color);border-radius:9px;padding:11px;background:var(--card-bg,transparent)}.dmd-license-box h3{margin:0 0 6px}.dmd-license-upload{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}.dmd-license-upload input[type=file]{min-width:0;width:100%}.dmd-license-order-note{margin:8px 0;padding:9px;border:1px solid var(--border-color);border-radius:8px;background:var(--input-bg,transparent)}.dmd-license-state{font-weight:800}.dmd-license-hash{font: .78rem ui-monospace,SFMono-Regular,Consolas,monospace;word-break:break-all;opacity:.78}@media(max-width:900px){.dmd-license-summary-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dmd-license-tools{grid-template-columns:1fr}}@media(max-width:560px){.dmd-license-summary-grid{grid-template-columns:1fr}.dmd-license-upload{grid-template-columns:1fr}}
.dmd-ticketing-license-admin{margin-top:14px;border:1px solid var(--border-color);border-radius:10px;padding:12px;background:var(--card-bg,transparent)}.dmd-ticketing-license-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.dmd-ticketing-license-head h3,.dmd-ticketing-client-create h3,.dmd-ticketing-clients h3{margin:0 0 5px}.dmd-ticketing-license-badge{white-space:nowrap;border:1px solid var(--border-color);border-radius:999px;padding:6px 9px;font-size:.8rem;font-weight:800}.dmd-ticketing-license-badge.is-off{opacity:.65}.dmd-ticketing-support-form,.dmd-ticketing-client-create,.dmd-ticketing-clients,.dmd-ticketing-master-key{margin-top:12px}.dmd-ticketing-switch{display:flex;align-items:center;gap:8px;font-weight:700;margin-bottom:10px}.dmd-ticketing-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.dmd-ticketing-form-grid label{display:grid;gap:5px}.dmd-ticketing-form-grid label>span{font-size:.82rem;font-weight:700;opacity:.82}.dmd-ticketing-form-grid input{width:100%;box-sizing:border-box;background:var(--input-bg,transparent);color:inherit;border:1px solid var(--border-color);border-radius:7px;padding:8px 9px}.dmd-ticketing-form-grid .is-wide{grid-column:1/-1}.dmd-ticketing-master-key{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid var(--border-color);border-radius:8px;padding:10px}.dmd-ticketing-client-create{border-top:1px solid var(--border-color);padding-top:12px}.dmd-ticketing-client-row{display:flex;justify-content:space-between;align-items:center;gap:10px;border-top:1px solid var(--border-color);padding:9px 0}.dmd-ticketing-client-row.is-revoked{opacity:.62}.dmd-ticketing-client-info{display:grid;gap:2px;min-width:0}.dmd-ticketing-client-info span,.dmd-ticketing-client-info small{font-size:.79rem;opacity:.76;overflow-wrap:anywhere}.dmd-ticketing-client-row form{margin:0}@media(max-width:760px){.dmd-ticketing-license-head,.dmd-ticketing-master-key,.dmd-ticketing-client-row{align-items:stretch;flex-direction:column}.dmd-ticketing-form-grid{grid-template-columns:1fr}.dmd-ticketing-form-grid .is-wide{grid-column:auto}}
.dmd-dms-bridge-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}.dmd-dms-bridge-instance-list{display:grid;gap:10px;margin-top:10px}.dmd-dms-bridge-instance{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:end;padding:10px;border:1px solid var(--border-color);border-radius:8px;background:var(--card-bg,transparent)}@media(max-width:700px){.dmd-dms-bridge-instance{grid-template-columns:1fr}}.dmd-dms-bridge-box{border:1px solid var(--border-color);border-radius:9px;padding:12px;background:var(--card-bg,transparent)}.dmd-dms-bridge-box h3{margin-top:0}.dmd-dms-bridge-token{display:flex;gap:8px;align-items:stretch;flex-wrap:wrap}.dmd-dms-bridge-token code{flex:1;min-width:240px;padding:10px;border:1px solid var(--border-color);border-radius:8px;background:var(--input-bg,rgba(0,0,0,.18));word-break:break-all;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.dmd-dms-bridge-meta{display:grid;gap:6px}.dmd-dms-bridge-meta strong{font-weight:800}.dmd-dms-bridge-empty{opacity:.75}.dmd-dms-bridge-danger{border-color:var(--danger,#d9534f)!important}.dmd-dms-bridge-label{width:100%}.dmd-dms-bridge-spaced{margin-top:12px}.dmd-dms-bridge-meta-spaced{margin-top:10px}@media(max-width:850px){.dmd-dms-bridge-grid{grid-template-columns:1fr}}

</style>

</head>
<body>
<?php include $baseDir . '/header.php'; ?>
<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">Administration systeme</h1>
            <p class="pe-subtitle">Gestion du site, des modules, des utilisateurs et des acces.</p>
        </div>
        <div class="dmd-admin-version-stack">
            <div class="pe-user-pill"><?= htmlspecialchars($email ?? 'Utilisateur') ?></div>
            <div class="dmd-version-pill" title="Version lue depuis data/version.txt"><?= htmlspecialchars($dmdVersionLabel) ?></div>
        </div>
    </div>

    <?php if ($success || $message): ?><div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Action effectuée.') ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e) . '<br>'; ?></div><?php endif; ?>

    <h2 class="pe-section-title">Site</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-site-settings">
            <span class="pe-card-main"><span class="pe-card-title">Parametres du site</span><span class="pe-card-desc">Nom, avatar/bannière et menus</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-core-interface">
            <span class="pe-card-main"><span class="pe-card-title">Outils Core & dashboards</span><span class="pe-card-desc">ActionHub, Quick-Session, icônes et limite des bureaux</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='notifications.php'">
            <span class="pe-card-main"><span class="pe-card-title">🔔 Notifications & e-mails</span><span class="pe-card-desc">Activation, SMTP, destinataires et textes des événements</span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-site-maintenance">
            <span class="pe-card-main"><span class="pe-card-title">Maintenance</span><span class="pe-card-desc">ID DoMyDesk et permissions</span></span>
        </button>
        <?php endif; ?>
        <button type="button" class="pe-card" data-popup-open="popup-index-settings">
            <span class="pe-card-main"><span class="pe-card-title">Reglages page d'accueil</span><span class="pe-card-desc">Reglage de l'index du site</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-theme-market">
            <span class="pe-card-main"><span class="pe-card-title">Market des themes</span><span class="pe-card-desc">Aperçus et installation depuis GitHub</span></span>
        </button>
		<button type="button" class="pe-card" data-popup-open="popup-news">
    <span class="pe-card-main">
        <span class="pe-card-title">Actualités</span>
        <span class="pe-card-desc">Configuration des actualités DoMyDesk</span>
    </span>
</button>
        <?php if ($isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-unofficial-themes">
            <span class="pe-card-main"><span class="pe-card-title"><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Thèmes non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></span><span class="pe-card-desc">Installer un thème tiers depuis un ZIP</span></span>
        </button>
        <?php endif; ?>
    </div>

    <h2 class="pe-section-title">Modules</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-market-inline">
            <span class="pe-card-main"><span class="pe-card-title">Installer un module</span><span class="pe-card-desc">Market DoMyDesk</span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-module-rights">
            <span class="pe-card-main"><span class="pe-card-title">Droits sur les modules</span><span class="pe-card-desc">Rôles métier et exceptions utilisateurs</span></span>
        </button>
        <?php endif; ?>
        <?php if ($isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-module-updates">
            <span class="pe-card-main"><span class="pe-card-title">Mise à jour des modules</span><span class="pe-card-desc">Catalogue GitHub ou ZIP manuel</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-unofficial-modules">
            <span class="pe-card-main"><span class="pe-card-title"><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Modules non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></span><span class="pe-card-desc">Installer un module tiers depuis un ZIP</span></span>
        </button>
        <?php endif; ?>
    </div>

    <h2 class="pe-section-title">Utilisateurs</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-user-add">
            <span class="pe-card-main"><span class="pe-card-title">Ajouter utilisateur</span><span class="pe-card-desc">Creer un compte</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-user-roles">
            <span class="pe-card-main"><span class="pe-card-title">Roles utilisateurs</span><span class="pe-card-desc">Admin/user et metier</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-registration">
            <span class="pe-card-main"><span class="pe-card-title">Validation des inscriptions</span><span class="pe-card-desc"><?= ($settings['registration_approval_mode'] ?? 'approval') === 'automatic' ? 'Activation automatique' : 'Validation par administrateur' ?><?= $dmdPendingRegistrations ? ' · ' . count($dmdPendingRegistrations) . ' en attente' : '' ?></span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-page-rights">
            <span class="pe-card-main"><span class="pe-card-title">Pages accessibles</span><span class="pe-card-desc">Rôles métier et exceptions utilisateurs</span></span>
        </button>
        <?php endif; ?>
        <button type="button" class="pe-card" data-popup-open="popup-metiers">
            <span class="pe-card-main"><span class="pe-card-title">Rôles métier</span><span class="pe-card-desc">Création, suppression et rôle par défaut</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='quick_sessions.php'">
            <span class="pe-card-main"><span class="pe-card-title"><?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?> Quick-Sessions</span><span class="pe-card-desc">Historique, timeline, mémoire et suppression</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='actionhub.php'">
            <span class="pe-card-main"><span class="pe-card-title"><?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?> ActionHub</span><span class="pe-card-desc">Scénarios, création, modification et suppression</span></span>
        </button>
    </div>

    <?php if ($isSuperadmin): ?>
    <h2 class="pe-section-title">Système</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-system-logs">
            <span class="pe-card-main"><span class="pe-card-title">📜 Logs système</span><span class="pe-card-desc">Historique des changements du Core, utilisateurs, droits et configuration</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='agent/'">
            <span class="pe-card-main"><span class="pe-card-title">🛡️ DMD-Agent sécurisé</span><span class="pe-card-desc">Identité DoMyDesk, enrôlements, agents et révocations</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-updates">
            <span class="pe-card-main"><span class="pe-card-title">Mises à jour système</span><span class="pe-card-desc">Mises à jour DoMyDesk depuis GitHub ou ZIP manuel</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-security-admin">
            <span class="pe-card-main"><span class="pe-card-title">🔐 Sécurité & administration</span><span class="pe-card-desc">MFA, annuaire, licences, liaison DoMySocial, droits et maintenance</span></span>
        </button>
    </div>
    <?php endif; ?>
</div>


<?php if ($isSuperadmin): ?>
<div id="popup-security-admin" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>🔐 Sécurité & administration</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-security-admin' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Configuration enregistrée.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-security-admin' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <?php
                // N'ouvrir que le volet correspondant à l'action réellement effectuée.
                $dmdSecurityRequestedSection = strtolower(trim((string)($_GET['section'] ?? '')));
                $dmdSecurityMfaOpen = (
                    $dmdSecurityRequestedSection === 'mfa'
                    || isset($_POST['save_mfa_policy'])
                    || (string)($_GET['mfa_saved'] ?? '') === '1'
                );
                $dmdSecurityDirectoryOpen = (
                    $dmdSecurityRequestedSection === 'directory'
                    || !empty($dmdDirectoryAction)
                );
                $dmdSecurityDoMySocialOpen = (
                    $dmdSecurityRequestedSection === 'domysocial'
                    || isset($_POST['generate_dms_bridge'])
                    || isset($_POST['revoke_dms_bridge'])
                    || (string)($_GET['dms_bridge_saved'] ?? '') === '1'
                    || (string)($_GET['dms_bridge_revoked'] ?? '') === '1'
                    || $dmdDmsBridgeNewToken !== ''
                );
                $dmdSecurityLicensesOpen = (
                    $dmdSecurityRequestedSection === 'licenses'
                    || isset($_POST['install_dmd_license'])
                    || isset($_POST['remove_dmd_license'])
                    || (string)($_GET['license_saved'] ?? '') === '1'
                    || (string)($_GET['license_removed'] ?? '') === '1'
                );
            ?>
            <div class="dmd-security-accordions" id="dmd-security-accordions">
                <details id="dmd-security-mfa" class="dmd-security-accordion" data-security-section="mfa" <?= $dmdSecurityMfaOpen ? 'open' : '' ?>>
                    <summary>🔐 Identité & MFA</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Politique centrale Microsoft Authenticator. Priorité : <strong>utilisateur → groupe/rôle métier → politique globale</strong>.</p>

                        <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=mfa" class="pe-form" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="save_mfa_policy" value="1">

                            <div class="dmd-security-grid">
                                <div>
                                    <label>Politique globale MFA</label>
                                    <select name="mfa_global_policy">
                                        <option value="optional" <?= ($mfaPolicy['global'] ?? 'optional') === 'optional' ? 'selected' : '' ?>>Facultatif — chaque utilisateur choisit</option>
                                        <option value="required" <?= ($mfaPolicy['global'] ?? '') === 'required' ? 'selected' : '' ?>>Obligatoire — configuration imposée avant accès</option>
                                        <option value="disabled" <?= ($mfaPolicy['global'] ?? '') === 'disabled' ? 'selected' : '' ?>>Désactivé — aucun MFA utilisé à la connexion</option>
                                    </select>
                                </div>
                                <div>
                                    <label>Validations de désactivation</label>
                                    <p class="pe-note"><?= (int)$mfaDisablePendingCount ?> demande(s) en attente.</p>
                                    <a class="btn" href="mfa_requests.php">Gérer les validations MFA</a>
                                </div>
                            </div>

                            <h3>Groupes / rôles métier</h3>
                            <div class="table-wrap">
                                <table class="dmd-security-table">
                                    <thead><tr><th>Groupe / rôle métier</th><th>Politique</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($metiers as $mfaRoleName): ?>
                                        <?php $mfaRoleState = (string)($mfaPolicy['roles'][$mfaRoleName] ?? 'inherit'); ?>
                                        <tr>
                                            <td><?= htmlspecialchars($mfaRoleName, ENT_QUOTES, 'UTF-8') ?></td>
                                            <td>
                                                <select name="mfa_role_policy[<?= htmlspecialchars($mfaRoleName, ENT_QUOTES, 'UTF-8') ?>]">
                                                    <option value="inherit" <?= $mfaRoleState === 'inherit' ? 'selected' : '' ?>>Hériter de la politique globale</option>
                                                    <option value="optional" <?= $mfaRoleState === 'optional' ? 'selected' : '' ?>>Facultatif</option>
                                                    <option value="required" <?= $mfaRoleState === 'required' ? 'selected' : '' ?>>Obligatoire</option>
                                                    <option value="disabled" <?= $mfaRoleState === 'disabled' ? 'selected' : '' ?>>Désactivé</option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <h3>Utilisateurs</h3>
                            <div class="table-wrap">
                                <table class="dmd-security-table">
                                    <thead><tr><th>Utilisateur</th><th>Groupe</th><th>MFA configuré</th><th>Politique effective</th><th>Exception</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($users as $mfaUserMail): ?>
                                        <?php
                                            $mfaUserProfile = $userProfiles[$mfaUserMail] ?? array();
                                            $mfaUserRole = (string)($mfaUserProfile['role_metier'] ?? '');
                                            $mfaUserConfigured = dmd_mfa_enabled($mfaUserMail);
                                            $mfaUserEffective = dmd_mfa_effective_policy($mfaUserMail, $mfaUserProfile);
                                            $mfaUserOverride = (string)($mfaPolicy['users'][$mfaUserMail] ?? 'inherit');
                                            $mfaUserName = trim((string)($mfaUserProfile['prenom'] ?? '') . ' ' . (string)($mfaUserProfile['nom'] ?? ''));
                                        ?>
                                        <tr>
                                            <td><strong><?= htmlspecialchars($mfaUserName !== '' ? $mfaUserName : $mfaUserMail, ENT_QUOTES, 'UTF-8') ?></strong><br><span class="dmd-security-status"><?= htmlspecialchars($mfaUserMail, ENT_QUOTES, 'UTF-8') ?></span></td>
                                            <td><?= htmlspecialchars($mfaUserRole !== '' ? $mfaUserRole : '—', ENT_QUOTES, 'UTF-8') ?></td>
                                            <td><?= $mfaUserConfigured ? '✅ Oui' : '⚪ Non' ?></td>
                                            <td><?= $mfaUserEffective === 'required' ? '🔒 Obligatoire' : ($mfaUserEffective === 'disabled' ? '⛔ Désactivé' : '⚪ Facultatif') ?></td>
                                            <td>
                                                <select name="mfa_user_policy[<?= htmlspecialchars($mfaUserMail, ENT_QUOTES, 'UTF-8') ?>]">
                                                    <option value="inherit" <?= $mfaUserOverride === 'inherit' ? 'selected' : '' ?>>Hériter du groupe/global</option>
                                                    <option value="optional" <?= $mfaUserOverride === 'optional' ? 'selected' : '' ?>>Facultatif</option>
                                                    <option value="required" <?= $mfaUserOverride === 'required' ? 'selected' : '' ?>>Obligatoire</option>
                                                    <option value="disabled" <?= $mfaUserOverride === 'disabled' ? 'selected' : '' ?>>Désactivé</option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <p class="pe-note">Une politique « Désactivé » ne détruit pas le secret Authenticator existant : elle suspend son utilisation. Une politique « Obligatoire » force la configuration du MFA après le mot de passe avant d’ouvrir la session DoMyDesk.</p>

                            <div class="dmd-security-auth">
                                <div>
                                    <label>Mot de passe Superadmin</label>
                                    <input type="password" name="mfa_admin_password" required autocomplete="current-password">
                                </div>
                                <div>
                                    <label>Code MFA Superadmin<?= dmd_mfa_enabled($email) ? '' : ' (non requis : MFA non configuré)' ?></label>
                                    <input type="text" name="mfa_admin_code" <?= dmd_mfa_enabled($email) ? 'required' : '' ?> autocomplete="one-time-code" inputmode="numeric">
                                </div>
                            </div>
                            <div class="pe-actions"><button type="submit" name="save_mfa_policy" value="1">Enregistrer la politique MFA</button></div>
                        </form>
                    </div>
                </details>

                <details id="dmd-security-directory" class="dmd-security-accordion" data-security-section="directory" <?= $dmdSecurityDirectoryOpen ? 'open' : '' ?>>
                    <summary>🏢 Annuaire / Active Directory</summary>
                    <?php require $baseDir . '/adm/directory/directory_config.php'; ?>
                </details>

                <details id="dmd-security-domysocial" class="dmd-security-accordion" data-security-section="domysocial" <?= $dmdSecurityDoMySocialOpen ? 'open' : '' ?>>
                    <summary>🔗 Liaison DoMySocial</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Appaire ce DoMyDesk avec une instance DoMySocial. DoMySocial pourra synchroniser les identités autorisées (profil, avatar, bannière, identité AD et, si activé, MFA), puis conserver sa propre copie locale pour rester autonome.</p>

                        <?php if ($dmdDmsBridgeNewToken !== ''): ?>
                            <div class="pe-msg pe-msg-ok">
                                <strong>🔑 Nouveau code d’appairage</strong><br>
                                Copiez ce code maintenant : il ne sera plus affiché après fermeture ou rechargement.
                            </div>
                            <div class="dmd-dms-bridge-token">
                                <code id="dmdDmsBridgeToken"><?= htmlspecialchars($dmdDmsBridgeNewToken, ENT_QUOTES, 'UTF-8') ?></code>
                                <button type="button" class="btn" onclick="dmdCopyBridgeToken(this)">📋 Copier</button>
                            </div>
                            <p class="pe-note">À coller dans DoMySocial → Administration → Sécurité → Liaison DoMyDesk.</p>
                        <?php endif; ?>

                        <div class="dmd-dms-bridge-grid">
                            <div class="dmd-dms-bridge-box">
                                <h3>Ajouter une instance DoMySocial</h3>
                                <p class="pe-note">Chaque code ajoute une nouvelle instance DoMySocial. Les liaisons déjà actives restent en place. Le code brut n’est pas conservé dans DoMyDesk.</p>
                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=domysocial" class="pe-form" autocomplete="off">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label>Nom de l’instance DoMySocial</label>
                                    <input class="dmd-dms-bridge-label" type="text" name="dms_bridge_label" value="DoMySocial" maxlength="120" placeholder="Ex. Marnaz-City">
                                    <div class="pe-actions"><button type="submit" name="generate_dms_bridge" value="1">🔑 Générer un code d’appairage</button></div>
                                </form>
                            </div>

                            <div class="dmd-dms-bridge-box">
                                <h3>État de la liaison</h3>
                                <div class="dmd-dms-bridge-meta">
                                    <div><span class="pe-note">ID DoMyDesk</span><br><strong><?= htmlspecialchars(dmd_domysocial_bridge_instance_uid() ?: 'Non disponible', ENT_QUOTES, 'UTF-8') ?></strong></div>
                                    <div><span class="pe-note">Instances autorisées</span><br><strong><?= count($dmdDmsBridgeTokens) ?> DoMySocial</strong></div>
                                </div>
                                <?php if ($dmdDmsBridgeTokens): ?>
                                    <div class="dmd-dms-bridge-instance-list">
                                    <?php foreach ($dmdDmsBridgeTokens as $dmdDmsBridgeRow): ?>
                                        <?php
                                          $dmsUid=trim((string)($dmdDmsBridgeRow['dms_instance_uid'] ?? ''));
                                          $dmsName=trim((string)($dmdDmsBridgeRow['dms_instance_name'] ?? ''));
                                          if ($dmsName==='') $dmsName=(string)($dmdDmsBridgeRow['label'] ?? 'DoMySocial');
                                        ?>
                                        <div class="dmd-dms-bridge-instance">
                                          <div class="dmd-dms-bridge-meta">
                                            <div><strong>🌐 <?= htmlspecialchars($dmsName, ENT_QUOTES, 'UTF-8') ?></strong></div>
                                            <div><span class="pe-note">ID unique DoMySocial</span><br><strong><?= htmlspecialchars($dmsUid!==''?$dmsUid:'En attente du premier test depuis DoMySocial', ENT_QUOTES, 'UTF-8') ?></strong></div>
                                            <div class="dmd-security-status">Créé : <?= htmlspecialchars((string)($dmdDmsBridgeRow['created_at'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Appairé : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['paired_at'] ?? '') ?: 'pas encore'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Dernière utilisation : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['last_used_at'] ?? '') ?: 'jamais'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Dernière IP : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['last_ip'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></div>
                                          </div>
                                          <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=domysocial" onsubmit="return confirm('Révoquer uniquement cette liaison DoMySocial ?');">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="dms_bridge_id" value="<?= htmlspecialchars((string)($dmdDmsBridgeRow['id'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                                            <button class="btn dmd-dms-bridge-danger" type="submit" name="revoke_dms_bridge" value="1">🚫 Révoquer cette instance</button>
                                          </form>
                                        </div>
                                    <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="dmd-dms-bridge-empty">Aucune instance DoMySocial n’est actuellement appairée.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="dmd-dms-bridge-box dmd-dms-bridge-spaced">
                            <h3>Ce que permet la liaison</h3>
                            <p class="pe-note">L’API DoMyDesk reste en lecture seule. Selon les options choisies dans DoMySocial, elle peut fournir les utilisateurs, profils, avatars, bannières, informations Active Directory et MFA. Les éléments synchronisés sont ensuite stockés localement dans DoMySocial : une panne de DoMyDesk ne supprime pas les données déjà copiées.</p>
                        </div>
                    </div>
                </details>

                <details id="dmd-security-licenses" class="dmd-security-accordion" data-security-section="licenses" <?= $dmdSecurityLicensesOpen ? 'open' : '' ?>>
                    <summary>🔑 Licences</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">État, droits actifs et installation du fichier <code>.dmdlic</code> signé pour cette instance. Le moteur utilise uniquement <code>var/licenses/current.dmdlic</code>.</p>

                        <div class="dmd-license-summary-grid">
                            <div class="dmd-license-summary-card"><span>État</span><strong class="dmd-license-state"><?= htmlspecialchars(dmd_admin_license_state_label($dmdLicenseStatus['state'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Instance</span><strong><?= htmlspecialchars((string)($dmdLicenseStatus['instance_id'] ?? dmd_license_instance_id() ?: 'Indisponible'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Licence</span><strong><?= htmlspecialchars((string)(($dmdLicenseStatus['license_id'] ?? '') ?: 'Aucune licence signée'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Valide jusqu’au</span><strong><?= htmlspecialchars((string)(($dmdLicenseStatus['valid_until'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                        </div>

                        <?php if ((string)($dmdLicenseStatus['source'] ?? '') === 'launch'): ?>
                            <div class="dmd-license-order-note"><strong>🎁 Offre de lancement active jusqu’en janvier 2027.</strong><br><span class="pe-note">Les licences commerciales seront disponibles à partir de janvier 2027. Le centre de commande affiche déjà les tarifs.</span></div>
                        <?php elseif ((string)($dmdLicenseStatus['state'] ?? '') === 'license_required'): ?>
                            <div class="dmd-license-order-note"><strong>Licence requise.</strong><br><span class="pe-note">Installez un fichier signé pour réactiver les fonctions commerciales.</span></div>
                        <?php endif; ?>

                        <div class="tablewrap">
                            <table class="dmd-license-products">
                                <thead><tr><th>Produit</th><th>Autorisé</th><th>Quota / droit</th></tr></thead>
                                <tbody>
                                    <tr><td>DMD-Remote</td><td><?= !empty($dmdLicenseAgent['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseAgent['remote_targets_max'] ?? 0, 'PC'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-MyDesk</td><td><?= !empty($dmdLicenseMyDesk['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseMyDesk['modules_max'] ?? 0, 'modules'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-Instances</td><td><?= !empty($dmdLicenseInstances['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseInstances['instances_max'] ?? 0, 'instances'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-Ticketing — Réception Support</td><td><?= !empty($dmdTicketingLicense['enabled']) ? 'Oui' : 'Non' ?></td><td><?= !empty($dmdTicketingLicense['enabled']) ? htmlspecialchars(dmd_admin_license_quota($dmdTicketingLicense['clients_max'] ?? -1, 'clients'), ENT_QUOTES, 'UTF-8') : 'Non activé' ?></td></tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="dmd-license-tools">
                            <div class="dmd-license-box">
                                <h3>Installer / remplacer une licence</h3>
                                <p class="pe-note">La signature Ed25519 et l’ID de cette instance sont contrôlés avant écriture. Une sauvegarde de l’ancienne licence est créée automatiquement.</p>
                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" enctype="multipart/form-data" class="dmd-license-upload">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="file" name="license_file" accept=".dmdlic,application/json" required>
                                    <button type="submit" class="btn" name="install_dmd_license" value="1">📥 Installer</button>
                                </form>
                                <?php if ($dmdLicenseHasSignedFile): ?>
                                    <div class="dmd-license-hash" style="margin-top:9px">SHA-256 : <?= is_file($dmdLicenseEngineFile) ? htmlspecialchars(strtoupper(hash_file('sha256', $dmdLicenseEngineFile)), ENT_QUOTES, 'UTF-8') : '—' ?></div>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" style="margin-top:9px" onsubmit="return confirm('Retirer la licence signée actuelle ? Une sauvegarde sera conservée.');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="btn" name="remove_dmd_license" value="1">🗑️ Retirer la licence</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="dmd-license-box">
                                <h3>Commander des licences</h3>
                                <p class="pe-note">Instances, Remote, MyDesk et DMD-Ticketing externe. Les tarifs sont visibles dès maintenant ; les commandes sont bloquées jusqu’à janvier 2027.</p>
                                <div class="dmd-license-order-note"><strong>DMD-Ticketing externe : 249 € HT / an</strong></div>
                                <a class="btn" href="<?= htmlspecialchars($dmdLicenseOrderHref, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer">🛒 Voir les licences et préparer une commande</a>
                            </div>
                        </div>

                        <?php if ($dmdTicketingAvailable): ?>
                        <div class="dmd-ticketing-license-admin">
                            <div class="dmd-ticketing-license-head">
                                <div>
                                    <h3>🎫 DMD-Ticketing — Récepteur Support</h3>
                                    <p class="pe-note">Cette partie existe sur tous les DoMyDesk mais reste réservée au superadmin. Le DoMyDesk Client n’a besoin d’aucune licence pour envoyer un ticket : il importe uniquement le fichier créé ici par son Support.</p>
                                </div>
                                <span class="dmd-ticketing-license-badge <?= !empty($dmdTicketingLicense['enabled']) ? 'is-ok' : 'is-off' ?>"><?= !empty($dmdTicketingLicense['enabled']) ? ((($dmdTicketingLicense['source'] ?? '') === 'launch') ? 'Lancement gratuit' : 'Licence active') : 'Licence requise' ?></span>
                            </div>

                            <?php if (!empty($dmdTicketingLicense['enabled'])): ?>
                                <div class="dmd-license-order-note">
                                    <strong><?= (($dmdTicketingLicense['source'] ?? '') === 'launch') ? '🎁 Réception gratuite jusqu’au 1er janvier 2027' : '✅ Réception externe autorisée' ?></strong><br>
                                    <span class="pe-note">Entreprises clientes actives : <?= (int)$dmdTicketingActiveClients ?> / <?= $dmdTicketingClientsMax < 0 ? 'Illimité' : (int)$dmdTicketingClientsMax ?>. La période de lancement est limitée à 5 clients.</span>
                                </div>

                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" class="dmd-ticketing-support-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label class="dmd-ticketing-switch"><input type="checkbox" name="dmd_ticketing_support_enabled" value="1" <?= !empty($dmdTicketingReceive['enabled']) ? 'checked' : '' ?>> <span>Activer ce DoMyDesk comme récepteur Support</span></label>
                                    <div class="dmd-ticketing-form-grid">
                                        <label><span>Nom de l’entreprise Support</span><input type="text" name="dmd_ticketing_support_name" value="<?= htmlspecialchars((string)($dmdTicketingReceive['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex. SynoHomes" required></label>
                                        <label class="is-wide">
                                            <span>Adresse publique du DoMyDesk Support</span>
                                            <input type="text" name="dmd_ticketing_support_endpoint" value="<?= htmlspecialchars($dmdTicketingSupportBaseUrl, ENT_QUOTES, 'UTF-8') ?>" placeholder="https://support.exemple.fr/domydesk/" required>
                                            <small class="pe-note">Indiquez uniquement l’adresse racine de DoMyDesk, par exemple <code>https://support.exemple.fr/domydesk/</code>. Le chemin DMD-Ticketing est ajouté automatiquement et n’a pas besoin d’être communiqué.</small>
                                        </label>
                                    </div>
                                    <div class="dmd-security-actions"><button type="submit" class="btn" name="dmd_ticketing_support_save" value="1">💾 Enregistrer le récepteur</button></div>
                                </form>

                                <?php if (!empty($dmdTicketingReceive['token'])): ?>
                                <div class="dmd-ticketing-master-key">
                                    <div><strong>Clé maître de liaison</strong><div class="pe-note">Créée une seule fois et conservée chiffrée. Elle est commune aux fichiers clients, mais chaque client possède en plus son propre jeton. Le renouvellement annuel de licence ne change jamais cette clé.</div></div>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Régénérer la clé maître ? Tous les fichiers .dmdticketlink déjà distribués devront être régénérés et réimportés chez les clients.');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="btn" name="dmd_ticketing_support_key_regenerate" value="1">⚠️ Régénérer la clé maître</button>
                                    </form>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($dmdTicketingReceive['enabled'])): ?>
                                <div class="dmd-ticketing-client-create">
                                    <h3>Ajouter une entreprise cliente</h3>
                                    <p class="pe-note">Le Support crée obligatoirement la liaison. Indiquez l’ID unique du DoMyDesk installé chez le client ; le fichier généré sera inutilisable sur une autre instance.</p>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" class="dmd-ticketing-form-grid">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <label><span>Nom de l’entreprise cliente</span><input type="text" name="dmd_ticketing_client_name" placeholder="Ex. Garage Dupont" required></label>
                                        <label><span>ID unique DoMyDesk client</span><input type="text" name="dmd_ticketing_client_instance" placeholder="DmD-..." required></label>
                                        <div class="is-wide dmd-security-actions"><button type="submit" class="btn" name="dmd_ticketing_client_create" value="1" <?= ($dmdTicketingClientsMax >= 0 && $dmdTicketingActiveClients >= $dmdTicketingClientsMax) ? 'disabled' : '' ?>>➕ Créer le client</button></div>
                                    </form>
                                </div>
                                <?php endif; ?>

                                <div class="dmd-ticketing-clients">
                                    <h3>Entreprises clientes</h3>
                                    <?php if (!$dmdTicketingClients): ?>
                                        <p class="pe-note">Aucune entreprise cliente enregistrée.</p>
                                    <?php else: ?>
                                        <?php foreach ($dmdTicketingClients as $tkClient): $tkStatus=(string)($tkClient['status']??'active'); $tkUid=(string)($tkClient['instance_uid']??''); ?>
                                        <div class="dmd-ticketing-client-row <?= $tkStatus === 'revoked' ? 'is-revoked' : '' ?>">
                                            <div class="dmd-ticketing-client-info">
                                                <strong><?= htmlspecialchars((string)($tkClient['client_name'] ?? $tkUid), ENT_QUOTES, 'UTF-8') ?></strong>
                                                <span><code><?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?></code> · <?= htmlspecialchars((string)($tkClient['client_ref'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
                                                <small><?= $tkStatus === 'revoked' ? 'Révoquée' : 'Active' ?><?= !empty($tkClient['last_seen_at']) ? ' · Dernier contact : '.htmlspecialchars((string)$tkClient['last_seen_at'], ENT_QUOTES, 'UTF-8') : '' ?></small>
                                            </div>
                                            <div class="dmd-security-actions">
                                                <?php if ($tkStatus === 'active'): ?>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_download" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">⬇️ Fichier .dmdticketlink</button>
                                                </form>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Régénérer uniquement le jeton de ce client ? Son ancien fichier cessera de fonctionner.');">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_token_regenerate" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">🔄 Jeton</button>
                                                </form>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Révoquer cette entreprise cliente ? Ses envois et téléchargements distants seront immédiatement refusés.');">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_revoke" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">🚫 Révoquer</button>
                                                </form>
                                                <?php else: ?>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_reactivate" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">✅ Réactiver</button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="dmd-license-order-note"><strong>Récepteur désactivé.</strong><br><span class="pe-note">L’envoi Client reste gratuit et fonctionnel avec un fichier de liaison valide. Seule la réception Support est soumise à la licence DMD-Ticketing.</span></div>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                            <div class="dmd-license-order-note"><strong>DMD-Ticketing non installé.</strong><br><span class="pe-note">La gestion du récepteur apparaîtra ici lorsque le module DMD-Ticketing sera présent.</span></div>
                        <?php endif; ?>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>🛡️ Droits des modules</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Rôles métier, exceptions utilisateurs et permissions fines des modules.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-module-rights')">Ouvrir les droits des modules</button></div>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>📄 Pages accessibles</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Accès aux pages par rôle métier et exceptions utilisateurs.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-page-rights')">Ouvrir les pages accessibles</button></div>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>🔧 Maintenance</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">ID DoMyDesk, permissions et synchronisation DomyCo. La gestion DMD-Agent n’est plus dupliquée ici.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-site-maintenance')">Ouvrir la maintenance</button></div>
                    </div>
                </details>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div id="popup-core-interface" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Outils Core & dashboards</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-core-interface' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Réglages enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-core-interface' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <form method="post" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="save_core_interface" value="1">

                <datalist id="dmd-core-tool-icons">
                    <option value="⚡"></option>
                    <option value="🚨"></option>
                    <option value="🧰"></option>
                    <option value="🚀"></option>
                    <option value="🎯"></option>
                    <option value="🛠️"></option>
                    <option value="🔧"></option>
                    <option value="▶️"></option>
                    <option value="⏱️"></option>
                    <option value="💡"></option>
                </datalist>

                <div class="pe-form-row">
                    <div>
                        <h3><?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?> ActionHub</h3>
                        <label style="display:flex;align-items:center;gap:10px;">
                            <input type="checkbox" name="actionhub_enabled" value="1" <?= !empty($settings['core_tools']['actionhub']['enabled']) ? 'checked' : '' ?>>
                            Activé globalement
                        </label>
                        <label>Emplacement par défaut</label>
                        <select name="actionhub_default_location">
                            <?php $ahDefaultLocation = (string)$settings['core_tools']['actionhub']['default_location']; ?>
                            <option value="header" <?= $ahDefaultLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $ahDefaultLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $ahDefaultLocation === 'hidden' ? 'selected' : '' ?>>Masqué par défaut</option>
                        </select>
                        <label>Icône</label>
                        <input type="text" name="actionhub_icon" list="dmd-core-tool-icons" maxlength="16" value="<?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?>" placeholder="⚡">
                    </div>

                    <div>
                        <h3><?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?> Quick-Session</h3>
                        <label style="display:flex;align-items:center;gap:10px;">
                            <input type="checkbox" name="quick_session_enabled" value="1" <?= !empty($settings['core_tools']['quick_session']['enabled']) ? 'checked' : '' ?>>
                            Activé globalement
                        </label>
                        <label>Emplacement par défaut</label>
                        <?php $qsDefaultLocation = (string)$settings['core_tools']['quick_session']['default_location']; ?>
                        <select name="quick_session_default_location">
                            <option value="header" <?= $qsDefaultLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $qsDefaultLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $qsDefaultLocation === 'hidden' ? 'selected' : '' ?>>Masqué par défaut</option>
                        </select>
                        <label>Icône</label>
                        <input type="text" name="quick_session_icon" list="dmd-core-tool-icons" maxlength="16" value="<?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?>" placeholder="🚨">
                    </div>
                </div>

                <hr>

                <div>
                    <label>Nombre maximum de dashboards par utilisateur</label>
                    <input type="number" min="0" step="1" name="dashboard_limit" value="<?= (int)$settings['dashboard_limit'] ?>">
                    <p class="pe-note"><strong>0 = illimité.</strong> La même règle est utilisée par la création manuelle et par ActionHub.</p>
                </div>

                <p class="pe-note">Si un outil est désactivé ici, aucun utilisateur ne peut le réactiver depuis son profil. Le choix utilisateur ne porte que sur l’emplacement ou le masquage lorsque l’outil est autorisé globalement.</p>

                <div class="pe-actions">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-site-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Paramètres du site</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-site-settings' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Paramètres enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-site-settings' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>
            <form method="post" accept-charset="UTF-8" enctype="multipart/form-data" class="pe-form">
                <div><label>Nom du site</label><input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>

                <div>
                    <label for="site_language">Langue de DoMyDesk</label>
                    <select name="site_language" id="site_language" <?= empty($availableLanguages) ? 'disabled' : '' ?>>
                        <?php if (empty($availableLanguages)): ?>
                            <option value="">Aucun dossier de langue installé dans /lang/</option>
                        <?php else: ?>
                            <?php foreach ($availableLanguages as $languageFolder => $languageLabel): ?>
                                <option
                                    value="<?= htmlspecialchars((string)$languageFolder, ENT_QUOTES, 'UTF-8') ?>"
                                    <?= (($settings['language'] ?? '') === $languageFolder) ? 'selected' : '' ?>
                                >
                                    <?= htmlspecialchars((string)$languageLabel, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <p class="pe-note">Seulement les textes du système seront traduis dans la langue choisie.</p>
                </div>
<br>
                <div class="pe-form-row">
                    <div>
                        <label>Avatar / logo actuel du site</label>
                        <?php
                        $siteLogoFile = dmd_site_asset_file($settings, 'logo_path');
                        $siteLogoUrl = $siteLogoFile !== '' ? dmd_media_public_url($siteLogoFile) : '';
                        ?>
                        <?php if ($siteLogoUrl !== ''): ?>
                            <br><img class="logo-preview" src="<?= htmlspecialchars($siteLogoUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Avatar du site">
                        <?php else: ?>
                            <p class="pe-note">Aucun avatar/logo.</p>
                        <?php endif; ?><br>
                        <input type="file" name="logo" accept="image/*,.svg"><br>
                        <?php if ($siteLogoUrl !== ''): ?><br>
                            <label><input type="checkbox" name="remove_site_logo" value="1"> Supprimer l’avatar/logo actuel</label>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label>Bannière actuelle du site</label>
                        <?php
                        $siteBannerFile = dmd_site_asset_file($settings, 'banner_path');
                        $siteBannerUrl = $siteBannerFile !== '' ? dmd_media_public_url($siteBannerFile) : '';
                        ?>
                        <?php if ($siteBannerUrl !== ''): ?>
                            <br><img src="<?= htmlspecialchars($siteBannerUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Bannière du site" style="width:100%;max-width:420px;height:110px;object-fit:cover;border:1px solid var(--border-color);border-radius:var(--radius,14px);">
                        <?php else: ?>
                            <p class="pe-note">Aucune bannière. Les utilisateurs sans bannière personnelle n’en afficheront pas.</p>
                        <?php endif; ?>
                        <input type="file" name="site_banner" accept="image/*,.svg">
                        <?php if ($siteBannerUrl !== ''): ?>
                            <label><input type="checkbox" name="remove_site_banner" value="1"> Supprimer la bannière actuelle</label>
                        <?php endif; ?>
                    </div>
                </div>
<br>
                <div><br>
                    <label>Image en haut du menu vertical</label>
                    <?php $brandModeCurrent = (string)($settings['vertical_menu_brand_mode'] ?? 'none'); ?>
                    <div class="pe-actions" style="justify-content:flex-start;">
                        <label><input type="radio" name="vertical_menu_brand_mode" value="none" <?= $brandModeCurrent === 'none' ? 'checked' : '' ?>> Aucune</label>
                        <label title="<?= $siteLogoUrl === '' ? 'Ajoute d’abord un avatar/logo du site.' : '' ?>">
                            <input type="radio" name="vertical_menu_brand_mode" value="avatar" <?= $brandModeCurrent === 'avatar' ? 'checked' : '' ?> <?= $siteLogoUrl === '' ? 'disabled' : '' ?>> Avatar
                        </label>
                        <label title="<?= $siteBannerUrl === '' ? 'Ajoute d’abord une bannière du site.' : '' ?>">
                            <input type="radio" name="vertical_menu_brand_mode" value="banner" <?= $brandModeCurrent === 'banner' ? 'checked' : '' ?> <?= $siteBannerUrl === '' ? 'disabled' : '' ?>> Bannière
                        </label>
                    </div>
                    <p class="pe-note">Une option sans image n’est pas sélectionnable.</p>
                </div><br>

                <h3>Menu horizontal du header</h3>
                <p class="pe-note">Ajoute une page interne ou un lien externe. L’icône doit venir de la liste.</p>
                <datalist id="dmd-pages-list">
                    <?php foreach ($pagesScan as $pageOption): ?>
                        <option value="/domydesk/<?= htmlspecialchars($pageOption, ENT_QUOTES, 'UTF-8') ?>"></option>
                    <?php endforeach; ?>
                    <option value="/domydesk/dashboard.php"></option>
                    <option value="/domydesk/index.php"></option>
                    <option value="/domydesk/profile_view.php"></option>
                    <option value="/domydesk/login.php"></option>
                    <option value="/domydesk/logout.php"></option>
                    <option value="/domydesk/adm/site_settings.php"></option>
                </datalist>

                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th class="dmd-menu-order-col" title="Glisser pour changer l’ordre">Ordre</th>
                                <th>Titre</th>
                                <th>Emoji</th>
                                <th>Type</th>
                                <th>Page ou lien</th>
                                <th>Supprimer</th>
                            </tr>
                        </thead>
                        <tbody id="dmd-horizontal-menu-body">
                            <?php
                            $menuRows = $settings['menu_horizontal'] ?? dmd_default_horizontal_menu();
                            if (!is_array($menuRows)) $menuRows = dmd_default_horizontal_menu();
                            for ($emptyRow = 0; $emptyRow < 5; $emptyRow++) {
                                $menuRows[] = ['title' => '', 'icon' => '⭐', 'url' => '', 'type' => 'page'];
                            }
                            foreach ($menuRows as $idx => $menuItem):
                                if (!is_array($menuItem)) $menuItem = [];
                                $miTitle = (string)($menuItem['title'] ?? '');
                                $miIcon = (string)($menuItem['icon'] ?? '⭐');
                                $miType = ((string)($menuItem['type'] ?? 'page')) === 'external' ? 'external' : 'page';
                                $miUrl = (string)($menuItem['url'] ?? '');
                            ?>
                                <tr class="dmd-menu-row">
                                    <td class="dmd-menu-order-col">
                                        <button type="button" class="dmd-menu-drag-handle" draggable="true" title="Maintenir et glisser pour déplacer cette ligne" aria-label="Déplacer cette entrée">☰</button>
                                    </td>
                                    <td><input type="text" name="menu_title[<?= (int)$idx ?>]" value="<?= htmlspecialchars($miTitle, ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex : Dashboard"></td>
                                    <td>
                                        <select name="menu_icon[<?= (int)$idx ?>]">
                                            <?php foreach ($dmdHorizontalMenuEmojis as $emoji): ?>
                                                <option value="<?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?>" <?= $emoji === $miIcon ? 'selected' : '' ?>><?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="menu_type[<?= (int)$idx ?>]">
                                            <option value="page" <?= $miType === 'page' ? 'selected' : '' ?>>Page</option>
                                            <option value="external" <?= $miType === 'external' ? 'selected' : '' ?>>Lien externe</option>
                                        </select>
                                    </td>
                                    <td><input type="text" name="menu_url[<?= (int)$idx ?>]" list="dmd-pages-list" value="<?= htmlspecialchars($miUrl, ENT_QUOTES, 'UTF-8') ?>" placeholder="/domydesk/page.php ou https://..."></td>
                                    <td><input type="checkbox" name="menu_delete[<?= (int)$idx ?>]" value="1"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pe-actions"><button name="save_site">Enregistrer</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-site-maintenance" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Maintenance</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($idDoMyDesk): ?>
                <p class="pe-note">ID DoMyDesk : <strong><?= htmlspecialchars($idDoMyDesk) ?></strong></p>
                <p><a class="btn" href="/domydesk/data/id_domydesk.txt" download>Sauvegarder l’ID</a></p>
            <?php else: ?>
                <p class="pe-note">Aucun ID DoMyDesk trouvé.</p>
            <?php endif; ?>

            <p><a href="../adm/fix_all_rights.php" target="_blank" class="btn">Accorder les permissions</a></p>

            <hr>

            <h3>Synchronisation DomyCo</h3>

            <?php if ($reopenPopup === 'popup-site-maintenance' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Réglage DomyCo enregistré.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-site-maintenance' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <label>
                    <input type="checkbox" name="domyco_heartbeat_enabled" value="1" <?= $heartbeatEnabled ? 'checked' : '' ?>>
                    Activer la synchronisation automatique avec DomyCo
                </label>

                <p class="pe-note">
                    Quand elle est activée, DoMyDesk maintient le heartbeat à <strong>5 minutes</strong> tant qu’une session est ouverte.
                    L’envoi est non bloquant et se relance automatiquement, y compris lorsque vous restez sur le même dashboard.
                </p>

                <div class="pe-actions">
                    <button type="submit" name="save_domyco_heartbeat" value="1">Enregistrer</button>
                </div><br>
            </form>

            <div class="pe-msg">
                <div><strong>État :</strong> <?= $heartbeatEnabled ? 'Activé' : 'Désactivé' ?></div>
                <div><strong>Dernière tentative :</strong> <?= htmlspecialchars($heartbeatLastAttemptText, ENT_QUOTES, 'UTF-8') ?></div>
                <div><strong>Prochaine tentative automatique :</strong> <?= $heartbeatEnabled ? htmlspecialchars($heartbeatNextText, ENT_QUOTES, 'UTF-8') : 'Désactivée' ?></div>
                <?php if ($heartbeatLastAttempt > 0): ?>
                    <div><strong>Dernier résultat :</strong>
                        <?php if (!empty($heartbeatLast['skipped'])): ?>
                            <?= htmlspecialchars((string)($heartbeatLast['reason'] ?? 'Ignoré'), ENT_QUOTES, 'UTF-8') ?>
                        <?php elseif ($heartbeatLastSuccess): ?>
                            OK<?= $heartbeatLastHttp ? ' — HTTP ' . (int)$heartbeatLastHttp : '' ?>
                        <?php else: ?>
                            Échec<?= $heartbeatLastHttp ? ' — HTTP ' . (int)$heartbeatLastHttp : '' ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="pe-actions">
                    <button type="submit" name="send_domyco_heartbeat_now" value="1">Envoyer maintenant</button>
                </div>
                <p class="pe-note">L’envoi manuel fonctionne même si la synchronisation automatique est désactivée.</p>
            </form>
        </div>
    </div>
</div>

<div id="popup-index-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Reglages page d'accueil</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/indexcfg.php" title="Reglages page d'accueil DoMyDesk" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<?php if ($isSuperadmin): ?>
<div id="popup-system-logs" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Logs système</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="system_logs.php" title="Logs système" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-updates" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Mises à jour système</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="updates.php" title="Mises à jour système" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-module-updates" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Mise à jour des modules</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="module_updates.php" title="Mise à jour des modules" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>
<?php endif; ?>

<div id="popup-news" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Actualités</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php include $baseDir . "/data/news/newscfg.php"; ?>
        </div>
    </div>
</div>

<div id="popup-theme-market" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Market des themes</h2>
            <div style="display:flex;gap:8px;align-items:center">
                <form method="post" action="?open=popup-theme-market" style="margin:0">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                    <button type="submit" name="refresh_theme_catalog" value="1" title="Rafraîchir immédiatement depuis GitHub">↻ Rafraîchir</button>
                </form>
                <button type="button" data-popup-close>Fermer</button>
            </div>
        </div>

        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-theme-market' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Catalogue rafraîchi.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-theme-market' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>
            <?php if ($themeMarketRaw === false): ?>
                <div class="pe-msg pe-msg-error">Impossible de charger le catalogue des themes : <?= htmlspecialchars($themeMarketWhy) ?></div>

            <?php elseif (!$themeMarketItems): ?>
                <div class="pe-msg pe-msg-error">Catalogue des themes vide ou JSON invalide.</div>

            <?php else: ?>

                <div class="mods-grid theme-market-grid">
                    <?php foreach ($themeMarketItems as $themeItem):
                        if (!is_array($themeItem)) continue;

                        $tmName = trim((string)($themeItem['name'] ?? 'Theme'));
                        $tmDate = trim((string)($themeItem['date'] ?? ''));
                        $tmDesc = trim((string)($themeItem['description'] ?? ''));
                        $tmImage = dmd_theme_github_to_raw((string)($themeItem['image'] ?? ''));
                        $tmDl = dmd_theme_github_to_raw((string)($themeItem['dl'] ?? ''));
                        $tmSize = trim((string)($themeItem['size'] ?? ''));
                        $tmFolder = dmd_theme_folder_from_url($tmDl, $tmName);
                        $tmInstalled = $tmFolder !== '' && in_array($tmFolder, $installedThemes, true);
                    ?>

                        <div class="mod-card theme-market-card">

                            <?php if ($tmImage): ?>
                                <img
                                    src="<?= htmlspecialchars($tmImage, ENT_QUOTES, 'UTF-8') ?>"
                                    alt="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>"
                                    class="mod-thumb theme-market-thumb"
                                    title="Cliquer pour agrandir"
                                    onclick='openThemePreview(
                                        <?= json_encode($tmImage, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>,
                                        <?= json_encode($tmName, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
                                    )'
                                >
                            <?php endif; ?>

                            <div class="mod-meta">
                                <div class="mod-name" title="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>
                                </div>

                                <div class="mod-id">
                                    Dossier : <?= htmlspecialchars($tmFolder ?: '-', ENT_QUOTES, 'UTF-8') ?>
                                    <?php if ($tmDate): ?> · <?= htmlspecialchars($tmDate, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                    <?php if ($tmSize): ?> · <?= htmlspecialchars($tmSize, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                </div>

                                <?php if ($tmDesc): ?>
                                    <p class="pe-note"><?= htmlspecialchars($tmDesc, ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>

                                <?php if ($tmInstalled): ?>
                                    <p class="pe-note"><strong>Déjà installé</strong></p>
                                <?php endif; ?>
                            </div>

                            <?php if ($tmDl): ?>
                                <form method="post" accept-charset="UTF-8" class="pe-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_name" value="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_dl" value="<?= htmlspecialchars($tmDl, ENT_QUOTES, 'UTF-8') ?>">
                                    <button type="submit" name="install_theme_market" value="1">
                                        <?= $tmInstalled ? 'Réinstaller' : 'Installer' ?>
                                    </button>
                                </form>
                            <?php else: ?>
                                <p class="pe-note">Lien ZIP manquant.</p>
                            <?php endif; ?>

                        </div>

                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-theme-preview" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2 id="theme-preview-title">Aperçu du thème</h2>
            <button type="button" onclick="closeThemePreview()">Fermer</button>
        </div>

        <div class="pe-popup-body theme-preview-body">
            <img id="theme-preview-img" src="" alt="" class="theme-preview-img">
        </div>
    </div>
</div>

<?php if ($isSuperadmin): ?>
<div id="popup-unofficial-themes" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Thèmes non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/unofficial_themes.php" title="Thèmes non officiels" style="width:100%;height:72vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-unofficial-modules" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Modules non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/unofficial_modules.php" title="Modules non officiels" style="width:100%;height:72vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>
<?php endif; ?>

<div id="popup-market-inline" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide market-modal">
        <div class="pe-popup-head market-head"><h2>Installer un module</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/marketmodules.php" title="Market DoMyDesk"></iframe>
        </div>
    </div>
</div>

<div id="popup-module-rights" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Droits sur les modules</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-module-rights' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Droits enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-module-rights' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <p>
            </p>

            <div class="dmd-rights-catalog-head">
                <div>
                    <h3>Tous les modules</h3>
                    <p class="pe-note">Cocher « Tout le monde » pour un accès global, ou ouvrir « Paramétrer » pour gérer les groupes et les utilisateurs.</p><br>
                </div>
                <span class="dmd-rights-module-count"><?= count($permissionModules) ?> module<?= count($permissionModules) > 1 ? 's' : '' ?></span>
            </div>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="global-module-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <?php if (!empty($permissionModules)): ?>
                    <div class="dmd-rights-card-grid">
                        <?php foreach ($permissionModules as $moduleId => $moduleInfo):
                            $moduleAccessMode = dmd_module_access_mode($moduleId);
                            $moduleName = (string)($moduleInfo['name'] ?? $moduleId);
                            $moduleDescription = trim((string)($moduleInfo['description'] ?? ''));
                        ?>
                            <article class="dmd-rights-card" data-global-module-card="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                                <div class="dmd-rights-card-main">
                                    <img
                                        class="dmd-rights-card-icon"
                                        src="../modules/<?= rawurlencode($moduleId) ?>/icon.png"
                                        alt=""
                                        onerror="this.hidden=true"
                                    >
                                    <div class="dmd-rights-card-copy">
                                        <strong><?= htmlspecialchars($moduleName, ENT_QUOTES, 'UTF-8') ?></strong>
                                        <?php if ($moduleDescription !== ''): ?>
                                            <small title="<?= htmlspecialchars($moduleDescription, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($moduleDescription, ENT_QUOTES, 'UTF-8') ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="dmd-rights-card-actions">
                                    <label class="dmd-rights-everyone">
                                        <input
                                            type="checkbox"
                                            name="global_modules[]"
                                            value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                            data-global-module="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                            <?= $moduleAccessMode === 'everyone' ? 'checked' : '' ?>
                                        >
                                        <span>Tout le monde</span>
                                    </label>

                                    <button
                                        type="button"
                                        class="dmd-rights-config-button"
                                        data-popup-open="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                        aria-haspopup="dialog"
                                        aria-controls="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    >⚙ Paramétrer</button>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pe-note">Aucun module installé pour le moment.</p>
                <?php endif; ?>
<br>
                <div class="pe-actions dmd-rights-global-save">
                    <button type="submit" name="save_global_module_rights" value="1">Enregistrer « Tout le monde »</button>
                </div>
            </form>

            <!-- Formulaires maîtres invisibles : les contrôles des popups y sont rattachés avec form="...". -->
            <form method="post" accept-charset="UTF-8" id="role-module-rights-form" class="dmd-rights-master-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="rights_role" id="moduleRightsRole" required>
                    <?php foreach ($metiers as $m): ?>
                        <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>" <?= $selectedRightsRole === $m ? 'selected' : '' ?>>
                            <?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>

            <form method="post" accept-charset="UTF-8" id="user-module-exceptions-form" class="dmd-rights-master-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="rights_user" id="moduleRightsUser" required>
                    <option value="">Sélectionner une personne</option>
                    <?php foreach ($users as $u):
                        $uProfile = $userProfiles[$u] ?? [];
                        $uName = trim((string)($uProfile['prenom'] ?? '') . ' ' . (string)($uProfile['nom'] ?? ''));
                        $uRole = (string)($uProfile['role_metier'] ?? '');
                    ?>
                        <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>" <?= $selectedRightsUser === $u ? 'selected' : '' ?>>
                            <?= htmlspecialchars(($uName !== '' ? $uName . ' — ' : '') . $u . ($uRole !== '' ? ' (' . $uRole . ')' : ''), ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="save_user_module_exceptions" value="1" id="saveUserModuleExceptions" hidden disabled>Enregistrer</button>
            </form>
        </div>
    </div>
</div>

<?php foreach ($permissionModules as $moduleId => $moduleInfo):
    $permissionGroups = dmd_module_permission_groups($moduleId);
    $moduleName = (string)($moduleInfo['name'] ?? $moduleId);
?>
<div id="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>" class="pe-popup dmd-module-config-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2><?= htmlspecialchars($moduleName, ENT_QUOTES, 'UTF-8') ?> — Paramétrer les droits</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <div class="dmd-rights-config-columns">
                <section class="dmd-rights-config-section">
                    <div class="dmd-rights-config-title">
                        <div>
                            <strong>👥 Groupe / rôle métier</strong>
                            <small>Définis les droits par défaut du groupe.</small>
                        </div>
                    </div>

                    <label class="dmd-rights-field">
                        <span>Groupe / rôle métier</span>
                        <select data-module-role-select="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <?php foreach ($metiers as $m): ?>
                                <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label class="dmd-rights-access-line">
                        <input
                            type="checkbox"
                            name="role_modules[]"
                            value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            data-rights-role-module="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            form="role-module-rights-form"
                        >
                        <span>Autoriser ce groupe à utiliser le module</span>
                    </label>

                    <?php if (!empty($permissionGroups)): ?>
                        <div class="dmd-rights-action-zone" data-role-permission-details="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <label class="dmd-permission-all">
                                <input
                                    type="checkbox"
                                    name="role_all_modules[]"
                                    value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-role-all="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    form="role-module-rights-form"
                                >
                                <span><strong>Tous les droits</strong><small>Contrôle complet de ce module.</small></span>
                            </label>

                            <?php foreach ($permissionGroups as $permissionGroup => $permissionDefinitions): ?>
                                <div class="dmd-permission-group">
                                    <div class="dmd-permission-group-title"><?= htmlspecialchars($permissionGroup, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="dmd-permission-grid">
                                        <?php foreach ($permissionDefinitions as $permissionId => $permissionDefinition): ?>
                                            <label class="dmd-permission-item<?= !empty($permissionDefinition['dangerous']) ? ' is-dangerous' : '' ?>">
                                                <input
                                                    type="checkbox"
                                                    name="role_permission_tokens[]"
                                                    value="<?= htmlspecialchars($moduleId . '|' . $permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-rights-role-permission="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-permission-id="<?= htmlspecialchars($permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    form="role-module-rights-form"
                                                >
                                                <span><strong><?= htmlspecialchars($permissionDefinition['label'] ?? $permissionId, ENT_QUOTES, 'UTF-8') ?></strong></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="dmd-rights-legacy-note">Ce module ne déclare pas encore de droits fins : l’accès au module donne son fonctionnement complet historique.</div>
                    <?php endif; ?>

                    <div class="pe-actions">
                        <button type="submit" name="save_role_module_rights" value="1" form="role-module-rights-form">Enregistrer le groupe</button>
                    </div>
                </section>

                <section class="dmd-rights-config-section">
                    <div class="dmd-rights-config-title">
                        <div>
                            <strong>👤 Utilisateur</strong>
                            <small>Ajoute une exception individuelle au-dessus des droits du groupe.</small>
                        </div>
                    </div>

                    <label class="dmd-rights-field">
                        <span>Utilisateur</span>
                        <select data-module-user-select="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <option value="">Sélectionner une personne</option>
                            <?php foreach ($users as $u):
                                $uProfile = $userProfiles[$u] ?? [];
                                $uName = trim((string)($uProfile['prenom'] ?? '') . ' ' . (string)($uProfile['nom'] ?? ''));
                                $uRole = (string)($uProfile['role_metier'] ?? '');
                            ?>
                                <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars(($uName !== '' ? $uName . ' — ' : '') . $u . ($uRole !== '' ? ' (' . $uRole . ')' : ''), ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <div class="dmd-rights-user-summary" data-rights-effective="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">Sélectionne une personne</div>

                    <label class="dmd-rights-field">
                        <span>Exception</span>
                        <select
                            name="user_override_state[]"
                            data-rights-user-override="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            form="user-module-exceptions-form"
                            disabled
                        >
                            <option value="<?= htmlspecialchars($moduleId . '|inherit', ENT_QUOTES, 'UTF-8') ?>">Comme son groupe</option>
                            <option value="<?= htmlspecialchars($moduleId . '|allow', ENT_QUOTES, 'UTF-8') ?>">Toujours autoriser</option>
                            <option value="<?= htmlspecialchars($moduleId . '|deny', ENT_QUOTES, 'UTF-8') ?>">Toujours refuser</option>
                        </select>
                    </label>

                    <?php if (!empty($permissionGroups)): ?>
                        <div class="dmd-rights-action-zone" data-user-permission-details="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <label class="dmd-permission-all">
                                <input
                                    type="checkbox"
                                    name="user_all_modules[]"
                                    value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-user-all="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    form="user-module-exceptions-form"
                                    disabled
                                >
                                <span><strong>Tous les droits</strong><small>Exception personnelle avec contrôle complet.</small></span>
                            </label>

                            <?php foreach ($permissionGroups as $permissionGroup => $permissionDefinitions): ?>
                                <div class="dmd-permission-group">
                                    <div class="dmd-permission-group-title"><?= htmlspecialchars($permissionGroup, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="dmd-permission-grid">
                                        <?php foreach ($permissionDefinitions as $permissionId => $permissionDefinition): ?>
                                            <label class="dmd-permission-item<?= !empty($permissionDefinition['dangerous']) ? ' is-dangerous' : '' ?>">
                                                <input
                                                    type="checkbox"
                                                    name="user_permission_tokens[]"
                                                    value="<?= htmlspecialchars($moduleId . '|' . $permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-rights-user-permission="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-permission-id="<?= htmlspecialchars($permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    form="user-module-exceptions-form"
                                                    disabled
                                                >
                                                <span><strong><?= htmlspecialchars($permissionDefinition['label'] ?? $permissionId, ENT_QUOTES, 'UTF-8') ?></strong></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="dmd-rights-legacy-note">Sans droits fins déclarés, « Toujours autoriser » donne accès au module complet.</div>
                    <?php endif; ?>

                    <div class="pe-actions">
                        <button type="submit" name="save_user_module_exceptions" value="1" form="user-module-exceptions-form" data-user-save disabled>Enregistrer l’utilisateur</button>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<div id="popup-user-add" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head"><h2>Ajouter utilisateur</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="pe-form-row"><div><label>Prenom</label><input type="text" name="prenom" required></div><div><label>Nom</label><input type="text" name="nom" required></div></div>
                <div><label>Email</label><input type="email" name="email" required></div>
                <div class="pe-form-row"><div><label>Role interne</label><select name="role_metier" required><option value="" disabled selected>Selectionner</option><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></div><div><label>Role systeme</label><select name="role_system" required><option value="user">Utilisateur</option><option value="admin">Administrateur</option><?php if ($isSuperadmin): ?><option value="superadmin">Superadmin</option><?php endif; ?></select></div></div>
                <div><label>Mot de passe</label><input type="password" name="password" required></div>
                <div class="pe-actions"><button type="submit" name="add_user">Ajouter</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-user-roles" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Roles utilisateurs</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="table-wrap"><table class="roles-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Role systeme</th><th>Role metier</th><th>Action</th></tr></thead><tbody>
                    <?php foreach ($users as $mail):
                        $profile = $userProfiles[$mail] ?? [];
                        $prenom = $profile['prenom'] ?? $mail;
                        $nom = $profile['nom'] ?? '';
                        $roleSys = $profile['role_system'] ?? 'user';
                        $roleMetier = $profile['role_metier'] ?? '';
                    ?>
                    <tr>
                        <td><strong><?= htmlspecialchars(trim($prenom . ' ' . $nom)) ?></strong><br><a href="/domydesk/profile_view.php?email=<?= urlencode($mail) ?>">Voir profil</a></td>
                        <td><?= htmlspecialchars($mail) ?><?= $mail === $email ? '<br><strong>Vous</strong>' : '' ?></td>
                        <td>
                            <?php if ($roleSys === 'superadmin' && !$isSuperadmin): ?>
                                <strong>Superadmin</strong>
                                <input type="hidden" name="role_systems[<?= htmlspecialchars($mail) ?>]" value="superadmin">
                            <?php else: ?>
                                <select name="role_systems[<?= htmlspecialchars($mail) ?>]">
                                    <option value="user" <?= $roleSys === 'user' ? 'selected' : '' ?>>Utilisateur</option>
                                    <option value="admin" <?= $roleSys === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                                    <?php if ($isSuperadmin): ?><option value="superadmin" <?= $roleSys === 'superadmin' ? 'selected' : '' ?>>Superadmin</option><?php endif; ?>
                                </select>
                            <?php endif; ?>
                        </td>
                        <td><select name="role_metiers[<?= htmlspecialchars($mail) ?>]" <?= ($roleSys === 'superadmin' && !$isSuperadmin) ? 'disabled' : '' ?>><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>" <?= $m === $roleMetier ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></td>
                        <td>
                            <?php $canDeleteThis = $mail !== $email && ($roleSys !== 'superadmin' || ($isSuperadmin && $superadminTotal > 1)); ?>
                            <?php if ($canDeleteThis): ?><button type="submit" name="delete_user" value="<?= htmlspecialchars($mail) ?>" class="btn-del" onclick="return confirm('Supprimer définitivement <?= htmlspecialchars($mail) ?> ?')">Supprimer</button><?php else: ?>—<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody></table></div>
                <div class="pe-actions"><button type="submit" name="save_user_roles">Enregistrer les rôles</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-page-rights" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Pages accessibles</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-page-rights' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Droits des pages enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-page-rights' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <p class="pe-note">
                <strong>L’administrateur autorise, l’utilisateur organise.</strong>
                Ici tu définis les pages que chacun peut utiliser. Ensuite chaque personne décide librement de les ajouter ou non à son propre menu vertical.
            </p>

            <h3>🔒 Pages essentielles</h3>
            <p class="pe-note">Ces pages font partie du fonctionnement normal de DoMyDesk. Elles restent disponibles, mais personne n’est obligé de les mettre dans son menu.</p>

            <?php if (!empty($alwaysPages)): ?>
                <div class="mods-grid">
                    <?php foreach ($alwaysPages as $pageId => $pageInfo): ?>
                        <div class="mod-card">
                            <div class="mod-meta">
                                <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="mod-id"><?= htmlspecialchars($pageInfo['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                            </div>
                            <strong>Toujours disponible</strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <hr>

            <h3>🌍 1. Pages pour tout le monde</h3>
            <p class="pe-note">Coche les pages facultatives que tous les utilisateurs peuvent ouvrir, quel que soit leur métier.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="global-page-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <?php if (!empty($permissionPages)): ?>
                    <div class="mods-grid">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <label class="mod-card">
                                <div class="mod-meta">
                                    <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="mod-id"><?= htmlspecialchars($pageInfo['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                                </div>
                                <div>
                                    <input
                                        type="checkbox"
                                        name="global_pages[]"
                                        value="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                        data-global-page="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                        <?= dmd_page_access_mode($pageId) === 'everyone' ? 'checked' : '' ?>
                                    >
                                    <strong>Tout le monde</strong>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pe-note">Aucune page facultative déclarée pour le moment.</p>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_global_page_rights" value="1">Enregistrer</button>
                </div>
            </form>

            <hr>

            <h3>👥 2. Pages par rôle métier</h3>
            <p class="pe-note">Choisis un métier, puis coche les pages que les personnes de ce métier peuvent utiliser.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="role-page-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <div>
                    <label for="pageRightsRole">Rôle métier</label>
                    <select name="page_rights_role" id="pageRightsRole" required>
                        <?php foreach ($metiers as $m): ?>
                            <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>" <?= $m === $selectedPageRightsRole ? 'selected' : '' ?>><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (!empty($permissionPages)): ?>
                    <div class="mods-grid">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <label class="mod-card">
                                <div class="mod-meta">
                                    <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="mod-id" data-role-page-help="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Autoriser ce rôle</div>
                                </div>
                                <input
                                    type="checkbox"
                                    name="role_pages[]"
                                    value="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-role-page="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                >
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_role_page_rights" value="1">Enregistrer les pages du rôle</button>
                </div>
            </form>

            <hr>

            <h3>👤 3. Exceptions pour une personne</h3>
            <p class="pe-note">Un cas particulier ? Donne une page en plus, retire-la, ou laisse simplement son rôle décider.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="user-page-exceptions-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <div>
                    <label for="pageRightsUser">Utilisateur</label>
                    <select name="page_rights_user" id="pageRightsUser">
                        <option value="">Sélectionner une personne</option>
                        <?php foreach ($users as $u):
                            $profile = $userProfiles[$u] ?? [];
                            $fullName = trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? ''));
                            $roleMetier = (string)($profile['role_metier'] ?? '');
                            $userLabel = ($fullName !== '' ? $fullName . ' — ' : '') . $u . ($roleMetier !== '' ? ' (' . $roleMetier . ')' : '');
                        ?>
                            <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>" <?= $u === $selectedPageRightsUser ? 'selected' : '' ?>><?= htmlspecialchars($userLabel, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (!empty($permissionPages)): ?>
                    <div id="userPageExceptionsGrid" class="pe-form">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <div class="pe-msg">
                                <div class="pe-form-row">
                                    <div>
                                        <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                        <div class="mod-id" data-page-rights-effective="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Sélectionne une personne</div>
                                    </div>
                                    <div>
                                        <label for="page-override-<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Exception</label>
                                        <select
                                            id="page-override-<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                            name="page_overrides[<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>]"
                                            data-rights-user-page-override="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                            disabled
                                        >
                                            <option value="inherit">Comme son rôle</option>
                                            <option value="allow">Toujours autoriser</option>
                                            <option value="deny">Toujours refuser</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_user_page_exceptions" value="1" id="saveUserPageExceptions" disabled>Enregistrer les exceptions</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-registration" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Validation des inscriptions</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-registration' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Configuration enregistrée.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-registration' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <form method="post" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="save_registration_settings" value="1">
                <div>
                    <label>Activation des nouveaux comptes créés depuis la page d’inscription</label>
                    <select name="registration_approval_mode">
                        <option value="automatic" <?= ($settings['registration_approval_mode'] ?? 'approval') === 'automatic' ? 'selected' : '' ?>>Automatique — le compte est utilisable immédiatement</option>
                        <option value="approval" <?= ($settings['registration_approval_mode'] ?? 'approval') === 'approval' ? 'selected' : '' ?>>Après validation — un administrateur doit accepter le compte</option>
                    </select>
                </div>
                <p class="pe-note">Ce réglage concerne uniquement les comptes créés depuis la page publique d’inscription. Les comptes créés manuellement dans l’administration restent actifs immédiatement.</p>
                <div class="pe-actions"><button type="submit">Enregistrer</button></div>
            </form>

            <hr>
            <h3>Demandes en attente<?= $dmdPendingRegistrations ? ' (' . count($dmdPendingRegistrations) . ')' : '' ?></h3>
            <?php if (!$dmdPendingRegistrations): ?>
                <p class="pe-note">Aucune inscription en attente.</p>
            <?php else: ?>
                <div class="table-wrap"><table class="roles-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Rôle prévu</th><th>Demande</th><th>Action</th></tr></thead><tbody>
                <?php foreach ($dmdPendingRegistrations as $pendingEmail => $pending): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars(trim((string)($pending['prenom'] ?? '') . ' ' . (string)($pending['nom'] ?? '')), ENT_QUOTES, 'UTF-8') ?></strong></td>
                        <td><?= htmlspecialchars($pendingEmail, ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)($pending['role_metier'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string)($pending['registration_requested_at'] ?? $pending['created_at'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <form method="post" style="display:inline-flex;gap:6px;flex-wrap:wrap;">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="registration_email" value="<?= htmlspecialchars($pendingEmail, ENT_QUOTES, 'UTF-8') ?>">
                                <button type="submit" name="approve_registration" value="1">Valider</button>
                                <button type="submit" name="refuse_registration" value="1" class="btn-del" onclick="return confirm('Refuser cette inscription ?')">Refuser</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-metiers" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Rôles métier</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="pe-form-row">
                    <div>
                        <label>Nouveau rôle métier</label>
                        <input type="text" name="new_metier" placeholder="ex: TECH, COMPTA, RH">
                    </div>
                    <div>
                        <label>Supprimer un rôle métier</label>
                        <select name="del_metier">
                            <option value="">Ne rien supprimer</option>
                            <?php foreach ($metiers as $m): ?>
                                <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="pe-actions">
                    <button type="submit" name="add_metier">Ajouter</button>
                    <button type="submit" name="delete_metier" class="btn-del">Supprimer</button>
                </div>
            </form>

            <hr>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div>
                    <label>Rôle attribué automatiquement aux nouvelles inscriptions</label>
                    <select name="default_registration_role" required>
                        <?php foreach ($metiers as $m): ?>
                            <option value="<?= htmlspecialchars($m) ?>" <?= (($rolesModulesData['default_role'] ?? '') === $m) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($m) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <p class="pe-note">L’utilisateur ne peut pas choisir lui-même un rôle plus privilégié lors de son inscription.</p>
                <div class="pe-actions">
                    <button type="submit" name="save_default_role">Enregistrer le rôle par défaut</button>
                </div>
            </form>

            <hr>
            <p class="pe-note">
                Les autorisations héritées des rôles et les exceptions individuelles sont maintenant centralisées dans « Droits sur les modules ».
            </p>
        </div>
    </div>
</div>

<script>
const ROLE_PAGES = <?= json_encode($pageRightsData['roles'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_PAGE_OVERRIDES = <?= json_encode($userPageOverridesMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const ROLE_MODULES = <?= json_encode($rolesModulesData['roles'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const MODULE_PERMISSION_DEFS = <?= json_encode($modulePermissionDefinitions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_MODULE_OVERRIDES = <?= json_encode($userModuleOverridesMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_RIGHTS_META = <?= json_encode($userRightsMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const REOPEN_POPUP = <?= json_encode($reopenPopup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const MODULE_RIGHTS_STATE_KEY = 'dmd-module-rights-selection';
const PAGE_RIGHTS_STATE_KEY = 'dmd-page-rights-selection';

async function dmdCopyBridgeToken(button) {
    const source = document.getElementById('dmdDmsBridgeToken');
    if (!source) return;
    const value = String(source.textContent || '').trim();
    if (!value) return;

    let copied = false;
    if (navigator.clipboard && window.isSecureContext) {
        try {
            await navigator.clipboard.writeText(value);
            copied = true;
        } catch (e) {}
    }

    if (!copied) {
        const area = document.createElement('textarea');
        area.value = value;
        area.setAttribute('readonly', 'readonly');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        try { copied = document.execCommand('copy'); } catch (e) { copied = false; }
        area.remove();
    }

    if (copied && button) {
        const old = button.textContent;
        button.textContent = '✅ Copié';
        window.setTimeout(() => { button.textContent = old || '📋 Copier'; }, 1400);
    }
}

function dmdRoleModuleRule(role, moduleId) {
    const roleData = ROLE_MODULES[role] || {};
    const modules = roleData.modules || {};
    const rule = modules[moduleId] || {};
    const permissions = Array.isArray(rule.permissions) ? rule.permissions.map(String) : [];
    return {
        enabled: !!rule.enabled,
        permissions: permissions
    };
}

function dmdRoleAllowsModule(role, moduleId) {
    return dmdRoleModuleRule(role, moduleId).enabled;
}

function dmdModuleHasFinePermissions(moduleId) {
    const defs = MODULE_PERMISSION_DEFS[moduleId] || {};
    return Object.keys(defs).length > 0;
}

function dmdRuleHasAllPermissions(rule) {
    return !!(rule && Array.isArray(rule.permissions) && rule.permissions.includes('*'));
}

function dmdUserOverrideRule(user, moduleId) {
    const userRules = USER_MODULE_OVERRIDES[user] || {};
    const rule = userRules[moduleId] || {};
    const state = String(rule.state || 'inherit').toLowerCase();
    return {
        state: ['inherit', 'allow', 'deny'].includes(state) ? state : 'inherit',
        permissions: Array.isArray(rule.permissions) ? rule.permissions.map(String) : []
    };
}

function dmdUserOverrideState(user, moduleId) {
    return dmdUserOverrideRule(user, moduleId).state;
}

function dmdIsGlobalModule(moduleId) {
    const checkbox = document.querySelector(`[data-global-module="${CSS.escape(moduleId)}"]`);
    return !!(checkbox && checkbox.checked);
}

function dmdSetRolePermissionUi(moduleId, rule, enabled, global) {
    const hasFine = dmdModuleHasFinePermissions(moduleId);
    if (!hasFine) return;

    const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
    const permissions = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)];
    const details = document.querySelector(`[data-role-permission-details="${CSS.escape(moduleId)}"]`);
    const allRights = dmdRuleHasAllPermissions(rule);

    if (all) {
        all.checked = enabled && allRights;
        all.disabled = !enabled || global;
    }

    permissions.forEach(input => {
        const permissionId = String(input.dataset.permissionId || '');
        input.checked = enabled && !allRights && rule.permissions.includes(permissionId);
        input.disabled = !enabled || global || allRights;
    });

    if (details) {
        details.disabled = !enabled || global;
        details.classList.toggle('is-disabled', !enabled || global);
    }
}

function dmdLoadRoleModuleRights() {
    const roleSelect = document.getElementById('moduleRightsRole');
    if (!roleSelect) return;
    const selectedRole = roleSelect.value || '';

    document.querySelectorAll('[data-rights-role-module]').forEach(input => {
        const moduleId = input.dataset.rightsRoleModule || '';
        const global = dmdIsGlobalModule(moduleId);
        const rule = dmdRoleModuleRule(selectedRole, moduleId);
        input.checked = rule.enabled;
        input.disabled = global;

        const help = document.querySelector(`[data-role-module-help="${CSS.escape(moduleId)}"]`);
        if (help) {
            help.textContent = global ? 'Déjà autorisé à tout le monde' : 'Autoriser ce rôle à utiliser le module';
        }

        dmdSetRolePermissionUi(moduleId, rule, rule.enabled, global);
    });
}

function dmdReadLiveRoleRule(moduleId) {
    const input = document.querySelector(`[data-rights-role-module="${CSS.escape(moduleId)}"]`);
    if (!input || !input.checked) {
        return { enabled: false, permissions: [] };
    }

    if (!dmdModuleHasFinePermissions(moduleId)) {
        return { enabled: true, permissions: ['*'] };
    }

    const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
    if (all && all.checked) {
        return { enabled: true, permissions: ['*'] };
    }

    const permissions = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)]
        .filter(el => el.checked)
        .map(el => String(el.dataset.permissionId || ''))
        .filter(Boolean);
    return { enabled: true, permissions };
}

function dmdOnRoleAccessChange(input) {
    const moduleId = input.dataset.rightsRoleModule || '';
    const global = dmdIsGlobalModule(moduleId);
    if (input.checked && dmdModuleHasFinePermissions(moduleId)) {
        const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
        const anyFine = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)].some(el => el.checked);
        if (all && !all.checked && !anyFine) {
            all.checked = true;
        }
    }
    dmdSetRolePermissionUi(moduleId, dmdReadLiveRoleRule(moduleId), input.checked, global);
    dmdUpdateUserEffectiveRights();
}

function dmdOnRoleAllPermissionsChange(input) {
    const moduleId = input.dataset.rightsRoleAll || '';
    const access = document.querySelector(`[data-rights-role-module="${CSS.escape(moduleId)}"]`);
    if (access && !access.checked) {
        access.checked = true;
    }
    document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`).forEach(el => {
        el.disabled = input.checked || dmdIsGlobalModule(moduleId) || !(access && access.checked);
        if (input.checked) el.checked = false;
    });
    dmdUpdateUserEffectiveRights();
}

function dmdLoadUserModuleOverrides() {
    const userSelect = document.getElementById('moduleRightsUser');
    const saveButton = document.getElementById('saveUserModuleExceptions');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);

    if (saveButton) saveButton.disabled = !selectedUser || isAdminUser;
    document.querySelectorAll('[data-user-save]').forEach(button => {
        button.disabled = !selectedUser || isAdminUser;
    });

    document.querySelectorAll('[data-rights-user-override]').forEach(select => {
        const moduleId = select.dataset.rightsUserOverride || '';
        const rule = selectedUser ? dmdUserOverrideRule(selectedUser, moduleId) : { state: 'inherit', permissions: [] };
        select.value = `${moduleId}|${rule.state}`;
        select.disabled = !selectedUser || isAdminUser;
        dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser);
    });

    dmdUpdateUserEffectiveRights();
}

function dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser) {
    if (!dmdModuleHasFinePermissions(moduleId)) return;
    const allow = !!selectedUser && !isAdminUser && rule.state === 'allow';
    const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
    const permissions = [...document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`)];
    const details = document.querySelector(`[data-user-permission-details="${CSS.escape(moduleId)}"]`);
    const allRights = dmdRuleHasAllPermissions(rule);

    if (all) {
        all.checked = allow && allRights;
        all.disabled = !allow;
    }
    permissions.forEach(input => {
        const permissionId = String(input.dataset.permissionId || '');
        input.checked = allow && !allRights && rule.permissions.includes(permissionId);
        input.disabled = !allow || allRights;
    });
    if (details) details.classList.toggle('is-disabled', !allow);
}

function dmdReadLiveUserRule(moduleId) {
    const select = document.querySelector(`[data-rights-user-override="${CSS.escape(moduleId)}"]`);
    if (!select) return { state: 'inherit', permissions: [] };
    const raw = String(select.value || `${moduleId}|inherit`);
    const splitAt = raw.indexOf('|');
    const state = splitAt >= 0 ? raw.slice(splitAt + 1) : 'inherit';
    if (state !== 'allow') return { state, permissions: [] };

    if (!dmdModuleHasFinePermissions(moduleId)) {
        return { state: 'allow', permissions: ['*'] };
    }

    const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
    if (all && all.checked) return { state: 'allow', permissions: ['*'] };

    const permissions = [...document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`)]
        .filter(el => el.checked)
        .map(el => String(el.dataset.permissionId || ''))
        .filter(Boolean);
    return { state: 'allow', permissions };
}

function dmdOnUserOverrideChange(select) {
    const moduleId = select.dataset.rightsUserOverride || '';
    const userSelect = document.getElementById('moduleRightsUser');
    const selectedUser = userSelect ? userSelect.value : '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const isAdminUser = ['admin', 'superadmin'].includes(String(userMeta.role_system || 'user').toLowerCase());
    let rule = dmdReadLiveUserRule(moduleId);

    if (rule.state === 'allow' && dmdModuleHasFinePermissions(moduleId) && !rule.permissions.length) {
        const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
        if (all) all.checked = true;
        rule = { state: 'allow', permissions: ['*'] };
    }

    dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser);
    dmdUpdateUserEffectiveRights();
}

function dmdOnUserAllPermissionsChange(input) {
    const moduleId = input.dataset.rightsUserAll || '';
    document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`).forEach(el => {
        el.disabled = input.checked;
        if (input.checked) el.checked = false;
    });
    dmdUpdateUserEffectiveRights();
}

function dmdPermissionSummary(rule) {
    if (!rule || !rule.enabled) return '';
    if (dmdRuleHasAllPermissions(rule)) return 'tous les droits';
    const count = Array.isArray(rule.permissions) ? rule.permissions.length : 0;
    if (count === 0) return 'accès au module uniquement';
    return count + (count > 1 ? ' actions autorisées' : ' action autorisée');
}

function dmdUpdateUserEffectiveRights() {
    const userSelect = document.getElementById('moduleRightsUser');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const userRole = String(userMeta.role_metier || '');
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);
    const selectedRole = document.getElementById('moduleRightsRole')?.value || '';

    document.querySelectorAll('[data-rights-user-override]').forEach(select => {
        const moduleId = select.dataset.rightsUserOverride || '';
        const effective = document.querySelector(`[data-rights-effective="${CSS.escape(moduleId)}"]`);
        if (!effective) return;

        if (!selectedUser) {
            effective.textContent = 'Sélectionne une personne';
            return;
        }
        if (isAdminUser) {
            effective.textContent = '✓ Administrateur : tous les droits';
            return;
        }

        const liveUserRule = dmdReadLiveUserRule(moduleId);
        if (liveUserRule.state === 'allow') {
            effective.textContent = `✓ Exception personnelle — ${dmdPermissionSummary({ enabled: true, permissions: liveUserRule.permissions })}`;
            return;
        }
        if (liveUserRule.state === 'deny') {
            effective.textContent = '✗ Refusé spécialement pour cette personne';
            return;
        }
        if (dmdIsGlobalModule(moduleId)) {
            effective.textContent = '✓ Autorisé à tout le monde — tous les droits';
            return;
        }

        let roleRule = dmdRoleModuleRule(userRole, moduleId);
        if (userRole && userRole === selectedRole) {
            roleRule = dmdReadLiveRoleRule(moduleId);
        }

        effective.textContent = roleRule.enabled
            ? `✓ Rôle ${userRole} — ${dmdPermissionSummary(roleRule)}`
            : `✗ Non prévu pour le rôle ${userRole || 'de cette personne'}`;
    });
}

function dmdSaveModuleRightsState() {
    const role = document.getElementById('moduleRightsRole')?.value || '';
    const user = document.getElementById('moduleRightsUser')?.value || '';
    try {
        sessionStorage.setItem(MODULE_RIGHTS_STATE_KEY, JSON.stringify({ role, user }));
    } catch (e) {}
}

function dmdRestoreModuleRightsState() {
    let saved = {};
    try {
        saved = JSON.parse(sessionStorage.getItem(MODULE_RIGHTS_STATE_KEY) || '{}') || {};
    } catch (e) {
        saved = {};
    }

    const roleSelect = document.getElementById('moduleRightsRole');
    const userSelect = document.getElementById('moduleRightsUser');

    if (roleSelect && saved.role && [...roleSelect.options].some(option => option.value === saved.role)) {
        roleSelect.value = saved.role;
    }
    if (userSelect && saved.user && [...userSelect.options].some(option => option.value === saved.user)) {
        userSelect.value = saved.user;
    }
}

function dmdRefreshModuleRights() {
    dmdLoadRoleModuleRights();
    dmdLoadUserModuleOverrides();
}

function openPopup(id){ const pop=document.getElementById(id); if(!pop) return; pop.classList.add('is-open'); pop.setAttribute('aria-hidden','false'); document.body.classList.add('noscroll'); }
function closePopup(pop){ if(!pop) return; pop.classList.remove('is-open'); pop.setAttribute('aria-hidden','true'); if(!document.querySelector('.pe-popup.is-open')) document.body.classList.remove('noscroll'); }
function esc(s){ return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[m])); }

// Gestion générique des popups de l'administration.
// Toutes les vignettes site_settings utilisent data-popup-open / data-popup-close.
document.querySelectorAll('[data-popup-open]').forEach(btn => {
    btn.addEventListener('click', () => openPopup(btn.dataset.popupOpen));
});

document.querySelectorAll('[data-popup-close]').forEach(btn => {
    btn.addEventListener('click', () => closePopup(btn.closest('.pe-popup')));
});

document.querySelectorAll('.pe-popup').forEach(pop => {
    pop.addEventListener('click', event => {
        if (event.target === pop) closePopup(pop);
    });
});

document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('.pe-popup.is-open').forEach(pop => closePopup(pop));
});

// Volets de Sécurité & administration : un seul ouvert à la fois.
document.querySelectorAll('#dmd-security-accordions details').forEach(detail => {
    detail.addEventListener('toggle', () => {
        if (!detail.open) return;
        document.querySelectorAll('#dmd-security-accordions details').forEach(other => {
            if (other !== detail) other.open = false;
        });
    });
});

function dmdRoleAllowsPage(role, pageId) {
    const roleData = ROLE_PAGES[role] || {};
    const pages = roleData.pages || {};
    return !!(pages[pageId] && pages[pageId].enabled);
}

function dmdUserPageOverrideState(user, pageId) {
    const userRules = USER_PAGE_OVERRIDES[user] || {};
    const rule = userRules[pageId] || {};
    const state = String(rule.state || 'inherit').toLowerCase();
    return ['inherit', 'allow', 'deny'].includes(state) ? state : 'inherit';
}

function dmdIsGlobalPage(pageId) {
    const checkbox = document.querySelector(`[data-global-page="${CSS.escape(pageId)}"]`);
    return !!(checkbox && checkbox.checked);
}

function dmdLoadRolePageRights() {
    const roleSelect = document.getElementById('pageRightsRole');
    if (!roleSelect) return;
    const selectedRole = roleSelect.value || '';

    document.querySelectorAll('[data-rights-role-page]').forEach(input => {
        const pageId = input.dataset.rightsRolePage || '';
        const global = dmdIsGlobalPage(pageId);
        input.checked = dmdRoleAllowsPage(selectedRole, pageId);
        input.disabled = global;

        const help = document.querySelector(`[data-role-page-help="${CSS.escape(pageId)}"]`);
        if (help) help.textContent = global ? 'Déjà accessible à tout le monde' : 'Autoriser ce rôle';
    });
}

function dmdLoadUserPageOverrides() {
    const userSelect = document.getElementById('pageRightsUser');
    const saveButton = document.getElementById('saveUserPageExceptions');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);

    if (saveButton) saveButton.disabled = !selectedUser || isAdminUser;

    document.querySelectorAll('[data-rights-user-page-override]').forEach(select => {
        const pageId = select.dataset.rightsUserPageOverride || '';
        select.value = selectedUser ? dmdUserPageOverrideState(selectedUser, pageId) : 'inherit';
        select.disabled = !selectedUser || isAdminUser;
    });

    dmdUpdateUserEffectivePageRights();
}

function dmdUpdateUserEffectivePageRights() {
    const userSelect = document.getElementById('pageRightsUser');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const userRole = String(userMeta.role_metier || '');
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);
    const selectedRole = document.getElementById('pageRightsRole')?.value || '';

    document.querySelectorAll('[data-rights-user-page-override]').forEach(select => {
        const pageId = select.dataset.rightsUserPageOverride || '';
        const effective = document.querySelector(`[data-page-rights-effective="${CSS.escape(pageId)}"]`);
        if (!effective) return;

        if (!selectedUser) {
            effective.textContent = 'Sélectionne une personne';
            return;
        }

        if (isAdminUser) {
            effective.textContent = '✓ Administrateur : toujours autorisé';
            return;
        }

        const state = select.value;
        if (state === 'allow') {
            effective.textContent = '✓ Accessible spécialement pour cette personne';
            return;
        }
        if (state === 'deny') {
            effective.textContent = '✗ Refusée spécialement pour cette personne';
            return;
        }
        if (dmdIsGlobalPage(pageId)) {
            effective.textContent = '✓ Accessible à tout le monde';
            return;
        }

        let roleAllowed = dmdRoleAllowsPage(userRole, pageId);
        if (userRole && userRole === selectedRole) {
            const liveRoleCheckbox = document.querySelector(`[data-rights-role-page="${CSS.escape(pageId)}"]`);
            if (liveRoleCheckbox && !liveRoleCheckbox.disabled) roleAllowed = liveRoleCheckbox.checked;
        }

        effective.textContent = roleAllowed
            ? `✓ Accessible au rôle ${userRole}`
            : `✗ Non prévue pour le rôle ${userRole || 'de cette personne'}`;
    });
}

function dmdSavePageRightsState() {
    const role = document.getElementById('pageRightsRole')?.value || '';
    const user = document.getElementById('pageRightsUser')?.value || '';
    try { sessionStorage.setItem(PAGE_RIGHTS_STATE_KEY, JSON.stringify({ role, user })); } catch (e) {}
}

function dmdRestorePageRightsState() {
    let saved = {};
    try { saved = JSON.parse(sessionStorage.getItem(PAGE_RIGHTS_STATE_KEY) || '{}') || {}; } catch (e) { saved = {}; }

    const roleSelect = document.getElementById('pageRightsRole');
    const userSelect = document.getElementById('pageRightsUser');

    if (roleSelect && saved.role && [...roleSelect.options].some(option => option.value === saved.role)) roleSelect.value = saved.role;
    if (userSelect && saved.user && [...userSelect.options].some(option => option.value === saved.user)) userSelect.value = saved.user;
}

const pageRightsRole = document.getElementById('pageRightsRole');
const pageRightsUser = document.getElementById('pageRightsUser');

dmdRestorePageRightsState();
pageRightsRole?.addEventListener('change', () => {
    dmdSavePageRightsState();
    dmdLoadRolePageRights();
    dmdUpdateUserEffectivePageRights();
});
pageRightsUser?.addEventListener('change', () => {
    dmdSavePageRightsState();
    dmdLoadUserPageOverrides();
});
document.querySelectorAll('[data-global-page]').forEach(el => el.addEventListener('change', () => {
    dmdLoadRolePageRights();
    dmdUpdateUserEffectivePageRights();
}));
document.querySelectorAll('[data-rights-role-page]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectivePageRights));
document.querySelectorAll('[data-rights-user-page-override]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectivePageRights));
['global-page-rights-form', 'role-page-rights-form', 'user-page-exceptions-form'].forEach(formId => {
    document.getElementById(formId)?.addEventListener('submit', dmdSavePageRightsState);
});
dmdLoadRolePageRights();
dmdLoadUserPageOverrides();


function dmdSyncModuleRightsSelectors() {
    const role = document.getElementById('moduleRightsRole')?.value || '';
    const user = document.getElementById('moduleRightsUser')?.value || '';

    document.querySelectorAll('[data-module-role-select]').forEach(select => {
        if ([...select.options].some(option => option.value === role)) select.value = role;
    });
    document.querySelectorAll('[data-module-user-select]').forEach(select => {
        if ([...select.options].some(option => option.value === user)) select.value = user;
        else select.value = '';
    });
}

document.querySelectorAll('[data-module-role-select]').forEach(select => {
    select.addEventListener('change', () => {
        const master = document.getElementById('moduleRightsRole');
        if (!master) return;
        master.value = select.value || '';
        dmdSaveModuleRightsState();
        dmdLoadRoleModuleRights();
        dmdUpdateUserEffectiveRights();
        dmdSyncModuleRightsSelectors();
    });
});

document.querySelectorAll('[data-module-user-select]').forEach(select => {
    select.addEventListener('change', () => {
        const master = document.getElementById('moduleRightsUser');
        if (!master) return;
        master.value = select.value || '';
        dmdSaveModuleRightsState();
        dmdLoadUserModuleOverrides();
        dmdSyncModuleRightsSelectors();
    });
});

const moduleRightsRole = document.getElementById('moduleRightsRole');
const moduleRightsUser = document.getElementById('moduleRightsUser');

dmdRestoreModuleRightsState();

moduleRightsRole?.addEventListener('change', () => {
    dmdSaveModuleRightsState();
    dmdLoadRoleModuleRights();
    dmdUpdateUserEffectiveRights();
});
moduleRightsUser?.addEventListener('change', () => {
    dmdSaveModuleRightsState();
    dmdLoadUserModuleOverrides();
});
document.querySelectorAll('[data-global-module]').forEach(el => el.addEventListener('change', () => {
    dmdLoadRoleModuleRights();
    dmdUpdateUserEffectiveRights();
}));
document.querySelectorAll('[data-rights-role-module]').forEach(el => el.addEventListener('change', () => dmdOnRoleAccessChange(el)));
document.querySelectorAll('[data-rights-role-all]').forEach(el => el.addEventListener('change', () => dmdOnRoleAllPermissionsChange(el)));
document.querySelectorAll('[data-rights-role-permission]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectiveRights));
document.querySelectorAll('[data-rights-user-override]').forEach(el => el.addEventListener('change', () => dmdOnUserOverrideChange(el)));
document.querySelectorAll('[data-rights-user-all]').forEach(el => el.addEventListener('change', () => dmdOnUserAllPermissionsChange(el)));
document.querySelectorAll('[data-rights-user-permission]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectiveRights));

['global-module-rights-form', 'role-module-rights-form', 'user-module-exceptions-form'].forEach(formId => {
    document.getElementById(formId)?.addEventListener('submit', dmdSaveModuleRightsState);
});

dmdRefreshModuleRights();
dmdSyncModuleRightsSelectors();

if (REOPEN_POPUP === 'popup-site-settings') {
    openPopup('popup-site-settings');
}
if (REOPEN_POPUP === 'popup-security-admin') {
    openPopup('popup-security-admin');

    // Si une sous-section de Sécurité est demandée dans l'URL, on l'ouvre
    // explicitement après l'ouverture de la popup. Cela évite de dépendre
    // uniquement du rendu PHP de l'attribut `open`.
    const requestedSecuritySection = new URLSearchParams(window.location.search).get('section') || '';
    if (requestedSecuritySection) {
        window.requestAnimationFrame(() => {
            const wanted = document.querySelector(`#dmd-security-accordions [data-security-section="${CSS.escape(requestedSecuritySection)}"]`);
            if (!wanted) return;
            document.querySelectorAll('#dmd-security-accordions details').forEach(other => {
                if (other !== wanted) other.open = false;
            });
            wanted.open = true;
            window.setTimeout(() => {
                wanted.scrollIntoView({block:'nearest', behavior:'auto'});
            }, 0);
        });
    }
}
if (REOPEN_POPUP === 'popup-module-rights') {
    openPopup('popup-module-rights');
}
if (REOPEN_POPUP === 'popup-page-rights') {
    openPopup('popup-page-rights');
}
if (REOPEN_POPUP === 'popup-site-maintenance') {
    openPopup('popup-site-maintenance');
}
if (REOPEN_POPUP === 'popup-updates') {
    openPopup('popup-updates');
}
if (REOPEN_POPUP === 'popup-system-logs') {
    openPopup('popup-system-logs');
}

function openThemePreview(src, title) {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');
    const headTitle = document.getElementById('theme-preview-title');

    if (!popup || !img || !headTitle) return;

    img.src = src;
    img.alt = title || 'Aperçu du thème';
    headTitle.textContent = title || 'Aperçu du thème';

    popup.classList.add('is-open');
    popup.setAttribute('aria-hidden', 'false');
    document.body.classList.add('noscroll');
}

function closeThemePreview() {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');

    if (!popup) return;

    popup.classList.remove('is-open');
    popup.setAttribute('aria-hidden', 'true');

    if (img) {
        img.src = '';
        img.alt = '';
    }

    if (!document.querySelector('.pe-popup.is-open')) {
        document.body.classList.remove('noscroll');
    }
}

document.getElementById('popup-theme-preview')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeThemePreview();
    }
});

function dmdRenumberHorizontalMenuRows() {
    const tbody = document.getElementById('dmd-horizontal-menu-body');
    if (!tbody) return;

    [...tbody.querySelectorAll('.dmd-menu-row')].forEach((row, index) => {
        const title = row.querySelector('input[name^="menu_title"]');
        const icon = row.querySelector('select[name^="menu_icon"]');
        const type = row.querySelector('select[name^="menu_type"]');
        const url = row.querySelector('input[name^="menu_url"]');
        const del = row.querySelector('input[name^="menu_delete"]');

        if (title) title.name = `menu_title[${index}]`;
        if (icon) icon.name = `menu_icon[${index}]`;
        if (type) type.name = `menu_type[${index}]`;
        if (url) url.name = `menu_url[${index}]`;
        if (del) del.name = `menu_delete[${index}]`;
    });
}

(function dmdInitHorizontalMenuOrdering() {
    const tbody = document.getElementById('dmd-horizontal-menu-body');
    if (!tbody) return;

    let draggedRow = null;

    const clearDropMarkers = () => {
        tbody.querySelectorAll('.dmd-menu-row').forEach(row => {
            row.classList.remove('dmd-menu-drop-before', 'dmd-menu-drop-after');
        });
    };

    tbody.querySelectorAll('.dmd-menu-drag-handle').forEach(handle => {
        handle.addEventListener('dragstart', event => {
            draggedRow = handle.closest('.dmd-menu-row');
            if (!draggedRow) return;

            draggedRow.classList.add('dmd-menu-dragging');
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', 'dmd-horizontal-menu-row');
        });

        handle.addEventListener('dragend', () => {
            if (draggedRow) draggedRow.classList.remove('dmd-menu-dragging');
            draggedRow = null;
            clearDropMarkers();
            dmdRenumberHorizontalMenuRows();
        });
    });

    tbody.querySelectorAll('.dmd-menu-row').forEach(targetRow => {
        targetRow.addEventListener('dragover', event => {
            if (!draggedRow || targetRow === draggedRow) return;
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';

            clearDropMarkers();
            const rect = targetRow.getBoundingClientRect();
            const before = event.clientY < rect.top + (rect.height / 2);
            targetRow.classList.add(before ? 'dmd-menu-drop-before' : 'dmd-menu-drop-after');
        });

        targetRow.addEventListener('dragleave', () => {
            targetRow.classList.remove('dmd-menu-drop-before', 'dmd-menu-drop-after');
        });

        targetRow.addEventListener('drop', event => {
            if (!draggedRow || targetRow === draggedRow) return;
            event.preventDefault();

            const rect = targetRow.getBoundingClientRect();
            const before = event.clientY < rect.top + (rect.height / 2);

            if (before) {
                tbody.insertBefore(draggedRow, targetRow);
            } else {
                tbody.insertBefore(draggedRow, targetRow.nextSibling);
            }

            clearDropMarkers();
            dmdRenumberHorizontalMenuRows();
        });
    });

    const siteForm = tbody.closest('form');
    siteForm?.addEventListener('submit', dmdRenumberHorizontalMenuRows);
    dmdRenumberHorizontalMenuRows();
})();
</script>
</body>
</html>
