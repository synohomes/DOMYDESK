<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');
$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
if ($email === '') { http_response_code(401); echo json_encode(array('ok'=>false,'error'=>'Session expirée.')); exit; }
$profile = dmd_read_profile($email);
$role = strtolower(trim((string)($profile['role_system'] ?? 'user')));
if (!in_array($role, array('admin','superadmin'), true)) { http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'Accès refusé.')); exit; }

$csrf = (string)($_SESSION['csrf_notifications_admin'] ?? '');
$token = (string)($_POST['csrf_token'] ?? '');
if ($csrf === '' || !hash_equals($csrf, $token)) { http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'Formulaire expiré.')); exit; }

$action = (string)($_POST['action'] ?? '');
$error = '';
if ($action === 'start') {
    $result = function_exists('dmd_mail_microsoft_device_start') ? dmd_mail_microsoft_device_start($error) : false;
    if ($result === false) { echo json_encode(array('ok'=>false,'error'=>$error !== '' ? $error : 'Connexion Microsoft impossible.'), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
    echo json_encode(array('ok'=>true,'status'=>'started') + $result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
if ($action === 'poll') {
    $result = function_exists('dmd_mail_microsoft_device_poll') ? dmd_mail_microsoft_device_poll($error) : array('status'=>'error');
    $ok = (($result['status'] ?? '') === 'connected' || ($result['status'] ?? '') === 'pending');
    echo json_encode(array('ok'=>$ok,'error'=>$error) + $result, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
http_response_code(400);
echo json_encode(array('ok'=>false,'error'=>'Action invalide.'), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
