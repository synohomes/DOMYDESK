<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_security.php';
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
if ($email === '') {
    header('Location: ../login.php');
    exit;
}

$profileFile = dmd_profile_path($email, true);
$profile = is_file($profileFile) ? json_decode((string)file_get_contents($profileFile), true) : null;
if (!is_array($profile)) {
    header('Location: ../login.php');
    exit;
}

$roleSystem = isset($profile['role_system']) ? (string)$profile['role_system'] : 'user';
$isSuperadmin = $roleSystem === 'superadmin';
if (!in_array($roleSystem, array('admin', 'superadmin'), true)) {
    header('Location: ../profile_view.php');
    exit;
}

$theme = 'default';
$themeFile = $baseDir . '/users/profiles/' . $email . '/theme.json';
if (is_file($themeFile)) {
    $themeData = json_decode((string)file_get_contents($themeFile), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file($baseDir . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}

$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';
if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . (int)filemtime($themeCssFile);
}

$csrf = dmd_csrf_token('actionhub');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ActionHub - Scénarios et ressources</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeCssHref, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="actionhub_admin.css?v=<?= (int)@filemtime(__DIR__ . '/actionhub_admin.css') ?>">
</head>
<body>
<?php include $baseDir . '/header.php'; ?>

<main class="ah-admin-page">
    <header class="ah-admin-head">
        <div>
            
            <h1>⚡ ActionHub</h1>
            <p>Gestion de tes scénarios et des corbeilles ActionHub par utilisateur.</p>
        </div>
		<button type="button" onclick="location.href='../adm/site_settings.php'">← Administration</button>
    </header>

    <section class="ah-admin-toolbar" aria-label="Recherche ActionHub">
        <input type="search" id="ahScenarioSearch" placeholder="Rechercher un scénario ou un utilisateur..." autocomplete="off">
        <button type="button" id="ahRefresh">↻ Actualiser</button><button type="button" id="ahNewScenario">＋ Nouveau scénario</button>
        <div class="ah-admin-counts">
            <span id="ahScenarioCount" class="ah-admin-count">0 scénario</span>
            <span id="ahResourceCount" class="ah-admin-count">0 élément en corbeille</span>
        </div>
    </section>

    <div id="ahAdminMessage" class="ah-admin-message" hidden aria-live="polite"></div>

    <section class="ah-admin-section" aria-labelledby="ahScenariosTitle">
        <div class="ah-admin-section-head">
            <div>
                <h2 id="ahScenariosTitle">⚡ Scénarios</h2>
                <p>Scripts ActionHub que tu crées et réutilises.</p>
            </div>
        </div>
        <section id="ahScenarioList" class="ah-admin-list" aria-live="polite">
            <div class="ah-admin-empty">Chargement des scénarios…</div>
        </section>
    </section>

    <section class="ah-admin-section" aria-labelledby="ahResourcesTitle">
        <div class="ah-admin-section-head">
            <div>
                <h2 id="ahResourcesTitle">🗑 Corbeilles utilisateurs</h2>
                <p>Une ressource retirée par un utilisateur disparaît de sa vue, mais son historique ActionHub reste ici jusqu’à purge par le Superadmin.</p>
            </div>
        </div>
        <section id="ahResourceList" class="ah-admin-list ah-admin-trash-users" aria-live="polite">
            <?php if ($isSuperadmin): ?>
            <div class="ah-admin-empty">Chargement des corbeilles…</div>
            <?php else: ?>
            <div class="ah-admin-empty">La consultation et la purge des corbeilles ActionHub sont réservées au Superadmin.</div>
            <?php endif; ?>
        </section>
    </section>
</main>

<div id="ahTrashModal" class="ah-admin-modal" aria-hidden="true">
    <section class="ah-admin-dialog ah-admin-trash-dialog" role="dialog" aria-modal="true" aria-labelledby="ahTrashModalTitle">
        <header class="ah-admin-dialog-head">
            <div>
                <strong id="ahTrashModalTitle">Corbeille utilisateur</strong>
                <small id="ahTrashModalSubtitle">Historique ActionHub conservé avant purge définitive.</small>
            </div>
            <button type="button" id="ahTrashModalClose" aria-label="Fermer">×</button>
        </header>
        <div class="ah-admin-dialog-body ah-admin-trash-body">
            <div class="ah-admin-trash-toolbar">
                <div id="ahTrashModalCount" class="ah-admin-count">0 élément</div>
                <button type="button" id="ahTrashEmpty" class="is-danger">🗑 Vider la corbeille</button>
            </div>
            <div id="ahTrashItems" class="ah-admin-trash-items" aria-live="polite">
                <div class="ah-admin-empty">Chargement…</div>
            </div>
        </div>
    </section>
</div>

<div id="ahScenarioModal" class="ah-admin-modal" aria-hidden="true">
    <section class="ah-admin-dialog" role="dialog" aria-modal="true" aria-labelledby="ahScenarioModalTitle">
        <header class="ah-admin-dialog-head">
            <div>
                <strong id="ahScenarioModalTitle">Nouveau scénario</strong>
                <small>Les étapes disponibles viennent des modules réellement câblés à ActionHub.</small>
            </div>
            <button type="button" id="ahScenarioModalClose" aria-label="Fermer">×</button>
        </header>

        <div class="ah-admin-dialog-body">
            <form id="ahScenarioForm" onsubmit="return false;">
                <input type="hidden" id="ahScenarioId" value="">

                <div class="ah-admin-grid-2">
                    <label class="ah-admin-field">
                        <span>Nom du scénario *</span>
                        <input type="text" id="ahScenarioName" maxlength="160" required placeholder="Ex. Courses barbecue">
                    </label>
                    <label class="ah-admin-field">
                        <span>Mots-clés</span>
                        <input type="text" id="ahScenarioKeywords" placeholder="barbecue, bbq, courses">
                    </label>
                </div>

                <div class="ah-admin-scenario-row">
                    <label class="ah-admin-field ah-admin-scenario-description">
                        <span>Description du scénario</span>
                        <textarea id="ahScenarioDescription" rows="3" placeholder="À quoi sert ce scénario ?"></textarea>
                    </label>

                    <section class="ah-admin-workspace-box ah-admin-scenario-dashboard">
                        <label class="ah-admin-checkline">
                            <input type="checkbox" id="ahCreateDashboard">
                            <span><strong>Créer / ouvrir un dashboard dédié après exécution</strong><small>Décoché : le scénario travaille sans créer de nouveau dashboard.</small></span>
                        </label>
                        <label class="ah-admin-field" id="ahDashboardNameWrap" hidden>
                            <span>Nom du dashboard</span>
                            <input type="text" id="ahDashboardName" maxlength="64" placeholder="Vide = nom du scénario">
                        </label>
                    </section>
                </div>

                <div class="ah-admin-steps-head">
                    <div>
                        <h2>Étapes</h2>
                        <p>Chaque étape appelle une capacité déclarée par un module.</p>
                    </div>
                    <button type="button" id="ahAddStep">＋ Ajouter une étape</button>
                </div>

                <div id="ahScenarioSteps" class="ah-admin-steps"></div>

                <footer class="ah-admin-dialog-actions">
                    <button type="button" class="ah-admin-secondary" id="ahScenarioCancel">Annuler</button>
                    <button type="button" id="ahScenarioSave">Enregistrer</button>
                </footer>
            </form>
        </div>
    </section>
</div>

<script>
window.DMDActionHubAdminConfig = {
    apiUrl: '../ActionHub/api.php',
    csrfToken: <?= json_encode($csrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
    isSuperadmin: <?= $isSuperadmin ? 'true' : 'false' ?>
};
</script>
<script src="actionhub_admin.js?v=<?= (int)@filemtime(__DIR__ . '/actionhub_admin.js') ?>"></script>
</body>
</html>
