<?php
require_once __DIR__ . '/includes/agent_core.php';

function dmd_install_public_fail($status, $message) {
    http_response_code((int)$status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('Pragma: no-cache');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');
    echo (string)$message;
    exit;
}

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    dmd_install_public_fail(405, 'Méthode non autorisée.');
}

$token = trim((string)($_GET['t'] ?? ''));
$endpointIndex = isset($_GET['e']) ? (int)$_GET['e'] : 0;

$loaded = dmd_agent_install_link_load($token, true);
if (empty($loaded['ok'])) {
    $error = (string)($loaded['error'] ?? 'install_link_invalid');
    $http = in_array($error, array('install_link_expired','enrollment_expired'), true) ? 410
        : ($error === 'install_link_consumed' ? 409 : 404);
    dmd_install_public_fail($http, 'Lien d’installation invalide, expiré ou déjà utilisé.');
}

$row = $loaded['row'];
$base = dmd_agent_install_link_endpoint_base($row, $endpointIndex);
if ($base === '') dmd_install_public_fail(500, 'Adresse DoMyDesk indisponible.');

$installer = dmd_agent_installer_binary_validate();
if (empty($installer['ok'])) {
    dmd_install_public_fail(503, 'DMD-Installer.exe est indisponible sur cette instance.');
}

/*
 * Le binaire n'est jamais modifié : sa signature Authenticode reste intacte.
 * Le contexte temporaire est porté par le nom du fichier téléchargé.
 */
$encodedBase = dmd_agent_b64url_encode($base);
$filename = 'DMD-Install-' . $token . '-' . $encodedBase . '.exe';

if (strlen($filename) > 230) {
    dmd_install_public_fail(500, 'Adresse DoMyDesk trop longue pour générer le nom d’installation temporaire.');
}

dmd_agent_install_link_increment($token, 'launcher_downloads');
dmd_agent_log('enrollment_direct_installer_downloaded', 'success', array(
    'enrollment_id'=>(string)($row['enrollment_id'] ?? ''),
    'target_name'=>(string)($row['target_name'] ?? ''),
    'endpoint_index'=>$endpointIndex,
    'size'=>(int)$installer['size'],
    'sha256'=>(string)$installer['sha256'],
));

@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
while (ob_get_level() > 0) { @ob_end_clean(); }

header('Content-Type: application/vnd.microsoft.portable-executable');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . (int)$installer['size']);
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('Content-Encoding: identity');
header('X-DMD-SHA256: ' . (string)$installer['sha256']);

$fh = @fopen($installer['path'], 'rb');
if (!$fh) dmd_install_public_fail(500, 'Impossible de lire DMD-Installer.exe.');

while (!feof($fh)) {
    $chunk = fread($fh, 1048576);
    if ($chunk === false) break;
    if ($chunk !== '') echo $chunk;
}
fclose($fh);
exit;
