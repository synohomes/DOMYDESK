<?php
require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/includes/agent_repository.php';
$dmdAgentRepositoryLocal = dmd_agent_repo_local_status();
$dmdAgentSystem = dmd_agent_system_status();
require __DIR__ . '/app/head.php';
require __DIR__ . '/app/shell-open.php';

/*
 * Le système Agents est un choix explicite.
 * Une installation neuve peut donc être livrée sans aucun EXE Agent.
 */
if (empty($dmdAgentSystem['enabled']) || empty($dmdAgentRepositoryLocal['ready'])) {
    require __DIR__ . '/app/views/agent-activation.php';
    require __DIR__ . '/app/main-close.php';
    require __DIR__ . '/app/footer.php';
    exit;
}

require __DIR__ . '/app/views/agent-system-control.php';

if (empty($devices)) {
    echo '<script>document.body.classList.add("dmd-agent-no-devices");</script>';
}

require __DIR__ . '/app/views/fleet.php';
require __DIR__ . '/app/views/admin-open.php';
require __DIR__ . '/app/views/backup.php';
require __DIR__ . '/app/views/network-scan.php';
require __DIR__ . '/app/views/pc-groups.php';
require __DIR__ . '/app/views/user-groups.php';
require __DIR__ . '/app/views/rights.php';
require __DIR__ . '/app/views/mydesk.php';
require __DIR__ . '/app/views/licenses.php';
require __DIR__ . '/app/views/audits.php';
require __DIR__ . '/app/views/admin-close.php';
require __DIR__ . '/app/views/tools-rail.php';
require __DIR__ . '/app/overlays/create.php';
require __DIR__ . '/app/overlays/enrollments.php';
require __DIR__ . '/app/overlays/security.php';
require __DIR__ . '/app/main-close.php';
require __DIR__ . '/app/overlays/device.php';
require __DIR__ . '/app/overlays/feature.php';
require __DIR__ . '/app/overlays/terminal.php';
require __DIR__ . '/app/overlays/software.php';
require __DIR__ . '/app/overlays/software-bulk.php';
require __DIR__ . '/app/overlays/software-updates.php';
require __DIR__ . '/app/overlays/agent-update.php';
require __DIR__ . '/app/overlays/agent-update-pdf.php';
require __DIR__ . '/app/overlays/pc-update.php';
require __DIR__ . '/app/overlays/mydesk-maint.php';
require __DIR__ . '/app/overlays/audit.php';

?>
<script>
/*
 * Le formulaire historique "Nouvel agent" n'est plus le parcours normal.
 * Tous les boutons qui ouvraient encore "create" doivent maintenant ouvrir
 * la vraie page d'enrôlement sécurisée.
 */
document.querySelectorAll('[data-open-panel="create"]').forEach(function(button){
    button.dataset.openPanel = 'enrollments';

    if (button.textContent.trim() === 'Créer le premier agent'
        || button.textContent.trim() === 'Ajouter un poste'
        || button.textContent.trim() === 'Nouvel agent'
        || button.textContent.trim() === '＋ Nouvel agent') {
        button.textContent = 'Ajouter un poste';
    }
});


/*
 * Quand aucun PC n'est encore enrôlé, l'ancienne zone de prévisualisation
 * à droite n'a aucune utilité. On libère cette colonne pour que le Parc
 * informatique occupe réellement tout le centre.
 */
(function(){
    const emptyState = document.querySelector('.dmd-agent-fleet-empty');
    if(!emptyState) return;

    const fleetLayout = emptyState.closest('.dmd-r38-fleet-layout');
    if(fleetLayout) fleetLayout.classList.add('is-empty-fleet');

    const fleetPanel = emptyState.closest('.dmd-r38-panel');
    if(fleetPanel) fleetPanel.classList.add('has-empty-fleet');
})();


(function(){
    const VIEW_KEY = 'dmd-agent-current-view-v1';
    const SCROLL_KEY = 'dmd-agent-current-scroll-v1';
    const RELOAD_FLAG = 'dmd-agent-refresh-after-save-v1';

    let pendingRefresh = false;
    let refreshTimer = null;

    function saveView(view){
        if(!view || !view.kind || !view.name) return;
        try{
            sessionStorage.setItem(VIEW_KEY, JSON.stringify(view));
            sessionStorage.setItem(SCROLL_KEY, String(Math.max(0, window.scrollY || 0)));
        }catch(_){}
    }

    function routeFromElement(element){
        if(!element) return null;

        if(element.dataset.workspaceView){
            return {kind:'workspace-view', name:String(element.dataset.workspaceView)};
        }

        if(element.dataset.workspaceAdmin){
            return {kind:'workspace-admin', name:String(element.dataset.workspaceAdmin)};
        }

        if(element.dataset.openPanel){
            return {kind:'panel', name:String(element.dataset.openPanel)};
        }

        return null;
    }

    function routeFromContext(element){
        if(!element) return null;

        const adminPane = element.closest('[data-admin-pane]');
        if(adminPane?.dataset.adminPane){
            return {kind:'workspace-admin', name:String(adminPane.dataset.adminPane)};
        }

        const tool = element.closest('[data-panel]');
        if(tool?.dataset.panel){
            return {kind:'panel', name:String(tool.dataset.panel)};
        }

        const workspace = element.closest('[data-workspace-pane]');
        if(workspace?.dataset.workspacePane === 'fleet'){
            return {kind:'workspace-view', name:'fleet'};
        }

        return null;
    }

    function currentVisibleRoute(){
        const activeAdmin = document.querySelector(
            '[data-admin-pane].active:not([hidden]), [data-admin-pane]:not([hidden])'
        );
        if(activeAdmin?.dataset.adminPane){
            return {kind:'workspace-admin', name:String(activeAdmin.dataset.adminPane)};
        }

        const visiblePanel = [...document.querySelectorAll('[data-panel]')]
            .find(el => !el.hidden);
        if(visiblePanel?.dataset.panel){
            return {kind:'panel', name:String(visiblePanel.dataset.panel)};
        }

        return {kind:'workspace-view', name:'fleet'};
    }

    function rememberCurrentView(){
        saveView(currentVisibleRoute());
    }

    function restoreView(){
        let saved = null;
        let scrollY = 0;

        try{
            saved = JSON.parse(sessionStorage.getItem(VIEW_KEY) || 'null');
            scrollY = Math.max(0, Number(sessionStorage.getItem(SCROLL_KEY) || 0) || 0);
        }catch(_){}

        if(!saved || !saved.kind || !saved.name) return;

        let selector = '';

        if(saved.kind === 'workspace-view'){
            selector = '[data-workspace-view="' + CSS.escape(saved.name) + '"]';
        }else if(saved.kind === 'workspace-admin'){
            selector = '[data-workspace-admin="' + CSS.escape(saved.name) + '"]';
        }else if(saved.kind === 'panel'){
            selector = '[data-open-panel="' + CSS.escape(saved.name) + '"]';
        }

        if(!selector) return;

        const button = document.querySelector(selector);
        if(!button) return;

        /*
         * Le footer installe les gestionnaires de navigation avant
         * DOMContentLoaded. Un clic programmatique utilise donc exactement
         * le même parcours que l'utilisateur.
         */
        button.click();

        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                window.scrollTo({top:scrollY, left:0, behavior:'auto'});
            });
        });
    }

    function isConfigurationForm(form, submitter){
        if(!form) return false;

        /*
         * Ne jamais recharger après la création d'un enrôlement :
         * il faut laisser visible le lien temporaire nouvellement généré.
         */
        if(form.id === 'enrollmentInlineCreateForm') return false;

        if(form.matches(
            '.dmd-agent-admin-editor,' +
            '#pcGroupForm,' +
            '#userGroupForm,' +
            '#policyForm,' +
            '#remoteNoticeForm,' +
            '#myDeskSettingsForm'
        )){
            return true;
        }

        /*
         * Les autres écrans d'administration peuvent avoir leurs propres
         * formulaires. On ne considère comme configuration que les boutons
         * d'enregistrement explicites.
         */
        if(form.closest('[data-admin-pane]')){
            const label = String(submitter?.textContent || '').trim().toLowerCase();
            return /(enregistrer|sauvegarder|appliquer|mettre à jour|valider)/i.test(label);
        }

        return false;
    }

    function reloadCurrentView(){
        if(refreshTimer) clearTimeout(refreshTimer);

        rememberCurrentView();

        try{
            sessionStorage.setItem(RELOAD_FLAG, '1');
        }catch(_){}

        refreshTimer = setTimeout(() => {
            location.reload();
        }, 300);
    }

    /*
     * Toute navigation dans DMD-Agent mémorise la vue.
     * Un F5 / Ctrl+F5 revient donc sur cette même rubrique.
     */
    document.addEventListener('click', function(event){
        const target = event.target.closest(
            '[data-workspace-view], [data-workspace-admin], [data-open-panel]'
        );
        const route = routeFromElement(target);
        if(route) saveView(route);
    }, true);

    /*
     * Lors d'un enregistrement de configuration, on prépare un refresh.
     * Le refresh ne part QUE lorsqu'un message de succès est reçu.
     */
    document.addEventListener('submit', function(event){
        const form = event.target;
        if(!(form instanceof HTMLFormElement)) return;
        if(!isConfigurationForm(form, event.submitter)) return;

        const route = routeFromContext(form) || currentVisibleRoute();
        saveView(route);
        pendingRefresh = true;
    }, true);

    /*
     * showMsg() affiche les confirmations dans #msg avec la classe
     * dmd-agent-ok. On s'en sert comme confirmation que le serveur a
     * réellement accepté l'enregistrement avant de recharger.
     */
    window.addEventListener('DOMContentLoaded', function(){
        restoreView();

        const msg = document.getElementById('msg');
        if(msg){
            const observer = new MutationObserver(function(){
                if(!pendingRefresh) return;
                if(!msg.classList.contains('dmd-agent-ok')) return;
                if(!String(msg.textContent || '').trim()) return;

                pendingRefresh = false;
                reloadCurrentView();
            });

            observer.observe(msg, {
                attributes:true,
                attributeFilter:['class'],
                childList:true,
                characterData:true,
                subtree:true
            });
        }

        try{
            if(sessionStorage.getItem(RELOAD_FLAG) === '1'){
                sessionStorage.removeItem(RELOAD_FLAG);
            }
        }catch(_){}
    });

    window.addEventListener('beforeunload', rememberCurrentView);
})();
</script>
<?php

require __DIR__ . '/app/footer.php';
