(function(){
    'use strict';

    function fmtBytes(value){
        const n=Number(value||0);
        if(!Number.isFinite(n)||n<=0)return '—';
        const units=['o','Ko','Mo','Go'];let x=n,i=0;
        while(x>=1024&&i<units.length-1){x/=1024;i++;}
        return (i===0?Math.round(x):x.toFixed(x>=10?1:2))+' '+units[i];
    }
    function fmtDate(value){
        if(!value)return '—';
        const d=new Date(value);return Number.isNaN(d.getTime())?String(value):d.toLocaleString('fr-FR');
    }
    function csrf(){ return typeof CSRF!=='undefined' ? String(CSRF||'') : ''; }
    async function apiPost(url,payload){
        const token=csrf();
        const r=await fetch(url,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMD-CSRF':token},body:JSON.stringify(Object.assign({csrf_token:token},payload||{}))});
        const data=await r.json().catch(()=>({}));
        if(!r.ok||!data.ok){
            const detail=data&&data.details&&data.details.error ? ' ('+data.details.error+')' : '';
            throw new Error((data.message||data.error||('HTTP '+r.status))+detail);
        }
        return data;
    }
    function repoErrorLabel(error){
        const code=String(error||'');
        const map={
            repo_share_open_failed:'Impossible d’ouvrir le dossier OneDrive public.',
            repo_share_metadata_missing:'OneDrive n’a pas fourni les informations du partage.',
            repo_share_root_invalid:'Identifiant du dossier OneDrive invalide.',
            repo_share_drive_invalid:'Identifiant du stockage OneDrive invalide.',
            repo_anonymous_token_failed:'OneDrive refuse la création du jeton de lecture public.',
            repo_anonymous_token_invalid:'Jeton public OneDrive invalide.',
            repo_share_redeem_failed:'Impossible d’activer le lien de partage OneDrive.',
            repo_share_authorization_failed:'OneDrive refuse l’accès anonyme au dossier partagé.',
            repo_share_json_invalid:'Réponse OneDrive invalide pendant l’autorisation.',
            repo_children_failed:'Impossible de lire le contenu du dossier OneDrive.',
            repo_children_json_invalid:'Réponse OneDrive invalide.',
            curl_required:'PHP cURL est requis sur le serveur.'
        };
        return map[code]||code;
    }

    function setProgress(root,pct,message,stage){
        const fill=root.querySelector('[data-repo-progress-fill]');
        const value=root.querySelector('[data-repo-progress-value]');
        const text=root.querySelector('[data-repo-progress-text]');
        if(fill)fill.style.width=Math.max(0,Math.min(100,Number(pct)||0))+'%';
        if(value)value.textContent=Math.max(0,Math.min(100,Number(pct)||0))+'%';
        if(text)text.textContent=message||'';
        root.querySelectorAll('[data-repo-step]').forEach(el=>{
            const order=['scan','download','verify','extract','prepare','done'];
            const cur=order.indexOf(stage),idx=order.indexOf(el.dataset.repoStep||'');
            el.classList.toggle('active',idx===cur);
            el.classList.toggle('done',cur>idx || stage==='done');
            if(stage==='error'&&el.classList.contains('active'))el.classList.add('error'); else el.classList.remove('error');
        });
    }
    function populate(root,data){
        const select=root.querySelector('[data-repo-version]');
        const state=root.querySelector('[data-repo-state]');
        const install=root.querySelector('[data-repo-install]');
        if(!select)return;
        select.innerHTML='';
        const items=Array.isArray(data.items)?data.items:[];
        if(!items.length){
            const opt=document.createElement('option');opt.value='';opt.textContent='Aucun ZIP Agent trouvé';select.appendChild(opt);select.disabled=true;if(install)install.disabled=true;
        }else{
            items.forEach((item,index)=>{
                const opt=document.createElement('option');opt.value=String(item.item_key||'');
                opt.textContent=(item.version||item.name)+' — '+item.name+' — '+fmtBytes(item.size);
                opt.dataset.name=item.name||'';opt.dataset.version=item.version||'';opt.dataset.size=String(item.size||0);opt.dataset.modified=item.modified_at||'';
                if(index===0)opt.selected=true;select.appendChild(opt);
            });
            select.disabled=false;if(install)install.disabled=false;
        }
        const local=data.local||{};
        if(state){
            state.innerHTML=local.ready
                ? '<strong>Installateur actif</strong><span>'+(local.version?'Version '+escapeHtml(local.version)+' · ':'')+fmtBytes(local.size)+(local.installed_at?' · '+escapeHtml(fmtDate(local.installed_at)):'')+'</span>'
                : '<strong>Aucun installateur Agent actif</strong><span>DoMyDesk peut fonctionner sans Agent tant que tu ne l’actives pas.</span>';
        }
        updateSelectedInfo(root);
    }
    function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
    function updateSelectedInfo(root){
        const select=root.querySelector('[data-repo-version]'),info=root.querySelector('[data-repo-selection-info]');
        if(!select||!info)return;
        const opt=select.options[select.selectedIndex];
        if(!opt||!opt.value){info.textContent='';return;}
        info.textContent='ZIP : '+(opt.dataset.name||opt.textContent)+' · '+fmtBytes(opt.dataset.size)+' · '+fmtDate(opt.dataset.modified);
    }
    async function scan(root){
        const scanBtn=root.querySelector('[data-repo-scan]'),installBtn=root.querySelector('[data-repo-install]'),select=root.querySelector('[data-repo-version]');
        if(scanBtn)scanBtn.disabled=true;if(installBtn)installBtn.disabled=true;if(select)select.disabled=true;
        setProgress(root,4,'Analyse du dossier OneDrive…','scan');
        try{
            const data=await apiPost('api/admin_agent_repository_versions.php',{});
            populate(root,data);
            setProgress(root,8,(data.items||[]).length+' version(s) disponible(s).','scan');
            return data;
        }catch(e){
            const msg=repoErrorLabel(e.message||e);
            setProgress(root,0,'Analyse impossible : '+msg,'error');
            throw e;
        }finally{
            if(scanBtn)scanBtn.disabled=false;
        }
    }
    async function install(root,options){
        options=options||{};
        const select=root.querySelector('[data-repo-version]'),btn=root.querySelector('[data-repo-install]'),scanBtn=root.querySelector('[data-repo-scan]');
        const itemKey=String(select&&select.value||'');if(!itemKey)return;
        if(btn)btn.disabled=true;if(scanBtn)scanBtn.disabled=true;if(select)select.disabled=true;
        setProgress(root,4,'Préparation…','scan');
        const token=csrf();
        try{
            const response=await fetch('api/admin_agent_repository_install.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMD-CSRF':token},body:JSON.stringify({csrf_token:token,item_key:itemKey})});
            if(!response.ok&&!response.body){throw new Error('HTTP '+response.status);}
            if(!response.body||!response.body.getReader)throw new Error('Navigateur incompatible avec le suivi de progression.');
            const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',doneEvent=null;
            while(true){
                const chunk=await reader.read();if(chunk.done)break;
                buffer+=decoder.decode(chunk.value,{stream:true});
                const lines=buffer.split('\n');buffer=lines.pop()||'';
                for(const line of lines){
                    if(!line.trim())continue;
                    let event;try{event=JSON.parse(line);}catch(_){continue;}
                    setProgress(root,event.progress,event.message,event.stage);
                    if(event.stage==='done')doneEvent=event;
                    if(event.stage==='error')throw new Error(event.error||event.message||'activation_failed');
                }
            }
            if(buffer.trim()){
                try{const event=JSON.parse(buffer);setProgress(root,event.progress,event.message,event.stage);if(event.stage==='done')doneEvent=event;if(event.stage==='error')throw new Error(event.error||event.message);}catch(e){if(e instanceof SyntaxError){}else throw e;}
            }
            if(!doneEvent||doneEvent.ok===false)throw new Error('Activation incomplète.');
            const state=root.querySelector('[data-repo-state]');
            if(state){const local=doneEvent.local||{};state.innerHTML='<strong>Installateur actif</strong><span>'+(local.version?'Version '+escapeHtml(local.version)+' · ':'')+fmtBytes(local.size)+' · prêt pour les enrôlements</span>';}
            setProgress(root,100,'Installateur Agent prêt.','done');
            if(options.enableSystem){
                await apiPost('api/admin_agent_system_toggle.php',{enabled:true});
                setProgress(root,100,'Système Agents DoMyDesk activé.','done');
            }
            if(options.reload || root.dataset.reloadOnSuccess==='1')setTimeout(()=>location.reload(),700);
            return true;
        }catch(e){
            setProgress(root,100,'Activation impossible : '+repoErrorLabel(e.message||e),'error');
            throw e;
        }finally{
            if(btn)btn.disabled=false;if(scanBtn)scanBtn.disabled=false;if(select)select.disabled=false;
        }
    }
    async function activateSystem(root,button){
        if(button)button.disabled=true;
        const oldText=button?button.textContent:'';
        if(button)button.textContent='ACTIVATION EN COURS…';

        try{
            const localState=root.querySelector('[data-repo-state]');
            const localReady=!!(localState&&/Installateur actif/i.test(localState.textContent||''));

            let data=null;
            if(!localReady){
                data=await scan(root);
                const select=root.querySelector('[data-repo-version]');
                if(!data||!Array.isArray(data.items)||!data.items.length||!select||!select.value){
                    throw new Error('Aucune version Agent disponible dans le dossier OneDrive.');
                }
                await install(root,{enableSystem:true,reload:true});
            }else{
                await apiPost('api/admin_agent_system_toggle.php',{enabled:true});
                setProgress(root,100,'Système Agents DoMyDesk activé.','done');
                setTimeout(()=>location.reload(),500);
            }
        }catch(e){
            setProgress(root,100,'Activation impossible : '+repoErrorLabel(e.message||e),'error');
            if(button){button.disabled=false;button.textContent=oldText;}
        }
    }

    async function disableSystem(button){
        if(!confirm('Désactiver le système Agents DoMyDesk ?\\n\\nLes données et l’installateur déjà téléchargé sont conservés.'))return;
        const oldText=button?button.textContent:'';
        if(button){button.disabled=true;button.textContent='Désactivation…';}
        try{
            await apiPost('api/admin_agent_system_toggle.php',{enabled:false});
            location.reload();
        }catch(e){
            alert('Désactivation impossible : '+repoErrorLabel(e.message||e));
            if(button){button.disabled=false;button.textContent=oldText;}
        }
    }

    function initRoot(root){
        if(root.dataset.repoInitialized==='1')return;root.dataset.repoInitialized='1';
        root.querySelector('[data-repo-scan]')?.addEventListener('click',()=>scan(root));
        root.querySelector('[data-repo-install]')?.addEventListener('click',()=>install(root,{reload:false}).catch(()=>{}));
        root.querySelector('[data-repo-version]')?.addEventListener('change',()=>updateSelectedInfo(root));
        if(root.dataset.autoScan==='1')scan(root).catch(()=>{});
    }
    function openModal(){
        const modal=document.querySelector('[data-dmd-repo-modal]');if(!modal)return;
        modal.hidden=false;modal.setAttribute('aria-hidden','false');
        const root=modal.querySelector('[data-dmd-repo-root]');if(root){initRoot(root);scan(root);}
    }
    function closeModal(){const modal=document.querySelector('[data-dmd-repo-modal]');if(modal){modal.hidden=true;modal.setAttribute('aria-hidden','true');}}
    document.addEventListener('click',e=>{
        const enableBtn=e.target.closest('[data-agent-system-enable]');
        if(enableBtn){
            e.preventDefault();
            const root=document.querySelector('[data-dmd-repo-root]');
            if(root){initRoot(root);activateSystem(root,enableBtn);}
            return;
        }
        const disableBtn=e.target.closest('[data-agent-system-disable]');
        if(disableBtn){
            e.preventDefault();
            disableSystem(disableBtn);
            return;
        }
        if(e.target.closest('[data-open-agent-repository]')){e.preventDefault();openModal();return;}
        if(e.target.closest('[data-close-agent-repository]')){e.preventDefault();closeModal();return;}
        const modal=e.target.closest('[data-dmd-repo-modal]');if(modal&&e.target===modal)closeModal();
    });
    document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
    document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('[data-dmd-repo-root]').forEach(initRoot));
})();
