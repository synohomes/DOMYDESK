    <header class="dmd-agent-hero dmd-r19-appbar dmd-r37-appbar">
        <div class="dmd-r37-brand">
            <div class="dmd-r37-brand-mark">▣</div>
            <div class="dmd-r37-brand-copy">
                <strong>DMD-Agent</strong>
                <span>Gestion et supervision des postes</span>
            </div>
        </div>
        <label class="dmd-r37-global-search" for="agentGlobalSearch">
            <span aria-hidden="true">⌕</span>
            <input id="agentGlobalSearch" type="search" placeholder="Rechercher un poste, une IP, un utilisateur, un groupe…" autocomplete="off">
            <kbd>Ctrl K</kbd>
        </label>

        <nav class="dmd-r37-header-kpis" aria-label="Résumé du parc">
            <button type="button" class="dmd-r37-header-kpi" data-workspace-view="fleet" data-kpi-filter="online" title="Afficher les postes en ligne">
                <span class="dmd-r37-header-kpi-icon ok">▣</span><span><strong><?= (int)$onlineCount ?></strong><small>Postes en ligne</small></span>
            </button>
            <button type="button" class="dmd-r37-header-kpi" data-workspace-view="fleet" data-kpi-filter="offline" title="Afficher les postes hors ligne">
                <span class="dmd-r37-header-kpi-icon bad">▣</span><span><strong><?= max(0,(int)$activeCount-(int)$onlineCount) ?></strong><small>Postes hors ligne</small></span>
            </button>
            <button type="button" class="dmd-r37-header-kpi" data-open-panel="enrollments" title="Ouvrir les enrôlements à valider">
                <span class="dmd-r37-header-kpi-icon warn">◷</span><span><strong><?= (int)$pendingCount ?></strong><small>À valider</small></span>
            </button>
            <button type="button" class="dmd-r37-header-kpi" data-workspace-view="fleet" data-kpi-filter="all" title="Afficher tout le parc">
                <span class="dmd-r37-header-kpi-icon info">●</span><span><strong><?= (int)$activeCount ?></strong><small>Postes gérés</small></span>
            </button>
            <button type="button" class="dmd-r37-header-kpi" data-open-panel="security" title="Ouvrir la sécurité">
                <span class="dmd-r37-header-kpi-icon ok">✓</span><span><strong><?= !empty($identity['ok'])?'0':'1' ?></strong><small>Alertes sécurité</small></span>
            </button>
            <button type="button" class="dmd-r37-header-kpi" data-workspace-admin="pc-groups" title="Ouvrir les groupes de PC">
                <span class="dmd-r37-header-kpi-icon info">♟</span><span><strong><?= count((array)($pcGroupsData['groups']??array())) ?></strong><small>Groupes de PC</small></span>
            </button>
        </nav>
    </header>

    <div id="msg" class="dmd-agent-message" role="status" aria-live="polite"></div>

    <section class="dmd-agent-workspace dmd-r19-workspace dmd-r37-workspace" aria-label="Console DMD-Agent et DMD-MyDesk">
        <aside class="dmd-agent-workspace-nav dmd-r19-sidebar dmd-r37-sidebar" aria-label="Navigation administration">
            <nav>
                <button type="button" class="active dmd-r37-dashboard-link" data-workspace-view="dashboard"><span><i>⌂</i>Tableau de bord</span></button>

                <div class="dmd-r19-nav-label">Parc</div>
                <button type="button" data-open-panel="enrollments"><span><i>◉</i>Enrôlements</span><b><?= (int)$pendingCount ?></b></button>
				<button type="button" data-workspace-admin="mydesk"><span><i>◆</i>DMD-MyDesk</span><b><?= (int)$myDeskSelectedCount ?>/<?= dmd_agent_h($licenseQuotaText($myDeskLimit)) ?></b></button>
                <button type="button" data-workspace-admin="licenses"><span><i>▥</i>Licences</span></button>
                <button type="button" data-workspace-admin="audits"><span><i>≣</i>Audits</span><b><?= count($agentAudits) ?></b></button>

                <div class="dmd-r19-nav-label">Opérations</div>
                <button type="button" data-workspace-admin="backup"><span><i>◫</i>Sauvegardes</span></button>
                <button type="button" data-workspace-admin="network-scan"><span><i>⌁</i>Scan réseau</span></button>
                <button type="button" data-maintenance-popup="software-bulk"><span><i>＋</i>Installation logiciels</span></button>
                <button type="button" data-maintenance-popup="software-updates"><span><i>↻</i>Mise à jour logiciels</span></button>
                <button type="button" data-maintenance-popup="agent-update"><span><i>◌</i>Mise à jour Agents</span></button>
                <button type="button" data-maintenance-popup="pc-update"><span><i>⟳</i>Mise à jour système</span></button>

                <div class="dmd-r19-nav-label">Organisation</div>
                <button type="button" data-workspace-admin="pc-groups"><span><i>♟</i>Groupes de PC</span><b><?= count((array)($pcGroupsData['groups']??array())) ?></b></button>
                <button type="button" data-workspace-admin="user-groups"><span><i>♚</i>Groupes utilisateurs</span><b><?= count((array)($userGroupsData['groups']??array())) ?></b></button>
                <button type="button" data-workspace-admin="rights"><span><i>⚿</i>Droits RemoteAgent</span><b><?= count((array)($policiesData['policies']??array())) ?></b></button>

                <div class="dmd-r19-nav-label"></div>
			
            </nav>
            <button type="button" class="dmd-r37-sidebar-collapse" aria-label="Réduire le menu"><span>«</span> Réduire le menu</button>
        </aside>

        <div class="dmd-agent-workspace-main dmd-r19-main dmd-r37-main">
