<div id="maintenanceMyDeskModal" class="dmd-agent-modal dmd-maint-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-maint-close></div>
    <section class="dmd-agent-modal-card dmd-maint-card medium" role="dialog" aria-modal="true" aria-labelledby="maintenanceMyDeskTitle">
        <header class="dmd-maint-head">
            <div><h2 id="maintenanceMyDeskTitle">Configuration MyDesk</h2><p>Modules proposés dans la barre des tâches DMD-MyDesk Windows.</p></div>
            <button type="button" class="dmd-agent-icon-btn" data-maint-close aria-label="Fermer">×</button>
        </header>
        <form id="maintenanceMyDeskForm" class="dmd-maint-body">
            <section class="dmd-maint-panel">
                <div class="dmd-maint-panel-head"><div><h3>Modules visibles</h3><p>Sélection globale appliquée aux clients DMD-MyDesk autorisés.</p></div><strong id="maintMyDeskCount">0</strong></div>
                <div id="maintMyDeskModules" class="dmd-maint-module-grid"><?php if(!$myDeskModules): ?>
<div class="dmd-maint-empty">Aucun module installé ne déclare la compatibilité MyDesk.</div>
<?php else: foreach($myDeskModules as $myDeskModule): $mdEnabled=dmd_agent_mydesk_module_enabled($myDeskModule,$myDeskSettings); ?>
<label class="dmd-maint-module">
    <input type="checkbox" name="maintenance_mydesk_modules[]" value="<?= dmd_agent_h($myDeskModule['id']) ?>" <?= $mdEnabled?'checked':'' ?> <?= !$myDeskLicensed?'disabled':'' ?>>
    <span>
        <strong><?= dmd_agent_h($myDeskModule['label']) ?></strong>
        <small><?= dmd_agent_h($myDeskModule['id']) ?><?= !empty($myDeskModule['description'])?' · '.dmd_agent_h($myDeskModule['description']):'' ?></small>
    </span>
</label>
<?php endforeach; endif; ?></div>
            </section>
            <section class="dmd-maint-panel">
                <div class="dmd-maint-actions"><button type="submit" class="dmd-agent-btn primary" >Enregistrer la configuration MyDesk</button></div>
                <div id="maintMyDeskResult" class="dmd-maint-results">Aucune modification enregistrée.</div>
            </section>
        </form>
        <footer class="dmd-maint-foot"><span>Les droits propres à chaque module restent inchangés.</span><button type="button" class="dmd-agent-btn" data-maint-close>Fermer</button></footer>
    </section>
</div>

