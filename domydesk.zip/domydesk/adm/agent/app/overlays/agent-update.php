<div id="maintenanceAgentUpdateModal" class="dmd-agent-modal dmd-maint-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-maint-close></div>
    <section class="dmd-agent-modal-card dmd-maint-card dmd-r19-update-page" role="dialog" aria-modal="true" aria-labelledby="maintenanceAgentUpdateTitle">
        <header class="dmd-r19-update-head">
            <div class="dmd-r19-update-title">
                <span class="dmd-r19-update-icon">⬡</span>
                <div><h2 id="maintenanceAgentUpdateTitle">Mise à jour des Agents</h2><p>DMD-Agent, DMD-Update, DMD-Remote et DMD-MyDesk sur les postes distants.</p></div>
            </div>
            <div class="dmd-r19-update-head-actions">
                <button type="button" class="dmd-agent-btn" id="maintAgentPackagesRefresh">↻ Vérifier les mises à jour</button>
                <button type="button" class="dmd-agent-btn" data-r19-update-tab="repository">Gestion des versions</button>
                <button type="button" class="dmd-agent-icon-btn" data-maint-close aria-label="Fermer">×</button>
            </div>
        </header>

        <nav class="dmd-r19-update-tabs" aria-label="Navigation mise à jour">
            <button type="button" class="active" data-r19-update-tab="overview">Vue d’ensemble</button>
            <button type="button" data-r19-update-tab="deployment">Déploiement</button>
            <button type="button" data-r19-update-tab="schedule">Planification</button>
            <button type="button" data-r19-update-tab="history">Historique</button>
            <button type="button" data-r19-update-tab="repository">Dépôt / versions</button>
        </nav>

        <div class="dmd-r19-update-body">
            <section class="dmd-r19-update-pane active" data-r19-update-pane="overview">
                <div class="dmd-r19-update-summary-grid">
                    <article><span>Version publique</span><strong>1.4.0</strong><small>DMD-Agent</small></article>
                    <article><span>Build cible</span><strong id="r19AgentTargetVersion">—</strong><small>Package sélectionné</small></article>
                    <article><span>PC sélectionnés</span><strong id="r19AgentTargetCount">0</strong><small>Pour le prochain déploiement</small></article>
                    <article><span>État</span><strong id="r19AgentDeployState">Prêt</strong><small id="maintAgentBinaryState">Vérification…</small></article>
                </div>

                <section class="dmd-r19-update-components">
                    <div class="dmd-r19-section-head"><div><h3>Composants DoMyDesk</h3><p>Le package met à niveau les composants installés sans recréer l’enrôlement ni les clés.</p></div><button type="button" class="dmd-agent-btn primary" data-r19-update-tab="deployment">Préparer le déploiement</button></div>
                    <div class="dmd-r19-component-table-wrap">
                        <table class="dmd-r19-component-table">
                            <thead><tr><th>Composant</th><th>Version publique</th><th>Build cible</th><th>Comportement</th><th>État</th></tr></thead>
                            <tbody>
                                <tr><td><strong>DMD-Agent</strong><small>Service principal</small></td><td>1.4.0</td><td data-r19-target-build>—</td><td>Toujours mis à jour</td><td><span class="dmd-r19-state ok">Prêt</span></td></tr>
                                <tr><td><strong>DMD-Update</strong><small>Moteur autonome</small></td><td>1.4.0</td><td data-r19-target-build>—</td><td>Toujours mis à jour</td><td><span class="dmd-r19-state ok">Prêt</span></td></tr>
                                <tr><td><strong>DMD-Remote</strong><small>Prise en main distante</small></td><td>1.4.0</td><td data-r19-target-build>—</td><td>Si installé</td><td><span class="dmd-r19-state ok">Sélectif</span></td></tr>
                                <tr><td><strong>DMD-MyDesk</strong><small>Client utilisateur</small></td><td>1.4.0</td><td data-r19-target-build>—</td><td>Si installé</td><td><span class="dmd-r19-state ok">Sélectif</span></td></tr>
                            </tbody>
                        </table>
                    </div>
                </section>

                <section class="dmd-r19-update-overview-actions">
                    <button type="button" class="dmd-r19-big-action" data-r19-update-tab="repository"><strong>＋ Ajouter une mise à jour</strong><span>Importer et gérer les versions disponibles</span></button>
                    <button type="button" class="dmd-r19-big-action" data-r19-update-tab="deployment"><strong>⬡ Déployer sur le parc</strong><span>Sélectionner les PC et suivre la progression</span></button>
                    <button type="button" class="dmd-r19-big-action" data-r19-update-tab="history"><strong>≣ Consulter le journal</strong><span>Succès, échecs, cause et utilisateur</span></button>
                </section>
            </section>

            <section class="dmd-r19-update-pane" data-r19-update-pane="deployment" hidden>
                <section class="dmd-maint-panel dmd-r19-update-target-panel">
                    <div class="dmd-maint-panel-head"><div><h3>PC cibles</h3><p>Sélectionne les Agents à mettre à jour. La progression est suivie poste par poste.</p></div><label class="dmd-maint-checkall"><input type="checkbox" id="maintAgentAllPc"> Tous</label></div>
                    <div id="maintAgentPcGrid" class="dmd-maint-pc-grid dmd-maint-update-pc-grid"><?php foreach($devices as $d):
                        $aid=(string)($d['agent_id']??'');
                        $hn=(string)($d['hostname']??'PC');
                        $ver=(string)($d['agent_version']??'—');
                        $dip=(string)($d['last_ip']??'IP inconnue');
                        $dst=(string)($d['status']??'');
                        $isServer=stripos(dmd_agent_device_os_label($d),'server')!==false;
                    ?>
                    <div class="dmd-maint-pc dmd-maint-update-pc">
                        <label class="dmd-maint-pc-main">
                            <input class="dmd-maint-pc-target" type="checkbox" value="<?= dmd_agent_h($aid) ?>" <?= $dst==='active'?'':'disabled' ?>>
                            <span><strong><?= dmd_agent_h($hn) ?></strong><small><?= dmd_agent_h($dip) ?> · Build <?= dmd_agent_h($ver) ?><?= $dst==='active'?'':' · '.dmd_agent_h($dst) ?></small></span>
                        </label>
                        <label class="dmd-maint-reboot-mini <?= $isServer?'server':'' ?>" title="Autoriser le redémarrage automatique après une mise à jour réussie">
                            <input class="dmd-maint-pc-autoreboot" type="checkbox" data-reboot-agent="<?= dmd_agent_h($aid) ?>" <?= ($dst==='active'&&!$isServer)?'checked':'' ?> <?= $dst==='active'?'':'disabled' ?>>
                            <span>Auto</span>
                        </label>
                    </div>
                    <?php endforeach; ?></div>
                </section>

                <section class="dmd-maint-panel dmd-maint-update-run-panel">
                    <div class="dmd-maint-update-run-head">
                        <div><strong>Déploiement</strong><small id="maintAgentUpdateRunState">Aucune mise à jour lancée.</small></div>
                        <div class="dmd-maint-actions"><button type="button" class="dmd-agent-btn primary" id="maintAgentUpdateRun">Mettre à jour les Agents sélectionnés</button></div>
                    </div>
                    <div id="maintAgentGlobalProgress" class="dmd-maint-update-global" hidden>
                        <div><strong>Progression globale</strong><span id="maintAgentGlobalProgressText">0 %</span></div>
                        <div class="dmd-maint-update-progressbar large"><i id="maintAgentGlobalProgressBar" style="width:0%"></i></div>
                    </div>
                    <div id="maintAgentUpdateResults" class="dmd-maint-results dmd-maint-update-results"><div class="dmd-maint-empty">Aucune mise à jour lancée.</div></div>
                </section>
            </section>

            <section class="dmd-r19-update-pane" data-r19-update-pane="schedule" hidden>
                <section class="dmd-maint-panel dmd-maint-reboot-policy-panel dmd-r19-schedule-panel">
                    <div class="dmd-maint-panel-head"><div><h3>Redémarrage automatique après succès</h3><p>La notification sur le PC distant reste obligatoire. Les PC marqués « Auto » suivent cette règle.</p></div><span class="dmd-maint-notify-pill">Utilisateur notifié</span></div>
                    <div class="dmd-maint-reboot-policy-grid">
                        <label><span>Mode</span><select id="maintAgentRebootMode"><option value="none">Aucun redémarrage automatique</option><option value="now">Après la mise à jour (préavis 60 s)</option><option value="countdown" selected>Compte à rebours</option><option value="at">À une heure précise</option></select></label>
                        <label id="maintAgentRebootCountdownWrap" hidden><span>Compte à rebours</span><div class="dmd-maint-input-unit"><input type="number" id="maintAgentRebootMinutes" min="1" max="10080" value="15"><b>min</b></div></label>
                        <label id="maintAgentRebootTimeWrap" hidden><span>Heure</span><input type="time" id="maintAgentRebootTime" value="23:00"></label>
                    </div>
                    <div class="dmd-maint-reboot-note">Les Windows Server restent sans redémarrage automatique par défaut. Le choix Auto reste individuel par PC.</div>
                </section>
            </section>

            <section class="dmd-r19-update-pane" data-r19-update-pane="history" hidden>
                <section class="dmd-maint-panel dmd-update-log-inline-panel" id="maintAgentUpdateLogsSection">
                    <div class="dmd-maint-panel-head dmd-update-log-inline-head">
                        <div><h3>Journal des mises à jour Agent</h3><p>Qui a lancé quoi, quand, sur quel PC, avec la réussite ou la cause réelle de l’échec.</p></div>
                        <div class="dmd-maint-actions">
                            <button type="button" class="dmd-agent-btn" id="maintUpdateLogsRefresh">Rafraîchir</button>
                            <button type="button" class="dmd-agent-btn primary" id="maintUpdateLogsPdf">Exporter PDF</button>
                            <button type="button" class="dmd-agent-btn danger" id="maintUpdateLogsPurge">Purger</button>
                        </div>
                    </div>
                    <div class="dmd-update-log-toolbar dmd-update-log-toolbar-inline">
                        <label><span>État</span><select id="maintUpdateLogsStatus"><option value="all">Tous</option><option value="success">Réussites</option><option value="error">Échecs</option><option value="running">En cours / demandées</option></select></label>
                        <label><span>Recherche</span><input type="search" id="maintUpdateLogsSearch" placeholder="Utilisateur, PC, build, cause…"></label>
                        <strong id="maintUpdateLogsSummary">Chargement…</strong>
                    </div>
                    <div class="dmd-update-log-table-wrap dmd-update-log-table-wrap-inline">
                        <table class="dmd-update-log-table"><thead><tr><th>Date / heure</th><th>Utilisateur</th><th>Action</th><th>PC / cible</th><th>Build</th><th>Résultat</th><th>Cause / détail</th></tr></thead><tbody id="maintUpdateLogsRows"><tr><td colspan="7">Chargement du journal…</td></tr></tbody></table>
                    </div>
                </section>
            </section>

            <section class="dmd-r19-update-pane" data-r19-update-pane="repository" hidden>
                <section class="dmd-maint-panel dmd-maint-update-repository dmd-r19-repository-panel">
                    <div class="dmd-maint-panel-head"><div><h3>Dépôt des mises à jour Agent</h3><p>Packages disponibles pour le déploiement des nouvelles versions de DMD-Agent.</p></div></div>
                    <div class="dmd-maint-update-repo-toolbar">
                        <label class="dmd-maint-update-version-field"><span>Version à déployer</span><select id="maintAgentVersionSelect"><option value="">Chargement…</option></select></label>
                        <div class="dmd-maint-update-repo-buttons">
                            <input type="file" id="maintAgentZipInput" accept=".zip,application/zip" hidden>
                            <button type="button" class="dmd-agent-btn primary" id="maintAgentZipPick">+ Ajouter un ZIP</button>
                            <button type="button" class="dmd-agent-btn danger" id="maintAgentPackagesDelete" disabled>Supprimer la sélection</button>
                        </div>
                    </div>
                    <div id="maintAgentUploadProgress" class="dmd-maint-update-upload" hidden>
                        <div><strong>Import du ZIP</strong><span id="maintAgentUploadProgressText">0 %</span></div>
                        <div class="dmd-maint-update-progressbar"><i id="maintAgentUploadProgressBar" style="width:0%"></i></div>
                    </div>
                    <div class="dmd-maint-update-repo-summary"><label><input type="checkbox" id="maintAgentPackagesAll"> Tout sélectionner</label><span id="maintAgentPackagesSummary">Lecture du dépôt…</span></div>
                    <div id="maintAgentPackagesList" class="dmd-maint-update-package-pairs"><div class="dmd-maint-empty">Chargement…</div></div>
                    <label class="dmd-maint-checkline"><input type="checkbox" id="maintAgentForce" checked> Forcer la réinstallation si la version est identique</label>
                </section>
            </section>
        </div>

        <footer class="dmd-r19-update-foot"><span><code></code><code></code>.</span></footer>
    </section>
</div>
