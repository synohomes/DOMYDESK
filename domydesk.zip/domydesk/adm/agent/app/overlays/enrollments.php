<link rel="stylesheet" href="assets/enrollments.css?v=20260911-0816">
<?php
/* Alias d'enrôlement par nom réel / agent id, uniquement pour l'affichage des cartes. */
$enrollmentAliasByHost = array();
$enrollmentAliasByAgent = array();
$enrollmentMetaByHost = array();
$enrollmentMetaByAgent = array();

/* Groupes PC disponibles pour l'affectation automatique lors de l'enrôlement. */
$enrollmentPcGroups = array();
foreach ((array)($pcGroupsData['groups'] ?? array()) as $groupId => $groupRow) {
    if (!is_array($groupRow)) continue;

    $resolvedId = trim((string)($groupRow['group_id'] ?? $groupId));
    $resolvedName = trim((string)($groupRow['name'] ?? ''));
    if ($resolvedId === '' || $resolvedName === '') continue;

    $enrollmentPcGroups[] = array(
        'group_id' => $resolvedId,
        'name' => $resolvedName,
    );
}
usort($enrollmentPcGroups, function($a, $b) {
    return strnatcasecmp((string)$a['name'], (string)$b['name']);
});

foreach ((array)$enrollments as $enr) {
    if (!is_array($enr)) continue;

    $alias = trim((string)($enr['target_name'] ?? ''));
    if ($alias === '') continue;

    $candidate = isset($enr['candidate']) && is_array($enr['candidate']) ? $enr['candidate'] : array();

    $candidateHost = strtolower(trim((string)($candidate['hostname'] ?? '')));
    $candidateAgent = trim((string)($candidate['agent_id'] ?? $enr['agent_id'] ?? ''));

    $meta = array(
        'enrollment_id' => trim((string)($enr['enrollment_id'] ?? '')),
        'status'        => trim((string)($enr['status'] ?? '')),
        'created_at'    => trim((string)($enr['created_at'] ?? '')),
        'created_by'    => trim((string)($enr['created_by'] ?? $enr['created_by_name'] ?? $enr['created_by_email'] ?? $enr['owner'] ?? ''))
    );

    if ($candidateHost !== '') {
        $enrollmentAliasByHost[$candidateHost] = $alias;
        $enrollmentMetaByHost[$candidateHost] = $meta;
    }

    if ($candidateAgent !== '') {
        $enrollmentAliasByAgent[$candidateAgent] = $alias;
        $enrollmentMetaByAgent[$candidateAgent] = $meta;
    }
}
?>

<section id="panel-enrollments" class="dmd-agent-drawer" hidden data-panel="enrollments">
    <div class="dmd-enrollments-toolbar">
        <?php if(count($enrollments)>0): ?>
            <button type="button" class="dmd-agent-btn danger" id="deleteAllEnrollments">
                Tout supprimer (<?= count($enrollments) ?>)
            </button>
        <?php endif; ?>
        <button type="button" class="dmd-agent-icon-btn" data-close-panel aria-label="Fermer">×</button>
    </div>

    <div class="dmd-enrollments-layout">

        <!-- =========================================================
             NOUVEL ENRÔLEMENT
             ========================================================= -->
        <section class="dmd-enrollment-section dmd-enrollment-create">
            <div class="dmd-enrollment-section-head">
                <div>
                    <h3>Nouvel enrôlement</h3>
                    <p>Prépare directement l'installation du nouveau poste.</p>
                </div>
                <div class="dmd-enrollment-installer-tools">
                    <?php $dmdRepoLocal = function_exists('dmd_agent_repo_local_status') ? dmd_agent_repo_local_status() : array(); ?>
                    <span class="dmd-enrollment-installer-badge" title="Installateur utilisé pour les nouveaux enrôlements">
                        DMD-Installer<?= !empty($dmdRepoLocal['version']) ? ' · '.dmd_agent_h($dmdRepoLocal['version']) : '' ?>
                    </span>
                    <button type="button" class="dmd-agent-mini-btn" data-open-agent-repository>Changer de version</button>
                </div>
            </div>

            <form id="enrollmentInlineCreateForm" class="dmd-enrollment-create-form">
                <div class="dmd-enrollment-form-block dmd-enrollment-form-block-machine">
                    <div class="dmd-enrollment-form-block-head"><strong>Poste</strong><small>Nom de gestion et groupe de destination.</small></div>
                    <div class="dmd-enrollment-form-block-grid two">
                <label class="dmd-enrollment-field dmd-enrollment-field-name">
                    <span>Nom / alias prévu</span>
                    <input
                        type="text"
                        name="target_name"
                        maxlength="100"
                        placeholder="POSTE-01"
                        required
                    >
                </label>

                <label class="dmd-enrollment-field dmd-enrollment-field-group">
                    <span>Groupe de PC</span>
                    <select name="pc_group_id">
                        <option value="">Aucun groupe</option>
                        <?php foreach($enrollmentPcGroups as $pcGroup): ?>
                            <option value="<?= dmd_agent_h($pcGroup['group_id']) ?>">
                                <?= dmd_agent_h($pcGroup['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small>Le poste sera ajouté automatiquement à ce groupe dès son approbation.</small>
                </label>
                    </div>
                </div>

                <div class="dmd-enrollment-form-block dmd-enrollment-form-block-network">
                    <div class="dmd-enrollment-form-block-head"><strong>Connexion à DoMyDesk</strong><small>Une ou plusieurs adresses pour retrouver cette instance.</small></div>

                <div class="dmd-enrollment-field dmd-enrollment-server-field">
                    <div class="dmd-enrollment-server-label">
                        <span>Adresses / IP DoMyDesk utilisables par l'agent</span>
                        <button type="button" class="dmd-enrollment-help-btn" id="enrollmentServerHelp" title="Procédure" aria-label="Procédure">?</button>
                    </div>

                    <div id="enrollmentServerRows" class="dmd-enrollment-server-rows"></div>

                    <div class="dmd-enrollment-server-actions">
                        <button type="button" class="dmd-agent-mini-btn" id="enrollmentAddServerUrl">+ Ajouter une adresse</button>
                        <button type="button" class="dmd-agent-mini-btn" id="enrollmentAddCurrentUrl">+ Adresse actuellement ouverte</button>
                    </div>

                    <datalist id="enrollmentServerUrlChoices"></datalist>
                    <small class="dmd-enrollment-server-hint">Saisis uniquement l'adresse, l'IP ou le nom. DoMyDesk détecte automatiquement son point d'accès puis l'agent essaie les adresses dans l'ordre.</small>
                </div>
                </div>

                <div class="dmd-enrollment-form-block dmd-enrollment-form-block-rules">
                    <div class="dmd-enrollment-form-block-head"><strong>Règles d'enrôlement</strong><small>Durée de validité et mode d'autorisation.</small></div>
                    <div class="dmd-enrollment-form-block-grid two">
                <label class="dmd-enrollment-field">
                    <span>Expiration</span>
                    <select name="expires_minutes">
                        <option value="15">15 minutes</option>
                        <option value="60">1 heure</option>
                        <option value="360">6 heures</option>
                        <option value="1440" selected>24 heures</option>
                        <option value="10080">7 jours</option>
                    </select>
                </label>

                <label class="dmd-enrollment-field">
                    <span>Validation</span>
                    <select name="approval_mode">
                        <option value="manual" selected>Validation Superadmin</option>
                        <option value="auto">Automatique</option>
                    </select>
                </label>
                    </div>
                </div>

                <div class="dmd-enrollment-form-block dmd-enrollment-form-block-components">
                    <div class="dmd-enrollment-form-block-head"><strong>Composants</strong><small>Choisis ce qui sera installé sur le poste.</small></div>
                    <div class="dmd-enrollment-component-grid">
                <label class="dmd-enrollment-option">
                    <input type="checkbox" name="include_remote" value="1" checked>
                    <span>
                        <strong>DMD-Remote</strong>
                        <small>Inclure la prise en main distante.</small>
                    </span>
                </label>

                <label class="dmd-enrollment-option">
                    <input type="checkbox" name="include_mydesk" value="1">
                    <span>
                        <strong>DMD-MyDesk</strong>
                        <small>Inclure le client utilisateur MyDesk.</small>
                    </span>
                </label>
                    </div>
                </div>

                <button type="submit" class="dmd-agent-btn primary dmd-enrollment-create-btn">
                    Créer l'enrôlement
                </button>
            </form>

            <div id="enrollmentServerHelpPopup" class="dmd-enrollment-help-popup" hidden aria-hidden="true">
                <div class="dmd-enrollment-help-window" role="dialog" aria-modal="true" aria-labelledby="enrollmentServerHelpTitle">
                    <div class="dmd-enrollment-help-head">
                        <div>
                            <strong id="enrollmentServerHelpTitle">Procédure — adresses de connexion</strong>
                            <small>Ajoute uniquement des adresses qui pointent vers cette même instance DoMyDesk.</small>
                        </div>
                        <button type="button" class="dmd-agent-mini-btn" id="enrollmentServerHelpClose">Fermer</button>
                    </div>

                    <div class="dmd-enrollment-help-body">
                        <div class="dmd-enrollment-help-case">
                            <strong>IP locale</strong>
                            <code>http://192.168.1.50</code>
                            <span>Pour un poste présent sur le LAN ou connecté au réseau par VPN.</span>
                        </div>

                        <div class="dmd-enrollment-help-case">
                            <strong>Nom DNS / nom de machine</strong>
                            <code>http://serveur-lan</code>
                            <span>Le poste cible doit être capable de résoudre ce nom.</span>
                        </div>

                        <div class="dmd-enrollment-help-case">
                            <strong>Adresse publique</strong>
                            <code>https://domydesk.exemple.fr</code>
                            <span>Pour les postes qui doivent joindre l'instance depuis Internet.</span>
                        </div>

                        <div class="dmd-enrollment-help-note">
                            <strong>Détection automatique :</strong>
                            tu peux saisir uniquement une IP, un nom local ou un domaine.
                            DoMyDesk teste automatiquement la racine puis le chemin de l'instance (par exemple <code>/domydesk</code>).
                            Un chemin complet saisi manuellement reste accepté et n'est jamais remplacé.
                        </div>

                        <div class="dmd-enrollment-help-note">
                            <strong>Plusieurs adresses :</strong>
                            ajoute plusieurs lignes et place-les dans l'ordre souhaité.
                            Pendant l'enrôlement, l'agent essaie chaque adresse jusqu'à ce qu'une connexion fonctionne.
                        </div>
                    </div>
                </div>
            </div>

            <div id="enrollmentInlineResult" class="dmd-enrollment-create-result" hidden>
                <div class="dmd-enrollment-install-result-main">
                    <div>
                        <strong>Enrôlement créé</strong>
                        <small id="enrollmentInlineResultText">Le lien temporaire télécharge directement DMD-Installer.exe.</small>
                    </div>

                    <div class="dmd-enrollment-install-link-row">
                        <input
                            type="text"
                            id="enrollmentInlineInstallLink"
                            readonly
                            spellcheck="false"
                            aria-label="Lien temporaire d'installation"
                        >
                        <button type="button" class="dmd-agent-mini-btn" id="enrollmentInlineCopyInstallLink">
                            Copier le lien
                        </button>
                    </div>
                </div>

                <div class="dmd-enrollment-create-result-actions">
                    <button type="button" class="dmd-agent-btn primary" id="enrollmentInlineDownloadInstaller">
                        Télécharger l’installateur
                    </button>
                    <button type="button" class="dmd-agent-mini-btn" id="enrollmentInlineCopyBootstrap">
                        Copier le JSON
                    </button>
                </div>
            </div>

            <textarea id="enrollmentInlineBootstrap" hidden></textarea>
        </section>

        <!-- =========================================================
             ENRÔLEMENTS / PC — VIGNETTES + RECHERCHE
             ========================================================= -->
        <section class="dmd-enrollment-section dmd-enrolled-pcs">
            <?php
            $deviceByAgent = array();
            $deviceByHost = array();

            foreach ((array)$devices as $deviceRow) {
                if (!is_array($deviceRow)) continue;

                $deviceAgent = trim((string)($deviceRow['agent_id'] ?? ''));
                $deviceHost  = strtolower(trim((string)($deviceRow['hostname'] ?? '')));

                if ($deviceAgent !== '') $deviceByAgent[$deviceAgent] = $deviceRow;
                if ($deviceHost !== '')  $deviceByHost[$deviceHost] = $deviceRow;
            }

            $matchedDeviceAgents = array();
            $matchedDeviceHosts = array();
            $totalCards = count((array)$enrollments);

            /* Ajoute au compteur les PC déjà enrôlés qui n'ont plus d'entrée d'historique. */
            foreach ((array)$devices as $deviceRow) {
                if (!is_array($deviceRow)) continue;

                $deviceAgent = trim((string)($deviceRow['agent_id'] ?? ''));
                $deviceHost  = strtolower(trim((string)($deviceRow['hostname'] ?? '')));
                $hasEnrollment = false;

                foreach ((array)$enrollments as $enrollmentRow) {
                    if (!is_array($enrollmentRow)) continue;

                    $candidate = isset($enrollmentRow['candidate']) && is_array($enrollmentRow['candidate'])
                        ? $enrollmentRow['candidate']
                        : array();

                    $candidateAgent = trim((string)($candidate['agent_id'] ?? $enrollmentRow['agent_id'] ?? ''));
                    $candidateHost = strtolower(trim((string)($candidate['hostname'] ?? '')));

                    if (($deviceAgent !== '' && $candidateAgent === $deviceAgent)
                        || ($deviceHost !== '' && $candidateHost === $deviceHost)) {
                        $hasEnrollment = true;
                        break;
                    }
                }

                if (!$hasEnrollment) $totalCards++;
            }
            ?>

            <div class="dmd-enrollment-section-head dmd-enrollment-pc-head">
                <div>
                    <h3>PC / enrôlements</h3>
                    <p><?= $totalCards ?> élément<?= $totalCards > 1 ? 's' : '' ?> : PC enrôlés et enrôlements en cours.</p>
                </div>

                <div class="dmd-enrollment-search">
                    <span aria-hidden="true">⌕</span>
                    <input
                        type="search"
                        id="enrollmentPcSearch"
                        placeholder="Rechercher PC, alias, IP, groupe, statut, build..."
                        autocomplete="off"
                    >
                    <button type="button" id="enrollmentPcSearchClear" class="dmd-agent-mini-btn" title="Effacer">×</button>
                </div>
            </div>

            <?php if($totalCards < 1): ?>
                <div class="dmd-agent-empty compact">
                    <strong>Aucun PC ou enrôlement</strong>
                    <span>Crée un enrôlement à gauche pour ajouter le premier poste.</span>
                </div>
            <?php else: ?>
                <div class="dmd-enrolled-pc-grid" id="enrollmentPcGrid">

                    <?php foreach(array_reverse((array)$enrollments) as $e):
                        if (!is_array($e)) continue;

                        $id = trim((string)($e['enrollment_id'] ?? ''));
                        $status = trim((string)($e['status'] ?? 'created'));
                        $alias = trim((string)($e['target_name'] ?? ''));

                        $candidate = isset($e['candidate']) && is_array($e['candidate'])
                            ? $e['candidate']
                            : array();

                        $candidateAgent = trim((string)($candidate['agent_id'] ?? $e['agent_id'] ?? ''));
                        $candidateHost  = trim((string)($candidate['hostname'] ?? ''));
                        $candidateHostKey = strtolower($candidateHost);

                        $device = null;
                        if ($candidateAgent !== '' && isset($deviceByAgent[$candidateAgent])) {
                            $device = $deviceByAgent[$candidateAgent];
                        } elseif ($candidateHostKey !== '' && isset($deviceByHost[$candidateHostKey])) {
                            $device = $deviceByHost[$candidateHostKey];
                        }

                        $agentId = $device
                            ? trim((string)($device['agent_id'] ?? $candidateAgent))
                            : $candidateAgent;

                        $hostname = $device
                            ? trim((string)($device['hostname'] ?? $candidateHost))
                            : $candidateHost;

                        if ($hostname === '') $hostname = 'PC non présenté';

                        if ($agentId !== '') $matchedDeviceAgents[$agentId] = true;
                        if ($device && trim((string)($device['hostname'] ?? '')) !== '') {
                            $matchedDeviceHosts[strtolower(trim((string)$device['hostname']))] = true;
                        }

                        $ip = '';
                        if ($device) $ip = trim((string)($device['last_ip'] ?? ''));
                        if ($ip === '') {
                            $ip = trim((string)($candidate['first_ip'] ?? $candidate['ip'] ?? ''));
                        }

                        $groupNames = array();
                        if ($device && $agentId !== '') {
                            if (function_exists('dmd_agent_device_group_names')) {
                                $groupNames = dmd_agent_device_group_names($agentId, $pcGroupsData);
                            } else {
                                foreach ((array)($pcGroupsData['groups'] ?? array()) as $group) {
                                    if (!is_array($group)) continue;
                                    if (in_array($agentId, (array)($group['agent_ids'] ?? array()), true)) {
                                        $groupName = trim((string)($group['name'] ?? ''));
                                        if ($groupName !== '') $groupNames[] = $groupName;
                                    }
                                }
                                $groupNames = array_values(array_unique($groupNames));
                            }
                        }
                        if ($groupNames) {
                            $groupLabel = implode(', ', $groupNames);
                        } else {
                            $plannedGroupName = trim((string)($e['target_pc_group_name'] ?? ''));
                            $groupLabel = $plannedGroupName !== '' ? $plannedGroupName . ' (prévu)' : 'Sans groupe';
                        }

                        /* AGENT_BUILD UNIQUEMENT. */
                        $inventory = $device && isset($device['last_inventory']) && is_array($device['last_inventory'])
                            ? $device['last_inventory']
                            : array();

                        $inventoryAgent = isset($inventory['agent']) && is_array($inventory['agent'])
                            ? $inventory['agent']
                            : array();

                        $candidateInventory = isset($candidate['inventory']) && is_array($candidate['inventory'])
                            ? $candidate['inventory']
                            : array();

                        $candidateInventoryAgent = isset($candidateInventory['agent']) && is_array($candidateInventory['agent'])
                            ? $candidateInventory['agent']
                            : array();

                        $agentBuild = trim((string)(
                            ($device['AGENT_BUILD'] ?? null)
                            ?? ($device['agent_build'] ?? null)
                            ?? ($inventory['AGENT_BUILD'] ?? null)
                            ?? ($inventory['agent_build'] ?? null)
                            ?? ($inventoryAgent['AGENT_BUILD'] ?? null)
                            ?? ($inventoryAgent['agent_build'] ?? null)
                            ?? ($candidate['AGENT_BUILD'] ?? null)
                            ?? ($candidate['agent_build'] ?? null)
                            ?? ($candidateInventory['AGENT_BUILD'] ?? null)
                            ?? ($candidateInventory['agent_build'] ?? null)
                            ?? ($candidateInventoryAgent['AGENT_BUILD'] ?? null)
                            ?? ($candidateInventoryAgent['agent_build'] ?? null)
                            /* Dans les données DMD-Agent actuelles, le build canonique est stocké dans agent_version. */
                            ?? ($device['agent_version'] ?? null)
                            ?? ($candidate['agent_version'] ?? null)
                            ?? ''
                        ));

                        $statusLabel = function_exists('dmd_agent_status_label')
                            ? dmd_agent_status_label($status)
                            : ($status !== '' ? $status : 'Créé');

                        $isOnline = false;
                        if ($device) {
                            $lastTs = (int)($device['last_seen_ts'] ?? 0);
                            $isOnline = (($device['status'] ?? '') === 'active'
                                && $lastTs > 0
                                && (time() - $lastTs) < 90);
                        }

                        $isPending = in_array($status, array('created', 'challenge', 'pending_approval', 'approved'), true);
                        $needsApproval = ($status === 'pending_approval');

                        $searchText = strtolower(implode(' ', array(
                            $hostname,
                            $alias,
                            $ip,
                            $groupLabel,
                            $agentBuild,
                            $statusLabel,
                            $id
                        )));
                    ?>
                        <article
                            class="dmd-enrolled-pc-card dmd-enrollment-card <?= $isPending ? 'is-enrolling' : 'is-enrolled' ?> <?= $isOnline ? 'is-online' : 'is-offline' ?>"
                            data-enrollment-id="<?= dmd_agent_h($id) ?>"
                            data-enrollment-status="<?= dmd_agent_h($status) ?>"
                            data-enrollment-search="<?= dmd_agent_h($searchText) ?>"
                            <?php if($agentId !== ''): ?>
                                data-device-open="<?= dmd_agent_h($agentId) ?>"
                                tabindex="0"
                                role="button"
                                aria-label="Ouvrir la fiche de <?= dmd_agent_h($hostname) ?>"
                            <?php endif; ?>
                        >
                            <div class="dmd-enrolled-pc-card-top">
                                <span class="dmd-enrollment-kind <?= $isPending ? 'pending' : 'done' ?>">
                                    <?= $isPending ? 'EN COURS' : 'ENRÔLÉ' ?>
                                </span>
                                <span
                                    class="dmd-enrolled-pc-state"
                                    title="<?= dmd_agent_h($isOnline ? 'En ligne' : $statusLabel) ?>"
                                ></span>
                            </div>

                            <div
                                class="dmd-enrolled-pc-title"
                                <?php if($agentId !== ''): ?>
                                    data-device-open="<?= dmd_agent_h($agentId) ?>"
                                    tabindex="0"
                                    role="button"
                                <?php endif; ?>
                            >
                                <strong title="<?= dmd_agent_h($hostname) ?>"><?= dmd_agent_h($hostname) ?></strong>
                                <small title="<?= dmd_agent_h($alias !== '' ? $alias : 'Sans alias') ?>">
                                    <?= dmd_agent_h($alias !== '' ? $alias : 'Sans alias') ?>
                                </small>
                            </div>

                            <dl class="dmd-enrolled-pc-info">
                                <div>
                                    <dt>Groupe</dt>
                                    <dd title="<?= dmd_agent_h($groupLabel) ?>"><?= dmd_agent_h($groupLabel) ?></dd>
                                </div>
                                <div>
                                    <dt>IP</dt>
                                    <dd><?= dmd_agent_h($ip !== '' ? $ip : '—') ?></dd>
                                </div>
                                <div class="dmd-enrolled-pc-build">
                                    <dt>AGENT_BUILD</dt>
                                    <dd><?= dmd_agent_h($agentBuild !== '' ? $agentBuild : '—') ?></dd>
                                </div>
                                <div>
                                    <dt>Statut</dt>
                                    <dd class="<?= $needsApproval ? 'needs-approval' : '' ?>">
                                        <?= dmd_agent_h($statusLabel) ?>
                                    </dd>
                                </div>
                            </dl>

                            <div class="dmd-enrolled-pc-actions">
                                <?php if($needsApproval): ?>
                                    <button
                                        type="button"
                                        class="dmd-agent-mini-btn primary decision"
                                        data-id="<?= dmd_agent_h($id) ?>"
                                        data-decision="approve"
                                    >Autoriser</button>

                                    <button
                                        type="button"
                                        class="dmd-agent-mini-btn danger decision"
                                        data-id="<?= dmd_agent_h($id) ?>"
                                        data-decision="reject"
                                    >Refuser</button>
                                <?php endif; ?>

                                <?php if($status !== 'completed'): ?>
                                    <button
                                        type="button"
                                        class="dmd-agent-mini-btn renew-enrollment"
                                        data-id="<?= dmd_agent_h($id) ?>"
                                    >Relancer</button>
                                <?php endif; ?>

                                <button
                                    type="button"
                                    class="dmd-agent-mini-btn danger delete-enrollment"
                                    data-id="<?= dmd_agent_h($id) ?>"
                                    data-status="<?= dmd_agent_h($status) ?>"
                                >Supprimer</button>
                            </div>
                        </article>
                    <?php endforeach; ?>

                    <?php
                    /* PC actifs dont l'historique d'enrôlement a déjà été purgé. */
                    foreach ((array)$devices as $d):
                        if (!is_array($d)) continue;

                        $agentId = trim((string)($d['agent_id'] ?? ''));
                        $hostname = trim((string)($d['hostname'] ?? 'PC'));
                        $hostKey = strtolower($hostname);

                        if (($agentId !== '' && isset($matchedDeviceAgents[$agentId]))
                            || ($hostKey !== '' && isset($matchedDeviceHosts[$hostKey]))) {
                            continue;
                        }

                        $ip = trim((string)($d['last_ip'] ?? ''));
                        $alias = trim((string)($d['enrollment_name'] ?? ''));

                        $groupNames = array();
                        if ($agentId !== '') {
                            if (function_exists('dmd_agent_device_group_names')) {
                                $groupNames = dmd_agent_device_group_names($agentId, $pcGroupsData);
                            } else {
                                foreach ((array)($pcGroupsData['groups'] ?? array()) as $group) {
                                    if (!is_array($group)) continue;
                                    if (in_array($agentId, (array)($group['agent_ids'] ?? array()), true)) {
                                        $groupName = trim((string)($group['name'] ?? ''));
                                        if ($groupName !== '') $groupNames[] = $groupName;
                                    }
                                }
                                $groupNames = array_values(array_unique($groupNames));
                            }
                        }
                        $groupLabel = $groupNames ? implode(', ', $groupNames) : 'Sans groupe';

                        $inventory = isset($d['last_inventory']) && is_array($d['last_inventory'])
                            ? $d['last_inventory']
                            : array();

                        $inventoryAgent = isset($inventory['agent']) && is_array($inventory['agent'])
                            ? $inventory['agent']
                            : array();

                        $agentBuild = trim((string)(
                            ($d['AGENT_BUILD'] ?? null)
                            ?? ($d['agent_build'] ?? null)
                            ?? ($inventory['AGENT_BUILD'] ?? null)
                            ?? ($inventory['agent_build'] ?? null)
                            ?? ($inventoryAgent['AGENT_BUILD'] ?? null)
                            ?? ($inventoryAgent['agent_build'] ?? null)
                            /* Dans les données DMD-Agent actuelles, le build canonique est stocké dans agent_version. */
                            ?? ($d['agent_version'] ?? null)
                            ?? ''
                        ));

                        $lastTs = (int)($d['last_seen_ts'] ?? 0);
                        $isOnline = (($d['status'] ?? '') === 'active'
                            && $lastTs > 0
                            && (time() - $lastTs) < 90);

                        $searchText = strtolower(implode(' ', array(
                            $hostname,
                            $alias,
                            $ip,
                            $groupLabel,
                            $agentBuild,
                            'enrôlé terminé'
                        )));
                    ?>
                        <article
                            class="dmd-enrolled-pc-card dmd-enrollment-card is-enrolled <?= $isOnline ? 'is-online' : 'is-offline' ?>"
                            data-enrollment-search="<?= dmd_agent_h($searchText) ?>"
                            <?php if($agentId !== ''): ?>
                                data-device-open="<?= dmd_agent_h($agentId) ?>"
                                tabindex="0"
                                role="button"
                                aria-label="Ouvrir la fiche de <?= dmd_agent_h($hostname) ?>"
                            <?php endif; ?>
                        >
                            <div class="dmd-enrolled-pc-card-top">
                                <span class="dmd-enrollment-kind done">ENRÔLÉ</span>
                                <span class="dmd-enrolled-pc-state" title="<?= $isOnline ? 'En ligne' : 'Hors ligne' ?>"></span>
                            </div>

                            <div
                                class="dmd-enrolled-pc-title"
                                <?php if($agentId !== ''): ?>
                                    data-device-open="<?= dmd_agent_h($agentId) ?>"
                                    tabindex="0"
                                    role="button"
                                <?php endif; ?>
                            >
                                <strong><?= dmd_agent_h($hostname) ?></strong>
                                <small><?= dmd_agent_h($alias !== '' ? $alias : 'Sans alias') ?></small>
                            </div>

                            <dl class="dmd-enrolled-pc-info">
                                <div><dt>Groupe</dt><dd><?= dmd_agent_h($groupLabel) ?></dd></div>
                                <div><dt>IP</dt><dd><?= dmd_agent_h($ip !== '' ? $ip : '—') ?></dd></div>
                                <div><dt>AGENT_BUILD</dt><dd><?= dmd_agent_h($agentBuild !== '' ? $agentBuild : '—') ?></dd></div>
                                <div><dt>Statut</dt><dd>Terminé</dd></div>
                            </dl>
                        </article>
                    <?php endforeach; ?>

                </div>

                <div class="dmd-enrollment-search-empty" id="enrollmentPcSearchEmpty" hidden>
                    Aucun PC ou enrôlement ne correspond à la recherche.
                </div>
            <?php endif; ?>
        </section>
    </div>
</section>

<div class="dmd-agent-repo-modal" data-dmd-repo-modal hidden aria-hidden="true">
    <section class="dmd-agent-repo-dialog" role="dialog" aria-modal="true" aria-labelledby="dmdAgentRepoDialogTitle">
        <header class="dmd-agent-repo-dialog-head">
            <div><h3 id="dmdAgentRepoDialogTitle">Version de DMD-Installer</h3><p>Choisis le ZIP Agent à préparer pour les prochains enrôlements.</p></div>
            <button type="button" class="dmd-agent-icon-btn" data-close-agent-repository aria-label="Fermer">×</button>
        </header>
        <div class="dmd-agent-repo-card compact" data-dmd-repo-root>
            <div class="dmd-agent-repo-state" data-repo-state>
                <strong>Installateur actif</strong><span>Lecture de l'état local…</span>
            </div>
            <div class="dmd-agent-repo-picker">
                <label><span>Version disponible</span><select data-repo-version disabled><option>Cliquer sur Actualiser</option></select></label>
                <button type="button" class="dmd-agent-mini-btn" data-repo-scan>Actualiser</button>
                <button type="button" class="dmd-agent-btn primary" data-repo-install disabled>Télécharger et préparer</button>
            </div>
            <small class="dmd-agent-repo-selection" data-repo-selection-info></small>
            <div class="dmd-agent-repo-progress">
                <div class="dmd-agent-repo-progress-head"><strong data-repo-progress-text>Prêt.</strong><span data-repo-progress-value>0%</span></div>
                <div class="dmd-agent-repo-progress-track"><i data-repo-progress-fill style="width:0%"></i></div>
                <div class="dmd-agent-repo-steps">
                    <span data-repo-step="scan">Analyse</span><span data-repo-step="download">Téléchargement</span><span data-repo-step="verify">Vérification</span><span data-repo-step="extract">Extraction</span><span data-repo-step="prepare">Préparation</span><span data-repo-step="done">Activé</span>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="assets/agent-repository.js?v=20260912-1" defer></script>

<script>
(function(){
    const form = document.getElementById('enrollmentInlineCreateForm');
    if(!form) return;

    let lastBootstrap = null;
    let lastInstallLink = '';

    const serverRows = document.getElementById('enrollmentServerRows');
    const serverChoices = document.getElementById('enrollmentServerUrlChoices');
    const addServerUrlBtn = document.getElementById('enrollmentAddServerUrl');
    const addCurrentUrlBtn = document.getElementById('enrollmentAddCurrentUrl');
    const helpBtn = document.getElementById('enrollmentServerHelp');
    const helpPopup = document.getElementById('enrollmentServerHelpPopup');
    const helpClose = document.getElementById('enrollmentServerHelpClose');
    const URL_STORAGE_KEY = 'dmd-agent-enrollment-server-urls';

    function normalizedServerUrl(value){
        return String(value || '').trim().replace(/\/+$/, '');
    }

    function currentDoMyDeskUrl(){
        // Le serveur résout lui-même /domydesk (ou un autre point de montage).
        // Le formulaire reste volontairement limité à l'adresse/hôte visible.
        return normalizedServerUrl(window.location.origin);
    }

    function escapeAttr(value){
        return String(value || '')
            .replaceAll('&','&amp;')
            .replaceAll('"','&quot;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;');
    }

    function loadSavedServerUrls(){
        let saved = [];
        try{
            const raw = JSON.parse(localStorage.getItem(URL_STORAGE_KEY) || '[]');
            if(Array.isArray(raw)) saved = raw.map(normalizedServerUrl).filter(Boolean);
        }catch(_){}

        const current = currentDoMyDeskUrl();
        const urls = [...new Set([current, ...saved].filter(Boolean))].slice(0, 20);

        if(serverChoices){
            serverChoices.innerHTML = '';
            urls.forEach(url => {
                const opt = document.createElement('option');
                opt.value = url;
                serverChoices.appendChild(opt);
            });
        }
    }

    function rememberServerUrls(values){
        let saved = [];
        try{
            const raw = JSON.parse(localStorage.getItem(URL_STORAGE_KEY) || '[]');
            if(Array.isArray(raw)) saved = raw.map(normalizedServerUrl).filter(Boolean);
        }catch(_){}

        const merged = [...new Set([
            ...values.map(normalizedServerUrl).filter(Boolean),
            ...saved
        ])].slice(0, 20);

        try{ localStorage.setItem(URL_STORAGE_KEY, JSON.stringify(merged)); }catch(_){}
        loadSavedServerUrls();
    }

    function addServerRow(value = ''){
        if(!serverRows) return;
        if(serverRows.querySelectorAll('.dmd-enrollment-server-row').length >= 8){
            showMsg('Maximum 8 adresses par enrôlement.', false);
            return;
        }

        const row = document.createElement('div');
        row.className = 'dmd-enrollment-server-row';
        row.innerHTML = `
            <input
                type="url"
                class="dmd-enrollment-server-input"
                list="enrollmentServerUrlChoices"
                placeholder="http://192.168.1.50"
                autocomplete="off"
                value="${escapeAttr(normalizedServerUrl(value))}"
            >
            <button type="button" class="dmd-agent-mini-btn danger dmd-enrollment-server-remove" title="Supprimer cette adresse">×</button>
        `;

        row.querySelector('.dmd-enrollment-server-remove')?.addEventListener('click', () => {
            const rows = serverRows.querySelectorAll('.dmd-enrollment-server-row');
            if(rows.length <= 1){
                row.querySelector('input').value = '';
                row.querySelector('input').focus();
                return;
            }
            row.remove();
        });

        serverRows.appendChild(row);
    }

    function getServerUrls(){
        return [...(serverRows?.querySelectorAll('.dmd-enrollment-server-input') || [])]
            .map(input => normalizedServerUrl(input.value))
            .filter(Boolean)
            .filter((value, index, array) => array.indexOf(value) === index);
    }

    function openServerHelp(){
        if(!helpPopup) return;
        helpPopup.hidden = false;
        helpPopup.setAttribute('aria-hidden','false');
    }

    function closeServerHelp(){
        if(!helpPopup) return;
        helpPopup.hidden = true;
        helpPopup.setAttribute('aria-hidden','true');
    }

    loadSavedServerUrls();
    addServerRow(currentDoMyDeskUrl());

    addServerUrlBtn?.addEventListener('click', () => {
        addServerRow('');
        const inputs = serverRows?.querySelectorAll('.dmd-enrollment-server-input');
        inputs?.[inputs.length - 1]?.focus();
    });

    addCurrentUrlBtn?.addEventListener('click', () => {
        const current = currentDoMyDeskUrl();
        if(current && !getServerUrls().includes(current)) addServerRow(current);
    });

    helpBtn?.addEventListener('click', openServerHelp);
    helpClose?.addEventListener('click', closeServerHelp);
    helpPopup?.addEventListener('click', e => {
        if(e.target === helpPopup) closeServerHelp();
    });

    form.addEventListener('submit', async function(e){
        e.preventDefault();

        const submit = form.querySelector('button[type="submit"]');
        const fd = new FormData(form);
        const urls = getServerUrls();

        if(!urls.length){
            showMsg('Ajoute au moins une adresse DoMyDesk.', false);
            return;
        }
        if(urls.some(url => !/^https?:\/\//i.test(url))){
            showMsg('Chaque adresse doit commencer par http:// ou https://', false);
            return;
        }

        rememberServerUrls(urls);

        submit.disabled = true;
        const oldText = submit.textContent;
        submit.textContent = 'Création…';

        try{
            const res = await post('api/admin_create_enrollment.php', {
                target_name: fd.get('target_name'),
                expires_minutes: Number(fd.get('expires_minutes')),
                approval_mode: fd.get('approval_mode'),
                include_remote: fd.get('include_remote') === '1',
                include_mydesk: fd.get('include_mydesk') === '1',
                pc_group_id: String(fd.get('pc_group_id') || '').trim(),
                server_urls: urls
            });

            if(!res.ok){
                showMsg('Création refusée : ' + (res.error || res.code || 'erreur'), false);
                return;
            }

            lastBootstrap = res.bootstrap || null;
            lastInstallLink = String(res.install_link?.url || '').trim();

            const area = document.getElementById('enrollmentInlineBootstrap');
            const result = document.getElementById('enrollmentInlineResult');
            const text = document.getElementById('enrollmentInlineResultText');
            const linkInput = document.getElementById('enrollmentInlineInstallLink');

            if(area) area.value = JSON.stringify(lastBootstrap, null, 2);
            if(linkInput) linkInput.value = lastInstallLink;

            if(text){
                if(lastInstallLink && res.install_link?.expires_at){
                    text.textContent = 'Lien temporaire valable jusqu’au ' + String(res.install_link.expires_at);
                }else if(lastInstallLink){
                    text.textContent = 'Lien temporaire prêt : il télécharge directement DMD-Installer.exe.';
                }else{
                    text.textContent = 'Enrôlement créé, mais le lien temporaire n’a pas pu être généré.';
                }
            }

            if(result) result.hidden = false;

            showMsg(
                lastInstallLink
                    ? 'Enrôlement créé. Le lien temporaire d’installation est prêt.'
                    : 'Enrôlement créé, mais le lien temporaire est indisponible.',
                !!lastInstallLink
            );
        } finally {
            submit.disabled = false;
            submit.textContent = oldText;
        }
    });

    document.getElementById('enrollmentInlineDownloadInstaller')?.addEventListener('click', function(){
        if(!lastInstallLink){
            lastInstallLink = String(document.getElementById('enrollmentInlineInstallLink')?.value || '').trim();
        }

        if(!lastInstallLink){
            showMsg('Crée d’abord un enrôlement avec un lien temporaire valide.', false);
            return;
        }

        window.location.href = lastInstallLink;
    });

    document.getElementById('enrollmentInlineCopyInstallLink')?.addEventListener('click', async function(){
        const link = String(
            lastInstallLink || document.getElementById('enrollmentInlineInstallLink')?.value || ''
        ).trim();

        if(!link){
            showMsg('Aucun lien temporaire à copier.', false);
            return;
        }

        try{
            await navigator.clipboard.writeText(link);
            showMsg('Lien temporaire d’installation copié.');
        }catch(_){
            const input = document.getElementById('enrollmentInlineInstallLink');
            input?.focus();
            input?.select();
            showMsg('Copie automatique impossible : le lien est sélectionné.', false);
        }
    });

    document.getElementById('enrollmentInlineCopyBootstrap')?.addEventListener('click', async function(){
        const raw = document.getElementById('enrollmentInlineBootstrap')?.value || '';
        if(!raw){
            showMsg('Aucun bootstrap à copier.', false);
            return;
        }

        try{
            await navigator.clipboard.writeText(raw);
            showMsg('Bootstrap copié.');
        }catch(_){
            showMsg('Copie impossible.', false);
        }
    });
})();
</script>
