<div id="maintenanceAgentUpdateLogsPdfModal" class="dmd-agent-submodal dmd-update-log-pdf-preview" hidden>
    <div class="dmd-agent-submodal-dialog dmd-update-log-pdf-dialog" role="dialog" aria-modal="true" aria-labelledby="maintenanceAgentUpdateLogsPdfTitle">
        <div class="dmd-agent-submodal-head">
            <div><h3 id="maintenanceAgentUpdateLogsPdfTitle">Export PDF - Journal des mises à jour Agent</h3><p>Aperçu du journal filtré, sans quitter DMD-Agent.</p></div>
            <div class="dmd-maint-actions"><button type="button" class="dmd-agent-mini-btn primary" id="maintUpdateLogsPdfDownload" disabled>Télécharger</button><button type="button" class="dmd-agent-mini-btn" id="maintUpdateLogsPdfClose">Fermer</button></div>
        </div>
        <iframe id="maintUpdateLogsPdfFrame" class="dmd-update-log-pdf-frame" title="Aperçu PDF du journal des mises à jour Agent"></iframe>
    </div>
</div>

