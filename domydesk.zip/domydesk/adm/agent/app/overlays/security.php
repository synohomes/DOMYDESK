    <section id="panel-security" class="dmd-agent-drawer" hidden>
        <div class="dmd-agent-drawer-head">
            <div><h2>Sécurité de l’instance</h2><p>État de la chaîne de confiance utilisée par DMD-Agent.</p></div>
            <button type="button" class="dmd-agent-icon-btn" data-close-panel aria-label="Fermer">×</button>
        </div>
        <div class="dmd-agent-security-grid">
            <div class="dmd-agent-security-card">
                <h3>Identité DoMyDesk</h3>
                <?php if (!empty($identity['ok'])): $m=$identity['manifest']; ?>
                    <div class="dmd-agent-kv"><strong>État</strong><span class="dmd-agent-ok">● Identité valide</span><strong>ID scellé</strong><span class="dmd-agent-code"><?= dmd_agent_h($m['instance_id']) ?></span><strong>Algorithme</strong><span><?= dmd_agent_h($m['identity_algorithm']) ?></span><strong>Empreinte</strong><span class="dmd-agent-code"><?= dmd_agent_h($m['public_key_fingerprint']) ?></span><strong>Créée</strong><span class="dmd-agent-date" data-date="<?= dmd_agent_h($m['created_at']) ?>"><?= dmd_agent_h($m['created_at']) ?></span></div>
                <?php else: ?><p class="dmd-agent-bad"><strong>● BLOQUÉ</strong></p><p><?= dmd_agent_h(isset($identity['message'])?$identity['message']:(isset($identity['state'])?$identity['state']:'Erreur identité')) ?></p><?php endif; ?>
            </div>
            <div class="dmd-agent-security-card">
                <h3>Protections</h3>
                <div class="dmd-agent-kv"><strong>Sodium / Ed25519</strong><span class="<?= dmd_agent_crypto_available()?'dmd-agent-ok':'dmd-agent-bad' ?>"><?= dmd_agent_crypto_available()?'Disponible':'Indisponible' ?></span><strong>Secrets</strong><span>Stockage local protégé</span><strong>HTTP direct</strong><span>Bloqué</span><strong>Jetons serveur</strong><span>Empreintes cryptographiques uniquement</span><strong>Anti-bruteforce</strong><span>5 échecs / 10 min → 30 min</span></div>
                <div class="dmd-agent-actions"><button id="selfTest" class="dmd-agent-btn primary" type="button" <?= empty($identity['ok'])?'disabled':'' ?>>Lancer l’autotest</button><a class="dmd-agent-btn" href="api/ping.php" target="_blank" rel="noopener">Ping signé</a></div>
            </div>
        </div>
    </section>
</main>
