<section id="terminalModal" class="dmd-agent-terminal-page" hidden>
    <div class="dmd-agent-terminal-popup-card" aria-labelledby="terminalModalTitle">
        <header class="dmd-agent-terminal-popup-head">
            <div>
                <h2 id="terminalModalTitle">Terminal distant</h2>
                <p id="terminalModalSub">—</p>
            </div>
            <div class="dmd-agent-terminal-popup-head-actions">
                <span id="terminalCommandState" class="dmd-agent-data-state">Prêt</span>
                <button type="button" class="dmd-agent-icon-btn" data-close-terminal aria-label="Retour au poste">←</button>
            </div>
        </header>

        <div class="dmd-agent-terminal-popup-body">
            <div class="dmd-agent-terminal-commandbar">
                <select id="deviceTerminalShell" aria-label="Interpréteur">
                    <option value="powershell">PowerShell</option>
                    <option value="cmd">CMD</option>
                </select>
                <input id="deviceTerminalInput" type="text" placeholder="Commande à exécuter" autocomplete="off">
                <button type="button" class="dmd-agent-btn primary" id="deviceTerminalRun">Exécuter</button>
            </div>
            <pre id="deviceTerminalOutput" class="dmd-agent-terminal-popup-output">DMD-Agent — terminal distant
Exécution avec les droits du service Windows SYSTEM.
</pre>
        </div>

        <footer class="dmd-agent-terminal-popup-foot">
            <button type="button" class="dmd-agent-btn" id="deviceTerminalClear">Effacer l’écran</button>
            <button type="button" class="dmd-agent-btn" data-close-terminal>Retour au poste</button>
        </footer>
    </div>
</section>

