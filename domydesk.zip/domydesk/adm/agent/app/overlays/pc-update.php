<div id="maintenancePcUpdateModal" class="dmd-agent-modal dmd-maint-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-maint-close></div>

    <section class="dmd-agent-modal-card dmd-maint-card dmd-system-update-card" role="dialog" aria-modal="true" aria-labelledby="maintenancePcUpdateTitle">
        <header class="dmd-maint-head dmd-system-update-head">
            <div>
                <h2 id="maintenancePcUpdateTitle">Mise à jour système</h2>
                <p>Recherche les mises à jour Windows, puis ouvre un poste pour sélectionner précisément ce qui doit être installé.</p>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-maint-close aria-label="Fermer">×</button>
        </header>

        <div class="dmd-maint-body dmd-system-update-body">
            <section class="dmd-maint-panel dmd-system-update-toolbar">
                <div class="dmd-system-update-toolbar-left">
                    <button type="button" class="dmd-agent-btn primary" id="maintPcUpdateScan">Rechercher les mises à jour</button>
                    <span id="maintPcUpdateState" class="dmd-maint-state-pill">Prêt</span>
                </div>

                <div class="dmd-system-update-filters">
                    <button type="button" class="dmd-agent-mini-btn active" data-pcupdate-filter="all">Tous les PC</button>
                    <?php foreach((array)($pcGroupsData['groups']??array()) as $g):
                        if(!is_array($g))continue;
                        $gid=trim((string)($g['group_id']??''));
                        $gn=trim((string)($g['name']??''));
                        if($gid===''||$gn==='')continue;
                    ?>
                        <button type="button" class="dmd-agent-mini-btn" data-pcupdate-filter="<?= dmd_agent_h($gid) ?>"><?= dmd_agent_h($gn) ?></button>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="dmd-maint-panel dmd-system-update-pcs">
                <div class="dmd-maint-panel-head">
                    <div>
                        <h3>Postes</h3>
                        <p>Une vignette = un PC. Le badge indique le nombre de mises à jour trouvées.</p>
                    </div>
                    <span id="maintPcUpdateSummary" class="dmd-system-update-summary">Aucune recherche effectuée</span>
                </div>

                <div id="maintPcUpdatePcGrid" class="dmd-system-update-pc-grid">
                    <?php foreach($devices as $d):
                        $aid=(string)($d['agent_id']??'');
                        $hn=(string)($d['hostname']??'PC');
                        $dst=(string)($d['status']??'');
                        $last=(int)($d['last_seen_ts']??0);
                        $isOnline=($dst==='active' && $last>0 && ($now-$last)<90);

                        $gids=array();
                        $gnames=array();
                        foreach((array)($pcGroupsData['groups']??array()) as $pg){
                            if(!is_array($pg))continue;
                            if(in_array($aid,(array)($pg['agent_ids']??array()),true)){
                                $gid=trim((string)($pg['group_id']??''));
                                $gn=trim((string)($pg['name']??''));
                                if($gid!=='')$gids[]=$gid;
                                if($gn!=='')$gnames[]=$gn;
                            }
                        }
                        $gids=array_values(array_filter(array_unique($gids)));
                        $gnames=array_values(array_filter(array_unique($gnames)));
                        $groupLabel=$gnames?implode(', ',$gnames):'Sans groupe';
                    ?>
                        <button
                            type="button"
                            class="dmd-system-update-pc <?= $isOnline?'is-online':'is-offline' ?>"
                            data-pcupdate-agent="<?= dmd_agent_h($aid) ?>"
                            data-pcupdate-groups="<?= dmd_agent_h(implode(' ',$gids)) ?>"
                            <?= $isOnline?'':'disabled' ?>
                        >
                            <span class="dmd-system-update-pc-main">
                                <strong><?= dmd_agent_h($hn) ?></strong>
                                <small><?= dmd_agent_h($groupLabel) ?></small>
                            </span>
                            <span class="dmd-system-update-pc-count" data-pcupdate-count>—</span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </section>

            <div id="maintPcUpdateProgress" class="dmd-maint-bulk-progress dmd-system-update-progress" hidden>
                <div>
                    <strong id="maintPcUpdateProgressLabel">Préparation…</strong>
                    <span id="maintPcUpdateProgressText">0 / 0</span>
                </div>
                <div class="dmd-maint-update-progressbar large"><i id="maintPcUpdateProgressBar" style="width:0%"></i></div>
            </div>
        </div>

        <footer class="dmd-maint-foot dmd-system-update-foot">
            <span>Clique sur un poste après la recherche pour voir et sélectionner ses mises à jour.</span>
            <button type="button" class="dmd-agent-btn" data-maint-close>Fermer</button>
        </footer>
    </section>
</div>

<div id="maintenancePcUpdateDetailsModal" class="dmd-agent-modal dmd-system-update-details-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-pcupdate-details-close></div>

    <section class="dmd-agent-modal-card dmd-system-update-details-card" role="dialog" aria-modal="true" aria-labelledby="maintPcUpdateDetailsTitle">
        <header class="dmd-maint-head">
            <div>
                <h2 id="maintPcUpdateDetailsTitle">Mises à jour du PC</h2>
                <p id="maintPcUpdateDetailsSub">—</p>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-pcupdate-details-close aria-label="Fermer">×</button>
        </header>

        <div class="dmd-system-update-details-body">
            <div class="dmd-system-update-details-tools">
                <label class="dmd-system-update-select-all">
                    <input type="checkbox" id="maintPcUpdateSelectAllUpdates">
                    <span>Tout sélectionner</span>
                </label>

                <label class="dmd-system-update-target">
                    <span>Installer sur</span>
                    <select id="maintPcUpdateInstallTarget">
                        <option value="pc">Ce PC uniquement</option>
                    </select>
                </label>
            </div>

            <div id="maintPcUpdateDetailsList" class="dmd-system-update-list"></div>

            <div id="maintPcUpdateInstallProgress" class="dmd-system-update-install-progress" hidden>
                <strong>Installation en cours…</strong>
                <span id="maintPcUpdateInstallProgressText">Préparation</span>
            </div>
        </div>

        <footer class="dmd-maint-foot">
            <span id="maintPcUpdateDetailsCount">0 mise à jour sélectionnée</span>
            <div class="dmd-system-update-details-actions">
                <button type="button" class="dmd-agent-btn" data-pcupdate-details-close>Annuler</button>
                <button type="button" class="dmd-agent-btn primary" id="maintPcUpdateInstallSelected" disabled>Installer la sélection</button>
            </div>
        </footer>
    </section>
</div>
