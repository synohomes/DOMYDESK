<section id="softwareModal" class="dmd-agent-software-page" hidden>
    <div class="dmd-agent-software-popup-card" aria-labelledby="softwareModalTitle">
        <header class="dmd-agent-software-popup-head">
            <div>
                <h2 id="softwareModalTitle">Logiciels</h2>
                <p id="softwareModalSub">—</p>
            </div>
            <div class="dmd-agent-software-popup-head-actions">
                <span id="softwareCommandState" class="dmd-agent-data-state">Prêt</span>
                <button type="button" class="dmd-agent-icon-btn" data-close-software aria-label="Retour au poste">←</button>
            </div>
        </header>

        <div class="dmd-agent-software-popup-body">
            <section class="dmd-agent-software-install-card">
                <div class="dmd-agent-software-section-head">
                    <div><h3>Installer un logiciel</h3><p>Package MSI ou EXE envoyé temporairement par DoMyDesk puis téléchargé et vérifié en SHA-256 par l’Agent.</p></div>
                </div>
                <div class="dmd-agent-software-install-row">
                    <input id="softwarePackageFile" type="file" accept=".msi,.exe,application/x-msi,application/vnd.microsoft.portable-executable">
                    <input id="softwareInstallArguments" type="text" maxlength="4096" placeholder="Arguments silencieux EXE (optionnel — automatique si vide)">
                    <button type="button" class="dmd-agent-btn primary" id="softwareInstallButton">Installer</button>
                </div>
                <small class="dmd-agent-software-help">MSI : /qn /norestart automatique. EXE : laisse le champ vide pour la détection automatique, ou indique tes propres arguments silencieux.</small>
            </section>

            <section class="dmd-agent-software-install-card dmd-agent-winget-search-card">
                <div class="dmd-agent-software-section-head">
                    <div>
                        <h3>Rechercher dans Winget</h3>
                        <p>Saisis un nom courant : Chrome, Firefox, VLC, 7-Zip, Notepad++, Teams… DoMyDesk recherche les vrais paquets disponibles.</p>
                    </div>
                </div>
                <div class="dmd-agent-winget-searchbar">
                    <input id="softwareWingetId" type="search" maxlength="180" placeholder="Nom du logiciel à rechercher…">
                    <button type="button" class="dmd-agent-btn primary" id="softwareWingetSearch">Rechercher dans Winget</button>
                </div>
                <div id="softwareWingetResults" class="dmd-agent-winget-results">
                    <div class="dmd-agent-data-empty">Aucune recherche effectuée.</div>
                </div>
            </section>

            <section class="dmd-agent-software-install-card">
                <div class="dmd-agent-software-section-head">
                    <div><h3>Mises à jour logiciels</h3><p>Recherche et installation silencieuse via Winget sur le poste distant.</p></div>
                    <div class="dmd-agent-software-popup-head-actions">
                        <button type="button" class="dmd-agent-btn" id="softwareUpdatesScan">Rechercher</button>
                        <button type="button" class="dmd-agent-btn primary" id="softwareUpdatesApply">Tout mettre à jour</button>
                    </div>
                </div>
                <pre id="softwareUpdatesOutput" class="dmd-agent-terminal-output" style="max-height:180px;overflow:auto;margin-top:7px">Aucune recherche effectuée.</pre>
            </section>

            <section class="dmd-agent-software-list-card">
                <div class="dmd-agent-software-toolbar">
                    <div>
                        <h3>Logiciels installés</h3>
                        <span id="softwareListCount">0 logiciel</span>
                    </div>
                    <div class="dmd-agent-software-search">
                        <input id="softwareSearch" type="search" placeholder="Rechercher nom, version, éditeur…" autocomplete="off">
                        <button type="button" class="dmd-agent-btn" id="softwareRefresh">Actualiser</button>
                    </div>
                </div>
                <div id="softwareList" class="dmd-agent-software-list">
                    <div class="dmd-agent-data-empty">Chargement…</div>
                </div>
                <div id="softwarePager" class="dmd-agent-software-pager"></div>
            </section>
        </div>

        <footer class="dmd-agent-software-popup-foot">
            <span>DoMyDesk protège DMD-Agent contre sa propre désinstallation distante.</span>
            <button type="button" class="dmd-agent-btn" data-close-software>Retour au poste</button>
        </footer>
    </div>
</section>


