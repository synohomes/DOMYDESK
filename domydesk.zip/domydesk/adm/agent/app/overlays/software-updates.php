<div id="maintenanceSoftwareUpdatesModal" class="dmd-agent-modal dmd-maint-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-maint-close></div>

    <section class="dmd-agent-modal-card dmd-maint-card dmd-software-update-card" role="dialog" aria-modal="true" aria-labelledby="maintenanceSoftwareUpdatesTitle">
        <header class="dmd-maint-head dmd-software-update-head">
            <div>
                <h2 id="maintenanceSoftwareUpdatesTitle">Mise à jour logiciels</h2>
                <p>Sélectionne les PC, lance la recherche, puis consulte le résultat dans la fenêtre de sélection.</p>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-maint-close aria-label="Fermer">×</button>
        </header>

        <div class="dmd-maint-body dmd-software-update-body">
            <section class="dmd-maint-panel dmd-software-update-targets">
                <div class="dmd-maint-panel-head">
                    <div>
                        <h3>PC cibles</h3>
                        <p>Sélectionne un ou plusieurs PC avant de lancer la recherche.</p>
                    </div>
                    <div class="dmd-software-update-target-head">
                        <strong id="maintSoftwareUpdatesSelectedCount">0 PC sélectionné</strong>
                        <label class="dmd-software-update-all">
                            <input type="checkbox" id="maintSoftwareUpdatesAllPc">
                            <span>Tous</span>
                        </label>
                    </div>
                </div>

                <div class="dmd-software-update-group-buttons">
                    <span>Groupes</span>
                    <?php foreach((array)($pcGroupsData['groups']??array()) as $g):
                        if(!is_array($g))continue;
                        $gid=trim((string)($g['group_id']??''));
                        $gn=trim((string)($g['name']??''));
                        if($gid===''||$gn==='')continue;
                    ?>
                        <button type="button" class="dmd-agent-mini-btn" data-swupdate-select-group="<?= dmd_agent_h($gid) ?>"><?= dmd_agent_h($gn) ?></button>
                    <?php endforeach; ?>
                    <button type="button" class="dmd-agent-mini-btn" data-swupdate-clear>Effacer</button>
                </div>

                <div id="maintSoftwareUpdatesPcGrid" class="dmd-software-update-pc-grid">
                    <?php foreach($devices as $d):
                        $aid=(string)($d['agent_id']??'');
                        $hn=(string)($d['hostname']??'PC');
                        $dip=(string)($d['last_ip']??'IP inconnue');
                        $dst=(string)($d['status']??'');
                        $last=(int)($d['last_seen_ts']??0);
                        $isOnline=($dst==='active' && $last>0 && ($now-$last)<90);

                        $gids=array();
                        $gnames=array();
                        foreach((array)($pcGroupsData['groups']??array()) as $pg){
                            if(!is_array($pg))continue;
                            if(in_array($aid,(array)($pg['agent_ids']??array()),true)){
                                $gid=trim((string)($pg['group_id']??''));
                                $gn=trim((string)($pg['name']??''));
                                if($gid!=='')$gids[]=$gid;
                                if($gn!=='')$gnames[]=$gn;
                            }
                        }
                        $gids=array_values(array_filter(array_unique($gids)));
                        $gnames=array_values(array_filter(array_unique($gnames)));
                        $groupLabel=$gnames?implode(', ',$gnames):'Sans groupe';
                    ?>
                        <label
                            class="dmd-software-update-pc <?= $isOnline?'is-online':'is-offline' ?>"
                            data-swupdate-agent="<?= dmd_agent_h($aid) ?>"
                            data-swupdate-groups="<?= dmd_agent_h(implode(' ',$gids)) ?>"
                        >
                            <input
                                type="checkbox"
                                class="dmd-software-update-pc-check"
                                value="<?= dmd_agent_h($aid) ?>"
                                <?= $isOnline?'':'disabled' ?>
                            >
                            <span class="dmd-software-update-pc-main">
                                <strong><?= dmd_agent_h($hn) ?></strong>
                                <small class="dmd-software-update-pc-group"><?= dmd_agent_h($groupLabel) ?></small>
                                <small class="dmd-software-update-pc-ip"><?= dmd_agent_h($dip) ?></small>
                            </span>
                            <i class="dmd-software-update-online-dot"></i>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="dmd-software-update-launch">
                    <button type="button" class="dmd-agent-btn primary" id="maintSoftwareUpdatesScan" disabled>Rechercher les mises à jour</button>
                    <span id="maintSoftwareUpdatesState" class="dmd-maint-state-pill">Sélectionne au moins un PC</span>
                </div>
            </section>

            <div id="maintSoftwareUpdatesProgress" class="dmd-maint-bulk-progress dmd-software-update-progress" hidden>
                <div>
                    <strong id="maintSoftwareUpdatesProgressLabel">Préparation…</strong>
                    <span id="maintSoftwareUpdatesProgressText">0 / 0</span>
                </div>
                <div class="dmd-maint-update-progressbar large"><i id="maintSoftwareUpdatesProgressBar" style="width:0%"></i></div>
            </div>
        </div>

        <footer class="dmd-maint-foot">
            <span>La recherche est exécutée uniquement sur les PC sélectionnés.</span>
            <button type="button" class="dmd-agent-btn" data-maint-close>Fermer</button>
        </footer>
    </section>
</div>

<div id="maintenanceSoftwareUpdatesDetailsModal" class="dmd-agent-modal dmd-software-update-details-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-swupdate-details-close></div>

    <section class="dmd-agent-modal-card dmd-software-update-details-card" role="dialog" aria-modal="true" aria-labelledby="maintSoftwareUpdatesDetailsTitle">
        <header class="dmd-maint-head">
            <div>
                <h2 id="maintSoftwareUpdatesDetailsTitle">Résultat de la recherche</h2>
                <p id="maintSoftwareUpdatesDetailsSub">Sélectionne un PC puis les mises à jour à installer.</p>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-swupdate-details-close aria-label="Fermer">×</button>
        </header>

        <div class="dmd-software-update-details-body">
            <div id="maintSoftwareUpdatesResultTabs" class="dmd-software-update-result-tabs"></div>

            <div class="dmd-software-update-details-tools">
                <label class="dmd-software-update-select-all">
                    <input type="checkbox" id="maintSoftwareUpdatesSelectAll">
                    <span>Tout sélectionner</span>
                </label>

                <label class="dmd-software-update-target">
                    <span>Installer sur</span>
                    <select id="maintSoftwareUpdatesInstallTarget">
                        <option value="pc">Ce PC uniquement</option>
                    </select>
                </label>
            </div>

            <div id="maintSoftwareUpdatesDetailsList" class="dmd-software-update-list"></div>

            <div id="maintSoftwareUpdatesInstallProgress" class="dmd-software-update-install-progress" hidden>
                <strong>Installation en cours</strong>
                <span id="maintSoftwareUpdatesInstallProgressText">Préparation…</span>
            </div>
        </div>

        <footer class="dmd-maint-foot">
            <span id="maintSoftwareUpdatesDetailsCount">0 mise à jour sélectionnée</span>
            <div class="dmd-software-update-details-actions">
                <button type="button" class="dmd-agent-btn" data-swupdate-details-close>Fermer</button>
                <button type="button" class="dmd-agent-btn primary" id="maintSoftwareUpdatesInstallSelected" disabled>Installer la sélection</button>
            </div>
        </footer>
    </section>
</div>
