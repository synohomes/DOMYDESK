<div id="maintenanceSoftwareBulkModal" class="dmd-agent-modal dmd-maint-modal" hidden>
    <div class="dmd-agent-modal-backdrop" data-maint-close></div>
    <section class="dmd-agent-modal-card dmd-maint-card dmd-maint-software-card" role="dialog" aria-modal="true" aria-labelledby="maintenanceSoftwareBulkTitle">
        <header class="dmd-maint-head">
            <div>
                <h2 id="maintenanceSoftwareBulkTitle">Installation de logiciels</h2>
                <p>Bibliothèque DoMyDesk EXE / MSI + catalogue Winget. Les PC et les logiciels peuvent être sélectionnés dans n’importe quel ordre.</p>
            </div>
            <div class="dmd-maint-software-head-actions">
                <span id="maintSoftwareSelectedCount" class="dmd-maint-selection-pill">0 logiciel</span>
                <span class="dmd-maint-selection-pill">PC : <strong id="maintSoftwarePcCount">0</strong></span>
                <button type="button" class="dmd-agent-icon-btn" data-maint-close aria-label="Fermer">×</button>
            </div>
        </header>

        <div class="dmd-maint-body dmd-maint-software-body">
            <section class="dmd-maint-panel dmd-maint-software-source-panel">
                <div class="dmd-maint-panel-head">
                    <div>
                        <h3>Ajouter un logiciel</h3>
                        <p>Choisis la source puis ajoute le logiciel à la bibliothèque.</p>
                    </div>
                    <span id="maintWingetProbe" class="dmd-maint-probe-state">PC de recherche : automatique</span>
                </div>

                <form id="maintSoftwareAddForm" class="dmd-maint-software-single-form">
                    <div class="dmd-maint-source-switch" role="radiogroup" aria-label="Source du logiciel">
                        <label class="dmd-maint-source-choice is-active">
                            <input type="radio" name="source_type" value="file" checked>
                            <span>EXE / MSI</span>
                        </label>
                        <label class="dmd-maint-source-choice">
                            <input type="radio" name="source_type" value="winget">
                            <span>Winget</span>
                        </label>
                    </div>

                    <div class="dmd-maint-single-form-main">
                        <div class="dmd-maint-single-form-common">
                            <label>
                                <span>Nom du logiciel</span>
                                <input id="maintSoftwareDisplayName" type="text" name="name" maxlength="120" placeholder="Ex. 7-Zip">
                            </label>
                        </div>

                        <div class="dmd-maint-source-fields" data-maint-source-fields="file">
                            <label class="dmd-maint-file-field">
                                <span>Fichier EXE / MSI</span>
                                <input id="maintSoftwarePackage" type="file" name="package" accept=".exe,.msi">
                            </label>
                            <label>
                                <span>Arguments silencieux</span>
                                <input id="maintSoftwareArguments" type="text" name="arguments" maxlength="4096" placeholder="Optionnel">
                            </label>
                        </div>

                        <div class="dmd-maint-source-fields" data-maint-source-fields="winget" hidden>
                            <label class="dmd-maint-winget-query-field">
                                <span>Rechercher dans Winget</span>
                                <span class="dmd-maint-winget-searchbar">
                                    <input id="maintWingetSearchInput" type="search" placeholder="Ex. Google Chrome, Firefox, VLC, 7-Zip…" autocomplete="off">
                                    <button type="button" class="dmd-agent-btn" id="maintWingetSearchButton">Rechercher</button>
                                </span>
                            </label>
                        </div>

                        <div class="dmd-maint-single-form-action">
                            <button type="submit" class="dmd-agent-btn primary" id="maintSoftwareAddSubmit">Ajouter à la bibliothèque</button>
                        </div>
                    </div>

                    <div class="dmd-maint-winget-inline" id="maintWingetInline" hidden>
                        <div class="dmd-maint-winget-inline-head">
                            <strong>Résultats Winget</strong>
                            <span id="maintWingetResultCount">0 résultat</span>
                        </div>
                        <div id="maintWingetSearchResults" class="dmd-maint-winget-results dmd-maint-winget-results-compact">
                            <div class="dmd-maint-empty">Saisis un nom puis clique sur « Rechercher ».</div>
                        </div>
                    </div>
                </form>
            </section>

            <section class="dmd-maint-panel dmd-maint-library-panel">
                <div class="dmd-maint-panel-head dmd-maint-library-toolbar">
                    <div>
                        <h3>Bibliothèque logiciels</h3>
                        <p>Coche les logiciels à installer ou désinstaller. La sélection reste active pendant que tu choisis les PC.</p>
                    </div>
                    <div class="dmd-maint-library-tools">
                        <input id="maintSoftwareLibrarySearch" type="search" placeholder="Filtrer la bibliothèque…" autocomplete="off">
                        <button type="button" class="dmd-agent-mini-btn" id="maintSoftwareRefresh">Actualiser</button>
                    </div>
                </div>
                <div id="maintSoftwareLibrary" class="dmd-maint-library dmd-maint-library-large">
                    <div class="dmd-maint-empty">Chargement…</div>
                </div>
            </section>


            <section class="dmd-maint-panel dmd-maint-targets-inline" id="maintSoftwarePcSection">
                <div class="dmd-maint-panel-head">
                    <div>
                        <h3>PC cibles</h3>
                        <p>Choisis ici les PC ou les groupes. La sélection reste visible sous les logiciels.</p>
                    </div>
                    <div class="dmd-maint-inline-target-head">
                        <strong id="maintSoftwarePcPopupCount">0 sélectionné</strong>
                        <label class="dmd-maint-checkall"><input type="checkbox" id="maintSoftwareAllPc"> Tous</label>
                    </div>
                </div>
                <div class="dmd-maint-target-toolbar">
                    <input id="maintSoftwarePcSearch" type="search" placeholder="Rechercher un PC, une IP ou un groupe…" autocomplete="off">
                    <div class="dmd-maint-group-buttons">
                        <?php foreach((array)($pcGroupsData['groups']??array()) as $g): if(!is_array($g))continue;$gid=trim((string)($g['group_id']??''));$gn=trim((string)($g['name']??''));if($gid===''||$gn==='')continue; ?>
                            <button type="button" class="dmd-agent-mini-btn" data-maint-software-group="<?= dmd_agent_h($gid) ?>"><?= dmd_agent_h($gn) ?></button>
                        <?php endforeach; ?>
                        <button type="button" class="dmd-agent-mini-btn" data-maint-software-clear>Aucun</button>
                    </div>
                </div>
                <div id="maintSoftwarePcGrid" class="dmd-maint-pc-grid dmd-maint-pc-grid-inline">
                    <?php foreach($devices as $d):
                        $aid=(string)($d['agent_id']??'');
                        $hn=(string)($d['hostname']??'PC');
                        $dip=(string)($d['last_ip']??'IP inconnue');
                        $dst=(string)($d['status']??'');
                        $last=(int)($d['last_seen_ts']??0);
                        $isOnline=($dst==='active' && $last>0 && ($now-$last)<90);
                        $groups=dmd_agent_device_group_names($aid,$pcGroupsData);
                        $groupIds=array();
                        foreach((array)($pcGroupsData['groups']??array()) as $pg){
                            if(is_array($pg)&&in_array($aid,(array)($pg['agent_ids']??array()),true))$groupIds[]=trim((string)($pg['group_id']??''));
                        }
                        $groupIds=array_values(array_filter(array_unique($groupIds),function($v){return $v!=='';}));
                        $groupText=$groups?implode(', ',$groups):'Aucun groupe';
                        $searchPc=strtolower(trim($hn.' '.$dip.' '.$groupText.' '.$aid));
                    ?>
                    <label class="dmd-maint-pc dmd-maint-pc-compact <?= $isOnline?'is-online':'is-offline' ?>"
                           data-maint-pc-search="<?= dmd_agent_h($searchPc) ?>"
                           data-maint-pc-groups="<?= dmd_agent_h(implode(' ',$groupIds)) ?>"
                           data-maint-pc-online="<?= $isOnline?'1':'0' ?>">
                        <input type="checkbox" value="<?= dmd_agent_h($aid) ?>" <?= ($dst==='active' && $isOnline)?'':'disabled' ?>>
                        <span class="dmd-maint-pc-copy">
                            <strong><?= dmd_agent_h($hn) ?></strong>
                            <small class="dmd-maint-pc-group"><?= dmd_agent_h($groupText) ?></small>
                            <small class="dmd-maint-pc-ip"><?= dmd_agent_h($dip) ?></small>
                        </span>
                        <i class="dmd-maint-pc-dot" title="<?= $isOnline?'En ligne':'Hors ligne' ?>"></i>
                    </label>
                    <?php endforeach; ?>
                </div>
                <div class="dmd-maint-inline-target-foot">
                    <strong id="maintSoftwarePcFooterCount">0 PC sélectionné</strong>
                    <small id="maintSoftwarePcFooterSoftware">0 logiciel sélectionné</small>
                </div>
            </section>

            <section class="dmd-maint-panel dmd-maint-deploy-panel">
                <div class="dmd-maint-deploy-summary">
                    <div>
                        <strong id="maintSoftwareDeploySummary">0 logiciel · 0 PC</strong>
                        <small>Tu peux choisir les PC avant ou après les logiciels.</small>
                    </div>
                    <div class="dmd-maint-actions">
                        <button type="button" class="dmd-agent-btn primary" id="maintSoftwareInstall">Installer la sélection</button>
                        <button type="button" class="dmd-agent-btn danger" id="maintSoftwareUninstall">Désinstaller la sélection</button>
                    </div>
                </div>
                <div id="maintSoftwareResults" class="dmd-maint-results">Aucune opération lancée.</div>
            </section>
        </div>

        <footer class="dmd-maint-foot">
            <span>La fenêtre « Logiciels » de la fiche PC reste réservée aux opérations sur un seul poste.</span>
            <button type="button" class="dmd-agent-btn" data-maint-close>Fermer</button>
        </footer>
    </section>
</div>

