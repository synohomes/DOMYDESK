<section id="deviceFeatureModal" class="dmd-agent-device-feature-page" hidden>
    <div class="dmd-agent-feature-card" aria-labelledby="deviceFeatureTitle">
        <header class="dmd-agent-feature-head">
            <div>
                <h2 id="deviceFeatureTitle">Détails</h2>
                <p id="deviceFeatureSub">—</p>
            </div>
            <div class="dmd-agent-feature-head-actions">
                <span id="deviceFeatureState" class="dmd-agent-data-state">Prêt</span>
                <button type="button" class="dmd-agent-icon-btn" data-close-feature aria-label="Retour au poste">←</button>
            </div>
        </header>
        <div id="deviceFeatureBody" class="dmd-agent-feature-body"></div>
    </div>
</section>

