    <section id="panel-create" class="dmd-agent-drawer" hidden>
        <div class="dmd-agent-drawer-head">
            <div><h2>Nouvel agent</h2><p>Prépare l’installation d’un poste et les fonctions qui lui seront attribuées.</p></div>
            <button type="button" class="dmd-agent-icon-btn" data-close-panel aria-label="Retour">←</button>
        </div>
        <form id="createForm" class="dmd-agent-form">
            <label>Nom prévu du PC<input name="target_name" maxlength="100" placeholder="PC-BUREAU" required></label>
            <label>Expiration<select name="expires_minutes"><option value="15">15 minutes</option><option value="60">1 heure</option><option value="360">6 heures</option><option value="1440" selected>24 heures</option><option value="10080">7 jours</option></select></label>
            <label>Validation<select name="approval_mode"><option value="manual" selected>Validation Superadmin</option><option value="auto">Automatique</option></select></label>
            <div class="dmd-agent-form-note">DMD-Agent sera installé sur le poste. Les options ci-dessous ajoutent uniquement les fonctions Remote et MyDesk souhaitées.</div>
            <label class="dmd-agent-mydesk-choice <?= $remoteCanEnroll?'':'is-disabled' ?>">
                <input type="checkbox" name="include_remote" value="1" checked <?= $remoteCanEnroll?'':'disabled' ?>>
                <span><strong>Inclure DMD-Remote</strong><small><?= $remoteCanEnroll ? 'Prise en main distante · '.$remoteUsage.' / '.$licenseQuotaText($remoteLimit).' utilisés.' : 'Quota Remote atteint ou licence indisponible.' ?></small></span>
            </label>
            <label class="dmd-agent-mydesk-choice <?= $myDeskLicensed?'':'is-disabled' ?>">
                <input type="checkbox" name="include_mydesk" value="1" <?= $myDeskLicensed?'':'disabled' ?>>
                <span><strong>Inclure DMD-MyDesk</strong><small><?= $myDeskLicensed ? 'Accès aux modules MyDesk autorisés pour ce poste.' : 'Licence MyDesk indisponible.' ?></small></span>
            </label>
            <div class="dmd-agent-actions dmd-agent-form-actions"><button class="dmd-agent-btn primary" type="submit" <?= empty($identity['ok'])?'disabled':'' ?>>Créer l’enrôlement</button></div>
        </form>
        <div id="bootstrapBox" class="dmd-agent-bootstrap">
            <div class="dmd-agent-bootstrap-head"><div><strong>Fichiers d’installation</strong><span>À utiliser uniquement pour ce poste et pendant la durée de validité choisie.</span></div></div>
            <textarea id="bootstrapText" readonly></textarea>
            <div class="dmd-agent-actions"><button id="downloadBundle" class="dmd-agent-btn primary" type="button">Télécharger l’installation</button><button id="downloadBootstrap" class="dmd-agent-btn" type="button">JSON seul</button><a class="dmd-agent-btn" href="api/admin_download_installer.php">Installateur maintenance</a><button id="copyBootstrap" class="dmd-agent-btn" type="button">Copier</button></div>
        </div>
    </section>
