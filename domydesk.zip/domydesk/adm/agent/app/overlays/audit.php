<div id="auditModal" class="dmd-agent-modal dmd-audit-modal-shell" hidden>
    <div class="dmd-agent-modal-backdrop" data-close-audit></div>

    <section class="dmd-agent-modal-card dmd-agent-audit-modal" role="dialog" aria-modal="true" aria-labelledby="auditModalTitle">
        <header class="dmd-agent-modal-head dmd-audit-modal-head">
            <div>
                <div class="dmd-agent-modal-status">
                    <span id="auditSignatureDot" class="dmd-agent-live-dot"></span>
                    <span id="auditSignatureState">Audit</span>
                    <span id="auditSchemaBadge" class="dmd-audit-schema-badge">Archive</span>
                </div>
                <h2 id="auditModalTitle">Audit PC</h2>
                <p id="auditModalSub">—</p>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-close-audit aria-label="Fermer">×</button>
        </header>

        <div class="dmd-agent-modal-body dmd-audit-modal-body">
            <section class="dmd-agent-detail-card">
                <h3>Identité du poste / Agent</h3>
                <div id="auditGeneral" class="dmd-agent-detail-grid"></div>
            </section>

            <section class="dmd-agent-detail-card">
                <h3>Révocation</h3>
                <div id="auditRevocation" class="dmd-agent-detail-grid"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Enrôlement</h3>
                <div id="auditEnrollment" class="dmd-agent-detail-grid"></div>
                <div id="auditEndpoints" class="dmd-audit-sublist"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Dernier état système connu</h3>
                <div id="auditTelemetry" class="dmd-agent-detail-grid"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Matériel</h3>
                <div id="auditHardware" class="dmd-audit-kv-table"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Inventaire</h3>
                <div id="auditInventory" class="dmd-audit-kv-table"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Réseau</h3>
                <div id="auditNetwork" class="dmd-audit-kv-table"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <div class="dmd-audit-card-title-row">
                    <h3>Ports ouverts</h3>
                    <strong id="auditPortsCount">0</strong>
                </div>
                <div id="auditPorts" class="dmd-audit-port-grid"></div>
            </section>

            <section class="dmd-agent-detail-card full">
                <div class="dmd-audit-card-title-row">
                    <h3>Capacités Agent</h3>
                    <strong id="auditCapabilitiesCount">0</strong>
                </div>
                <div class="dmd-audit-capability-columns">
                    <div>
                        <h4>Autorisées par DoMyDesk</h4>
                        <div id="auditCapabilities" class="dmd-agent-cap-list"></div>
                    </div>
                    <div>
                        <h4>Déclarées par l’Agent</h4>
                        <div id="auditReportedCapabilities" class="dmd-agent-cap-list"></div>
                    </div>
                </div>
            </section>

            <section class="dmd-agent-detail-card full">
                <h3>Groupes du PC</h3>
                <div id="auditGroups" class="dmd-agent-cap-list"></div>
            </section>

            <details class="dmd-agent-detail-card full dmd-agent-cap-details" open>
                <summary>
                    <span>Droits au moment de la révocation</span>
                    <strong id="auditRightsCount">0</strong>
                </summary>
                <div id="auditRights" class="dmd-agent-audit-rights"></div>
            </details>

            <details class="dmd-agent-detail-card full dmd-agent-cap-details" open>
                <summary>
                    <span>Événements sécurité</span>
                    <strong id="auditEventsCount">0</strong>
                </summary>
                <div id="auditEvents" class="dmd-agent-audit-events"></div>
            </details>

            <details class="dmd-agent-detail-card full dmd-agent-cap-details">
                <summary>
                    <span>Données techniques complètes de l’archive</span>
                    <strong>JSON</strong>
                </summary>
                <p class="dmd-audit-tech-note">
                    Cette zone affiche tous les champs réellement archivés. Les secrets, tokens, mots de passe et nonces sont volontairement exclus.
                </p>
                <pre id="auditRawArchive" class="dmd-audit-raw-json"></pre>
            </details>
        </div>

        <footer class="dmd-agent-modal-foot dmd-audit-modal-foot">
            <span class="dmd-agent-audit-note">Archive signée : aucun token, mot de passe, nonce ou clé privée n’est conservé.</span>
            <div class="dmd-audit-modal-actions">
                <button type="button" class="dmd-agent-btn" data-audit-print>Imprimer / PDF</button>
                <button type="button" class="dmd-agent-btn" data-close-audit>Fermer</button>
            </div>
        </footer>
    </section>
</div>

<script>
(function () {
    'use strict';

    const modal = document.getElementById('auditModal');
    const dataNode = document.getElementById('dmdAgentAuditsData');
    if (!modal || !dataNode) return;

    let audits = [];
    let currentAudit = null;

    try {
        audits = JSON.parse(dataNode.textContent || '[]');
        if (!Array.isArray(audits)) audits = [];
    } catch (_) {
        audits = [];
    }

    const $ = (id) => document.getElementById(id);
    const esc = (value) => String(value ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');

    const object = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    const array = (value) => Array.isArray(value) ? value : [];
    const first = (...values) => values.find(v => v !== undefined && v !== null && v !== '') ?? '';

    function formatDate(value) {
        if (!value) return '—';

        let candidate = value;
        if (typeof value === 'number' && Number.isFinite(value)) {
            candidate = value > 100000000000 ? value : value * 1000;
        }

        const d = new Date(candidate);
        if (Number.isNaN(d.getTime())) return String(value);

        return new Intl.DateTimeFormat('fr-FR', {
            dateStyle: 'short',
            timeStyle: 'medium'
        }).format(d);
    }

    function formatBytes(value) {
        const n = Number(value);
        if (!Number.isFinite(n) || n < 0) return '—';
        if (n === 0) return '0 o';

        const units = ['o', 'Ko', 'Mo', 'Go', 'To', 'Po'];
        let i = 0, v = n;
        while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }

        return (v >= 10 || i === 0 ? v.toFixed(0) : v.toFixed(1)).replace('.', ',') + ' ' + units[i];
    }

    function formatPercent(value) {
        const n = Number(value);
        return Number.isFinite(n) ? n.toFixed(1).replace('.', ',') + ' %' : '—';
    }

    function formatDuration(seconds) {
        let s = Number(seconds);
        if (!Number.isFinite(s) || s < 0) return '—';

        s = Math.floor(s);
        const d = Math.floor(s / 86400); s %= 86400;
        const h = Math.floor(s / 3600); s %= 3600;
        const m = Math.floor(s / 60);

        return [
            d ? d + ' j' : '',
            h ? h + ' h' : '',
            m ? m + ' min' : ''
        ].filter(Boolean).join(' ') || '< 1 min';
    }

    function displayScalar(value) {
        if (value === true) return 'Oui';
        if (value === false) return 'Non';
        if (value === null || value === undefined || value === '') return '—';

        if (Array.isArray(value)) {
            if (!value.length) return '—';
            if (value.every(v => typeof v !== 'object' || v === null)) return value.join(', ');
            return value.length + ' élément(s)';
        }

        if (typeof value === 'object') return Object.keys(value).length + ' champ(s)';
        return String(value);
    }

    function humanKey(key) {
        const map = {
            cpu: 'CPU',
            cpu_model: 'Modèle CPU',
            model: 'Modèle',
            name: 'Nom',
            manufacturer: 'Fabricant',
            serial: 'N° de série',
            serial_number: 'N° de série',
            bios: 'BIOS',
            board: 'Carte mère',
            motherboard: 'Carte mère',
            memory: 'Mémoire',
            ram: 'RAM',
            total_bytes: 'Total',
            used_bytes: 'Utilisé',
            free_bytes: 'Libre',
            usage_percent: 'Utilisation',
            uptime_seconds: 'Uptime',
            os: 'Système',
            os_name: 'Système',
            os_version: 'Version OS',
            hostname: 'Nom Windows',
            username: 'Utilisateur',
            users: 'Utilisateurs',
            sessions: 'Sessions',
            disks: 'Disques',
            volumes: 'Volumes',
            interfaces: 'Interfaces',
            addresses: 'Adresses',
            mac: 'MAC',
            mac_address: 'MAC',
            ipv4: 'IPv4',
            ipv6: 'IPv6',
            gateway: 'Passerelle',
            dns: 'DNS',
            dhcp: 'DHCP',
            domain: 'Domaine',
            workgroup: 'Groupe de travail',
            platform: 'Plateforme',
            arch: 'Architecture'
        };

        if (map[key]) return map[key];

        return String(key)
            .replace(/_/g, ' ')
            .replace(/\b\w/g, c => c.toUpperCase());
    }

    function flattenObject(value, prefix = '', out = [], depth = 0) {
        if (depth > 5 || out.length > 250) return out;

        if (Array.isArray(value)) {
            if (!value.length) {
                if (prefix) out.push([prefix, '—']);
                return out;
            }

            if (value.every(v => typeof v !== 'object' || v === null)) {
                out.push([prefix || 'Valeur', value.join(', ')]);
                return out;
            }

            value.forEach((item, index) => {
                const next = prefix ? prefix + ' · ' + (index + 1) : String(index + 1);
                flattenObject(item, next, out, depth + 1);
            });

            return out;
        }

        if (value && typeof value === 'object') {
            const entries = Object.entries(value);

            if (!entries.length && prefix) {
                out.push([prefix, '—']);
                return out;
            }

            entries.forEach(([key, item]) => {
                const label = prefix ? prefix + ' · ' + humanKey(key) : humanKey(key);

                if (item && typeof item === 'object') {
                    flattenObject(item, label, out, depth + 1);
                } else {
                    out.push([label, displayScalar(item)]);
                }
            });

            return out;
        }

        out.push([prefix || 'Valeur', displayScalar(value)]);
        return out;
    }

    function renderKv(target, value, emptyText = 'Aucune donnée archivée.') {
        const node = typeof target === 'string' ? $(target) : target;
        if (!node) return;

        const rows = flattenObject(value);

        node.innerHTML = rows.length
            ? rows.map(([label, val]) =>
                '<div class="dmd-audit-kv-row"><small>' + esc(label) + '</small><strong>' + esc(val) + '</strong></div>'
              ).join('')
            : '<div class="dmd-audit-empty-detail">' + esc(emptyText) + '</div>';
    }

    function detail(label, value) {
        return '<div><small>' + esc(label) + '</small><strong>' + esc(displayScalar(value)) + '</strong></div>';
    }

    function normalizeVolumes(value) {
        return array(value).map(v => object(v)).map(v => ({
            name: first(v.name, v.mount, v.mount_point, v.drive, v.letter, 'Disque'),
            total: first(v.total_bytes, v.total, v.size_bytes, v.size),
            free: first(v.free_bytes, v.free, v.available_bytes, v.available),
            usage: first(v.usage_percent, v.percent, v.used_percent)
        }));
    }

    function normalizeSessions(value) {
        return array(value).map(v => object(v)).map(v => ({
            username: first(v.username, v.user, v.name, 'Session'),
            state: first(v.state, v.status, ''),
            domain: first(v.domain, '')
        }));
    }

    function normalizePorts(value) {
        return array(value);
    }

    function renderPorts(ports) {
        const node = $('auditPorts');
        if (!node) return;

        $('auditPortsCount').textContent = ports.length + ' port(s)';

        if (!ports.length) {
            node.innerHTML = '<div class="dmd-audit-empty-detail">Aucun port ouvert archivé.</div>';
            return;
        }

        node.innerHTML = ports.map(port => {
            if (port && typeof port === 'object') {
                const p = object(port);
                const number = first(p.port, p.local_port, p.localPort, p.number, '—');
                const proto = first(p.protocol, p.proto, p.transport, '');
                const address = first(p.address, p.local_address, p.localAddress, '');
                const process = first(p.process, p.process_name, p.processName, p.pid ? 'PID ' + p.pid : '');

                return '<div class="dmd-audit-port">'
                    + '<strong>' + esc(number) + (proto ? ' / ' + esc(proto) : '') + '</strong>'
                    + '<span>' + esc([address, process].filter(Boolean).join(' · ') || '—') + '</span>'
                    + '</div>';
            }

            return '<div class="dmd-audit-port"><strong>' + esc(port) + '</strong></div>';
        }).join('');
    }

    function renderCapabilities(id, values, emptyText) {
        const node = $(id);
        if (!node) return;

        const items = array(values).map(v => String(v)).filter(Boolean).sort();
        node.innerHTML = items.length
            ? items.map(v => '<span>' + esc(v) + '</span>').join('')
            : '<span>' + esc(emptyText) + '</span>';
    }

    function renderEvents(events) {
        const node = $('auditEvents');
        $('auditEventsCount').textContent = events.length + ' événement(s)';

        if (!events.length) {
            node.innerHTML = '<div class="dmd-audit-empty-detail">Aucun événement de sécurité archivé.</div>';
            return;
        }

        node.innerHTML = events.slice().reverse().map(e => {
            e = object(e);

            const title = first(e.event, e.type, e.action, e.message, 'Événement');
            const date = first(e.date_iso, e.created_at, e.date, e.time, e.ts, e.timestamp, '');
            const status = first(e.status, '');
            const ip = first(e.ip, '');
            const details = object(e.details);
            const rows = flattenObject(details);

            return '<article class="dmd-audit-event">'
                + '<header><strong>' + esc(title) + '</strong>'
                + '<span>' + esc(formatDate(date)) + (status ? ' · ' + esc(status) : '') + (ip ? ' · ' + esc(ip) : '') + '</span></header>'
                + (rows.length
                    ? '<div class="dmd-audit-event-details">'
                        + rows.map(([k,v]) => '<div><small>' + esc(k) + '</small><span>' + esc(v) + '</span></div>').join('')
                        + '</div>'
                    : '')
                + '</article>';
        }).join('');
    }

    function openAudit(id) {
        const audit = audits.find(a => String(a && a.audit_id) === String(id));
        if (!audit) {
            console.warn('Audit introuvable:', id);
            return;
        }

        currentAudit = audit;

        const ag = object(audit.agent);
        const rv = object(audit.revocation);
        const enr = object(audit.enrollment);
        const inv = object(ag.last_inventory);
        const tel = object(ag.telemetry);
        const hardware = object(ag.hardware);
        const network = first(ag.network, inv.network, tel.network, {});

        const cpu = object(first(tel.cpu, inv.cpu, hardware.cpu, {}));
        const mem = object(first(tel.memory, tel.ram, inv.memory, inv.ram, hardware.memory, hardware.ram, {}));
        const vols = normalizeVolumes(first(tel.volumes, tel.disks, inv.volumes, inv.disks, []));
        const sessions = normalizeSessions(first(tel.sessions, inv.sessions, []));
        const ports = normalizePorts(first(ag.open_ports, tel.open_ports, inv.open_ports, []));
        const cert = object(ag.certificate);
        const certPayload = object(cert.payload);

        const title = first(ag.enrollment_name, enr.target_name, ag.hostname, 'PC révoqué');

        $('auditModalTitle').textContent = title;
        $('auditModalSub').textContent = [
            ag.hostname && ag.hostname !== title ? 'Windows : ' + ag.hostname : '',
            ag.agent_id || '',
            ag.last_ip || ''
        ].filter(Boolean).join(' · ') || '—';

        $('auditSignatureState').textContent = audit.signature_valid ? 'Signature valide' : 'Signature invalide';
        $('auditSignatureDot').className = 'dmd-agent-live-dot ' + (audit.signature_valid ? 'online' : 'offline');
        $('auditSchemaBadge').textContent = 'Archive v' + String(audit.schema || 1);

        $('auditGeneral').innerHTML = [
            detail('Agent ID', ag.agent_id),
            detail('Instance', audit.instance_id),
            detail('Enrôlement', first(ag.enrollment_id, enr.enrollment_id)),
            detail('Nom prévu', first(ag.enrollment_name, enr.target_name)),
            detail('Nom Windows', ag.hostname),
            detail('Système', (ag.platform || '—') + (ag.arch ? ' / ' + ag.arch : '')),
            detail('Version Agent', ag.agent_version),
            detail('Créé le', formatDate(ag.created_at)),
            detail('Dernier contact', formatDate(ag.last_seen_at)),
            detail('Dernière IP', ag.last_ip),
            detail('Empreinte PC', ag.device_key_fingerprint),
            detail('Certificat émis', formatDate(first(certPayload.issued_at, object(cert).issued_at))),
            detail('Certificat valide jusqu’au', formatDate(first(certPayload.valid_until, object(cert).valid_until)))
        ].join('');

        $('auditRevocation').innerHTML = [
            detail('Date', formatDate(rv.revoked_at)),
            detail('Révoqué par', rv.revoked_by),
            detail('Motif', rv.reason || 'Non renseigné'),
            detail('Audit ID', audit.audit_id),
            detail('Archive créée', formatDate(audit.created_at)),
            detail('Signature', audit.signature_valid ? 'Valide' : 'Invalide')
        ].join('');

        const components = object(enr.install_components);
        $('auditEnrollment').innerHTML = Object.keys(enr).length ? [
            detail('Nom prévu', enr.target_name),
            detail('Créé par', enr.created_by),
            detail('Créé le', formatDate(enr.created_at)),
            detail('Expiration', formatDate(enr.expires_at)),
            detail('Validation', enr.approval_mode === 'manual' ? 'Validation Superadmin' : (enr.approval_mode === 'auto' ? 'Automatique' : enr.approval_mode)),
            detail('État final', enr.status),
            detail('Adresse principale', enr.server_url),
            detail('Transport', enr.transport_policy),
            detail('DMD-Agent', components.agent === false ? 'Non' : 'Oui'),
            detail('DMD-Remote', components.remote ? 'Oui' : 'Non'),
            detail('DMD-MyDesk', components.mydesk ? 'Oui' : 'Non'),
            detail('Groupe prévu', first(enr.assigned_pc_group_name, enr.target_pc_group_name)),
            detail('Preuve vérifiée', enr.proof_verified ? 'Oui' : 'Non'),
            detail('Preuve vérifiée le', formatDate(enr.proof_verified_at)),
            detail('Approuvé le', formatDate(enr.approved_at)),
            detail('Terminé le', formatDate(enr.completed_at))
        ].join('') : '<div class="dmd-audit-legacy-note">Cette ancienne archive ne contient pas encore le snapshot détaillé de l’enrôlement.</div>';

        const endpoints = array(enr.server_endpoints);
        $('auditEndpoints').innerHTML = endpoints.length
            ? '<strong>Adresses enregistrées</strong>'
                + endpoints.map(endpoint => {
                    endpoint = object(endpoint);
                    return '<span>' + esc(first(endpoint.url, '—')) + (endpoint.transport_policy ? ' · ' + esc(endpoint.transport_policy) : '') + '</span>';
                }).join('')
            : '';

        $('auditTelemetry').innerHTML = [
            detail('CPU', first(cpu.model, cpu.name, inv.cpu_model, hardware.cpu_model)),
            detail('CPU utilisation', formatPercent(first(cpu.usage_percent, cpu.usage, cpu.percent, tel.cpu_percent))),
            detail('RAM totale', formatBytes(first(mem.total_bytes, mem.total, tel.memory_total_bytes))),
            detail('RAM utilisée', formatBytes(first(mem.used_bytes, mem.used, tel.memory_used_bytes))),
            detail('RAM utilisation', formatPercent(first(mem.usage_percent, mem.percent, tel.memory_percent))),
            detail('Disques', vols.length
                ? vols.map(v => v.name
                    + (v.total !== '' ? ' / ' + formatBytes(v.total) : '')
                    + (v.usage !== '' ? ' / ' + formatPercent(v.usage) : '')
                  ).join(' · ')
                : '—'),
            detail('Session(s)', sessions.length
                ? sessions.map(s => s.username + (s.domain ? '@' + s.domain : '') + (s.state ? ' (' + s.state + ')' : '')).join(', ')
                : '—'),
            detail('Ports ouverts', ports.length),
            detail('Uptime', formatDuration(first(tel.uptime_seconds, inv.uptime_seconds)))
        ].join('');

        renderKv('auditHardware', hardware, 'Aucune information matérielle archivée.');
        renderKv('auditInventory', inv, 'Aucun inventaire archivé.');
        renderKv('auditNetwork', network, 'Aucune information réseau archivée.');
        renderPorts(ports);

        const capabilities = array(ag.capabilities);
        const reported = array(ag.reported_capabilities);
        $('auditCapabilitiesCount').textContent = capabilities.length + ' autorisée(s) · ' + reported.length + ' déclarée(s)';
        renderCapabilities('auditCapabilities', capabilities, 'Aucune capability autorisée.');
        renderCapabilities('auditReportedCapabilities', reported, 'Aucune capability déclarée.');

        const groups = array(audit.pc_groups);
        $('auditGroups').innerHTML = groups.length
            ? groups.map(g => {
                g = object(g);
                const title = first(g.name, g.group_id, 'Groupe');
                const description = first(g.description, '');
                return '<span title="' + esc(description) + '">' + esc(title) + '</span>';
            }).join('')
            : '<span>Aucun groupe</span>';

        const rights = array(audit.access_policies);
        $('auditRightsCount').textContent = rights.length + ' règle(s)';
        $('auditRights').innerHTML = rights.length
            ? rights.map(r => {
                r = object(r);

                const subject = first(r.subject_id, 'Sujet');
                const type = first(r.subject_type, '');
                const permissions = array(r.permissions);
                const groups = array(r.pc_group_ids);
                const scope = r.all_pcs
                    ? 'Tous les PC'
                    : [
                        r.direct_agent ? 'PC direct' : '',
                        groups.length ? 'Groupes : ' + groups.join(', ') : ''
                      ].filter(Boolean).join(' · ') || 'Portée non précisée';

                return '<article class="dmd-audit-right">'
                    + '<header><strong>' + esc(subject) + '</strong><span>' + esc(type) + '</span></header>'
                    + '<small>' + esc(scope) + '</small>'
                    + '<div class="dmd-agent-cap-list">'
                        + (permissions.length ? permissions.map(p => '<span>' + esc(p) + '</span>').join('') : '<span>Aucun droit</span>')
                    + '</div>'
                    + '</article>';
            }).join('')
            : '<div class="dmd-audit-empty-detail">Aucune règle enregistrée.</div>';

        renderEvents(array(audit.events));

        const raw = $('auditRawArchive');
        if (raw) {
            try {
                raw.textContent = JSON.stringify(audit, null, 2);
            } catch (_) {
                raw.textContent = 'Impossible d’afficher les données JSON.';
            }
        }

        modal.hidden = false;
        document.documentElement.classList.add('dmd-audit-modal-open');
    }

    function closeAudit() {
        modal.hidden = true;
        currentAudit = null;
        document.documentElement.classList.remove('dmd-audit-modal-open');
    }

    function printKvTable(title, value) {
        const rows = flattenObject(value);
        if (!rows.length) return '';

        return '<h2>' + esc(title) + '</h2><table>'
            + rows.map(([k,v]) => '<tr><th>' + esc(k) + '</th><td>' + esc(v) + '</td></tr>').join('')
            + '</table>';
    }

    function printableAudit(audit) {
        const ag = object(audit.agent);
        const rv = object(audit.revocation);
        const enr = object(audit.enrollment);
        const groups = array(audit.pc_groups);
        const rights = array(audit.access_policies);
        const events = array(audit.events);

        const title = first(ag.enrollment_name, enr.target_name, ag.hostname, 'PC révoqué');

        return `
            <section class="audit-print-card">
                <h1>${esc(title)}</h1>
                <p class="sub">${esc(ag.agent_id || '')}</p>

                <h2>Identité / révocation</h2>
                <table>
                    <tr><th>Audit ID</th><td>${esc(audit.audit_id || '—')}</td></tr>
                    <tr><th>Signature</th><td>${audit.signature_valid ? 'Valide' : 'Invalide'}</td></tr>
                    <tr><th>Nom Windows</th><td>${esc(ag.hostname || '—')}</td></tr>
                    <tr><th>Agent ID</th><td>${esc(ag.agent_id || '—')}</td></tr>
                    <tr><th>Version Agent</th><td>${esc(ag.agent_version || '—')}</td></tr>
                    <tr><th>Système</th><td>${esc((ag.platform || '—') + (ag.arch ? ' / ' + ag.arch : ''))}</td></tr>
                    <tr><th>Dernière IP</th><td>${esc(ag.last_ip || '—')}</td></tr>
                    <tr><th>Dernier contact</th><td>${esc(formatDate(ag.last_seen_at))}</td></tr>
                    <tr><th>Date de révocation</th><td>${esc(formatDate(rv.revoked_at))}</td></tr>
                    <tr><th>Révoqué par</th><td>${esc(rv.revoked_by || '—')}</td></tr>
                    <tr><th>Motif</th><td>${esc(rv.reason || 'Non renseigné')}</td></tr>
                    <tr><th>Groupes</th><td>${esc(groups.map(g => object(g).name || object(g).group_id).filter(Boolean).join(', ') || 'Aucun')}</td></tr>
                    <tr><th>Règles d’accès</th><td>${rights.length}</td></tr>
                    <tr><th>Événements sécurité</th><td>${events.length}</td></tr>
                </table>

                ${printKvTable('Enrôlement', enr)}
                ${printKvTable('Matériel', object(ag.hardware))}
                ${printKvTable('Inventaire', object(ag.last_inventory))}
                ${printKvTable('Télémetrie', object(ag.telemetry))}
                ${printKvTable('Réseau', ag.network || {})}

                <h2>Capabilities</h2>
                <p><strong>Autorisées :</strong> ${esc(array(ag.capabilities).join(', ') || 'Aucune')}</p>
                <p><strong>Déclarées :</strong> ${esc(array(ag.reported_capabilities).join(', ') || 'Aucune')}</p>

                <h2>Événements sécurité</h2>
                ${events.length
                    ? '<table>'
                        + events.slice().reverse().map(e => {
                            e = object(e);
                            return '<tr><th>' + esc(first(e.event, e.type, e.action, 'Événement')) + '</th><td>'
                                + esc(formatDate(first(e.date_iso, e.created_at, e.timestamp, e.ts, '')))
                                + (e.status ? ' · ' + esc(e.status) : '')
                                + '</td></tr>';
                        }).join('')
                        + '</table>'
                    : '<p>Aucun événement archivé.</p>'
                }
            </section>`;
    }

    function openPrintWindow(items, title) {
        const w = window.open('', '_blank', 'noopener,noreferrer');
        if (!w) {
            alert('La fenêtre d’impression a été bloquée par le navigateur.');
            return;
        }

        w.document.open();
        w.document.write(`<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>
body{font-family:Arial,sans-serif;color:#111;background:#fff;margin:14mm;font-size:9pt}
h1{font-size:16pt;margin:0 0 2mm}.sub{margin:0 0 5mm;color:#555}
h2{font-size:11pt;margin:6mm 0 2mm;padding-bottom:1mm;border-bottom:1px solid #999}
.audit-print-card{break-inside:auto;margin:0 0 9mm;padding:0 0 7mm;border-bottom:1px solid #999}
table{border-collapse:collapse;width:100%;table-layout:fixed;margin-bottom:3mm}
th,td{border:1px solid #aaa;padding:1.8mm 2.2mm;text-align:left;vertical-align:top;word-break:break-word}
th{width:31%;background:#eee}
p{margin:1.5mm 0;word-break:break-word}
@page{size:A4;margin:12mm}
</style></head><body>${items.map(printableAudit).join('')}</body></html>`);
        w.document.close();
        w.focus();

        setTimeout(() => w.print(), 250);
    }

    document.addEventListener('click', function (event) {
        const open = event.target.closest('[data-audit-open]');
        if (open) {
            event.preventDefault();
            event.stopPropagation();
            openAudit(open.getAttribute('data-audit-open'));
            return;
        }

        if (event.target.closest('[data-close-audit]')) {
            event.preventDefault();
            closeAudit();
            return;
        }

        if (event.target.closest('[data-audit-print]')) {
            event.preventDefault();
            if (currentAudit) openPrintWindow([currentAudit], 'Audit DMD-Agent');
            return;
        }

        const printAll = event.target.closest('[data-audits-print-all]');
        if (printAll) {
            event.preventDefault();
            openPrintWindow(audits, 'Archives DMD-Agent');
            return;
        }

        const purge = event.target.closest('[data-audits-purge]');
        if (purge) {
            event.preventDefault();

            const root = document.querySelector('[data-audits-root]');
            const csrf = root ? (root.getAttribute('data-audits-csrf') || '') : '';
            if (!audits.length) return;

            if (!confirm('Purger définitivement toutes les archives d’audit ? Cette opération est irréversible.')) return;
            if (!confirm('Confirmation finale : supprimer ' + audits.length + ' archive(s) ?')) return;

            purge.disabled = true;
            const oldText = purge.textContent;
            purge.textContent = 'Purge…';

            fetch('api/admin_audit_purge.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-DMD-CSRF': csrf
                },
                body: JSON.stringify({ csrf_token: csrf, action: 'purge_all' })
            })
            .then(async response => {
                let body = {};
                try { body = await response.json(); } catch (_) {}

                if (!response.ok || !body.ok) {
                    throw new Error(body.error || ('HTTP ' + response.status));
                }

                location.reload();
            })
            .catch(error => {
                purge.disabled = false;
                purge.textContent = oldText;
                alert('Purge impossible : ' + error.message);
            });
        }
    }, true);

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && !modal.hidden) closeAudit();
    });
})();
</script>
