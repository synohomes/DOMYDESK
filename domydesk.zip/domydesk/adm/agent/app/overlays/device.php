<section id="deviceModal" class="dmd-agent-device-page" hidden>
    <div class="dmd-agent-launcher-card" aria-labelledby="deviceModalTitle">
        <header class="dmd-agent-launcher-head">
            <div class="dmd-agent-launcher-identity">
                <span class="dmd-agent-device-icon large">🖥️</span>
                <div>
                    <div class="dmd-agent-launcher-titleline">
                        <h2 id="deviceModalTitle">PC</h2>
                        <span class="dmd-agent-modal-status"><span id="deviceModalDot" class="dmd-agent-live-dot"></span><span id="deviceModalState">—</span></span>
                    </div>
                    <p id="deviceModalSub">—</p>
                </div>
            </div>
            <button type="button" class="dmd-agent-icon-btn" data-close-device aria-label="Retour">←</button>
        </header>

        <div class="dmd-agent-launcher-grid" aria-label="Tableau de bord du PC">
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="network">
                <span class="dmd-agent-tile-title">Réseau</span>
                <strong class="dmd-agent-tile-main" data-tile-main="network">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="network">IP · débit</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="machine">
                <span class="dmd-agent-tile-title">Machine</span>
                <strong class="dmd-agent-tile-main" data-tile-main="machine">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="machine">Système</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="sessions">
                <span class="dmd-agent-tile-title">Sessions</span>
                <strong class="dmd-agent-tile-main" data-tile-main="sessions">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="sessions">Session active</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="processes" data-command-cap="system.processes">
                <span class="dmd-agent-tile-title">Processus</span>
                <strong class="dmd-agent-tile-main" data-tile-main="processes">Chargement…</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="processes">Applications et processus</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="services" data-command-cap="system.services">
                <span class="dmd-agent-tile-title">Services</span>
                <strong class="dmd-agent-tile-main" data-tile-main="services">Chargement…</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="services">Services Windows</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="ports">
                <span class="dmd-agent-tile-title">Ports ouverts</span>
                <strong class="dmd-agent-tile-main" data-tile-main="ports">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="ports">TCP / UDP</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="storage">
                <span class="dmd-agent-tile-title">Stockages</span>
                <strong class="dmd-agent-tile-main" data-tile-main="storage">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="storage">Volumes</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="backup" data-command-cap="filesystem.read">
                <span class="dmd-agent-tile-title">Sauvegarde</span>
                <strong class="dmd-agent-tile-main" data-tile-main="backup">Fichiers</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="backup">Copie incrémentale · logs locaux</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="network-scan" data-command-cap="system.terminal">
                <span class="dmd-agent-tile-title">Sonde réseau</span>
                <strong class="dmd-agent-tile-main" data-tile-main="network-scan">Scan LAN</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="network-scan">IP · MAC · hostname · ports</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="terminal" data-command-cap="system.terminal">
                <span class="dmd-agent-tile-title">Terminal</span>
                <strong class="dmd-agent-tile-main">PowerShell · CMD</strong>
                <small class="dmd-agent-tile-sub">Exécution distante SYSTEM</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="software">
                <span class="dmd-agent-tile-title">Logiciels</span>
                <strong class="dmd-agent-tile-main" data-tile-main="software">Chargement…</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="software">Installés sur le PC</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile dmd-agent-launch-tile-updates" data-device-feature="updates">
                <span class="dmd-agent-tile-title">Mises à jour</span>
                <strong class="dmd-agent-tile-main">Windows · Logiciels · Agent</strong>
                <small class="dmd-agent-tile-sub">3 types séparés dans la fenêtre</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="security">
                <span class="dmd-agent-tile-title">Sécurité Agent</span>
                <strong class="dmd-agent-tile-main" data-tile-main="security">—</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="security">Identité et certificat</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="registry" data-command-cap="system.registry.read">
                <span class="dmd-agent-tile-title">Registre</span>
                <strong class="dmd-agent-tile-main">Registre Windows réel</strong>
                <small class="dmd-agent-tile-sub">HKLM · HKCU · HKU · HKCR</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="usb" data-command-cap="system.removable">
                <span class="dmd-agent-tile-title">USB</span>
                <strong class="dmd-agent-tile-main" data-tile-main="usb">Chargement…</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="usb">Clés / disques / lecteurs</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile" data-device-feature="network-paths" data-command-cap="system.networkpaths">
                <span class="dmd-agent-tile-title">Lecteurs réseau</span>
                <strong class="dmd-agent-tile-main" data-tile-main="network-paths">Chargement…</strong>
                <small class="dmd-agent-tile-sub" data-tile-sub="network-paths">Chemins SMB mappés</small>
            </button>
            <button type="button" class="dmd-agent-launch-tile dmd-agent-launch-tile-control" data-device-feature="control">
                <span class="dmd-agent-tile-title">Contrôle</span>
                <strong class="dmd-agent-tile-main">Remote · WOL</strong>
                <small class="dmd-agent-tile-sub">Éteindre · Redémarrer</small>
            </button>
        </div>

        <!-- Cache fonctionnel : les routines existantes continuent à remplir les données,
             mais rien de ceci n'est affiché dans la fiche principale. -->
        <div class="dmd-agent-device-data-cache" aria-hidden="true">
            <span id="deviceTelemetryState"></span>
            <div id="deviceHealth" class="dmd-agent-health-grid"></div>
            <div id="deviceNetwork" class="dmd-agent-detail-grid"></div>
            <div id="deviceGeneral" class="dmd-agent-detail-grid"></div>
            <div id="deviceSessions" class="dmd-agent-session-list"></div>
            <div id="deviceStorage" class="dmd-agent-storage-list"></div>
            <div id="devicePcGroups" class="dmd-agent-cap-list"></div>
            <strong id="devicePortsCount">0</strong><div id="devicePorts" class="dmd-agent-port-list"></div>
            <span id="deviceCommandState">Prêt</span><div id="deviceCommandResult"></div>
            <div id="deviceSecurity" class="dmd-agent-detail-grid"></div><strong id="deviceCapsCount">0 actives</strong><div id="deviceCaps" class="dmd-agent-cap-list"></div>
            <button type="button" id="deviceLoadProcesses" data-command-cap="system.processes">Processus</button>
            <button type="button" id="deviceLoadServices" data-command-cap="system.services">Services</button>
            <button type="button" id="deviceOpenSoftware">Logiciels</button>
            <button type="button" id="deviceOpenTerminal" data-command-cap="system.terminal">Terminal</button>
            <button type="button" id="deviceRestartPc" data-command-cap="system.power">Redémarrer</button>
            <button type="button" id="deviceShutdownPc" data-command-cap="system.power">Éteindre</button>
            <button type="button" id="deviceRevoke">Révoquer</button>
            <button type="button" id="deviceMyDeskUpgrade">MyDesk</button>
        </div>
    </div>
</section>
