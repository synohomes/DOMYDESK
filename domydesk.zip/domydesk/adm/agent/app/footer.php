<script>
const CSRF=<?= json_encode($csrfAgent) ?>;
const DEVICE_DATA=<?= $deviceJson ?: '[]' ?>;
let PC_GROUPS=<?= $pcGroupsJson ?: '[]' ?>;
let USER_GROUPS=<?= $userGroupsJson ?: '[]' ?>;
let ACCESS_POLICIES=<?= $policiesJson ?: '[]' ?>;
const DMD_USERS=<?= $usersJson ?: '[]' ?>;
const AGENT_AUDITS=<?= $auditsJson ?: '[]' ?>;
const DMD_MYDESK_LIMIT_LABEL=<?= json_encode($licenseQuotaText($myDeskLimit)) ?>;
</script>
<script src="app/agent-panel.js?v=45"></script>
</body>
</html>
