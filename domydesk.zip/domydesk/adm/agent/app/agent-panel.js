const msg=document.getElementById('msg');
const DMD_BASE_PATH=(location.pathname.split('/adm/agent/')[0]||'').replace(/\/$/,'');
const DMD_SERVER_URL=location.origin+DMD_BASE_PATH;
let msgTimer=null;
function showMsg(text,ok=true){
    msg.textContent=text;
    msg.className='dmd-agent-message show '+(ok?'dmd-agent-ok':'dmd-agent-bad');
    clearTimeout(msgTimer);
    msgTimer=setTimeout(()=>{msg.className='dmd-agent-message';},3200);
}
async function post(url,payload){payload.csrf_token=CSRF;const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':CSRF},body:JSON.stringify(payload),credentials:'same-origin'});let j={};try{j=await r.json()}catch(e){j={ok:false,error:'Réponse JSON invalide'};}if(!r.ok&&j.ok!==false)j.ok=false;return j;}

function formatDate(value){if(!value)return 'Jamais';const d=new Date(value);if(Number.isNaN(d.getTime()))return value;const diff=Math.max(0,Date.now()-d.getTime());if(diff<60000)return 'À l’instant';if(diff<3600000)return 'Il y a '+Math.floor(diff/60000)+' min';if(diff<86400000)return 'Il y a '+Math.floor(diff/3600000)+' h';return d.toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});}
document.querySelectorAll('.dmd-agent-date').forEach(el=>{el.textContent=formatDate(el.dataset.date||el.textContent.trim());});

const panels={create:document.getElementById('panel-create'),enrollments:document.getElementById('panel-enrollments'),security:document.getElementById('panel-security')};
let selectedDevice=null;let agentInteractiveTimer=null;

// Console 3 colonnes : une seule zone de travail centrale, y compris pour les actions rapides.
const workspaceFleet=document.getElementById('workspace-fleet');
const workspaceAdministration=document.getElementById('workspace-administration');
const workspaceTools=document.getElementById('workspace-tools');
const workspaceToolHost=document.getElementById('workspaceToolHost');
const workspaceNav=[...document.querySelectorAll('.dmd-agent-workspace-nav [data-workspace-view], .dmd-agent-workspace-nav [data-workspace-admin], .dmd-agent-workspace-nav [data-maintenance-popup], .dmd-agent-workspace-nav [data-open-panel]')];
const adminPanes=[...document.querySelectorAll('[data-admin-pane]')];
const adminLabels={
    'backup':['Sauvegardes','Sauvegarde des données, moteurs détectés et images système.'],
    'network-scan':['Scan réseau','Découvre les équipements visibles depuis un poste du parc.'],
    'pc-groups':['Groupes de PC','Organise le parc pour simplifier les opérations et les droits.'],
    'user-groups':['Groupes utilisateurs','Regroupe les comptes pour attribuer les droits plus facilement.'],
    'rights':['Droits RemoteAgent','Contrôle les accès aux postes et aux fonctions distantes.'],
    'mydesk':['DMD-MyDesk','Choisis les modules proposés aux utilisateurs MyDesk.'],
    'licenses':['Licences','Consulte l’utilisation et l’état des licences de cette instance.'],
    'audits':['Audits','Consulte l’historique des révocations et des suppressions de postes.']
};
let workspaceState={type:'fleet',name:'dashboard'};
let workspaceBeforeTool={type:'fleet',name:'dashboard'};

function setWorkspaceNavActive(target){
    workspaceNav.forEach(b=>{
        const popupTarget=b.dataset.maintenancePopup?('popup:'+b.dataset.maintenancePopup):'';
        const toolTarget=b.dataset.openPanel?('tool:'+b.dataset.openPanel):'';
        const on=(b.dataset.workspaceView===target)||(b.dataset.workspaceAdmin===target)||(popupTarget===target)||(toolTarget===target);
        b.classList.toggle('active',on);
    });
    document.querySelectorAll('.dmd-agent-rail-actions [data-open-panel],.dmd-agent-rail-actions [data-workspace-admin],.dmd-agent-rail-actions [data-maintenance-popup]').forEach(b=>{
        const popupTarget=b.dataset.maintenancePopup?('popup:'+b.dataset.maintenancePopup):'';
        const toolTarget=b.dataset.openPanel?('tool:'+b.dataset.openPanel):'';
        const on=(b.dataset.workspaceAdmin===target)||(popupTarget===target)||(toolTarget===target);
        b.classList.toggle('active',on);
        b.classList.toggle('primary',on);
    });
}
function hideWorkspacePanes(){
    if(workspaceFleet)workspaceFleet.hidden=true;
    if(workspaceAdministration)workspaceAdministration.hidden=true;
    if(workspaceTools)workspaceTools.hidden=true;
}
function hideInlineEndpointPages(){
    ['deviceModal','deviceFeatureModal','terminalModal','softwareModal'].forEach(id=>{const el=document.getElementById(id);if(el)el.hidden=true;});
    if(agentInteractiveTimer){clearInterval(agentInteractiveTimer);agentInteractiveTimer=null;}
    if(['device','device-feature','terminal','software'].includes(workspaceState.type))selectedDevice=null;
    document.body.classList.remove('dmd-agent-modal-open');
}

/* R27.1 — isolation stricte des vues.
   Les pages Maintenance sont physiquement déplacées dans workspaceToolHost lorsqu'elles
   sont ouvertes. Avant d'afficher Parc / Administration / Enrôlements / Sécurité / Création,
   on remet systématiquement chaque carte dans son conteneur d'origine afin qu'aucune
   rubrique précédente ne reste affichée sous la suivante. */
const DMD_INLINE_MAINTENANCE_VIEWS=[
    ['maintenanceSoftwareBulkModal','maintenanceSoftwareBulkTitle'],
    ['maintenanceSoftwareUpdatesModal','maintenanceSoftwareUpdatesTitle'],
    ['maintenanceAgentUpdateModal','maintenanceAgentUpdateTitle'],
    ['maintenancePcUpdateModal','maintenancePcUpdateTitle'],
    ['maintenanceMyDeskModal','maintenanceMyDeskTitle']
];
function resetInlineMaintenanceViews(){
    DMD_INLINE_MAINTENANCE_VIEWS.forEach(([wrapperId,titleId])=>{
        const wrapper=document.getElementById(wrapperId);
        const card=document.querySelector('[aria-labelledby="'+titleId+'"]');
        if(!wrapper||!card)return;
        card.classList.remove('dmd-maint-inline-page');
        if(card.parentElement!==wrapper)wrapper.appendChild(card);
        wrapper.hidden=true;
    });
}
function hideToolPanels(){
    Object.values(panels).filter(Boolean).forEach(p=>p.hidden=true);
}
function openWorkspaceFleet(mode='dashboard'){
    mode=mode==='fleet'?'fleet':'dashboard';
    resetInlineMaintenanceViews();
    hideInlineEndpointPages();hideToolPanels();hideWorkspacePanes();
    if(workspaceFleet){
        workspaceFleet.hidden=false;
        workspaceFleet.classList.toggle('dmd-r37-fleet-only',mode==='fleet');
    }
    const title=document.getElementById('fleetPageTitle'),sub=document.getElementById('fleetPageSubtitle');
    if(title)title.textContent=mode==='fleet'?'Parc informatique':'Tableau de bord';
    if(sub)sub.textContent=mode==='fleet'?'Liste des postes gérés, état et accès aux actions.':'État du parc et accès aux opérations courantes.';
    workspaceState={type:'fleet',name:mode};
    setWorkspaceNavActive(mode);
}
function openAdminTab(name){
    resetInlineMaintenanceViews();
    hideInlineEndpointPages();hideToolPanels();hideWorkspacePanes();
    if(workspaceAdministration)workspaceAdministration.hidden=false;
    adminPanes.forEach(p=>{const on=p.dataset.adminPane===name;p.classList.toggle('active',on);p.hidden=!on;});
    const meta=adminLabels[name]||['Administration','Configuration DMD-Agent & DMD-MyDesk.'];
    const title=document.getElementById('workspaceAdminTitle'),sub=document.getElementById('workspaceAdminSubtitle');
    if(title)title.textContent=meta[0];if(sub)sub.textContent=meta[1];
    workspaceState={type:'admin',name:name};
    setWorkspaceNavActive(name);
}
function restoreWorkspace(){
    const prev=workspaceBeforeTool||{type:'fleet',name:'dashboard'};
    if(prev.type==='admin'&&prev.name)openAdminTab(prev.name);
    else if(prev.type==='fleet')openWorkspaceFleet(prev.name||'dashboard');
    else openWorkspaceFleet('dashboard');
}
function closePanels(restore=true){
    hideToolPanels();
    if(workspaceTools)workspaceTools.hidden=true;
    if(restore)restoreWorkspace();
}
function openPanel(name){
    const p=panels[name];if(!p)return;
    if(workspaceState.type!=='tool')workspaceBeforeTool={...workspaceState};
    resetInlineMaintenanceViews();
    hideInlineEndpointPages();hideToolPanels();hideWorkspacePanes();
    if(workspaceToolHost&&p.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(p);
    p.hidden=false;
    if(workspaceTools)workspaceTools.hidden=false;
    workspaceState={type:'tool',name:name};
    setWorkspaceNavActive('tool:'+name);
}

document.querySelectorAll('[data-open-panel]').forEach(b=>b.addEventListener('click',()=>openPanel(b.dataset.openPanel)));
document.querySelectorAll('[data-close-panel]').forEach(b=>b.addEventListener('click',()=>closePanels(true)));
document.querySelectorAll('[data-workspace-view]').forEach(b=>b.addEventListener('click',()=>openWorkspaceFleet(b.dataset.workspaceView)));
document.querySelectorAll('[data-workspace-admin]').forEach(b=>b.addEventListener('click',()=>openAdminTab(b.dataset.workspaceAdmin)));
openWorkspaceFleet('dashboard');
const r37Workspace=document.querySelector('.dmd-r37-workspace');
const r37Collapse=document.querySelector('.dmd-r37-sidebar-collapse');
const DMD_SIDEBAR_STATE_KEY='dmd-agent-sidebar-collapsed';

function applyR37SidebarState(collapsed,persist=false){
    if(!r37Workspace||!r37Collapse)return;
    r37Workspace.classList.toggle('is-collapsed',!!collapsed);
    r37Collapse.setAttribute('aria-expanded',collapsed?'false':'true');
    r37Collapse.setAttribute('aria-label',collapsed?'Développer le menu':'Réduire le menu');
    const arrow=r37Collapse.querySelector('span');
    if(arrow)arrow.textContent=collapsed?'»':'«';
    if(persist){
        try{localStorage.setItem(DMD_SIDEBAR_STATE_KEY,collapsed?'1':'0');}catch(_){ }
    }
}

if(r37Workspace&&r37Collapse){
    let savedCollapsed=false;
    try{savedCollapsed=localStorage.getItem(DMD_SIDEBAR_STATE_KEY)==='1';}catch(_){ }
    applyR37SidebarState(savedCollapsed,false);

    r37Collapse.addEventListener('click',()=>{
        applyR37SidebarState(!r37Workspace.classList.contains('is-collapsed'),true);
    });
}
const myDeskGrid=document.getElementById('myDeskModuleGrid');
function refreshMyDeskQuota(){
    if(!myDeskGrid)return;
    const boxes=[...myDeskGrid.querySelectorAll('input[name="mydesk_modules[]"]')];
    const checked=boxes.filter(x=>x.checked).length;
    const limit=Number(myDeskGrid.dataset.limit||0);
    const counter=document.getElementById('myDeskModuleCounter');
    if(counter){const strong=counter.querySelector('strong');if(strong)strong.textContent=String(checked);counter.classList.toggle('is-full',limit>=0&&checked>=limit);counter.classList.toggle('is-over',limit>=0&&checked>limit);}
    boxes.forEach(x=>{if(x.dataset.licenseDisabled==='1')return;x.disabled=!x.checked && limit>=0 && checked>=limit;});
}
if(myDeskGrid){[...myDeskGrid.querySelectorAll('input[name="mydesk_modules[]"]')].forEach(x=>x.addEventListener('change',refreshMyDeskQuota));refreshMyDeskQuota();}
const myDeskSettingsForm=document.getElementById('myDeskSettingsForm');
if(myDeskSettingsForm)myDeskSettingsForm.addEventListener('submit',async e=>{
    e.preventDefault();const fd=new FormData(myDeskSettingsForm);
    const r=await post('api/admin_mydesk_settings.php',{enabled_modules:fd.getAll('mydesk_modules[]')});
    if(!r.ok){showMsg('DMD-MyDesk : '+(r.error||'enregistrement impossible'),false);return;}
    showMsg('Modules DMD-MyDesk enregistrés.');
});
document.querySelectorAll('[data-maintenance-open-fleet]').forEach(b=>b.addEventListener('click',()=>openWorkspaceFleet()));
function htmlEsc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function byId(arr,key,id){return arr.find(x=>String(x?.[key]||'')===String(id||''));}

// PC groups
const pcGroupForm=document.getElementById('pcGroupForm'),pcGroupList=document.getElementById('pcGroupList');
function resetPcGroup(){pcGroupForm.reset();pcGroupForm.elements.group_id.value='';document.getElementById('pcGroupEditorTitle').textContent='Nouveau groupe de PC';document.getElementById('deletePcGroup').hidden=true;}
function editPcGroup(id){const g=byId(PC_GROUPS,'group_id',id);if(!g)return;resetPcGroup();pcGroupForm.elements.group_id.value=g.group_id;pcGroupForm.elements.name.value=g.name||'';pcGroupForm.elements.description.value=g.description||'';const members=new Set(g.agent_ids||[]);pcGroupForm.querySelectorAll('input[name="agent_ids[]"]').forEach(i=>i.checked=members.has(i.value));document.getElementById('pcGroupEditorTitle').textContent=g.name;document.getElementById('deletePcGroup').hidden=false;}
function renderPcGroups(){pcGroupList.innerHTML=PC_GROUPS.length?PC_GROUPS.map(g=>`<button type="button" class="dmd-agent-admin-list-item" data-pcg="${htmlEsc(g.group_id)}"><span><strong>${htmlEsc(g.name)}</strong><small>${(g.agent_ids||[]).length} PC</small></span><b>›</b></button>`).join(''):'<div class="dmd-agent-admin-empty">Aucun groupe de PC.</div>';pcGroupList.querySelectorAll('[data-pcg]').forEach(b=>b.addEventListener('click',()=>editPcGroup(b.dataset.pcg)));}
renderPcGroups();document.getElementById('newPcGroup').addEventListener('click',resetPcGroup);
pcGroupForm.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(pcGroupForm);
    const r=await post('api/admin_access.php',{action:'save_pc_group',group_id:fd.get('group_id'),name:fd.get('name'),description:fd.get('description'),agent_ids:fd.getAll('agent_ids[]')});
    if(!r.ok){showMsg('Groupe PC : '+(r.error||'erreur'),false);return;}
    const idx=PC_GROUPS.findIndex(g=>g.group_id===r.group.group_id);
    if(idx>=0) PC_GROUPS[idx]=r.group; else PC_GROUPS.push(r.group);
    renderPcGroups();fillPolicyDynamic();renderPolicies();editPcGroup(r.group.group_id);
    showMsg('Groupe de PC enregistré sans rechargement.');
});
document.getElementById('deletePcGroup').addEventListener('click',async()=>{
    const id=pcGroupForm.elements.group_id.value;
    if(!id||!confirm('Supprimer ce groupe de PC ? Les PC ne seront pas révoqués.'))return;
    const r=await post('api/admin_access.php',{action:'delete_pc_group',group_id:id});
    if(!r.ok){showMsg('Suppression impossible : '+(r.error||'erreur'),false);return;}
    PC_GROUPS=PC_GROUPS.filter(g=>g.group_id!==id);
    ACCESS_POLICIES=ACCESS_POLICIES.map(p=>({...p,pc_group_ids:(p.pc_group_ids||[]).filter(x=>x!==id)}));
    renderPcGroups();fillPolicyDynamic();renderPolicies();resetPcGroup();
    showMsg('Groupe de PC supprimé.');
});

// User groups
const userGroupForm=document.getElementById('userGroupForm'),userGroupList=document.getElementById('userGroupList');
function resetUserGroup(){userGroupForm.reset();userGroupForm.elements.group_id.value='';document.getElementById('userGroupEditorTitle').textContent='Nouveau groupe utilisateur';document.getElementById('deleteUserGroup').hidden=true;}
function editUserGroup(id){const g=byId(USER_GROUPS,'group_id',id);if(!g)return;resetUserGroup();userGroupForm.elements.group_id.value=g.group_id;userGroupForm.elements.name.value=g.name||'';userGroupForm.elements.description.value=g.description||'';const members=new Set(g.users||[]);userGroupForm.querySelectorAll('input[name="users[]"]').forEach(i=>i.checked=members.has(i.value));document.getElementById('userGroupEditorTitle').textContent=g.name;document.getElementById('deleteUserGroup').hidden=false;}
function renderUserGroups(){userGroupList.innerHTML=USER_GROUPS.length?USER_GROUPS.map(g=>`<button type="button" class="dmd-agent-admin-list-item" data-ugr="${htmlEsc(g.group_id)}"><span><strong>${htmlEsc(g.name)}</strong><small>${(g.users||[]).length} utilisateur(s)</small></span><b>›</b></button>`).join(''):'<div class="dmd-agent-admin-empty">Aucun groupe utilisateur.</div>';userGroupList.querySelectorAll('[data-ugr]').forEach(b=>b.addEventListener('click',()=>editUserGroup(b.dataset.ugr)));}
renderUserGroups();document.getElementById('newUserGroup').addEventListener('click',resetUserGroup);
userGroupForm.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(userGroupForm);
    const r=await post('api/admin_access.php',{action:'save_user_group',group_id:fd.get('group_id'),name:fd.get('name'),description:fd.get('description'),users:fd.getAll('users[]')});
    if(!r.ok){showMsg('Groupe utilisateurs : '+(r.error||'erreur'),false);return;}
    const idx=USER_GROUPS.findIndex(g=>g.group_id===r.group.group_id);
    if(idx>=0) USER_GROUPS[idx]=r.group; else USER_GROUPS.push(r.group);
    renderUserGroups();fillPolicyDynamic();renderPolicies();editUserGroup(r.group.group_id);
    showMsg('Groupe utilisateurs enregistré sans rechargement.');
});
document.getElementById('deleteUserGroup').addEventListener('click',async()=>{
    const id=userGroupForm.elements.group_id.value;
    if(!id||!confirm('Supprimer ce groupe utilisateur et ses règles associées ?'))return;
    const r=await post('api/admin_access.php',{action:'delete_user_group',group_id:id});
    if(!r.ok){showMsg('Suppression impossible : '+(r.error||'erreur'),false);return;}
    USER_GROUPS=USER_GROUPS.filter(g=>g.group_id!==id);
    ACCESS_POLICIES=ACCESS_POLICIES.filter(p=>!(p.subject_type==='user_group'&&p.subject_id===id));
    renderUserGroups();fillPolicyDynamic();renderPolicies();resetUserGroup();resetPolicy();
    showMsg('Groupe utilisateurs supprimé.');
});

// Rights / policies
const policyForm=document.getElementById('policyForm'),policyList=document.getElementById('policyList');
const subjectGroupSelect=policyForm.elements.subject_group_id,subjectUserSelect=policyForm.elements.subject_user_id;
const policySearch=document.getElementById('policySearch');
const policySelectAllPermissions=document.getElementById('policySelectAllPermissions');
function subjectLabel(p){if(p.subject_type==='user')return p.subject_id;const g=byId(USER_GROUPS,'group_id',p.subject_id);return g?g.name:p.subject_id;}
function scopeLabel(p){if(p.all_pcs)return 'Tous les PC';const parts=[];(p.pc_group_ids||[]).forEach(id=>{const g=byId(PC_GROUPS,'group_id',id);parts.push(g?g.name:id);});(p.agent_ids||[]).forEach(id=>{const d=byId(DEVICE_DATA,'agent_id',id);parts.push(d?d.hostname:id);});return parts.join(', ')||'Aucun périmètre';}
function fillPolicyDynamic(){
    subjectGroupSelect.innerHTML=USER_GROUPS.length?USER_GROUPS.map(g=>`<option value="${htmlEsc(g.group_id)}">${htmlEsc(g.name)}</option>`).join(''):'<option value="">Aucun groupe</option>';
    document.getElementById('policyPcGroups').innerHTML=PC_GROUPS.length?PC_GROUPS.map(g=>`<label><input type="checkbox" name="pc_group_ids[]" value="${htmlEsc(g.group_id)}"><span><strong>${htmlEsc(g.name)}</strong><small>${(g.agent_ids||[]).length} PC</small></span></label>`).join(''):'<span class="dmd-agent-muted">Aucun groupe de PC.</span>';
}
function syncSubjectType(){const t=policyForm.elements.subject_type.value;document.querySelector('.policy-subject-group').hidden=t!=='user_group';document.querySelector('.policy-subject-user').hidden=t!=='user';}
function syncScopeVisual(){
    const all=!!policyForm.elements.all_pcs.checked;
    const groups=[...policyForm.querySelectorAll('input[name="pc_group_ids[]"]')].some(i=>i.checked);
    const devices=[...policyForm.querySelectorAll('input[name="policy_agent_ids[]"]')].some(i=>i.checked);
    const allCard=document.querySelector('.all-pcs-choice');
    if(allCard){allCard.classList.toggle('selected',all);const st=allCard.querySelector('.choice-state');if(st)st.textContent=all?'✓':'○';}
    document.querySelectorAll('[data-scope-focus]').forEach(b=>{
        const on=b.dataset.scopeFocus==='groups'?groups:devices;
        b.classList.toggle('selected',on&&!all);
        const st=b.querySelector('.choice-state');if(st)st.textContent=on&&!all?'✓':'○';
    });
    document.querySelectorAll('[data-scope-panel]').forEach(p=>p.classList.toggle('disabled',all));
}
function syncPermissionMaster(){
    if(!policySelectAllPermissions)return;
    const items=[...policyForm.querySelectorAll('input[name="permissions[]"]')];
    const checked=items.filter(i=>i.checked).length;
    policySelectAllPermissions.checked=items.length>0&&checked===items.length;
    policySelectAllPermissions.indeterminate=checked>0&&checked<items.length;
}
function resetPolicy(){
    policyForm.reset();policyForm.elements.policy_id.value='';
    document.getElementById('policyEditorTitle').textContent='Nouvelle règle';
    document.getElementById('deletePolicy').hidden=true;
    policyList.querySelectorAll('[data-pol]').forEach(b=>b.classList.remove('active'));
    syncSubjectType();syncScopeVisual();syncPermissionMaster();
}
function editPolicy(id){
    const p=byId(ACCESS_POLICIES,'policy_id',id);if(!p)return;
    resetPolicy();policyForm.elements.policy_id.value=p.policy_id;policyForm.elements.subject_type.value=p.subject_type||'user_group';syncSubjectType();
    if(p.subject_type==='user')subjectUserSelect.value=p.subject_id;else subjectGroupSelect.value=p.subject_id;
    policyForm.elements.all_pcs.checked=!!p.all_pcs;
    const pgs=new Set(p.pc_group_ids||[]),ags=new Set(p.agent_ids||[]),perms=new Set(p.permissions||[]);
    policyForm.querySelectorAll('input[name="pc_group_ids[]"]').forEach(i=>i.checked=pgs.has(i.value));
    policyForm.querySelectorAll('input[name="policy_agent_ids[]"]').forEach(i=>i.checked=ags.has(i.value));
    policyForm.querySelectorAll('input[name="permissions[]"]').forEach(i=>i.checked=perms.has(i.value));
    document.getElementById('policyEditorTitle').textContent=subjectLabel(p);
    document.getElementById('deletePolicy').hidden=false;
    policyList.querySelectorAll('[data-pol]').forEach(b=>b.classList.toggle('active',b.dataset.pol===String(id)));
    syncScopeVisual();syncPermissionMaster();
}
function renderPolicies(){
    const q=(policySearch?.value||'').trim().toLowerCase();
    const rows=ACCESS_POLICIES.filter(p=>!q||(`${subjectLabel(p)} ${scopeLabel(p)} ${(p.permissions||[]).join(' ')}`).toLowerCase().includes(q));
    policyList.innerHTML=rows.length?rows.map(p=>`<button type="button" class="dmd-agent-admin-list-item policy" data-pol="${htmlEsc(p.policy_id)}"><span class="dmd-rights-policy-icon">${p.subject_type==='user'?'◉':'♟'}</span><span class="dmd-rights-policy-copy"><strong>${htmlEsc(subjectLabel(p))}</strong><small>${htmlEsc(scopeLabel(p))}</small></span><span class="dmd-rights-policy-meta"><span class="dmd-rights-policy-count">${(p.permissions||[]).length} droits</span><b class="dmd-rights-policy-arrow">›</b></span></button>`).join(''):'<div class="dmd-rights-empty">'+(ACCESS_POLICIES.length?'Aucune règle ne correspond à la recherche.':'Aucune règle : hors Superadmin, aucun droit RemoteAgent n’est accordé.')+'</div>';
    policyList.querySelectorAll('[data-pol]').forEach(b=>b.addEventListener('click',()=>editPolicy(b.dataset.pol)));
}
fillPolicyDynamic();renderPolicies();syncSubjectType();syncScopeVisual();syncPermissionMaster();
policyForm.elements.subject_type.addEventListener('change',syncSubjectType);
document.getElementById('newPolicy').addEventListener('click',resetPolicy);
document.getElementById('resetPolicy')?.addEventListener('click',resetPolicy);
policySearch?.addEventListener('input',renderPolicies);
policyForm.elements.all_pcs.addEventListener('change',()=>{
    if(policyForm.elements.all_pcs.checked){
        policyForm.querySelectorAll('input[name="pc_group_ids[]"],input[name="policy_agent_ids[]"]').forEach(i=>i.checked=false);
    }
    syncScopeVisual();
});
policyForm.addEventListener('change',e=>{
    if(e.target.matches('input[name="pc_group_ids[]"],input[name="policy_agent_ids[]"]')){
        if(e.target.checked)policyForm.elements.all_pcs.checked=false;
        syncScopeVisual();
    }
    if(e.target.matches('input[name="permissions[]"]'))syncPermissionMaster();
});
document.querySelectorAll('[data-scope-focus]').forEach(b=>b.addEventListener('click',()=>{
    policyForm.elements.all_pcs.checked=false;syncScopeVisual();
    const panel=document.querySelector(`[data-scope-panel="${b.dataset.scopeFocus}"]`);
    if(panel){panel.classList.add('focused');panel.scrollIntoView({behavior:'smooth',block:'nearest'});setTimeout(()=>panel.classList.remove('focused'),900);}
}));
policySelectAllPermissions?.addEventListener('change',()=>{
    policyForm.querySelectorAll('input[name="permissions[]"]').forEach(i=>i.checked=policySelectAllPermissions.checked);
    syncPermissionMaster();
});
policyForm.addEventListener('submit',async e=>{
    e.preventDefault();
    const fd=new FormData(policyForm),type=fd.get('subject_type');
    const subject=type==='user'?fd.get('subject_user_id'):fd.get('subject_group_id');
    const r=await post('api/admin_access.php',{action:'save_policy',policy_id:fd.get('policy_id'),subject_type:type,subject_id:subject,all_pcs:fd.get('all_pcs')==='1',pc_group_ids:fd.getAll('pc_group_ids[]'),agent_ids:fd.getAll('policy_agent_ids[]'),permissions:fd.getAll('permissions[]')});
    if(!r.ok){showMsg('Règle refusée : '+(r.error||'erreur'),false);return;}
    const idx=ACCESS_POLICIES.findIndex(p=>p.policy_id===r.policy.policy_id);
    if(idx>=0) ACCESS_POLICIES[idx]=r.policy; else ACCESS_POLICIES.push(r.policy);
    renderPolicies();editPolicy(r.policy.policy_id);
    showMsg('Droits enregistrés sans fermer l’administration.');
});
document.getElementById('deletePolicy').addEventListener('click',async()=>{
    const id=policyForm.elements.policy_id.value;
    if(!id||!confirm('Supprimer cette règle de droits ?'))return;
    const r=await post('api/admin_access.php',{action:'delete_policy',policy_id:id});
    if(!r.ok){showMsg('Suppression impossible : '+(r.error||'erreur'),false);return;}
    ACCESS_POLICIES=ACCESS_POLICIES.filter(p=>p.policy_id!==id);
    renderPolicies();resetPolicy();
    showMsg('Règle de droits supprimée.');
});


const search=document.getElementById('agentSearch'), filter=document.getElementById('agentFilter');
const osFilter=document.getElementById('agentOsFilter'), groupFilter=document.getElementById('agentGroupFilter');
function applyAgentFilter(){
    if(!search||!filter)return;
    const q=(search.value||'').trim().toLowerCase(),f=filter.value,os=osFilter?osFilter.value:'all',grp=groupFilter?groupFilter.value:'all';
    let visible=0;
    document.querySelectorAll('.dmd-agent-pc-compact').forEach(card=>{
        const hay=(card.dataset.search||((card.dataset.hostname||'')+' '+(card.dataset.ip||'')+' '+(card.dataset.agentId||''))).toLowerCase();
        const matchText=!q||hay.includes(q);
        const matchFilter=f==='all'||card.dataset.filter===f;
        const matchOs=os==='all'||card.dataset.os===os;
        const groups=' '+(card.dataset.groups||'')+' ';
        const matchGroup=grp==='all'||groups.includes(' '+grp+' ');
        const show=matchText&&matchFilter&&matchOs&&matchGroup;
        card.hidden=!show;if(show)visible++;
    });
    const empty=document.getElementById('agentNoResult');if(empty)empty.hidden=visible!==0;
}
if(search)search.addEventListener('input',applyAgentFilter);if(filter)filter.addEventListener('change',applyAgentFilter);if(osFilter)osFilter.addEventListener('change',applyAgentFilter);if(groupFilter)groupFilter.addEventListener('change',applyAgentFilter);

const globalAgentSearch=document.getElementById('agentGlobalSearch');
if(globalAgentSearch){
    globalAgentSearch.addEventListener('input',()=>{
        openWorkspaceFleet('fleet');
        if(search){search.value=globalAgentSearch.value;applyAgentFilter();}
    });
}
document.addEventListener('keydown',e=>{
    if((e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='k'&&globalAgentSearch){e.preventDefault();globalAgentSearch.focus();globalAgentSearch.select();}
});

let fleetPreviewAgentId='';
function fleetDeviceGroupLabel(agentId){
    const names=PC_GROUPS.filter(g=>Array.isArray(g.agent_ids)&&g.agent_ids.includes(agentId)).map(g=>String(g.name||'').trim()).filter(Boolean);
    return names.length?names.join(', '):'—';
}
function fleetDeviceOs(d){
    const inv=d&&d.last_inventory&&typeof d.last_inventory==='object'?d.last_inventory:{};
    const os=inv.os&&typeof inv.os==='object'?inv.os:{};
    const name=String(inv.os_name||os.name||d.platform||'—').trim();
    const version=String(inv.os_version||os.version||'').trim();
    return version&& !name.includes(version)?(name+' · '+version):name;
}
function fleetDeviceUser(d){
    const inv=d&&d.last_inventory&&typeof d.last_inventory==='object'?d.last_inventory:{};
    return String(inv.active_user||inv.logged_on_user||inv.current_user||inv.username||'—');
}
function selectFleetPreview(agentId){
    const d=DEVICE_DATA.find(x=>String(x.agent_id||'')===String(agentId||''));if(!d)return;
    fleetPreviewAgentId=String(d.agent_id||'');
    document.querySelectorAll('.dmd-r39-fleet-row').forEach(r=>r.classList.toggle('selected',String(r.dataset.agentId||'')===fleetPreviewAgentId));
    const lastTs=Number(d.last_seen_ts||0),online=d.status==='active'&&lastTs>0&&((Date.now()/1000)-lastTs)<90;
    const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value||'—';};
    set('fleetPreviewName',d.hostname||'PC');set('fleetPreviewHost',d.hostname||'PC');set('fleetPreviewOs',fleetDeviceOs(d));
    set('fleetPreviewUser',fleetDeviceUser(d));set('fleetPreviewGroup',fleetDeviceGroupLabel(d.agent_id));set('fleetPreviewIp',d.last_ip||'—');
    set('fleetPreviewSeen',formatDate(d.last_seen_at));set('fleetPreviewAgent',d.agent_version||'—');set('fleetPreviewEnroll',d.enrollment_id||'—');
    const st=document.getElementById('fleetPreviewStatus');if(st){st.textContent=online?'● En ligne':'● Hors ligne';st.className='dmd-r39-status '+(online?'online':'offline');}
}
document.querySelectorAll('.dmd-r39-fleet-row[data-device-preview]').forEach(row=>{
    row.addEventListener('click',e=>{if(e.target.closest('button,a,input,select'))return;selectFleetPreview(row.dataset.devicePreview);});
    row.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!e.target.closest('button')){e.preventDefault();selectFleetPreview(row.dataset.devicePreview);}});
});
const firstFleetRow=document.querySelector('.dmd-r39-fleet-row[data-device-preview]');if(firstFleetRow)selectFleetPreview(firstFleetRow.dataset.devicePreview);
function fleetPreviewOpen(feature=''){if(!fleetPreviewAgentId)return;openDevice(fleetPreviewAgentId);if(feature)setTimeout(()=>openFeatureByName(feature),0);}
document.getElementById('fleetPreviewRemote')?.addEventListener('click',()=>fleetPreviewOpen('control'));
document.getElementById('fleetPreviewDetails')?.addEventListener('click',()=>fleetPreviewOpen('machine'));
document.getElementById('fleetPreviewUpdate')?.addEventListener('click',()=>fleetPreviewOpen('updates'));
document.getElementById('fleetPreviewSoftware')?.addEventListener('click',()=>fleetPreviewOpen('software'));
document.getElementById('fleetPreviewUpdates')?.addEventListener('click',()=>fleetPreviewOpen('updates'));
document.getElementById('fleetPreviewBackup')?.addEventListener('click',()=>fleetPreviewOpen('backup'));

// Reprend exactement la couleur que le thème applique à « Parc informatique ».
const fleetAccentSource=document.querySelector('#workspace-fleet .dmd-agent-workspace-head h2');
const fleetGrid=document.getElementById('agentGrid');
if(fleetAccentSource&&fleetGrid){
    const themedAccent=getComputedStyle(fleetAccentSource).color;
    if(themedAccent){
        fleetGrid.style.setProperty('--dmd-agent-card-accent',themedAccent);
        fleetGrid.querySelectorAll('.dmd-agent-pc-display-name').forEach(el=>el.style.setProperty('color',themedAccent,'important'));
        fleetGrid.querySelectorAll('.dmd-agent-pc-ip').forEach(el=>el.style.setProperty('color',themedAccent,'important'));
    }
}

const modal=document.getElementById('deviceModal');let devicePreviousWorkspace={type:'fleet',name:'dashboard'};
function touchAgentInteractive(agentId){
    if(!agentId)return;
    post('api/admin_command.php',{action:'interactive_touch',agent_id:agentId}).catch(()=>{});
}
function startAgentInteractive(agentId){
    if(agentInteractiveTimer){clearInterval(agentInteractiveTimer);agentInteractiveTimer=null;}
    touchAgentInteractive(agentId);
    agentInteractiveTimer=setInterval(()=>{if(selectedDevice&&selectedDevice.agent_id===agentId)touchAgentInteractive(agentId);},15000);
}
function stopAgentInteractive(){if(agentInteractiveTimer){clearInterval(agentInteractiveTimer);agentInteractiveTimer=null;}}

function escText(v){return v===undefined||v===null||v===''?'—':String(v);}
function detail(label,value){return `<div><small>${htmlEsc(label)}</small><strong>${htmlEsc(escText(value))}</strong></div>`;}
function firstValue(...values){for(const v of values){if(v===undefined||v===null||v===''||(typeof v==='number'&&Number.isNaN(v)))continue;if(Array.isArray(v)&&v.length===0)continue;if(v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===0)continue;return v;}return null;}
function toNumber(v){const n=Number(v);return Number.isFinite(n)?n:null;}
function percentValue(v){const n=toNumber(v);if(n===null)return null;return Math.max(0,Math.min(100,n));}
function formatPercent(v){const n=percentValue(v);if(n===null)return '—';return (Math.round(n*10)/10).toLocaleString('fr-FR')+' %';}
function formatBytes(v){const n=toNumber(v);if(n===null||n<0)return '—';const u=['o','Ko','Mo','Go','To','Po'];let x=n,i=0;while(x>=1024&&i<u.length-1){x/=1024;i++;}return (i===0?Math.round(x):Math.round(x*10)/10).toLocaleString('fr-FR')+' '+u[i];}
function formatDuration(seconds){let n=toNumber(seconds);if(n===null||n<0)return '—';n=Math.floor(n);const d=Math.floor(n/86400);n%=86400;const h=Math.floor(n/3600);n%=3600;const m=Math.floor(n/60);const parts=[];if(d)parts.push(d+' j');if(h||d)parts.push(h+' h');parts.push(m+' min');return parts.join(' ');}
function obj(v){return v&&typeof v==='object'&&!Array.isArray(v)?v:{};}
function arrayValue(v){if(Array.isArray(v))return v;if(v&&typeof v==='object')return Object.entries(v).map(([k,x])=>typeof x==='object'?{name:k,...x}:{name:k,value:x});return [];}
function metricCard(label,value,sub,usage=null){const p=percentValue(usage);return `<div class="dmd-agent-health-item"><div class="dmd-agent-health-head"><span>${htmlEsc(label)}</span><strong>${htmlEsc(escText(value))}</strong></div><small>${htmlEsc(escText(sub))}</small>${p===null?'':`<div class="dmd-agent-progress"><i style="width:${p}%"></i></div>`}</div>`;}
function deviceCaps(d){return [...new Set([...(Array.isArray(d.capabilities)?d.capabilities:[]),...(Array.isArray(d.reported_capabilities)?d.reported_capabilities:[])])];}
function normalizeVolumes(raw){
    return arrayValue(raw).map((v,idx)=>{
        v=obj(v);const total=toNumber(firstValue(v.total_bytes,v.total,v.size_bytes,v.size)),free=toNumber(firstValue(v.free_bytes,v.free,v.available_bytes,v.available)),used0=toNumber(firstValue(v.used_bytes,v.used));
        const used=used0!==null?used0:(total!==null&&free!==null?Math.max(0,total-free):null);
        const usage=percentValue(firstValue(v.usage_percent,v.percent,v.used_percent,total&&used!==null?(used/total*100):null));
        return {name:firstValue(v.letter,v.mount,v.mountpoint,v.name,v.device,'Disque '+(idx+1)),fs:firstValue(v.filesystem,v.fs,v.type,''),total,used,free,usage};
    });
}
function normalizeSessions(raw){
    return arrayValue(raw).map(s=>{s=typeof s==='string'?{username:s}:obj(s);return {username:firstValue(s.username,s.user,s.name,'—'),state:firstValue(s.state,s.status,'—'),type:firstValue(s.type,s.session_type,s.kind,'—'),id:firstValue(s.id,s.session_id,'')};});
}
function normalizePorts(raw){
    return arrayValue(raw).map(p=>{if(typeof p==='number'||typeof p==='string')p={port:p};p=obj(p);return {port:firstValue(p.port,p.local_port,p.number,'—'),proto:String(firstValue(p.protocol,p.proto,p.transport,'TCP')).toUpperCase(),address:firstValue(p.address,p.local_address,p.bind,'—'),process:firstValue(p.process,p.process_name,p.executable,'—'),pid:firstValue(p.pid,p.process_id,''),state:firstValue(p.state,p.status,'LISTEN')};}).sort((a,b)=>(Number(a.port)||99999)-(Number(b.port)||99999));
}
function renderStorage(volumes){
    const el=document.getElementById('deviceStorage');
    if(!volumes.length){el.innerHTML='<div class="dmd-agent-data-empty">Donnée non remontée par l’Agent actuel.</div>';return;}
    el.innerHTML=volumes.map(v=>`<div class="dmd-agent-storage-item"><div><strong>${htmlEsc(v.name)}</strong><small>${htmlEsc(v.fs||'Volume')}</small></div><div class="dmd-agent-storage-value"><strong>${htmlEsc(formatPercent(v.usage))}</strong><small>${htmlEsc(v.used!==null&&v.total!==null?formatBytes(v.used)+' / '+formatBytes(v.total):formatBytes(v.total))}</small></div><div class="dmd-agent-progress"><i style="width:${v.usage===null?0:v.usage}%"></i></div></div>`).join('');
}
function renderSessions(sessions,activeUser){
    const el=document.getElementById('deviceSessions');
    if(!sessions.length&&activeUser){sessions=[{username:activeUser,state:'active',type:'—',id:''}];}
    if(!sessions.length){el.innerHTML='<div class="dmd-agent-data-empty">Aucune session remontée pour le moment.</div>';return;}
    el.innerHTML=sessions.map(s=>`<div class="dmd-agent-session-item"><span class="dmd-agent-live-dot ${String(s.state).toLowerCase().includes('active')?'online':''}"></span><div><strong>${htmlEsc(s.username)}</strong><small>${htmlEsc(s.type)}${s.id?' · #'+htmlEsc(s.id):''}</small></div><span>${htmlEsc(s.state)}</span></div>`).join('');
}
function renderPorts(ports){
    const el=document.getElementById('devicePorts');document.getElementById('devicePortsCount').textContent=ports.length;
    if(!ports.length){el.innerHTML='<div class="dmd-agent-data-empty">Aucun inventaire de ports remonté. DMD-Agent le fournira dans la prochaine version.</div>';return;}
    el.innerHTML=`<div class="dmd-agent-port-head"><span>Port</span><span>Proto</span><span>Adresse</span><span>Processus</span></div>`+ports.map(p=>`<div class="dmd-agent-port-row"><strong>${htmlEsc(p.port)}</strong><span>${htmlEsc(p.proto)}</span><span>${htmlEsc(p.address)}</span><span>${htmlEsc(p.process)}${p.pid?' <small>PID '+htmlEsc(p.pid)+'</small>':''}</span></div>`).join('');
}

function setTilePreview(name,main,sub=''){
    const a=document.querySelector('[data-tile-main="'+name+'"]');
    const b=document.querySelector('[data-tile-sub="'+name+'"]');
    if(a&&main!==undefined&&main!==null)a.textContent=String(main);
    if(b&&sub!==undefined&&sub!==null&&sub!=='')b.textContent=String(sub);
}
function friendlyOsName(name,version){
    const raw=[name,version].filter(Boolean).join(' ').replace(/\s+/g,' ').trim();
    if(/windows\s+server\s+2025/i.test(raw))return 'Windows Server 2025';
    if(/windows\s+server\s+2022/i.test(raw))return 'Windows Server 2022';
    if(/windows\s+server\s+2019/i.test(raw))return 'Windows Server 2019';
    if(/windows\s+11/i.test(raw)){
        const edition=/professionnel|professional|\bpro\b/i.test(raw)?' Pro':'';
        return 'Windows 11'+edition;
    }
    if(/windows\s+10/i.test(raw)){
        const edition=/professionnel|professional|\bpro\b/i.test(raw)?' Pro':'';
        return 'Windows 10'+edition;
    }
    return name||version||'Système inconnu';
}
async function loadLauncherLiveSummaries(agentId){
    if(!selectedDevice||selectedDevice.agent_id!==agentId)return;
    const caps=deviceCaps(selectedDevice);
    const jobs=[];
    if(caps.includes('system.processes'))jobs.push(
        runDeviceAdminCommand('processes.list',{offset:0,limit:1})
            .then(r=>setTilePreview('processes',(Number(r&&r.total)||((r&&r.processes)||[]).length)+' processus','Applications et processus actifs'))
            .catch(()=>setTilePreview('processes','À vérifier','Cliquer pour actualiser'))
    );
    if(caps.includes('system.services'))jobs.push(
        runDeviceAdminCommand('services.list',{offset:0,limit:1})
            .then(r=>setTilePreview('services',(Number(r&&r.total)||((r&&r.services)||[]).length)+' services','Services Windows'))
            .catch(()=>setTilePreview('services','À vérifier','Cliquer pour actualiser'))
    );
    if(caps.includes('software.list')||caps.includes('software.uninstall'))jobs.push(
        runDeviceAdminCommand('software.list',{offset:0,limit:1,query:''})
            .then(r=>setTilePreview('software',(Number(r&&r.total)||((r&&r.software)||[]).length)+' logiciels','Installés sur le PC'))
            .catch(()=>setTilePreview('software','À vérifier','Cliquer pour actualiser'))
    );
    if(caps.includes('system.removable'))jobs.push(
        runDeviceAdminCommand('devices.removable.list',{})
            .then(r=>{const v=Array.isArray(r&&r.volumes)?r.volumes:[],u=Array.isArray(r&&r.usb_devices)?r.usb_devices:[];{const n=v.length+u.length;setTilePreview('usb',n? n+' périphérique'+(n>1?'s':'') : 'Aucun périphérique','USB / lecteurs amovibles');}})
            .catch(()=>setTilePreview('usb','À vérifier','Cliquer pour analyser'))
    );
    if(caps.includes('system.networkpaths'))jobs.push(
        runDeviceAdminCommand('network.paths.list',{})
            .then(r=>{let p=r&&r.paths;if(p&&!Array.isArray(p)&&typeof p==='object')p=Object.values(p);if(!Array.isArray(p))p=[];setTilePreview('network-paths',p.length? p.length+' lecteur'+(p.length>1?'s':'')+' mappé'+(p.length>1?'s':'') : 'Aucun lecteur','Chemins SMB');})
            .catch(()=>setTilePreview('network-paths','À vérifier','Cliquer pour actualiser'))
    );
    await Promise.allSettled(jobs);
}

function openDevice(agentId){
    const d=DEVICE_DATA.find(x=>x.agent_id===agentId);if(!d)return;
    if(!['device','device-feature','terminal','software'].includes(workspaceState.type))devicePreviousWorkspace={...workspaceState};
    selectedDevice=d;
    const lastTs=Number(d.last_seen_ts||0),online=d.status==='active'&&lastTs>0&&((Date.now()/1000)-lastTs)<90;
    document.getElementById('deviceModalTitle').textContent=d.hostname||'PC';
    document.getElementById('deviceModalSub').textContent=(d.platform||'')+(d.arch?' · '+d.arch:'')+(d.agent_version?' · Agent '+d.agent_version:'');
    document.getElementById('deviceModalState').textContent=d.status==='revoked'?'Révoqué':(online?'En ligne':'Hors ligne');
    document.getElementById('deviceModalDot').className='dmd-agent-live-dot '+(online?'online':'');
    const inv=obj(d.last_inventory),hw=obj(d.hardware),tel=obj(firstValue(d.telemetry,d.last_telemetry,inv.telemetry,{}));
    const cpuRaw=firstValue(tel.cpu,inv.cpu,hw.cpu,{}),cpu=typeof cpuRaw==='string'?{model:cpuRaw}:obj(cpuRaw);
    const mem=obj(firstValue(tel.memory,tel.ram,inv.memory,inv.ram,{}));
    const totalMem=toNumber(firstValue(mem.total_bytes,mem.total,inv.memory_total_bytes,inv.ram_total_bytes));
    const freeMem=toNumber(firstValue(mem.free_bytes,mem.free,mem.available_bytes,mem.available,inv.memory_free_bytes));
    const usedMem0=toNumber(firstValue(mem.used_bytes,mem.used,inv.memory_used_bytes));
    const usedMem=usedMem0!==null?usedMem0:(totalMem!==null&&freeMem!==null?Math.max(0,totalMem-freeMem):null);
    const memUsage=percentValue(firstValue(mem.usage_percent,mem.percent,mem.used_percent,totalMem&&usedMem!==null?(usedMem/totalMem*100):null));
    const cpuUsage=percentValue(firstValue(cpu.usage_percent,cpu.usage,cpu.percent,tel.cpu_usage_percent,inv.cpu_usage_percent));
    const cpuModel=firstValue(cpu.model,cpu.name,cpu.brand,inv.cpu_model,hw.cpu_model);
    const cores=firstValue(cpu.cores,inv.cpu_cores,hw.cpu_cores),threads=firstValue(cpu.threads,inv.cpu_threads,hw.cpu_threads);
    const cpuShape=(cores||threads)?[cores?cores+' cœurs':null,threads?threads+' threads':null].filter(Boolean).join(' / '):'—';
    const uptime=firstValue(tel.uptime_seconds,inv.uptime_seconds,d.uptime_seconds);
    const sessions=normalizeSessions(firstValue(tel.sessions,inv.sessions,d.sessions,[]));
    const activeSession=firstValue(tel.active_session,inv.active_session,sessions.find(x=>String(x.state).toLowerCase().includes('active'))?.username,inv.logged_on_user,inv.username,inv.user,hw.username);
    const volumeRaw=firstValue(tel.volumes,tel.disks,inv.volumes,inv.disks,d.volumes,[]);
    const portRaw=firstValue(tel.open_ports,inv.open_ports,d.open_ports,[]);
    const hasTelemetry=cpuUsage!==null||memUsage!==null||uptime!==null||sessions.length||arrayValue(volumeRaw).length||arrayValue(portRaw).length;
    document.getElementById('deviceHealth').innerHTML=[
        metricCard('CPU',formatPercent(cpuUsage),cpuModel||cpuShape,cpuUsage),
        metricCard('RAM',formatPercent(memUsage),totalMem!==null?formatBytes(usedMem)+' / '+formatBytes(totalMem):'Capacité non remontée',memUsage),
        metricCard('Uptime',formatDuration(uptime),firstValue(inv.last_boot_at,tel.last_boot_at)?'Démarré '+formatDate(firstValue(inv.last_boot_at,tel.last_boot_at)):'Temps depuis le dernier démarrage'),
        metricCard('Télémétrie',hasTelemetry?'Disponible':'Partielle',online?'Agent joignable':'Dernières données reçues')
    ].join('');
    const ts=document.getElementById('deviceTelemetryState');ts.textContent=hasTelemetry?'Télémétrie disponible':'Inventaire Agent partiel';ts.classList.toggle('ok',hasTelemetry);
    renderStorage(normalizeVolumes(volumeRaw));
    renderSessions(sessions,activeSession);
    renderPorts(normalizePorts(portRaw));

    const net=obj(firstValue(tel.network,inv.network,d.network,{}));
    const activeNic=obj(firstValue(net.active_interface,net.primary,inv.active_interface,{}));
    const speed=firstValue(activeNic.speed_mbps,net.speed_mbps,inv.link_speed_mbps);
    document.getElementById('deviceNetwork').innerHTML=[
        detail('IP vue par DoMyDesk',d.last_ip),
        detail('Interface',firstValue(activeNic.name,net.interface,inv.network_interface)),
        detail('MAC',firstValue(activeNic.mac,net.mac,inv.mac_address,inv.mac)),
        detail('Passerelle',firstValue(activeNic.gateway,net.gateway,inv.gateway)),
        detail('Vitesse lien',speed?speed+' Mbps':'—'),
        detail('DNS',Array.isArray(net.dns)?net.dns.join(', '):firstValue(net.dns,inv.dns))
    ].join('');

    const invOsObj=obj(inv.os);
    const osName=firstValue(inv.os_name,invOsObj.name,typeof inv.os==='string'?inv.os:null,hw.os_name,d.platform);
    const osVersion=firstValue(inv.os_version,invOsObj.version,inv.version,hw.os_version);
    const domain=firstValue(inv.domain,inv.workgroup,hw.domain,hw.workgroup);
    const gpuRaw=firstValue(tel.gpu,inv.gpu,hw.gpu),gpu=typeof gpuRaw==='string'?gpuRaw:(Array.isArray(gpuRaw)?gpuRaw.map(x=>typeof x==='string'?x:firstValue(x.name,x.model)).filter(Boolean).join(', '):firstValue(obj(gpuRaw).name,obj(gpuRaw).model));
    const battery=obj(firstValue(tel.battery,inv.battery,{}));const batteryPct=firstValue(battery.percent,battery.charge_percent);
    document.getElementById('deviceGeneral').innerHTML=[
        detail('Nom du PC',d.hostname),
        detail('Système',[osName,osVersion].filter(Boolean).join(' ')||((d.platform||'—')+(d.arch?' / '+d.arch:''))),
        detail('Architecture',d.arch),
        detail('CPU',cpuModel),
        detail('Cœurs / threads',cpuShape),
        detail('RAM installée',formatBytes(totalMem)),
        detail('GPU',gpu),
        detail('Domaine / Workgroup',domain),
        detail('UUID matériel',firstValue(hw.system_uuid,inv.system_uuid)),
        detail('Fabricant',firstValue(hw.manufacturer,inv.manufacturer)),
        detail('Modèle',firstValue(hw.model,inv.model)),
        detail('Batterie',batteryPct!==null&&batteryPct!==undefined?formatPercent(batteryPct):'—'),
        detail('Version Agent',d.agent_version),
        detail('Dernier contact',formatDate(d.last_seen_at))
    ].join('');
    const groups=PC_GROUPS.filter(g=>(g.agent_ids||[]).includes(d.agent_id));
    document.getElementById('devicePcGroups').innerHTML=groups.length?groups.map(g=>`<span>${htmlEsc(g.name)}</span>`).join(''):'<span>Aucun groupe attribué</span>';

    document.getElementById('deviceSecurity').innerHTML=[
        detail('Agent ID',d.agent_id),detail('Instance DoMyDesk',d.instance_id),detail('Empreinte PC',d.device_key_fingerprint),detail('Enrôlement',d.enrollment_id),
        detail('État certificat',d.status==='active'?'Valide':d.status),detail('Protocole',d.certificate&&d.certificate.payload?d.certificate.payload.protocol_version:'1'),detail('Créé le',formatDate(d.created_at))
    ].join('');
    const caps=deviceCaps(d);document.getElementById('deviceCaps').innerHTML=caps.length?caps.map(c=>`<span>${htmlEsc(c)}</span>`).join(''):'<span>Aucune capability déclarée</span>';
    document.getElementById('deviceCapsCount').textContent=caps.length+' active'+(caps.length>1?'s':'');
    document.querySelectorAll('#deviceModal .dmd-agent-action-tile').forEach(btn=>{const cap=btn.dataset.cap;let enabled=caps.includes(cap);if(cap==='remote.files') enabled=enabled||caps.includes('filesystem.list')||caps.includes('filesystem.roots');if(cap==='software.list')enabled=enabled||caps.includes('software.uninstall');btn.disabled=!enabled;btn.title=enabled?'Capability autorisée : l’action sera disponible dans DMD-RemoteAgent':'Capability non autorisée pour cet agent';});document.querySelectorAll('[data-command-cap]').forEach(btn=>{const enabled=caps.includes(btn.dataset.commandCap||'');btn.disabled=!enabled;btn.title=enabled?'Disponible sur cet agent':'Capability non autorisée pour cet agent';});document.getElementById('deviceCommandState').textContent='Prêt';document.getElementById('deviceCommandState').classList.remove('ok');document.getElementById('deviceCommandResult').innerHTML='<div class="dmd-agent-data-empty">Choisis Processus, Services, Logiciels, Terminal, Redémarrer ou Éteindre.</div>';
    document.getElementById('deviceRevoke').hidden=d.status!=='active';
    const myDeskUpgrade=document.getElementById('deviceMyDeskUpgrade');
    myDeskUpgrade.hidden=d.status!=='active';
    myDeskUpgrade.textContent='Activer / mettre à niveau DMD-MyDesk';

    const volumesForTile=normalizeVolumes(volumeRaw),portsForTile=normalizePorts(portRaw);
    const primaryVolume=volumesForTile.find(v=>String(v.name||'').toUpperCase().startsWith('C'))||volumesForTile[0];
    setTilePreview('network',d.last_ip||'IP inconnue',speed?('Lien '+speed+' Mbps'):'Débit non remonté');
    setTilePreview('machine',d.hostname||'PC',friendlyOsName(osName,osVersion));
    setTilePreview('sessions',activeSession||'Aucune session',sessions.length?String(sessions.length)+' session'+(sessions.length>1?'s':''):'Aucune session active');
    setTilePreview('ports',portsForTile.length+' port'+(portsForTile.length>1?'s':''),portsForTile.length?'Ports à l’écoute':'Aucun port remonté');
    setTilePreview('storage',primaryVolume?(String(primaryVolume.name||'Volume')+' · '+formatPercent(primaryVolume.usage)):'Aucun volume',
        primaryVolume&&primaryVolume.used!==null&&primaryVolume.total!==null?(formatBytes(primaryVolume.used)+' / '+formatBytes(primaryVolume.total)):(volumesForTile.length+' volume'+(volumesForTile.length>1?'s':'')));
    setTilePreview('security',d.status==='active'?'Certificat valide':String(d.status||'État inconnu'),'Agent '+(d.agent_version||'—'));
    setTilePreview('processes','Chargement…','Applications et processus');
    setTilePreview('services','Chargement…','Services Windows');
    setTilePreview('software','Chargement…','Installés sur le PC');
    setTilePreview('usb','Chargement…','USB / lecteurs amovibles');
    setTilePreview('network-paths','Chargement…','Chemins SMB');
    setTilePreview('backup','Fichiers','Copie incrémentale · logs locaux');
    setTilePreview('network-scan','Scan LAN','IP · MAC · hostname · ports');

    startAgentInteractive(d.agent_id);
    setTimeout(()=>loadLauncherLiveSummaries(d.agent_id),0);
    resetInlineMaintenanceViews();hideToolPanels();hideWorkspacePanes();
    if(workspaceToolHost&&modal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(modal);
    modal.hidden=false;
    if(workspaceTools)workspaceTools.hidden=false;
    workspaceState={type:'device',name:d.agent_id};
    setWorkspaceNavActive('fleet');
    document.body.classList.remove('dmd-agent-modal-open');
}
async function runAdminCommandForAgent(agentId,operation,params={},options={}){
    agentId=String(agentId||'').trim();
    if(!agentId)throw new Error('Aucun PC sélectionné.');
    const showState=options.showState!==false && selectedDevice && String(selectedDevice.agent_id||'')===agentId;
    const state=showState?document.getElementById('deviceCommandState'):null;
    if(state){state.textContent='Envoi…';state.classList.remove('ok');}
    const queued=await post('api/admin_command.php',{action:'queue',agent_id:agentId,operation,params});
    if(!queued.ok)throw new Error(queued.error||'Commande refusée.');
    const id=queued.command&&queued.command.command_id;
    if(!id)throw new Error('ID de commande absent.');
    const started=Date.now();
    let waitLimitMs=90000;
    const opName=String(operation||'');
    if(opName.startsWith('software.'))waitLimitMs=35*60*1000;
    if(opName==='windows_update.scan')waitLimitMs=30000;
    if(opName==='windows_update.history')waitLimitMs=120000;
    if(opName==='network.ports.list'||opName==='firewall.list')waitLimitMs=30000;
    if(opName==='windows_update.install')waitLimitMs=50*60*1000;
    if(opName==='storage.format')waitLimitMs=6*60*1000;
    if(opName==='security.defender.action')waitLimitMs=50*60*1000;
    if(opName.startsWith('backup.')||opName==='filesystem.roots'||opName==='filesystem.list')waitLimitMs=120000;
    if(opName==='network.adapters.list'||opName==='network.localnets.list'||opName==='network.scan.start'||opName==='network.scan.status')waitLimitMs=120000;
    if(Number(options.waitLimitMs)>0)waitLimitMs=Math.max(1000,Number(options.waitLimitMs));
    while(Date.now()-started<waitLimitMs){
        await new Promise(r=>setTimeout(r,150));
        const r=await post('api/admin_command.php',{action:'status',agent_id:agentId,command_id:id});
        if(!r.ok)throw new Error(r.error||'Statut commande indisponible.');
        const c=r.command||{};
        if(state)state.textContent=c.status||'En attente…';
        if(['completed','failed','expired','cancelled'].includes(String(c.status||''))){
            if(c.status!=='completed')throw new Error(c.error||('Commande '+c.status));
            if(state){state.textContent='Terminé';state.classList.add('ok');}
            return c.result;
        }
    }
    throw new Error('Délai de réponse DMD-Agent dépassé.');
}
async function runDeviceAdminCommand(operation,params={}){
    if(!selectedDevice)throw new Error('Aucun PC sélectionné.');
    return runAdminCommandForAgent(selectedDevice.agent_id,operation,params,{showState:true});
}

function fmtAdminBytes(v){let n=Number(v||0);if(!Number.isFinite(n)||n<=0)return '—';const u=['o','Ko','Mo','Go','To'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++;}return (n>=10||i===0?n.toFixed(0):n.toFixed(1))+' '+u[i];}
function renderAdminProcesses(result){
    const box=document.getElementById('deviceCommandResult');if(result&&result.truncated){box.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(result.message||'Résultat processus trop volumineux.')+'</div>';return;}const rows=Array.isArray(result&&result.processes)?result.processes:[];
    if(!rows.length){box.innerHTML='<div class="dmd-agent-data-empty">Aucun processus retourné.</div>';return;}
    const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||25),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
    const nav='<div class="dmd-agent-command-meta"><span>'+htmlEsc((offset+1)+'-'+(offset+rows.length)+' / '+total+' processus')+'</span><span class="dmd-agent-command-actions">'+(offset>0?'<button type="button" class="dmd-agent-mini-btn" data-admin-process-offset="'+prev+'">‹ Précédent</button>':'')+(hasMore?'<button type="button" class="dmd-agent-mini-btn" data-admin-process-offset="'+next+'">Suivant ›</button>':'')+'</span></div>';
    box.innerHTML=nav+'<div class="dmd-agent-command-list">'+rows.map(p=>'<div class="dmd-agent-command-row"><div><strong>'+htmlEsc(p.name||'Processus')+'</strong><small>PID '+htmlEsc(p.pid||'—')+(p.user?' · '+htmlEsc(p.user):'')+'</small><small title="'+htmlEsc(p.path||'')+'">'+htmlEsc(p.path||'')+'</small></div><span>'+htmlEsc((p.cpu??0)+' %')+'</span><span>'+htmlEsc(fmtAdminBytes(p.memory_bytes))+'</span>'+(!p.protected?'<button type="button" class="dmd-agent-mini-btn danger" data-admin-kill="'+htmlEsc(p.pid)+'">Arrêter</button>':'<span class="dmd-agent-protected-pill">Protégé</span>')+'</div>').join('')+'</div>';
}
function adminServiceStatusLabel(v){const m={running:'En cours',stopped:'Arrêté',start_pending:'Démarrage…',stop_pending:'Arrêt…',continue_pending:'Reprise…',pause_pending:'Mise en pause…',paused:'En pause'};return m[String(v||'').toLowerCase()]||String(v||'—');}
function renderAdminServices(result){
    const box=document.getElementById('deviceCommandResult');if(result&&result.truncated){box.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(result.message||'Résultat services trop volumineux.')+'</div>';return;}const rows=Array.isArray(result&&result.services)?result.services:[];
    if(!rows.length){box.innerHTML='<div class="dmd-agent-data-empty">Aucun service retourné.</div>';return;}
    const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||40),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
    const nav='<div class="dmd-agent-command-meta"><span>'+htmlEsc((offset+1)+'-'+(offset+rows.length)+' / '+total+' services')+'</span><span class="dmd-agent-command-actions">'+(offset>0?'<button type="button" class="dmd-agent-mini-btn" data-admin-services-offset="'+prev+'">‹ Précédent</button>':'')+(hasMore?'<button type="button" class="dmd-agent-mini-btn" data-admin-services-offset="'+next+'">Suivant ›</button>':'')+'</span></div>';
    box.innerHTML=nav+'<div class="dmd-agent-command-list">'+rows.map(s=>{let controls='<span class="dmd-agent-protected-pill">Aucune action</span>';if(s.protected){controls='<span class="dmd-agent-protected-pill">Protégé</span>';}else{const a=[];if(s.can_start)a.push('<button type="button" class="dmd-agent-mini-btn" data-admin-service="'+htmlEsc(s.name)+'" data-admin-service-op="start">Démarrer</button>');if(s.can_stop)a.push('<button type="button" class="dmd-agent-mini-btn" data-admin-service="'+htmlEsc(s.name)+'" data-admin-service-op="stop">Arrêter</button>');if(s.can_restart)a.push('<button type="button" class="dmd-agent-mini-btn" data-admin-service="'+htmlEsc(s.name)+'" data-admin-service-op="restart">Redémarrer</button>');if(a.length)controls='<span class="dmd-agent-command-actions">'+a.join('')+'</span>';}return '<div class="dmd-agent-command-row service"><div><strong>'+htmlEsc(s.display_name||s.name||'Service')+'</strong><small>'+htmlEsc(s.name||'')+' · '+htmlEsc(s.start_mode||'—')+(s.pid?' · PID '+htmlEsc(s.pid):'')+'</small></div><span>'+htmlEsc(adminServiceStatusLabel(s.status))+'</span>'+controls+'</div>';}).join('')+'</div>';
}
async function loadAdminProcesses(offset=0){try{document.getElementById('deviceCommandResult').innerHTML='<div class="dmd-agent-data-empty">Chargement des processus…</div>';renderAdminProcesses(await runDeviceAdminCommand('processes.list',{offset:Number(offset)||0,limit:25}));}catch(e){document.getElementById('deviceCommandState').textContent='Erreur';showMsg(e.message||'Commande impossible.',false);}}
async function loadAdminServices(offset=0){try{document.getElementById('deviceCommandResult').innerHTML='<div class="dmd-agent-data-empty">Chargement des services…</div>';renderAdminServices(await runDeviceAdminCommand('services.list',{offset:Number(offset)||0,limit:40}));}catch(e){document.getElementById('deviceCommandState').textContent='Erreur';showMsg(e.message||'Commande impossible.',false);}}
const softwareModal=document.getElementById('softwareModal');
let softwarePageOffset=0;
function softwareSetState(text,ok=false){
    const el=document.getElementById('softwareCommandState');
    if(!el)return;
    el.textContent=text;
    el.classList.toggle('ok',!!ok);
}
function openSoftwareManager(){
    if(!selectedDevice||!softwareModal)return;
    if(deviceFeatureModal)deviceFeatureModal.hidden=true;if(modal)modal.hidden=true;
    hideWorkspacePanes();if(workspaceToolHost&&softwareModal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(softwareModal);if(workspaceTools)workspaceTools.hidden=false;workspaceState={type:'software',name:selectedDevice.agent_id};
    document.getElementById('softwareModalTitle').textContent='Logiciels — '+(selectedDevice.hostname||'PC');
    document.getElementById('softwareModalSub').textContent=(selectedDevice.last_ip||'IP inconnue')+' · DMD-Agent '+(selectedDevice.agent_version||'—');
    const caps=deviceCaps(selectedDevice);
    const canList=caps.includes('software.list')||caps.includes('software.uninstall');
    const canInstall=caps.includes('software.uninstall');
    const installBtn=document.getElementById('softwareInstallButton');
    const file=document.getElementById('softwarePackageFile');
    const args=document.getElementById('softwareInstallArguments');
    const refresh=document.getElementById('softwareRefresh');
    const search=document.getElementById('softwareSearch');
    if(installBtn)installBtn.disabled=!canInstall;
    if(file)file.disabled=!canInstall;
    if(args)args.disabled=!canInstall;
    if(refresh)refresh.disabled=!canList;
    if(search)search.disabled=!canList;
    softwareModal.hidden=false;
    document.body.classList.remove('dmd-agent-modal-open');
    softwarePageOffset=0;
    if(!canList){
        softwareSetState('Agent à mettre à jour');
        const list=document.getElementById('softwareList');
        const pager=document.getElementById('softwarePager');
        const count=document.getElementById('softwareListCount');
        if(list)list.innerHTML='<div class="dmd-agent-data-empty">Cet Agent ne possède pas encore les commandes Logiciels. Installe le binaire DMD-Agent Logiciels sur ce PC puis actualise.</div>';
        if(pager)pager.innerHTML='';
        if(count)count.textContent='0 logiciel';
        return;
    }
    softwareSetState(canInstall?'Prêt':'Consultation seule');
    loadAdminSoftware(0);
}
async function searchSoftwareWinget(){
    if(!selectedDevice)return;
    const input=document.getElementById('softwareWingetId'),query=String(input?.value||'').trim();
    const box=document.getElementById('softwareWingetResults');
    if(query.length<2){showMsg('Saisis au moins 2 caractères pour rechercher dans Winget.',false);return;}
    softwareSetState('Recherche Winget…');
    if(box)box.innerHTML='<div class="dmd-agent-data-empty">Recherche de « '+htmlEsc(query)+' »…</div>';
    try{
        const r=await runDeviceAdminCommand('software.winget.search',{query});
        const rows=Array.isArray(r&&r.matches)?r.matches:[];
        if(box)box.innerHTML=rows.length?rows.map(x=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(x.name||x.id||'Logiciel')+'</strong><small>'+htmlEsc(x.id||'')+' · '+htmlEsc(x.version||'—')+'</small></div><button type="button" class="dmd-agent-btn primary" data-winget-install-id="'+htmlEsc(x.id||'')+'">Installer</button></div>').join(''):'<div class="dmd-agent-data-empty">Aucun résultat Winget pour « '+htmlEsc(query)+' ».</div>';
        softwareSetState(rows.length+' résultat'+(rows.length>1?'s':''),true);
    }catch(err){
        if(box)box.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(err.message||'Recherche Winget impossible.')+'</div>';
        softwareSetState('Erreur');showMsg(err.message||'Recherche Winget impossible.',false);
    }
}

async function runSoftwareWinget(mode){
    if(!selectedDevice)return;
    const input=document.getElementById('softwareWingetId'),id=String(input?.value||'').trim();
    if(!id){showMsg('Indique le nom ou l’ID Winget.',false);return;}
    const uninstall=mode==='uninstall';
    if(!confirm((uninstall?'Désinstaller ':'Installer ')+id+' sur '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    softwareSetState(uninstall?'Désinstallation Winget…':'Installation Winget…');
    try{const r=await runDeviceAdminCommand(uninstall?'software.winget.uninstall':'software.winget.install',{id});softwareSetState('Terminé',true);showMsg((uninstall?'Désinstallation':'Installation')+' Winget terminée : '+id+'.');if(r&&r.stdout)console.log(r.stdout);await loadAdminSoftware(0);}catch(err){softwareSetState('Erreur');showMsg(err.message||'Commande Winget impossible.',false);}
}
function closeSoftwareManager(){
    if(!softwareModal)return;softwareModal.hidden=true;
    if(selectedDevice&&modal){if(workspaceToolHost&&modal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(modal);modal.hidden=false;if(workspaceTools)workspaceTools.hidden=false;workspaceState={type:'device',name:selectedDevice.agent_id};}
    else restoreDevicePreviousWorkspace();
    document.body.classList.remove('dmd-agent-modal-open');
}
function renderAdminSoftware(result){
    const box=document.getElementById('softwareList'),pager=document.getElementById('softwarePager'),count=document.getElementById('softwareListCount');
    const rows=Array.isArray(result&&result.software)?result.software:[];
    const total=Number(result&&result.total||rows.length),offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||40);
    softwarePageOffset=offset;
    if(count)count.textContent=total+' logiciel'+(total>1?'s':'');
    if(!rows.length){
        box.innerHTML='<div class="dmd-agent-data-empty">Aucun logiciel ne correspond à la recherche.</div>';
    }else{
        box.innerHTML=rows.map(x=>`<div class="dmd-agent-software-row">
            <div class="dmd-agent-software-main"><strong>${htmlEsc(x.name||'Logiciel')}</strong><small>${htmlEsc([x.version,x.publisher].filter(Boolean).join(' · ')||'—')}</small></div>
            <span class="dmd-agent-software-scope">${htmlEsc(x.scope==='user'?'Utilisateur':'Machine')}</span>
            ${x.protected?'<span class="dmd-agent-protected-pill">Protégé</span>':(x.can_uninstall?`<button type="button" class="dmd-agent-btn danger dmd-agent-software-uninstall" data-software-id="${htmlEsc(x.id)}" data-software-name="${htmlEsc(x.name||'Logiciel')}">Désinstaller</button>`:'<span class="dmd-agent-protected-pill">Non silencieux</span>')}
        </div>`).join('');
    }
    const prev=Math.max(0,offset-limit),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
    pager.innerHTML=(offset>0?`<button type="button" class="dmd-agent-btn" data-software-page="${prev}">‹ Précédent</button>`:'')+
        `<span>${total?Math.min(offset+1,total):0}–${Math.min(offset+rows.length,total)} / ${total}</span>`+
        (result&&result.has_more?`<button type="button" class="dmd-agent-btn" data-software-page="${next}">Suivant ›</button>`:'');
}
async function loadAdminSoftware(offset=0){
    if(!selectedDevice)return;
    const box=document.getElementById('softwareList');
    const query=(document.getElementById('softwareSearch')?.value||'').trim();
    if(box)box.innerHTML='<div class="dmd-agent-data-empty">Inventaire des logiciels en cours…</div>';
    softwareSetState('Inventaire…');
    try{
        const r=await runDeviceAdminCommand('software.list',{offset:Number(offset)||0,limit:40,query});
        renderAdminSoftware(r||{});
        softwareSetState('À jour',true);
    }catch(err){
        if(box)box.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(err.message||'Inventaire impossible.')+'</div>';
        softwareSetState('Erreur');
        showMsg(err.message||'Inventaire logiciels impossible.',false);
    }
}
async function installSelectedSoftware(){
    if(!selectedDevice)return;
    const fileEl=document.getElementById('softwarePackageFile'),argsEl=document.getElementById('softwareInstallArguments'),btn=document.getElementById('softwareInstallButton');
    const file=fileEl&&fileEl.files?fileEl.files[0]:null;
    if(!file){showMsg('Choisis un fichier MSI ou EXE.',false);return;}
    const ext=(file.name.split('.').pop()||'').toLowerCase();
    if(!['msi','exe'].includes(ext)){showMsg('Seuls les packages MSI et EXE sont acceptés.',false);return;}
    const args=(argsEl?.value||'').trim();
    if(!confirm('Installer '+file.name+' sur '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    btn.disabled=true;fileEl.disabled=true;if(argsEl)argsEl.disabled=true;
    softwareSetState('Envoi du package…');
    try{
        const form=new FormData();
        form.append('csrf_token',CSRF);
        form.append('package',file,file.name);
        const upload=await fetch('api/admin_software_upload.php',{method:'POST',headers:{'X-DMD-CSRF':CSRF},body:form,credentials:'same-origin'});
        let up={};try{up=await upload.json();}catch(e){up={ok:false,error:'Réponse upload invalide'};}
        if(!upload.ok||!up.ok)throw new Error(up.error||('Upload HTTP '+upload.status));
        softwareSetState('Installation…');
        const r=await runDeviceAdminCommand('software.install',{
            package_id:up.package.package_id,token:up.token,arguments:args,timeout_seconds:1200
        });
        const reboot=!!(r&&r.reboot_required);
        const auto=!!(r&&r.arguments_auto);
        softwareSetState(reboot?'Installé · redémarrage requis':'Installé',true);
        showMsg('Installation terminée'+(auto&&r.arguments?' · mode auto : '+r.arguments:'')+(reboot?' · redémarrage Windows requis.':'.'));
        fileEl.value='';if(argsEl)argsEl.value='';
        await new Promise(resolve=>setTimeout(resolve,1500));
        await loadAdminSoftware(0);
    }catch(err){
        const reason=err.message||'erreur';
        softwareSetState('Erreur · '+reason);
        showMsg('Installation impossible : '+reason,false);
    }finally{
        const caps=selectedDevice?deviceCaps(selectedDevice):[];
        const canInstall=caps.includes('software.uninstall');
        btn.disabled=!canInstall;fileEl.disabled=!canInstall;if(argsEl)argsEl.disabled=!canInstall;
    }
}

async function scanAdminSoftwareUpdates(){
    if(!selectedDevice)return;const out=document.getElementById('softwareUpdatesOutput');
    if(out)out.textContent='Recherche des mises à jour…';softwareSetState('Recherche mises à jour…');
    try{const r=await runDeviceAdminCommand('software.updates.scan',{include_unknown:true});const text=[r&&r.stdout,r&&r.stderr].filter(Boolean).join('\n').trim()||'Aucune mise à jour retournée par Winget.';if(out)out.textContent=text;softwareSetState('Recherche terminée',true);}
    catch(err){if(out)out.textContent=err.message||'Recherche impossible.';softwareSetState('Erreur');showMsg(err.message||'Recherche des mises à jour impossible.',false);}
}
async function applyAdminSoftwareUpdates(){
    if(!selectedDevice||!confirm('Installer toutes les mises à jour logicielles disponibles sur '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    const out=document.getElementById('softwareUpdatesOutput');if(out)out.textContent='Installation des mises à jour…';softwareSetState('Mises à jour…');
    try{const r=await runDeviceAdminCommand('software.updates.apply',{all:true});const text=[r&&r.stdout,r&&r.stderr].filter(Boolean).join('\n').trim()||'Mises à jour terminées.';if(out)out.textContent=text;softwareSetState('Mises à jour terminées',true);showMsg('Mises à jour logicielles terminées.');await loadAdminSoftware(0);}
    catch(err){if(out)out.textContent=err.message||'Mise à jour impossible.';softwareSetState('Erreur');showMsg(err.message||'Mise à jour des logiciels impossible.',false);}
}

const terminalModal=document.getElementById('terminalModal');
function openAdminTerminal(){
    if(!selectedDevice||!terminalModal)return;
    if(deviceFeatureModal)deviceFeatureModal.hidden=true;if(modal)modal.hidden=true;if(softwareModal)softwareModal.hidden=true;
    hideWorkspacePanes();if(workspaceToolHost&&terminalModal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(terminalModal);if(workspaceTools)workspaceTools.hidden=false;workspaceState={type:'terminal',name:selectedDevice.agent_id};
    const title=document.getElementById('terminalModalTitle');
    const sub=document.getElementById('terminalModalSub');
    const state=document.getElementById('terminalCommandState');
    const out=document.getElementById('deviceTerminalOutput');
    if(title) title.textContent='Terminal — '+(selectedDevice.hostname||'PC');
    if(sub) sub.textContent=(selectedDevice.last_ip||'IP inconnue')+' · DMD-Agent '+(selectedDevice.agent_version||'—');
    if(state){state.textContent='Prêt';state.classList.remove('ok');}
    if(out) out.textContent='DMD-Agent — terminal distant\nExécution avec les droits du service Windows SYSTEM.\n';
    terminalModal.hidden=false;
    document.body.classList.remove('dmd-agent-modal-open');
    const input=document.getElementById('deviceTerminalInput');
    if(input){input.value='';setTimeout(()=>input.focus(),0);}
}
function closeAdminTerminal(){
    if(!terminalModal)return;terminalModal.hidden=true;
    if(selectedDevice&&modal){if(workspaceToolHost&&modal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(modal);modal.hidden=false;if(workspaceTools)workspaceTools.hidden=false;workspaceState={type:'device',name:selectedDevice.agent_id};}
    else restoreDevicePreviousWorkspace();
    document.body.classList.remove('dmd-agent-modal-open');
}
async function runAdminTerminal(){
    const input=document.getElementById('deviceTerminalInput'),shellEl=document.getElementById('deviceTerminalShell'),out=document.getElementById('deviceTerminalOutput'),terminalState=document.getElementById('terminalCommandState');
    if(!input||!out)return;
    const command=input.value.trim();
    if(!command)return;
    const shell=shellEl?shellEl.value:'powershell';
    input.value='';
    input.disabled=true;
    const runBtn=document.getElementById('deviceTerminalRun');
    if(runBtn)runBtn.disabled=true;
    if(terminalState){terminalState.textContent='Exécution…';terminalState.classList.remove('ok');}
    out.textContent+='\n['+shell+'] > '+command+'\n';
    out.scrollTop=out.scrollHeight;
    try{
        const r=await runDeviceAdminCommand('system.terminal',{command,shell,timeout_seconds:45});
        if(r&&r.stdout)out.textContent+=r.stdout;
        if(r&&r.stderr)out.textContent+='\n[stderr]\n'+r.stderr;
        if(r&&r.timed_out)out.textContent+='\n[Délai d’exécution dépassé]\n';
        else if(r&&r.exit_code!=null&&Number(r.exit_code)!==0)out.textContent+='\n[Code retour '+r.exit_code+']\n';
        if(r&&r.truncated)out.textContent+='\n[Sortie tronquée]\n';
        if(terminalState){terminalState.textContent='Terminé';terminalState.classList.add('ok');}
    }catch(err){
        out.textContent+='ERREUR: '+(err.message||'Commande terminal impossible.')+'\n';
        if(terminalState){terminalState.textContent='Erreur';terminalState.classList.remove('ok');}
    }finally{
        input.disabled=false;
        if(runBtn)runBtn.disabled=false;
        input.focus();
        out.scrollTop=out.scrollHeight;
    }
}

const deviceFeatureModal=document.getElementById('deviceFeatureModal');
const deviceFeatureBody=document.getElementById('deviceFeatureBody');
const deviceFeatureTitle=document.getElementById('deviceFeatureTitle');
const deviceFeatureSub=document.getElementById('deviceFeatureSub');
const deviceFeatureState=document.getElementById('deviceFeatureState');
let activeDeviceFeature='';
let registryState={hive:'HKLM',path:''};

function featureSetState(text,ok=false){if(!deviceFeatureState)return;deviceFeatureState.textContent=text||'Prêt';deviceFeatureState.classList.toggle('ok',!!ok);}
function openDeviceFeature(title,html='',size='compact'){
    if(!selectedDevice||!deviceFeatureModal)return;
    deviceFeatureTitle.textContent=title;
    deviceFeatureSub.textContent=(selectedDevice.hostname||'PC')+(selectedDevice.last_ip?' · '+selectedDevice.last_ip:'');
    deviceFeatureBody.innerHTML=html;
    deviceFeatureModal.dataset.size=size;
    featureSetState('Prêt');
    if(modal)modal.hidden=true;
    if(terminalModal)terminalModal.hidden=true;
    if(softwareModal)softwareModal.hidden=true;
    hideWorkspacePanes();
    if(workspaceToolHost&&deviceFeatureModal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(deviceFeatureModal);
    deviceFeatureModal.hidden=false;if(workspaceTools)workspaceTools.hidden=false;
    workspaceState={type:'device-feature',name:activeDeviceFeature||title};
    document.body.classList.remove('dmd-agent-modal-open');
}
function closeDeviceFeature(){
    if(!deviceFeatureModal)return;
    deviceFeatureModal.hidden=true;activeDeviceFeature='';
    if(selectedDevice&&modal){if(workspaceToolHost&&modal.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(modal);modal.hidden=false;if(workspaceTools)workspaceTools.hidden=false;workspaceState={type:'device',name:selectedDevice.agent_id};}
    else restoreDevicePreviousWorkspace();
    document.body.classList.remove('dmd-agent-modal-open');
}
function featureCopy(title,id,extra='',size='compact'){
    activeDeviceFeature=id;
    const src=document.getElementById(id);
    const extraClass=src&&src.className?(' '+src.className):'';openDeviceFeature(title,extra+'<div class="dmd-agent-feature-copy'+extraClass+'">'+(src?src.innerHTML:'<div class="dmd-agent-data-empty">Aucune donnée.</div>')+'</div>',size);
}
function featureLoading(title,text='Chargement…',size='compact'){activeDeviceFeature='loading';openDeviceFeature(title,'<div class="dmd-agent-feature-loading">'+htmlEsc(text)+'</div>',size);featureSetState('Chargement…');}

function renderFeatureProcesses(result){
    const rows=Array.isArray(result&&result.processes)?result.processes:[];
    const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||25),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more);
    const prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
    const launcher='<form id="processStartForm" class="dmd-agent-admin-inline-form dmd-agent-process-start"><input name="path" required placeholder="C:\\Windows\\System32\\notepad.exe"><input name="arguments" placeholder="Arguments (optionnel)"><button class="dmd-agent-btn primary" type="submit">Lancer</button></form>';
    deviceFeatureBody.innerHTML=launcher+'<div class="dmd-agent-feature-toolbar"><strong>'+htmlEsc(total+' processus')+'</strong><div>'+(offset>0?'<button class="dmd-agent-btn" data-feature-process-offset="'+prev+'">‹ Précédent</button>':'')+(hasMore?'<button class="dmd-agent-btn" data-feature-process-offset="'+next+'">Suivant ›</button>':'')+'</div></div>'+(rows.length?'<div class="dmd-agent-feature-table"><div class="dmd-agent-feature-tr head"><span>Processus</span><span>PID</span><span>Utilisateur</span><span>CPU</span><span>RAM</span><span>Action</span></div>'+rows.map(p=>'<div class="dmd-agent-feature-tr"><span class="main"><strong>'+htmlEsc(p.name||'Processus')+'</strong><small title="'+htmlEsc(p.path||'')+'">'+htmlEsc(p.path||'')+'</small></span><span>'+htmlEsc(p.pid||'—')+'</span><span>'+htmlEsc(p.user||'—')+'</span><span>'+htmlEsc((p.cpu??0)+' %')+'</span><span>'+htmlEsc(fmtAdminBytes(p.memory_bytes))+'</span><span class="actions">'+(!p.protected?'<button type="button" class="dmd-agent-mini-btn" data-feature-restart-process="'+htmlEsc(p.pid)+'">Relancer</button> <button type="button" class="dmd-agent-mini-btn danger" data-feature-kill="'+htmlEsc(p.pid)+'">Arrêter</button>':'<span class="dmd-agent-protected-pill">Protégé</span>')+'</span></div>').join('')+'</div>':'<div class="dmd-agent-data-empty">Aucun processus retourné.</div>');
    featureSetState('À jour',true);
}
async function showFeatureProcesses(offset=0){featureLoading('Processus','Lecture des processus…','large');activeDeviceFeature='processes';try{renderFeatureProcesses(await runDeviceAdminCommand('processes.list',{offset:Number(offset)||0,limit:25}));}catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture impossible.')+'</div>';featureSetState('Erreur');}}

function renderFeatureServices(result){
    const rows=Array.isArray(result&&result.services)?result.services:[];
    const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||40),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more);
    const prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
    const modeValue=v=>{v=String(v||'').toLowerCase();if(v.includes('delay'))return 'delayed';if(v.includes('auto'))return 'auto';if(v.includes('disable'))return 'disabled';return 'manual';};
    deviceFeatureBody.innerHTML='<div class="dmd-agent-feature-toolbar"><strong>'+htmlEsc(total+' services')+'</strong><div>'+(offset>0?'<button class="dmd-agent-btn" data-feature-services-offset="'+prev+'">‹ Précédent</button>':'')+(hasMore?'<button class="dmd-agent-btn" data-feature-services-offset="'+next+'">Suivant ›</button>':'')+'</div></div>'+(rows.length?'<div class="dmd-agent-feature-table services"><div class="dmd-agent-feature-tr head"><span>Service</span><span>État</span><span>Démarrage</span><span>PID</span><span>Actions</span></div>'+rows.map(s=>{let a='<span class="dmd-agent-protected-pill">Aucune action</span>';let startup=htmlEsc(s.start_mode||'—');if(s.protected){a='<span class="dmd-agent-protected-pill">Protégé</span>';}else{const x=[];if(s.can_start)x.push('<button class="dmd-agent-mini-btn" data-feature-service="'+htmlEsc(s.name)+'" data-feature-service-op="start">Démarrer</button>');if(s.can_stop)x.push('<button class="dmd-agent-mini-btn danger" data-feature-service="'+htmlEsc(s.name)+'" data-feature-service-op="stop">Arrêter</button>');if(s.can_restart)x.push('<button class="dmd-agent-mini-btn" data-feature-service="'+htmlEsc(s.name)+'" data-feature-service-op="restart">Redémarrer</button>');a=(x.length?x.join(' '):'')+' <select class="dmd-agent-service-startmode" data-service-startmode="'+htmlEsc(s.name)+'"><option value="auto" '+(modeValue(s.start_mode)==='auto'?'selected':'')+'>Auto</option><option value="delayed" '+(modeValue(s.start_mode)==='delayed'?'selected':'')+'>Auto différé</option><option value="manual" '+(modeValue(s.start_mode)==='manual'?'selected':'')+'>Manuel</option><option value="disabled" '+(modeValue(s.start_mode)==='disabled'?'selected':'')+'>Désactivé</option></select>';startup=htmlEsc(s.start_mode||'—');}return '<div class="dmd-agent-feature-tr"><span class="main"><strong>'+htmlEsc(s.display_name||s.name||'Service')+'</strong><small>'+htmlEsc(s.name||'')+'</small></span><span>'+htmlEsc(adminServiceStatusLabel(s.status))+'</span><span>'+startup+'</span><span>'+htmlEsc(s.pid||'—')+'</span><span class="actions">'+a+'</span></div>';}).join('')+'</div>':'<div class="dmd-agent-data-empty">Aucun service retourné.</div>');
    featureSetState('À jour',true);
}
async function showFeatureServices(offset=0){featureLoading('Services','Lecture des services…','large');activeDeviceFeature='services';try{renderFeatureServices(await runDeviceAdminCommand('services.list',{offset:Number(offset)||0,limit:40}));}catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture impossible.')+'</div>';featureSetState('Erreur');}}

function dmdNextLocalTimeUnix(value){
    const m=/^(\d{2}):(\d{2})$/.exec(String(value||''));
    if(!m)return 0;
    const now=new Date(),target=new Date(now);
    target.setHours(Number(m[1]),Number(m[2]),0,0);
    if(target.getTime()<=now.getTime()+60000)target.setDate(target.getDate()+1);
    return Math.floor(target.getTime()/1000);
}
function dmdRebootControlsSync(prefix){
    const mode=document.getElementById(prefix+'Mode')?.value||'none';
    const count=document.getElementById(prefix+'CountdownWrap'),at=document.getElementById(prefix+'TimeWrap');
    if(count)count.hidden=mode!=='countdown';
    if(at)at.hidden=mode!=='at';
}
function dmdRebootPolicyFromControls(prefix,message){
    const mode=document.getElementById(prefix+'Mode')?.value||'none';
    const policy={mode,delay_seconds:0,execute_at_ts:0,message:message||'DoMyDesk : redémarrage planifié après maintenance. Enregistrez votre travail.'};
    if(mode==='now')policy.delay_seconds=60;
    else if(mode==='countdown'){
        const minutes=Math.max(1,Math.min(10080,Number(document.getElementById(prefix+'Minutes')?.value||15)));
        policy.delay_seconds=Math.round(minutes*60);
    }else if(mode==='at'){
        policy.execute_at_ts=dmdNextLocalTimeUnix(document.getElementById(prefix+'Time')?.value||'23:00');
    }
    return policy;
}
function dmdRebootPolicyLabel(policy){
    if(!policy||policy.mode==='none')return 'Pas de redémarrage automatique';
    if(policy.mode==='now')return 'Redémarrage avec préavis 60 s';
    if(policy.mode==='countdown')return 'Redémarrage dans '+Math.round((policy.delay_seconds||0)/60)+' min';
    if(policy.mode==='at'&&policy.execute_at_ts)return 'Redémarrage prévu le '+new Date(policy.execute_at_ts*1000).toLocaleString();
    return 'Redémarrage planifié';
}

async function showFeatureUpdates(){
    activeDeviceFeature='updates';
    const currentVersion=selectedDevice?.agent_version||'—';
    openDeviceFeature('Mises à jour',`
        <div class="dmd-agent-updates-dashboard">
            <section class="dmd-agent-update-kind">
                <div class="dmd-agent-update-kind-head">
                    <div><strong>Windows Update</strong><small>Mises à jour Windows, sécurité, cumulatives et pilotes proposés par Windows Update.</small></div>
                    <span>Windows</span>
                </div>
                <div class="dmd-agent-update-actions">
                    <button class="dmd-agent-btn" data-feature-windows-scan>Rechercher</button>
                    <button class="dmd-agent-btn primary" data-feature-windows-install>Installer</button>
                    <button class="dmd-agent-btn" data-feature-windows-history>Historique</button>
                </div>
                <div id="deviceFeatureWindowsUpdateOutput" class="dmd-agent-update-result">Aucune recherche effectuée.</div>
            </section>

            <section class="dmd-agent-update-kind">
                <div class="dmd-agent-update-kind-head">
                    <div><strong>Logiciels</strong><small>Mises à jour des applications détectées par Winget.</small></div>
                    <span>Winget</span>
                </div>
                <div class="dmd-agent-update-actions">
                    <button class="dmd-agent-btn" data-feature-updates-scan>Rechercher</button>
                    <button class="dmd-agent-btn primary" data-feature-updates-apply>Tout mettre à jour</button>
                </div>
                <pre id="deviceFeatureUpdatesOutput" class="dmd-agent-update-result dmd-agent-update-pre">Aucune recherche effectuée.</pre>
            </section>

            <section class="dmd-agent-update-kind dmd-agent-update-domydesk">
                <div class="dmd-agent-update-kind-head">
                    <div><strong>DoMyDesk</strong><small>Met à jour Agent / Update / Remote / MyDesk depuis le package disponible sur ce DoMyDesk.</small></div>
                    <span>Agent</span>
                </div>
                <div class="dmd-agent-version-grid">
                    <div class="dmd-agent-version-card current">
                        <small>Version actuelle</small>
                        <strong id="deviceFeatureAgentCurrentVersion">${htmlEsc(currentVersion)}</strong>
                        <span>Installée</span>
                    </div>
                    <div class="dmd-agent-version-card available" id="deviceFeatureAgentAvailable" data-version="">
                        <small>Version disponible</small>
                        <strong>Vérification…</strong>
                        <span>Serveur</span>
                    </div>
                    <div class="dmd-agent-version-card state">
                        <small>État</small>
                        <strong id="deviceFeatureAgentVersionState">Vérification…</strong>
                        <span id="deviceFeatureAgentProtocol">Update sécurisé</span>
                    </div>
                </div>
                <div class="dmd-agent-update-main-action">
                    <button class="dmd-agent-btn" data-feature-agent-refresh>Rafraîchir</button>
                    <button class="dmd-agent-btn" data-feature-update-packages>Packages</button>
                    <button class="dmd-agent-btn primary" id="deviceFeatureAgentUpdateButton" data-feature-agent-update>Mettre à jour DoMyDesk</button>
                </div>
                <div class="dmd-agent-update-reboot-settings">
                    <div class="dmd-agent-update-reboot-head"><div><strong>Après cette mise à jour</strong><small>Choisis si ce PC doit redémarrer automatiquement après une mise à jour réussie. L’utilisateur distant sera averti.</small></div><span>Notification obligatoire</span></div>
                    <div class="dmd-agent-reboot-control-grid">
                        <label><small>Redémarrage</small><select id="deviceFeatureUpdateRebootMode"><option value="none">Pas automatique</option><option value="now">Après succès · 60 s</option><option value="countdown">Compte à rebours</option><option value="at">À une heure précise</option></select></label>
                        <label id="deviceFeatureUpdateRebootCountdownWrap" hidden><small>Délai</small><div class="dmd-agent-input-unit"><input id="deviceFeatureUpdateRebootMinutes" type="number" min="1" max="10080" value="15"><b>min</b></div></label>
                        <label id="deviceFeatureUpdateRebootTimeWrap" hidden><small>Heure</small><input id="deviceFeatureUpdateRebootTime" type="time" value="23:00"></label>
                    </div>
                </div>
                <div id="deviceFeatureAgentUpdateOutput" class="dmd-agent-update-result dmd-agent-update-result-structured">Aucune mise à jour lancée.</div>

                <div class="dmd-agent-pc-restart-box">
                    <div class="dmd-agent-update-reboot-head"><div><strong>Redémarrer le PC</strong><small>Commande indépendante de la mise à jour. Le poste reçoit un avertissement Windows avant le redémarrage.</small></div><span>Redémarrage</span></div>
                    <div class="dmd-agent-reboot-control-grid manual">
                        <label><small>Mode</small><select id="deviceFeatureManualRebootMode"><option value="now">Maintenant · préavis 60 s</option><option value="countdown">Compte à rebours</option><option value="at">À une heure précise</option></select></label>
                        <label id="deviceFeatureManualRebootCountdownWrap" hidden><small>Délai</small><div class="dmd-agent-input-unit"><input id="deviceFeatureManualRebootMinutes" type="number" min="1" max="10080" value="15"><b>min</b></div></label>
                        <label id="deviceFeatureManualRebootTimeWrap" hidden><small>Heure</small><input id="deviceFeatureManualRebootTime" type="time" value="23:00"></label>
                        <button class="dmd-agent-btn" data-feature-pc-restart>Programmer le redémarrage</button>
                    </div>
                    <div id="deviceFeatureManualRebootOutput" class="dmd-agent-restart-status">Aucun redémarrage programmé depuis cette fenêtre.</div>
                </div>
            </section>
            <div id="deviceUpdatePackagesModal" class="dmd-agent-submodal" hidden>
                <div class="dmd-agent-submodal-dialog dmd-agent-update-packages-modal" role="dialog" aria-modal="true" aria-labelledby="deviceUpdatePackagesTitle">
                    <div class="dmd-agent-submodal-head"><div><h3 id="deviceUpdatePackagesTitle">Packages de mise à jour</h3><p>Fichiers présents dans <code>/domydesk/updates/</code>. Import ZIP, sélection multiple et suppression directe.</p></div><button type="button" class="dmd-agent-mini-btn" data-update-packages-close>Fermer</button></div>
                    <div class="dmd-agent-update-packages-toolbar">
                        <input id="deviceUpdateZipInput" type="file" accept=".zip,application/zip" hidden>
                        <button type="button" class="dmd-agent-mini-btn primary" data-update-packages-pick>Importer un ZIP</button>
                        <button type="button" class="dmd-agent-mini-btn" data-update-packages-refresh>Rafraîchir</button>
                        <button type="button" class="dmd-agent-mini-btn danger" data-update-packages-delete>Supprimer la sélection</button>
                        <span id="deviceUpdatePackagesState" class="dmd-agent-muted"></span>
                    </div>
                    <div id="deviceUpdatePackagesList" class="dmd-agent-update-packages-list"><div class="dmd-agent-admin-empty">Chargement…</div></div>
                </div>
            </div>
        </div>
    `,'medium');
    featureSetState('Prêt',true);
    dmdRebootControlsSync('deviceFeatureUpdateReboot');
    dmdRebootControlsSync('deviceFeatureManualReboot');
    await featureRefreshUpdateInfo(false);
}
async function featureRefreshUpdateInfo(showToast=true){
    if(!selectedDevice)return null;
    const current=document.getElementById('deviceFeatureAgentCurrentVersion'),box=document.getElementById('deviceFeatureAgentAvailable'),state=document.getElementById('deviceFeatureAgentVersionState'),btn=document.getElementById('deviceFeatureAgentUpdateButton'),proto=document.getElementById('deviceFeatureAgentProtocol');
    if(state)state.textContent='Actualisation…';
    try{
        const r=await maintPost('api/admin_maintenance_actions.php',{action:'agent_runtime_info',agent_id:selectedDevice.agent_id});
        if(!r||!r.ok)throw new Error(r&&r.error||'Informations Agent indisponibles.');
        const a=r.agent||{},pkg=r.package||null;
        if(a.agent_version){selectedDevice.agent_version=a.agent_version;if(current)current.textContent=a.agent_version;}
        if(a.update_protocol!=null)selectedDevice.update_protocol=Number(a.update_protocol||0);
        if(a.last_ip)selectedDevice.last_ip=a.last_ip;
        if(a.last_seen_at)selectedDevice.last_seen_at=a.last_seen_at;
        if(proto)proto.textContent='Update sécurisé · protocole '+Number(a.update_protocol||0);
        if(pkg){
            const version=String(pkg.version||'');if(box){box.dataset.version=version;const strong=box.querySelector('strong');if(strong)strong.textContent=version||'Indisponible';}
            const installed=String(a.agent_version||selectedDevice.agent_version||'');const same=installed.toLowerCase()===version.toLowerCase();
            if(state)state.textContent=same?'À jour':'Mise à jour disponible';
            if(btn){btn.disabled=false;btn.textContent=same?'Réinstaller la version actuelle':'Mettre à jour DoMyDesk';}
        }else{
            if(box){box.dataset.version='';const strong=box.querySelector('strong');if(strong)strong.textContent='Indisponible';}
            if(state)state.textContent='Package indisponible';if(btn)btn.disabled=true;
        }
        if(showToast)showMsg('Informations de mise à jour rafraîchies.');
        return r;
    }catch(e){if(state)state.textContent='Actualisation impossible';if(showToast)showMsg(e.message||'Actualisation impossible.',false);return null;}
}
function featureUpdatePackagesRender(r){
    const host=document.getElementById('deviceUpdatePackagesList'),state=document.getElementById('deviceUpdatePackagesState');if(!host)return;
    const rows=Array.isArray(r&&r.files)?r.files:[];
    if(state)state.textContent=rows.length+' fichier(s) · '+fmtAdminBytes(Number(r&&r.total_bytes||0));
    host.innerHTML=rows.length?rows.map(f=>`<label class="dmd-agent-update-package-row ${f.pair_present?'':'incomplete'}"><input type="checkbox" data-update-package-file value="${htmlEsc(f.name||'')}"><span><strong>${htmlEsc(f.name||'')}</strong><small>${htmlEsc(f.kind==='package'?'Package autonome':'Bootstrap Agent')} · ${htmlEsc(fmtAdminBytes(f.size||0))} · ${htmlEsc(formatDate(f.modified_at||''))}</small></span><b>${f.valid_pe?(f.pair_present?'Paire OK':'Paire incomplète'):'Fichier invalide'}</b></label>`).join(''):'<div class="dmd-agent-admin-empty">Aucun package dans /updates/.</div>';
}
async function featureLoadUpdatePackages(){
    const state=document.getElementById('deviceUpdatePackagesState');if(state)state.textContent='Lecture…';
    const r=await post('api/admin_update_packages.php',{action:'list'});if(!r.ok)throw new Error(r.error||'Lecture des packages impossible.');featureUpdatePackagesRender(r);return r;
}
async function featureOpenUpdatePackages(){const m=document.getElementById('deviceUpdatePackagesModal');if(!m)return;m.hidden=false;try{await featureLoadUpdatePackages();}catch(e){showMsg(e.message||'Packages indisponibles.',false);}}
function featureCloseUpdatePackages(){const m=document.getElementById('deviceUpdatePackagesModal');if(m)m.hidden=true;}
async function featureDeleteUpdatePackages(){
    const files=[...document.querySelectorAll('[data-update-package-file]:checked')].map(x=>x.value).filter(Boolean);if(!files.length){showMsg('Sélectionne au moins un fichier.',false);return;}
    if(!confirm('Supprimer '+files.length+' fichier(s) de /updates/ ?'))return;
    const r=await post('api/admin_update_packages.php',{action:'delete',files});if(!r.ok&&!Array.isArray(r.deleted))throw new Error(r.error||'Suppression impossible.');featureUpdatePackagesRender(r);await featureRefreshUpdateInfo(false);showMsg((r.deleted||[]).length+' fichier(s) supprimé(s).');
}
async function featureUploadUpdateZip(file){
    if(!file)return;const state=document.getElementById('deviceUpdatePackagesState');if(state)state.textContent='Import du ZIP…';
    const fd=new FormData();fd.append('action','upload');fd.append('csrf_token',CSRF);fd.append('package_zip',file,file.name||'update.zip');
    const resp=await fetch('api/admin_update_packages.php',{method:'POST',headers:{'X-DMD-CSRF':CSRF},body:fd,credentials:'same-origin'});let r={};try{r=await resp.json();}catch(_){r={ok:false,error:'Réponse import invalide'};}
    if(!resp.ok||!r.ok)throw new Error(r.error||'Import ZIP impossible.');featureUpdatePackagesRender(r);await featureRefreshUpdateInfo(false);showMsg((r.installed||[]).length+' fichier(s) importé(s) dans /updates/.');
}

async function featureUpdatesScan(){
    const out=document.getElementById('deviceFeatureUpdatesOutput');
    if(out)out.textContent='Recherche en cours…';
    featureSetState('Recherche logiciels…');
    try{
        const r=await runDeviceAdminCommand('software.updates.scan',{include_unknown:true});
        if(out)out.textContent=[r&&r.stdout,r&&r.stderr].filter(Boolean).join('\n').trim()||'Aucune mise à jour logicielle disponible.';
        featureSetState('Recherche terminée',true);
    }catch(e){
        if(out)out.textContent=e.message||'Recherche impossible.';
        featureSetState('Erreur');
    }
}
async function featureUpdatesApply(){
    if(!confirm('Installer toutes les mises à jour logicielles Winget disponibles sur '+(selectedDevice?.hostname||'ce PC')+' ?'))return;
    const out=document.getElementById('deviceFeatureUpdatesOutput');
    if(out)out.textContent='Installation en cours…';
    featureSetState('Mise à jour logiciels…');
    try{
        const r=await runDeviceAdminCommand('software.updates.apply',{all:true});
        if(out)out.textContent=[r&&r.stdout,r&&r.stderr].filter(Boolean).join('\n').trim()||'Mises à jour logicielles terminées.';
        featureSetState('Terminé',true);
    }catch(e){
        if(out)out.textContent=e.message||'Mise à jour impossible.';
        featureSetState('Erreur');
    }
}
async function featureWindowsUpdate(mode){
    if(!selectedDevice)return;
    if(mode==='install'&&!confirm('Télécharger et installer les mises à jour Windows sur ce PC ?'))return;
    const out=document.getElementById('deviceFeatureWindowsUpdateOutput');
    if(out)out.innerHTML='<div class="dmd-agent-inline-loading">'+(mode==='scan'?'Démarrage de la recherche Windows Update…':'Téléchargement et installation Windows Update…')+'</div>';
    featureSetState(mode==='scan'?'Recherche Windows Update…':'Installation Windows Update…');
    try{
        if(mode==='scan'){
            let r=await runDeviceAdminCommand('windows_update.scan',{force:true});
            const started=Date.now();
            while(r&&r.scanning&&Date.now()-started<36000){
                if(out)out.innerHTML='<div class="dmd-agent-inline-loading">Recherche Windows Update en arrière-plan… Le reste de DMD-Agent reste disponible.</div>';
                featureSetState('Recherche en arrière-plan…');
                await new Promise(resolve=>setTimeout(resolve,3000));
                r=await runDeviceAdminCommand('windows_update.scan',{force:false});
            }
            if(r&&r.scanning){
                if(out)out.innerHTML='<div class="dmd-agent-update-info">La recherche Windows Update continue en arrière-plan. Tu peux fermer cette fenêtre et revenir dans quelques instants sans bloquer les autres fonctions de DMD-Agent.</div>';
                featureSetState('Recherche en cours…');
                return;
            }
            if(r&&String(r.status||'').toLowerCase()==='error'){
                throw new Error(r.error_message||'Recherche Windows Update impossible.');
            }
            const rows=Array.isArray(r&&r.updates)?r.updates:[];
            const count=Number(r&&r.count||rows.length);
            if(out)out.innerHTML=count?'<div class="dmd-agent-update-list">'+rows.map(u=>'<div class="dmd-agent-update-row"><div><strong>'+htmlEsc(u.title||'Mise à jour Windows')+'</strong><small>'+htmlEsc((Array.isArray(u.kb)&&u.kb.length?u.kb.map(x=>'KB'+String(x).replace(/^KB/i,'')).join(' · '):'Windows Update')+(u.browse_only?' · Optionnelle':'')+(u.source==='windows_update'?' · Source Windows Update':''))+'</small></div><span>'+htmlEsc(u.downloaded?'Téléchargée':(u.browse_only?'Optionnelle':'Disponible'))+'</span></div>').join('')+'</div>':'<div class="dmd-agent-update-ok">Recherche terminée. Aucune mise à jour exploitable n’a été retournée par l’API Windows Update.</div>';
            featureSetState(count+' mise'+(count>1?'s':'')+' à jour',true);
            return;
        }
        const r=await runDeviceAdminCommand('windows_update.install',{all:true});
        const rows=Array.isArray(r&&r.updates)?r.updates:[];
        const count=Number(r&&r.count||rows.length),installed=rows.filter(u=>Number(u&&u.result_code)===2).length,reboot=!!(r&&r.reboot_required);
        if(out)out.innerHTML='<div class="dmd-agent-update-summary"><strong>'+htmlEsc(installed+' / '+count+' installée'+(installed>1?'s':''))+'</strong><span>'+(reboot?'Redémarrage requis':'Aucun redémarrage signalé')+'</span></div>'+(rows.length?'<div class="dmd-agent-update-list">'+rows.map(u=>'<div class="dmd-agent-update-row"><div><strong>'+htmlEsc(u.title||'Mise à jour Windows')+'</strong><small>'+htmlEsc(Array.isArray(u.kb)?u.kb.map(x=>'KB'+String(x).replace(/^KB/i,'')).join(' · '):'')+'</small></div><span>'+htmlEsc(Number(u.result_code)===2?'Installée':'Résultat '+(u.result_code??'—'))+'</span></div>').join('')+'</div>':'');
        featureSetState(reboot?'Terminé · redémarrage requis':'Terminé',true);
    }catch(e){
        if(out)out.innerHTML='<div class="dmd-agent-update-error">'+htmlEsc(e.message||'Windows Update impossible.')+'</div>';
        featureSetState('Erreur');
    }
}

async function featureWindowsHistory(){
    if(!selectedDevice)return;
    const out=document.getElementById('deviceFeatureWindowsUpdateOutput');
    if(out)out.innerHTML='<div class="dmd-agent-inline-loading">Lecture de l’historique Windows Update…</div>';
    featureSetState('Historique Windows Update…');
    try{
        const r=await runDeviceAdminCommand('windows_update.history',{limit:50});
        const rows=Array.isArray(r&&r.history)?r.history:[];
        if(out)out.innerHTML=rows.length?'<div class="dmd-agent-update-list">'+rows.map(u=>'<div class="dmd-agent-update-row"><div><strong>'+htmlEsc(u.title||'Mise à jour Windows')+'</strong><small>'+htmlEsc(formatDate(u.date||''))+'</small></div><span>'+htmlEsc(Number(u.result_code)===2?'Réussie':'Code '+(u.result_code??'—'))+'</span></div>').join('')+'</div>':'<div class="dmd-agent-update-ok">Aucun historique Windows Update retourné.</div>';
        featureSetState(rows.length+' entrée'+(rows.length>1?'s':''),true);
    }catch(e){if(out)out.innerHTML='<div class="dmd-agent-update-error">'+htmlEsc(e.message||'Historique impossible.')+'</div>';featureSetState('Erreur');}
}

function maintUpdatePercent(row){
    const status=String(row&&row.status||'queued').toLowerCase();
    const data=(row&&row.result&&typeof row.result==='object')?row.result:{};
    let p=Number(data.progress_percent);
    if(Number.isFinite(p))return Math.max(0,Math.min(100,p));
    if(status==='completed')return 100;
    if(row&&row.stage==='bootstrap_wait')return 14;
    if(row&&row.stage==='bootstrap')return status==='completed'?18:8;
    const phase=String(data.phase||'').toLowerCase();
    const phaseMap={download:12,verify:40,updater_start:46,stop_services:50,replace_agent:56,replace_update:63,replace_remote:70,replace_mydesk:77,start_services:88,completed:100};
    if(phase&&phaseMap[phase]!=null)return phaseMap[phase];
    const statusMap={queued:1,delivered:3,downloading:12,verified:42,installing:48,waiting:14,failed:0,error:0,expired:0,cancelled:0,ignored:100};
    return statusMap[status]??0;
}
function maintUpdateProgressDetail(row){
    const status=String(row&&row.status||'queued').toLowerCase();
    const data=(row&&row.result&&typeof row.result==='object')?row.result:{};
    let detail=row&&row.error||row&&row.message||data.message||'';
    if(row&&row.stage==='bootstrap')detail=detail||'Installation du moteur DMD-Agent compatible update v2';
    else if(row&&row.stage==='bootstrap_wait')detail=detail||'Attente de la reconnexion du nouvel Agent';
    else if(row&&row.stage==='package'&&!detail)detail='Package update.'+String(row.version||'')+'.exe';
    const bytesDone=Number(data.bytes_done||0),bytesTotal=Number(data.bytes_total||0);
    if(bytesDone>0){
        const bytes=bytesTotal>0?(fmtAdminBytes(bytesDone)+' / '+fmtAdminBytes(bytesTotal)):fmtAdminBytes(bytesDone);
        detail+=(detail?' · ':'')+bytes;
    }
    const comps=Array.isArray(data.components)?data.components:[];
    if(comps.length){
        const txt=comps.map(c=>String(c.name||'composant')+': '+maintComponentStateLabel(c.status||'—')).join(' · ');
        detail+=(detail?' · ':'')+txt;
    }
    if(status==='completed'&&data.reboot_scheduled){
        const when=data.reboot_execute_at?new Date(data.reboot_execute_at).toLocaleString():'heure inconnue';
        detail+=(detail?' · ':'')+'Redémarrage planifié : '+when;
    }else if(status==='completed'&&data.reboot_required){
        detail+=(detail?' · ':'')+'Redémarrage requis';
    }
    return detail||maintStateLabel(status);
}
function maintRenderUpdateProgress(rowsMap,box){
    const rows=[...rowsMap.values()];
    const global=document.getElementById('maintAgentGlobalProgress');
    const bar=document.getElementById('maintAgentGlobalProgressBar');
    const text=document.getElementById('maintAgentGlobalProgressText');
    const runState=document.getElementById('maintAgentUpdateRunState');
    const values=rows.map(maintUpdatePercent);
    const avg=values.length?values.reduce((a,b)=>a+b,0)/values.length:0;
    const completed=rows.filter(r=>String(r.status||'').toLowerCase()==='completed').length;
    const failed=rows.filter(r=>['failed','expired','cancelled','error'].includes(String(r.status||'').toLowerCase())).length;
    if(global)global.hidden=false;
    if(bar)bar.style.width=Math.max(0,Math.min(100,avg)).toFixed(1)+'%';
    if(text)text.textContent=Math.round(avg)+' % · '+completed+'/'+rows.length+' terminé'+(rows.length>1?'s':'')+(failed?' · '+failed+' échec'+(failed>1?'s':''):'');
    if(runState)runState.textContent=failed?('Déploiement terminé avec '+failed+' échec'+(failed>1?'s':'')):completed===rows.length&&rows.length?'Déploiement terminé':('Mise à jour en cours · '+completed+'/'+rows.length+' terminé'+(rows.length>1?'s':''));
    if(!box)return;
    box.innerHTML=rows.map(row=>{
        const host=maintDevice(row.agent_id)?.hostname||row.agent_id||'PC';
        const status=String(row.status||'queued').toLowerCase();
        const p=maintUpdatePercent(row);
        const bad=['failed','expired','cancelled','error'].includes(status);
        const done=status==='completed';
        return `<div class="dmd-maint-update-progress-row ${bad?'bad':(done?'ok':'')}"><div class="dmd-maint-update-progress-head"><strong>${htmlEsc(host)}</strong><span>${htmlEsc(maintStateLabel(status))}</span><b>${Math.round(p)} %</b></div><div class="dmd-maint-update-progressbar"><i style="width:${p}%"></i></div><small>${htmlEsc(maintUpdateProgressDetail(row))}</small></div>`;
    }).join('')||'<div class="dmd-maint-empty">Aucune mise à jour lancée.</div>';
}
async function maintTrackUpdateQueued(rows,box,sharedState,timeoutMs=35*60*1000){
    const state=sharedState||new Map();
    for(const row of rows){
        const previous=state.get(row.agent_id)||{};
        state.set(row.agent_id,{...previous,...row});
    }
    maintRenderUpdateProgress(state,box);
    const deadline=Date.now()+timeoutMs;
    while(Date.now()<deadline){
        let pending=0;
        for(const row of state.values()){
            const status=String(row.status||'').toLowerCase();
            if(!row.command_id||['completed','failed','expired','cancelled','error','ignored'].includes(status))continue;
            pending++;
            try{
                const r=await post('api/admin_command.php',{action:'status',agent_id:row.agent_id,command_id:row.command_id});
                if(r.ok&&r.command){
                    row.status=r.command.status||row.status;
                    row.error=r.command.error||'';
                    row.message=r.command.message||'';
                    row.result=r.command.result||null;
                }
            }catch(_){ }
        }
        maintRenderUpdateProgress(state,box);
        if(pending===0)break;
        await new Promise(resolve=>setTimeout(resolve,700));
    }
    return [...state.values()];
}
async function maintRunDmdUpdateTargets(targets,box,force=true,rebootConfig=null,targetVersion=''){
    const rebootPolicy=(rebootConfig&&rebootConfig.policy)?rebootConfig.policy:{mode:'none',delay_seconds:0,execute_at_ts:0,message:'DoMyDesk : redémarrage planifié après maintenance. Enregistrez votre travail.'};
    const rebootAgentIds=(rebootConfig&&Array.isArray(rebootConfig.agentIds))?rebootConfig.agentIds:[];
    const remaining=new Set((targets||[]).filter(Boolean));
    const statusRows=new Map((targets||[]).filter(Boolean).map(id=>[id,{agent_id:id,status:'queued',stage:'prepare',version:targetVersion||''}]));
    const packageRows=[];
    const failures=[];
    const deadline=Date.now()+5*60*1000;
    maintRenderUpdateProgress(statusRows,box);
    while(remaining.size&&Date.now()<deadline){
        const ids=[...remaining];
        const r=await maintPost('api/admin_maintenance_actions.php',{action:'agent_update',agent_ids:ids,version:targetVersion||'',force:!!force,reboot_policy:rebootPolicy,reboot_agent_ids:rebootAgentIds});
        if(!r.ok)throw new Error(r.error||'Mise à jour DoMyDesk impossible.');
        for(const row of (Array.isArray(r.commands)?r.commands:[])){
            const previous=statusRows.get(row.agent_id)||{};
            statusRows.set(row.agent_id,{...previous,...row});
            if(row.stage==='package'){
                remaining.delete(row.agent_id);
                packageRows.push({...previous,...row});
            }else if(row.stage==='error'||row.status==='error'){
                remaining.delete(row.agent_id);
                failures.push((maintDevice(row.agent_id)?.hostname||row.agent_id)+': '+(row.error||'échec update'));
            }
        }
        maintRenderUpdateProgress(statusRows,box);
        if(remaining.size)await new Promise(resolve=>setTimeout(resolve,1800));
    }
    if(remaining.size)throw new Error('Le nouvel Agent ne s’est pas reconnecté dans le délai prévu. Consulte DMD-Update.log.');
    if(failures.length)throw new Error(failures.join(' · '));
    if(packageRows.length&&box){
        const tracked=await maintTrackUpdateQueued(packageRows,box,statusRows);
        const terminalBad=(tracked||[]).filter(row=>['failed','expired','cancelled','error'].includes(String(row.status||'').toLowerCase()));
        if(terminalBad.length){
            throw new Error(terminalBad.map(row=>(maintDevice(row.agent_id)?.hostname||row.agent_id)+': '+(row.error||row.message||(row.result&&row.result.message)||'échec update')).join(' · '));
        }
        const unfinished=(tracked||[]).filter(row=>!['completed','failed','expired','cancelled','error','ignored'].includes(String(row.status||'').toLowerCase()));
        if(unfinished.length){
            throw new Error('La mise à jour n’a pas atteint un état final dans le délai prévu. Consulte DMD-Update.log.');
        }
    }
    return packageRows;
}

async function featureAgentUpdate(){
    if(!selectedDevice)return;
    const available=document.getElementById('deviceFeatureAgentAvailable')?.dataset.version||'';
    if(!confirm('Mettre à jour DoMyDesk sur '+(selectedDevice.hostname||'ce PC')+(available?' vers '+available:'')+' ?'))return;
    const out=document.getElementById('deviceFeatureAgentUpdateOutput');
    if(out)out.innerHTML='<div class="dmd-agent-inline-loading">Préparation de la mise à jour DoMyDesk…</div>';
    featureSetState('Mise à jour DoMyDesk…');
    const policy=dmdRebootPolicyFromControls('deviceFeatureUpdateReboot','DoMyDesk : redémarrage automatique planifié après la mise à jour. Enregistrez votre travail.');
    const rebootIds=policy.mode==='none'?[]:[selectedDevice.agent_id];
    try{
        await maintRunDmdUpdateTargets([selectedDevice.agent_id],out,true,{policy,agentIds:rebootIds});
        // Ne jamais fabriquer localement la « version actuelle ». Seul le
        // heartbeat de DMD-Agent fait foi. Cela évite d’afficher une version
        // cible comme installée alors que le package a échoué.
        const versionState=document.getElementById('deviceFeatureAgentVersionState');
        if(versionState)versionState.textContent='Terminée · confirmation Agent au prochain heartbeat';
        featureSetState('Mise à jour DoMyDesk terminée',true);
    }catch(e){
        if(out)out.innerHTML='<div class="dmd-agent-update-error">'+htmlEsc(e.message||'Mise à jour DoMyDesk impossible.')+'</div>';
        featureSetState('Erreur');
    }
}

async function featureSchedulePcRestart(){
    if(!selectedDevice)return;
    const policy=dmdRebootPolicyFromControls('deviceFeatureManualReboot','DoMyDesk : redémarrage planifié par l’administrateur. Enregistrez votre travail.');
    let delay=60;
    if(policy.mode==='countdown')delay=policy.delay_seconds||60;
    else if(policy.mode==='at')delay=Math.max(60,(policy.execute_at_ts||0)-Math.floor(Date.now()/1000));
    const label=dmdRebootPolicyLabel(policy);
    if(!confirm(label+' sur '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    const out=document.getElementById('deviceFeatureManualRebootOutput');
    if(out)out.textContent='Planification du redémarrage…';
    try{
        const r=await maintRunCommand(selectedDevice.agent_id,'system.restart',{delay_seconds:delay,message:policy.message},120000);
        const when=r&&r.execute_at?new Date(r.execute_at).toLocaleString():new Date(Date.now()+delay*1000).toLocaleString();
        if(out)out.innerHTML='<strong>Redémarrage programmé</strong><span>'+htmlEsc(when)+' · utilisateur distant averti · délai '+htmlEsc(String(r&&r.delay_seconds||delay))+' s</span>';
        showMsg('Redémarrage programmé.');
    }catch(e){
        if(out)out.innerHTML='<strong>Erreur</strong><span>'+htmlEsc(e.message||'Redémarrage impossible.')+'</span>';
        showMsg(e.message||'Redémarrage impossible.',false);
    }
}

function registryValueText(v){if(Array.isArray(v))return v.join(' ; ');if(v&&typeof v==='object')return JSON.stringify(v);return v===null||v===undefined?'':String(v);}
async function showRegistry(hive=registryState.hive,path=registryState.path){
    registryState={hive:hive||'HKLM',path:path||''};activeDeviceFeature='registry';
    openDeviceFeature('Registre Windows','<div class="dmd-agent-registry"><div class="dmd-agent-registry-bar"><select id="registryHive"><option>HKLM</option><option>HKCU</option><option>HKU</option><option>HKCR</option><option>HKCC</option></select><button class="dmd-agent-btn" data-registry-up>↑</button><input id="registryPath" value="'+htmlEsc(registryState.path)+'" placeholder="Chemin de clé"><button class="dmd-agent-btn primary" data-registry-go>Ouvrir</button></div><div class="dmd-agent-feature-loading">Lecture du registre réel du poste…</div></div>','large');
    const hs=document.getElementById('registryHive');if(hs)hs.value=registryState.hive;featureSetState('Lecture…');
    try{
        const r=await runDeviceAdminCommand('registry.list',{hive:registryState.hive,path:registryState.path}),keys=Array.isArray(r&&r.keys)?r.keys:[],vals=Array.isArray(r&&r.values)?r.values:[];
        const root=document.querySelector('#deviceFeatureBody .dmd-agent-registry');if(!root)return;
        root.innerHTML='<div class="dmd-agent-registry-bar"><select id="registryHive"><option>HKLM</option><option>HKCU</option><option>HKU</option><option>HKCR</option><option>HKCC</option></select><button class="dmd-agent-btn" data-registry-up>↑</button><input id="registryPath" value="'+htmlEsc(registryState.path)+'" placeholder="Chemin de clé"><button class="dmd-agent-btn primary" data-registry-go>Ouvrir</button></div><div class="dmd-agent-registry-path">'+htmlEsc(registryState.hive+(registryState.path?'\\'+registryState.path:''))+'</div><form id="registrySetForm" class="dmd-agent-registry-set"><input name="name" placeholder="Nom valeur (vide = défaut)"><select name="value_type"><option value="string">String</option><option value="expandstring">ExpandString</option><option value="multistring">MultiString</option><option value="dword">DWORD</option><option value="qword">QWORD</option><option value="binary">Binary base64</option></select><input name="value" placeholder="Valeur"><button class="dmd-agent-btn primary" type="submit">Créer / modifier</button></form><div class="dmd-agent-registry-columns"><section><h3>Clés</h3><div class="dmd-agent-registry-list">'+(keys.length?keys.map(k=>'<div class="dmd-agent-registry-key-row"><button type="button" class="dmd-agent-registry-key" data-registry-key="'+htmlEsc(k.path||k.name||'')+'">▸ '+htmlEsc(k.name||'Clé')+'</button><button type="button" class="dmd-agent-mini-btn danger" data-registry-delete-key="'+htmlEsc(k.path||k.name||'')+'">×</button></div>').join(''):'<div class="dmd-agent-data-empty">Aucune sous-clé.</div>')+'</div></section><section><h3>Valeurs</h3><div class="dmd-agent-registry-values">'+(vals.length?vals.map(v=>'<div><strong>'+htmlEsc(v.name||'(Par défaut)')+'</strong><span>'+htmlEsc(v.type||'')+'</span><code>'+htmlEsc(registryValueText(v.value))+'</code><button type="button" class="dmd-agent-mini-btn" data-registry-edit-value="'+htmlEsc(v.raw_name??v.name??'')+'" data-registry-edit-type="'+htmlEsc(v.type||'String')+'" data-registry-edit-data="'+htmlEsc(registryValueText(v.value))+'">Modifier</button><button type="button" class="dmd-agent-mini-btn danger" data-registry-delete-value="'+htmlEsc(v.raw_name??v.name??'')+'">Supprimer</button></div>').join(''):'<div class="dmd-agent-data-empty">Aucune valeur.</div>')+'</div></section></div>';
        const sel=document.getElementById('registryHive');if(sel)sel.value=registryState.hive;featureSetState('Registre réel',true);
    }catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture du registre impossible.')+'</div>';featureSetState('Erreur');}
}

async function showNetworkPaths(){
    featureLoading('Lecteurs réseau','Lecture des lecteurs réseau…','medium');activeDeviceFeature='network-paths';
    try{
        const r=await runDeviceAdminCommand('network.paths.list',{});
        let rows=r&&r.paths;if(rows&&!Array.isArray(rows)&&typeof rows==='object')rows=Object.values(rows);if(!Array.isArray(rows))rows=[];
        const body=document.getElementById('deviceFeatureBody');
        if(!body)throw new Error('Zone Lecteurs réseau introuvable dans la fenêtre.');
        body.innerHTML='<div class="dmd-agent-network-paths"><form id="networkPathAddForm" class="dmd-agent-network-add"><input name="local" maxlength="2" placeholder="Z:"><input name="remote" placeholder="\\\\serveur\\partage ou serveur\\partage\\dossier"><button class="dmd-agent-btn primary" type="submit">Ajouter</button></form><small class="dmd-agent-network-help">Le chemin est normalisé automatiquement : tu peux saisir \\\\serveur\\partage, serveur\\partage ou une IP.</small><div class="dmd-agent-feature-list">'+(rows.length?rows.map(x=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(x.local_path||'—')+' → '+htmlEsc(x.remote_path||'—')+'</strong><small>'+htmlEsc(x.status||'')+' · '+htmlEsc(x.scope||'')+'</small></div><button class="dmd-agent-btn danger" data-network-remove="'+htmlEsc(x.local_path||'')+'">Retirer</button></div>').join(''):'<div class="dmd-agent-data-empty">Aucun chemin réseau mappé.</div>')+'</div></div>';
        featureSetState('À jour',true);
    }catch(e){
        const body=document.getElementById('deviceFeatureBody');
        if(body)body.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture réseau impossible.')+'</div>';
        featureSetState('Erreur');
    }
}

const dmdFileState={path:'',offset:0,roots:[]};
function dmdWinJoin(base,name){return String(base||'').replace(/[\\/]+$/,'')+'\\'+String(name||'').replace(/^[\\/]+/,'');}
function dmdB64FromBytes(bytes){let out='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)out+=String.fromCharCode(...bytes.subarray(i,Math.min(i+step,bytes.length)));return btoa(out);}
function dmdBytesFromB64(v){const raw=atob(String(v||'')),a=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)a[i]=raw.charCodeAt(i);return a;}
function dmdTruthy(v){return v===true||v===1||String(v).toLowerCase()==='true'||String(v).toLowerCase()==='enabled'||String(v).toLowerCase()==='up';}

async function showFeatureNetworkAdmin(){
    featureLoading('Réseau','Lecture de toutes les cartes réseau…','large');activeDeviceFeature='network';
    try{
        const r=await runDeviceAdminCommand('network.adapters.list',{}),rows=Array.isArray(r&&r.adapters)?r.adapters:[];
        deviceFeatureBody.innerHTML='<div class="dmd-agent-feature-toolbar"><strong>'+htmlEsc(rows.length+' carte'+(rows.length>1?'s':''))+'</strong><button class="dmd-agent-btn" data-network-refresh>Actualiser</button></div><div class="dmd-agent-adapter-list">'+(rows.length?rows.map(a=>{const v4=Array.isArray(a.ipv4)?a.ipv4:[],dns=Array.isArray(a.dns_ipv4)?a.dns_ipv4:[];const ip=v4[0]||{};const dhcp=String(a.dhcp_ipv4||'').toLowerCase()==='enabled';return '<section class="dmd-agent-adapter-card"><div class="dmd-agent-adapter-head"><div><strong>'+htmlEsc(a.name||'Carte réseau')+'</strong><small>'+htmlEsc(a.description||'')+' · '+htmlEsc(a.mac||'MAC inconnue')+' · '+htmlEsc(a.link_speed||'')+'</small></div><span>'+htmlEsc(a.status||'—')+'</span></div><div class="dmd-agent-admin-kv"><span>IPv4 <b>'+htmlEsc(v4.map(x=>(x.address||'')+'/'+String(x.prefix_length??'')).join(', ')||'—')+'</b></span><span>Passerelle <b>'+htmlEsc(a.gateway_ipv4||'—')+'</b></span><span>DNS <b>'+htmlEsc(dns.join(', ')||'—')+'</b></span><span>DHCP <b>'+htmlEsc(a.dhcp_ipv4||'—')+'</b></span><span>Index <b>'+htmlEsc(a.index??'—')+'</b></span></div><div class="dmd-agent-adapter-actions"><button class="dmd-agent-mini-btn" data-net-control="enable" data-net-alias="'+htmlEsc(a.name||'')+'">Activer</button><button class="dmd-agent-mini-btn" data-net-control="restart" data-net-alias="'+htmlEsc(a.name||'')+'">Redémarrer carte</button><button class="dmd-agent-mini-btn danger" data-net-control="disable" data-net-alias="'+htmlEsc(a.name||'')+'">Désactiver</button></div><form class="dmd-agent-network-config-form" data-network-config-form data-alias="'+htmlEsc(a.name||'')+'"><label><input type="checkbox" name="dhcp" '+(dhcp?'checked':'')+'> DHCP IPv4</label><input name="ipv4" value="'+htmlEsc(ip.address||'')+'" placeholder="IPv4"><input name="prefix" type="number" min="0" max="32" value="'+htmlEsc(ip.prefix_length??24)+'" placeholder="Préfixe"><input name="gateway" value="'+htmlEsc(a.gateway_ipv4||'')+'" placeholder="Passerelle"><input name="dns" value="'+htmlEsc(dns.join(', '))+'" placeholder="DNS séparés par virgules"><label><input type="checkbox" name="restart" checked> Changer maintenant / redémarrer la carte</label><button class="dmd-agent-btn primary" type="submit">Appliquer</button></form></section>';}).join(''):'<div class="dmd-agent-data-empty">Aucune carte réseau retournée.</div>')+'</div>';
        featureSetState('À jour',true);
    }catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture réseau impossible.')+'</div>';featureSetState('Erreur');}
}

async function showFeatureMachineAdmin(){
    activeDeviceFeature='machine';
    openDeviceFeature('Machine','<div class="dmd-agent-feature-machine"><div id="featureHealthCopy" class="dmd-agent-health-grid">'+document.getElementById('deviceHealth').innerHTML+'</div><div class="dmd-agent-feature-copy dmd-agent-detail-grid">'+document.getElementById('deviceGeneral').innerHTML+'</div><section class="dmd-agent-admin-section"><h3>Renommer le PC</h3><form id="machineRenameForm" class="dmd-agent-admin-inline-form"><input name="new_name" maxlength="15" required value="'+htmlEsc(selectedDevice?.hostname||'')+'" placeholder="PC-BUREAU-01"><button class="dmd-agent-btn primary" type="submit">Renommer</button></form><small>Le nouveau nom prendra effet après redémarrage. DMD-Agent avertit l’utilisateur Windows.</small></section></div>','medium');
}

async function showFeatureSessionsAdmin(){
    featureLoading('Sessions','Lecture des sessions Windows…','medium');activeDeviceFeature='sessions';
    try{const r=await runDeviceAdminCommand('sessions.list',{}),rows=Array.isArray(r&&r.sessions)?r.sessions:[];deviceFeatureBody.innerHTML='<div class="dmd-agent-feature-toolbar"><strong>'+htmlEsc(rows.length+' session'+(rows.length>1?'s':''))+'</strong><button class="dmd-agent-btn" data-sessions-refresh>Actualiser</button></div><div class="dmd-agent-feature-list">'+(rows.length?rows.map(x=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(x.username||'Utilisateur')+(x.console?' · Console':'')+'</strong><small>Session #'+htmlEsc(x.id)+' · '+htmlEsc(x.station||'—')+' · '+htmlEsc(x.state||'—')+'</small></div><div class="dmd-agent-row-actions">'+(x.can_disconnect?'<button class="dmd-agent-btn" data-session-action="disconnect" data-session-id="'+htmlEsc(x.id)+'">Déconnecter</button>':'')+(x.can_logoff?'<button class="dmd-agent-btn danger" data-session-action="logoff" data-session-id="'+htmlEsc(x.id)+'">Fermer session</button>':'')+'</div></div>').join(''):'<div class="dmd-agent-data-empty">Aucune session utilisateur.</div>')+'</div>';featureSetState('À jour',true);}catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture sessions impossible.')+'</div>';featureSetState('Erreur');}
}

let firewallStateRules=[];
function renderFirewallRules(rows){firewallStateRules=rows;return rows.length?'<div class="dmd-agent-firewall-list">'+rows.map((r,i)=>'<div class="dmd-agent-firewall-row"><div><strong>'+htmlEsc(r.display_name||r.name||'Règle')+'</strong><small>'+htmlEsc(r.direction||'')+' · '+htmlEsc(r.action||'')+' · '+htmlEsc(r.protocol||'ANY')+' · Local '+htmlEsc(r.local_port||'Any')+' · Distant '+htmlEsc(r.remote_address||'Any')+'</small></div><span>'+htmlEsc(r.enabled||'—')+'</span><div class="dmd-agent-row-actions"><button class="dmd-agent-mini-btn" data-firewall-toggle="'+i+'">'+(dmdTruthy(r.enabled)?'Désactiver':'Activer')+'</button><button class="dmd-agent-mini-btn" data-firewall-action-toggle="'+i+'">'+(String(r.action||'').toLowerCase()==='allow'?'Bloquer':'Autoriser')+'</button><button class="dmd-agent-mini-btn danger" data-firewall-delete="'+htmlEsc(r.name||'')+'">Supprimer</button></div></div>').join('')+'</div>':'<div class="dmd-agent-data-empty">Aucune règle retournée pour ce filtre.</div>';}

async function showFeaturePortsAdmin(query='',portOffset=0,fwOffset=0){
    activeDeviceFeature='ports';
    openDeviceFeature('Ports & pare-feu',
        '<div class="dmd-agent-admin-two-section">'+
            '<section><div id="portsAdminHost"><div class="dmd-agent-feature-loading">Lecture des ports TCP/UDP…</div></div></section>'+
            '<section class="dmd-agent-admin-section">'+
                '<div class="dmd-agent-feature-toolbar"><h3>Règles pare-feu</h3><span id="firewallCountLabel">Chargement…</span></div>'+
                '<form id="firewallSearchForm" class="dmd-agent-admin-inline-form"><input type="hidden" name="port_offset" value="'+Number(portOffset||0)+'"><input name="query" value="'+htmlEsc(query)+'" placeholder="Filtrer les règles"><button class="dmd-agent-btn" type="submit">Rechercher</button></form>'+
                '<form id="firewallAddForm" class="dmd-agent-firewall-form"><input name="name" required placeholder="Nom unique de règle"><select name="direction"><option value="inbound">Entrant</option><option value="outbound">Sortant</option></select><select name="action"><option value="allow">Autoriser</option><option value="block">Bloquer</option></select><select name="protocol"><option>TCP</option><option>UDP</option><option>ANY</option></select><input name="local_port" placeholder="Port local / Any"><input name="remote_port" placeholder="Port distant / Any"><input name="program" placeholder="Programme (optionnel)"><input name="remote_address" placeholder="Adresse distante (optionnel)"><button class="dmd-agent-btn primary" type="submit">Ajouter la règle</button></form>'+
                '<div id="firewallRulesHost"><div class="dmd-agent-feature-loading">Lecture des règles pare-feu…</div></div>'+
                '<div id="firewallPagerHost" class="dmd-agent-file-pager"></div>'+
            '</section>'+
        '</div>','large');
    featureSetState('Chargement…');

    let hadError=false;
    const portsJob=(async()=>{
        const host=document.getElementById('portsAdminHost');if(!host)return;
        try{
            const p=await runDeviceAdminCommand('network.ports.list',{offset:Number(portOffset)||0,limit:80});
            const ports=Array.isArray(p&&p.ports)?p.ports:[];
            const pTotal=Number(p&&p.total||ports.length),pOff=Number(p&&p.offset||0),pPrev=Number(p&&p.prev_offset||0),pNext=Number(p&&p.next_offset||pOff+ports.length),pMore=!!(p&&p.has_more);
            host.innerHTML='<div class="dmd-agent-feature-toolbar"><strong>'+htmlEsc(pTotal+' ports/endpoints')+'</strong><div>'+(pOff>0?'<button class="dmd-agent-btn" data-ports-page="'+pPrev+'" data-fw-page="'+Number(fwOffset||0)+'">‹</button>':'')+(pMore?'<button class="dmd-agent-btn" data-ports-page="'+pNext+'" data-fw-page="'+Number(fwOffset||0)+'">›</button>':'')+'<button class="dmd-agent-btn" data-ports-refresh>Actualiser</button></div></div><div class="dmd-agent-port-admin-list">'+(ports.length?ports.map(x=>'<div class="dmd-agent-port-admin-row"><strong>'+htmlEsc(x.port)+'</strong><span>'+htmlEsc(x.protocol||'')+'</span><span>'+htmlEsc(x.address||'')+'</span><span>'+htmlEsc(x.process||'—')+(x.pid?' · PID '+htmlEsc(x.pid):'')+'</span></div>').join(''):'<div class="dmd-agent-data-empty">Aucun port en écoute.</div>')+'</div>';
        }catch(e){
            hadError=true;
            host.innerHTML='<div class="dmd-agent-data-empty">Ports indisponibles : '+htmlEsc(e.message||'erreur')+' <button class="dmd-agent-btn" data-ports-refresh>Réessayer</button></div>';
        }
    })();

    const firewallJob=(async()=>{
        const host=document.getElementById('firewallRulesHost'),countHost=document.getElementById('firewallCountLabel'),pager=document.getElementById('firewallPagerHost');if(!host)return;
        try{
            const f=await runDeviceAdminCommand('firewall.list',{query,offset:Number(fwOffset)||0,limit:30});
            const rules=Array.isArray(f&&f.rules)?f.rules:[];
            const fTotal=Number(f&&f.total||rules.length),fOff=Number(f&&f.offset||0),fPrev=Number(f&&f.prev_offset||0),fNext=Number(f&&f.next_offset||fOff+rules.length),fMore=!!(f&&f.has_more);
            if(countHost)countHost.textContent=fTotal+' règle'+(fTotal>1?'s':'');
            host.innerHTML=renderFirewallRules(rules);
            if(pager)pager.innerHTML=(fOff>0?'<button class="dmd-agent-btn" data-firewall-page="'+fPrev+'" data-port-page="'+Number(portOffset||0)+'">‹ Précédent</button>':'')+(fMore?'<button class="dmd-agent-btn" data-firewall-page="'+fNext+'" data-port-page="'+Number(portOffset||0)+'">Suivant ›</button>':'');
        }catch(e){
            hadError=true;
            firewallStateRules=[];
            if(countHost)countHost.textContent='Erreur';
            host.innerHTML='<div class="dmd-agent-data-empty">Pare-feu indisponible : '+htmlEsc(e.message||'erreur')+'</div>';
            if(pager)pager.innerHTML='';
        }
    })();

    await Promise.allSettled([portsJob,firewallJob]);
    featureSetState(hadError?'Chargement partiel':'À jour',!hadError);
}

function renderFileEntries(r){const rows=Array.isArray(r&&r.entries)?r.entries:[];return '<div class="dmd-agent-file-toolbar">'+(r&&r.parent?'<button class="dmd-agent-btn" data-file-open="'+htmlEsc(r.parent)+'">↑ Dossier parent</button>':'')+'<code>'+htmlEsc(r&&r.path||'')+'</code><button class="dmd-agent-btn" data-files-refresh>Actualiser</button></div><div class="dmd-agent-file-list">'+(rows.length?rows.map(x=>'<div class="dmd-agent-file-row"><button class="dmd-agent-file-name" '+(x.is_dir?'data-file-open="'+htmlEsc(x.path||'')+'"':'data-file-download="'+htmlEsc(x.path||'')+'"')+'><strong>'+(x.is_dir?'📁 ':'📄 ')+htmlEsc(x.name||'')+'</strong><small>'+htmlEsc(x.is_dir?'Dossier':fmtAdminBytes(x.size))+' · '+htmlEsc(formatDate(x.modified_at||''))+'</small></button><div class="dmd-agent-row-actions"><button class="dmd-agent-mini-btn" data-file-rename="'+htmlEsc(x.path||'')+'" data-file-name="'+htmlEsc(x.name||'')+'">Renommer</button><button class="dmd-agent-mini-btn danger" data-file-delete="'+htmlEsc(x.path||'')+'" data-file-dir="'+(x.is_dir?'1':'0')+'">Supprimer</button></div></div>').join(''):'<div class="dmd-agent-data-empty">Dossier vide.</div>')+'</div><div class="dmd-agent-file-pager">'+(Number(r&&r.offset||0)>0?'<button class="dmd-agent-btn" data-file-page="'+Number(r.prev_offset||0)+'">‹ Précédent</button>':'')+(r&&r.has_more?'<button class="dmd-agent-btn" data-file-page="'+Number(r.next_offset||0)+'">Suivant ›</button>':'')+'</div>';}
async function showFileRoots(){
    featureSetState('Lecteurs…');
    const r=await runDeviceAdminCommand('filesystem.roots',{}),roots=Array.isArray(r&&r.roots)?r.roots:[];
    dmdFileState.roots=roots;dmdFileState.path='';
    const rootsHost=deviceFeatureBody.querySelector('#dmdFileRootsHost');
    const fileHost=deviceFeatureBody.querySelector('#dmdFileManagerHost');
    if(rootsHost){
        rootsHost.innerHTML=roots.length?roots.map(x=>{
            const total=Number(x.total_bytes||0),used=Number(x.used_bytes||0),free=Number(x.free_bytes||0);
            const usage=total>0?Math.max(0,Math.min(100,(used/total)*100)):0;
            const letter=String(x.path||x.label||'').replace(/\\/g,'').replace(':','').trim()||'?';
            const sizeText=total>0?(formatBytes(used)+' / '+formatBytes(total)):(x.drive_type_name||x.filesystem||'Lecteur');
            return '<button class="dmd-agent-drive-mini" data-file-open="'+htmlEsc(x.path||'')+'" title="'+htmlEsc(x.path||'')+'">'+
                '<strong>'+htmlEsc(letter)+':</strong>'+
                '<span>'+htmlEsc(sizeText)+'</span>'+
                (total>0?'<i><b style="width:'+usage.toFixed(1)+'%"></b></i>':'')+
                '</button>';
        }).join(''):'<div class="dmd-agent-data-empty compact">Aucun lecteur.</div>';
    }
    if(fileHost)fileHost.innerHTML='<div class="dmd-agent-data-empty">Sélectionne un lecteur ci-dessus pour afficher ses dossiers et fichiers.</div>';
    featureSetState('Prêt',true);
}
async function showFilePath(path,offset=0){dmdFileState.path=path;dmdFileState.offset=offset;featureSetState('Fichiers…');const r=await runDeviceAdminCommand('filesystem.list',{path,offset,limit:80});const host=deviceFeatureBody.querySelector('#dmdFileManagerHost');if(host)host.innerHTML=renderFileEntries(r);featureSetState('À jour',true);}
async function downloadAgentFile(path){featureSetState('Téléchargement…');let off=0,total=0,name=String(path).split(/[\\/]/).pop()||'fichier',chunks=[];while(true){const r=await runDeviceAdminCommand('filesystem.read',{path,offset:off,length:28672});const b=dmdBytesFromB64(r&&r.data_base64||'');chunks.push(b);total=Number(r&&r.total_size||total);off=Number(r&&r.next_offset||off+b.length);if(r&&r.eof)break;}const blob=new Blob(chunks),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);featureSetState('Téléchargé · '+fmtAdminBytes(total),true);}
async function uploadAgentFile(file){if(!dmdFileState.path)throw new Error('Ouvre d’abord un dossier cible.');featureSetState('Envoi '+file.name+'…');const data=new Uint8Array(await file.arrayBuffer()),path=dmdWinJoin(dmdFileState.path,file.name),chunk=24576;for(let off=0;off<data.length||off===0;off+=chunk){const part=data.subarray(off,Math.min(data.length,off+chunk));await runDeviceAdminCommand('filesystem.write',{path,offset:off,truncate:off===0,data_base64:dmdB64FromBytes(part)});if(data.length===0)break;}await showFilePath(dmdFileState.path,0);showMsg('Fichier envoyé : '+file.name);}
async function showFeatureStorageAdmin(){
    activeDeviceFeature='storage';
    openDeviceFeature('Stockages','<div class="dmd-agent-storage-admin">'+
        '<div class="dmd-agent-storage-top">'+
            '<section class="dmd-agent-storage-physical"><div class="dmd-agent-feature-toolbar"><strong>Disques physiques</strong><button class="dmd-agent-btn" data-storage-refresh>Actualiser</button></div><div id="dmdPhysicalDisksHost"><div class="dmd-agent-feature-loading">Lecture des disques…</div></div></section>'+
            '<section class="dmd-agent-storage-drives"><div class="dmd-agent-feature-toolbar"><strong>Lecteurs</strong></div><div id="dmdFileRootsHost" class="dmd-agent-drive-mini-grid"><div class="dmd-agent-feature-loading">Lecture des lecteurs…</div></div></section>'+
        '</div>'+
        '<section class="dmd-agent-admin-section dmd-agent-storage-files"><div class="dmd-agent-card-title-row"><div><h3>Fichiers</h3><p>Clique sur un lecteur ci-dessus puis navigue dans ses dossiers.</p></div><div class="dmd-agent-row-actions"><button class="dmd-agent-btn" data-file-mkdir>Nouveau dossier</button><label class="dmd-agent-btn dmd-agent-file-upload-label">Envoyer fichier<input id="dmdFileUpload" type="file" hidden></label></div></div><div id="dmdFileManagerHost"><div class="dmd-agent-data-empty">Sélectionne un lecteur.</div></div></section>'+
    '</div>','large');
    featureSetState('Chargement…');
    const diskJob=(async()=>{try{
        const r=await runDeviceAdminCommand('storage.disks.list',{}),disks=Array.isArray(r&&r.disks)?r.disks:[];
        const host=document.getElementById('dmdPhysicalDisksHost');if(!host)return;
        host.innerHTML='<div class="dmd-agent-physical-disks">'+(disks.length?disks.map(d=>'<article class="dmd-agent-disk-card '+(d.protected?'protected':'')+'"><div class="dmd-agent-disk-head"><div><strong>Disque '+htmlEsc(d.number)+' · '+htmlEsc(d.friendly_name||'Disque')+'</strong><small>'+htmlEsc(d.bus_type||'')+' · '+htmlEsc(d.partition_style||'')+' · '+htmlEsc(fmtAdminBytes(d.size))+' · '+htmlEsc(d.health||'')+'</small></div><span>'+(d.protected?'SYSTÈME PROTÉGÉ':'Administrable')+'</span></div><div class="dmd-agent-partition-list">'+(Array.isArray(d.partitions)?d.partitions.map(p=>'<div class="dmd-agent-partition-row"><div><strong>'+(p.drive_letter?htmlEsc(p.drive_letter)+':':'Partition '+htmlEsc(p.partition_number))+' · '+htmlEsc(p.label||p.filesystem||'')+'</strong><small>'+htmlEsc(p.filesystem||'—')+' · '+htmlEsc(fmtAdminBytes(p.size))+' · libre '+htmlEsc(fmtAdminBytes(p.size_remaining))+'</small></div>'+(!d.protected&&p.drive_letter&&!p.is_boot&&!p.is_system?'<button class="dmd-agent-btn danger" data-format-drive="'+htmlEsc(p.drive_letter)+'">Formater</button>':'')+'</div>').join(''):'')+'</div>'+(!d.protected?'<button class="dmd-agent-btn danger dmd-agent-format-disk" data-format-disk="'+htmlEsc(d.number)+'">Effacer / formater tout le disque</button>':'')+'</article>').join(''):'<div class="dmd-agent-data-empty">Aucun disque retourné.</div>')+'</div>';
    }catch(e){const host=document.getElementById('dmdPhysicalDisksHost');if(host)host.innerHTML='<div class="dmd-agent-data-empty">Inventaire disques indisponible : '+htmlEsc(e.message||'erreur')+'</div>';}})();
    const filesJob=(async()=>{try{await showFileRoots();}catch(e){const host=document.getElementById('dmdFileManagerHost');if(host)host.innerHTML='<div class="dmd-agent-data-empty">Fichiers indisponibles : '+htmlEsc(e.message||'erreur')+'</div>';}})();
    await Promise.allSettled([diskJob,filesJob]);
    featureSetState('Prêt',true);
}

async function showFeatureSecurityAdmin(){featureLoading('Sécurité','Lecture de Microsoft Defender, antivirus et pare-feu…','large');activeDeviceFeature='security';try{const r=await runDeviceAdminCommand('security.status',{}),d=r&&r.defender||{},avs=Array.isArray(r&&r.antivirus_products)?r.antivirus_products:[],profiles=Array.isArray(r&&r.firewall_profiles)?r.firewall_profiles:[];deviceFeatureBody.innerHTML='<div class="dmd-agent-security-admin"><section class="dmd-agent-admin-section"><h3>Microsoft Defender</h3><div class="dmd-agent-admin-kv"><span>Antivirus <b>'+htmlEsc(d.antivirus_enabled?'Actif':'Inactif / indisponible')+'</b></span><span>Temps réel <b>'+htmlEsc(d.real_time_enabled?'Actif':'Inactif')+'</b></span><span>Tamper Protection <b>'+htmlEsc(d.tamper_protected?'Actif':'Inactif')+'</b></span><span>Signatures <b>'+htmlEsc(d.signature_version||'—')+'</b></span><span>MAJ signatures <b>'+htmlEsc(formatDate(d.signature_updated||''))+'</b></span></div><div class="dmd-agent-row-actions wrap"><button class="dmd-agent-btn" data-defender-action="scan_quick">Scan rapide</button><button class="dmd-agent-btn" data-defender-action="scan_full">Scan complet</button><button class="dmd-agent-btn" data-defender-action="signatures_update">Mettre à jour signatures</button><button class="dmd-agent-btn" data-defender-action="realtime_enable">Activer temps réel</button><button class="dmd-agent-btn danger" data-defender-action="realtime_disable">Désactiver temps réel</button></div></section><section class="dmd-agent-admin-section"><h3>Produits antivirus détectés</h3>'+(avs.length?avs.map(x=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(x.name||'Antivirus')+'</strong><small>'+htmlEsc(x.path||'')+' · état '+htmlEsc(x.state??'—')+'</small></div></div>').join(''):'<div class="dmd-agent-data-empty">Aucun produit SecurityCenter2 remonté.</div>')+'</section><section class="dmd-agent-admin-section"><h3>Profils pare-feu Windows</h3>'+(profiles.length?profiles.map(x=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(x.name||'Profil')+'</strong><small>Entrant '+htmlEsc(x.default_inbound||'')+' · Sortant '+htmlEsc(x.default_outbound||'')+'</small></div><span>'+htmlEsc(x.enabled?'Actif':'Inactif')+'</span></div>').join(''):'<div class="dmd-agent-data-empty">Aucun profil.</div>')+'</section></div>';featureSetState('À jour',true);}catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture sécurité impossible.')+'</div>';featureSetState('Erreur');}}

async function showUsb(){featureLoading('USB','Détection des périphériques amovibles…','large');activeDeviceFeature='usb';try{const r=await runDeviceAdminCommand('devices.removable.list',{});const vols=Array.isArray(r&&r.volumes)?r.volumes:[],usb=Array.isArray(r&&r.usb_devices)?r.usb_devices:[];deviceFeatureBody.innerHTML='<div class="dmd-agent-feature-toolbar"><strong>Contrôle USB</strong><div><button class="dmd-agent-btn danger" data-usb-global="block">Bloquer stockage USB</button><button class="dmd-agent-btn" data-usb-global="unblock">Débloquer stockage USB</button></div></div><div class="dmd-agent-feature-split"><section><h3>Lecteurs amovibles / optiques</h3>'+(vols.length?vols.map(v=>{const canFormat=v.can_format===true||String(v.kind||'').toLowerCase()==='removable';return '<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(v.letter||'Lecteur')+' '+htmlEsc(v.label||'')+'</strong><small>'+htmlEsc(v.kind||'')+' · '+htmlEsc(v.filesystem||'—')+' · '+htmlEsc(formatBytes(v.free))+' libres / '+htmlEsc(formatBytes(v.size))+'</small></div><div class="dmd-agent-row-actions"><button class="dmd-agent-btn" data-usb-browse="'+htmlEsc(v.letter||'')+'">Fichiers</button>'+(canFormat?'<button class="dmd-agent-btn danger" data-usb-format="'+htmlEsc(v.letter||'')+'">Formater</button>':'')+'<button class="dmd-agent-btn" data-usb-eject="'+htmlEsc(v.letter||'')+'">Éjecter</button></div></div>';}).join(''):'<div class="dmd-agent-data-empty">Aucun lecteur amovible.</div>')+'</section><section><h3>Périphériques USB de stockage</h3>'+(usb.length?usb.map(v=>'<div class="dmd-agent-feature-item"><div><strong>'+htmlEsc(v.model||'USB')+'</strong><small>'+htmlEsc(v.serial||'Sans numéro de série')+' · '+htmlEsc(formatBytes(v.size))+'</small></div></div>').join(''):'<div class="dmd-agent-data-empty">Aucun disque USB détecté.</div>')+'</section></div>';featureSetState('À jour',true);}catch(e){deviceFeatureBody.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'Lecture USB impossible.')+'</div>';featureSetState('Erreur');}}

function showControl(){activeDeviceFeature='control';openDeviceFeature('Contrôle','<div class="dmd-agent-control-actions"><button type="button" class="dmd-agent-control-action remote" data-control-action="remote"><strong>Remote</strong><span>Prendre le contrôle</span></button><button type="button" class="dmd-agent-control-action danger" data-control-action="shutdown"><strong>Éteindre</strong><span>Arrêt Windows</span></button><button type="button" class="dmd-agent-control-action wol" data-control-action="wol"><strong>Allumer WOL</strong><span>Wake-on-LAN</span></button><button type="button" class="dmd-agent-control-action warning" data-control-action="restart"><strong>Redémarrer</strong><span>Redémarrage Windows</span></button><button type="button" class="dmd-agent-control-action danger" data-control-action="revoke"><strong>Révoquer</strong><span>Retirer ce PC</span></button></div>');}
async function runControlAction(action){
    if(!selectedDevice)return;
    if(action==='remote'){
        const name='DMDRemote_'+String(selectedDevice.agent_id||'PC').replace(/[^A-Za-z0-9_-]/g,'_');
        const url=DMD_BASE_PATH+'/modules/DMD-RemoteAgent/DMD-RemoteAgent_detached.php?agent_id='+encodeURIComponent(selectedDevice.agent_id)+'&control=1';
        const w=window.open(url,name,'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');
        if(w){featureSetState('Remote lancé',true);}else{featureSetState('Erreur');showMsg('Le navigateur a bloqué la fenêtre Remote.',false);}return;
    }
    if(action==='revoke'){revokeAgent(selectedDevice.agent_id);return;}
    if(action==='shutdown'){if(!confirm('Éteindre '+(selectedDevice.hostname||'ce PC')+' ?'))return;featureSetState('Arrêt envoyé…');try{await runDeviceAdminCommand('system.shutdown',{delay_seconds:45});featureSetState('Arrêt programmé',true);}catch(e){featureSetState('Erreur');showMsg(e.message||'Arrêt impossible.',false);}return;}
    if(action==='restart'){if(!confirm('Redémarrer '+(selectedDevice.hostname||'ce PC')+' ?'))return;featureSetState('Redémarrage envoyé…');try{await runDeviceAdminCommand('system.restart',{delay_seconds:45});featureSetState('Redémarrage programmé',true);}catch(e){featureSetState('Erreur');showMsg(e.message||'Redémarrage impossible.',false);}return;}
    if(action==='wol'){featureSetState('Envoi WOL…');try{const r=await post('api/admin_command.php',{action:'wol',agent_id:selectedDevice.agent_id});if(!r.ok)throw new Error(r.error||'WOL impossible');featureSetState('Paquet WOL envoyé',true);showMsg('Wake-on-LAN envoyé à '+(selectedDevice.hostname||'ce PC')+'.');}catch(e){featureSetState('Erreur');showMsg(e.message||'WOL impossible.',false);}return;}
}


function dmdMaintenanceStatusLabel(v){const m={none:'Aucun job',running:'En cours',stopping:'Arrêt en cours',cancelled:'Arrêté',completed:'Terminé',failed:'Échec',interrupted:'Interrompu'};return m[String(v||'').toLowerCase()]||String(v||'—');}
function dmdMaintenanceDate(v){try{return v?new Date(v).toLocaleString('fr-FR'):'—';}catch(_){return v||'—';}}
function dmdBackupStatusHtml(job){
    if(!job||job.status==='none')return '<div class="dmd-agent-data-empty">Aucune sauvegarde lancée depuis cet Agent.</div>';
    const s=job.summary&&typeof job.summary==='object'?job.summary:{},r=job.result&&typeof job.result==='object'?job.result:{},rows=Array.isArray(r.sources)?r.sources:[],target=s.target&&typeof s.target==='object'?s.target:{};
    const targetText=r.target_name||s.target_name||target.name||r.backup_root||s.destination||'—';
    const typeText=r.target_type||s.target_type||target.type||'';
    return '<div class="dmd-agent-maint-status '+htmlEsc(String(job.status||''))+'"><div class="dmd-agent-maint-status-head"><div><strong>'+htmlEsc(dmdMaintenanceStatusLabel(job.status))+'</strong><small>'+htmlEsc(job.job_id||'')+'</small></div><span>'+htmlEsc(dmdMaintenanceDate(job.completed_at||job.updated_at||job.started_at))+'</span></div>'+
        '<div class="dmd-agent-maint-kv"><span>Cible</span><strong>'+htmlEsc(targetText+(typeText?' · '+dmdBackupTargetTypeLabel(typeText):''))+'</strong><span>Sources</span><strong>'+htmlEsc(String(r.sources_total??(Array.isArray(s.sources)?s.sources.length:'—')))+'</strong><span>Durée</span><strong>'+htmlEsc(r.duration_seconds!=null?(r.duration_seconds+' s'):'—')+'</strong><span>Échecs</span><strong>'+htmlEsc(String(r.sources_failed??r.files_failed??0))+'</strong></div>'+
        (job.error?'<div class="dmd-agent-maint-error">'+htmlEsc(job.error)+'</div>':'')+
        (rows.length?'<div class="dmd-agent-maint-result-list">'+rows.map(x=>'<div><strong>'+htmlEsc(x.source||'Source')+'</strong><span>'+htmlEsc(x.status||'—')+'</span><small>'+htmlEsc(x.target||'')+'</small></div>').join('')+'</div>':'')+'</div>';
}
async function showFeatureBackup(){
    const agentId=selectedDevice&&selectedDevice.agent_id?String(selectedDevice.agent_id):'';
    if(!agentId)return;
    closeDevice();openAdminTab('backup');
    document.querySelectorAll('.dmd-backup-pc-target').forEach(cb=>{cb.checked=String(cb.value||'')===agentId;});
    const all=document.getElementById('backupAllAgents');if(all)all.checked=false;
    await dmdBackupSelectionChanged();
}

async function refreshBackupStatus(jobId=''){
    const host=document.getElementById('dmdBackupStatus'),state=document.getElementById('dmdBackupStatusState');if(!host)return;
    if(state)state.textContent='Lecture…';
    try{const r=await runDeviceAdminCommand('backup.files.status',jobId?{job_id:jobId}:{});host.innerHTML=dmdBackupStatusHtml(r);if(state)state.textContent=dmdMaintenanceStatusLabel(r&&r.status);setTilePreview('backup',dmdMaintenanceStatusLabel(r&&r.status),r&&r.started_at?('Depuis '+dmdMaintenanceDate(r.started_at)):'Sauvegarde fichiers');}
    catch(e){host.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'État sauvegarde indisponible.')+'</div>';if(state)state.textContent='Erreur';}
}
function dmdDefaultScanCidr(){const ip=selectedDevice&&String(selectedDevice.last_ip||'');const m=ip.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.\d{1,3}$/);return m?(m[1]+'.'+m[2]+'.'+m[3]+'.0/24'):'192.168.1.0/24';}
function dmdNetworkScanStatusHtml(job){
    if(!job||job.status==='none')return '<div class="dmd-agent-data-empty">Aucun scan réseau lancé depuis cet Agent.</div>';
    const s=job.summary&&typeof job.summary==='object'?job.summary:{},r=job.result&&typeof job.result==='object'?job.result:{},hosts=Array.isArray(r.hosts)?r.hosts:[];
    const scanned=r.hosts_scanned??s.hosts_scanned??'—',found=r.hosts_found??s.hosts_found??hosts.length,dur=r.duration_ms!=null?r.duration_ms:(s.elapsed_ms??null),phase=String(s.phase||'');
    const phaseText=phase==='dns'?'Résolution des noms…':phase==='discovery_done'?'Découverte terminée…':job.status==='running'?'Découverte en cours…':'';
    return '<div class="dmd-agent-maint-status '+htmlEsc(String(job.status||''))+'"><div class="dmd-agent-maint-status-head"><div><strong>'+htmlEsc(dmdMaintenanceStatusLabel(job.status))+'</strong><small>'+htmlEsc(job.job_id||'')+(phaseText?' · '+htmlEsc(phaseText):'')+'</small></div><span>'+htmlEsc(dmdMaintenanceDate(job.completed_at||job.updated_at||job.started_at))+'</span></div>'+
        '<div class="dmd-agent-maint-kv"><span>Réseau</span><strong>'+htmlEsc(r.cidr||s.cidr||'—')+'</strong><span>Hôtes scannés</span><strong>'+htmlEsc(String(scanned))+'</strong><span>Détectés</span><strong>'+htmlEsc(String(found))+'</strong><span>Durée</span><strong>'+htmlEsc(dur!=null?((dur/1000).toFixed(1)+' s'):'—')+'</strong></div>'+
        (job.error?'<div class="dmd-agent-maint-error">'+htmlEsc(job.error)+'</div>':'')+
        (hosts.length?'<div class="dmd-agent-scan-table"><div class="head"><span>IP</span><span>Nom</span><span>MAC</span><span>Ports</span></div>'+hosts.map(h=>'<div><strong>'+htmlEsc(h.ip||'—')+'</strong><span>'+htmlEsc(h.hostname||'—')+'</span><span>'+htmlEsc(h.mac||'—')+'</span><span>'+htmlEsc(Array.isArray(h.open_ports)&&h.open_ports.length?h.open_ports.join(', '):'—')+'</span></div>').join('')+'</div>':'')+(r.truncated?'<small>Affichage limité dans DoMyDesk ; le résultat complet reste enregistré localement sur le PC.</small>':'')+'</div>';
}

async function showFeatureNetworkScan(){
    const agentId=selectedDevice&&selectedDevice.agent_id?String(selectedDevice.agent_id):'';
    if(!agentId)return;
    closeDevice();openAdminTab('network-scan');
    const sel=document.getElementById('scanWorkspaceAgent');if(sel){sel.value=agentId;await dmdScanWorkspaceAgentChanged();}
}

async function refreshNetworkScanStatus(jobId=''){
    const host=document.getElementById('dmdScanStatus'),state=document.getElementById('dmdScanStatusState');if(!host)return;
    if(state)state.textContent='Lecture…';
    try{const r=await runDeviceAdminCommand('network.scan.status',jobId?{job_id:jobId}:{});host.innerHTML=dmdNetworkScanStatusHtml(r);if(state)state.textContent=dmdMaintenanceStatusLabel(r&&r.status);setTilePreview('network-scan',dmdMaintenanceStatusLabel(r&&r.status),r&&r.result&&r.result.hosts_found!=null?(r.result.hosts_found+' équipement(s) détecté(s)'):'Sonde réseau');}
    catch(e){host.innerHTML='<div class="dmd-agent-data-empty">'+htmlEsc(e.message||'État scan indisponible.')+'</div>';if(state)state.textContent='Erreur';}
}

async function openFeatureByName(name){
    if(!selectedDevice)return;
    if(name==='network')return showFeatureNetworkAdmin();
    if(name==='machine')return showFeatureMachineAdmin();
    if(name==='sessions')return showFeatureSessionsAdmin();
    if(name==='ports')return showFeaturePortsAdmin('');
    if(name==='storage')return showFeatureStorageAdmin();
    if(name==='backup')return showFeatureBackup();
    if(name==='network-scan')return showFeatureNetworkScan();
    if(name==='processes')return showFeatureProcesses(0);
    if(name==='services')return showFeatureServices(0);
    if(name==='terminal')return openAdminTerminal();
    if(name==='software')return openSoftwareManager();
    if(name==='updates')return showFeatureUpdates();
    if(name==='security')return showFeatureSecurityAdmin();
    if(name==='registry')return showRegistry('HKLM','');
    if(name==='usb')return showUsb();
    if(name==='network-paths')return showNetworkPaths();
    if(name==='control')return showControl();
}

function restoreDevicePreviousWorkspace(){
    const prev=devicePreviousWorkspace||{type:'fleet',name:'dashboard'};
    if(prev.type==='admin'&&prev.name)openAdminTab(prev.name);else if(prev.type==='fleet')openWorkspaceFleet(prev.name||'dashboard');else openWorkspaceFleet('dashboard');
}
function closeDevice(){
    if(deviceFeatureModal)deviceFeatureModal.hidden=true;if(terminalModal)terminalModal.hidden=true;if(softwareModal)softwareModal.hidden=true;
    stopAgentInteractive();if(modal)modal.hidden=true;selectedDevice=null;workspaceState={type:'fleet',name:'dashboard'};document.body.classList.remove('dmd-agent-modal-open');restoreDevicePreviousWorkspace();
}
document.querySelectorAll('[data-device-open]').forEach(b=>b.addEventListener('click',e=>{
    if(e.target.closest('button,a,input,select,textarea,label'))return;
    openDevice(b.dataset.deviceOpen);
}));
document.querySelectorAll('[data-device-quick]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(b.disabled)return;const agentId=b.dataset.agentId||'';const feature=b.dataset.deviceQuick||'';openDevice(agentId);setTimeout(()=>openFeatureByName(feature),0);}));
document.querySelectorAll('[data-device-open][tabindex]').forEach(r=>r.addEventListener('keydown',e=>{
    if((e.key==='Enter'||e.key===' ')&&!e.target.closest('button,a,input,select,textarea,label')){
        e.preventDefault();
        openDevice(r.dataset.deviceOpen);
    }
}));
document.querySelectorAll('[data-close-device]').forEach(b=>b.addEventListener('click',closeDevice));

document.querySelectorAll('[data-device-feature]').forEach(b=>b.addEventListener('click',()=>{if(b.disabled)return;openFeatureByName(b.dataset.deviceFeature);}));
document.querySelectorAll('[data-close-feature]').forEach(b=>b.addEventListener('click',closeDeviceFeature));
if(deviceFeatureBody)deviceFeatureBody.addEventListener('click',async e=>{
    const po=e.target.closest('[data-feature-process-offset]');if(po){showFeatureProcesses(Number(po.dataset.featureProcessOffset||0));return;}
    const so=e.target.closest('[data-feature-services-offset]');if(so){showFeatureServices(Number(so.dataset.featureServicesOffset||0));return;}
    const kill=e.target.closest('[data-feature-kill]');if(kill){const pid=Number(kill.dataset.featureKill||0);if(pid&&confirm('Arrêter le PID '+pid+' ?')){try{await runDeviceAdminCommand('processes.kill',{pid});await showFeatureProcesses(0);}catch(err){showMsg(err.message||'Arrêt impossible.',false);}}return;}
    const rp=e.target.closest('[data-feature-restart-process]');if(rp){const pid=Number(rp.dataset.featureRestartProcess||0);if(pid&&confirm('Arrêter puis relancer le PID '+pid+' ?')){try{await runDeviceAdminCommand('processes.restart',{pid});await showFeatureProcesses(0);}catch(err){showMsg(err.message||'Relance impossible.',false);}}return;}
    const svc=e.target.closest('[data-feature-service]');if(svc){const name=svc.dataset.featureService||'',op=svc.dataset.featureServiceOp||'restart';try{await runDeviceAdminCommand('services.control',{name,operation:op});await showFeatureServices(0);}catch(err){showMsg(err.message||'Action service impossible.',false);}return;}
    if(e.target.closest('[data-feature-windows-scan]')){featureWindowsUpdate('scan');return;}
    if(e.target.closest('[data-feature-windows-install]')){featureWindowsUpdate('install');return;}
    if(e.target.closest('[data-feature-windows-history]')){featureWindowsHistory();return;}
    if(e.target.closest('[data-feature-updates-scan]')){featureUpdatesScan();return;}
    if(e.target.closest('[data-feature-updates-apply]')){featureUpdatesApply();return;}
    if(e.target.closest('[data-feature-agent-update]')){featureAgentUpdate();return;}
    if(e.target.closest('[data-feature-agent-refresh]')){featureRefreshUpdateInfo(true);return;}
    if(e.target.closest('[data-feature-update-packages]')){featureOpenUpdatePackages();return;}
    if(e.target.closest('[data-update-packages-close]')){featureCloseUpdatePackages();return;}
    if(e.target.closest('[data-update-packages-refresh]')){featureLoadUpdatePackages().catch(err=>showMsg(err.message||'Actualisation impossible.',false));return;}
    if(e.target.closest('[data-update-packages-delete]')){featureDeleteUpdatePackages().catch(err=>showMsg(err.message||'Suppression impossible.',false));return;}
    if(e.target.closest('[data-update-packages-pick]')){document.getElementById('deviceUpdateZipInput')?.click();return;}
    if(e.target.closest('[data-feature-pc-restart]')){featureSchedulePcRestart();return;}
    if(e.target.closest('[data-backup-run]')){const sources=String(document.getElementById('dmdBackupSources')?.value||'').split(/\r?\n/).map(v=>v.trim()).filter(Boolean),destination=String(document.getElementById('dmdBackupDestination')?.value||'').trim(),backup_name=String(document.getElementById('dmdBackupName')?.value||'DoMyDesk').trim(),exclude_dirs=String(document.getElementById('dmdBackupExcludeDirs')?.value||'').split(/\r?\n/).map(v=>v.trim()).filter(Boolean),exclude_files=String(document.getElementById('dmdBackupExcludeFiles')?.value||'').split(/\r?\n/).map(v=>v.trim()).filter(Boolean);if(!sources.length||!destination){showMsg('Indique au moins une source et une destination.',false);return;}if(!confirm('Lancer la sauvegarde de '+sources.length+' source(s) vers '+destination+' ?'))return;featureSetState('Lancement…');try{const r=await runDeviceAdminCommand('backup.files.start',{sources,destination,backup_name,exclude_dirs,exclude_files});featureSetState('Sauvegarde lancée',true);showMsg('Sauvegarde lancée : '+(r.job_id||'job créé')+'.');await refreshBackupStatus(r.job_id||'');}catch(err){featureSetState('Erreur');showMsg(err.message||'Sauvegarde impossible.',false);}return;}
    if(e.target.closest('[data-backup-refresh]')){refreshBackupStatus();return;}
    if(e.target.closest('[data-network-scan-run]')){const cidr=String(document.getElementById('dmdScanCidr')?.value||'').trim(),ports=String(document.getElementById('dmdScanPorts')?.value||'').split(/[,;\s]+/).map(v=>Number(v)).filter(v=>Number.isInteger(v)&&v>0&&v<=65535),timeout_ms=Number(document.getElementById('dmdScanTimeout')?.value||250),resolve_names=!!document.getElementById('dmdScanResolve')?.checked;if(!cidr){showMsg('Indique un réseau CIDR.',false);return;}if(!confirm('Scanner '+cidr+' depuis '+(selectedDevice.hostname||'ce PC')+' ?'))return;featureSetState('Scan lancé…');try{const r=await runDeviceAdminCommand('network.scan.start',{cidr,ports,timeout_ms,resolve_names});featureSetState('Scan en arrière-plan',true);showMsg('Scan réseau lancé : '+(r.job_id||'job créé')+'.');await refreshNetworkScanStatus(r.job_id||'');}catch(err){featureSetState('Erreur');showMsg(err.message||'Scan impossible.',false);}return;}
    if(e.target.closest('[data-network-scan-refresh]')){refreshNetworkScanStatus();return;}
    const nc=e.target.closest('[data-net-control]');if(nc){const alias=nc.dataset.netAlias||'',operation=nc.dataset.netControl||'restart';if(operation==='disable'&&!confirm('Désactiver la carte '+alias+' ? La communication avec ce PC peut être coupée.'))return;try{await runDeviceAdminCommand('network.adapter.control',{alias,operation});await showFeatureNetworkAdmin();}catch(err){showMsg(err.message||'Action réseau impossible.',false);}return;}
    if(e.target.closest('[data-network-refresh]')){showFeatureNetworkAdmin();return;}
    if(e.target.closest('[data-sessions-refresh]')){showFeatureSessionsAdmin();return;}
    const sa=e.target.closest('[data-session-action]');if(sa){const session_id=Number(sa.dataset.sessionId||0),op=sa.dataset.sessionAction||'';if(!session_id)return;if(!confirm((op==='logoff'?'Fermer':'Déconnecter')+' la session #'+session_id+' ?'))return;try{await runDeviceAdminCommand(op==='logoff'?'sessions.logoff':'sessions.disconnect',{session_id});await showFeatureSessionsAdmin();}catch(err){showMsg(err.message||'Action session impossible.',false);}return;}
    if(e.target.closest('[data-ports-refresh]')){showFeaturePortsAdmin(document.querySelector('#firewallSearchForm input[name=query]')?.value||'',0,0);return;}
    const pp=e.target.closest('[data-ports-page]');if(pp){showFeaturePortsAdmin(document.querySelector('#firewallSearchForm input[name=query]')?.value||'',Number(pp.dataset.portsPage||0),Number(pp.dataset.fwPage||0));return;}
    const fwp=e.target.closest('[data-firewall-page]');if(fwp){showFeaturePortsAdmin(document.querySelector('#firewallSearchForm input[name=query]')?.value||'',Number(fwp.dataset.portPage||0),Number(fwp.dataset.firewallPage||0));return;}
    const ft=e.target.closest('[data-firewall-toggle]');if(ft){const r=firewallStateRules[Number(ft.dataset.firewallToggle)];if(!r)return;try{await runDeviceAdminCommand('firewall.set',{name:r.name,display_name:r.display_name||r.name,direction:String(r.direction||'inbound').toLowerCase(),action:String(r.action||'allow').toLowerCase(),protocol:String(r.protocol||'ANY').toUpperCase(),local_port:r.local_port||'',remote_port:r.remote_port||'',program:r.program||'',remote_address:r.remote_address||'',enabled:!dmdTruthy(r.enabled)});await showFeaturePortsAdmin('');}catch(err){showMsg(err.message||'Modification firewall impossible.',false);}return;}
    const fa=e.target.closest('[data-firewall-action-toggle]');if(fa){const r=firewallStateRules[Number(fa.dataset.firewallActionToggle)];if(!r)return;const action=String(r.action||'allow').toLowerCase()==='allow'?'block':'allow';if(!confirm((action==='block'?'Bloquer':'Autoriser')+' le trafic de la règle « '+(r.display_name||r.name)+' » ?'))return;try{await runDeviceAdminCommand('firewall.set',{name:r.name,display_name:r.display_name||r.name,direction:String(r.direction||'inbound').toLowerCase(),action,protocol:String(r.protocol||'ANY').toUpperCase(),local_port:r.local_port||'',remote_port:r.remote_port||'',program:r.program||'',remote_address:r.remote_address||'',enabled:dmdTruthy(r.enabled)});await showFeaturePortsAdmin('');}catch(err){showMsg(err.message||'Modification firewall impossible.',false);}return;}
    const fd=e.target.closest('[data-firewall-delete]');if(fd){const name=fd.dataset.firewallDelete||'';if(name&&confirm('Supprimer la règle pare-feu « '+name+' » ?')){try{await runDeviceAdminCommand('firewall.delete',{name});await showFeaturePortsAdmin('');}catch(err){showMsg(err.message||'Suppression firewall impossible.',false);}}return;}
    if(e.target.closest('[data-storage-refresh]')){showFeatureStorageAdmin();return;}
    const fdrive=e.target.closest('[data-format-drive]');if(fdrive){const drive=String(fdrive.dataset.formatDrive||'').replace(':','');const fs=prompt('Système de fichiers pour '+drive+': (NTFS, EXFAT ou FAT32)','NTFS');if(!fs)return;const label=prompt('Nom du volume (facultatif)','')??'';if(!confirm('ATTENTION : toutes les données de '+drive+': seront supprimées. Confirmer le formatage ?'))return;try{await runDeviceAdminCommand('storage.format',{confirm:true,drive_letter:drive,filesystem:fs,label});await showFeatureStorageAdmin();}catch(err){showMsg(err.message||'Formatage impossible.',false);}return;}
    const fdisk=e.target.closest('[data-format-disk]');if(fdisk){const disk_number=Number(fdisk.dataset.formatDisk);const typed=prompt('EFFACEMENT TOTAL DU DISQUE '+disk_number+'. Tape exactement : EFFACER '+disk_number,'');if(typed!=='EFFACER '+disk_number)return;const fs=prompt('Système de fichiers du nouveau volume','NTFS');if(!fs)return;try{await runDeviceAdminCommand('storage.format',{confirm:true,disk_number,whole_disk:true,filesystem:fs,label:''});await showFeatureStorageAdmin();}catch(err){showMsg(err.message||'Formatage disque impossible.',false);}return;}
    if(e.target.closest('[data-files-roots]')){try{await showFileRoots();}catch(err){showMsg(err.message||'Lecture lecteurs impossible.',false);}return;}
    if(e.target.closest('[data-files-refresh]')){try{dmdFileState.path?await showFilePath(dmdFileState.path,dmdFileState.offset):await showFileRoots();}catch(err){showMsg(err.message||'Actualisation impossible.',false);}return;}
    const fo=e.target.closest('[data-file-open]');if(fo){try{await showFilePath(fo.dataset.fileOpen||'',0);}catch(err){showMsg(err.message||'Dossier inaccessible.',false);}return;}
    const fp=e.target.closest('[data-file-page]');if(fp){try{await showFilePath(dmdFileState.path,Number(fp.dataset.filePage||0));}catch(err){showMsg(err.message||'Page inaccessible.',false);}return;}
    const fdl=e.target.closest('[data-file-download]');if(fdl){try{await downloadAgentFile(fdl.dataset.fileDownload||'');}catch(err){showMsg(err.message||'Téléchargement impossible.',false);}return;}
    const fr=e.target.closest('[data-file-rename]');if(fr){const old=fr.dataset.fileName||'',name=prompt('Nouveau nom',old);if(!name||name===old)return;try{await runDeviceAdminCommand('filesystem.rename',{path:fr.dataset.fileRename||'',name});await showFilePath(dmdFileState.path,0);}catch(err){showMsg(err.message||'Renommage impossible.',false);}return;}
    const fdel=e.target.closest('[data-file-delete]');if(fdel){const path=fdel.dataset.fileDelete||'',recursive=fdel.dataset.fileDir==='1';if(!confirm('Supprimer définitivement '+path+(recursive?' et tout son contenu':'')+' ?'))return;try{await runDeviceAdminCommand('filesystem.delete',{path,recursive});await showFilePath(dmdFileState.path,0);}catch(err){showMsg(err.message||'Suppression impossible.',false);}return;}
    if(e.target.closest('[data-file-mkdir]')){if(!dmdFileState.path){showMsg('Ouvre d’abord un lecteur ou un dossier.',false);return;}const name=prompt('Nom du nouveau dossier','Nouveau dossier');if(!name)return;try{await runDeviceAdminCommand('filesystem.mkdir',{path:dmdFileState.path,name});await showFilePath(dmdFileState.path,0);}catch(err){showMsg(err.message||'Création impossible.',false);}return;}
    const da=e.target.closest('[data-defender-action]');if(da){const operation=da.dataset.defenderAction||'';if(operation==='realtime_disable'&&!confirm('Désactiver la protection temps réel Microsoft Defender ?'))return;featureSetState('Action Defender…');try{await runDeviceAdminCommand('security.defender.action',{operation});await showFeatureSecurityAdmin();}catch(err){showMsg(err.message||'Action Defender impossible.',false);featureSetState('Erreur');}return;}
    const ug=e.target.closest('[data-usb-global]');if(ug){const block=ug.dataset.usbGlobal==='block';if(block&&!confirm('Bloquer le stockage USB sur ce PC ? Les périphériques USB de stockage seront désactivés.'))return;try{await runDeviceAdminCommand(block?'devices.removable.block':'devices.removable.unblock',{global:true});await showUsb();showMsg(block?'Stockage USB bloqué.':'Stockage USB débloqué.');}catch(err){showMsg(err.message||'Action USB impossible.',false);}return;}
    const ub=e.target.closest('[data-usb-browse]');if(ub){const letter=String(ub.dataset.usbBrowse||'').replace(':','');await showFeatureStorageAdmin();try{await showFilePath(letter+':\\',0);}catch(err){showMsg(err.message||'Lecture USB impossible.',false);}return;}
    const uf=e.target.closest('[data-usb-format]');if(uf){const drive=String(uf.dataset.usbFormat||'').replace(':','');if(!confirm('ATTENTION : toutes les données de '+drive+': seront supprimées. Formater en EXFAT ?'))return;try{await runDeviceAdminCommand('storage.format',{confirm:true,drive_letter:drive,filesystem:'EXFAT',label:''});await showUsb();}catch(err){showMsg(err.message||'Formatage USB impossible.',false);}return;}
    const redit=e.target.closest('[data-registry-edit-value]');if(redit){const form=document.getElementById('registrySetForm');if(form){form.elements.name.value=redit.dataset.registryEditValue||'';const rawType=String(redit.dataset.registryEditType||'String').toLowerCase();const map={string:'string',expandstring:'expandstring',multistring:'multistring',dword:'dword',qword:'qword',binary:'binary'};form.elements.value_type.value=map[rawType]||'string';form.elements.value.value=redit.dataset.registryEditData||'';form.elements.value.focus();}return;}
    const rdel=e.target.closest('[data-registry-delete-value]');if(rdel){const name=rdel.dataset.registryDeleteValue||'';if(!confirm('Supprimer cette valeur du registre ?'))return;try{await runDeviceAdminCommand('registry.delete',{hive:registryState.hive,path:registryState.path,name,scope:'value'});await showRegistry(registryState.hive,registryState.path);}catch(err){showMsg(err.message||'Suppression registre impossible.',false);}return;}
    const rkeydel=e.target.closest('[data-registry-delete-key]');if(rkeydel){const path=rkeydel.dataset.registryDeleteKey||'';if(!path||!confirm('Supprimer la clé '+registryState.hive+'\\'+path+' et toutes ses sous-clés ?'))return;try{await runDeviceAdminCommand('registry.delete',{hive:registryState.hive,path,name:'',scope:'key',recursive:true});await showRegistry(registryState.hive,registryState.path);}catch(err){showMsg(err.message||'Suppression clé impossible.',false);}return;}
    const rk=e.target.closest('[data-registry-key]');if(rk){showRegistry(registryState.hive,rk.dataset.registryKey||'');return;}
    if(e.target.closest('[data-registry-up]')){const p=registryState.path.split('\\').filter(Boolean);p.pop();showRegistry(registryState.hive,p.join('\\'));return;}
    if(e.target.closest('[data-registry-go]')){const h=document.getElementById('registryHive')?.value||'HKLM',p=document.getElementById('registryPath')?.value||'';showRegistry(h,p);return;}
    const ej=e.target.closest('[data-usb-eject]');if(ej){const letter=ej.dataset.usbEject||'';if(letter&&confirm('Éjecter '+letter+' ?')){try{await runDeviceAdminCommand('devices.removable.eject',{letter});await showUsb();}catch(err){showMsg(err.message||'Éjection impossible.',false);}}return;}
    const nr=e.target.closest('[data-network-remove]');if(nr){const local_path=nr.dataset.networkRemove||'';if(local_path&&confirm('Retirer le lecteur réseau '+local_path+' ?')){try{await runDeviceAdminCommand('network.paths.remove',{local_path});await showNetworkPaths();}catch(err){showMsg(err.message||'Suppression impossible.',false);}}return;}
    const ca=e.target.closest('[data-control-action]');if(ca){runControlAction(ca.dataset.controlAction);return;}
});
if(deviceFeatureBody)deviceFeatureBody.addEventListener('submit',async e=>{
    const netp=e.target.closest('#networkPathAddForm');if(netp){e.preventDefault();const fd=new FormData(netp);const local_path=String(fd.get('local')||'').trim(),remote_path=String(fd.get('remote')||'').trim();if(!local_path||!remote_path)return;try{await runDeviceAdminCommand('network.paths.add',{local_path,remote_path});await showNetworkPaths();}catch(err){showMsg(err.message||'Ajout du chemin réseau impossible.',false);}return;}
    const ps=e.target.closest('#processStartForm');if(ps){e.preventDefault();const fd=new FormData(ps),path=String(fd.get('path')||'').trim(),arguments=String(fd.get('arguments')||'').trim();if(!path)return;try{await runDeviceAdminCommand('processes.start',{path,arguments});await showFeatureProcesses(0);showMsg('Processus lancé.');}catch(err){showMsg(err.message||'Lancement impossible.',false);}return;}
    const rn=e.target.closest('#machineRenameForm');if(rn){e.preventDefault();const fd=new FormData(rn),new_name=String(fd.get('new_name')||'').trim().toUpperCase();if(!new_name)return;if(!confirm('Renommer '+(selectedDevice?.hostname||'ce PC')+' en '+new_name+' ? Le changement sera effectif après redémarrage.'))return;try{const r=await runDeviceAdminCommand('system.rename',{new_name});showMsg('PC renommé en '+new_name+(r&&r.reboot_required?' · redémarrage requis.':'.'));featureSetState('Renommé · redémarrage requis',true);}catch(err){showMsg(err.message||'Renommage impossible.',false);}return;}
    const nc=e.target.closest('[data-network-config-form]');if(nc){e.preventDefault();const fd=new FormData(nc),alias=nc.dataset.alias||'',dhcp=fd.get('dhcp')!==null,ipv4=String(fd.get('ipv4')||'').trim(),prefix_length=Number(fd.get('prefix')||24),gateway=String(fd.get('gateway')||'').trim(),dns=String(fd.get('dns')||'').split(/[,;\s]+/).filter(Boolean),restart=fd.get('restart')!==null;if(!dhcp&&!ipv4){showMsg('IPv4 requise en mode statique.',false);return;}if(!confirm('Appliquer cette configuration à « '+alias+' » ? Une mauvaise IP peut couper la communication avec DoMyDesk.'))return;try{await runDeviceAdminCommand('network.configure',{alias,dhcp,ipv4,prefix_length,gateway,dns,restart});showMsg('Configuration réseau appliquée.');await showFeatureNetworkAdmin();}catch(err){showMsg(err.message||'Configuration réseau impossible.',false);}return;}
    const fwq=e.target.closest('#firewallSearchForm');if(fwq){e.preventDefault();const fd=new FormData(fwq);showFeaturePortsAdmin(String(fd.get('query')||'').trim(),Number(fd.get('port_offset')||0),0);return;}
    const fwa=e.target.closest('#firewallAddForm');if(fwa){e.preventDefault();const fd=new FormData(fwa),p={name:String(fd.get('name')||'').trim(),display_name:String(fd.get('name')||'').trim(),direction:String(fd.get('direction')||'inbound'),action:String(fd.get('action')||'allow'),protocol:String(fd.get('protocol')||'ANY'),local_port:String(fd.get('local_port')||'').trim(),remote_port:String(fd.get('remote_port')||'').trim(),program:String(fd.get('program')||'').trim(),remote_address:String(fd.get('remote_address')||'').trim(),enabled:true};if(!p.name)return;try{await runDeviceAdminCommand('firewall.add',p);showMsg('Règle pare-feu ajoutée.');await showFeaturePortsAdmin('');}catch(err){showMsg(err.message||'Ajout firewall impossible.',false);}return;}
    const rs=e.target.closest('#registrySetForm');if(rs){e.preventDefault();const fd=new FormData(rs),name=String(fd.get('name')||''),value_type=String(fd.get('value_type')||'string'),value=String(fd.get('value')||'');try{await runDeviceAdminCommand('registry.set',{hive:registryState.hive,path:registryState.path,name,value_type,value});showMsg('Valeur registre enregistrée.');await showRegistry(registryState.hive,registryState.path);}catch(err){showMsg(err.message||'Écriture registre impossible.',false);}return;}

});
if(deviceFeatureBody)deviceFeatureBody.addEventListener('change',async e=>{
    if(e.target.id==='deviceFeatureUpdateRebootMode'){dmdRebootControlsSync('deviceFeatureUpdateReboot');return;}
    if(e.target.id==='deviceFeatureManualRebootMode'){dmdRebootControlsSync('deviceFeatureManualReboot');return;}
    const sm=e.target.closest('[data-service-startmode]');if(sm){try{await runDeviceAdminCommand('services.configure',{name:sm.dataset.serviceStartmode||'',start_mode:sm.value});showMsg('Type de démarrage du service modifié.');await showFeatureServices(0);}catch(err){showMsg(err.message||'Configuration service impossible.',false);}return;}
    if(e.target.id==='dmdFileUpload'){const file=e.target.files&&e.target.files[0];if(file){try{await uploadAgentFile(file);}catch(err){showMsg(err.message||'Envoi fichier impossible.',false);}e.target.value='';}}
});


document.querySelectorAll('#deviceModal .dmd-agent-action-tile').forEach(b=>b.addEventListener('click',()=>{if(b.disabled)return;showMsg(b.querySelector('strong').textContent+' : capability autorisée.');}));
document.getElementById('deviceLoadProcesses').addEventListener('click',loadAdminProcesses);
document.getElementById('deviceLoadServices').addEventListener('click',loadAdminServices);
document.getElementById('deviceOpenSoftware').addEventListener('click',openSoftwareManager);
document.querySelectorAll('[data-close-software]').forEach(b=>b.addEventListener('click',closeSoftwareManager));
document.getElementById('softwareRefresh').addEventListener('click',()=>loadAdminSoftware(0));
document.getElementById('softwareInstallButton').addEventListener('click',installSelectedSoftware);
document.getElementById('softwareUpdatesScan').addEventListener('click',scanAdminSoftwareUpdates);
document.getElementById('softwareUpdatesApply').addEventListener('click',applyAdminSoftwareUpdates);
document.getElementById('softwareWingetSearch')?.addEventListener('click',searchSoftwareWinget);
document.getElementById('softwareWingetInstall')?.addEventListener('click',()=>runSoftwareWinget('install'));
document.getElementById('softwareWingetUninstall')?.addEventListener('click',()=>runSoftwareWinget('uninstall'));
document.getElementById('softwareWingetId')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchSoftwareWinget();}});
document.getElementById('softwareSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();loadAdminSoftware(0);}});
document.getElementById('softwarePager').addEventListener('click',e=>{const b=e.target.closest('[data-software-page]');if(b)loadAdminSoftware(Number(b.dataset.softwarePage||0));});
document.getElementById('softwareWingetResults')?.addEventListener('click',async e=>{
    const b=e.target.closest('[data-winget-install-id]');if(!b)return;
    const id=String(b.dataset.wingetInstallId||'').trim();if(!id)return;
    const input=document.getElementById('softwareWingetId');if(input)input.value=id;
    await runSoftwareWinget('install');
});
document.getElementById('softwareList').addEventListener('click',async e=>{
    const b=e.target.closest('[data-software-id]');if(!b||!selectedDevice)return;
    const id=b.dataset.softwareId||'',name=b.dataset.softwareName||'ce logiciel';
    if(!confirm('Désinstaller '+name+' de '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    b.disabled=true;softwareSetState('Désinstallation…');
    try{
        const r=await runDeviceAdminCommand('software.uninstall',{id});
        softwareSetState(r&&r.reboot_required?'Désinstallé · redémarrage requis':'Désinstallé',true);
        showMsg('Logiciel désinstallé'+(r&&r.reboot_required?' · redémarrage requis.':'.'));
        await loadAdminSoftware(softwarePageOffset);
    }catch(err){const reason=err.message||'erreur';softwareSetState('Erreur · '+reason);showMsg('Désinstallation impossible : '+reason,false);}
    finally{b.disabled=false;}
});
document.getElementById('deviceOpenTerminal').addEventListener('click',openAdminTerminal);
document.querySelectorAll('[data-close-terminal]').forEach(b=>b.addEventListener('click',closeAdminTerminal));
document.getElementById('deviceTerminalRun').addEventListener('click',runAdminTerminal);
document.getElementById('deviceTerminalClear').addEventListener('click',()=>{
    const out=document.getElementById('deviceTerminalOutput');
    if(out)out.textContent='';
    const input=document.getElementById('deviceTerminalInput');
    if(input)input.focus();
});
document.getElementById('deviceRestartPc').addEventListener('click',async()=>{if(!selectedDevice||!confirm('Redémarrer '+(selectedDevice.hostname||'ce PC')+' ? Le redémarrage sera programmé dans environ 60 secondes.'))return;try{const r=await runDeviceAdminCommand('system.restart',{delay_seconds:60});document.getElementById('deviceCommandResult').innerHTML='<div class="dmd-agent-data-empty">Redémarrage programmé dans '+htmlEsc(r&&r.delay_seconds||60)+' seconde(s).</div>';showMsg('Redémarrage programmé.');}catch(err){showMsg(err.message||'Redémarrage impossible.',false);}});
document.getElementById('deviceShutdownPc').addEventListener('click',async()=>{if(!selectedDevice||!confirm('Éteindre '+(selectedDevice.hostname||'ce PC')+' ? L’arrêt sera programmé dans environ 60 secondes.'))return;try{const r=await runDeviceAdminCommand('system.shutdown',{delay_seconds:60});document.getElementById('deviceCommandResult').innerHTML='<div class="dmd-agent-data-empty">Arrêt programmé dans '+htmlEsc(r&&r.delay_seconds||60)+' seconde(s).</div>';showMsg('Arrêt programmé.');}catch(err){showMsg(err.message||'Arrêt impossible.',false);}});
document.getElementById('deviceCommandResult').addEventListener('click',async e=>{
    const pp=e.target.closest('[data-admin-process-offset]');if(pp){await loadAdminProcesses(Number(pp.dataset.adminProcessOffset||0));return;}
    const sp=e.target.closest('[data-admin-services-offset]');if(sp){await loadAdminServices(Number(sp.dataset.adminServicesOffset||0));return;}
    const kill=e.target.closest('[data-admin-kill]');
    if(kill){const pid=Number(kill.dataset.adminKill||0);if(!pid||!confirm('Arrêter le PID '+pid+' ?'))return;try{await runDeviceAdminCommand('processes.kill',{pid});showMsg('Processus arrêté.');await loadAdminProcesses();}catch(err){showMsg(err.message||'Arrêt impossible.',false);}return;}
    const svc=e.target.closest('[data-admin-service]');
    if(svc){const name=svc.dataset.adminService||'',op=svc.dataset.adminServiceOp||'restart';if(!name)return;try{await runDeviceAdminCommand('services.control',{name,operation:op});showMsg('Service '+name+' : '+op+' OK.');await loadAdminServices();}catch(err){showMsg(err.message||'Action service impossible.',false);}return;}
});
document.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target&&e.target.id==='deviceTerminalInput'){e.preventDefault();runAdminTerminal();return;}if(e.key==='Escape'&&terminalModal&&!terminalModal.hidden){closeAdminTerminal();return;}if(e.key==='Escape'&&softwareModal&&!softwareModal.hidden){closeSoftwareManager();return;}if(e.key==='Escape'&&!modal.hidden)closeDevice();});


/* ============================================================
   Maintenance — quatre fenêtres popup indépendantes.
   Installation logiciels : sélection PC intégrée + recherche Winget native.
   ============================================================ */
const MAINTENANCE_POPUPS={
    'software-bulk':document.getElementById('maintenanceSoftwareBulkModal'),
    'software-updates':document.getElementById('maintenanceSoftwareUpdatesModal'),
    'agent-update':document.getElementById('maintenanceAgentUpdateModal'),
    'pc-update':document.getElementById('maintenancePcUpdateModal'),
    'mydesk-config':document.getElementById('maintenanceMyDeskModal')
};
const MAINT_SOFTWARE_PC_MODAL=null;
let MAINT_UPDATE_LOG_ROWS=[];
let MAINT_SOFTWARE_LIBRARY=[];
let MAINT_WINGET_RESULTS=[];
const MAINT_SOFTWARE_SELECTED=new Set();
const MAINT_SOFTWARE_PC_SELECTED=new Set();

const MAINTENANCE_CARDS=Object.fromEntries(Object.entries(MAINTENANCE_POPUPS).map(([k,el])=>[k,el?el.querySelector(':scope > section'):null]));
let maintenancePreviousWorkspace={type:'fleet',name:'fleet'};
function maintOpen(name){
    const el=MAINTENANCE_POPUPS[name],card=MAINTENANCE_CARDS[name];
    if(!el||!card)return;
    if(workspaceState.type!=='maintenance')maintenancePreviousWorkspace={...workspaceState};
    hideInlineEndpointPages();hideToolPanels();hideWorkspacePanes();
    Object.entries(MAINTENANCE_CARDS).forEach(([k,c])=>{
        if(!c)return;
        c.classList.remove('dmd-maint-inline-page');
        const wrap=MAINTENANCE_POPUPS[k];
        if(c.parentElement!==wrap)wrap.appendChild(c);
        wrap.hidden=true;
    });
    if(MAINT_SOFTWARE_PC_MODAL)MAINT_SOFTWARE_PC_MODAL.hidden=true;
    if(card.parentElement!==workspaceToolHost)workspaceToolHost.appendChild(card);
    card.classList.add('dmd-maint-inline-page');
    if(workspaceTools)workspaceTools.hidden=false;
    workspaceState={type:'maintenance',name:name};
    setWorkspaceNavActive('popup:'+name);
    document.body.classList.remove('dmd-agent-modal-open');
    if(name==='software-bulk'){
        maintLoadSoftwareLibrary();
        maintSyncSoftwarePcChecks();
        maintUpdateSoftwareSelectionUi();
    }
    if(name==='agent-update'){
        if(typeof r19OpenUpdateTab==='function')r19OpenUpdateTab('overview');
        const gp=document.getElementById('maintAgentGlobalProgress');if(gp)gp.hidden=true;
        const rs=document.getElementById('maintAgentUpdateRunState');if(rs)rs.textContent='Aucune mise à jour lancée.';
        maintLoadUpdateRepository(false).catch(e=>showMsg(e.message||'Dépôt des mises à jour indisponible.',false));
        maintLoadUpdateLogs(false).catch(e=>{const body=document.getElementById('maintUpdateLogsRows');if(body)body.innerHTML='<tr><td colspan="7" class="dmd-update-log-empty">Erreur : '+htmlEsc(e.message||'journal indisponible')+'</td></tr>';});
    }
    if(name==='mydesk-config')maintRefreshMyDeskCount();
}
function maintClose(){
    Object.entries(MAINTENANCE_CARDS).forEach(([k,c])=>{
        if(!c)return;
        c.classList.remove('dmd-maint-inline-page');
        const wrap=MAINTENANCE_POPUPS[k];
        if(c.parentElement!==wrap)wrap.appendChild(c);
        wrap.hidden=true;
    });
    if(MAINT_SOFTWARE_PC_MODAL)MAINT_SOFTWARE_PC_MODAL.hidden=true;
    const prev=maintenancePreviousWorkspace||{type:'fleet',name:'fleet'};
    if(prev.type==='admin'&&prev.name)openAdminTab(prev.name);else openWorkspaceFleet();
    if(modal.hidden && (!terminalModal||terminalModal.hidden) && (!softwareModal||softwareModal.hidden))document.body.classList.remove('dmd-agent-modal-open');
}
document.querySelectorAll('[data-maintenance-popup]').forEach(b=>b.addEventListener('click',()=>maintOpen(b.dataset.maintenancePopup)));
document.querySelectorAll('[data-maint-close]').forEach(b=>b.addEventListener('click',maintClose));

function maintUpdateLogDate(row){
    const ts=Number(row&&row.timestamp||0);
    if(ts>0)return new Date(ts*1000).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const iso=String(row&&row.date_iso||'').trim();
    if(!iso)return '—';
    const d=new Date(iso);return Number.isNaN(d.getTime())?iso:d.toLocaleString('fr-FR');
}
function maintUpdateLogActor(row){
    const name=String(row&&row.actor_name||'').trim(),mail=String(row&&row.actor||'').trim();
    if(name&&mail)return `<strong>${htmlEsc(name)}</strong><small>${htmlEsc(mail)}</small>`;
    return `<strong>${htmlEsc(name||mail||'Système / Agent')}</strong>`;
}
function maintUpdateLogsRender(){
    const body=document.getElementById('maintUpdateLogsRows'),summary=document.getElementById('maintUpdateLogsSummary');
    if(!body)return;
    const status=String(document.getElementById('maintUpdateLogsStatus')?.value||'all');
    const q=String(document.getElementById('maintUpdateLogsSearch')?.value||'').trim().toLowerCase();
    const rows=MAINT_UPDATE_LOG_ROWS.filter(row=>{
        if(status!=='all'&&String(row.status||'running')!==status)return false;
        if(!q)return true;
        const hay=[row.actor,row.actor_name,row.hostname,row.agent_id,row.build,row.action,row.state,row.cause,row.command_id].map(v=>String(v||'').toLowerCase()).join(' ');
        return hay.includes(q);
    });
    if(summary)summary.textContent=rows.length+' entrée'+(rows.length>1?'s':'')+(rows.length!==MAINT_UPDATE_LOG_ROWS.length?' / '+MAINT_UPDATE_LOG_ROWS.length:'');
    if(!rows.length){body.innerHTML='<tr><td colspan="7" class="dmd-update-log-empty">Aucune entrée pour ce filtre.</td></tr>';return;}
    body.innerHTML=rows.map(row=>{
        const st=String(row.status||'running');
        const cause=String(row.cause||'').trim()||'—';
        const target=String(row.hostname||row.agent_id||'—');
        const cmd=String(row.command_id||'').trim();
        return `<tr class="dmd-update-log-row ${htmlEsc(st)}"><td><strong>${htmlEsc(maintUpdateLogDate(row))}</strong>${cmd?`<small>${htmlEsc(cmd)}</small>`:''}</td><td>${maintUpdateLogActor(row)}</td><td><strong>${htmlEsc(row.action||'Mise à jour Agent')}</strong><small>${htmlEsc(row.stage||'')}</small></td><td><strong>${htmlEsc(target)}</strong>${row.agent_id&&row.agent_id!==target?`<small>${htmlEsc(row.agent_id)}</small>`:''}</td><td><code>${htmlEsc(row.build||'—')}</code></td><td><span class="dmd-update-log-status ${htmlEsc(st)}">${htmlEsc(row.state||'—')}</span></td><td class="dmd-update-log-cause">${htmlEsc(cause)}</td></tr>`;
    }).join('');
}
async function maintLoadUpdateLogs(showToast=false){
    const body=document.getElementById('maintUpdateLogsRows'),summary=document.getElementById('maintUpdateLogsSummary');
    if(body)body.innerHTML='<tr><td colspan="7" class="dmd-update-log-empty">Lecture du journal…</td></tr>';
    if(summary)summary.textContent='Chargement…';
    const r=await maintPost('api/admin_update_logs.php',{action:'list',limit:600});
    if(!r.ok)throw new Error(r.error||'Lecture du journal impossible.');
    MAINT_UPDATE_LOG_ROWS=Array.isArray(r.rows)?r.rows:[];
    maintUpdateLogsRender();
    if(showToast)showMsg('Journal des mises à jour rafraîchi.');
    return r;
}
function maintFilteredUpdateLogs(){
    const status=String(document.getElementById('maintUpdateLogsStatus')?.value||'all');
    const q=String(document.getElementById('maintUpdateLogsSearch')?.value||'').trim().toLowerCase();
    return MAINT_UPDATE_LOG_ROWS.filter(row=>{
        if(status!=='all'&&String(row.status||'running')!==status)return false;
        if(!q)return true;
        const hay=[row.actor,row.actor_name,row.hostname,row.agent_id,row.build,row.action,row.state,row.cause,row.command_id].map(v=>String(v||'').toLowerCase()).join(' ');
        return hay.includes(q);
    });
}
let MAINT_UPDATE_LOG_PDF_URL='';
function maintPdfAscii(value){
    return String(value??'')
        .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
        .replace(/[’‘]/g,"'").replace(/[“”]/g,'"')
        .replace(/[–—]/g,'-').replace(/…/g,'...')
        .replace(/[^\x20-\x7E]/g,' ')
        .replace(/\s+/g,' ').trim();
}
function maintPdfEsc(value){return maintPdfAscii(value).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');}
function maintPdfWrap(value,maxChars,maxLines){
    const text=maintPdfAscii(value)||'-', words=text.split(' '), lines=[];let line='';
    for(let word of words){
        if(word.length>maxChars){
            if(line){lines.push(line);line='';if(lines.length>=maxLines)break;}
            while(word.length>maxChars&&lines.length<maxLines){lines.push(word.slice(0,maxChars));word=word.slice(maxChars);}
            if(lines.length>=maxLines)break;
            line=word;continue;
        }
        const candidate=line?line+' '+word:word;
        if(candidate.length<=maxChars)line=candidate;
        else{lines.push(line);line=word;if(lines.length>=maxLines)break;}
    }
    if(line&&lines.length<maxLines)lines.push(line);
    if(!lines.length)lines.push('-');
    const rendered=lines.join(' ');
    if(rendered.length<text.length){const i=lines.length-1;lines[i]=(lines[i].slice(0,Math.max(1,maxChars-3)).replace(/\s+$/,'')+'...');}
    return lines;
}
function maintBuildUpdateLogsPdf(rows,filters){
    const clean=rows.slice(0,600).map(row=>{
        const status=String(row.status||'').toLowerCase();
        const state=String(row.state||'').trim()||(status==='success'?'Reussite':status==='error'?'Echec':'En cours');
        const actorName=String(row.actor_name||'').trim(),actor=String(row.actor||'').trim();
        return {
            date:maintUpdateLogDate(row)||'-',
            actor:actorName&&actor?actorName+' - '+actor:(actorName||actor||'Systeme / Agent'),
            action:String(row.action||'Mise a jour Agent'),
            target:String(row.hostname||row.agent_id||'-'),
            build:String(row.build||'-'),
            state,
            cause:String(row.cause||'').trim()||(status==='success'?'Operation terminee avec succes.':'-')
        };
    });
    const cols=[
        {k:'date',x:28,w:91,c:22,l:2},{k:'actor',x:121,w:118,c:27,l:3},{k:'action',x:241,w:91,c:21,l:3},
        {k:'target',x:334,w:92,c:21,l:3},{k:'build',x:428,w:65,c:14,l:2},{k:'state',x:495,w:63,c:13,l:2},{k:'cause',x:560,w:252,c:55,l:4}
    ];
    const pages=[];let current=[],y=503;
    for(const row of clean){
        const wrapped={};let maxLines=1;
        for(const col of cols){wrapped[col.k]=maintPdfWrap(row[col.k],col.c,col.l);maxLines=Math.max(maxLines,wrapped[col.k].length);}
        const h=Math.max(18,7+maxLines*8);
        if(y-h<38&&current.length){pages.push(current);current=[];y=503;}
        current.push({wrapped,h});y-=h;
    }
    if(current.length||!pages.length)pages.push(current);
    const filterBits=[];
    if(filters.status&&filters.status!=='all')filterBits.push('etat='+filters.status);
    if(filters.search)filterBits.push('recherche='+maintPdfAscii(filters.search).slice(0,45));
    const filterText=filterBits.join(', ');
    const headers=[['Date / heure',28],['Utilisateur',121],['Action',241],['PC / cible',334],['Build',428],['Resultat',495],['Cause / detail',560]];
    const contents=pages.map((items,pi)=>{
        let c='0.45 w\n';
        c+=`BT /F1 15 Tf 28 558 Td (${maintPdfEsc('DoMyDesk - Journal des mises a jour Agent')}) Tj ET\n`;
        let sub=`Export: ${new Date().toLocaleString('fr-FR')} | Entrees exportees: ${clean.length}`;if(filterText)sub+=' | Filtres: '+filterText;
        c+=`BT /F1 7.5 Tf 28 543 Td (${maintPdfEsc(sub.slice(0,155))}) Tj ET\n`;
        c+=`BT /F1 7 Tf 750 20 Td (${maintPdfEsc('Page '+(pi+1)+' / '+pages.length)}) Tj ET\n`;
        let yy=523;c+=`28 ${yy} m 812 ${yy} l S\n`;
        for(const [label,x] of headers)c+=`BT /F1 7 Tf ${x} ${yy-12} Td (${maintPdfEsc(label)}) Tj ET\n`;
        yy-=18;c+=`28 ${yy} m 812 ${yy} l S\n`;
        for(const item of items){
            const base=yy-10;
            for(const col of cols){
                const lines=item.wrapped[col.k]||['-'];
                lines.forEach((line,li)=>{c+=`BT /F1 6.2 Tf ${col.x} ${base-li*8} Td (${maintPdfEsc(line)}) Tj ET\n`;});
            }
            yy-=item.h;c+=`28 ${yy} m 812 ${yy} l S\n`;
        }
        return c;
    });
    const objects={1:'<< /Type /Catalog /Pages 2 0 R >>',3:'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'};
    const kids=[];let next=4;
    for(const content of contents){const contentId=next++,pageId=next++;objects[contentId]=`<< /Length ${content.length} >>\nstream\n${content}endstream`;objects[pageId]=`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents ${contentId} 0 R >>`;kids.push(pageId+' 0 R');}
    objects[2]=`<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${kids.length} >>`;
    const max=Math.max(...Object.keys(objects).map(Number));let pdf='%PDF-1.4\n%DoMyDesk\n',offsets={0:0};
    for(let i=1;i<=max;i++){if(!(i in objects))continue;offsets[i]=pdf.length;pdf+=`${i} 0 obj\n${objects[i]}\nendobj\n`;}
    const xref=pdf.length;pdf+=`xref\n0 ${max+1}\n0000000000 65535 f \n`;
    for(let i=1;i<=max;i++)pdf+=String(offsets[i]||0).padStart(10,'0')+' 00000 n \n';
    pdf+=`trailer\n<< /Size ${max+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
    return new Blob([pdf],{type:'application/pdf'});
}
function maintShowUpdateLogsPdf(blob){
    if(MAINT_UPDATE_LOG_PDF_URL)URL.revokeObjectURL(MAINT_UPDATE_LOG_PDF_URL);
    MAINT_UPDATE_LOG_PDF_URL=URL.createObjectURL(blob);
    const modal=document.getElementById('maintenanceAgentUpdateLogsPdfModal'),frame=document.getElementById('maintUpdateLogsPdfFrame'),dl=document.getElementById('maintUpdateLogsPdfDownload');
    if(frame)frame.src=MAINT_UPDATE_LOG_PDF_URL;
    if(dl){dl.disabled=false;dl.onclick=()=>{const a=document.createElement('a');a.href=MAINT_UPDATE_LOG_PDF_URL;a.download='DMD-Agent-Journal-Mises-a-jour-'+new Date().toISOString().slice(0,10)+'.pdf';document.body.appendChild(a);a.click();a.remove();};}
    if(modal)modal.hidden=false;
}
async function maintExportUpdateLogsPdf(){
    const rows=maintFilteredUpdateLogs();
    if(!rows.length){showMsg('Aucune entrée à exporter avec le filtre actuel.',false);return;}
    const filters={status:String(document.getElementById('maintUpdateLogsStatus')?.value||'all'),search:String(document.getElementById('maintUpdateLogsSearch')?.value||'')};
    const btn=document.getElementById('maintUpdateLogsPdf');
    if(btn){btn.disabled=true;btn.textContent='Génération…';}
    try{
        let blob=null;
        try{
            const r=await fetch('api/admin_update_logs_export_pdf.php',{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':CSRF},credentials:'same-origin',body:JSON.stringify({csrf_token:CSRF,rows:rows.slice(0,600),filters})});
            if(r.ok){const serverBlob=await r.blob();if(String(serverBlob.type||'').toLowerCase().includes('pdf')&&serverBlob.size>100)blob=serverBlob;}
        }catch(_){/* génération locale ci-dessous */}
        if(!blob)blob=maintBuildUpdateLogsPdf(rows,filters);
        if(!blob||blob.size<100)throw new Error('Le PDF n’a pas pu être généré.');
        maintShowUpdateLogsPdf(blob);
    }catch(e){showMsg(e.message||'Export PDF impossible.',false);}finally{if(btn){btn.disabled=false;btn.textContent='Exporter PDF';}}
}
function maintCloseUpdateLogsPdf(){
    const modal=document.getElementById('maintenanceAgentUpdateLogsPdfModal'),frame=document.getElementById('maintUpdateLogsPdfFrame'),dl=document.getElementById('maintUpdateLogsPdfDownload');
    if(modal)modal.hidden=true;
    if(frame)frame.removeAttribute('src');
    if(dl){dl.disabled=true;dl.onclick=null;}
    if(MAINT_UPDATE_LOG_PDF_URL){URL.revokeObjectURL(MAINT_UPDATE_LOG_PDF_URL);MAINT_UPDATE_LOG_PDF_URL='';}
}
document.getElementById('maintUpdateLogsRefresh')?.addEventListener('click',()=>maintLoadUpdateLogs(true).catch(e=>showMsg(e.message||'Journal indisponible.',false)));
document.getElementById('maintUpdateLogsStatus')?.addEventListener('change',maintUpdateLogsRender);
document.getElementById('maintUpdateLogsSearch')?.addEventListener('input',maintUpdateLogsRender);
document.getElementById('maintUpdateLogsPdf')?.addEventListener('click',maintExportUpdateLogsPdf);
async function maintPurgeUpdateLogs(){
    if(!confirm('Purger tout le journal des mises à jour Agent ?\n\nLes entrées de mise à jour terminées seront supprimées côté DoMyDesk. Les autres audits DoMyDesk ne seront pas touchés. Cette action est irréversible.'))return;
    const btn=document.getElementById('maintUpdateLogsPurge');
    if(btn){btn.disabled=true;btn.textContent='Purge…';}
    try{
        const r=await maintPost('api/admin_update_logs.php',{action:'purge'});
        if(!r.ok)throw new Error(r.error||'Purge impossible.');
        MAINT_UPDATE_LOG_ROWS=[];
        maintUpdateLogsRender();
        await maintLoadUpdateLogs(false);
        const n=(Number(r.commands_removed)||0)+(Number(r.system_logs_removed)||0);
        showMsg('Journal purgé : '+n+' entrée'+(n>1?'s':'')+' supprimée'+(n>1?'s':'')+'.');
    }catch(e){showMsg(e.message||'Purge du journal impossible.',false);}
    finally{if(btn){btn.disabled=false;btn.textContent='Purger';}}
}
document.getElementById('maintUpdateLogsPurge')?.addEventListener('click',maintPurgeUpdateLogs);
document.getElementById('maintUpdateLogsPdfClose')?.addEventListener('click',maintCloseUpdateLogsPdf);
document.getElementById('maintenanceAgentUpdateLogsPdfModal')?.addEventListener('click',e=>{if(e.target&&e.target.id==='maintenanceAgentUpdateLogsPdfModal')maintCloseUpdateLogsPdf();});
document.addEventListener('keydown',e=>{const m=document.getElementById('maintenanceAgentUpdateLogsPdfModal');if(e.key==='Escape'&&m&&!m.hidden){e.preventDefault();maintCloseUpdateLogsPdf();}});

function maintCheckedPc(containerId){
    const root=document.getElementById(containerId);
    return root?[...root.querySelectorAll('input.dmd-maint-pc-target:checked:not(:disabled)')].map(x=>x.value):[];
}
function maintBindAll(masterId,containerId){
    const master=document.getElementById(masterId),root=document.getElementById(containerId);
    if(!master||!root)return;
    master.addEventListener('change',()=>root.querySelectorAll('input.dmd-maint-pc-target:not(:disabled)').forEach(x=>x.checked=master.checked));
}
maintBindAll('maintAgentAllPc','maintAgentPcGrid');
maintBindAll('maintPcUpdateAllPc','maintPcUpdatePcGrid');

function maintSelectGroup(containerId,groupId){
    const root=document.getElementById(containerId),gid=String(groupId||'').trim();
    if(!root||!gid)return 0;
    let count=0;
    root.querySelectorAll('[data-maint-groups]').forEach(row=>{
        const groups=String(row.dataset.maintGroups||'').split(/\s+/).filter(Boolean);
        const input=row.querySelector('input.dmd-maint-pc-target:not(:disabled)');
        if(input&&groups.includes(gid)){input.checked=true;count++;}
    });
    return count;
}
function maintClearTargets(containerId,masterId=''){
    const root=document.getElementById(containerId);if(!root)return;
    root.querySelectorAll('input.dmd-maint-pc-target:not(:disabled)').forEach(x=>x.checked=false);
    if(masterId){const master=document.getElementById(masterId);if(master){master.checked=false;master.indeterminate=false;}}
}
document.querySelectorAll('[data-maint-pcupdate-group]').forEach(btn=>btn.addEventListener('click',()=>{
    const n=maintSelectGroup('maintPcUpdatePcGrid',btn.dataset.maintPcupdateGroup);
    showMsg(n+' PC du groupe sélectionné'+(n>1?'s':'')+'.');
}));
document.querySelector('[data-maint-pcupdate-clear]')?.addEventListener('click',()=>maintClearTargets('maintPcUpdatePcGrid','maintPcUpdateAllPc'));

function maintStateLabel(state){
    const s=String(state||'').toLowerCase();
    const map={queued:'En attente',delivered:'Transmise',downloading:'Téléchargement',verified:'Vérifié',installing:'Installation',waiting:'Attente',completed:'Terminé',failed:'Échec',expired:'Expirée',cancelled:'Annulée',error:'Erreur',ignored:'Ignorée',recherche:'Recherche'};
    return map[s]||state||'—';
}
function maintComponentStateLabel(state){
    const s=String(state||'').toLowerCase();
    const map={updated:'mis à jour',not_installed:'non installé',failed:'échec',unchanged:'inchangé',skipped:'ignoré',completed:'terminé'};
    return map[s]||state||'—';
}
function maintResultLine(host,state,text,kind=''){
    return '<div class="dmd-maint-result-row '+htmlEsc(kind)+'"><strong>'+htmlEsc(host||'PC')+'</strong><span>'+htmlEsc(maintStateLabel(state))+'</span><small>'+htmlEsc(text||'')+'</small></div>';
}
function maintDevice(agentId){return DEVICE_DATA.find(x=>String(x.agent_id||'')===String(agentId||''))||null;}

async function maintPost(url,payload){return post(url,payload);}
async function maintRunCommand(agentId,operation,params={},timeoutMs=150000){
    const q=await post('api/admin_command.php',{action:'queue',agent_id:agentId,operation,params});
    if(!q.ok)throw new Error(q.error||'Commande refusée');
    const commandId=q.command&&q.command.command_id;
    if(!commandId)throw new Error('ID de commande absent');
    const started=Date.now();
    while(Date.now()-started<timeoutMs){
        await new Promise(r=>setTimeout(r,700));
        const s=await post('api/admin_command.php',{action:'status',agent_id:agentId,command_id:commandId});
        if(!s.ok)throw new Error(s.error||'Statut indisponible');
        const c=s.command||{};
        if(['completed','failed','expired','cancelled'].includes(String(c.status||''))){
            if(c.status!=='completed')throw new Error(c.error||('Commande '+c.status));
            return c.result||{};
        }
    }
    throw new Error('Délai de réponse dépassé');
}

/* ---------- Sélection indépendante des PC ---------- */
function maintSoftwarePcTargets(){return [...MAINT_SOFTWARE_PC_SELECTED];}
function maintSyncSoftwarePcChecks(){
    const root=document.getElementById('maintSoftwarePcGrid');
    if(!root)return;
    root.querySelectorAll('input[type=checkbox]').forEach(x=>{x.checked=MAINT_SOFTWARE_PC_SELECTED.has(x.value);});
    const enabled=[...root.querySelectorAll('input[type=checkbox]:not(:disabled)')];
    const master=document.getElementById('maintSoftwareAllPc');
    if(master){
        master.checked=enabled.length>0&&enabled.every(x=>x.checked);
        master.indeterminate=enabled.some(x=>x.checked)&&!master.checked;
    }
}
function maintUpdateSoftwareSelectionUi(){
    const softwareCount=MAINT_SOFTWARE_SELECTED.size;
    const pcCount=MAINT_SOFTWARE_PC_SELECTED.size;
    const a=document.getElementById('maintSoftwareSelectedCount');
    const b=document.getElementById('maintSoftwarePcCount');
    const c=document.getElementById('maintSoftwarePcPopupCount');
    const d=document.getElementById('maintSoftwarePcFooterCount');
    const e=document.getElementById('maintSoftwarePcFooterSoftware');
    const f=document.getElementById('maintSoftwareDeploySummary');
    const installPopup=document.getElementById('maintSoftwareInstallFromPcPopup');
    if(a)a.textContent=softwareCount+' logiciel'+(softwareCount>1?'s':'');
    if(b)b.textContent=String(pcCount);
    if(c)c.textContent=pcCount+' sélectionné'+(pcCount>1?'s':'');
    if(d)d.textContent=pcCount+' PC sélectionné'+(pcCount>1?'s':'');
    if(e)e.textContent=softwareCount+' logiciel'+(softwareCount>1?'s':'')+' sélectionné'+(softwareCount>1?'s':'');
    if(f)f.textContent=softwareCount+' logiciel'+(softwareCount>1?'s':'')+' · '+pcCount+' PC';
    if(installPopup)installPopup.disabled=!(softwareCount>0&&pcCount>0);
}
function maintOpenSoftwarePcSelector(){
    const section=document.getElementById('maintSoftwarePcSection');
    if(!section)return;
    maintSyncSoftwarePcChecks();
    maintUpdateSoftwareSelectionUi();
    section.scrollIntoView({behavior:'smooth',block:'center'});
    section.classList.add('is-attention');
    setTimeout(()=>section.classList.remove('is-attention'),900);
}
function maintCloseSoftwarePcSelector(){
    maintUpdateSoftwareSelectionUi();
}
document.getElementById('maintSoftwarePcGrid')?.addEventListener('change',e=>{
    const input=e.target.closest('input[type=checkbox]');
    if(!input||input.disabled)return;
    if(input.checked)MAINT_SOFTWARE_PC_SELECTED.add(input.value);
    else MAINT_SOFTWARE_PC_SELECTED.delete(input.value);
    maintSyncSoftwarePcChecks();maintUpdateSoftwareSelectionUi();
});
document.getElementById('maintSoftwareAllPc')?.addEventListener('change',e=>{
    const root=document.getElementById('maintSoftwarePcGrid');if(!root)return;
    root.querySelectorAll('input[type=checkbox]:not(:disabled)').forEach(x=>{
        const row=x.closest('[data-maint-pc-search]');
        if(row&&row.hidden)return;
        x.checked=e.target.checked;
        if(x.checked)MAINT_SOFTWARE_PC_SELECTED.add(x.value);else MAINT_SOFTWARE_PC_SELECTED.delete(x.value);
    });
    maintSyncSoftwarePcChecks();maintUpdateSoftwareSelectionUi();
});
document.querySelectorAll('[data-maint-software-group]').forEach(btn=>btn.addEventListener('click',()=>{
    const gid=String(btn.dataset.maintSoftwareGroup||'').trim();
    const root=document.getElementById('maintSoftwarePcGrid');if(!gid||!root)return;
    let added=0;
    root.querySelectorAll('[data-maint-pc-groups]').forEach(row=>{
        const groups=String(row.dataset.maintPcGroups||'').split(/\s+/).filter(Boolean);
        const input=row.querySelector('input[type=checkbox]:not(:disabled)');
        if(input&&groups.includes(gid)){input.checked=true;MAINT_SOFTWARE_PC_SELECTED.add(input.value);added++;}
    });
    maintSyncSoftwarePcChecks();maintUpdateSoftwareSelectionUi();
    showMsg(added+' PC du groupe ajouté'+(added>1?'s':'')+' à la sélection.');
}));
document.querySelector('[data-maint-software-clear]')?.addEventListener('click',()=>{
    MAINT_SOFTWARE_PC_SELECTED.clear();
    maintSyncSoftwarePcChecks();maintUpdateSoftwareSelectionUi();
});
function maintFilterSoftwarePc(){
    const root=document.getElementById('maintSoftwarePcGrid');
    const q=(document.getElementById('maintSoftwarePcSearch')?.value||'').trim().toLowerCase();
    if(!root)return;
    root.querySelectorAll('[data-maint-pc-search]').forEach(row=>{
        row.hidden=!!q&&!String(row.dataset.maintPcSearch||'').includes(q);
    });
}
document.getElementById('maintSoftwarePcSearch')?.addEventListener('input',maintFilterSoftwarePc);

/* ---------- Bibliothèque logiciels ---------- */
async function maintLoadSoftwareLibrary(){
    const box=document.getElementById('maintSoftwareLibrary');
    if(box)box.innerHTML='<div class="dmd-maint-empty">Chargement…</div>';
    const r=await maintPost('api/admin_maintenance_software.php',{action:'list'});
    if(!r.ok){if(box)box.innerHTML='<div class="dmd-maint-empty">Erreur : '+htmlEsc(r.error||'lecture impossible')+'</div>';return;}
    MAINT_SOFTWARE_LIBRARY=Array.isArray(r.items)?r.items:[];
    const valid=new Set(MAINT_SOFTWARE_LIBRARY.map(x=>x.id));
    [...MAINT_SOFTWARE_SELECTED].forEach(id=>{if(!valid.has(id))MAINT_SOFTWARE_SELECTED.delete(id);});
    maintRenderSoftwareLibrary();
    maintUpdateSoftwareSelectionUi();
}
function maintRenderSoftwareLibrary(){
    const box=document.getElementById('maintSoftwareLibrary');
    if(!box)return;
    const q=(document.getElementById('maintSoftwareLibrarySearch')?.value||'').trim().toLowerCase();
    const rows=MAINT_SOFTWARE_LIBRARY.filter(x=>{
        if(!q)return true;
        return String((x.name||'')+' '+(x.winget_id||'')+' '+(x.file_name||'')+' '+(x.source||'')).toLowerCase().includes(q);
    });
    if(!rows.length){
        box.innerHTML='<div class="dmd-maint-empty">'+(MAINT_SOFTWARE_LIBRARY.length?'Aucun logiciel ne correspond au filtre.':'Bibliothèque vide.')+'</div>';
        return;
    }
    box.innerHTML=rows.map(x=>`
        <label class="dmd-maint-library-row ${MAINT_SOFTWARE_SELECTED.has(x.id)?'is-selected':''}">
            <input type="checkbox" value="${htmlEsc(x.id||'')}" ${MAINT_SOFTWARE_SELECTED.has(x.id)?'checked':''}>
            <span class="dmd-maint-library-main">
                <strong>${htmlEsc(x.name||'Logiciel')}</strong>
                <small>${x.source==='winget'?'Winget · '+htmlEsc(x.winget_id||''):htmlEsc(x.file_name||'Fichier DoMyDesk')}${x.arguments?' · args: '+htmlEsc(x.arguments):''}</small>
            </span>
            <span class="dmd-maint-source">${x.source==='winget'?'Winget':String(x.extension||'FILE').toUpperCase()}</span>
            <button type="button" class="dmd-agent-mini-btn danger" data-maint-lib-delete="${htmlEsc(x.id||'')}">Supprimer</button>
        </label>`).join('');
}
document.getElementById('maintSoftwareLibrarySearch')?.addEventListener('input',maintRenderSoftwareLibrary);
document.getElementById('maintSoftwareRefresh')?.addEventListener('click',maintLoadSoftwareLibrary);
document.getElementById('maintSoftwareLibrary')?.addEventListener('change',e=>{
    const input=e.target.closest('input[type=checkbox]');
    if(!input)return;
    if(input.checked)MAINT_SOFTWARE_SELECTED.add(input.value);else MAINT_SOFTWARE_SELECTED.delete(input.value);
    input.closest('.dmd-maint-library-row')?.classList.toggle('is-selected',input.checked);
    maintUpdateSoftwareSelectionUi();
});
document.getElementById('maintSoftwareLibrary')?.addEventListener('click',async e=>{
    const b=e.target.closest('[data-maint-lib-delete]');
    if(!b)return;
    e.preventDefault();
    const id=b.dataset.maintLibDelete;
    const item=MAINT_SOFTWARE_LIBRARY.find(x=>x.id===id);
    if(!confirm('Supprimer '+(item?.name||'ce logiciel')+' de la bibliothèque DoMyDesk ?'))return;
    const r=await maintPost('api/admin_maintenance_software.php',{action:'delete',id});
    if(!r.ok){showMsg('Suppression impossible : '+(r.error||'erreur'),false);return;}
    MAINT_SOFTWARE_SELECTED.delete(id);
    await maintLoadSoftwareLibrary();
});
document.getElementById('maintLocalSoftwareForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const form=e.currentTarget,fd=new FormData(form);
    fd.append('action','add_file');fd.append('csrf_token',CSRF);
    const r=await fetch('api/admin_maintenance_software.php',{method:'POST',headers:{'X-DMD-CSRF':CSRF},body:fd,credentials:'same-origin'});
    let j={};try{j=await r.json();}catch(_){j={ok:false,error:'Réponse JSON invalide'};}
    if(!r.ok||!j.ok){showMsg('Ajout logiciel impossible : '+(j.error||('HTTP '+r.status)),false);return;}
    form.reset();
    if(j.item&&j.item.id)MAINT_SOFTWARE_SELECTED.add(j.item.id);
    showMsg('Logiciel ajouté à la bibliothèque.');
    await maintLoadSoftwareLibrary();
});

/* ---------- Générateur / recherche Winget ---------- */
function maintWingetProbeDevice(){
    const selected=[...MAINT_SOFTWARE_PC_SELECTED].map(maintDevice).filter(Boolean);
    const all=[...selected,...DEVICE_DATA.filter(d=>!MAINT_SOFTWARE_PC_SELECTED.has(String(d.agent_id||'')))];
    const now=Math.floor(Date.now()/1000);
    return all.find(d=>{
        const caps=deviceCaps(d);
        return String(d.status||'')==='active'
            && String(d.platform||'').toLowerCase()==='windows'
            && Number(d.last_seen_ts||0)>0
            && (now-Number(d.last_seen_ts||0))<90
            && caps.includes('software.update');
    })||null;
}
async function maintWingetSearch(){
    const input=document.getElementById('maintWingetSearchInput');
    const results=document.getElementById('maintWingetSearchResults');
    const count=document.getElementById('maintWingetResultCount');
    const add=document.getElementById('maintWingetAddSelected');
    const query=(input?.value||'').trim();
    if(query.length<2){showMsg('Saisis au moins 2 caractères pour la recherche Winget.',false);return;}
    const d=maintWingetProbeDevice();
    if(!d){
        showMsg('Aucun PC Windows en ligne disposant de la fonction Mise à jour logiciels.',false);
        if(results)results.innerHTML='<div class="dmd-maint-empty">Aucun Agent compatible Winget disponible. Mets au moins un Agent à jour puis relance la recherche.</div>';
        return;
    }
    const probe=document.getElementById('maintWingetProbe');
    if(probe)probe.textContent='PC de recherche : '+(d.hostname||'PC');
    if(results)results.innerHTML='<div class="dmd-maint-empty">Recherche Winget sur '+htmlEsc(d.hostname||'PC')+'…</div>';
    if(count)count.textContent='Recherche…';
    if(add)add.disabled=true;
    try{
        const r=await maintRunCommand(d.agent_id,'software.winget.search',{query},3*60*1000);
        MAINT_WINGET_RESULTS=(Array.isArray(r?.matches)?r.matches:[]).filter(x=>x&&x.id&&x.name);
        maintRenderWingetResults();
        if(!MAINT_WINGET_RESULTS.length && r?.raw && results){
            results.innerHTML='<div class="dmd-maint-empty">Aucun résultat exploitable pour « '+htmlEsc(query)+' ».<br><small>'+htmlEsc(String(r.raw).slice(0,1200))+'</small></div>';
        }
    }catch(err){
        MAINT_WINGET_RESULTS=[];
        if(results)results.innerHTML='<div class="dmd-maint-empty">Erreur Winget : '+htmlEsc(err.message||'recherche impossible')+'</div>';
        if(count)count.textContent='0 résultat';
        if(add)add.disabled=true;
        showMsg('Recherche Winget impossible : '+(err.message||'erreur'),false);
    }
}
function maintRenderWingetResults(){
    const box=document.getElementById('maintWingetSearchResults');
    const count=document.getElementById('maintWingetResultCount');
    const add=document.getElementById('maintWingetAddSelected');
    if(count)count.textContent=MAINT_WINGET_RESULTS.length+' résultat'+(MAINT_WINGET_RESULTS.length>1?'s':'');
    if(!box)return;
    if(!MAINT_WINGET_RESULTS.length){box.innerHTML='<div class="dmd-maint-empty">Aucun résultat Winget.</div>';if(add)add.disabled=true;return;}
    box.innerHTML=MAINT_WINGET_RESULTS.map((x,i)=>`
        <label class="dmd-maint-winget-row">
            <input type="checkbox" value="${i}">
            <span>
                <strong>${htmlEsc(x.name)}</strong>
                <small>${htmlEsc(x.id)}</small>
            </span>
            <b>${htmlEsc(x.version||'—')}</b>
            <em>${htmlEsc(x.source||'winget')}</em>
        </label>`).join('');
    if(add)add.disabled=true;
}
document.getElementById('maintWingetSearchButton')?.addEventListener('click',maintWingetSearch);
document.getElementById('maintWingetSearchInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();maintWingetSearch();}});
document.getElementById('maintWingetSearchResults')?.addEventListener('change',()=>{
    const n=document.querySelectorAll('#maintWingetSearchResults input[type=checkbox]:checked').length;
    const add=document.getElementById('maintWingetAddSelected');
    if(add)add.disabled=n===0;
});
document.getElementById('maintWingetAddSelected')?.addEventListener('click',async()=>{
    const checks=[...document.querySelectorAll('#maintWingetSearchResults input[type=checkbox]:checked')];
    if(!checks.length)return;
    const btn=document.getElementById('maintWingetAddSelected');
    btn.disabled=true;btn.textContent='Ajout…';
    let added=0,failed=0;
    try{
        for(const check of checks){
            const item=MAINT_WINGET_RESULTS[Number(check.value)];
            if(!item)continue;
            const r=await maintPost('api/admin_maintenance_software.php',{action:'add_winget',name:item.name,winget_id:item.id});
            if(r.ok){added++;if(r.item?.id)MAINT_SOFTWARE_SELECTED.add(r.item.id);}
            else failed++;
        }
        await maintLoadSoftwareLibrary();
        showMsg(added+' logiciel'+(added>1?'s':'')+' Winget ajouté'+(added>1?'s':'')+' à la bibliothèque'+(failed?' · '+failed+' erreur(s)':'')+'.',failed===0);
    }finally{
        btn.textContent='Ajouter la sélection à la bibliothèque';
        btn.disabled=false;
    }
});

/* ---------- Déploiement logiciels ---------- */
function maintSelectedSoftware(){
    return [...MAINT_SOFTWARE_SELECTED].map(id=>MAINT_SOFTWARE_LIBRARY.find(x=>x.id===id)).filter(Boolean);
}
async function maintTrackQueued(rows,box,timeoutMs=35*60*1000){
    if(!rows.length)return [];
    const state=new Map(rows.map((r,i)=>[(r.agent_id||'')+'|'+(r.item_id||'')+'|'+i,{...r}]));
    const deadline=Date.now()+timeoutMs;
    while(Date.now()<deadline){
        let pending=0;
        for(const row of state.values()){
            if(!row.command_id||['completed','failed','expired','cancelled','error'].includes(String(row.status||'')))continue;
            pending++;
            try{
                const s=await post('api/admin_command.php',{action:'status',agent_id:row.agent_id,command_id:row.command_id});
                if(s.ok&&s.command){
                    row.status=s.command.status||row.status;
                    row.error=s.command.error||'';
                    row.message=s.command.message||'';
                    row.result=s.command.result||null;
                }
            }catch(_){}
        }
        box.innerHTML=[...state.values()].map(r=>{
            const d=maintDevice(r.agent_id),host=d?.hostname||r.agent_id;
            const status=String(r.status||'queued');
            const done=status==='completed',bad=['failed','expired','cancelled','error'].includes(status);
            const data=(r.result&&typeof r.result==='object')?r.result:{};
            let detail=r.error||r.message||data.message||'';
            if(data.phase&&detail)detail=String(data.phase)+' · '+detail;
            const comps=Array.isArray(data.components)?data.components:[];
            if(comps.length){
                const txt=comps.map(c=>String(c.name||'composant')+': '+maintComponentStateLabel(c.status||'—')).join(' · ');
                detail+=(detail?' · ':'')+txt;
            }
            if(done&&data.reboot_scheduled){
                const when=data.reboot_execute_at?new Date(data.reboot_execute_at).toLocaleString():'heure inconnue';
                detail+=(detail?' · ':'')+'Redémarrage automatique planifié : '+when+' · utilisateur averti';
            }else if(done&&data.reboot_required){
                detail+=(detail?' · ':'')+'Redémarrage requis · aucun redémarrage automatique planifié';
            }
            return maintResultLine(host,status,detail,done?'ok':(bad?'bad':''));
        }).join('');
        if(pending===0)break;
        await new Promise(r=>setTimeout(r,1200));
    }
    return [...state.values()];
}
async function maintSoftwareInstallSelected(closePcPopup=false){
    const items=maintSelectedSoftware(),targets=maintSoftwarePcTargets(),box=document.getElementById('maintSoftwareResults');
    if(!items.length){showMsg('Sélectionne au moins un logiciel.',false);return;}
    if(!targets.length){maintOpenSoftwarePcSelector();showMsg('Sélectionne au moins un PC.',false);return;}
    if(closePcPopup)maintCloseSoftwarePcSelector();
    box.innerHTML='<div class="dmd-maint-empty">Création des déploiements vers '+targets.length+' PC…</div>';
    const r=await maintPost('api/admin_maintenance_software.php',{action:'deploy_install',item_ids:items.map(x=>x.id),agent_ids:targets});
    if(!r.ok){box.innerHTML='<div class="dmd-maint-empty">Erreur : '+htmlEsc(r.error||'déploiement impossible')+'</div>';return;}
    const rows=Array.isArray(r.commands)?r.commands:[];
    box.innerHTML=rows.map(x=>maintResultLine(maintDevice(x.agent_id)?.hostname||x.agent_id,x.status||'queued',(x.item_name?x.item_name+' · ':'')+(x.error||''),x.error?'bad':'')).join('');
    await maintTrackQueued(rows.filter(x=>x.command_id),box);
}
document.getElementById('maintSoftwareInstall')?.addEventListener('click',()=>maintSoftwareInstallSelected(false));
document.getElementById('maintSoftwareInstallFromPcPopup')?.addEventListener('click',()=>maintSoftwareInstallSelected(true));

document.getElementById('maintSoftwareUninstall')?.addEventListener('click',async()=>{
    const items=maintSelectedSoftware(),targets=maintSoftwarePcTargets(),box=document.getElementById('maintSoftwareResults');
    if(!items.length){showMsg('Sélectionne au moins un logiciel.',false);return;}
    if(!targets.length){maintOpenSoftwarePcSelector();showMsg('Sélectionne au moins un PC.',false);return;}
    if(!confirm('Désinstaller les logiciels sélectionnés sur les PC cochés ?'))return;
    box.innerHTML='';
    for(const agentId of targets){
        const host=maintDevice(agentId)?.hostname||agentId;
        for(const item of items){
            try{
                if(item.source==='winget'){
                    const r=await maintPost('api/admin_maintenance_software.php',{action:'deploy_winget_uninstall',item_id:item.id,agent_ids:[agentId]});
                    if(!r.ok)throw new Error(r.error||'Winget refusé');
                    const row=(r.commands||[])[0]||{};
                    box.innerHTML+=maintResultLine(host,'queued','Désinstallation Winget '+item.name);
                    if(row.command_id)await maintTrackQueued([row],box);
                }else{
                    box.innerHTML+=maintResultLine(host,'recherche','Recherche de '+item.name);
                    const list=await maintRunCommand(agentId,'software.list',{query:item.name,offset:0,limit:60},120000);
                    const rows=Array.isArray(list.software)?list.software:[];
                    const exact=rows.find(x=>String(x.name||'').toLowerCase()===String(item.name||'').toLowerCase());
                    const target=exact||rows.find(x=>String(x.name||'').toLowerCase().includes(String(item.name||'').toLowerCase()));
                    if(!target)throw new Error('logiciel non trouvé sur le PC');
                    if(target.protected)throw new Error('logiciel protégé');
                    if(!target.can_uninstall)throw new Error('désinstallation silencieuse non disponible');
                    await maintRunCommand(agentId,'software.uninstall',{id:target.id},12*60*1000);
                    box.innerHTML+=maintResultLine(host,'completed','Désinstallé : '+item.name,'ok');
                }
            }catch(err){
                box.innerHTML+=maintResultLine(host,'error',item.name+' : '+(err.message||'erreur'),'bad');
            }
        }
    }
});

/* ---------- Mise à jour DMD-Agent ---------- */
function maintAgentRebootSync(){
    const mode=document.getElementById('maintAgentRebootMode')?.value||'none';
    const count=document.getElementById('maintAgentRebootCountdownWrap'),at=document.getElementById('maintAgentRebootTimeWrap');
    if(count)count.hidden=mode!=='countdown';
    if(at)at.hidden=mode!=='at';
}
function maintAgentRebootPolicy(){
    const mode=document.getElementById('maintAgentRebootMode')?.value||'none';
    const policy={mode,delay_seconds:0,execute_at_ts:0,message:'DoMyDesk : redémarrage automatique planifié après la mise à jour. Enregistrez votre travail.'};
    if(mode==='now')policy.delay_seconds=60;
    else if(mode==='countdown')policy.delay_seconds=Math.max(60,Math.min(604800,Math.round(Number(document.getElementById('maintAgentRebootMinutes')?.value||15)*60)));
    else if(mode==='at')policy.execute_at_ts=dmdNextLocalTimeUnix(document.getElementById('maintAgentRebootTime')?.value||'23:00');
    return policy;
}
function maintAgentRebootTargets(targets){
    const selected=new Set((targets||[]).map(String));
    if((document.getElementById('maintAgentRebootMode')?.value||'none')==='none')return [];
    return [...document.querySelectorAll('#maintAgentPcGrid .dmd-maint-pc-autoreboot:checked:not(:disabled)')]
        .map(x=>String(x.dataset.rebootAgent||''))
        .filter(x=>x&&selected.has(x));
}
document.getElementById('maintAgentRebootMode')?.addEventListener('change',maintAgentRebootSync);
maintAgentRebootSync();

let MAINT_UPDATE_REPOSITORY=null;
function maintUpdateRepoSelectedVersion(){return String(document.getElementById('maintAgentVersionSelect')?.value||'').trim();}
function maintUpdateRepoRender(data,preserveVersion=''){
    MAINT_UPDATE_REPOSITORY=data||{};
    const pairs=Array.isArray(data&&data.pairs)?data.pairs:[];
    const select=document.getElementById('maintAgentVersionSelect');
    const list=document.getElementById('maintAgentPackagesList');
    const summary=document.getElementById('maintAgentPackagesSummary');
    const all=document.getElementById('maintAgentPackagesAll');
    if(summary)summary.textContent=(data?.count||0)+' fichier(s) · '+(pairs.filter(p=>p.complete).length)+' version(s) complète(s) · '+fmtAdminBytes(Number(data?.total_bytes||0));
    if(select){
        const complete=pairs.filter(p=>p.complete);
        const wanted=preserveVersion||select.value||String(data?.latest_version||'');
        select.innerHTML=complete.length?complete.map(p=>`<option value="${htmlEsc(p.version||'')}">${htmlEsc(p.version||'')}${String(p.version||'')===String(data?.latest_version||'')?' · dernière':''}</option>`).join(''):'<option value="">Aucune version complète</option>';
        if(complete.some(p=>String(p.version||'')===String(wanted)))select.value=wanted;
        else if(data?.latest_version)select.value=String(data.latest_version);
    }
    if(list){
        list.innerHTML=pairs.length?pairs.map(p=>{
            const files=[p.package_name,p.bootstrap_name].filter(Boolean).join(' + ');
            const cls=p.complete?'complete':'incomplete';
            return `<label class="dmd-maint-update-pair ${cls}"><input type="checkbox" data-maint-update-pair value="${htmlEsc(p.version||'')}"><span><strong>${htmlEsc(p.version||'')}</strong><small>${htmlEsc(files||'Paire incomplète')} · ${htmlEsc(fmtAdminBytes(p.total_size||0))} · ${htmlEsc(formatDate(p.modified_at||''))}</small></span><b>${p.complete?'Prête':'Incomplète'}</b></label>`;
        }).join(''):'<div class="dmd-maint-empty">Aucun fichier de mise à jour dans /updates/.</div>';
    }
    if(all)all.checked=false;
    maintUpdateRepoSyncDelete();
}
function maintUpdateRepoSyncDelete(){
    const checked=[...document.querySelectorAll('[data-maint-update-pair]:checked')];
    const btn=document.getElementById('maintAgentPackagesDelete');if(btn)btn.disabled=checked.length===0;
    const all=document.getElementById('maintAgentPackagesAll');
    const boxes=[...document.querySelectorAll('[data-maint-update-pair]')];
    if(all){all.indeterminate=checked.length>0&&checked.length<boxes.length;all.checked=boxes.length>0&&checked.length===boxes.length;}
}
async function maintLoadAgentBinaryState(version=''){
    const el=document.getElementById('maintAgentBinaryState');
    if(!el)return null;
    el.textContent='Vérification…';
    const r=await maintPost('api/admin_maintenance_actions.php',{action:'agent_binary_info',version:version||''});
    el.textContent=r.ok?((r.version||'Version inconnue')+' · '+String(r.sha256||'').slice(0,12)+'…'):'Binaire indisponible';
    return r;
}
async function maintLoadUpdateRepository(showToast=false){
    const keep=maintUpdateRepoSelectedVersion();
    const summary=document.getElementById('maintAgentPackagesSummary');if(summary)summary.textContent='Lecture du dépôt…';
    const r=await post('api/admin_update_packages.php',{action:'list'});
    if(!r.ok)throw new Error(r.error||'Lecture du dépôt impossible.');
    maintUpdateRepoRender(r,keep);
    await maintLoadAgentBinaryState(maintUpdateRepoSelectedVersion());
    if(showToast)showMsg('Dépôt des mises à jour rafraîchi.');
    return r;
}
function maintUploadUpdateZip(file){
    return new Promise((resolve,reject)=>{
        if(!file){reject(new Error('ZIP absent'));return;}
        const wrap=document.getElementById('maintAgentUploadProgress'),bar=document.getElementById('maintAgentUploadProgressBar'),text=document.getElementById('maintAgentUploadProgressText');
        if(wrap)wrap.hidden=false;if(bar)bar.style.width='0%';if(text)text.textContent='0 %';
        const fd=new FormData();fd.append('action','upload');fd.append('csrf_token',CSRF);fd.append('package_zip',file,file.name||'update.zip');
        const xhr=new XMLHttpRequest();xhr.open('POST','api/admin_update_packages.php',true);xhr.withCredentials=true;xhr.setRequestHeader('X-DMD-CSRF',CSRF);
        xhr.upload.onprogress=e=>{if(!e.lengthComputable)return;const p=Math.max(0,Math.min(100,(e.loaded/e.total)*100));if(bar)bar.style.width=p.toFixed(1)+'%';if(text)text.textContent=Math.round(p)+' % · '+fmtAdminBytes(e.loaded)+' / '+fmtAdminBytes(e.total);};
        xhr.onerror=()=>reject(new Error('Import ZIP impossible.'));
        xhr.onload=()=>{let r={};try{r=JSON.parse(xhr.responseText||'{}');}catch(_){r={ok:false,error:'Réponse import invalide'};}if(xhr.status<200||xhr.status>=300||!r.ok){reject(new Error(r.error||'Import ZIP impossible.'));return;}if(bar)bar.style.width='100%';if(text)text.textContent='100 % · import terminé';resolve(r);};
        xhr.send(fd);
    });
}
document.getElementById('maintAgentPackagesRefresh')?.addEventListener('click',()=>maintLoadUpdateRepository(true).catch(e=>showMsg(e.message||'Rafraîchissement impossible.',false)));
document.getElementById('maintAgentVersionSelect')?.addEventListener('change',()=>maintLoadAgentBinaryState(maintUpdateRepoSelectedVersion()));
document.getElementById('maintAgentPackagesList')?.addEventListener('change',maintUpdateRepoSyncDelete);
document.getElementById('maintAgentPackagesAll')?.addEventListener('change',e=>{document.querySelectorAll('[data-maint-update-pair]').forEach(x=>x.checked=!!e.target.checked);maintUpdateRepoSyncDelete();});
document.getElementById('maintAgentZipPick')?.addEventListener('click',()=>document.getElementById('maintAgentZipInput')?.click());
document.getElementById('maintAgentZipInput')?.addEventListener('change',async e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    try{
        const r=await maintUploadUpdateZip(file);
        maintUpdateRepoRender(r,String((r.installed_versions||[])[0]||''));
        await maintLoadAgentBinaryState(maintUpdateRepoSelectedVersion());
        showMsg((r.installed||[]).length+' fichier(s) importé(s) · '+(r.installed_versions||[]).join(', '));
    }catch(err){showMsg(err.message||'Import ZIP impossible.',false);}finally{e.target.value='';setTimeout(()=>{const w=document.getElementById('maintAgentUploadProgress');if(w)w.hidden=true;},1800);}
});
document.getElementById('maintAgentPackagesDelete')?.addEventListener('click',async()=>{
    const versions=[...document.querySelectorAll('[data-maint-update-pair]:checked')].map(x=>String(x.value||'')).filter(Boolean);
    if(!versions.length)return;
    const pairs=Array.isArray(MAINT_UPDATE_REPOSITORY&&MAINT_UPDATE_REPOSITORY.pairs)?MAINT_UPDATE_REPOSITORY.pairs:[];
    const files=[];for(const v of versions){const p=pairs.find(x=>String(x.version||'')===v);if(!p)continue;if(p.package_name)files.push(p.package_name);if(p.bootstrap_name)files.push(p.bootstrap_name);}
    if(!files.length)return;
    if(!confirm('Supprimer '+versions.length+' version(s) du dépôt /updates/ ?'))return;
    try{const r=await post('api/admin_update_packages.php',{action:'delete',files});if(!r.ok&&!Array.isArray(r.deleted))throw new Error(r.error||'Suppression impossible.');maintUpdateRepoRender(r,'');await maintLoadAgentBinaryState(maintUpdateRepoSelectedVersion());showMsg((r.deleted||[]).length+' fichier(s) supprimé(s).');}catch(e){showMsg(e.message||'Suppression impossible.',false);}
});
document.getElementById('maintAgentUpdateRun')?.addEventListener('click',async()=>{
    const targets=maintCheckedPc('maintAgentPcGrid'),box=document.getElementById('maintAgentUpdateResults');
    if(!targets.length){showMsg('Sélectionne au moins un PC.',false);return;}
    const version=maintUpdateRepoSelectedVersion();
    if(!version){showMsg('Aucune version complète n’est disponible dans /updates/.',false);return;}
    const policy=maintAgentRebootPolicy(),rebootIds=maintAgentRebootTargets(targets);
    const rebootSummary=policy.mode==='none'?'sans redémarrage automatique':(dmdRebootPolicyLabel(policy)+' sur '+rebootIds.length+' PC');
    if(!confirm('Déployer la version '+version+' sur '+targets.length+' PC · '+rebootSummary+' ?'))return;
    box.innerHTML='<div class="dmd-maint-empty">Préparation du déploiement '+htmlEsc(version)+'…</div>';
    const btn=document.getElementById('maintAgentUpdateRun');if(btn){btn.disabled=true;btn.textContent='Mise à jour en cours…';}
    try{
        await maintRunDmdUpdateTargets(targets,box,!!document.getElementById('maintAgentForce')?.checked,{policy,agentIds:rebootIds},version);
        const rs=document.getElementById('maintAgentUpdateRunState');if(rs)rs.textContent='Version '+version+' déployée sur '+targets.length+' PC.';
    }catch(e){
        const rs=document.getElementById('maintAgentUpdateRunState');if(rs)rs.textContent='Échec du déploiement.';
        if(!box.querySelector('.dmd-maint-update-progress-row'))box.innerHTML='<div class="dmd-maint-empty">Erreur : '+htmlEsc(e.message||'mise à jour impossible')+'</div>';
        showMsg(e.message||'Mise à jour impossible.',false);
    }finally{if(btn){btn.disabled=false;btn.textContent='Mettre à jour les Agents sélectionnés';}}
});

/* ---------- Mises à jour logiciels (Winget) ---------- */
function maintBulkProgress(prefix,done,total,label=''){
    const wrap=document.getElementById(prefix+'Progress');
    const bar=document.getElementById(prefix+'ProgressBar');
    const text=document.getElementById(prefix+'ProgressText');
    const lab=document.getElementById(prefix+'ProgressLabel');
    const pct=total>0?Math.max(0,Math.min(100,(done/total)*100)):0;
    if(wrap)wrap.hidden=false;
    if(bar)bar.style.width=pct.toFixed(1)+'%';
    if(text)text.textContent=done+' / '+total+' · '+Math.round(pct)+' %';
    if(lab&&label)lab.textContent=label;
}
async function maintRunPool(items,limit,worker){
    const queue=[...items];
    const workers=Array.from({length:Math.max(1,Math.min(limit,queue.length||1))},async()=>{
        while(queue.length){
            const item=queue.shift();
            await worker(item);
        }
    });
    await Promise.all(workers);
}
const MAINT_SWUPDATE_SCAN_RESULTS = new Map();
let MAINT_SWUPDATE_CURRENT_AGENT = '';

function maintSwUpdateParseResult(result){
    result=result&&typeof result==='object'?result:{};

    if(Array.isArray(result.updates)){
        return result.updates.map(x=>({
            name:String(x.name||x.title||x.id||'Logiciel'),
            id:String(x.id||x.package_id||''),
            current:String(x.current_version||x.version||''),
            available:String(x.available_version||x.available||x.new_version||'')
        })).filter(x=>x.id);
    }

    const text=String(result.stdout||'').replace(/\r/g,'').trim();
    if(!text)return [];

    const lines=text.split('\n').map(x=>x.trimEnd()).filter(Boolean);
    const rows=[];

    for(const line of lines){
        if(/^(Nom|Name)\s{2,}(ID|Id)\s{2,}/i.test(line))continue;
        if(/^-{3,}/.test(line))continue;
        if(/^\d+\s+(mise|upgrade)/i.test(line))continue;

        const cols=line.trim().split(/\s{2,}/).map(x=>x.trim()).filter(Boolean);
        if(cols.length<3)continue;

        const name=cols[0]||'Logiciel';
        const id=cols[1]||'';
        const current=cols[2]||'';
        const available=cols[3]||'';

        if(!id || !/^[A-Za-z0-9._+\-]+$/.test(id))continue;
        rows.push({name,id,current,available});
    }

    const seen=new Set();
    return rows.filter(x=>{
        const key=x.id.toLowerCase();
        if(seen.has(key))return false;
        seen.add(key);
        return true;
    });
}

function maintSwUpdateSelectedTargets(){
    return [...document.querySelectorAll('#maintSoftwareUpdatesPcGrid .dmd-software-update-pc-check:checked:not(:disabled)')]
        .map(cb=>String(cb.value||''))
        .filter(Boolean);
}

function maintSwUpdateSelectionUi(){
    const enabled=[...document.querySelectorAll('#maintSoftwareUpdatesPcGrid .dmd-software-update-pc-check:not(:disabled)')];
    const selected=maintSwUpdateSelectedTargets();
    const count=document.getElementById('maintSoftwareUpdatesSelectedCount');
    const all=document.getElementById('maintSoftwareUpdatesAllPc');
    const scan=document.getElementById('maintSoftwareUpdatesScan');
    const state=document.getElementById('maintSoftwareUpdatesState');

    if(count)count.textContent=selected.length+' PC sélectionné'+(selected.length>1?'s':'');
    if(scan)scan.disabled=selected.length===0;

    if(all){
        all.checked=enabled.length>0&&selected.length===enabled.length;
        all.indeterminate=selected.length>0&&selected.length<enabled.length;
    }

    if(state && !scan?.disabled && state.textContent==='Sélectionne au moins un PC'){
        state.textContent='Prêt';
    }else if(state && scan?.disabled){
        state.textContent='Sélectionne au moins un PC';
    }
}

document.getElementById('maintSoftwareUpdatesPcGrid')?.addEventListener('change',e=>{
    if(e.target.matches('.dmd-software-update-pc-check')){
        maintSwUpdateSelectionUi();
    }
});

document.getElementById('maintSoftwareUpdatesAllPc')?.addEventListener('change',e=>{
    document.querySelectorAll('#maintSoftwareUpdatesPcGrid .dmd-software-update-pc-check:not(:disabled)').forEach(cb=>{
        cb.checked=!!e.currentTarget.checked;
    });
    maintSwUpdateSelectionUi();
});

document.querySelectorAll('[data-swupdate-select-group]').forEach(btn=>{
    btn.addEventListener('click',()=>{
        const gid=String(btn.dataset.swupdateSelectGroup||'');
        const groupCards=[...document.querySelectorAll('#maintSoftwareUpdatesPcGrid [data-swupdate-agent]')]
            .filter(card=>String(card.dataset.swupdateGroups||'').split(/\s+/).filter(Boolean).includes(gid));

        const checks=groupCards
            .map(card=>card.querySelector('.dmd-software-update-pc-check'))
            .filter(cb=>cb&&!cb.disabled);

        const allChecked=checks.length>0&&checks.every(cb=>cb.checked);
        checks.forEach(cb=>cb.checked=!allChecked);
        maintSwUpdateSelectionUi();
    });
});

document.querySelector('[data-swupdate-clear]')?.addEventListener('click',()=>{
    document.querySelectorAll('#maintSoftwareUpdatesPcGrid .dmd-software-update-pc-check').forEach(cb=>cb.checked=false);
    maintSwUpdateSelectionUi();
});

function maintSwUpdateRenderResultTabs(){
    const box=document.getElementById('maintSoftwareUpdatesResultTabs');
    if(!box)return;

    const rows=[...MAINT_SWUPDATE_SCAN_RESULTS.values()];
    box.innerHTML=rows.map(row=>{
        const count=row.status==='error'?'!':(Array.isArray(row.updates)?row.updates.length:0);
        const cls=row.status==='error'?' error':'';
        return `<button type="button" class="dmd-software-update-result-tab${cls}" data-swupdate-result-agent="${htmlEsc(row.agent_id)}">
            <span>${htmlEsc(row.host||row.agent_id)}</span>
            <b>${htmlEsc(String(count))}</b>
        </button>`;
    }).join('');

    box.querySelectorAll('[data-swupdate-result-agent]').forEach(btn=>{
        btn.addEventListener('click',()=>maintSwUpdateOpenDetails(btn.dataset.swupdateResultAgent));
    });
}

async function maintSoftwareUpdatesScanSelected(){
    const targets=maintSwUpdateSelectedTargets();
    const stateEl=document.getElementById('maintSoftwareUpdatesState');
    const scanBtn=document.getElementById('maintSoftwareUpdatesScan');

    if(!targets.length){
        showMsg('Sélectionne au moins un PC.',false);
        return;
    }

    MAINT_SWUPDATE_SCAN_RESULTS.clear();
    targets.forEach(id=>MAINT_SWUPDATE_SCAN_RESULTS.set(id,{
        agent_id:id,
        host:maintDevice(id)?.hostname||id,
        status:'waiting',
        result:null,
        updates:[]
    }));

    if(scanBtn)scanBtn.disabled=true;
    if(stateEl)stateEl.textContent='Recherche…';
    maintBulkProgress('maintSoftwareUpdates',0,targets.length,'Recherche Winget sur les PC sélectionnés…');

    let done=0;

    try{
        await maintRunPool(targets,4,async agentId=>{
            const row=MAINT_SWUPDATE_SCAN_RESULTS.get(agentId);
            row.status='running';

            try{
                row.result=await maintRunCommand(
                    agentId,
                    'software.updates.scan',
                    {include_unknown:true},
                    7*60*1000
                );
                row.updates=maintSwUpdateParseResult(row.result);
                row.status='completed';
            }catch(e){
                row.status='error';
                row.error=e.message||'Recherche impossible';
            }

            done++;
            maintBulkProgress(
                'maintSoftwareUpdates',
                done,
                targets.length,
                'Recherche terminée sur '+done+' / '+targets.length+' PC'
            );
        });

        const failed=[...MAINT_SWUPDATE_SCAN_RESULTS.values()].filter(x=>x.status==='error').length;
        if(stateEl){
            stateEl.textContent=failed
                ? `${targets.length-failed} OK · ${failed} échec${failed>1?'s':''}`
                : 'Terminé';
        }

        maintSwUpdateRenderResultTabs();

        const firstOk=[...MAINT_SWUPDATE_SCAN_RESULTS.values()].find(x=>x.status==='completed')
            || [...MAINT_SWUPDATE_SCAN_RESULTS.values()][0];

        const modal=document.getElementById('maintenanceSoftwareUpdatesDetailsModal');
        if(modal)modal.hidden=false;

        if(firstOk){
            maintSwUpdateOpenDetails(firstOk.agent_id);
        }
    }finally{
        if(scanBtn)scanBtn.disabled=maintSwUpdateSelectedTargets().length===0;
    }
}

document.getElementById('maintSoftwareUpdatesScan')?.addEventListener('click',maintSoftwareUpdatesScanSelected);

function maintSwUpdateCloseDetails(){
    const modal=document.getElementById('maintenanceSoftwareUpdatesDetailsModal');
    if(modal)modal.hidden=true;
    MAINT_SWUPDATE_CURRENT_AGENT='';
}

function maintSwUpdateSelectionRefresh(){
    const list=document.getElementById('maintSoftwareUpdatesDetailsList');
    const checks=list?[...list.querySelectorAll('input[data-swupdate-id]:checked')]:[];
    const all=list?[...list.querySelectorAll('input[data-swupdate-id]')]:[];
    const count=document.getElementById('maintSoftwareUpdatesDetailsCount');
    const install=document.getElementById('maintSoftwareUpdatesInstallSelected');
    const selectAll=document.getElementById('maintSoftwareUpdatesSelectAll');

    if(count){
        count.textContent=checks.length+' mise'+(checks.length>1?'s':'')+' à jour sélectionnée'+(checks.length>1?'s':'');
    }
    if(install)install.disabled=checks.length===0;

    if(selectAll){
        selectAll.checked=all.length>0&&checks.length===all.length;
        selectAll.indeterminate=checks.length>0&&checks.length<all.length;
    }
}

function maintSwUpdateTargetOptions(agentId){
    const select=document.getElementById('maintSoftwareUpdatesInstallTarget');
    if(!select)return;

    const card=document.querySelector(`#maintSoftwareUpdatesPcGrid [data-swupdate-agent="${CSS.escape(String(agentId))}"]`);
    const gids=card?String(card.dataset.swupdateGroups||'').split(/\s+/).filter(Boolean):[];

    const groupButtons=[...document.querySelectorAll('[data-swupdate-select-group]')]
        .filter(btn=>gids.includes(String(btn.dataset.swupdateSelectGroup||'')));

    select.innerHTML=
        '<option value="pc">Ce PC uniquement</option>'+
        groupButtons.map(btn=>
            `<option value="group:${htmlEsc(btn.dataset.swupdateSelectGroup||'')}">Groupe : ${htmlEsc(btn.textContent.trim())}</option>`
        ).join('');
}

function maintSwUpdateOpenDetails(agentId){
    const row=MAINT_SWUPDATE_SCAN_RESULTS.get(String(agentId||''));
    if(!row)return;

    const modal=document.getElementById('maintenanceSoftwareUpdatesDetailsModal');
    const title=document.getElementById('maintSoftwareUpdatesDetailsTitle');
    const sub=document.getElementById('maintSoftwareUpdatesDetailsSub');
    const list=document.getElementById('maintSoftwareUpdatesDetailsList');

    MAINT_SWUPDATE_CURRENT_AGENT=String(agentId);

    document.querySelectorAll('[data-swupdate-result-agent]').forEach(btn=>{
        btn.classList.toggle('active',String(btn.dataset.swupdateResultAgent||'')===String(agentId));
    });

    const device=maintDevice(agentId);
    if(title)title.textContent='Mises à jour · '+(device?.hostname||agentId);

    const card=document.querySelector(`#maintSoftwareUpdatesPcGrid [data-swupdate-agent="${CSS.escape(String(agentId))}"]`);
    const groupNames=[];
    if(card){
        const gids=String(card.dataset.swupdateGroups||'').split(/\s+/).filter(Boolean);
        document.querySelectorAll('[data-swupdate-select-group]').forEach(btn=>{
            if(gids.includes(String(btn.dataset.swupdateSelectGroup||'')))groupNames.push(btn.textContent.trim());
        });
    }

    if(row.status==='error'){
        if(sub)sub.textContent=(groupNames.length?groupNames.join(', '):'Sans groupe')+' · recherche en erreur';
        if(list)list.innerHTML=`<div class="dmd-software-update-empty">${htmlEsc(row.error||'Recherche impossible sur ce PC.')}</div>`;
    }else{
        const updates=Array.isArray(row.updates)?row.updates:[];
        if(sub){
            sub.textContent=(groupNames.length?groupNames.join(', '):'Sans groupe')+
                ' · '+updates.length+' mise'+(updates.length>1?'s':'')+' à jour trouvée'+(updates.length>1?'s':'');
        }

        if(list){
            list.innerHTML=updates.length
                ? updates.map(u=>`<label class="dmd-software-update-item">
                    <input type="checkbox" data-swupdate-id value="${htmlEsc(u.id)}">
                    <span class="dmd-software-update-item-copy">
                        <strong>${htmlEsc(u.name||u.id)}</strong>
                        <small>${htmlEsc(u.id)}</small>
                    </span>
                    <span class="dmd-software-update-version">
                        <small>${htmlEsc(u.current||'—')}</small>
                        <strong>${htmlEsc(u.available||'Disponible')}</strong>
                    </span>
                </label>`).join('')
                : '<div class="dmd-software-update-empty">Aucune mise à jour logicielle disponible sur ce PC.</div>';
        }
    }

    maintSwUpdateTargetOptions(agentId);

    const all=document.getElementById('maintSoftwareUpdatesSelectAll');
    if(all){all.checked=false;all.indeterminate=false;}

    const progress=document.getElementById('maintSoftwareUpdatesInstallProgress');
    if(progress)progress.hidden=true;

    maintSwUpdateSelectionRefresh();
    if(modal)modal.hidden=false;
}

document.getElementById('maintSoftwareUpdatesSelectAll')?.addEventListener('change',e=>{
    document.querySelectorAll('#maintSoftwareUpdatesDetailsList input[data-swupdate-id]').forEach(cb=>{
        cb.checked=!!e.currentTarget.checked;
    });
    maintSwUpdateSelectionRefresh();
});

document.getElementById('maintSoftwareUpdatesDetailsList')?.addEventListener('change',e=>{
    if(e.target.matches('input[data-swupdate-id]'))maintSwUpdateSelectionRefresh();
});

document.querySelectorAll('[data-swupdate-details-close]').forEach(el=>{
    el.addEventListener('click',maintSwUpdateCloseDetails);
});

function maintSwUpdateGroupTargets(groupId){
    return [...document.querySelectorAll('#maintSoftwareUpdatesPcGrid [data-swupdate-agent]')]
        .filter(card=>String(card.dataset.swupdateGroups||'').split(/\s+/).filter(Boolean).includes(String(groupId||'')))
        .map(card=>card.querySelector('.dmd-software-update-pc-check'))
        .filter(cb=>cb&&!cb.disabled)
        .map(cb=>String(cb.value||''))
        .filter(Boolean);
}

async function maintSoftwareUpdatesInstallSelected(){
    const sourceAgent=MAINT_SWUPDATE_CURRENT_AGENT;
    if(!sourceAgent)return;

    const selected=[...document.querySelectorAll('#maintSoftwareUpdatesDetailsList input[data-swupdate-id]:checked')]
        .map(cb=>String(cb.value||'').trim())
        .filter(Boolean);

    if(!selected.length)return;

    const targetValue=document.getElementById('maintSoftwareUpdatesInstallTarget')?.value||'pc';
    let targets=[sourceAgent];
    let targetLabel=maintDevice(sourceAgent)?.hostname||sourceAgent;

    if(targetValue.startsWith('group:')){
        const gid=targetValue.slice(6);
        targets=maintSwUpdateGroupTargets(gid);
        const btn=document.querySelector(`[data-swupdate-select-group="${CSS.escape(gid)}"]`);
        targetLabel='le groupe '+(btn?.textContent.trim()||gid);
    }

    if(!targets.length){
        showMsg('Aucun PC en ligne dans cette cible.',false);
        return;
    }

    if(!confirm(
        `Installer ${selected.length} mise${selected.length>1?'s':''} à jour `+
        `sur ${targetLabel} (${targets.length} PC) ?`
    ))return;

    const btn=document.getElementById('maintSoftwareUpdatesInstallSelected');
    const progress=document.getElementById('maintSoftwareUpdatesInstallProgress');
    const progressText=document.getElementById('maintSoftwareUpdatesInstallProgressText');

    if(btn)btn.disabled=true;
    if(progress)progress.hidden=false;

    let totalJobs=targets.length*selected.length;
    let done=0;
    let failed=0;

    try{
        await maintRunPool(targets,3,async agentId=>{
            for(const id of selected){
                if(progressText)progressText.textContent=`${done} / ${totalJobs}`;
                try{
                    await maintRunCommand(
                        agentId,
                        'software.updates.apply',
                        {id:id,all:false},
                        35*60*1000
                    );
                }catch(e){
                    failed++;
                }
                done++;
                if(progressText)progressText.textContent=`${done} / ${totalJobs}`;
            }
        });

        showMsg(
            failed
                ? `Installation terminée : ${totalJobs-failed} OK · ${failed} échec${failed>1?'s':''}.`
                : `Installation terminée : ${totalJobs} opération${totalJobs>1?'s':''}.`,
            failed===0
        );

        // Actualise seulement les PC qui étaient sélectionnés.
        maintSwUpdateCloseDetails();
        setTimeout(()=>maintSoftwareUpdatesScanSelected().catch(()=>{}),500);
    }finally{
        if(btn)btn.disabled=false;
    }
}

document.getElementById('maintSoftwareUpdatesInstallSelected')?.addEventListener('click',maintSoftwareUpdatesInstallSelected);

document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    const modal=document.getElementById('maintenanceSoftwareUpdatesDetailsModal');
    if(modal&&!modal.hidden){
        e.preventDefault();
        e.stopImmediatePropagation();
        maintSwUpdateCloseDetails();
    }
},true);

maintSwUpdateSelectionUi();

/* ---------- Windows Update ---------- */
function maintWindowsResultCodeLabel(code){
    const n=Number(code);
    return ({0:'Non démarrée',1:'En cours',2:'Réussie',3:'Réussie avec erreurs',4:'Échec',5:'Annulée'})[n]||('Code '+String(code??'—'));
}
function maintWindowsRowsRender(results,box){
    if(!box)return;
    box.innerHTML=[...results.values()].map(row=>{
        const host=htmlEsc(row.host||row.agent_id||'PC');
        const status=String(row.status||'waiting');
        if(status==='waiting')return `<article class="dmd-maint-update-detail-card"><div class="dmd-maint-update-detail-head"><strong>${host}</strong><span>En attente</span></div></article>`;
        if(status==='running'){
            return `<article class="dmd-maint-update-detail-card running"><div class="dmd-maint-update-detail-head"><strong>${host}</strong><span>${htmlEsc(row.phase||'En cours')}</span></div><div class="dmd-maint-update-progressbar is-indeterminate"><i></i></div><small>${htmlEsc(row.message||'Windows Update travaille sur le PC distant…')}</small></article>`;
        }
        if(status==='error'){
            return `<article class="dmd-maint-update-detail-card error"><div class="dmd-maint-update-detail-head"><strong>${host}</strong><span>Échec</span></div><small>${htmlEsc(row.error||'Erreur inconnue')}</small></article>`;
        }
        const r=row.result&&typeof row.result==='object'?row.result:{};
        if(row.mode==='scan'){
            const updates=Array.isArray(r.updates)?r.updates:[];
            const errors=Array.isArray(r.search_errors)?r.search_errors:[];
            const count=Number(r.count||updates.length);
            const list=updates.length?`<div class="dmd-maint-windows-update-list">${updates.map(u=>{
                const kb=Array.isArray(u.kb)&&u.kb.length?u.kb.map(x=>'KB'+String(x).replace(/^KB/i,'')).join(' · '):'';
                const meta=[kb,u.browse_only?'Optionnelle':'',u.source||''].filter(Boolean).join(' · ');
                return `<div class="dmd-maint-windows-update-row"><div><strong>${htmlEsc(u.title||'Mise à jour Windows')}</strong><small>${htmlEsc(meta||'Windows Update')}</small></div><span>${htmlEsc(u.downloaded?'Téléchargée':'Disponible')}</span></div>`;
            }).join('')}</div>`:'<div class="dmd-maint-update-none">Aucune mise à jour disponible.</div>';
            const errHtml=errors.length?`<details class="dmd-maint-update-errors"><summary>${errors.length} avertissement${errors.length>1?'s':''} de recherche</summary><pre>${htmlEsc(errors.join('\n'))}</pre></details>`:'';
            return `<article class="dmd-maint-update-detail-card success"><div class="dmd-maint-update-detail-head"><strong>${host}</strong><span>${count} mise${count>1?'s':''} à jour</span></div><div class="dmd-maint-update-summaryline"><span>${r.reboot_required?'Redémarrage déjà requis':'Pas de redémarrage requis avant installation'}</span><span>${htmlEsc((Array.isArray(r.sources_checked)?r.sources_checked.length:0)+' source(s) interrogée(s)')}</span></div>${list}${errHtml}</article>`;
        }
        const updates=Array.isArray(r.updates)?r.updates:[];
        const count=Number(r.count||updates.length);
        const list=updates.length?`<div class="dmd-maint-windows-update-list">${updates.map(u=>`<div class="dmd-maint-windows-update-row"><div><strong>${htmlEsc(u.title||'Mise à jour Windows')}</strong><small>${htmlEsc(u.update_id||'')}</small></div><span>${htmlEsc(maintWindowsResultCodeLabel(u.result_code))}</span></div>`).join('')}</div>`:'';
        return `<article class="dmd-maint-update-detail-card success"><div class="dmd-maint-update-detail-head"><strong>${host}</strong><span>Installation terminée</span></div><div class="dmd-maint-update-summaryline"><span>${count} mise${count>1?'s':''} à jour traitée${count>1?'s':''}</span><span>${r.reboot_required?'Redémarrage requis':'Aucun redémarrage signalé'}</span></div>${list}</article>`;
    }).join('');
}
async function maintWindowsStartScan(agentId,row){
    row.status='running';row.phase='Démarrage';row.message='Démarrage de la recherche Windows Update…';
    try{
        const r=await maintRunCommand(agentId,'windows_update.scan',{force:true},120000);
        row.result=r;
        if(r&&String(r.status||'').toLowerCase()==='error')throw new Error(r.error_message||'Recherche Windows Update impossible.');
        if(!(r&&r.scanning)){row.status='completed';return;}
        row.phase='Recherche';row.message='Windows Update recherche les mises à jour sur le PC distant.';
    }catch(e){row.status='error';row.error=e.message||'Démarrage impossible';}
}
async function maintWindowsPollScan(agentId,row,onTick){
    if(row.status!=='running')return;
    const started=Date.now(),deadline=started+8*60*1000;
    while(Date.now()<deadline){
        await new Promise(r=>setTimeout(r,3500));
        const elapsed=Math.max(1,Math.round((Date.now()-started)/1000));
        row.phase='Recherche · '+elapsed+' s';
        row.message=elapsed<45?'Interrogation Windows Update en cours…':'Windows Update travaille encore sur le PC distant. La recherche peut prendre quelques minutes selon Microsoft ou WSUS.';
        if(onTick)onTick();
        try{
            const r=await maintRunCommand(agentId,'windows_update.scan',{force:false},120000);
            row.result=r;
            if(r&&String(r.status||'').toLowerCase()==='error')throw new Error(r.error_message||'Recherche Windows Update impossible.');
            if(!(r&&r.scanning)){row.status='completed';return;}
        }catch(e){row.status='error';row.error=e.message||'Lecture du résultat impossible';return;}
    }
    row.status='error';row.error='Windows Update n’a pas rendu son résultat après 8 minutes. Vérifie Windows Update/WSUS sur ce PC et le journal DMD-Agent.';
}
async function maintPcUpdate(mode){
    const targets=maintCheckedPc('maintPcUpdatePcGrid');
    const box=document.getElementById('maintPcUpdateResults');
    const stateEl=document.getElementById('maintPcUpdateState');
    const scanBtn=document.getElementById('maintPcUpdateScan');
    const installBtn=document.getElementById('maintPcUpdateInstall');
    if(!targets.length){showMsg('Sélectionne au moins un PC ou un groupe.',false);return;}
    if(mode==='install'&&!confirm('Télécharger et installer les mises à jour Windows sur '+targets.length+' PC ?'))return;
    const results=new Map(targets.map(id=>[id,{agent_id:id,host:maintDevice(id)?.hostname||id,status:'waiting',mode}]));
    let done=0;
    if(scanBtn)scanBtn.disabled=true;if(installBtn)installBtn.disabled=true;
    if(stateEl)stateEl.textContent=mode==='scan'?'Recherche…':'Installation…';
    maintWindowsRowsRender(results,box);
    maintBulkProgress('maintPcUpdate',0,targets.length,mode==='scan'?'Démarrage des recherches Windows Update…':'Installation Windows Update…');
    try{
        if(mode==='scan'){
            await maintRunPool(targets,8,async agentId=>{
                const row=results.get(agentId);
                await maintWindowsStartScan(agentId,row);
                if(row.status==='completed'||row.status==='error')done++;
                maintBulkProgress('maintPcUpdate',done,targets.length,'Recherches lancées · '+done+' résultat'+(done>1?'s':'')+' reçu'+(done>1?'s':''));
                maintWindowsRowsRender(results,box);
            });
            const polling=targets.filter(id=>results.get(id)?.status==='running');
            await maintRunPool(polling,6,async agentId=>{
                const row=results.get(agentId);
                await maintWindowsPollScan(agentId,row,()=>maintWindowsRowsRender(results,box));
                done++;
                maintBulkProgress('maintPcUpdate',done,targets.length,'Résultats Windows Update reçus : '+done+' / '+targets.length);
                maintWindowsRowsRender(results,box);
            });
        }else{
            await maintRunPool(targets,3,async agentId=>{
                const row=results.get(agentId);row.status='running';row.phase='Installation';row.message='Téléchargement et installation par Windows Update…';maintWindowsRowsRender(results,box);
                try{
                    row.result=await maintRunCommand(agentId,'windows_update.install',{all:true,update_ids:[]},50*60*1000);
                    row.status='completed';
                }catch(e){row.status='error';row.error=e.message||'Installation impossible';}
                done++;
                maintBulkProgress('maintPcUpdate',done,targets.length,'Installations terminées : '+done+' / '+targets.length);
                maintWindowsRowsRender(results,box);
            });
        }
        const failed=[...results.values()].filter(x=>x.status==='error').length;
        if(stateEl){stateEl.textContent=failed?(targets.length-failed)+' OK · '+failed+' échec'+(failed>1?'s':''):'Terminé';stateEl.classList.toggle('ok',failed===0);}
    }finally{
        if(scanBtn)scanBtn.disabled=false;if(installBtn)installBtn.disabled=false;
    }
}
document.getElementById('maintPcUpdateScan')?.addEventListener('click',()=>maintPcUpdate('scan'));
document.getElementById('maintPcUpdateInstall')?.addEventListener('click',()=>maintPcUpdate('install'));

/* ---------- Configuration MyDesk ---------- */
function maintRefreshMyDeskCount(){
    const root=document.getElementById('maintMyDeskModules'),el=document.getElementById('maintMyDeskCount');
    if(!root||!el)return;
    const checked=root.querySelectorAll('input[type=checkbox]:checked').length;
    el.textContent=checked+' / '+String(DMD_MYDESK_LIMIT_LABEL);
}
document.querySelectorAll('#maintMyDeskModules input[type=checkbox]').forEach(x=>x.addEventListener('change',maintRefreshMyDeskCount));
document.getElementById('maintenanceMyDeskForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const ids=[...document.querySelectorAll('#maintMyDeskModules input[type=checkbox]:checked')].map(x=>x.value);
    const r=await post('api/admin_mydesk_settings.php',{enabled_modules:ids});
    const box=document.getElementById('maintMyDeskResult');
    if(!r.ok){box.textContent='Erreur : '+(r.error||'enregistrement impossible');return;}
    box.textContent='Configuration MyDesk enregistrée : '+ids.length+' module(s) actif(s).';
    showMsg('Configuration DMD-MyDesk enregistrée.');
    maintRefreshMyDeskCount();
});

/* Échap : popup PC d’abord, puis popup Maintenance. */
document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    const opened=Object.values(MAINTENANCE_POPUPS).find(x=>x&&!x.hidden);
    if(opened){e.stopImmediatePropagation();maintClose();}
},true);


document.getElementById('createForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const res=await post('api/admin_create_enrollment.php',{target_name:fd.get('target_name'),expires_minutes:Number(fd.get('expires_minutes')),approval_mode:fd.get('approval_mode'),include_remote:fd.get('include_remote')==='1',include_mydesk:fd.get('include_mydesk')==='1',server_url:DMD_SERVER_URL});if(!res.ok){showMsg('Création refusée : '+(res.error||res.code||'erreur'),false);return;}const text=JSON.stringify(res.bootstrap,null,2);document.getElementById('bootstrapText').value=text;document.getElementById('bootstrapBox').classList.add('show');showMsg('Enrôlement créé. Génération de DMD-Installer + JSON…');await downloadInstallerForBootstrap(res.bootstrap);});
document.getElementById('downloadBootstrap').addEventListener('click',()=>{const text=document.getElementById('bootstrapText').value;if(!text)return;const data=JSON.parse(text);const blob=new Blob([text+'\n'],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='DMD-Agent-'+(data.enrollment_id||'bootstrap')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});
async function downloadInstallerForBootstrap(bootstrap){
    if(!bootstrap||!bootstrap.enrollment_id){showMsg('Bootstrap invalide.',false);return false;}
    showMsg('Génération du pack Windows d’enrôlement…');
    const r=await fetch('api/admin_build_install_bundle.php',{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':CSRF},body:JSON.stringify({csrf_token:CSRF,bootstrap}),credentials:'same-origin'});
    if(!r.ok){let t='';try{t=await r.text();}catch(e){}showMsg('Installateur impossible : '+(t||('HTTP '+r.status)),false);return false;}
    const blob=await r.blob();
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='DMD-Installer-'+(bootstrap.enrollment_id||'enrollment')+'.zip';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500);
    showMsg('ZIP prêt : DMD-Installer.exe + bootstrap.json.');
    return true;
}
document.getElementById('downloadBundle').addEventListener('click',async()=>{const text=document.getElementById('bootstrapText').value;if(!text){showMsg('Crée d’abord un enrôlement.',false);return;}let bootstrap;try{bootstrap=JSON.parse(text);}catch(e){showMsg('Bootstrap JSON invalide.',false);return;}await downloadInstallerForBootstrap(bootstrap);});
document.getElementById('copyBootstrap').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(document.getElementById('bootstrapText').value);showMsg('Bootstrap copié.');}catch(e){showMsg('Copie impossible.',false);}});
document.getElementById('selfTest').addEventListener('click',async()=>{showMsg('Autotest en cours…');const r=await post('api/self_test.php',{});showMsg(r.ok?'Autotest réussi : identité, challenge, preuve de possession, certificat et destruction du token sont OK.':'Autotest en échec : '+JSON.stringify(r),!!r.ok);});
function enrollmentRows(){return [...document.querySelectorAll('#panel-enrollments [data-enrollment-id]')];}
function enrollmentStatusLabel(status){const map={created:'Créé',challenge:'Challenge envoyé',pending_approval:'Validation requise',approved:'Approuvé',completed:'Terminé',expired:'Expiré',rejected:'Refusé'};return map[status]||status||'—';}
function refreshEnrollmentManageUi(){
    const btn=document.getElementById('deleteAllEnrollments');
    const count=enrollmentRows().length;
    if(btn){btn.textContent='Tout supprimer ('+count+')';btn.hidden=count===0;btn.disabled=false;}
    const list=document.querySelector('#panel-enrollments .dmd-agent-enrollment-list');
    if(list && count===0 && !list.querySelector('.dmd-agent-empty')){
        list.innerHTML='<div class="dmd-agent-empty compact"><strong>Aucun enrôlement</strong><span>Les demandes apparaîtront ici.</span></div>';
    }
}
function removeEnrollmentRows(ids){
    const wanted=new Set((ids||[]).map(String));
    enrollmentRows().forEach(row=>{const id=String(row.dataset.enrollmentId||'');if(wanted.has(id))row.remove();});
    refreshEnrollmentManageUi();
}
function enrollmentActionsHtml(e){
    const id=htmlEsc(e.enrollment_id||'');
    const st=String(e.status||'');
    let out='';
    if(st==='pending_approval') out+='<button class="dmd-agent-mini-btn decision" data-id="'+id+'" data-decision="approve">Autoriser</button><button class="dmd-agent-mini-btn danger decision" data-id="'+id+'" data-decision="reject">Refuser</button>';
    if(st!=='completed') out+='<button type="button" class="dmd-agent-mini-btn renew-enrollment" data-id="'+id+'" title="Créer une nouvelle invitation avec les mêmes paramètres">Relancer</button>';
    out+='<button type="button" class="dmd-agent-mini-btn danger delete-enrollment" data-id="'+id+'" data-status="'+htmlEsc(st)+'" title="Supprimer cet enrôlement de l’historique">Supprimer</button>';
    return out;
}
function replaceEnrollmentRow(oldId,e){
    const row=enrollmentRows().find(x=>String(x.dataset.enrollmentId||'')===String(oldId));
    if(!row||!e)return;
    const candidate=(e.candidate&&e.candidate.hostname)?e.candidate.hostname:'Aucun PC présenté';
    row.dataset.enrollmentId=e.enrollment_id||'';
    row.dataset.enrollmentStatus=e.status||'';
    row.innerHTML='<div class="dmd-agent-enrollment-status"><span class="dmd-agent-status-dot '+htmlEsc(e.status||'')+'"></span></div>'+
        '<div class="dmd-agent-enrollment-main"><strong>'+htmlEsc(e.target_name||'PC')+'</strong><span>'+htmlEsc(candidate)+'</span></div>'+
        '<div class="dmd-agent-enrollment-id"><small>'+htmlEsc(e.enrollment_id||'')+'</small><span class="dmd-agent-status '+htmlEsc(e.status||'')+'">'+htmlEsc(enrollmentStatusLabel(e.status||''))+'</span></div>'+
        '<div class="dmd-agent-enrollment-date dmd-agent-date" data-date="'+htmlEsc(e.created_at||'')+'">'+htmlEsc(formatDate(e.created_at||''))+'</div>'+
        '<div class="dmd-agent-enrollment-actions">'+enrollmentActionsHtml(e)+'</div>';
    refreshEnrollmentManageUi();
}
const enrollmentPanel=document.getElementById('panel-enrollments');
if(enrollmentPanel)enrollmentPanel.addEventListener('click',async e=>{
    const decisionBtn=e.target.closest('.decision');
    if(decisionBtn){
        e.preventDefault();
        e.stopPropagation();

        const decision=decisionBtn.dataset.decision||'';
        const id=decisionBtn.dataset.id||'';
        if(!id || !decision)return;

        if(!confirm((decision==='approve'?'Autoriser':'Refuser')+' cet enrôlement ?'))return;

        decisionBtn.disabled=true;
        const r=await post('api/admin_decision.php',{
            enrollment_id:id,
            decision:decision
        });

        if(r.ok){
            showMsg(decision==='approve'?'Enrôlement autorisé.':'Enrôlement refusé.');
            location.reload();
            return;
        }

        decisionBtn.disabled=false;
        showMsg('Action refusée : '+(r.error||'erreur'),false);
        return;
    }

    const del=e.target.closest('.delete-enrollment');
    if(del){
        e.preventDefault();e.stopPropagation();
        const id=del.dataset.id||'',status=del.dataset.status||'';
        if(!id)return;
        let warning='Supprimer définitivement cet enrôlement de l’historique ?\n\n'+id;
        if(status==='completed') warning+='\n\nLe PC déjà enrôlé restera actif : seul cet historique sera supprimé.';
        else warning+='\n\nS’il s’agit d’une invitation encore utilisable, elle sera immédiatement invalidée.';
        if(!confirm(warning))return;
        del.disabled=true;
        const r=await post('api/admin_manage_enrollments.php',{mode:'delete_one',enrollment_id:id});
        if(r.ok){removeEnrollmentRows(r.enrollment_ids&&r.enrollment_ids.length?r.enrollment_ids:[id]);showMsg('Enrôlement supprimé.');return;}
        del.disabled=false;showMsg('Suppression impossible : '+(r.error||'erreur'),false);return;
    }
    const renew=e.target.closest('.renew-enrollment');
    if(renew){
        e.preventDefault();e.stopPropagation();
        const id=renew.dataset.id||'';if(!id)return;
        if(!confirm('Relancer cette invitation ?\n\nL’ancienne invitation sera invalidée et un nouvel enrôlement avec un nouveau token et une nouvelle date d’expiration sera créé.'))return;
        renew.disabled=true;
        showMsg('Relance de l’invitation…');
        const r=await post('api/admin_manage_enrollments.php',{mode:'renew',enrollment_id:id,server_url:DMD_SERVER_URL});
        if(!r.ok){renew.disabled=false;showMsg('Relance impossible : '+(r.error||'erreur'),false);return;}
        if(r.bootstrap){
            document.getElementById('bootstrapText').value=JSON.stringify(r.bootstrap,null,2);
            document.getElementById('bootstrapBox').classList.add('show');
            await downloadInstallerForBootstrap(r.bootstrap);
        }
        showMsg('Invitation relancée.');
        location.reload();
        return;
    }
});

/* Recherche dans les PC enrôlés et les enrôlements en cours. */
(function(){
    const input=document.getElementById('enrollmentPcSearch');
    const clear=document.getElementById('enrollmentPcSearchClear');
    const grid=document.getElementById('enrollmentPcGrid');
    const empty=document.getElementById('enrollmentPcSearchEmpty');

    if(!input || !grid)return;

    function normalize(v){
        return String(v||'')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g,'')
            .trim();
    }

    function apply(){
        const q=normalize(input.value);
        let shown=0;

        grid.querySelectorAll('.dmd-enrollment-card').forEach(card=>{
            const hay=normalize(card.dataset.enrollmentSearch||card.textContent||'');
            const visible=!q || hay.includes(q);
            card.hidden=!visible;
            if(visible)shown++;
        });

        if(empty)empty.hidden=shown>0;
    }

    input.addEventListener('input',apply);

    clear?.addEventListener('click',()=>{
        input.value='';
        apply();
        input.focus();
    });
})();

const deleteAllBtn=document.getElementById('deleteAllEnrollments');
if(deleteAllBtn)deleteAllBtn.addEventListener('click',async e=>{
    e.preventDefault();e.stopPropagation();
    const count=enrollmentRows().length;if(!count)return;
    if(!confirm('Supprimer TOUS les enrôlements de l’historique ?\n\n'+count+' entrée(s) seront supprimée(s).\n\nLes PC déjà enrôlés resteront actifs, mais toutes les invitations en attente ou encore valides seront invalidées.'))return;
    deleteAllBtn.disabled=true;
    const r=await post('api/admin_manage_enrollments.php',{mode:'delete_all'});
    if(r.ok){removeEnrollmentRows((r.enrollment_ids&&r.enrollment_ids.length)?r.enrollment_ids:enrollmentRows().map(x=>x.dataset.enrollmentId||''));showMsg((r.deleted||0)+' enrôlement(s) supprimé(s).');return;}
    deleteAllBtn.disabled=false;showMsg('Suppression globale impossible : '+(r.error||'erreur'),false);
});
async function revokeAgent(agentId){if(!confirm('Révoquer cet agent ? Son fichier actif et son enrôlement seront supprimés après création d’un audit signé.'))return;const reason=prompt('Motif de révocation (facultatif, conservé dans l’audit) :','')??'';const r=await post('api/admin_revoke.php',{agent_id:agentId,reason});if(r.ok)location.reload();else showMsg('Révocation impossible : '+(r.error||'erreur'),false);}
async function downloadMyDeskUpgrade(agentId){
    const btn=document.getElementById('deviceMyDeskUpgrade');
    if(!agentId||!btn)return;
    const old=btn.textContent;btn.disabled=true;btn.textContent='Préparation du pack…';
    try{
        const r=await fetch('api/admin_mydesk_agent_upgrade.php',{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':CSRF},body:JSON.stringify({csrf_token:CSRF,agent_id:agentId}),credentials:'same-origin'});
        if(!r.ok){let err='Création du pack impossible.';try{const j=await r.json();err=j.error||err;}catch(e){}throw new Error(err);}
        const blob=await r.blob();
        let filename='DMD-Agent-MyDesk-UPGRADE-'+agentId+'.zip';
        const cd=r.headers.get('Content-Disposition')||'';const m=cd.match(/filename="?([^";]+)"?/i);if(m&&m[1])filename=m[1];
        const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);
        showMsg('Pack DMD-MyDesk généré : même Agent ID, DMD-MyDesk reste dépendant de DMD-Agent et utilise la capability signée mydesk.client.');
        btn.textContent='Activer / mettre à niveau DMD-MyDesk';
    }catch(e){showMsg('DMD-MyDesk : '+e.message,false);btn.textContent=old;}
    finally{btn.disabled=false;}
}
document.getElementById('deviceMyDeskUpgrade').addEventListener('click',()=>{if(selectedDevice)downloadMyDeskUpgrade(selectedDevice.agent_id);});
document.getElementById('deviceRevoke').addEventListener('click',()=>{if(selectedDevice)revokeAgent(selectedDevice.agent_id);});

// Signed audit viewer
const auditModal=document.getElementById('auditModal');
function openAudit(id){
    const a=AGENT_AUDITS.find(x=>x.audit_id===id);if(!a)return;
    const ag=a.agent||{},rv=a.revocation||{},inv=obj(ag.last_inventory),tel=obj(ag.telemetry);
    document.getElementById('auditModalTitle').textContent=ag.hostname||'PC révoqué';
    document.getElementById('auditModalSub').textContent=(ag.agent_id||'')+(ag.last_ip?' · '+ag.last_ip:'');
    document.getElementById('auditSignatureState').textContent=a.signature_valid?'Signature valide':'Signature invalide';
    document.getElementById('auditSignatureDot').className='dmd-agent-live-dot '+(a.signature_valid?'online':'');
    document.getElementById('auditGeneral').innerHTML=[detail('Agent ID',ag.agent_id),detail('Système',(ag.platform||'—')+(ag.arch?' / '+ag.arch:'')),detail('Version Agent',ag.agent_version),detail('Dernier contact',formatDate(ag.last_seen_at)),detail('Dernière IP',ag.last_ip),detail('Empreinte PC',ag.device_key_fingerprint)].join('');
    document.getElementById('auditRevocation').innerHTML=[detail('Date',formatDate(rv.revoked_at)),detail('Révoqué par',rv.revoked_by),detail('Motif',rv.reason||'Non renseigné'),detail('Audit ID',a.audit_id)].join('');
    const cpu=obj(firstValue(tel.cpu,inv.cpu,{})),mem=obj(firstValue(tel.memory,tel.ram,inv.memory,inv.ram,{}));
    const ports=normalizePorts(firstValue(tel.open_ports,ag.open_ports,inv.open_ports,[])),vols=normalizeVolumes(firstValue(tel.volumes,tel.disks,inv.volumes,inv.disks,[])),sessions=normalizeSessions(firstValue(tel.sessions,inv.sessions,[]));
    const memTotal=firstValue(mem.total_bytes,mem.total),memUsage=firstValue(mem.usage_percent,mem.percent);
    document.getElementById('auditTelemetry').innerHTML=[
        detail('CPU',firstValue(cpu.model,cpu.name,inv.cpu_model)),
        detail('CPU utilisation',formatPercent(firstValue(cpu.usage_percent,cpu.usage,cpu.percent))),
        detail('RAM',formatBytes(memTotal)),
        detail('RAM utilisation',formatPercent(memUsage)),
        detail('Disques',vols.length?vols.map(v=>v.name+' '+formatPercent(v.usage)).join(' · '):'—'),
        detail('Session(s)',sessions.length?sessions.map(x=>x.username+' ('+x.state+')').join(', '):'—'),
        detail('Ports ouverts',ports.length),
        detail('Uptime',formatDuration(firstValue(tel.uptime_seconds,inv.uptime_seconds)))
    ].join('');
    const groups=a.pc_groups||[];document.getElementById('auditGroups').innerHTML=groups.length?groups.map(g=>`<span>${htmlEsc(g.name||g.group_id)}</span>`).join(''):'<span>Aucun groupe</span>';
    const rights=a.access_policies||[];document.getElementById('auditRightsCount').textContent=rights.length+' règle(s)';document.getElementById('auditRights').innerHTML=rights.length?rights.map(r=>`<div><strong>${htmlEsc(r.subject_id||'Sujet')}</strong><span>${htmlEsc((r.permissions||[]).join(', '))}</span></div>`).join(''):'<div class="dmd-agent-admin-empty">Aucune règle spécifique.</div>';
    const ev=a.events||[];document.getElementById('auditEventsCount').textContent=ev.length+' événement(s)';document.getElementById('auditEvents').innerHTML=ev.length?ev.slice().reverse().map(e=>`<div><time>${htmlEsc(formatDate(e.date_iso||''))}</time><strong>${htmlEsc(e.event||'événement')}</strong><span>${htmlEsc(e.status||'')}</span></div>`).join(''):'<div class="dmd-agent-admin-empty">Aucun événement lié conservé.</div>';
    auditModal.hidden=false;document.body.classList.add('dmd-agent-modal-open');
}
function closeAudit(){auditModal.hidden=true;document.body.classList.remove('dmd-agent-modal-open');}
document.querySelectorAll('[data-audit-open]').forEach(b=>b.addEventListener('click',()=>openAudit(b.dataset.auditOpen)));document.querySelectorAll('[data-close-audit]').forEach(b=>b.addEventListener('click',closeAudit));


/* =====================================================================
   Sauvegardes / Scan réseau — R6 multi-PC + découverte automatique SMB
   ===================================================================== */
let dmdBackupWorkspaceSources=[];
let dmdBackupTargets=[];
let dmdBackupSelectedTargetId='';
let dmdBackupBrowserMode='source';
let dmdBackupBrowserPath='';
let dmdBackupSelectedAgents=new Set();
let dmdBackupReferenceAgentId='';
let dmdBackupBatchJobs={};
let dmdBackupPollToken=0;
let dmdScanWorkspaceNetworks=[];
let dmdScanWorkspaceCidr='';
let dmdScanPollToken=0;
let dmdScanLastResult=null;
let dmdScanCurrentJobId='';
let dmdScanPdfUrl='';
let dmdScanPdfFilename='DMD-Scan-reseau.pdf';

function dmdWorkspaceDeviceById(agentId){return DEVICE_DATA.find(x=>String(x.agent_id||'')===String(agentId||''))||null;}
function dmdWorkspaceOnline(d){
    if(!d||String(d.status||'')==='revoked')return false;
    const last=Number(d.last_seen_ts||0);
    if(last>0)return ((Date.now()/1000)-last)<180;
    return String(d.status||'')==='active';
}
function dmdWorkspaceSelectAgent(agentId){
    const d=dmdWorkspaceDeviceById(agentId);
    if(!d){selectedDevice=null;stopAgentInteractive();return null;}
    selectedDevice=d;startAgentInteractive(d.agent_id);return d;
}
function dmdWorkspacePcLabel(d){return d?((d.hostname||'PC')+(d.last_ip?' · '+d.last_ip:'')):'—';}
function dmdBackupSelectedAgentIds(){return [...document.querySelectorAll('.dmd-backup-pc-target:checked')].map(x=>String(x.value||'')).filter(Boolean);}
function dmdBackupReferenceDevice(){return dmdWorkspaceDeviceById(dmdBackupReferenceAgentId)||null;}
function dmdBackupPresetValues(){return [...document.querySelectorAll('[data-backup-preset]:checked')].map(x=>String(x.dataset.backupPreset||'')).filter(Boolean);}
function dmdBackupRandomTargetId(){
    const b=new Uint8Array(12);crypto.getRandomValues(b);
    return 'BKT-'+[...b].map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase();
}
async function dmdBatchRun(ids,worker,concurrency=6){
    ids=[...new Set((ids||[]).filter(Boolean))];
    const out=[];let cursor=0;
    async function runner(){
        while(true){
            const i=cursor++;if(i>=ids.length)return;
            const id=ids[i];
            try{out[i]={agent_id:id,ok:true,result:await worker(id,i)};}
            catch(e){out[i]={agent_id:id,ok:false,error:String(e&&e.message||e||'Erreur')};}
        }
    }
    await Promise.all(Array.from({length:Math.max(1,Math.min(concurrency,ids.length||1))},runner));
    return out;
}
function dmdBackupSetSelectedDevice(){
    const ids=dmdBackupSelectedAgentIds();
    dmdBackupSelectedAgents=new Set(ids);
    const previous=dmdBackupReferenceAgentId;
    dmdBackupReferenceAgentId=ids[0]||'';
    const d=dmdBackupReferenceAgentId?dmdWorkspaceSelectAgent(dmdBackupReferenceAgentId):null;
    if(!d)selectedDevice=null;
    return {ids,device:d,referenceChanged:previous!==dmdBackupReferenceAgentId};
}
function dmdBackupTargetById(id){return dmdBackupTargets.find(x=>String(x.id||'')===String(id||''))||null;}
function dmdBackupTargetTypeLabel(type){return type==='smb'?'NAS / serveur SMB':type==='webdav'?'Cloud WebDAV':type==='local'?'Disque local / USB':type||'Cible';}
function dmdBackupTargetDescription(t){
    if(!t)return 'Aucune cible sélectionnée.';
    if(t.type==='smb')return '\\\\'+(t.server||'serveur')+'\\'+(t.share||'partage')+(t.folder?'\\'+t.folder:'');
    if(t.type==='webdav')return (t.webdav_url||'WebDAV')+(t.folder?' / '+t.folder:'');
    if(t.type==='local')return t.local_path||'Dossier local';
    return t.name||'Cible';
}
function dmdBackupUpdatePcUi(){
    const ids=dmdBackupSelectedAgentIds(),count=document.getElementById('backupAgentCount'),state=document.getElementById('backupWorkspacePcState');
    if(count)count.textContent=ids.length+' PC';
    const onlineBoxes=[...document.querySelectorAll('.dmd-backup-pc-target:not(:disabled)')],all=document.getElementById('backupAllAgents');
    if(all){all.checked=onlineBoxes.length>0&&onlineBoxes.every(x=>x.checked);all.indeterminate=ids.length>0&&!all.checked;}
    const ref=dmdBackupReferenceDevice();
    if(state)state.textContent=ids.length?(ids.length+' PC sélectionné'+(ids.length>1?'s':'')+' · PC de référence : '+(ref?.hostname||'—')):'Sélectionne un ou plusieurs PC.';
    const advanced=document.getElementById('backupChooseSources');if(advanced)advanced.disabled=ids.length===0;
    const manage=document.getElementById('backupManageTargets');if(manage)manage.disabled=ids.length===0;
    const newTarget=document.getElementById('backupNewTarget');if(newTarget)newTarget.disabled=ids.length===0;
    const refresh=document.getElementById('backupWorkspaceRefresh');if(refresh)refresh.disabled=ids.length===0;
    const deploy=document.getElementById('backupTargetDeployCount');if(deploy)deploy.textContent=ids.length+' PC sélectionné'+(ids.length>1?'s':'');
    const providerDetect=document.getElementById('backupProviderDetect');if(providerDetect)providerDetect.disabled=ids.length===0;
    const imageDetect=document.getElementById('backupImageDetect');if(imageDetect)imageDetect.disabled=ids.length===0;
    dmdBackupRenderSelections();
}
async function dmdBackupSelectionChanged(){
    dmdBackupPollToken++;
    const {ids,referenceChanged}=dmdBackupSetSelectedDevice();
    dmdBackupUpdatePcUi();
    dmdBackupProviderReset();
    dmdBackupImageReset();
    if(!ids.length){
        dmdBackupTargets=[];dmdBackupSelectedTargetId='';dmdBackupRenderTargetList();
        const st=document.getElementById('backupWorkspaceStatus');if(st)st.innerHTML='<div class="dmd-agent-admin-empty">Aucun PC sélectionné.</div>';
        return;
    }
    if(referenceChanged){dmdBackupWorkspaceSources=[];await dmdBackupLoadTargets();}
    await dmdBackupWorkspaceRefresh('',false);
}
function dmdBackupRenderSelections(){
    const host=document.getElementById('backupSelectedSources');
    if(host)host.innerHTML=dmdBackupWorkspaceSources.length?dmdBackupWorkspaceSources.map((x,i)=>`<span class="dmd-agent-maint-chip"><b>${htmlEsc(x)}</b><button type="button" data-backup-source-remove="${i}" aria-label="Retirer">×</button></span>`).join(''):'<span class="dmd-agent-muted">Aucun chemin avancé. Les sélections automatiques ci-dessus seront utilisées.</span>';
    const t=dmdBackupTargetById(dmdBackupSelectedTargetId),dst=document.getElementById('backupSelectedDestination');
    if(dst)dst.innerHTML=t?`<div><strong>${htmlEsc(t.name||'Cible')}</strong><small>${htmlEsc(dmdBackupTargetTypeLabel(t.type))} · ${htmlEsc(dmdBackupTargetDescription(t))}</small></div>`:'<span>Aucune cible sélectionnée.</span>';
    const ids=dmdBackupSelectedAgentIds(),hasSources=dmdBackupPresetValues().length>0||dmdBackupWorkspaceSources.length>0;
    const run=document.getElementById('backupWorkspaceRun');if(run)run.disabled=!(ids.length&&hasSources&&t);
    const test=document.getElementById('backupTestTarget');if(test)test.disabled=!(ids.length&&t);
    dmdBackupImageUpdateTargetHint();
}
function dmdBackupRenderTargetList(){
    const sel=document.getElementById('backupTargetSelect'),list=document.getElementById('backupTargetList');
    if(sel){
        sel.disabled=!dmdBackupSelectedAgentIds().length;
        sel.innerHTML='<option value="">Choisir une cible…</option>'+dmdBackupTargets.map(t=>`<option value="${htmlEsc(t.id||'')}">${htmlEsc(t.name||'Cible')} · ${htmlEsc(dmdBackupTargetTypeLabel(t.type))}</option>`).join('');
        if(dmdBackupSelectedTargetId&&dmdBackupTargetById(dmdBackupSelectedTargetId))sel.value=dmdBackupSelectedTargetId;
        else if(dmdBackupTargets.length){dmdBackupSelectedTargetId=String(dmdBackupTargets[0].id||'');sel.value=dmdBackupSelectedTargetId;}
        else dmdBackupSelectedTargetId='';
    }
    if(list)list.innerHTML=dmdBackupTargets.length?dmdBackupTargets.map(t=>`<div class="dmd-agent-backup-target-row"><div><strong>${htmlEsc(t.name||'Cible')}</strong><small>${htmlEsc(dmdBackupTargetDescription(t))}${t.has_credentials?' · identifiants protégés':''}</small></div><div><button type="button" class="dmd-agent-mini-btn" data-backup-target-test="${htmlEsc(t.id||'')}">Tester</button><button type="button" class="dmd-agent-mini-btn" data-backup-target-edit="${htmlEsc(t.id||'')}">Modifier / déployer</button></div></div>`).join(''):'<div class="dmd-agent-admin-empty">Aucune cible sur le PC de référence. Crée une cible et déploie-la en une fois sur les PC sélectionnés.</div>';
    dmdBackupRenderSelections();
}
async function dmdBackupLoadTargets(){
    const ref=dmdBackupReferenceAgentId;if(!ref){dmdBackupTargets=[];dmdBackupRenderTargetList();return;}
    const list=document.getElementById('backupTargetList');if(list)list.innerHTML='<div class="dmd-agent-admin-empty">Lecture des cibles du PC de référence…</div>';
    try{
        const r=await runAdminCommandForAgent(ref,'backup.targets.list',{}, {showState:false});
        dmdBackupTargets=Array.isArray(r&&r.targets)?r.targets:[];
        dmdBackupRenderTargetList();
    }catch(e){
        dmdBackupTargets=[];dmdBackupSelectedTargetId='';
        if(list)list.innerHTML='<div class="dmd-agent-admin-empty">'+htmlEsc(e.message||'Impossible de lire les cibles.')+'</div>';
        dmdBackupRenderSelections();
    }
}
function dmdBackupSetBrowserHint(text){const h=document.getElementById('backupBrowserHint');if(h)h.textContent=text;}
async function dmdBackupLoadRoots(){
    const host=document.getElementById('backupBrowser'),ref=dmdBackupReferenceAgentId;if(!host||!ref)return;
    host.innerHTML='<div class="dmd-agent-admin-empty">Lecture des disques du PC…</div>';
    try{
        const r=await runAdminCommandForAgent(ref,'filesystem.roots',{}, {showState:false}),roots=Array.isArray(r&&r.roots)?r.roots:[];
        const network=roots.filter(x=>Number(x.drive_type||0)===4),local=roots.filter(x=>Number(x.drive_type||0)!==4);
        const section=(title,rows)=>rows.length?`<div class="dmd-agent-backup-root-section"><strong>${htmlEsc(title)}</strong><div class="dmd-agent-backup-root-grid">${rows.map(x=>`<button type="button" class="dmd-agent-backup-root" data-backup-browse="${htmlEsc(x.path||'')}"><span>${htmlEsc(x.label||x.path||'Disque')}</span><small>${htmlEsc(x.drive_type_name||'')} ${x.free_bytes?('· '+fmtAdminBytes(x.free_bytes)+' libres'):''}</small></button>`).join('')}</div></div>`:'';
        host.innerHTML=(section('Disques et volumes',local)+section('Lecteurs réseau déjà montés',network))||'<div class="dmd-agent-admin-empty">Aucun volume accessible par cet Agent.</div>';dmdBackupBrowserPath='';
    }catch(e){host.innerHTML='<div class="dmd-agent-admin-empty">'+htmlEsc(e.message||'Impossible de lire les disques.')+'</div>';}
}
async function dmdBackupBrowse(path){
    const host=document.getElementById('backupBrowser'),ref=dmdBackupReferenceAgentId;if(!host||!ref||!path)return;
    dmdBackupBrowserPath=path;host.innerHTML='<div class="dmd-agent-admin-empty">Lecture du dossier…</div>';
    try{
        const r=await runAdminCommandForAgent(ref,'filesystem.list',{path,offset:0,limit:120},{showState:false}),entries=Array.isArray(r&&r.entries)?r.entries:[];
        const current=String(r&&r.path||path),parent=String(r&&r.parent||'');
        const chooseCurrent=dmdBackupBrowserMode==='target-local'?`<button type="button" class="dmd-agent-mini-btn primary" data-backup-target-local="${htmlEsc(current)}">Utiliser ce dossier</button>`:`<button type="button" class="dmd-agent-mini-btn primary" data-backup-add-source="${htmlEsc(current)}">Ajouter ce dossier</button>`;
        host.innerHTML=`<div class="dmd-agent-backup-browser-toolbar"><button type="button" class="dmd-agent-mini-btn" data-backup-roots>Disques</button>${parent?`<button type="button" class="dmd-agent-mini-btn" data-backup-browse="${htmlEsc(parent)}">← Parent</button>`:''}<code>${htmlEsc(current)}</code>${chooseCurrent}</div><div class="dmd-agent-backup-browser-list">${entries.length?entries.map(e=>{const ep=String(e.path||'');if(e.is_dir)return `<div class="dmd-agent-backup-browser-row"><button type="button" class="folder" data-backup-browse="${htmlEsc(ep)}"><strong>📁 ${htmlEsc(e.name||'Dossier')}</strong><small>${htmlEsc(e.modified_at?formatDate(e.modified_at):'')}</small></button>${dmdBackupBrowserMode==='source'?`<button type="button" class="dmd-agent-mini-btn" data-backup-add-source="${htmlEsc(ep)}">Ajouter</button>`:''}</div>`;return dmdBackupBrowserMode==='source'?`<div class="dmd-agent-backup-browser-row"><div class="file"><strong>${htmlEsc(e.name||'Fichier')}</strong><small>${htmlEsc(fmtAdminBytes(e.size||0))}</small></div><button type="button" class="dmd-agent-mini-btn" data-backup-add-source="${htmlEsc(ep)}">Ajouter</button></div>`:'';}).join(''):'<div class="dmd-agent-admin-empty">Dossier vide.</div>'}</div>`;
    }catch(e){host.innerHTML='<div class="dmd-agent-admin-empty">'+htmlEsc(e.message||'Impossible de lire ce dossier.')+'</div>';}
}
async function dmdBackupOpenBrowser(mode){
    const ids=dmdBackupSelectedAgentIds();if(!ids.length){showMsg('Sélectionne au moins un PC.',false);return;}
    dmdBackupBrowserMode=mode==='target-local'?'target-local':'source';
    const ref=dmdBackupReferenceDevice(),suffix=ids.length>1?' Le chemin sera appliqué aux '+ids.length+' PC sélectionnés ; un Agent qui ne possède pas ce chemin le signalera dans son résultat.':'';
    dmdBackupSetBrowserHint((dmdBackupBrowserMode==='target-local'?'Choisis le dossier local ou USB sur le PC de référence '+(ref?.hostname||'')+'.':'Ajoute des dossiers ou fichiers depuis le PC de référence '+(ref?.hostname||'')+'.')+suffix);
    const modal=document.getElementById('backupBrowserModal');if(modal)modal.hidden=false;await dmdBackupLoadRoots();
}
function dmdBackupCloseBrowserModal(){const m=document.getElementById('backupBrowserModal');if(m)m.hidden=true;}
function dmdBackupTargetFormTypeSync(){
    const type=document.getElementById('backupTargetType')?.value||'smb';
    const map={Smb:'smb',Local:'local',Webdav:'webdav'};
    Object.entries(map).forEach(([k,v])=>{const el=document.getElementById('backupTargetFields'+k);if(el)el.hidden=type!==v;});
}
function dmdBackupOpenTargetForm(target=null){
    if(!dmdBackupSelectedAgentIds().length)return;
    const form=document.getElementById('backupTargetForm'),modal=document.getElementById('backupTargetModal');if(!form)return;if(modal)modal.hidden=false;
    form.hidden=false;
    const st=document.getElementById('backupTargetFormState');if(st){st.hidden=true;st.textContent='';}
    document.getElementById('backupTargetId').value=target?.id||'';
    document.getElementById('backupTargetName').value=target?.name||'Sauvegarde principale';
    document.getElementById('backupTargetType').value=target?.type||'smb';
    document.getElementById('backupTargetServer').value=target?.server||'';
    document.getElementById('backupTargetShare').value=target?.share||'';
    document.getElementById('backupTargetFolder').value=target?.type==='smb'?(target?.folder||''):'';
    document.getElementById('backupTargetUsername').value=target?.type==='smb'?(target?.username||''):'';
    document.getElementById('backupTargetPassword').value='';
    document.getElementById('backupTargetLocalPath').value=target?.local_path||'';
    document.getElementById('backupTargetWebdavUrl').value=target?.webdav_url||'';
    document.getElementById('backupTargetWebdavFolder').value=target?.type==='webdav'?(target?.folder||''):'';
    document.getElementById('backupTargetWebdavUsername').value=target?.type==='webdav'?(target?.username||''):'';
    document.getElementById('backupTargetWebdavPassword').value='';
    const del=document.getElementById('backupTargetDelete');if(del)del.hidden=!target;
    const disc=document.getElementById('backupSmbDiscovery');if(disc)disc.innerHTML='<div class="dmd-agent-admin-empty">'+(target?.type==='smb'?'Clique sur « Découvrir les partages » pour explorer le NAS/serveur.':'Renseigne le serveur et découvre les partages automatiquement.')+'</div>';
    const ds=document.getElementById('backupSmbDiscoveryState');if(ds)ds.textContent='Le scan SMB est exécuté depuis le premier PC sélectionné.';
    dmdBackupTargetFormTypeSync();dmdBackupUpdatePcUi();
}
function dmdBackupCloseTargetForm(){const f=document.getElementById('backupTargetForm');if(f)f.hidden=true;}
function dmdBackupOpenTargetModal(){if(!dmdBackupSelectedAgentIds().length)return;const m=document.getElementById('backupTargetModal');if(m)m.hidden=false;if(!dmdBackupTargets.length)dmdBackupOpenTargetForm(null);}
function dmdBackupCloseTargetModal(){dmdBackupCloseTargetForm();const m=document.getElementById('backupTargetModal');if(m)m.hidden=true;}
function dmdBackupTargetPayload(){
    const type=document.getElementById('backupTargetType')?.value||'smb';
    let id=String(document.getElementById('backupTargetId')?.value||'').trim();
    if(!id){id=dmdBackupRandomTargetId();document.getElementById('backupTargetId').value=id;}
    const p={target_id:id,target_type:type,name:String(document.getElementById('backupTargetName')?.value||'').trim()||'Sauvegarde'};
    if(type==='smb'){p.server=String(document.getElementById('backupTargetServer')?.value||'').trim();p.share=String(document.getElementById('backupTargetShare')?.value||'').trim();p.folder=String(document.getElementById('backupTargetFolder')?.value||'').trim();p.username=String(document.getElementById('backupTargetUsername')?.value||'').trim();p.password=String(document.getElementById('backupTargetPassword')?.value||'');}
    else if(type==='local'){p.local_path=String(document.getElementById('backupTargetLocalPath')?.value||'').trim();}
    else{p.webdav_url=String(document.getElementById('backupTargetWebdavUrl')?.value||'').trim();p.folder=String(document.getElementById('backupTargetWebdavFolder')?.value||'').trim();p.username=String(document.getElementById('backupTargetWebdavUsername')?.value||'').trim();p.password=String(document.getElementById('backupTargetWebdavPassword')?.value||'');}
    return p;
}
function dmdBackupRenderSmbDiscovery(result,folder=''){
    const host=document.getElementById('backupSmbDiscovery');if(!host)return;
    if(result&&Array.isArray(result.shares)){
        const rows=result.shares.filter(x=>Number(x.type||0)===0&&!x.special);
        host.innerHTML=rows.length?`<div class="dmd-backup-smb-title">Partages disponibles sur ${htmlEsc(result.server||'serveur')}</div><div class="dmd-backup-smb-grid">${rows.map(x=>`<button type="button" class="dmd-backup-smb-item" data-backup-smb-share="${htmlEsc(x.name||'')}"><strong>${htmlEsc(x.name||'Partage')}</strong><small>${htmlEsc(x.remark||x.unc||'')}</small></button>`).join('')}</div>`:'<div class="dmd-agent-admin-empty">Aucun partage disque visible avec ces identifiants.</div>';
        return;
    }
    if(result&&Array.isArray(result.folders)){
        const current=String(result.folder||folder||''),parent=current.includes('\\')?current.split('\\').slice(0,-1).join('\\'):'';
        host.innerHTML=`<div class="dmd-backup-smb-toolbar"><button type="button" class="dmd-agent-mini-btn" data-backup-smb-shares>Partages</button>${current?`<button type="button" class="dmd-agent-mini-btn" data-backup-smb-folder="${htmlEsc(parent)}">← Parent</button>`:''}<code>${htmlEsc('\\\\'+(result.server||'')+'\\'+(result.share||'')+(current?'\\'+current:''))}</code><button type="button" class="dmd-agent-mini-btn primary" data-backup-smb-use="${htmlEsc(current)}">Utiliser ce dossier</button></div><div class="dmd-backup-smb-grid">${result.folders.length?result.folders.map(x=>`<button type="button" class="dmd-backup-smb-item" data-backup-smb-folder="${htmlEsc(x.folder||'')}"><strong>📁 ${htmlEsc(x.name||'Dossier')}</strong><small>${htmlEsc(x.folder||'')}</small></button>`).join(''):'<div class="dmd-agent-admin-empty">Aucun sous-dossier. Tu peux utiliser ce dossier.</div>'}</div>`;
    }
}
function dmdBackupSmbDiscoveryPayload(includeCurrentShare=false){
    const targetId=String(document.getElementById('backupTargetId')?.value||'').trim();
    const existing=targetId&&dmdBackupTargetById(targetId);
    const password=String(document.getElementById('backupTargetPassword')?.value||'');
    if(existing&&existing.type==='smb'&&password===''){
        return {target_id:targetId,share:includeCurrentShare?String(document.getElementById('backupTargetShare')?.value||''):''};
    }
    return {
        server:String(document.getElementById('backupTargetServer')?.value||'').trim(),
        share:includeCurrentShare?String(document.getElementById('backupTargetShare')?.value||'').trim():'',
        folder:includeCurrentShare?String(document.getElementById('backupTargetFolder')?.value||'').trim():'',
        username:String(document.getElementById('backupTargetUsername')?.value||'').trim(),
        password
    };
}
async function dmdBackupDiscoverShares(){
    const ref=dmdBackupReferenceAgentId;if(!ref)throw new Error('Sélectionne au moins un PC.');
    const p=dmdBackupSmbDiscoveryPayload(false);
    if(!p.target_id&&!p.server)throw new Error('Renseigne le serveur/NAS.');
    const state=document.getElementById('backupSmbDiscoveryState'),host=document.getElementById('backupSmbDiscovery');
    if(state)state.textContent='Recherche des partages…';if(host)host.innerHTML='<div class="dmd-agent-admin-empty">Interrogation SMB depuis le PC de référence…</div>';
    const r=await runAdminCommandForAgent(ref,'backup.smb.discover',p,{showState:false});
    if(state)state.textContent=(r.count||0)+' partage(s) détecté(s)';
    dmdBackupRenderSmbDiscovery(r);return r;
}
async function dmdBackupBrowseSmbFolder(folder=''){
    const ref=dmdBackupReferenceAgentId;if(!ref)return;
    const p=dmdBackupSmbDiscoveryPayload(true);
    p.folder=String(folder||'');
    if(!p.share)throw new Error('Choisis d’abord un partage.');
    const state=document.getElementById('backupSmbDiscoveryState');if(state)state.textContent='Lecture des dossiers…';
    const r=await runAdminCommandForAgent(ref,'backup.smb.discover',p,{showState:false});
    if(state)state.textContent=(r.count||0)+' dossier(s)';
    dmdBackupRenderSmbDiscovery(r,folder);return r;
}
async function dmdBackupSaveTarget(testAfter=false){
    const ids=dmdBackupSelectedAgentIds();if(!ids.length)throw new Error('Sélectionne au moins un PC.');
    const p=dmdBackupTargetPayload(),st=document.getElementById('backupTargetFormState');
    if(p.target_type==='smb'&&(!p.server||!p.share))throw new Error('Découvre puis choisis un partage SMB.');
    if(p.target_type==='local'&&!p.local_path)throw new Error('Choisis le dossier local/USB sur le PC de référence. Le même chemin sera déployé sur les PC sélectionnés.');
    if(p.target_type==='webdav'&&!p.webdav_url)throw new Error('Renseigne l’URL WebDAV.');
    if(st){st.hidden=false;st.textContent='Déploiement sur '+ids.length+' PC…';}
    const buttons=['backupTargetSave','backupTargetFormTest','backupTargetDelete'].map(id=>document.getElementById(id));buttons.forEach(b=>{if(b)b.disabled=true;});
    try{
        const rows=await dmdBatchRun(ids,id=>runAdminCommandForAgent(id,'backup.target.configure',p,{showState:false}),6);
        const ok=rows.filter(x=>x.ok).length,fail=rows.length-ok;
        if(st)st.textContent='Cible déployée : '+ok+'/'+rows.length+(fail?' · '+fail+' échec(s)':'');
        if(!ok)throw new Error(rows.map(x=>x.error).filter(Boolean)[0]||'Aucun Agent n’a enregistré la cible.');
        dmdBackupSelectedTargetId=p.target_id;await dmdBackupLoadTargets();
        showMsg('Cible enregistrée sur '+ok+' PC'+(ok>1?'s':'')+(fail?' · '+fail+' échec(s).':'.'),fail===0);
        if(testAfter)await dmdBackupTestTarget(p.target_id);
        if(!fail)dmdBackupCloseTargetForm();
        return rows;
    }finally{buttons.forEach(b=>{if(b)b.disabled=false;});}
}
async function dmdBackupTestTarget(id=dmdBackupSelectedTargetId){
    const ids=dmdBackupSelectedAgentIds();if(!ids.length||!id)return;
    const target=dmdBackupTargetById(id);
    if(target&&target.type==='smb')dmdBackupOpenTargetForm(target);
    const state=document.getElementById('backupTargetTestState'),discState=document.getElementById('backupSmbDiscoveryState');
    if(state)state.textContent='Test sur '+ids.length+' PC…';
    if(discState&&target&&target.type==='smb')discState.textContent='Test d’accès et lecture du partage…';
    const rows=await dmdBatchRun(ids,agentId=>runAdminCommandForAgent(agentId,'backup.target.test',{target_id:id},{showState:false}),6);
    const okRows=rows.filter(x=>x.ok),fail=rows.length-okRows.length;
    if(state)state.textContent=okRows.length+'/'+rows.length+' accessibles'+(fail?' · '+fail+' échec(s)':'');
    if(okRows.length){
        const first=okRows[0].result||{},pub=first.target||target||{};
        if(pub.type==='smb'){
            if(Array.isArray(first.folders)){
                dmdBackupRenderSmbDiscovery({server:pub.server||'',share:pub.share||'',folder:pub.folder||'',folders:first.folders},pub.folder||'');
                if(discState)discState.textContent=(first.folders.length||0)+' dossier(s) visibles dans '+(pub.share||'le partage');
            }else if(Array.isArray(first.shares)){
                dmdBackupRenderSmbDiscovery({server:pub.server||'',shares:first.shares});
                if(discState)discState.textContent=(first.shares.length||0)+' partage(s) détecté(s)';
            }
        }
        showMsg('Cible accessible depuis '+okRows.length+' PC'+(okRows.length>1?'s':'')+(fail?' ; '+fail+' échec(s).':'.'),fail===0);
    }else{
        if(discState&&target&&target.type==='smb')discState.textContent='Cible inaccessible';
        showMsg(rows.map(x=>x.error).filter(Boolean)[0]||'Cible inaccessible.',false);
    }
    return rows;
}
function dmdBackupProgressValue(job){
    const s=job&&job.summary&&typeof job.summary==='object'?job.summary:{},r=job&&job.result&&typeof job.result==='object'?job.result:{};
    let p=Number(s.progress_percent??r.progress_percent??(String(job&&job.status||'')==='completed'?100:0));
    if(!Number.isFinite(p))p=0;return Math.max(0,Math.min(100,p));
}
function dmdBackupPhaseLabel(v){const m={indexing:'Analyse des fichiers',copy:'Copie',upload:'Envoi cloud',finalizing:'Finalisation',stopping:'Arrêt demandé',cancelled:'Arrêté'};return m[String(v||'').toLowerCase()]||'';}
function dmdBackupStatusRow(agentId,job){
    const d=dmdWorkspaceDeviceById(agentId),name=d?.hostname||agentId;
    if(!job||job.status==='none')return `<div class="dmd-backup-status-row"><strong>${htmlEsc(name)}</strong><span>—</span><div class="dmd-backup-status-detail"><small>Aucune sauvegarde enregistrée.</small></div><span></span></div>`;
    const s=job.summary&&typeof job.summary==='object'?job.summary:{},r=job.result&&typeof job.result==='object'?job.result:{};
    const target=r.target_name||s.target_name||'—',when=job.completed_at||job.updated_at||job.started_at||'',p=dmdBackupProgressValue(job),phase=dmdBackupPhaseLabel(s.phase),filesDone=Number(s.files_completed||0),filesTotal=Number(s.files_total||r.files_total||0),status=String(job.status||'').toLowerCase();
    const pct=(Math.round(p*10)/10).toLocaleString('fr-FR',{maximumFractionDigits:1})+' %',statusText=dmdMaintenanceStatusLabel(status)+((status==='running'||status==='stopping')?' · '+pct:'');
    const fileText=filesTotal>0?(' · '+filesDone+'/'+filesTotal+' fichiers'):'';
    const stop=(status==='running'||status==='stopping')?`<button type="button" class="dmd-agent-mini-btn danger dmd-backup-stop-one" data-backup-stop-agent="${htmlEsc(agentId)}" data-backup-stop-job="${htmlEsc(job.job_id||'')}" ${status==='stopping'?'disabled':''}>${status==='stopping'?'Arrêt…':'Arrêter'}</button>`:'<span></span>';
    return `<div class="dmd-backup-status-row ${htmlEsc(status)}"><strong>${htmlEsc(name)}</strong><span>${htmlEsc(statusText)}</span><div class="dmd-backup-status-detail"><div class="dmd-backup-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(p)}"><i style="width:${p}%"></i></div><small>${htmlEsc(target)}${phase?' · '+htmlEsc(phase):''}${fileText?htmlEsc(fileText):''} · ${htmlEsc(dmdMaintenanceDate(when))}${job.error?' · '+htmlEsc(job.error):''}</small></div>${stop}</div>`;
}

async function dmdBackupWorkspaceRefresh(jobId='',auto=false){
    const ids=dmdBackupSelectedAgentIds(),host=document.getElementById('backupWorkspaceStatus'),state=document.getElementById('backupWorkspaceStatusState');if(!host)return null;
    if(!ids.length){host.innerHTML='<div class="dmd-agent-admin-empty">Aucun PC sélectionné.</div>';if(state)state.textContent='—';const stopAll=document.getElementById('backupWorkspaceStop');if(stopAll)stopAll.disabled=true;return null;}
    if(state)state.textContent='Lecture…';
    const rows=await dmdBatchRun(ids,async agentId=>{
        const jid=dmdBackupBatchJobs[agentId]||'';
        return runAdminCommandForAgent(agentId,'backup.files.status',jid?{job_id:jid}:{},{showState:false,waitLimitMs:15000});
    },6);
    const okJobs=rows.filter(x=>x.ok&&x.result&&x.result.status!=='none').map(x=>x.result),running=okJobs.filter(x=>['running','stopping'].includes(String(x.status||'').toLowerCase())).length,failed=rows.filter(x=>!x.ok||x.result?.status==='failed').length;
    let aggregate='';
    if(okJobs.length){
        const avg=okJobs.reduce((a,j)=>a+dmdBackupProgressValue(j),0)/okJobs.length;
        aggregate=`<div class="dmd-backup-aggregate"><div><strong>Progression globale</strong><span>${Math.round(avg)} % · ${running} en cours / ${ids.length} PC</span></div><div class="dmd-backup-progress large"><i style="width:${avg}%"></i></div></div>`;
    }
    host.innerHTML=aggregate+rows.map(x=>x.ok?dmdBackupStatusRow(x.agent_id,x.result):`<div class="dmd-backup-status-row failed"><strong>${htmlEsc(dmdWorkspaceDeviceById(x.agent_id)?.hostname||x.agent_id)}</strong><span>Erreur</span><div class="dmd-backup-status-detail"><small>${htmlEsc(x.error||'État indisponible')}</small></div><span></span></div>`).join('');
    if(state)state.textContent=running?running+' en cours':failed?failed+' échec(s)':'À jour';const stopAll=document.getElementById('backupWorkspaceStop');if(stopAll)stopAll.disabled=!running;
    if(auto&&running){
        const token=++dmdBackupPollToken,delay=Math.max(1800,ids.length*90);
        setTimeout(()=>{if(token===dmdBackupPollToken)dmdBackupWorkspaceRefresh('',true);},delay);
    }
    return rows;
}

/* Scan réseau */
function dmdIPv4Private(ip){const p=String(ip||'').split('.').map(Number);if(p.length!==4||p.some(x=>!Number.isInteger(x)||x<0||x>255))return false;return p[0]===10||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168);}
function dmdIPv4Cidr(ip,prefix){
    const a=String(ip||'').split('.').map(Number);if(a.length!==4)return '';
    let pr=Number(prefix);if(!Number.isInteger(pr)||pr<1||pr>32)pr=24;if(pr<22)pr=24;
    const n=((a[0]<<24)>>>0)+((a[1]<<16)>>>0)+((a[2]<<8)>>>0)+(a[3]>>>0),mask=((0xffffffff<<(32-pr))>>>0),net=(n&mask)>>>0;
    return [net>>>24,(net>>>16)&255,(net>>>8)&255,net&255].join('.')+'/'+pr;
}
function dmdScanRenderNetworks(){
    const host=document.getElementById('scanDetectedNetworks');if(!host)return;
    if(!dmdScanWorkspaceNetworks.length){host.innerHTML='<span class="dmd-agent-muted">Aucun réseau IPv4 détecté.</span>';dmdScanWorkspaceCidr='';}
    else{
        if(!dmdScanWorkspaceNetworks.some(x=>x.cidr===dmdScanWorkspaceCidr))dmdScanWorkspaceCidr=dmdScanWorkspaceNetworks[0].cidr;
        host.innerHTML=dmdScanWorkspaceNetworks.map(x=>`<label class="dmd-agent-maint-network-choice"><input type="radio" name="scanDetectedNetwork" value="${htmlEsc(x.cidr)}" ${x.cidr===dmdScanWorkspaceCidr?'checked':''}><span><strong>${htmlEsc(x.cidr)}</strong><small>${htmlEsc(x.interface||x.adapter||'Carte réseau')} · ${htmlEsc(x.ip||'')}</small></span></label>`).join('');
    }
    const run=document.getElementById('scanWorkspaceRun');if(run)run.disabled=!(selectedDevice&&String(selectedDevice.status||'')!=='revoked'&&dmdScanWorkspaceCidr);
}
function dmdScanFallbackNetworks(){
    if(!selectedDevice)return [];
    const raw=String(selectedDevice.last_ip||''),m=raw.match(/(?:^|[^0-9])(10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2})(?:$|[^0-9])/),ip=m&&m[1]?m[1]:'';
    if(!dmdIPv4Private(ip))return [];
    const cidr=dmdIPv4Cidr(ip,24);return cidr?[{cidr,ip,interface:'IPv4 connue du PC sonde'}]:[];
}
async function dmdScanDetectNetworks(){
    const host=document.getElementById('scanDetectedNetworks');if(!selectedDevice||!host)return;
    let rows=dmdScanFallbackNetworks(),warning='';
    dmdScanWorkspaceNetworks=rows;dmdScanRenderNetworks();
    if(host&&rows.length)host.insertAdjacentHTML('beforeend','<span class="dmd-agent-muted">Vérification des interfaces directement sur le PC…</span>');
    else if(host)host.innerHTML='<span class="dmd-agent-muted">Détection directe des interfaces IPv4 par le PC sonde…</span>';
    try{
        const r=await runAdminCommandForAgent(selectedDevice.agent_id,'network.localnets.list',{}, {showState:false,waitLimitMs:12000});
        const direct=Array.isArray(r&&r.networks)?r.networks.filter(x=>dmdIPv4Private(x.ip)):[];
        if(direct.length)rows=direct;
        else if(rows.length)warning='Interfaces non remontées ; utilisation de l’IPv4 connue.';
    }catch(e){if(rows.length)warning='Détection directe indisponible ; utilisation de l’IPv4 connue.';else warning=String(e&&e.message||'');}
    dmdScanWorkspaceNetworks=rows;dmdScanRenderNetworks();
    const state=document.getElementById('scanWorkspacePcState');
    if(state)state.textContent=dmdWorkspacePcLabel(selectedDevice)+(rows.length?' · '+rows.length+' réseau(x) prêt(s) au scan':' · aucun réseau détecté')+(warning?' · '+warning:'');
}
async function dmdScanWorkspaceRefresh(jobId='',auto=false){
    const host=document.getElementById('scanWorkspaceStatus'),state=document.getElementById('scanWorkspaceStatusState');if(!host||!selectedDevice)return null;
    if(state)state.textContent='Lecture…';
    try{
        const r=await runAdminCommandForAgent(selectedDevice.agent_id,'network.scan.status',jobId?{job_id:jobId}:{},{showState:false});
        dmdScanLastResult=r||null;if(r&&r.job_id)dmdScanCurrentJobId=String(r.job_id||'');host.innerHTML=dmdNetworkScanStatusHtml(r);if(state)state.textContent=dmdMaintenanceStatusLabel(r&&r.status);const stop=document.getElementById('scanWorkspaceStop');if(stop)stop.disabled=!(r&&['running','stopping'].includes(String(r.status||'').toLowerCase()));
        const exp=document.getElementById('scanWorkspaceExportPdf');if(exp)exp.disabled=!(r&&String(r.status||'').toLowerCase()==='completed'&&r.result&&Array.isArray(r.result.hosts));
        if(auto&&r&&['running','stopping'].includes(String(r.status||'').toLowerCase())){const token=++dmdScanPollToken;setTimeout(()=>{if(token===dmdScanPollToken)dmdScanWorkspaceRefresh(jobId,true);},1800);}
        return r;
    }catch(e){host.innerHTML='<div class="dmd-agent-admin-empty">'+htmlEsc(e.message||'État indisponible.')+'</div>';if(state)state.textContent='Erreur';const stop=document.getElementById('scanWorkspaceStop');if(stop)stop.disabled=true;return null;}
}
async function dmdScanWorkspaceAgentChanged(){
    dmdScanPollToken++;
    const id=document.getElementById('scanWorkspaceAgent')?.value||'',d=dmdWorkspaceSelectAgent(id),state=document.getElementById('scanWorkspacePcState'),detect=document.getElementById('scanWorkspaceDetect'),refresh=document.getElementById('scanWorkspaceRefresh');
    dmdScanWorkspaceNetworks=[];dmdScanWorkspaceCidr='';dmdScanLastResult=null;dmdScanCurrentJobId='';const stop=document.getElementById('scanWorkspaceStop');if(stop)stop.disabled=true;const exp=document.getElementById('scanWorkspaceExportPdf');if(exp)exp.disabled=true;
    const usable=!!(d&&String(d.status||'')!=='revoked');if(detect)detect.disabled=!usable;if(refresh)refresh.disabled=!usable;
    if(state)state.textContent=d?(dmdWorkspacePcLabel(d)+(dmdWorkspaceOnline(d)?' · sonde joignable':' · tentative directe via Agent')):'Sélectionne le PC qui servira de sonde.';
    dmdScanRenderNetworks();
    if(usable){await dmdScanDetectNetworks();dmdScanWorkspaceRefresh().catch(()=>{});}else{const st=document.getElementById('scanWorkspaceStatus');if(st)st.innerHTML='<div class="dmd-agent-admin-empty">Sélectionne un PC Agent.</div>';}
}

async function dmdScanExportPdf(){
    if(!selectedDevice||!dmdScanLastResult||String(dmdScanLastResult.status||'').toLowerCase()!=='completed'){showMsg('Aucun scan terminé à exporter.',false);return;}
    const btn=document.getElementById('scanWorkspaceExportPdf');if(btn)btn.disabled=true;
    try{
        const resp=await fetch('api/admin_scan_export_pdf.php',{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':CSRF},credentials:'same-origin',body:JSON.stringify({csrf_token:CSRF,agent_id:selectedDevice.agent_id,scan:dmdScanLastResult})});
        if(!resp.ok){let err='Export PDF impossible.';try{const j=await resp.json();err=j.error||err;}catch(_){}throw new Error(err);}
        const blob=await resp.blob();if(dmdScanPdfUrl)URL.revokeObjectURL(dmdScanPdfUrl);dmdScanPdfUrl=URL.createObjectURL(blob);
        const cd=resp.headers.get('Content-Disposition')||'',m=cd.match(/filename="?([^";]+)"?/i);dmdScanPdfFilename=m&&m[1]?m[1]:'DMD-Scan-'+(selectedDevice.hostname||'reseau')+'.pdf';
        const frame=document.getElementById('scanPdfFrame'),modal=document.getElementById('scanPdfModal');if(frame)frame.src=dmdScanPdfUrl;if(modal)modal.hidden=false;
    }catch(e){showMsg(e.message||'Export PDF impossible.',false);}finally{if(btn)btn.disabled=false;}
}
function dmdScanClosePdf(){const modal=document.getElementById('scanPdfModal'),frame=document.getElementById('scanPdfFrame');if(modal)modal.hidden=true;if(frame)frame.src='about:blank';if(dmdScanPdfUrl){URL.revokeObjectURL(dmdScanPdfUrl);dmdScanPdfUrl='';}}
function dmdScanDownloadPdf(){if(!dmdScanPdfUrl)return;const a=document.createElement('a');a.href=dmdScanPdfUrl;a.download=dmdScanPdfFilename||'DMD-Scan-reseau.pdf';document.body.appendChild(a);a.click();a.remove();}


/* ---------- Moteurs de sauvegarde externes + image système ---------- */
let DMD_BACKUP_PROVIDER_SCAN=[];
let DMD_BACKUP_PROVIDER_RUNS={};
let dmdBackupProviderConfigCurrent=null;
let dmdBackupProviderRecoveryRunId='';
let dmdBackupProviderRecoveryPollToken=0;

let DMD_BACKUP_IMAGE_SCAN=[];
let DMD_BACKUP_IMAGE_RUNS={};

function dmdBackupClampPercent(value){
    const n=Number(value);
    return Number.isFinite(n)?Math.max(0,Math.min(100,n)):-1;
}
function dmdBackupElapsed(seconds){
    let s=Math.max(0,Math.floor(Number(seconds)||0));
    const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);s%=60;
    if(h)return h+' h '+String(m).padStart(2,'0')+' min';
    if(m)return m+' min '+String(s).padStart(2,'0')+' s';
    return s+' s';
}
function dmdBackupProviderReset(){
    DMD_BACKUP_PROVIDER_SCAN=[];
    DMD_BACKUP_PROVIDER_RUNS={};
    const host=document.getElementById('backupProviderResults'),count=document.getElementById('backupProviderCount');
    if(count)count.textContent='Non analysé';
    if(host)host.innerHTML='<div class="dmd-agent-admin-empty">Sélectionne un ou plusieurs PC puis lance la détection.</div>';
}
function dmdBackupProviderActionLabel(action){
    if(action==='active_full')return 'Active Full';
    if(action==='standalone_full')return 'Full autonome';
    return 'Lancer';
}
function dmdBackupProviderTarget(job){
    const type=String(job?.target_type||'').trim(),target=String(job?.target||'').trim();
    if(target&&type)return type+' · '+target;
    return target||type||'Destination gérée par le moteur';
}
function dmdBackupProviderJobsHtml(agentId,provider){
    const jobs=Array.isArray(provider?.jobs)?provider.jobs:[];
    const actions=Array.isArray(provider?.actions)?provider.actions:[];
    if(!jobs.length){
        if(provider?.controllable===false || !actions.length){
            return '<div class="dmd-backup-provider-nojob">Moteur détecté. Lecture disponible ; pilotage direct non encore disponible pour ce connecteur.</div>';
        }
        return '<div class="dmd-backup-provider-nojob">Moteur détecté mais aucun job exportable n’a été trouvé.</div>';
    }
    return '<div class="dmd-backup-provider-jobs">'+jobs.map(job=>{
        const buttons=actions.map(action=>`<button type="button" class="dmd-agent-mini-btn${action==='backup'?' primary':''}" data-backup-provider-run="${htmlEsc(agentId)}" data-backup-provider="${htmlEsc(provider.id||'')}" data-backup-provider-action="${htmlEsc(action)}" data-backup-provider-job="${htmlEsc(job.id||'')}">${htmlEsc(dmdBackupProviderActionLabel(action))}</button>`).join('');
        const stats=[];
        if(job.average_duration)stats.push('Moy. '+job.average_duration);
        if(Number(job.last_point_size||0)>0)stats.push('Dernier '+fmtAdminBytes(job.last_point_size));
        if(Number(job.total_size||0)>0)stats.push('Total '+fmtAdminBytes(job.total_size));
        return `<article class="dmd-backup-provider-job" data-backup-provider-job-row data-backup-agent="${htmlEsc(agentId)}" data-backup-provider="${htmlEsc(provider.id||'')}" data-backup-job="${htmlEsc(job.id||'')}">
            <div class="dmd-backup-provider-job-main"><strong>${htmlEsc(job.name||'Job Veeam')}</strong><small>${htmlEsc(dmdBackupProviderTarget(job))}</small>${stats.length?`<small>${htmlEsc(stats.join(' · '))}</small>`:''}</div>
            <div class="dmd-backup-provider-job-actions">${buttons}<button type="button" class="dmd-agent-mini-btn danger" data-backup-provider-stop hidden>Arrêter</button></div>
            <div class="dmd-backup-provider-progress" data-backup-provider-progress hidden><div class="dmd-backup-progress"><i style="width:0%"></i></div><small>En attente…</small></div>
            <span class="dmd-backup-provider-run-state" data-backup-provider-state></span>
        </article>`;
    }).join('')+'</div>';
}
function dmdBackupRenderProviders(){
    const host=document.getElementById('backupProviderResults'),count=document.getElementById('backupProviderCount');if(!host)return;
    if(!DMD_BACKUP_PROVIDER_SCAN.length){host.innerHTML='<div class="dmd-agent-admin-empty">Aucune analyse.</div>';if(count)count.textContent='0';return;}
    let detectedCount=0;
    host.innerHTML=DMD_BACKUP_PROVIDER_SCAN.map(row=>{
        const device=dmdWorkspaceDeviceById(row.agent_id),name=device?.hostname||row.agent_id,ip=device?.last_ip||'';
        if(!row.ok)return `<section class="dmd-backup-provider-pc is-error"><header><div><strong>${htmlEsc(name)}</strong><small>${htmlEsc(ip)}</small></div><span>Échec</span></header><div class="dmd-agent-admin-empty">${htmlEsc(row.error||'Détection impossible')}</div></section>`;
        const providers=Array.isArray(row.result?.providers)?row.result.providers:[];
        const detected=providers.filter(p=>p&&p.detected);
        const servicesScanned=Number(row.result?.services_scanned||0);
        const softwareScanned=Number(row.result?.software_scanned||0);
        detectedCount+=detected.length;
        const body=detected.length?detected.map(p=>{
            const source=p.detection_source==='service-windows'?'Service Windows':(p.detection_source==='logiciel-installe'?'Logiciel installé':'Détection Agent');
            const serviceLabel=p.service_display_name||p.service_name||'';
            const meta=[];
            if(p.version)meta.push('Version '+p.version);
            if(serviceLabel)meta.push(serviceLabel);
            if(p.service_status)meta.push('État '+p.service_status);
            meta.push(source);
            const canConfigure=String(p.id||'')==='veeam-agent-windows'&&p.controllable!==false;
            return `<article class="dmd-backup-provider-card" data-backup-provider-card data-backup-agent="${htmlEsc(row.agent_id)}" data-backup-provider="${htmlEsc(p.id||'')}">
                <div class="dmd-backup-provider-card-head">
                    <div><strong>${htmlEsc(p.name||p.id||'Moteur')}</strong><small>${htmlEsc(meta.join(' · '))}</small></div>
                    <div class="dmd-backup-provider-card-actions">${canConfigure?`<button type="button" class="dmd-agent-mini-btn" data-backup-provider-config="${htmlEsc(row.agent_id)}" data-backup-provider="${htmlEsc(p.id||'')}">Configurer</button>`:''}<span class="dmd-agent-maint-state-pill">${p.controllable?'Pilotable':'Détecté'}</span></div>
                </div>
                ${p.diagnostic?`<div class="dmd-backup-provider-diagnostic">${htmlEsc(p.diagnostic)}</div>`:''}
                ${dmdBackupProviderJobsHtml(row.agent_id,p)}
            </article>`;
        }).join(''):`<div class="dmd-backup-provider-none">${servicesScanned} service${servicesScanned>1?'s':''} Windows analysé${servicesScanned>1?'s':''}${softwareScanned?' · '+softwareScanned+' logiciels analysés':''}. Aucun moteur de sauvegarde reconnu.</div>`;
        const scanMeta=servicesScanned?` · ${servicesScanned} services analysés`:'';
        return `<section class="dmd-backup-provider-pc"><header><div><strong>${htmlEsc(name)}</strong><small>${htmlEsc(ip)}${scanMeta}</small></div><span>${detected.length} moteur${detected.length>1?'s':''}</span></header>${body}</section>`;
    }).join('');
    if(count)count.textContent=detectedCount+' détecté'+(detectedCount>1?'s':'');
}
function dmdBackupFindProviderJobRow(agentId,provider,jobId=''){
    const rows=[...document.querySelectorAll('[data-backup-provider-job-row]')];
    return rows.find(r=>String(r.dataset.backupAgent||'')===String(agentId||'')&&String(r.dataset.backupProvider||'')===String(provider||'')&&String(r.dataset.backupJob||'')===String(jobId||''))||
        rows.find(r=>String(r.dataset.backupAgent||'')===String(agentId||'')&&String(r.dataset.backupProvider||'')===String(provider||''))||null;
}
function dmdBackupProviderSetRunUi(row,status,runId=''){
    if(!row)return;
    const s=status||{},summary=s.summary||{},state=row.querySelector('[data-backup-provider-state]'),progress=row.querySelector('[data-backup-provider-progress]'),bar=progress?.querySelector('i'),progressText=progress?.querySelector('small'),stop=row.querySelector('[data-backup-provider-stop]');
    const st=String(s.status||'').toLowerCase(),running=st==='running'||st==='stopping';
    if(runId)row.dataset.backupProviderRunId=runId;
    if(running&&runId)DMD_BACKUP_PROVIDER_RUNS[String(row.dataset.backupAgent||'')]=runId;
    const pct=dmdBackupClampPercent(summary.progress_percent);
    const detail=String(summary.progress_text||'').trim();
    const elapsed=Number(summary.elapsed_seconds||0);
    if(progress){
        progress.hidden=!(running||pct>=0||st==='completed'||st==='cancelled'||st==='failed');
        if(bar)bar.style.width=(pct>=0?pct:(st==='completed'?100:0))+'%';
        if(progressText){
            let txt=pct>=0?Math.round(pct)+' %':'Progression en cours';
            if(detail)txt+=' · '+detail;
            if(elapsed>0)txt+=' · '+dmdBackupElapsed(elapsed);
            progressText.textContent=txt;
        }
    }
    row.querySelectorAll('[data-backup-provider-run]').forEach(b=>b.disabled=running);
    if(stop){stop.hidden=!running;stop.disabled=st==='stopping';}
    if(state){
        state.className='dmd-backup-provider-run-state';
        if(st==='running')state.textContent='Sauvegarde en cours';
        else if(st==='stopping')state.textContent='Arrêt en cours…';
        else if(st==='completed'){state.textContent='Sauvegarde terminée';state.classList.add('ok');}
        else if(st==='cancelled'){state.textContent='Sauvegarde arrêtée';state.classList.add('warn');}
        else if(st==='unknown'){state.textContent='Suivi interrompu — actualise le moteur';state.classList.add('warn');}
        else if(st==='failed'){state.textContent='Échec : '+(s.error||'commande refusée');state.classList.add('bad');}
        else state.textContent=s.status?('État : '+s.status):'';
    }
}
async function dmdBackupDetectProviders(){
    const ids=dmdBackupSelectedAgentIds(),btn=document.getElementById('backupProviderDetect'),host=document.getElementById('backupProviderResults'),count=document.getElementById('backupProviderCount');
    if(!ids.length){showMsg('Sélectionne au moins un PC.',false);return;}
    if(btn){btn.disabled=true;btn.textContent='Détection…';}
    if(count)count.textContent='Analyse…';
    if(host)host.innerHTML='<div class="dmd-agent-admin-empty">Détection des moteurs sur '+ids.length+' PC…</div>';
    try{
        DMD_BACKUP_PROVIDER_SCAN=await dmdBatchRun(ids,id=>runAdminCommandForAgent(id,'backup.providers.list',{}, {showState:false,waitLimitMs:120000}),4);
        dmdBackupRenderProviders();
        dmdBackupRestoreProviderRuns(ids).catch(()=>{});
    }finally{
        if(btn){btn.textContent='Détecter';btn.disabled=dmdBackupSelectedAgentIds().length===0;}
    }
}
async function dmdBackupTrackProviderRun(agentId,runId,row){
    while(row&&document.body.contains(row)&&String(row.dataset.backupProviderRunId||'')===String(runId||'')){
        try{
            const s=await runAdminCommandForAgent(agentId,'backup.provider.status',{job_id:runId},{showState:false,waitLimitMs:30000});
            dmdBackupProviderSetRunUi(row,s,runId);
            const status=String(s?.status||'').toLowerCase();
            if(!['running','stopping'].includes(status))return;
        }catch(e){
            const state=row.querySelector('[data-backup-provider-state]');
            if(state){state.textContent='Suivi : '+(e.message||'indisponible');state.className='dmd-backup-provider-run-state warn';}
            return;
        }
        await new Promise(r=>setTimeout(r,2500));
    }
}
async function dmdBackupRestoreProviderRuns(ids){
    const rows=await dmdBatchRun(ids,agentId=>runAdminCommandForAgent(agentId,'backup.provider.status',{}, {showState:false,waitLimitMs:30000}),4);
    rows.forEach(x=>{
        if(!x.ok||!x.result)return;
        const s=x.result,st=String(s.status||'').toLowerCase(),summary=s.summary||{};
        if(!['running','stopping'].includes(st)||String(summary.action||'')==='recovery_iso')return;
        const provider=String(summary.provider||'veeam-agent-windows'),job=String(summary.job_id||'');
        const row=dmdBackupFindProviderJobRow(x.agent_id,provider,job);
        if(!row)return;
        row.dataset.backupProviderRunId=String(s.job_id||'');
        dmdBackupProviderSetRunUi(row,s,s.job_id||'');
        dmdBackupTrackProviderRun(x.agent_id,s.job_id,row);
    });
}
async function dmdBackupRunProviderAction(button){
    const agentId=String(button.dataset.backupProviderRun||''),provider=String(button.dataset.backupProvider||''),action=String(button.dataset.backupProviderAction||''),jobId=String(button.dataset.backupProviderJob||'');
    if(!agentId||!provider||!action)return;
    const device=dmdWorkspaceDeviceById(agentId),label=dmdBackupProviderActionLabel(action);
    if((action==='active_full'||action==='standalone_full')&&!confirm(label+' sur '+(device?.hostname||agentId)+' ?'))return;
    const row=button.closest('[data-backup-provider-job-row]'),state=row?.querySelector('[data-backup-provider-state]');
    row?.querySelectorAll('[data-backup-provider-run]').forEach(b=>b.disabled=true);
    if(state){state.textContent='Envoi…';state.className='dmd-backup-provider-run-state';}
    try{
        const r=await runAdminCommandForAgent(agentId,'backup.provider.action',{provider,action,job_id:jobId},{showState:false,waitLimitMs:60000});
        const runId=String(r?.job_id||'');
        if(!runId)throw new Error('ID de sauvegarde Veeam absent.');
        if(row){
            row.dataset.backupProviderRunId=runId;
            dmdBackupProviderSetRunUi(row,{status:'running',summary:{progress_percent:0,progress_text:'Démarrage Veeam…'}},runId);
            dmdBackupTrackProviderRun(agentId,runId,row);
        }
    }catch(e){
        row?.querySelectorAll('[data-backup-provider-run]').forEach(b=>b.disabled=false);
        if(state){state.textContent='Échec : '+(e.message||'commande refusée');state.className='dmd-backup-provider-run-state bad';}
        showMsg(e.message||'Commande de sauvegarde impossible.',false);
    }
}
async function dmdBackupStopProvider(button){
    const row=button.closest('[data-backup-provider-job-row]');if(!row)return;
    const agentId=String(row.dataset.backupAgent||''),runId=String(row.dataset.backupProviderRunId||'');
    const device=dmdWorkspaceDeviceById(agentId);
    if(!agentId||!runId||!confirm('Arrêter la sauvegarde Veeam en cours sur '+(device?.hostname||agentId)+' ?'))return;
    button.disabled=true;
    try{
        await runAdminCommandForAgent(agentId,'backup.provider.stop',{job_id:runId},{showState:false,waitLimitMs:45000});
        dmdBackupProviderSetRunUi(row,{status:'stopping',summary:{progress_text:'Arrêt demandé…'}},runId);
        dmdBackupTrackProviderRun(agentId,runId,row);
    }catch(e){button.disabled=false;showMsg(e.message||'Arrêt Veeam impossible.',false);}
}

/* Configuration Veeam distante */
function dmdBackupProviderConfigRenderJobs(jobs){
    const host=document.getElementById('backupProviderConfigJobs');if(!host)return;
    jobs=Array.isArray(jobs)?jobs:[];
    host.innerHTML=jobs.length?jobs.map(j=>`<div class="dmd-backup-provider-config-job"><strong>${htmlEsc(j.name||'Job Veeam')}</strong><span>${htmlEsc(dmdBackupProviderTarget(j))}</span></div>`).join(''):'<span class="dmd-agent-muted">Aucun job exportable dans cette configuration.</span>';
}
async function dmdBackupProviderConfigLoad(){
    const agentId=String(document.getElementById('backupProviderConfigAgent')?.value||''),provider=String(document.getElementById('backupProviderConfigProvider')?.value||'');
    if(!agentId||!provider)return;
    const state=document.getElementById('backupProviderConfigState'),xml=document.getElementById('backupProviderConfigXml');
    if(state)state.textContent='Lecture de la configuration Veeam…';if(xml)xml.value='';
    dmdBackupProviderConfigRenderJobs([]);
    try{
        const r=await runAdminCommandForAgent(agentId,'backup.provider.config.get',{provider},{showState:false,waitLimitMs:90000});
        if(xml)xml.value=String(r?.config_xml||'');
        dmdBackupProviderConfigRenderJobs(r?.jobs||[]);
        if(state)state.textContent='Configuration chargée'+(r?.version?' · version '+r.version:'')+'.';
    }catch(e){if(state)state.textContent='Échec : '+(e.message||'configuration indisponible');showMsg(e.message||'Configuration Veeam impossible à lire.',false);}
}
async function dmdBackupOpenProviderConfig(button){
    const agentId=String(button.dataset.backupProviderConfig||''),provider=String(button.dataset.backupProvider||'');
    if(!agentId||!provider)return;
    const device=dmdWorkspaceDeviceById(agentId),modal=document.getElementById('backupProviderConfigModal');
    dmdBackupProviderConfigCurrent={agentId,provider};
    document.getElementById('backupProviderConfigAgent').value=agentId;
    document.getElementById('backupProviderConfigProvider').value=provider;
    document.getElementById('backupProviderConfigTitle').textContent='Veeam Agent — '+(device?.hostname||agentId);
    document.getElementById('backupProviderConfigSub').textContent=(device?.last_ip||'IP inconnue')+' · configuration distante';
    document.getElementById('backupProviderConfigUsername').value='';
    document.getElementById('backupProviderConfigPassword').value='';
    const recState=document.getElementById('backupProviderRecoveryState');if(recState)recState.textContent='Aucun média en cours.';
    const recProgress=document.getElementById('backupProviderRecoveryProgress');if(recProgress)recProgress.hidden=true;
    const recStop=document.getElementById('backupProviderRecoveryStop');if(recStop)recStop.disabled=true;
    dmdBackupProviderRecoveryRunId='';dmdBackupProviderRecoveryPollToken++;
    if(modal)modal.hidden=false;
    await dmdBackupProviderConfigLoad();
}
function dmdBackupCloseProviderConfig(){
    dmdBackupProviderRecoveryPollToken++;
    const modal=document.getElementById('backupProviderConfigModal');if(modal)modal.hidden=true;
}
function dmdBackupProviderConfigPayload(){
    return {
        provider:String(document.getElementById('backupProviderConfigProvider')?.value||''),
        config_xml:String(document.getElementById('backupProviderConfigXml')?.value||''),
        username:String(document.getElementById('backupProviderConfigUsername')?.value||'').trim(),
        password:String(document.getElementById('backupProviderConfigPassword')?.value||'')
    };
}
async function dmdBackupProviderConfigSave(deploy=false){
    const current=dmdBackupProviderConfigCurrent,p=dmdBackupProviderConfigPayload(),state=document.getElementById('backupProviderConfigState');
    if(!current?.agentId||!p.provider||!p.config_xml.trim()){showMsg('Configuration Veeam vide.',false);return;}
    const ids=deploy?dmdBackupSelectedAgentIds():[current.agentId];
    if(!ids.length)return;
    if(deploy&&!confirm('Déployer cette configuration Veeam sur les '+ids.length+' PC sélectionnés ?'))return;
    if(state)state.textContent='Application sur '+ids.length+' PC…';
    const buttons=['backupProviderConfigSave','backupProviderConfigDeploy','backupProviderConfigReload'].map(id=>document.getElementById(id)).filter(Boolean);buttons.forEach(b=>b.disabled=true);
    try{
        const rows=await dmdBatchRun(ids,id=>runAdminCommandForAgent(id,'backup.provider.config.set',p,{showState:false,waitLimitMs:150000}),3);
        const ok=rows.filter(x=>x.ok).length,fail=rows.length-ok;
        if(state)state.textContent='Configuration appliquée sur '+ok+'/'+rows.length+' PC'+(fail?' · '+fail+' échec(s).':'.');
        document.getElementById('backupProviderConfigPassword').value='';
        showMsg('Configuration Veeam appliquée sur '+ok+'/'+rows.length+' PC.',fail===0);
        if(!deploy&&ok===1)await dmdBackupProviderConfigLoad();
        dmdBackupDetectProviders().catch(()=>{});
    }finally{buttons.forEach(b=>b.disabled=false);}
}
function dmdBackupRecoverySetUi(status){
    const progress=document.getElementById('backupProviderRecoveryProgress'),bar=progress?.querySelector('i'),txt=progress?.querySelector('small'),state=document.getElementById('backupProviderRecoveryState'),start=document.getElementById('backupProviderRecoveryStart'),stop=document.getElementById('backupProviderRecoveryStop');
    const s=status||{},summary=s.summary||{},st=String(s.status||'').toLowerCase(),running=st==='running'||st==='stopping',pct=dmdBackupClampPercent(summary.progress_percent);
    if(progress){progress.hidden=!(running||pct>=0||st==='completed'||st==='cancelled'||st==='failed');if(bar)bar.style.width=(pct>=0?pct:(st==='completed'?100:0))+'%';if(txt)txt.textContent=(pct>=0?Math.round(pct)+' %':'Création en cours')+(summary.progress_text?' · '+summary.progress_text:'');}
    if(start)start.disabled=running;if(stop)stop.disabled=!running||st==='stopping';
    if(state){
        if(st==='running')state.textContent='Création du média de récupération en cours…';
        else if(st==='stopping')state.textContent='Arrêt du média demandé…';
        else if(st==='completed')state.textContent='ISO créé'+(s.result?.path?' : '+s.result.path:'')+(Number(s.result?.size||0)>0?' · '+fmtAdminBytes(s.result.size):'');
        else if(st==='cancelled')state.textContent='Création de l’ISO arrêtée.';
        else if(st==='failed')state.textContent='Échec : '+(s.error||'création impossible');
        else state.textContent=s.status?('État : '+s.status):'Aucun média en cours.';
    }
}
async function dmdBackupTrackRecovery(agentId,runId){
    const token=++dmdBackupProviderRecoveryPollToken;
    while(token===dmdBackupProviderRecoveryPollToken&&String(dmdBackupProviderRecoveryRunId||'')===String(runId||'')){
        try{
            const s=await runAdminCommandForAgent(agentId,'backup.provider.status',{job_id:runId},{showState:false,waitLimitMs:30000});
            dmdBackupRecoverySetUi(s);
            if(!['running','stopping'].includes(String(s?.status||'').toLowerCase()))return;
        }catch(e){const st=document.getElementById('backupProviderRecoveryState');if(st)st.textContent='Suivi ISO : '+(e.message||'indisponible');return;}
        await new Promise(r=>setTimeout(r,2500));
    }
}
async function dmdBackupProviderRecoveryStart(){
    const current=dmdBackupProviderConfigCurrent,path=String(document.getElementById('backupProviderRecoveryPath')?.value||'').trim();
    if(!current?.agentId||!path||!/\.iso$/i.test(path)){showMsg('Renseigne un chemin ISO valide sur le PC distant.',false);return;}
    if(!confirm('Créer le média de récupération Veeam sur '+(dmdWorkspaceDeviceById(current.agentId)?.hostname||current.agentId)+' ?'))return;
    const r=await runAdminCommandForAgent(current.agentId,'backup.provider.recovery.iso',{provider:current.provider,path},{showState:false,waitLimitMs:60000});
    dmdBackupProviderRecoveryRunId=String(r?.job_id||'');
    if(!dmdBackupProviderRecoveryRunId)throw new Error('ID de création ISO absent.');
    dmdBackupRecoverySetUi({status:'running',summary:{progress_percent:0}});
    dmdBackupTrackRecovery(current.agentId,dmdBackupProviderRecoveryRunId);
}
async function dmdBackupProviderRecoveryStop(){
    const current=dmdBackupProviderConfigCurrent,runId=dmdBackupProviderRecoveryRunId;if(!current?.agentId||!runId)return;
    if(!confirm('Arrêter la création du média Veeam ?'))return;
    await runAdminCommandForAgent(current.agentId,'backup.provider.stop',{job_id:runId},{showState:false,waitLimitMs:45000});
    dmdBackupRecoverySetUi({status:'stopping',summary:{progress_text:'Arrêt demandé…'}});
    dmdBackupTrackRecovery(current.agentId,runId);
}

/* Image système DoMyDesk / Bare Metal */
function dmdBackupImageReset(){
    DMD_BACKUP_IMAGE_SCAN=[];
    DMD_BACKUP_IMAGE_RUNS={};
    const host=document.getElementById('backupImageResults'),count=document.getElementById('backupImageCount');
    if(count)count.textContent='Non analysé';
    if(host)host.innerHTML='<div class="dmd-agent-admin-empty">Sélectionne un ou plusieurs PC puis analyse les disques.</div>';
    dmdBackupImageUpdateTargetHint();
}
function dmdBackupImageTarget(){
    return dmdBackupTargetById(dmdBackupSelectedTargetId);
}
function dmdBackupImageTargetDrive(target){
    if(!target||target.type!=='local')return '';
    const m=String(target.local_path||'').match(/^([A-Za-z]):/);return m?m[1].toUpperCase():'';
}
function dmdBackupImageTargetUsable(){
    const target=dmdBackupImageTarget();return !!(target&&(target.type==='smb'||target.type==='local'));
}
function dmdBackupImageUpdateTargetHint(){
    const hint=document.getElementById('backupImageTargetHint'),target=dmdBackupImageTarget();
    if(hint){
        if(!target)hint.textContent='Choisis une cible NAS/SMB ou un disque/USB avant de lancer une image système.';
        else if(target.type==='webdav')hint.textContent='La cible « '+(target.name||'WebDAV')+' » n’est pas compatible avec une image Bare Metal. Choisis NAS/SMB ou disque/USB.';
        else hint.textContent='Cible image : '+(target.name||'Cible')+' · '+dmdBackupTargetDescription(target)+' · restauration via WinRE / support Windows.';
    }
    const usable=dmdBackupImageTargetUsable(),targetDrive=dmdBackupImageTargetDrive(target);
    document.querySelectorAll('[data-backup-image-volume]').forEach(cb=>{
        const letter=String(cb.value||'').replace(':','').toUpperCase(),isTarget=!!(targetDrive&&letter===targetDrive),wasTarget=cb.dataset.backupTargetDisabled==='1';
        const card=cb.closest('[data-backup-image-card]'),running=card&&['running','stopping'].includes(String(card.dataset.backupImageStatus||''));
        cb.dataset.backupTargetDisabled=isTarget?'1':'0';
        cb.disabled=!!running||isTarget;
        if(isTarget)cb.checked=false;else if(wasTarget&&!running)cb.checked=true;
        cb.closest('.dmd-backup-image-volume')?.classList.toggle('is-target',isTarget);
    });
    document.querySelectorAll('[data-backup-image-start]').forEach(b=>{const card=b.closest('[data-backup-image-card]');const running=card&&['running','stopping'].includes(String(card.dataset.backupImageStatus||''));b.disabled=!usable||!!running;});
}
function dmdBackupImageDiskHtml(agentId,result){
    const storage=result?.storage||{},disks=Array.isArray(storage.disks)?storage.disks:[],targetDrive=dmdBackupImageTargetDrive(dmdBackupImageTarget());
    if(!disks.length)return '<div class="dmd-backup-provider-none">Aucun disque exploitable remonté par Windows.</div>';
    return '<div class="dmd-backup-image-disks">'+disks.map(d=>{
        const parts=Array.isArray(d.partitions)?d.partitions:[];
        const partHtml=parts.map(p=>{
            const letter=String(p.drive_letter||'').toUpperCase(),selectable=/^[A-Z]$/.test(letter),isTarget=selectable&&letter===targetDrive;
            const tags=[];if(p.is_system)tags.push('Système');if(p.is_boot)tags.push('Boot');if(isTarget)tags.push('Cible sauvegarde');
            if(selectable){
                return `<label class="dmd-backup-image-volume${isTarget?' is-target':''}"><input type="checkbox" data-backup-image-volume value="${htmlEsc(letter+':')}" ${isTarget?'disabled': 'checked'}><span><strong>${htmlEsc(letter+':'+(p.label?' · '+p.label:''))}</strong><small>${htmlEsc(p.filesystem||'Volume')} · ${htmlEsc(fmtAdminBytes(p.size))}${tags.length?' · '+htmlEsc(tags.join(' · ')):''}</small></span></label>`;
            }
            return `<div class="dmd-backup-image-volume is-hidden"><span><strong>Partition ${htmlEsc(p.partition_number??'')}</strong><small>${htmlEsc(p.type||'Sans lettre')} · ${htmlEsc(fmtAdminBytes(p.size))}${tags.length?' · '+htmlEsc(tags.join(' · ')):''}</small></span></div>`;
        }).join('');
        return `<div class="dmd-backup-image-disk"><header><div><strong>Disque ${htmlEsc(d.number??'')} · ${htmlEsc(d.friendly_name||'Disque Windows')}</strong><small>${htmlEsc(fmtAdminBytes(d.size))}${d.bus_type?' · '+htmlEsc(d.bus_type):''}</small></div>${d.protected?'<span class="dmd-agent-maint-state-pill">Système</span>':''}</header>${partHtml||'<div class="dmd-backup-provider-none">Aucune partition.</div>'}</div>`;
    }).join('')+'</div>';
}
function dmdBackupRenderImages(){
    const host=document.getElementById('backupImageResults'),count=document.getElementById('backupImageCount');if(!host)return;
    if(!DMD_BACKUP_IMAGE_SCAN.length){host.innerHTML='<div class="dmd-agent-admin-empty">Aucune analyse.</div>';if(count)count.textContent='0';return;}
    let available=0;
    host.innerHTML=DMD_BACKUP_IMAGE_SCAN.map(row=>{
        const d=dmdWorkspaceDeviceById(row.agent_id),name=d?.hostname||row.agent_id,ip=d?.last_ip||'';
        if(!row.ok)return `<article class="dmd-backup-image-card is-error" data-backup-image-card data-agent="${htmlEsc(row.agent_id)}"><header><div><strong>${htmlEsc(name)}</strong><small>${htmlEsc(ip)}</small></div><span>Échec</span></header><div class="dmd-agent-admin-empty">${htmlEsc(row.error||'Analyse impossible')}</div></article>`;
        const r=row.result||{},ok=!!r.available;if(ok)available++;
        return `<article class="dmd-backup-image-card${ok?'':' is-error'}" data-backup-image-card data-agent="${htmlEsc(row.agent_id)}" data-backup-image-status="">
            <header><div><strong>${htmlEsc(name)}</strong><small>${htmlEsc(ip)} · ${htmlEsc(r.engine||'Windows VSS / wbadmin')}</small></div><span class="dmd-agent-maint-state-pill">${ok?'Prêt':'Indisponible'}</span></header>
            ${r.diagnostic?`<div class="dmd-backup-provider-diagnostic">${htmlEsc(r.diagnostic)}</div>`:''}
            ${ok?dmdBackupImageDiskHtml(row.agent_id,r):''}
            <div class="dmd-backup-image-options"><label class="check"><input type="checkbox" checked disabled><span>Inclure les volumes critiques Windows / démarrage</span></label><small>Les volumes cochés sont ajoutés à l’image. Les partitions système sans lettre sont incluses automatiquement par Windows.</small></div>
            <div class="dmd-backup-provider-progress" data-backup-image-progress hidden><div class="dmd-backup-progress"><i style="width:0%"></i></div><small>En attente…</small></div>
            <div class="dmd-backup-image-state" data-backup-image-state>${ok?'Prêt à créer une image complète.':'Image système indisponible sur cette édition de Windows.'}</div>
            <div class="dmd-backup-image-actions">${ok?`<button type="button" class="dmd-agent-mini-btn primary" data-backup-image-start="${htmlEsc(row.agent_id)}">Créer l’image complète</button><button type="button" class="dmd-agent-mini-btn danger" data-backup-image-stop="${htmlEsc(row.agent_id)}" hidden>Arrêter</button>`:''}</div>
        </article>`;
    }).join('');
    if(count)count.textContent=available+'/'+DMD_BACKUP_IMAGE_SCAN.length+' prêt'+(available>1?'s':'');
    dmdBackupImageUpdateTargetHint();
}
function dmdBackupImageSetRunUi(card,status,runId=''){
    if(!card)return;
    const s=status||{},summary=s.summary||{},st=String(s.status||'').toLowerCase(),running=st==='running'||st==='stopping',pct=dmdBackupClampPercent(summary.progress_percent),progress=card.querySelector('[data-backup-image-progress]'),bar=progress?.querySelector('i'),txt=progress?.querySelector('small'),state=card.querySelector('[data-backup-image-state]'),start=card.querySelector('[data-backup-image-start]'),stop=card.querySelector('[data-backup-image-stop]');
    card.dataset.backupImageStatus=st;if(runId)card.dataset.backupImageRunId=runId;
    if(runId&&running)DMD_BACKUP_IMAGE_RUNS[String(card.dataset.agent||'')]=runId;
    if(progress){progress.hidden=!(running||pct>=0||st==='completed'||st==='cancelled'||st==='failed');if(bar)bar.style.width=(pct>=0?pct:(st==='completed'?100:0))+'%';if(txt){let t=pct>=0?Math.round(pct)+' %':'Image en cours';if(summary.progress_text)t+=' · '+summary.progress_text;if(Number(summary.elapsed_seconds||0)>0)t+=' · '+dmdBackupElapsed(summary.elapsed_seconds);txt.textContent=t;}}
    if(start)start.disabled=running||!dmdBackupImageTargetUsable();
    if(stop){stop.hidden=!running;stop.disabled=st==='stopping';}
    if(state){
        state.className='dmd-backup-image-state';
        if(st==='running')state.textContent='Image système en cours vers '+(summary.destination||'la cible')+'.';
        else if(st==='stopping')state.textContent='Arrêt de l’image système en cours…';
        else if(st==='completed'){state.textContent='Image système terminée · restauration Bare Metal prête.';state.classList.add('ok');}
        else if(st==='cancelled'){state.textContent='Image système arrêtée.';state.classList.add('warn');}
        else if(st==='failed'){state.textContent='Échec : '+(s.error||'image impossible');state.classList.add('bad');}
        else if(st==='unknown'){state.textContent='Suivi interrompu après redémarrage de l’Agent.';state.classList.add('warn');}
    }
}
async function dmdBackupDetectImages(){
    const ids=dmdBackupSelectedAgentIds(),btn=document.getElementById('backupImageDetect'),host=document.getElementById('backupImageResults'),count=document.getElementById('backupImageCount');
    if(!ids.length)return;
    if(btn){btn.disabled=true;btn.textContent='Analyse…';}if(count)count.textContent='Analyse…';if(host)host.innerHTML='<div class="dmd-agent-admin-empty">Analyse des disques sur '+ids.length+' PC…</div>';
    try{
        DMD_BACKUP_IMAGE_SCAN=await dmdBatchRun(ids,id=>runAdminCommandForAgent(id,'backup.image.list',{}, {showState:false,waitLimitMs:60000}),4);
        dmdBackupRenderImages();
        dmdBackupRestoreImageRuns(ids).catch(()=>{});
    }finally{if(btn){btn.textContent='Analyser les disques';btn.disabled=dmdBackupSelectedAgentIds().length===0;}}
}
function dmdBackupImageVolumes(card){
    return [...card.querySelectorAll('[data-backup-image-volume]:checked:not(:disabled)')].map(x=>String(x.value||'')).filter(Boolean);
}
async function dmdBackupStartImage(button){
    const agentId=String(button.dataset.backupImageStart||''),card=button.closest('[data-backup-image-card]'),target=dmdBackupImageTarget();if(!agentId||!card)return;
    if(!target||!['smb','local'].includes(String(target.type||''))){showMsg('Choisis une cible NAS/SMB ou disque/USB pour l’image système.',false);return;}
    const volumes=dmdBackupImageVolumes(card),device=dmdWorkspaceDeviceById(agentId);
    if(!confirm('Créer une image système complète de '+(device?.hostname||agentId)+' vers « '+(target.name||'cible')+' » ?\nLes volumes critiques Windows seront inclus automatiquement.'))return;
    card.querySelectorAll('button').forEach(b=>b.disabled=true);
    try{
        const r=await runAdminCommandForAgent(agentId,'backup.image.start',{target_id:target.id,all_critical:true,volumes},{showState:false,waitLimitMs:60000});
        const runId=String(r?.job_id||'');if(!runId)throw new Error('ID image système absent.');
        card.dataset.backupImageRunId=runId;DMD_BACKUP_IMAGE_RUNS[agentId]=runId;
        dmdBackupImageSetRunUi(card,{status:'running',summary:{progress_percent:0,destination:r.destination||dmdBackupTargetDescription(target)}},runId);
        dmdBackupTrackImage(agentId,runId,card);
    }catch(e){dmdBackupImageSetRunUi(card,{status:'failed',error:e.message||'démarrage impossible'});showMsg(e.message||'Image système impossible.',false);}
}
async function dmdBackupTrackImage(agentId,runId,card){
    while(card&&document.body.contains(card)&&String(card.dataset.backupImageRunId||'')===String(runId||'')){
        try{
            const s=await runAdminCommandForAgent(agentId,'backup.image.status',{job_id:runId},{showState:false,waitLimitMs:30000});
            dmdBackupImageSetRunUi(card,s,runId);
            if(!['running','stopping'].includes(String(s?.status||'').toLowerCase()))return;
        }catch(e){dmdBackupImageSetRunUi(card,{status:'unknown',error:e.message||'suivi indisponible'},runId);return;}
        await new Promise(r=>setTimeout(r,2500));
    }
}
async function dmdBackupRestoreImageRuns(ids){
    const rows=await dmdBatchRun(ids,id=>runAdminCommandForAgent(id,'backup.image.status',{}, {showState:false,waitLimitMs:30000}),4);
    rows.forEach(x=>{
        if(!x.ok||!x.result||!['running','stopping'].includes(String(x.result.status||'').toLowerCase()))return;
        const card=[...document.querySelectorAll('[data-backup-image-card]')].find(c=>String(c.dataset.agent||'')===String(x.agent_id||''));if(!card)return;
        const runId=String(x.result.job_id||'');if(!runId)return;
        card.dataset.backupImageRunId=runId;dmdBackupImageSetRunUi(card,x.result,runId);dmdBackupTrackImage(x.agent_id,runId,card);
    });
}
async function dmdBackupStopImage(button){
    const agentId=String(button.dataset.backupImageStop||''),card=button.closest('[data-backup-image-card]'),runId=String(card?.dataset.backupImageRunId||'');if(!agentId||!card||!runId)return;
    if(!confirm('Arrêter l’image système en cours sur '+(dmdWorkspaceDeviceById(agentId)?.hostname||agentId)+' ?'))return;
    button.disabled=true;
    try{
        await runAdminCommandForAgent(agentId,'backup.image.stop',{job_id:runId},{showState:false,waitLimitMs:45000});
        dmdBackupImageSetRunUi(card,{status:'stopping',summary:{progress_text:'Arrêt demandé…'}},runId);
        dmdBackupTrackImage(agentId,runId,card);
    }catch(e){button.disabled=false;showMsg(e.message||'Arrêt de l’image système impossible.',false);}
}

/* Événements sauvegarde */
document.getElementById('backupProviderDetect')?.addEventListener('click',()=>dmdBackupDetectProviders().catch(e=>showMsg(e.message||'Détection des moteurs impossible.',false)));
document.getElementById('backupProviderResults')?.addEventListener('click',e=>{
    const run=e.target.closest('[data-backup-provider-run]');if(run){dmdBackupRunProviderAction(run);return;}
    const stop=e.target.closest('[data-backup-provider-stop]');if(stop){dmdBackupStopProvider(stop);return;}
    const config=e.target.closest('[data-backup-provider-config]');if(config){dmdBackupOpenProviderConfig(config);}
});
document.getElementById('backupImageDetect')?.addEventListener('click',()=>dmdBackupDetectImages().catch(e=>showMsg(e.message||'Analyse des disques impossible.',false)));
document.getElementById('backupImageResults')?.addEventListener('click',e=>{
    const start=e.target.closest('[data-backup-image-start]');if(start){dmdBackupStartImage(start);return;}
    const stop=e.target.closest('[data-backup-image-stop]');if(stop){dmdBackupStopImage(stop);}
});
document.getElementById('backupProviderConfigClose')?.addEventListener('click',dmdBackupCloseProviderConfig);
document.getElementById('backupProviderConfigReload')?.addEventListener('click',()=>dmdBackupProviderConfigLoad().catch(e=>showMsg(e.message||'Lecture Veeam impossible.',false)));
document.getElementById('backupProviderConfigSave')?.addEventListener('click',()=>dmdBackupProviderConfigSave(false).catch(e=>showMsg(e.message||'Configuration Veeam impossible.',false)));
document.getElementById('backupProviderConfigDeploy')?.addEventListener('click',()=>dmdBackupProviderConfigSave(true).catch(e=>showMsg(e.message||'Déploiement Veeam impossible.',false)));
document.getElementById('backupProviderRecoveryStart')?.addEventListener('click',()=>dmdBackupProviderRecoveryStart().catch(e=>showMsg(e.message||'Création ISO impossible.',false)));
document.getElementById('backupProviderRecoveryStop')?.addEventListener('click',()=>dmdBackupProviderRecoveryStop().catch(e=>showMsg(e.message||'Arrêt ISO impossible.',false)));
document.getElementById('backupProviderConfigModal')?.addEventListener('click',e=>{if(e.target&&e.target.id==='backupProviderConfigModal')dmdBackupCloseProviderConfig();});
document.getElementById('backupAllAgents')?.addEventListener('change',e=>{
    document.querySelectorAll('.dmd-backup-pc-target:not(:disabled)').forEach(x=>x.checked=!!e.target.checked);
    const gs=document.getElementById('backupSelectGroup');if(gs)gs.value='';
    dmdBackupSelectionChanged();
});
document.getElementById('backupSelectGroup')?.addEventListener('change',e=>{
    const gid=String(e.target.value||''),group=PC_GROUPS.find(g=>String(g.group_id||'')===gid),members=new Set((group&&Array.isArray(group.agent_ids)?group.agent_ids:[]).map(String));
    document.querySelectorAll('.dmd-backup-pc-target').forEach(x=>{x.checked=!x.disabled&&gid!==''&&members.has(String(x.value||''));});
    const all=document.getElementById('backupAllAgents');if(all)all.checked=false;
    dmdBackupSelectionChanged();
});
document.getElementById('backupAgentGrid')?.addEventListener('change',e=>{if(e.target&&e.target.classList.contains('dmd-backup-pc-target')){const gs=document.getElementById('backupSelectGroup');if(gs)gs.value='';const all=document.getElementById('backupAllAgents');if(all)all.checked=false;dmdBackupSelectionChanged();}});
document.getElementById('backupPresetGrid')?.addEventListener('change',dmdBackupRenderSelections);
document.getElementById('backupChooseSources')?.addEventListener('click',()=>dmdBackupOpenBrowser('source'));
document.getElementById('backupManageTargets')?.addEventListener('click',dmdBackupOpenTargetModal);
document.getElementById('backupNewTarget')?.addEventListener('click',()=>dmdBackupOpenTargetForm(null));
document.getElementById('backupTargetType')?.addEventListener('change',dmdBackupTargetFormTypeSync);
document.getElementById('backupTargetBrowseLocal')?.addEventListener('click',()=>dmdBackupOpenBrowser('target-local'));
document.getElementById('backupTargetCancel')?.addEventListener('click',dmdBackupCloseTargetForm);
document.getElementById('backupTargetModalClose')?.addEventListener('click',dmdBackupCloseTargetModal);
document.getElementById('backupTargetSave')?.addEventListener('click',()=>dmdBackupSaveTarget(false).catch(e=>showMsg(e.message||'Cible impossible à enregistrer.',false)));
document.getElementById('backupTargetFormTest')?.addEventListener('click',()=>dmdBackupSaveTarget(true).catch(e=>showMsg(e.message||'Cible impossible à enregistrer/tester.',false)));
document.getElementById('backupSmbDiscover')?.addEventListener('click',()=>dmdBackupDiscoverShares().catch(e=>{const st=document.getElementById('backupSmbDiscoveryState');if(st)st.textContent='Échec';showMsg(e.message||'Découverte SMB impossible.',false);}));
document.getElementById('backupSmbDiscovery')?.addEventListener('click',async e=>{
    const shares=e.target.closest('[data-backup-smb-shares]');if(shares){await dmdBackupDiscoverShares().catch(err=>showMsg(err.message,false));return;}
    const share=e.target.closest('[data-backup-smb-share]');if(share){document.getElementById('backupTargetShare').value=share.dataset.backupSmbShare||'';document.getElementById('backupTargetFolder').value='';await dmdBackupBrowseSmbFolder('').catch(err=>showMsg(err.message,false));return;}
    const folder=e.target.closest('[data-backup-smb-folder]');if(folder){document.getElementById('backupTargetFolder').value=folder.dataset.backupSmbFolder||'';await dmdBackupBrowseSmbFolder(folder.dataset.backupSmbFolder||'').catch(err=>showMsg(err.message,false));return;}
    const use=e.target.closest('[data-backup-smb-use]');if(use){document.getElementById('backupTargetFolder').value=use.dataset.backupSmbUse||'';const st=document.getElementById('backupSmbDiscoveryState');if(st)st.textContent='Dossier sélectionné';return;}
});
document.getElementById('backupTargetSelect')?.addEventListener('change',e=>{dmdBackupSelectedTargetId=String(e.target.value||'');const state=document.getElementById('backupTargetTestState');if(state)state.textContent='';dmdBackupRenderSelections();dmdBackupImageUpdateTargetHint();});
document.getElementById('backupTestTarget')?.addEventListener('click',()=>dmdBackupTestTarget().catch(e=>showMsg(e.message||'Test impossible.',false)));
document.getElementById('backupTargetDelete')?.addEventListener('click',async()=>{
    const id=String(document.getElementById('backupTargetId')?.value||'');const ids=dmdBackupSelectedAgentIds();if(!id||!ids.length||!confirm('Supprimer cette cible des '+ids.length+' PC sélectionnés ?'))return;
    const rows=await dmdBatchRun(ids,agentId=>runAdminCommandForAgent(agentId,'backup.target.delete',{target_id:id},{showState:false}),6);
    const ok=rows.filter(x=>x.ok).length;if(dmdBackupSelectedTargetId===id)dmdBackupSelectedTargetId='';await dmdBackupLoadTargets();dmdBackupCloseTargetForm();showMsg('Cible supprimée sur '+ok+'/'+rows.length+' PC.',ok===rows.length);
});
document.getElementById('backupTargetList')?.addEventListener('click',e=>{
    const edit=e.target.closest('[data-backup-target-edit]');if(edit){dmdBackupOpenTargetForm(dmdBackupTargetById(edit.dataset.backupTargetEdit||''));return;}
    const test=e.target.closest('[data-backup-target-test]');if(test)dmdBackupTestTarget(test.dataset.backupTargetTest||'').catch(err=>showMsg(err.message,false));
});
document.getElementById('backupBrowserClose')?.addEventListener('click',dmdBackupCloseBrowserModal);
document.getElementById('backupBrowser')?.addEventListener('click',async e=>{
    const roots=e.target.closest('[data-backup-roots]');if(roots){await dmdBackupLoadRoots();return;}
    const browse=e.target.closest('[data-backup-browse]');if(browse){await dmdBackupBrowse(browse.dataset.backupBrowse||'');return;}
    const add=e.target.closest('[data-backup-add-source]');if(add){const v=String(add.dataset.backupAddSource||'');if(v&&!dmdBackupWorkspaceSources.includes(v))dmdBackupWorkspaceSources.push(v);dmdBackupRenderSelections();return;}
    const local=e.target.closest('[data-backup-target-local]');if(local){const inp=document.getElementById('backupTargetLocalPath');if(inp)inp.value=String(local.dataset.backupTargetLocal||'');dmdBackupCloseBrowserModal();}
});
document.getElementById('backupSelectedSources')?.addEventListener('click',e=>{const b=e.target.closest('[data-backup-source-remove]');if(!b)return;const i=Number(b.dataset.backupSourceRemove);if(Number.isInteger(i)&&i>=0)dmdBackupWorkspaceSources.splice(i,1);dmdBackupRenderSelections();});
document.getElementById('backupWorkspaceStatus')?.addEventListener('click',async e=>{
    const b=e.target.closest('[data-backup-stop-agent]');if(!b)return;
    const agentId=String(b.dataset.backupStopAgent||''),jobId=String(b.dataset.backupStopJob||'');if(!agentId)return;
    const d=dmdWorkspaceDeviceById(agentId);if(!confirm('Arrêter la sauvegarde en cours sur '+(d?.hostname||agentId)+' ?'))return;
    b.disabled=true;
    try{await runAdminCommandForAgent(agentId,'backup.files.stop',jobId?{job_id:jobId}:{},{showState:false,waitLimitMs:30000});showMsg('Arrêt demandé sur '+(d?.hostname||agentId)+'.');dmdBackupPollToken++;await dmdBackupWorkspaceRefresh('',true);}catch(err){b.disabled=false;showMsg(err.message||'Arrêt de la sauvegarde impossible.',false);}
});
document.getElementById('backupWorkspaceStop')?.addEventListener('click',async()=>{
    const ids=dmdBackupSelectedAgentIds();if(!ids.length||!confirm('Arrêter les sauvegardes en cours sur les PC sélectionnés ?'))return;
    const btn=document.getElementById('backupWorkspaceStop');if(btn)btn.disabled=true;
    const rows=await dmdBatchRun(ids,agentId=>runAdminCommandForAgent(agentId,'backup.files.stop',dmdBackupBatchJobs[agentId]?{job_id:dmdBackupBatchJobs[agentId]}:{},{showState:false,waitLimitMs:30000}),6);
    const ok=rows.filter(x=>x.ok).length;showMsg('Arrêt demandé sur '+ok+'/'+rows.length+' PC.',ok===rows.length);dmdBackupPollToken++;await dmdBackupWorkspaceRefresh('',true);
});
document.getElementById('backupWorkspaceRefresh')?.addEventListener('click',()=>{dmdBackupPollToken++;dmdBackupWorkspaceRefresh();});
document.getElementById('backupWorkspaceRun')?.addEventListener('click',async()=>{
    const ids=dmdBackupSelectedAgentIds(),target=dmdBackupTargetById(dmdBackupSelectedTargetId),presets=dmdBackupPresetValues();
    if(!ids.length||!target||(!presets.length&&!dmdBackupWorkspaceSources.length))return;
    const retentionRaw=Number.parseInt(String(document.getElementById('backupRetentionCount')?.value||'5'),10);
    const retention_count=Number.isFinite(retentionRaw)?Math.max(1,Math.min(100,retentionRaw)):5;
    const retentionInput=document.getElementById('backupRetentionCount');if(retentionInput)retentionInput.value=String(retention_count);
    const auto=!!document.getElementById('backupExcludeTemp')?.checked;
    const exclude_dirs=auto?['$RECYCLE.BIN','System Volume Information','Temp','tmp','Cache','Caches','node_modules','.git']:[],exclude_files=auto?['*.tmp','*.temp','*.cache','Thumbs.db','desktop.ini']:[];
    if(!confirm('Lancer la sauvegarde sur '+ids.length+' PC vers « '+(target.name||'cible')+' » ?\nRétention : '+retention_count+' sauvegarde(s) par PC.'))return;
    const btn=document.getElementById('backupWorkspaceRun');if(btn)btn.disabled=true;
    dmdBackupBatchJobs={};
    try{
        const rows=await dmdBatchRun(ids,agentId=>runAdminCommandForAgent(agentId,'backup.files.start',{sources:dmdBackupWorkspaceSources,source_presets:presets,target_id:target.id,retention_count,exclude_dirs,exclude_files},{showState:false}),6);
        rows.forEach(x=>{if(x.ok&&x.result&&x.result.job_id)dmdBackupBatchJobs[x.agent_id]=x.result.job_id;});
        const ok=rows.filter(x=>x.ok).length,fail=rows.length-ok;showMsg('Sauvegarde lancée sur '+ok+'/'+rows.length+' PC'+(fail?' · '+fail+' échec(s).':'.'),fail===0);
        dmdBackupPollToken++;await dmdBackupWorkspaceRefresh('',true);
    }finally{dmdBackupRenderSelections();if(btn)btn.disabled=false;}
});
document.getElementById('backupTargetModal')?.addEventListener('click',e=>{if(e.target&&e.target.id==='backupTargetModal')dmdBackupCloseTargetModal();});
document.getElementById('backupBrowserModal')?.addEventListener('click',e=>{if(e.target&&e.target.id==='backupBrowserModal')dmdBackupCloseBrowserModal();});

document.getElementById('scanWorkspaceExportPdf')?.addEventListener('click',dmdScanExportPdf);
document.getElementById('scanPdfClose')?.addEventListener('click',dmdScanClosePdf);
document.getElementById('scanPdfDownload')?.addEventListener('click',dmdScanDownloadPdf);
document.getElementById('scanPdfModal')?.addEventListener('click',e=>{if(e.target&&e.target.id==='scanPdfModal')dmdScanClosePdf();});
document.addEventListener('change',e=>{if(e.target&&e.target.id==='deviceUpdateZipInput'){const f=e.target.files&&e.target.files[0];if(f)featureUploadUpdateZip(f).catch(err=>showMsg(err.message||'Import ZIP impossible.',false));e.target.value='';}});

/* Événements scan */
const scanAgentSel=document.getElementById('scanWorkspaceAgent');if(scanAgentSel)scanAgentSel.addEventListener('change',dmdScanWorkspaceAgentChanged);
document.getElementById('scanWorkspaceDetect')?.addEventListener('click',dmdScanDetectNetworks);
document.getElementById('scanDetectedNetworks')?.addEventListener('change',e=>{if(e.target&&e.target.name==='scanDetectedNetwork'){dmdScanWorkspaceCidr=String(e.target.value||'');dmdScanRenderNetworks();}});
document.getElementById('scanWorkspaceStop')?.addEventListener('click',async()=>{
    if(!selectedDevice)return;const jobId=dmdScanCurrentJobId||String(dmdScanLastResult?.job_id||'');if(!confirm('Arrêter le scan réseau en cours sur '+(selectedDevice.hostname||'ce PC')+' ?'))return;
    const btn=document.getElementById('scanWorkspaceStop');if(btn)btn.disabled=true;
    try{await runAdminCommandForAgent(selectedDevice.agent_id,'network.scan.stop',jobId?{job_id:jobId}:{},{showState:false,waitLimitMs:30000});showMsg('Arrêt du scan demandé.');dmdScanPollToken++;await dmdScanWorkspaceRefresh(jobId,true);}catch(err){if(btn)btn.disabled=false;showMsg(err.message||'Arrêt du scan impossible.',false);}
});
document.getElementById('scanWorkspaceRefresh')?.addEventListener('click',()=>{dmdScanPollToken++;dmdScanWorkspaceRefresh();});
document.getElementById('scanWorkspaceRun')?.addEventListener('click',async()=>{
    if(!selectedDevice||!dmdScanWorkspaceCidr)return;
    const profile=document.getElementById('scanWorkspaceProfile')?.value||'standard';
    const ports=profile==='light'?[80,443,445,3389]:profile==='extended'?[21,22,23,25,53,80,110,135,139,143,389,443,445,636,1433,3306,3389,5000,5001,5432,8000,8080,8443,9100]:[22,53,80,135,139,443,445,3389,5000,5001,8000,8080,8443,9100];
    const resolve_names=!!document.getElementById('scanWorkspaceResolve')?.checked;
    const btn=document.getElementById('scanWorkspaceRun');if(btn)btn.disabled=true;
    try{
        const r=await runAdminCommandForAgent(selectedDevice.agent_id,'network.scan.start',{cidr:dmdScanWorkspaceCidr,ports,timeout_ms:profile==='extended'?350:profile==='light'?180:240,resolve_names},{showState:false});
        dmdScanCurrentJobId=String(r.job_id||'');showMsg('Scan lancé depuis '+(selectedDevice.hostname||'le PC')+' : '+(r.job_id||'job créé')+'.');
        dmdScanPollToken++;await dmdScanWorkspaceRefresh(r.job_id||'',true);
    }catch(e){showMsg(e.message||'Scan impossible.',false);}
    finally{dmdScanRenderNetworks();if(btn)btn.disabled=false;}
});


/* R19 — navigation de la page Mise à jour DoMyDesk + résumé dynamique. */
function r19OpenUpdateTab(name){
    const root=document.querySelector('.dmd-r19-update-page');
    if(!root)return;
    root.querySelectorAll('[data-r19-update-pane]').forEach(p=>{const on=p.dataset.r19UpdatePane===name;p.hidden=!on;p.classList.toggle('active',on);});
    root.querySelectorAll('.dmd-r19-update-tabs [data-r19-update-tab]').forEach(b=>b.classList.toggle('active',b.dataset.r19UpdateTab===name));
}
document.querySelectorAll('[data-r19-update-tab]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();r19OpenUpdateTab(b.dataset.r19UpdateTab||'overview');}));

function r19SyncUpdateSummary(){
    const select=document.getElementById('maintAgentVersionSelect');
    const version=String(select?.value||'').trim()||'—';
    const target=document.getElementById('r19AgentTargetVersion');if(target)target.textContent=version;
    document.querySelectorAll('[data-r19-target-build]').forEach(x=>x.textContent=version);
    const checked=document.querySelectorAll('#maintAgentPcGrid .dmd-maint-pc-target:checked:not(:disabled)').length;
    const count=document.getElementById('r19AgentTargetCount');if(count)count.textContent=String(checked);
    const run=document.getElementById('maintAgentUpdateRunState');
    const state=document.getElementById('r19AgentDeployState');if(state&&run)state.textContent=(run.textContent||'Prêt').replace(/\.$/,'');
}
document.getElementById('maintAgentVersionSelect')?.addEventListener('change',r19SyncUpdateSummary);
document.getElementById('maintAgentPcGrid')?.addEventListener('change',r19SyncUpdateSummary);
document.getElementById('maintAgentAllPc')?.addEventListener('change',()=>setTimeout(r19SyncUpdateSummary,0));
const r19VersionSelect=document.getElementById('maintAgentVersionSelect');
if(r19VersionSelect)new MutationObserver(r19SyncUpdateSummary).observe(r19VersionSelect,{childList:true,subtree:true,attributes:true});
const r19RunState=document.getElementById('maintAgentUpdateRunState');
if(r19RunState)new MutationObserver(r19SyncUpdateSummary).observe(r19RunState,{childList:true,subtree:true,characterData:true});
r19SyncUpdateSummary();
