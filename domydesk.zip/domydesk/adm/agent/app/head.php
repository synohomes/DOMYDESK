<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-Agent</title>
<link rel="stylesheet" href="../../theme/<?= dmd_agent_h($theme) ?>/style.css">
<link rel="stylesheet" href="assets/index.css?v=45">
<link rel="stylesheet" href="assets/admin-close.css?v=45">
<link rel="stylesheet" href="assets/admin-open.css?v=45">
<link rel="stylesheet" href="assets/agent-update-pdf.css?v=45">
<link rel="stylesheet" href="assets/agent-update.css?v=45">
<link rel="stylesheet" href="assets/audit.css?v=45">
<link rel="stylesheet" href="assets/audits.css?v=45">
<link rel="stylesheet" href="assets/backup.css?v=45">
<link rel="stylesheet" href="assets/bootstrap.css?v=45">
<link rel="stylesheet" href="assets/create.css?v=45">
<link rel="stylesheet" href="assets/device.css?v=45">
<link rel="stylesheet" href="assets/enrollments.css?v=45">
<link rel="stylesheet" href="assets/feature.css?v=45">
<link rel="stylesheet" href="assets/fleet.css?v=45">
<link rel="stylesheet" href="assets/footer.css?v=45">
<link rel="stylesheet" href="assets/head.css?v=45">
<link rel="stylesheet" href="assets/licenses.css?v=45">
<link rel="stylesheet" href="assets/main-close.css?v=45">
<link rel="stylesheet" href="assets/mydesk-maint.css?v=45">
<link rel="stylesheet" href="assets/mydesk.css?v=45">
<link rel="stylesheet" href="assets/network-scan.css?v=45">
<link rel="stylesheet" href="assets/pc-groups.css?v=45">
<link rel="stylesheet" href="assets/pc-update.css?v=45">
<link rel="stylesheet" href="assets/rights.css?v=45">
<link rel="stylesheet" href="assets/security.css?v=45">
<link rel="stylesheet" href="assets/shell-open.css?v=45">
<link rel="stylesheet" href="assets/software-bulk.css?v=45">
<link rel="stylesheet" href="assets/software-updates.css?v=45">
<link rel="stylesheet" href="assets/software.css?v=45">
<link rel="stylesheet" href="assets/terminal.css?v=45">
<link rel="stylesheet" href="assets/tools-rail.css?v=45">
<link rel="stylesheet" href="assets/user-groups.css?v=45">
<style>
:root{
    --dmd-agent-ui-scale: <?= dmd_agent_h(number_format($uiScaleFactor, 3, '.', '')) ?>;
    --dmd-agent-ui-scale-width: <?= dmd_agent_h(number_format($uiScaleWidth, 4, '.', '')) ?>%;
}
</style>
</head>
<body>
<?php include $baseDir . '/header.php'; ?>
<main class="dmd-agent-page dmd-r37-page">
