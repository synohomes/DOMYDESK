<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
$identity = dmd_agent_ensure_instance_identity();
$enrollments = dmd_agent_list_enrollments();
$devices = dmd_agent_list_devices();
// Le hostname réel remonté par l'Agent est la source de vérité.
// Le hostname enregistré lors de l'enrôlement reste uniquement une donnée historique/alias.
foreach ($devices as &$dmdAgentDeviceRef) {
    if (!is_array($dmdAgentDeviceRef)) continue;
    $dmdAgentInv = isset($dmdAgentDeviceRef['last_inventory']) && is_array($dmdAgentDeviceRef['last_inventory']) ? $dmdAgentDeviceRef['last_inventory'] : array();
    $dmdAgentReportedHostname = trim((string)($dmdAgentInv['hostname'] ?? ''));
    if ($dmdAgentReportedHostname !== '' && strlen($dmdAgentReportedHostname) <= 255 && !preg_match('/[\x00-\x1F\x7F]/', $dmdAgentReportedHostname)) {
        $dmdAgentDeviceRef['hostname'] = $dmdAgentReportedHostname;
    }
}
unset($dmdAgentDeviceRef);
$pcGroupsData = dmd_agent_access_read_pc_groups();
$userGroupsData = dmd_agent_access_read_user_groups();
$policiesData = dmd_agent_access_read_policies();
$domydeskUsers = dmd_agent_access_known_users();
$agentAudits = dmd_agent_list_audits();
$remotePermissionCatalog = dmd_agent_remote_permissions_catalog();
$remoteNoticeSettings = dmd_agent_remote_notice_settings_read();
$myDeskModules = dmd_agent_mydesk_manifest_modules();
$myDeskSettings = dmd_agent_mydesk_settings_read();
$licenseStatus = function_exists('dmd_license_status') ? dmd_license_status() : array('ok'=>true,'source'=>'launch','state'=>'launch','entitlements'=>array());
$myDeskLimit = dmd_agent_mydesk_license_limit();
$myDeskSelectedCount = dmd_agent_mydesk_selected_count($myDeskSettings);
$myDeskEntitlement = isset($licenseStatus['entitlements']['dmd_mydesk']) && is_array($licenseStatus['entitlements']['dmd_mydesk']) ? $licenseStatus['entitlements']['dmd_mydesk'] : array();
$myDeskLicensed = !empty($myDeskEntitlement['enabled']) && ($myDeskLimit < 0 || $myDeskLimit > 0);
$remoteLimit = dmd_agent_remote_license_limit();
$remoteActiveUsage = function_exists('dmd_agent_remote_active_usage') ? dmd_agent_remote_active_usage() : dmd_agent_remote_license_usage();
$remoteReservedUsage = function_exists('dmd_agent_remote_pending_reservations') ? dmd_agent_remote_pending_reservations() : 0;
$remoteUsage = dmd_agent_remote_license_usage(); // actif + réservations : enforcement quota
$remoteCanEnroll = ($remoteLimit < 0 || $remoteUsage < $remoteLimit);
$instancesEntitlement = isset($licenseStatus['entitlements']['dmd_instances']) && is_array($licenseStatus['entitlements']['dmd_instances']) ? $licenseStatus['entitlements']['dmd_instances'] : array();
$instancesLimit = isset($instancesEntitlement['instances_max']) ? (int)$instancesEntitlement['instances_max'] : 1;
$instancesUsage = function_exists('dmd_instances_linked_count') ? max(0, (int)dmd_instances_linked_count()) : 0;
$licenseLaunchLocked = time() < strtotime(DMD_LICENSE_LAUNCH_UNTIL);
$licenseQuotaText = function($v){ return ((int)$v < 0) ? '∞' : (string)(int)$v; };
$theme = 'default';
$themeFile = $baseDir . '/users/profiles/' . $email . '/theme.json';
$themeData = dmd_sys_json_read($themeFile, array());
if (!empty($themeData['theme']) && is_file($baseDir . '/theme/' . basename($themeData['theme']) . '/style.css')) $theme = basename($themeData['theme']);

/* Zoom utilisateur configuré dans Profil > Thème. */
$uiScale = 100;
if (isset($themeData['ui_scale']) && is_numeric($themeData['ui_scale'])) {
    $uiScale = max(60, min(150, (int)$themeData['ui_scale']));
}
$uiScaleFactor = $uiScale / 100;
$uiScaleWidth = 100 / $uiScaleFactor;

function dmd_agent_h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function dmd_agent_status_label($s){$map=array('created'=>'Créé','challenge'=>'Challenge envoyé','pending_approval'=>'Validation requise','approved'=>'Approuvé','completed'=>'Terminé','expired'=>'Expiré','rejected'=>'Refusé','active'=>'Actif','revoked'=>'Révoqué');return isset($map[$s])?$map[$s]:$s;}
function dmd_agent_platform_label($platform,$arch){
    $p=strtolower((string)$platform);
    if($p==='windows') $name='Windows'; elseif($p==='linux') $name='Linux'; elseif($p==='darwin') $name='macOS'; else $name=$platform?:'Système inconnu';
    return trim($name . ($arch ? ' · '.$arch : ''));
}
function dmd_agent_platform_group($platform){
    $p=strtolower(trim((string)$platform));
    if($p==='windows' || $p==='win32' || $p==='win64') return 'windows';
    if($p==='linux') return 'linux';
    if($p==='darwin' || $p==='macos' || $p==='mac' || $p==='osx') return 'macos';
    return 'other';
}
function dmd_agent_device_os_label($device){
    $inv=isset($device['last_inventory'])&&is_array($device['last_inventory'])?$device['last_inventory']:array();
    $name=trim((string)($inv['os_name']??''));
    if($name===''){
        $os=isset($inv['os'])&&is_array($inv['os'])?$inv['os']:array();
        $name=trim((string)($os['name']??''));
    }
    if($name==='') $name=dmd_agent_platform_label($device['platform']??'', '');
    $version=trim((string)($inv['os_version']??''));
    if($version!=='' && stripos($name,$version)===false) $name=trim($name.' · '.$version);
    return $name;
}
function dmd_agent_device_enrollment_name($device,$enrollments){
    // Le noyau serveur connaît maintenant la vraie source persistante
    // et sait récupérer les anciennes valeurs dans les logs de sécurité.
    if(function_exists('dmd_agent_enrollment_name_for_device')){
        $value=trim((string)dmd_agent_enrollment_name_for_device($device));
        if($value!=='') return $value;
    }

    // Fallback local si ce fichier est copié sans agent_core mis à jour.
    foreach(array('enrollment_name','enrollment_target_name','target_name') as $key){
        $value=trim((string)($device[$key]??''));
        if($value!=='') return $value;
    }
    $enrollmentId=trim((string)($device['enrollment_id']??''));
    if($enrollmentId!==''){
        foreach((array)$enrollments as $enrollment){
            if(!is_array($enrollment)) continue;
            if((string)($enrollment['enrollment_id']??'')!==$enrollmentId) continue;
            $value=trim((string)($enrollment['target_name']??''));
            if($value!=='') return $value;
        }
    }
    return 'Non disponible';
}
function dmd_agent_device_group_names($agentId,$pcGroupsData){
    $out=array();
    foreach((array)($pcGroupsData['groups']??array()) as $group){
        if(!is_array($group)) continue;
        if(in_array((string)$agentId,(array)($group['agent_ids']??array()),true)) $out[]=trim((string)($group['name']??''));
    }
    return array_values(array_filter(array_unique($out),function($v){return $v!=='';}));
}
function dmd_agent_cap_enabled($d,$cap){
    $caps=array_unique(array_merge(isset($d['capabilities'])&&is_array($d['capabilities'])?$d['capabilities']:array(),isset($d['reported_capabilities'])&&is_array($d['reported_capabilities'])?$d['reported_capabilities']:array()));
    return in_array($cap,$caps,true);
}
$now=time();
$onlineCount=0;$pendingCount=0;$activeCount=0;
foreach($devices as $d){
    if(($d['status']??'')==='active') $activeCount++;
    $lastTs=isset($d['last_seen_ts'])?(int)$d['last_seen_ts']:0;
    if(($d['status']??'')==='active' && $lastTs>0 && ($now-$lastTs)<90) $onlineCount++;
}
$expiredCount=0;
foreach($enrollments as $e){
    $st=(string)($e['status']??'');
    if($st==='pending_approval') $pendingCount++;
    if($st==='expired') $expiredCount++;
}
$deviceGroups=array(
    'windows'=>array('label'=>'Microsoft / Windows','devices'=>array()),
    'linux'=>array('label'=>'Linux','devices'=>array()),
    'macos'=>array('label'=>'macOS','devices'=>array()),
    'other'=>array('label'=>'Autres systèmes','devices'=>array()),
);
foreach($devices as $device){
    $group=dmd_agent_platform_group($device['platform']??'');
    $deviceGroups[$group]['devices'][]=$device;
}
$deviceJson=json_encode($devices,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$pcGroupsJson=json_encode(array_values($pcGroupsData['groups']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$userGroupsJson=json_encode(array_values($userGroupsData['groups']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$policiesJson=json_encode(array_values($policiesData['policies']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$usersJson=json_encode($domydeskUsers,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
$auditsJson=json_encode($agentAudits,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
?>
