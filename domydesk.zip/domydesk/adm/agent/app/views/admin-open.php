            <section id="workspace-administration" class="dmd-agent-workspace-view dmd-pro-page" data-workspace-pane="administration" hidden>
                <div class="dmd-agent-workspace-head admin dmd-pro-page-head">
                    <div><h2 id="workspaceAdminTitle">Administration</h2><p id="workspaceAdminSubtitle"></p></div>
                </div>
                <div class="dmd-agent-workspace-admin-content">
