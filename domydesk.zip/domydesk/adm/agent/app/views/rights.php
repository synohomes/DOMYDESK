<section class="dmd-agent-admin-pane dmd-rights-page" data-admin-pane="rights" hidden>
    <div class="dmd-rights-shell">

        <aside class="dmd-rights-rules-card">
            <div class="dmd-rights-card-head">
                <div>
                    <h3>Règles existantes</h3>
                    <p>Accès attribués aux utilisateurs et aux groupes.</p>
                </div>
                <button type="button" class="dmd-agent-mini-btn dmd-rights-new-btn" id="newPolicy">＋ Nouvelle règle</button>
            </div>

            <label class="dmd-rights-search">
                <span aria-hidden="true">⌕</span>
                <input id="policySearch" type="search" placeholder="Rechercher une règle…" autocomplete="off">
            </label>

            <div id="policyList" class="dmd-rights-policy-list"></div>
        </aside>

        <form id="policyForm" class="dmd-rights-editor">
            <input type="hidden" name="policy_id" value="">

            <header class="dmd-rights-editor-head">
                <div class="dmd-rights-editor-title">
                    <span class="dmd-rights-title-icon" aria-hidden="true">＋</span>
                    <div>
                        <h3 id="policyEditorTitle">Nouvelle règle</h3>
                        <p>Choisis les bénéficiaires, les postes concernés et les actions autorisées.</p>
                    </div>
                </div>

                <div class="dmd-rights-editor-actions top">
                    <button type="button" id="resetPolicy" class="dmd-agent-btn">Réinitialiser</button>
                    <button type="submit" class="dmd-agent-btn primary">Enregistrer la règle</button>
                    <button type="button" id="deletePolicy" class="dmd-agent-btn danger" hidden>Supprimer</button>
                </div>
            </header>

            <section class="dmd-rights-step">
                <div class="dmd-rights-step-title">
                    <span class="dmd-rights-step-number">1</span>
                    <div>
                        <h4>Bénéficiaires</h4>
                        <p>Définis à qui cette règle s’applique.</p>
                    </div>
                </div>

                <div class="dmd-rights-form-row">
                    <label>
                        <span>Type</span>
                        <select name="subject_type">
                            <option value="user_group">Groupe utilisateurs</option>
                            <option value="user">Utilisateur</option>
                        </select>
                    </label>

                    <label class="policy-subject policy-subject-group">
                        <span>Groupe</span>
                        <select name="subject_group_id"></select>
                    </label>

                    <label class="policy-subject policy-subject-user" hidden>
                        <span>Utilisateur</span>
                        <select name="subject_user_id">
                            <?php foreach($domydeskUsers as $u): ?>
                                <option value="<?= dmd_agent_h($u['email']) ?>"><?= dmd_agent_h($u['email']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </div>
            </section>

            <section class="dmd-rights-step">
                <div class="dmd-rights-step-title">
                    <span class="dmd-rights-step-number">2</span>
                    <div>
                        <h4>Périmètre</h4>
                        <p>Sélectionne les postes concernés par cette règle.</p>
                    </div>
                </div>

                <div class="dmd-rights-scope-mode">
                    <label class="dmd-rights-scope-choice all-pcs-choice">
                        <input type="checkbox" name="all_pcs" value="1">
                        <span class="choice-icon">▣</span>
                        <span class="choice-copy">
                            <strong>Tous les PC</strong>
                            <small>La règle s’applique à tout le parc.</small>
                        </span>
                        <span class="choice-state">○</span>
                    </label>

                    <button type="button" class="dmd-rights-scope-choice" data-scope-focus="groups">
                        <span class="choice-icon">▦</span>
                        <span class="choice-copy">
                            <strong>Groupes de PC</strong>
                            <small>Sélection par groupe.</small>
                        </span>
                        <span class="choice-state">○</span>
                    </button>

                    <button type="button" class="dmd-rights-scope-choice" data-scope-focus="devices">
                        <span class="choice-icon">▣</span>
                        <span class="choice-copy">
                            <strong>PC particuliers</strong>
                            <small>Sélection poste par poste.</small>
                        </span>
                        <span class="choice-state">○</span>
                    </button>
                </div>

                <div class="dmd-rights-scope-columns">
                    <div class="dmd-rights-scope-panel" data-scope-panel="groups">
                        <div class="dmd-rights-scope-panel-head">
                            <strong>Groupes de PC</strong>
                            <small>Sélection multiple</small>
                        </div>
                        <div id="policyPcGroups" class="dmd-rights-check-grid"></div>
                    </div>

                    <div class="dmd-rights-scope-panel" data-scope-panel="devices">
                        <div class="dmd-rights-scope-panel-head">
                            <strong>PC particuliers</strong>
                            <small>Sélection multiple</small>
                        </div>

                        <div class="dmd-rights-check-grid">
                            <?php foreach($devices as $d): ?>
                                <label>
                                    <input type="checkbox" name="policy_agent_ids[]" value="<?= dmd_agent_h($d['agent_id']??'') ?>">
                                    <span>
                                        <strong><?= dmd_agent_h($d['hostname']??'PC') ?></strong>
                                        <small><?= dmd_agent_h($d['last_ip']??'') ?></small>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </section>

            <section class="dmd-rights-step actions-step">
                <div class="dmd-rights-step-title with-control">
                    <span class="dmd-rights-step-number">3</span>
                    <div>
                        <h4>Actions autorisées</h4>
                        <p>Coche uniquement les fonctions réellement nécessaires.</p>
                    </div>
                    <label class="dmd-rights-select-all">
                        <input type="checkbox" id="policySelectAllPermissions">
                        <span>Tout sélectionner</span>
                    </label>
                </div>

                <div class="dmd-rights-permission-sections">
                    <?php
                    $rightsIcons = array(
                        'remote' => '▣',
                        'files' => '▰',
                        'software' => '◆',
                        'registry' => '⬡',
                        'devices' => '⌘',
                        'network' => '⌁',
                        'backup' => '▤',
                        'system' => '⚙'
                    );
                    foreach($remotePermissionCatalog as $sectionKey=>$section):
                        $sectionIcon = $rightsIcons[$sectionKey] ?? '•';
                    ?>
                        <fieldset data-permission-section="<?= dmd_agent_h($sectionKey) ?>">
                            <legend>
                                <span class="dmd-rights-section-icon" aria-hidden="true"><?= dmd_agent_h($sectionIcon) ?></span>
                                <span><?= dmd_agent_h($section['label']) ?></span>
                            </legend>

                            <div class="dmd-rights-permission-list">
                                <?php foreach($section['permissions'] as $perm=>$meta): ?>
                                    <label>
                                        <input type="checkbox" name="permissions[]" value="<?= dmd_agent_h($perm) ?>">
                                        <span><?= dmd_agent_h($meta['label']) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </fieldset>
                    <?php endforeach; ?>
                </div>
            </section>
        </form>
    </div>
</section>
