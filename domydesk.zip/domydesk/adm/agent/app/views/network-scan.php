        <section class="dmd-agent-admin-pane" data-admin-pane="network-scan" hidden>
            <div class="dmd-agent-maint-compact-page scan dmd-r27-operation">
                <section class="dmd-agent-maint-config-card dmd-agent-maint-primary-card">
                    <div class="dmd-agent-admin-card-head"><div><h3>Paramètres du scan</h3><p>Choisis un poste pour analyser son réseau local.</p></div><span class="dmd-agent-protected-pill">IPv4 local</span></div>
                    <div class="dmd-agent-maint-topline">
                        <label class="dmd-agent-maint-select">PC sonde
                            <select id="scanWorkspaceAgent">
                                <option value="">Choisir un PC avec Agent…</option>
                                <?php foreach($devices as $d):
                                    $scanLast=(int)($d['last_seen_ts']??0);
                                    $active=(($d['status']??'')!=='revoked' && $scanLast>0 && ($now-$scanLast)<180);
                                ?>
                                    <option value="<?= dmd_agent_h($d['agent_id']??'') ?>" <?= !$active?'disabled':'' ?>><?= dmd_agent_h($d['hostname']??'PC') ?><?= $active?'':' — hors ligne' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <div id="scanWorkspacePcState" class="dmd-agent-maint-inline-state">Sélectionne le PC qui servira de sonde.</div>
                    </div>
                    <div class="dmd-agent-maint-scan-row">
                        <div class="dmd-agent-maint-block compact network">
                            <div class="dmd-agent-maint-block-head"><div><strong>Réseau à scanner</strong><small>Réseau détecté automatiquement depuis le poste sélectionné.</small></div><button type="button" class="dmd-agent-btn" id="scanWorkspaceDetect" disabled>Redétecter</button></div>
                            <div id="scanDetectedNetworks" class="dmd-agent-maint-network-list"><span class="dmd-agent-muted">Aucun réseau détecté.</span></div>
                        </div>
                        <div class="dmd-agent-maint-scan-options">
                            <label>Profil<select id="scanWorkspaceProfile"><option value="standard">Standard</option><option value="light">Rapide</option><option value="extended">Étendu</option></select></label>
                            <label class="check"><input id="scanWorkspaceResolve" type="checkbox" checked><span>Résoudre les noms</span></label>
                            <div class="dmd-agent-editor-actions"><button type="button" class="dmd-agent-btn primary" id="scanWorkspaceRun" disabled>Lancer le scan</button><button type="button" class="dmd-agent-btn danger" id="scanWorkspaceStop" disabled>Arrêter</button><button type="button" class="dmd-agent-btn" id="scanWorkspaceRefresh" disabled>Actualiser</button></div>
                        </div>
                    </div>
                </section>

                <section class="dmd-agent-maint-config-card dmd-agent-maint-status-card">
                    <div class="dmd-agent-admin-card-head"><div><h3>Résultats</h3><p>IP, nom, MAC et ports détectés par le PC sonde.</p></div><div class="dmd-agent-scan-result-actions"><button type="button" class="dmd-agent-mini-btn" id="scanWorkspaceExportPdf" disabled>Exporter PDF</button><span id="scanWorkspaceStatusState" class="dmd-agent-maint-state-pill">—</span></div></div>
                    <div id="scanWorkspaceStatus"><div class="dmd-agent-admin-empty">Aucun PC sélectionné.</div></div>
                </section>
            </div>
            <div id="scanPdfModal" class="dmd-agent-submodal" hidden>
                <div class="dmd-agent-submodal-dialog dmd-agent-scan-pdf-modal" role="dialog" aria-modal="true" aria-labelledby="scanPdfModalTitle">
                    <div class="dmd-agent-submodal-head"><div><h3 id="scanPdfModalTitle">Export PDF du scan réseau</h3><p>Aperçu généré sans quitter DoMyDesk.</p></div><div class="dmd-agent-scan-pdf-actions"><button type="button" class="dmd-agent-mini-btn primary" id="scanPdfDownload">Télécharger</button><button type="button" class="dmd-agent-mini-btn" id="scanPdfClose">Fermer</button></div></div>
                    <iframe id="scanPdfFrame" class="dmd-agent-scan-pdf-frame" title="Aperçu PDF du scan réseau"></iframe>
                </div>
            </div>
        </section>

