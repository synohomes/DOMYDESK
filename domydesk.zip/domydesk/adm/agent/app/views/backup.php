        <section class="dmd-agent-admin-pane" data-admin-pane="backup" hidden>
            <div class="dmd-agent-maint-compact-page dmd-backup-pro-page dmd-r27-operation">
                <section class="dmd-agent-maint-config-card dmd-agent-maint-primary-card">
                    <div class="dmd-agent-admin-card-head">
                        <div><h3>Politique de sauvegarde</h3><p>Sélectionne les postes, les données et la destination de sauvegarde.</p></div>
                        <span class="dmd-agent-protected-pill">Multi-PC</span>
                    </div>

                    <div class="dmd-backup-section">
                        <div class="dmd-backup-section-head">
                            <div><strong>PC concernés</strong><small>Sélectionne un ou plusieurs postes en ligne.</small></div>
                            <div class="dmd-backup-inline-actions">
                                <select id="backupSelectGroup" class="dmd-backup-group-select" title="Sélectionner les PC d’un groupe">
                                    <option value="">Groupe…</option>
                                    <?php foreach((array)($pcGroupsData['groups']??array()) as $bg): if(!is_array($bg))continue; ?>
                                        <option value="<?= dmd_agent_h($bg['group_id']??'') ?>"><?= dmd_agent_h($bg['name']??'Groupe') ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <label class="dmd-backup-checkall"><input type="checkbox" id="backupAllAgents"> Tous en ligne</label>
                                <span id="backupAgentCount" class="dmd-agent-maint-state-pill">0 PC</span>
                            </div>
                        </div>
                        <div id="backupAgentGrid" class="dmd-backup-pc-grid">
                            <?php foreach($devices as $d):
                                $aid=(string)($d['agent_id']??'');
                                $hn=(string)($d['hostname']??'PC');
                                $dip=(string)($d['last_ip']??'IP inconnue');
                                $dst=(string)($d['status']??'');
                                $last=(int)($d['last_seen_ts']??0);
                                $isOnline=($dst!=='revoked' && $last>0 && ($now-$last)<120);
                                $groups=dmd_agent_device_group_names($aid,$pcGroupsData);
                                $groupText=$groups?implode(', ',$groups):'Aucun groupe';
                            ?>
                            <label class="dmd-backup-pc <?= $isOnline?'is-online':'is-offline' ?>">
                                <input class="dmd-backup-pc-target" type="checkbox" value="<?= dmd_agent_h($aid) ?>" <?= $isOnline?'':'disabled' ?>>
                                <span><strong><?= dmd_agent_h($hn) ?></strong><small><?= dmd_agent_h($dip) ?> · <?= dmd_agent_h($groupText) ?></small></span>
                                <i title="<?= $isOnline?'En ligne':'Hors ligne' ?>"></i>
                            </label>
                            <?php endforeach; ?>
                        </div>
                        <div id="backupWorkspacePcState" class="dmd-agent-maint-inline-state compact">Sélectionne un ou plusieurs PC.</div>
                    </div>

                    <section class="dmd-backup-provider-section" aria-labelledby="backupProviderTitle">
                        <div class="dmd-backup-provider-head">
                            <div>
                                <strong id="backupProviderTitle">Moteurs de sauvegarde détectés</strong>
                                <small>Analyse les solutions de sauvegarde disponibles sur les postes sélectionnés.</small>
                            </div>
                            <div class="dmd-backup-provider-actions">
                                <span id="backupProviderCount" class="dmd-agent-maint-state-pill">Non analysé</span>
                                <button type="button" class="dmd-agent-mini-btn primary" id="backupProviderDetect" disabled>Détecter</button>
                            </div>
                        </div>
                        <div id="backupProviderResults" class="dmd-backup-provider-results">
                            <div class="dmd-agent-admin-empty">Sélectionne un ou plusieurs PC puis lance la détection.</div>
                        </div>
                    </section>

                    <section class="dmd-backup-image-section" aria-labelledby="backupImageTitle">
                        <div class="dmd-backup-provider-head">
                            <div>
                                <strong id="backupImageTitle">Image système complète / restauration Bare Metal</strong>
                                <small>Crée une image système restaurable du poste, indépendamment du logiciel de sauvegarde installé.</small>
                            </div>
                            <div class="dmd-backup-provider-actions">
                                <span id="backupImageCount" class="dmd-agent-maint-state-pill">Non analysé</span>
                                <button type="button" class="dmd-agent-mini-btn primary" id="backupImageDetect" disabled>Analyser les disques</button>
                            </div>
                        </div>
                        <div id="backupImageTargetHint" class="dmd-backup-image-target-hint">Choisis une cible NAS/SMB ou un disque/USB avant de lancer une image système.</div>
                        <div id="backupImageResults" class="dmd-backup-image-results">
                            <div class="dmd-agent-admin-empty">Sélectionne un ou plusieurs PC puis analyse les disques.</div>
                        </div>
                    </section>

                    <div class="dmd-agent-maint-two-blocks dmd-backup-main-grid">
                        <div class="dmd-agent-maint-block compact">
                            <div class="dmd-agent-maint-block-head">
                                <div><strong>Données à sauvegarder</strong><small>Choisis les dossiers utilisateur à inclure.</small></div>
                                <button type="button" class="dmd-agent-mini-btn" id="backupChooseSources" disabled>Avancé</button>
                            </div>
                            <div class="dmd-backup-presets" id="backupPresetGrid">
                                <label><input type="checkbox" data-backup-preset="profiles.desktop" checked><span>Bureaux</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.documents" checked><span>Documents</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.pictures" checked><span>Images</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.videos"><span>Vidéos</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.music"><span>Musique</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.downloads"><span>Téléchargements</span></label>
                                <label><input type="checkbox" data-backup-preset="profiles.onedrive"><span>OneDrive</span></label>
                                <label><input type="checkbox" data-backup-preset="public.all"><span>Public</span></label>
                                <label class="wide"><input type="checkbox" data-backup-preset="profiles.all"><span>Profils utilisateurs complets</span></label>
                            </div>
                            <div id="backupSelectedSources" class="dmd-agent-maint-selection-list"><span class="dmd-agent-muted">Aucun chemin avancé sélectionné.</span></div>
                        </div>

                        <div class="dmd-agent-maint-block compact">
                            <div class="dmd-agent-maint-block-head">
                                <div><strong>Cible de sauvegarde</strong><small>NAS/SMB, serveur DATA, disque/USB ou cloud WebDAV.</small></div>
                                <button type="button" class="dmd-agent-mini-btn" id="backupManageTargets" disabled>Gérer</button>
                            </div>
                            <select id="backupTargetSelect" class="dmd-agent-maint-target-select" disabled><option value="">Sélectionne d’abord des PC</option></select>
                            <div id="backupSelectedDestination" class="dmd-agent-maint-destination"><span>Aucune cible sélectionnée.</span></div>
                            <div class="dmd-agent-maint-target-actions">
                                <button type="button" class="dmd-agent-mini-btn" id="backupTestTarget" disabled>Tester sur les PC</button>
                                <span id="backupTargetTestState" class="dmd-agent-muted"></span>
                            </div>
                        </div>
                    </div>

                    <div class="dmd-agent-maint-footer-row dmd-backup-footer">
                        <label class="dmd-backup-retention">Rétention
                            <span class="dmd-backup-retention-control"><input id="backupRetentionCount" type="number" min="1" max="100" step="1" value="5"><small>sauvegardes / PC</small></span>
                        </label>
                        <label class="check"><input id="backupExcludeTemp" type="checkbox" checked><span>Exclure temporaires/caches</span></label>
                        <div class="dmd-agent-editor-actions">
                            <button type="button" class="dmd-agent-btn primary" id="backupWorkspaceRun" disabled>Lancer sur les PC sélectionnés</button>
                            <button type="button" class="dmd-agent-btn danger" id="backupWorkspaceStop" disabled>Arrêter les sauvegardes</button>
                            <button type="button" class="dmd-agent-btn" id="backupWorkspaceRefresh" disabled>Actualiser</button>
                        </div>
                    </div>
                </section>

                <section class="dmd-agent-maint-config-card dmd-agent-maint-status-card">
                    <div class="dmd-agent-admin-card-head"><div><h3>État des sauvegardes</h3><p>Résultat PC par PC, avec le job Agent correspondant.</p></div><span id="backupWorkspaceStatusState" class="dmd-agent-maint-state-pill">—</span></div>
                    <div id="backupWorkspaceStatus"><div class="dmd-agent-admin-empty">Aucun PC sélectionné.</div></div>
                </section>
            </div>

            <div id="backupTargetModal" class="dmd-agent-submodal" hidden>
                <div class="dmd-agent-submodal-dialog dmd-backup-target-modal" role="dialog" aria-modal="true" aria-labelledby="backupTargetModalTitle">
                    <div class="dmd-agent-submodal-head">
                        <div><h3 id="backupTargetModalTitle">Cibles de sauvegarde</h3><p>Une cible peut être déployée en une fois sur tous les PC sélectionnés. Les mots de passe sont ensuite protégés par DPAPI sur chaque Agent.</p></div>
                        <button type="button" class="dmd-agent-mini-btn" id="backupTargetModalClose">Fermer</button>
                    </div>
                    <div class="dmd-agent-submodal-toolbar">
                        <button type="button" class="dmd-agent-mini-btn primary" id="backupNewTarget" disabled>+ Nouvelle cible</button>
                        <span id="backupTargetSaveState" class="dmd-agent-muted"></span>
                    </div>
                    <div id="backupTargetList" class="dmd-agent-backup-target-list"><div class="dmd-agent-admin-empty">Sélectionne au moins un PC.</div></div>

                    <form id="backupTargetForm" class="dmd-agent-backup-target-form dmd-backup-target-form-pro" hidden autocomplete="off">
                        <input type="hidden" id="backupTargetId" value="">
                        <div class="dmd-backup-target-top">
                            <label>Nom<input id="backupTargetName" maxlength="80" value="Sauvegarde principale"></label>
                            <label>Type<select id="backupTargetType"><option value="smb">NAS / serveur SMB</option><option value="webdav">Cloud WebDAV</option><option value="local">Disque local / USB</option></select></label>
                        </div>

                        <div id="backupTargetFieldsSmb" class="dmd-backup-target-fields-pro">
                            <label>Serveur / NAS<input id="backupTargetServer" placeholder="NAS-BACKUP ou 192.168.1.111"></label>
                            <label>Compte<input id="backupTargetUsername" autocomplete="username" placeholder="DOMAINE\backup ou backup"></label>
                            <label>Mot de passe<input id="backupTargetPassword" type="password" autocomplete="new-password" placeholder="Mot de passe"></label>
                            <div class="dmd-backup-discover-row">
                                <button type="button" class="dmd-agent-mini-btn primary" id="backupSmbDiscover">Découvrir les partages</button>
                                <span id="backupSmbDiscoveryState" class="dmd-agent-muted">Le scan SMB est exécuté depuis le premier PC sélectionné.</span>
                            </div>
                            <div id="backupSmbDiscovery" class="dmd-backup-smb-browser"><div class="dmd-agent-admin-empty">Renseigne le serveur et les identifiants, puis clique sur « Découvrir les partages ».</div></div>
                            <div class="dmd-backup-selected-path">
                                <label>Partage<input id="backupTargetShare" readonly placeholder="Choisi automatiquement"></label>
                                <label>Sous-dossier<input id="backupTargetFolder" readonly placeholder="Racine du partage"></label>
                            </div>
                        </div>

                        <div id="backupTargetFieldsLocal" class="dmd-backup-target-fields-pro" hidden>
                            <label>Dossier local / USB<div class="dmd-agent-target-path-line"><input id="backupTargetLocalPath" readonly placeholder="Sélectionner depuis le PC"><button type="button" class="dmd-agent-mini-btn" id="backupTargetBrowseLocal">Parcourir</button></div></label>
                            <small class="dmd-agent-muted">Le chemin est choisi sur le PC de référence puis déployé aux PC sélectionnés. Chaque Agent utilise ce chemin s’il existe sur son poste.</small>
                        </div>

                        <div id="backupTargetFieldsWebdav" class="dmd-backup-target-fields-pro" hidden>
                            <label class="wide">URL WebDAV<input id="backupTargetWebdavUrl" placeholder="https://cloud.exemple.tld/remote.php/dav/files/..."></label>
                            <label>Sous-dossier<input id="backupTargetWebdavFolder" placeholder="DoMyDesk"></label>
                            <label>Compte<input id="backupTargetWebdavUsername" autocomplete="username"></label>
                            <label>Mot de passe / mot de passe d’application<input id="backupTargetWebdavPassword" type="password" autocomplete="new-password"></label>
                        </div>

                        <div id="backupTargetFormState" class="dmd-agent-maint-inline-state compact" hidden></div>
                        <div class="dmd-backup-target-foot">
                            <span id="backupTargetDeployCount">0 PC sélectionné</span>
                            <div>
                                <button type="button" class="dmd-agent-mini-btn primary" id="backupTargetSave">Enregistrer / déployer</button>
                                <button type="button" class="dmd-agent-mini-btn" id="backupTargetFormTest">Déployer et tester</button>
                                <button type="button" class="dmd-agent-mini-btn danger" id="backupTargetDelete" hidden>Supprimer</button>
                                <button type="button" class="dmd-agent-mini-btn" id="backupTargetCancel">Annuler</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div id="backupBrowserModal" class="dmd-agent-submodal" hidden>
                <div class="dmd-agent-submodal-dialog browser" role="dialog" aria-modal="true" aria-labelledby="backupBrowserTitle">
                    <div class="dmd-agent-submodal-head"><div><h3 id="backupBrowserTitle">Sélection avancée</h3><p id="backupBrowserHint">Le premier PC sélectionné sert de référence ; les chemins choisis sont ensuite appliqués à tous les PC sélectionnés.</p></div><button type="button" class="dmd-agent-mini-btn" id="backupBrowserClose">Fermer</button></div>
                    <div id="backupBrowser" class="dmd-agent-backup-browser compact"><div class="dmd-agent-admin-empty">Sélectionne un seul PC.</div></div>
                </div>
            </div>

            <div id="backupProviderConfigModal" class="dmd-agent-submodal" hidden>
                <div class="dmd-agent-submodal-dialog dmd-backup-provider-config-modal" role="dialog" aria-modal="true" aria-labelledby="backupProviderConfigTitle">
                    <div class="dmd-agent-submodal-head">
                        <div>
                            <h3 id="backupProviderConfigTitle">Configuration du moteur de sauvegarde</h3>
                            <p id="backupProviderConfigSub">Charge et applique la configuration directement sur le PC distant.</p>
                        </div>
                        <button type="button" class="dmd-agent-mini-btn" id="backupProviderConfigClose">Fermer</button>
                    </div>
                    <input type="hidden" id="backupProviderConfigAgent" value="">
                    <input type="hidden" id="backupProviderConfigProvider" value="">

                    <div class="dmd-backup-provider-config-grid">
                        <section class="dmd-agent-maint-block compact">
                            <div class="dmd-agent-maint-block-head">
                                <div><strong>Configuration Veeam Agent</strong><small>La configuration est exportée depuis Veeam Agent, modifiable ici puis réimportée sans intervention locale sur le poste.</small></div>
                                <button type="button" class="dmd-agent-mini-btn" id="backupProviderConfigReload">Recharger</button>
                            </div>
                            <div id="backupProviderConfigJobs" class="dmd-backup-provider-config-jobs"><span class="dmd-agent-muted">Chargement…</span></div>
                            <label class="dmd-backup-provider-config-xml">Configuration XML
                                <textarea id="backupProviderConfigXml" spellcheck="false" placeholder="Configuration Veeam exportée automatiquement"></textarea>
                            </label>
                            <div class="dmd-backup-provider-credentials">
                                <label>Compte Veeam / Windows (optionnel)<input id="backupProviderConfigUsername" autocomplete="username"></label>
                                <label>Mot de passe (optionnel)<input id="backupProviderConfigPassword" type="password" autocomplete="new-password"></label>
                            </div>
                            <div id="backupProviderConfigState" class="dmd-agent-maint-inline-state compact">—</div>
                            <div class="dmd-agent-editor-actions">
                                <button type="button" class="dmd-agent-btn primary" id="backupProviderConfigSave">Appliquer sur ce PC</button>
                                <button type="button" class="dmd-agent-btn" id="backupProviderConfigDeploy">Déployer aux PC sélectionnés</button>
                            </div>
                        </section>

                        <section class="dmd-agent-maint-block compact">
                            <div class="dmd-agent-maint-block-head">
                                <div><strong>ISO de récupération Veeam</strong><small>Crée le média de démarrage Veeam directement sur le PC distant.</small></div>
                            </div>
                            <label>Chemin ISO sur le PC distant<input id="backupProviderRecoveryPath" value="C:\ProgramData\DoMyDesk\Recovery\Veeam-Recovery.iso"></label>
                            <div id="backupProviderRecoveryProgress" class="dmd-backup-provider-progress" hidden>
                                <div class="dmd-backup-progress"><i style="width:0%"></i></div>
                                <small>Préparation…</small>
                            </div>
                            <div id="backupProviderRecoveryState" class="dmd-agent-maint-inline-state compact">Aucun média en cours.</div>
                            <div class="dmd-agent-editor-actions">
                                <button type="button" class="dmd-agent-btn primary" id="backupProviderRecoveryStart">Créer l’ISO</button>
                                <button type="button" class="dmd-agent-btn danger" id="backupProviderRecoveryStop" disabled>Arrêter</button>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </section>

