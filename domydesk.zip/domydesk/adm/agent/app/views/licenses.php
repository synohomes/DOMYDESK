       <section class="dmd-agent-admin-pane" data-admin-pane="licenses" hidden>
       <div class="dmd-agent-license-pane dmd-r27-licenses">
               <div class="dmd-agent-license-overview-head"><strong>Utilisation des licences</strong><span class="dmd-agent-license-state <?= !empty($licenseStatus['verified'])?'verified':'launch' ?>"><?= !empty($licenseStatus['verified'])?'Licence signée':'Licence de lancement' ?></span></div>
                <div class="dmd-agent-license-grid">
                    <article class="dmd-agent-license-card"><div><strong>DMD-Agent</strong><small>Option Remote</small></div><div class="dmd-agent-license-value"><?= (int)$remoteActiveUsage ?> / <?= dmd_agent_h($licenseQuotaText($remoteLimit)) ?></div><p>PC avec DMD-Remote<?php if($remoteReservedUsage>0): ?> · <?= (int)$remoteReservedUsage ?> réservé<?= $remoteReservedUsage>1?'s':'' ?><?php endif; ?></p></article>
                    <article class="dmd-agent-license-card"><div><strong>DMD-MyDesk</strong><small>Modules actifs</small></div><div class="dmd-agent-license-value"><?= (int)$myDeskSelectedCount ?> / <?= dmd_agent_h($licenseQuotaText($myDeskLimit)) ?></div><p>Modules MyDesk actifs</p></article>
                    <article class="dmd-agent-license-card"><div><strong>DMD-Instances</strong><small>Instances liées</small></div><div class="dmd-agent-license-value"><?= dmd_agent_h((string)$instancesUsage) ?> / <?= dmd_agent_h($licenseQuotaText($instancesLimit)) ?></div><p>Instances liées</p></article>
                </div>
                <details class="dmd-agent-license-tech"><summary>Informations de licence</summary><div class="dmd-agent-detail-grid"><div><small>État</small><strong><?= dmd_agent_h($licenseStatus['state']??'—') ?></strong></div><div><small>Source</small><strong><?= dmd_agent_h($licenseStatus['source']??'—') ?></strong></div><div><small>Licence</small><strong><?= dmd_agent_h($licenseStatus['license_id']??'—') ?></strong></div><div><small>Révision</small><strong><?= (int)($licenseStatus['revision']??0) ?></strong></div><div><small>Fin</small><strong><?= dmd_agent_h($licenseStatus['valid_until']??DMD_LICENSE_LAUNCH_UNTIL) ?></strong></div><div><small>Clé</small><strong><?= dmd_agent_h($licenseStatus['signer_key_id']??DMD_LICENSE_ROOT_KEY_ID) ?></strong></div></div></details>
            </div>
        </section>

