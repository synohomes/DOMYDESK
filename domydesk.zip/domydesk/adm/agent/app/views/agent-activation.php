<?php
$repoLocal = function_exists('dmd_agent_repo_local_status') ? dmd_agent_repo_local_status() : array('ready'=>false);
?>
<section class="dmd-agent-activation-page">
    <div class="dmd-agent-activation-shell">
        <header class="dmd-agent-activation-head">
            <div class="dmd-agent-activation-mark">A</div>
            <div class="dmd-agent-activation-head-copy">
                <h2>Agents DoMyDesk désactivés</h2>
                <p>DoMyDesk fonctionne sans Agent. L’activation télécharge et prépare automatiquement l’installateur nécessaire aux enrôlements.</p>
            </div>
            <button type="button"
                    class="dmd-agent-btn primary dmd-agent-system-enable-btn"
                    data-agent-system-enable>
                ACTIVER LE SYSTÈME AGENTS
            </button>
        </header>

        <div class="dmd-agent-activation-features">
            <article><strong>Inventaire</strong><span>Machine, réseau, stockage, sessions, logiciels et matériel.</span></article>
            <article><strong>Administration</strong><span>Processus, services, terminal, registre, fichiers et commandes.</span></article>
            <article><strong>Maintenance</strong><span>Déploiement logiciel, Windows Update et mises à jour Agent.</span></article>
            <article><strong>DMD-Remote</strong><span>Prise en main distante selon les composants choisis à l’enrôlement.</span></article>
            <article><strong>DMD-MyDesk</strong><span>Client utilisateur optionnel, rattaché à l’identité sécurisée de l’Agent.</span></article>
            <article><strong>Enrôlement sécurisé</strong><span>Bootstrap signé, certificat de poste et installateur servi par DoMyDesk.</span></article>
        </div>

        <section class="dmd-agent-repo-card" data-dmd-repo-root data-auto-scan="0" data-reload-on-success="1">
            <div class="dmd-agent-repo-state" data-repo-state>
                <strong>Aucun installateur Agent actif</strong>
                <span>Le dépôt distant va être analysé pour proposer les ZIP disponibles.</span>
            </div>

            <div class="dmd-agent-repo-picker">
                <label>
                    <span>Version à activer</span>
                    <select data-repo-version disabled><option>Analyse du dépôt…</option></select>
                </label>
                <button type="button" class="dmd-agent-mini-btn" data-repo-scan>Actualiser les versions</button>
                <button type="button" class="dmd-agent-btn primary dmd-agent-activation-main-btn" data-repo-install disabled>Télécharger et préparer cette version</button>
            </div>
            <small class="dmd-agent-repo-selection" data-repo-selection-info></small>

            <div class="dmd-agent-repo-progress">
                <div class="dmd-agent-repo-progress-head"><strong data-repo-progress-text>Analyse du dépôt…</strong><span data-repo-progress-value>0%</span></div>
                <div class="dmd-agent-repo-progress-track"><i data-repo-progress-fill style="width:0%"></i></div>
                <div class="dmd-agent-repo-steps">
                    <span data-repo-step="scan">1. Analyse</span>
                    <span data-repo-step="download">2. Téléchargement</span>
                    <span data-repo-step="verify">3. Vérification</span>
                    <span data-repo-step="extract">4. Extraction</span>
                    <span data-repo-step="prepare">5. Préparation</span>
                    <span data-repo-step="done">6. Activé</span>
                </div>
            </div>

            <p class="dmd-agent-repo-note">Le ZIP sélectionné est téléchargé côté serveur. Seul <strong>DMD-Installer.exe</strong> est extrait puis placé dans <code>adm/agent/bin/windows-x64/</code>. Le ZIP temporaire est supprimé ensuite.</p>
        </section>
    </div>
</section>
<script src="assets/agent-repository.js?v=20260912-1" defer></script>
