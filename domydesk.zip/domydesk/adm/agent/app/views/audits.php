<?php
$__dmdAuditsJson = json_encode(
    array_values((array)$agentAudits),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
?>
<section
    class="dmd-agent-admin-pane dmd-audits-page"
    data-admin-pane="audits"
    data-audits-root
    data-audits-csrf="<?= dmd_agent_h(isset($csrfAgent) ? $csrfAgent : '') ?>"
    hidden
>
    <header class="dmd-audits-head">
        <div class="dmd-audits-title">
            <h3>Archives de révocation</h3>
            <p>État complet conservé au moment de la révocation : identité, matériel, inventaire, réseau, droits, enrôlement et événements.</p>
        </div>

        <div class="dmd-audits-actions">
            <span class="dmd-audits-count">
                <strong data-audit-count><?= count($agentAudits) ?></strong>
                archive<?= count($agentAudits) > 1 ? 's' : '' ?>
            </span>

            <button type="button" class="dmd-audits-btn" data-audits-print-all <?= !$agentAudits ? 'disabled' : '' ?>>
                Imprimer / PDF
            </button>

            <button type="button" class="dmd-audits-btn danger" data-audits-purge <?= !$agentAudits ? 'disabled' : '' ?>>
                Purger
            </button>
        </div>
    </header>

    <script type="application/json" id="dmdAgentAuditsData"><?= $__dmdAuditsJson ?: '[]' ?></script>

    <?php if (!$agentAudits): ?>
        <div class="dmd-audits-empty" data-audits-empty>
            <strong>Aucune archive</strong>
            <span>Une archive détaillée sera créée automatiquement lors de la révocation d’un agent.</span>
        </div>
    <?php else: ?>
        <div class="dmd-audits-table-wrap" data-audits-list>
            <table class="dmd-audits-table">
                <thead>
                    <tr>
                        <th>PC</th>
                        <th>Agent</th>
                        <th>Version</th>
                        <th>Dernière IP</th>
                        <th>Groupes</th>
                        <th>Révoqué le</th>
                        <th>Par</th>
                        <th>Signature</th>
                        <th class="actions">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($agentAudits as $a):
                    $aa = isset($a['agent']) && is_array($a['agent']) ? $a['agent'] : array();
                    $rr = isset($a['revocation']) && is_array($a['revocation']) ? $a['revocation'] : array();
                    $groups = isset($a['pc_groups']) && is_array($a['pc_groups']) ? $a['pc_groups'] : array();
                    $groupNames = array();
                    foreach ($groups as $group) {
                        if (!is_array($group)) continue;
                        $label = trim((string)($group['name'] ?? $group['group_id'] ?? ''));
                        if ($label !== '') $groupNames[] = $label;
                    }
                    $auditId = (string)($a['audit_id'] ?? '');
                    $valid = !empty($a['signature_valid']);
                    $pcName = trim((string)($aa['enrollment_name'] ?? ''));
                    if ($pcName === '') $pcName = trim((string)($aa['hostname'] ?? 'PC'));
                ?>
                    <tr data-audit-row="<?= dmd_agent_h($auditId) ?>">
                        <td class="hostname" title="<?= dmd_agent_h($aa['hostname'] ?? '') ?>">
                            <span class="dmd-audits-dot <?= $valid ? 'valid' : 'invalid' ?>" aria-hidden="true"></span>
                            <strong><?= dmd_agent_h($pcName) ?></strong>
                        </td>
                        <td class="agent-id" title="<?= dmd_agent_h($aa['agent_id'] ?? '') ?>">
                            <?= dmd_agent_h($aa['agent_id'] ?? '—') ?>
                        </td>
                        <td><?= dmd_agent_h($aa['agent_version'] ?? '—') ?></td>
                        <td><?= dmd_agent_h($aa['last_ip'] ?? '—') ?></td>
                        <td class="groups" title="<?= dmd_agent_h(implode(', ', $groupNames)) ?>">
                            <?= dmd_agent_h($groupNames ? implode(', ', $groupNames) : '—') ?>
                        </td>
                        <td>
                            <strong class="dmd-agent-date" data-date="<?= dmd_agent_h($rr['revoked_at'] ?? '') ?>">
                                <?= dmd_agent_h($rr['revoked_at'] ?? '—') ?>
                            </strong>
                        </td>
                        <td class="actor" title="<?= dmd_agent_h($rr['revoked_by'] ?? '—') ?>">
                            <?= dmd_agent_h($rr['revoked_by'] ?? '—') ?>
                        </td>
                        <td>
                            <span class="dmd-audits-signature <?= $valid ? 'valid' : 'invalid' ?>">
                                <?= $valid ? 'Valide' : 'Invalide' ?>
                            </span>
                        </td>
                        <td class="actions">
                            <button
                                type="button"
                                class="dmd-audits-btn compact"
                                data-audit-open="<?= dmd_agent_h($auditId) ?>"
                            >Voir tout</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
