            <section id="workspace-tools" class="dmd-agent-workspace-view dmd-agent-workspace-tools" data-workspace-pane="tools" hidden>
                <div id="workspaceToolHost" class="dmd-agent-workspace-tool-host"></div>
            </section>
        </div>
    </section>
