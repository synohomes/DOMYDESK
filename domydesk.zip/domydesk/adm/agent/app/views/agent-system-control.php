<?php
$agentSystemStatus = function_exists('dmd_agent_system_status')
    ? dmd_agent_system_status()
    : array('enabled'=>true);
?>
<section class="dmd-agent-system-control" data-agent-system-control>
    <div class="dmd-agent-system-control-state">
        <span class="dmd-agent-system-control-dot"></span>
        <div>
            <strong>Système Agents DoMyDesk actif</strong>
            <small>Les fonctions Agent et les enrôlements sont disponibles.</small>
        </div>
    </div>

    <div class="dmd-agent-system-control-actions">
        <button type="button"
                class="dmd-agent-system-help-btn"
                id="dmdAgentSystemHelpOpen"
                title="Comment installer un Agent ?"
                aria-label="Comment installer un Agent ?">
            ?
        </button>

        <button type="button"
                class="dmd-agent-btn danger"
                data-agent-system-disable>
            Désactiver le système Agents
        </button>
    </div>
</section>

<div class="dmd-agent-system-help-modal"
     id="dmdAgentSystemHelpModal"
     hidden
     aria-hidden="true">
    <div class="dmd-agent-system-help-backdrop" data-agent-help-close></div>

    <section class="dmd-agent-system-help-card"
             role="dialog"
             aria-modal="true"
             aria-labelledby="dmdAgentSystemHelpTitle">

        <header class="dmd-agent-system-help-head">
            <div>
                <h2 id="dmdAgentSystemHelpTitle">Installer un Agent DoMyDesk sur un PC</h2>
                <p>Procédure complète depuis la création de l’enrôlement jusqu’à l’apparition du poste dans le parc.</p>
            </div>
            <button type="button"
                    class="dmd-agent-icon-btn"
                    data-agent-help-close
                    aria-label="Fermer">×</button>
        </header>

        <div class="dmd-agent-system-help-body">
            <div class="dmd-agent-help-step">
                <span>1</span>
                <div>
                    <strong>Créer un nouvel enrôlement</strong>
                    <p>Depuis <b>Enrôlements</b> ou le bouton <b>Nouvel enrôlement</b>, ouvre la fiche de préparation du nouveau poste.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>2</span>
                <div>
                    <strong>Préparer le poste</strong>
                    <p>Renseigne son nom / alias, éventuellement son groupe, la durée de validité et le mode de validation.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>3</span>
                <div>
                    <strong>Indiquer les adresses DoMyDesk</strong>
                    <p>Saisis simplement l’IP, le nom local ou le domaine, par exemple <code>http://192.168.1.50</code>. Il n’est pas nécessaire d’ajouter <code>/domydesk</code> : DoMyDesk détecte automatiquement son point d’accès. Plusieurs adresses peuvent être ajoutées.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>4</span>
                <div>
                    <strong>Choisir les composants</strong>
                    <p><b>DMD-Agent</b> est toujours installé. Active <b>DMD-Remote</b> si le poste doit accepter la prise en main distante et <b>DMD-MyDesk</b> si le client utilisateur doit être installé.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>5</span>
                <div>
                    <strong>Créer l’enrôlement</strong>
                    <p>DoMyDesk génère un enrôlement signé ainsi qu’un <b>lien temporaire</b> lié uniquement à ce poste et valable pendant la durée choisie.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>6</span>
                <div>
                    <strong>Installer sur le PC cible</strong>
                    <p>Ouvre le lien temporaire sur le PC à enrôler. Il télécharge <b>DMD-Installer.exe</b>. Lance l’EXE : l’installateur récupère automatiquement son bootstrap sécurisé et prépare les composants sélectionnés.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>7</span>
                <div>
                    <strong>Valider le poste si nécessaire</strong>
                    <p>Si <b>Validation Superadmin</b> a été choisie, retourne dans <b>Enrôlements</b> puis clique sur <b>Autoriser</b> lorsque le PC se présente.</p>
                </div>
            </div>

            <div class="dmd-agent-help-step">
                <span>8</span>
                <div>
                    <strong>Le PC rejoint le parc</strong>
                    <p>Une fois l’enrôlement terminé, le poste apparaît dans le tableau de bord avec son état, son IP, son groupe et les fonctions Agent autorisées.</p>
                </div>
            </div>

            <aside class="dmd-agent-help-note">
                <strong>À retenir</strong>
                <span>Le lien temporaire et le bootstrap sont propres à un enrôlement. Ne réutilise pas le même lien pour installer plusieurs PC.</span>
            </aside>
        </div>

        <footer class="dmd-agent-system-help-foot">
            <button type="button"
                    class="dmd-agent-btn"
                    data-agent-help-close>
                Fermer
            </button>
            <button type="button"
                    class="dmd-agent-btn primary"
                    data-open-panel="enrollments"
                    data-agent-help-enroll>
                Ouvrir les enrôlements
            </button>
        </footer>
    </section>
</div>

<script>
(function(){
    const modal = document.getElementById('dmdAgentSystemHelpModal');
    const openButton = document.getElementById('dmdAgentSystemHelpOpen');
    if(!modal || !openButton) return;

    function openHelp(){
        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('dmd-agent-help-open');
    }

    function closeHelp(){
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('dmd-agent-help-open');
    }

    openButton.addEventListener('click', openHelp);

    modal.querySelectorAll('[data-agent-help-close]').forEach(function(button){
        button.addEventListener('click', closeHelp);
    });

    modal.querySelector('[data-agent-help-enroll]')?.addEventListener('click', function(){
        closeHelp();
    });

    document.addEventListener('keydown', function(event){
        if(event.key === 'Escape' && !modal.hidden) closeHelp();
    });
})();
</script>
