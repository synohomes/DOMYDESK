<?php
$dmdR38Preview=null;
foreach($devices as $dmdR38Candidate){
    if(($dmdR38Candidate['status']??'')==='active'){$dmdR38Preview=$dmdR38Candidate;break;}
}
if(!$dmdR38Preview && $devices)$dmdR38Preview=$devices[0];
?>
            <section id="workspace-fleet" class="dmd-agent-workspace-view active dmd-r19-dashboard dmd-r38-dashboard" data-workspace-pane="fleet">
                <header class="dmd-r38-page-head">
                    <div>
                        <h2 id="fleetPageTitle">Tableau de bord</h2>
                        <p id="fleetPageSubtitle">État du parc et accès aux opérations courantes.</p>
                    </div>
                    <div class="dmd-r38-health"><span></span><?= !empty($identity['ok'])?'Systèmes opérationnels':'Vérification requise' ?></div>
                </header>

                <section class="dmd-r38-quickbar">
                    <strong>Actions rapides</strong>
                    <div>
                        <button type="button" class="dmd-agent-btn primary" data-open-panel="create">＋ Nouvel enrôlement</button>
                        <button type="button" class="dmd-agent-btn" data-workspace-admin="network-scan">⌁ Scan réseau</button>
                        <button type="button" class="dmd-agent-btn" data-maintenance-popup="software-bulk">＋ Installer un logiciel</button>
                        <button type="button" class="dmd-agent-btn" data-maintenance-popup="software-updates">↻ Mises à jour</button>
                        <button type="button" class="dmd-agent-btn" data-workspace-admin="backup">◫ Sauvegardes</button>
                    </div>
                </section>

                <div class="dmd-r38-fleet-layout">
                    <section class="dmd-r38-panel dmd-r38-fleet-panel">
                        <header class="dmd-r38-panel-head dmd-r38-fleet-toolbar">
                            <div>
                                <h3>Parc informatique</h3>
                                <p>Liste des postes gérés et de leur état.</p>
                            </div>
                            <div class="dmd-r38-filters">
                                <input id="agentSearch" type="search" placeholder="Rechercher un poste…" autocomplete="off">
                                <select id="agentFilter" aria-label="Filtrer par état">
                                    <option value="all">Tous les statuts</option>
                                    <option value="online">En ligne</option>
                                    <option value="offline">Hors ligne</option>
                                </select>
                                <select id="agentOsFilter" aria-label="Filtrer par système">
                                    <option value="all">Tous les OS</option>
                                    <option value="windows">Windows</option>
                                    <option value="linux">Linux</option>
                                    <option value="macos">macOS</option>
                                    <option value="other">Autres</option>
                                </select>
                                <select id="agentGroupFilter" aria-label="Filtrer par groupe">
                                    <option value="all">Tous les groupes</option>
                                    <?php foreach((array)($pcGroupsData['groups']??array()) as $g): if(!is_array($g))continue; ?>
                                        <option value="<?= dmd_agent_h($g['group_id']??'') ?>"><?= dmd_agent_h($g['name']??'Groupe') ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </header>

                        <?php if(!$devices): ?>
                            <div class="dmd-agent-empty compact">
                                <strong>Aucun PC enrôlé</strong>
                                <span>Ajoute un poste pour commencer à gérer le parc.</span>
                                <button type="button" class="dmd-agent-btn primary" data-open-panel="create">Ajouter un poste</button>
                            </div>
                        <?php else: ?>
                        <div class="dmd-r38-table-wrap">
                            <table class="dmd-r38-device-table">
                                <colgroup>
                                    <col class="c-name"><col class="c-status"><col class="c-user"><col class="c-system"><col class="c-group"><col class="c-seen"><col class="c-action">
                                </colgroup>
                                <thead>
                                    <tr><th>Nom du poste</th><th>Statut</th><th>Utilisateur</th><th>Système</th><th>Groupe</th><th>Dernière connexion</th><th></th></tr>
                                </thead>
                                <tbody id="agentGrid">
                                <?php foreach($devices as $d):
                                    $lastTs=isset($d['last_seen_ts'])?(int)$d['last_seen_ts']:0;
                                    $online=($d['status']??'')==='active' && $lastTs>0 && ($now-$lastTs)<90;
                                    $revoked=($d['status']??'')==='revoked';
                                    $hostname=$d['hostname']??'PC sans nom';
                                    $ip=$d['last_ip']??'IP inconnue';
                                    $agentId=$d['agent_id']??'';
                                    $osGroup=dmd_agent_platform_group($d['platform']??'');
                                    $osLabel=dmd_agent_device_os_label($d);
                                    $groupNames=dmd_agent_device_group_names($agentId,$pcGroupsData);
                                    $groupIds=array(); foreach((array)($pcGroupsData['groups']??array()) as $pg){if(is_array($pg)&&in_array((string)$agentId,(array)($pg['agent_ids']??array()),true))$groupIds[]=(string)($pg['group_id']??'');}
                                    $groupLabel=$groupNames?implode(', ',$groupNames):'—';
                                    $inv=isset($d['last_inventory'])&&is_array($d['last_inventory'])?$d['last_inventory']:array();
                                    $activeUser=trim((string)($inv['active_user']??$inv['logged_on_user']??$inv['current_user']??$inv['username']??''));
                                    if($activeUser==='')$activeUser='—';
                                    $searchText=strtolower(trim($hostname.' '.$ip.' '.$groupLabel.' '.$agentId.' '.$osLabel.' '.$activeUser));
                                ?>
                                    <tr class="dmd-r39-fleet-row <?= $online?'is-online':'is-offline' ?> <?= $revoked?'is-revoked':'' ?>"
                                        tabindex="0"
                                        data-device-preview="<?= dmd_agent_h($agentId) ?>"
                                        data-agent-id="<?= dmd_agent_h($agentId) ?>"
                                        data-hostname="<?= dmd_agent_h(strtolower($hostname)) ?>"
                                        data-ip="<?= dmd_agent_h(strtolower($ip)) ?>"
                                        data-search="<?= dmd_agent_h($searchText) ?>"
                                        data-filter="<?= $revoked?'revoked':($online?'online':'offline') ?>"
                                        data-os="<?= dmd_agent_h($osGroup) ?>"
                                        data-groups="<?= dmd_agent_h(implode(' ',array_filter($groupIds))) ?>">
                                        <td><div class="dmd-r39-device-name"><span class="dmd-r39-device-icon">▣</span><span><strong><?= dmd_agent_h($hostname) ?></strong><small><?= dmd_agent_h($ip) ?></small></span></div></td>
                                        <td><b class="dmd-r39-status <?= $online?'online':'offline' ?>"><?= $online?'● En ligne':'● Hors ligne' ?></b></td>
                                        <td class="dmd-r39-ellipsis" title="<?= dmd_agent_h($activeUser) ?>"><?= dmd_agent_h($activeUser) ?></td>
                                        <td class="dmd-r39-ellipsis" title="<?= dmd_agent_h($osLabel) ?>"><?= dmd_agent_h($osLabel) ?></td>
                                        <td class="dmd-r39-ellipsis" title="<?= dmd_agent_h($groupLabel) ?>"><?= dmd_agent_h($groupLabel) ?></td>
                                        <td class="dmd-agent-date" data-date="<?= dmd_agent_h($d['last_seen_at']??'') ?>"><?= dmd_agent_h($d['last_seen_at']??'Jamais') ?></td>
                                        <td><button type="button" class="dmd-r39-row-action" data-device-open="<?= dmd_agent_h($agentId) ?>" aria-label="Ouvrir la gestion de <?= dmd_agent_h($hostname) ?>">•••</button></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <div id="agentNoResult" class="dmd-agent-table-empty" hidden>Aucun PC ne correspond aux filtres.</div>
                        </div>
                        <footer class="dmd-r38-table-foot">
                            <span><?= count($devices) ?> poste<?= count($devices)>1?'s':'' ?></span>
                            <button type="button" class="dmd-agent-btn" data-open-panel="create">＋ Ajouter un poste</button>
                        </footer>
                        <?php endif; ?>
                    </section>

                    <aside id="fleetPreview" class="dmd-r38-panel dmd-r38-device-preview" <?= $dmdR38Preview?'':'hidden' ?>>
                        <header class="dmd-r38-preview-head">
                            <span class="dmd-r38-preview-icon">▣</span>
                            <div><strong id="fleetPreviewName">—</strong><small id="fleetPreviewOs">—</small></div>
                            <span id="fleetPreviewStatus" class="dmd-r39-status">—</span>
                        </header>
                        <nav class="dmd-r38-preview-tabs">
                            <button type="button" class="active">Aperçu</button>
                            <button type="button" id="fleetPreviewSoftware">Logiciels</button>
                            <button type="button" id="fleetPreviewUpdates">Mises à jour</button>
                            <button type="button" id="fleetPreviewBackup">Sauvegardes</button>
                        </nav>
                        <div class="dmd-r38-preview-kv">
                            <div><span>Nom du poste</span><strong id="fleetPreviewHost">—</strong></div>
                            <div><span>Utilisateur</span><strong id="fleetPreviewUser">—</strong></div>
                            <div><span>Groupe</span><strong id="fleetPreviewGroup">—</strong></div>
                            <div><span>Adresse IP</span><strong id="fleetPreviewIp">—</strong></div>
                            <div><span>Dernière connexion</span><strong id="fleetPreviewSeen">—</strong></div>
                            <div><span>Agent DMD</span><strong id="fleetPreviewAgent">—</strong></div>
                            <div><span>Enrôlement</span><strong id="fleetPreviewEnroll">—</strong></div>
                        </div>
                        <div class="dmd-r38-preview-actions">
                            <button type="button" class="dmd-agent-btn primary" id="fleetPreviewRemote">Bureau à distance</button>
                            <button type="button" class="dmd-agent-btn" id="fleetPreviewDetails">Détails système</button>
                            <button type="button" class="dmd-agent-btn" id="fleetPreviewUpdate">Mettre à jour</button>
                        </div>
                    </aside>
                </div>
            </section>
