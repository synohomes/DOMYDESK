        <section class="dmd-agent-admin-pane active" data-admin-pane="pc-groups">
            <div class="dmd-agent-admin-two-col dmd-r27-organizer">
                <div class="dmd-agent-admin-list-card">
                    <div class="dmd-agent-admin-card-head"><div><h3>Groupes existants</h3><p>Un poste peut appartenir à plusieurs groupes.</p></div><button type="button" class="dmd-agent-mini-btn" id="newPcGroup">＋ Groupe</button></div>
                    <div id="pcGroupList" class="dmd-agent-admin-list"></div>
                </div>
                <form id="pcGroupForm" class="dmd-agent-admin-editor">
                    <input type="hidden" name="group_id" value="">
                    <div class="dmd-agent-admin-card-head"><div><h3 id="pcGroupEditorTitle">Nouveau groupe</h3><p>Définis le nom, la description et les postes membres.</p></div></div>
                    <label>Nom<input name="name" maxlength="80" required placeholder="PC France"></label>
                    <label>Description<input name="description" maxlength="240" placeholder="Périmètre du parc"></label>
                    <div class="dmd-agent-check-section"><strong>PC membres</strong><div class="dmd-agent-check-grid compact">
                    <?php foreach($devices as $d): ?><label><input type="checkbox" name="agent_ids[]" value="<?= dmd_agent_h($d['agent_id']??'') ?>"><span><?= dmd_agent_h($d['hostname']??'PC') ?><small><?= dmd_agent_h($d['last_ip']??'IP inconnue') ?></small></span></label><?php endforeach; ?>
                    </div></div>
                    <div class="dmd-agent-editor-actions"><button type="submit" class="dmd-agent-btn primary">Enregistrer</button><button type="button" id="deletePcGroup" class="dmd-agent-btn danger" hidden>Supprimer</button></div>
                </form>
            </div>
        </section>

