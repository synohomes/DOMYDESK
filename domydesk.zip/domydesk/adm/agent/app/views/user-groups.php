<?php
// Avatar + lien vers la fiche utilisateur DoMyDesk.
if (isset($baseDir) && is_file($baseDir . '/core/dmd_media.php')) {
    require_once $baseDir . '/core/dmd_media.php';
}
?>
<section class="dmd-agent-admin-pane" data-admin-pane="user-groups" hidden>
    <div class="dmd-agent-admin-two-col dmd-r27-organizer dmd-user-groups-layout">

        <div class="dmd-agent-admin-list-card dmd-user-groups-list-card">
            <div class="dmd-agent-admin-card-head">
                <div>
                    <h3>Groupes existants</h3>
                    <p>Utilisés pour attribuer les droits d’accès.</p>
                </div>
                <button type="button" class="dmd-agent-mini-btn" id="newUserGroup">＋ Groupe</button>
            </div>

            <div id="userGroupList" class="dmd-agent-admin-list"></div>
        </div>

        <form id="userGroupForm" class="dmd-agent-admin-editor dmd-user-groups-editor">
            <input type="hidden" name="group_id" value="">

            <div class="dmd-agent-admin-card-head">
                <div>
                    <h3 id="userGroupEditorTitle">Nouveau groupe</h3>
                    <p>Définis le nom, la description et les utilisateurs membres.</p>
                </div>
            </div>

            <div class="dmd-user-groups-fields">
                <label>
                    <span>Nom</span>
                    <input name="name" maxlength="80" required placeholder="Stagiaires IT">
                </label>

                <label>
                    <span>Description</span>
                    <input name="description" maxlength="240" placeholder="Niveau de support">
                </label>
            </div>

            <div class="dmd-agent-check-section dmd-user-groups-users">
                <div class="dmd-user-groups-users-head">
                    <div>
                        <strong>Utilisateurs</strong>
                        <small>Coche les membres. Clique sur l’avatar ou le nom pour ouvrir leur fiche DoMyDesk.</small>
                    </div>
                    <span><?= count($domydeskUsers) ?> utilisateur<?= count($domydeskUsers) > 1 ? 's' : '' ?></span>
                </div>

                <div class="dmd-user-card-grid">
                <?php foreach ($domydeskUsers as $u):
                    $emailUser = trim((string)($u['email'] ?? ''));
                    $full = trim((string)($u['prenom'] ?? '') . ' ' . (string)($u['nom'] ?? ''));
                    $display = $full !== '' ? $full : $emailUser;
                    $role = trim((string)($u['role_system'] ?? 'user'));

                    $avatarUrl = '';
                    if (
                        $emailUser !== '' &&
                        function_exists('dmd_user_avatar_file') &&
                        function_exists('dmd_media_public_url')
                    ) {
                        $avatarPath = dmd_user_avatar_file($emailUser);
                        if ($avatarPath !== '') {
                            $avatarUrl = dmd_media_public_url($avatarPath);
                        }
                    }

                    $initial = '?';
                    $initialSource = trim((string)($u['prenom'] ?? ''));
                    if ($initialSource === '') $initialSource = $display;
                    if ($initialSource !== '') {
                        $initial = function_exists('mb_substr')
                            ? mb_strtoupper(mb_substr($initialSource, 0, 1, 'UTF-8'), 'UTF-8')
                            : strtoupper(substr($initialSource, 0, 1));
                    }

                    // DoMyDesk utilise "email", pas "user", pour afficher la fiche d'un autre utilisateur.
                    $profileUrl = '/domydesk/profile_view.php?email=' . rawurlencode($emailUser);
                ?>
                    <div class="dmd-user-card">
                        <label class="dmd-user-card-selector" title="Ajouter au groupe">
                            <input
                                class="dmd-user-card-check"
                                type="checkbox"
                                name="users[]"
                                value="<?= dmd_agent_h($emailUser) ?>"
                                aria-label="Ajouter <?= dmd_agent_h($display) ?> au groupe"
                            >
                            <span aria-hidden="true"></span>
                        </label>

                        <a
                            class="dmd-user-card-profile"
                            href="<?= dmd_agent_h($profileUrl) ?>"
                            title="Ouvrir la fiche de <?= dmd_agent_h($display) ?>"
                        >
                            <span class="dmd-user-card-avatar">
                                <?php if ($avatarUrl !== ''): ?>
                                    <img
                                        src="<?= dmd_agent_h($avatarUrl) ?>"
                                        alt=""
                                        loading="lazy"
                                        onerror="this.hidden=true;this.nextElementSibling.hidden=false;"
                                    >
                                    <span class="dmd-user-card-avatar-fallback" hidden><?= dmd_agent_h($initial) ?></span>
                                <?php else: ?>
                                    <span class="dmd-user-card-avatar-fallback"><?= dmd_agent_h($initial) ?></span>
                                <?php endif; ?>
                            </span>

                            <span class="dmd-user-card-name"><?= dmd_agent_h($display) ?></span>
                            <span class="dmd-user-card-email"><?= dmd_agent_h($emailUser) ?></span>
                            <span class="dmd-user-card-role"><?= dmd_agent_h($role) ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
                </div>
            </div>

            <div class="dmd-agent-editor-actions dmd-user-groups-actions">
                <button type="submit" class="dmd-agent-btn primary">Enregistrer</button>
                <button type="button" id="deleteUserGroup" class="dmd-agent-btn danger" hidden>Supprimer</button>
            </div>
        </form>
    </div>
</section>
