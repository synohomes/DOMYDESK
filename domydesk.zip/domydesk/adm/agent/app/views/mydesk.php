        <section class="dmd-agent-admin-pane" data-admin-pane="mydesk" hidden>
            <form id="myDeskSettingsForm" class="dmd-agent-admin-editor dmd-agent-mydesk-admin dmd-r27-mydesk">
                <div class="dmd-agent-admin-card-head"><div><h3>Modules disponibles</h3><p>Choisis les modules accessibles depuis MyDesk.</p></div><div class="dmd-agent-license-counter" id="myDeskModuleCounter"><strong><?= (int)$myDeskSelectedCount ?></strong><span>/ <?= dmd_agent_h($licenseQuotaText($myDeskLimit)) ?></span></div></div>

                <div class="dmd-agent-check-section">
                    <strong>Modules compatibles détectés</strong>

                    <div class="dmd-agent-check-grid compact"
                         id="myDeskModuleGrid"
                         data-limit="<?= (int)$myDeskLimit ?>">

                        <?php if(!$myDeskModules): ?>
                            <span class="dmd-agent-muted">
                                Aucun module installé ne déclare
                                <code>mydesk_compatible: true</code>
                                dans son <code>dmd_module.json</code>.
                            </span>
                        <?php else: ?>
                            <?php foreach($myDeskModules as $myDeskModule): ?>
                                <?php
                                $mdEnabled = dmd_agent_mydesk_module_enabled($myDeskModule, $myDeskSettings);
                                $mdId = (string)($myDeskModule['id'] ?? '');
                                $mdLabel = trim((string)($myDeskModule['label'] ?? $mdId));
                                $mdDescription = trim((string)($myDeskModule['description'] ?? ''));
                                $mdRuntime = trim((string)($myDeskModule['min_runtime'] ?? '1.4.0'));
                                $mdFeatures = isset($myDeskModule['features']) && is_array($myDeskModule['features'])
                                    ? array_values(array_filter(array_map('strval', $myDeskModule['features'])))
                                    : array();
                                ?>

                                <label class="dmd-r27-module-card">
                                    <input
                                        type="checkbox"
                                        name="mydesk_modules[]"
                                        value="<?= dmd_agent_h($mdId) ?>"
                                        <?= $mdEnabled ? 'checked' : '' ?>
                                        <?= !$myDeskLicensed ? 'disabled data-license-disabled="1"' : '' ?>
                                    >

                                    <span>
                                        <strong><?= dmd_agent_h($mdLabel) ?></strong>
                                        <small>
                                            <?= dmd_agent_h($mdId) ?>
                                            · MyDesk ≥ <?= dmd_agent_h($mdRuntime) ?>
                                            <?php if($mdFeatures): ?>
                                                · <?= dmd_agent_h(implode(', ', $mdFeatures)) ?>
                                            <?php endif; ?>
                                            <?php if($mdDescription !== ''): ?>
                                                · <?= dmd_agent_h($mdDescription) ?>
                                            <?php endif; ?>
                                        </small>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        <?php endif; ?>

                    </div>
                </div>

                <?php if(!$myDeskLicensed): ?>
                    <p class="dmd-agent-form-note danger">
                        DMD-MyDesk n’est pas disponible avec la licence actuelle.
                    </p>
                <?php endif; ?>

                <div class="dmd-agent-editor-actions"><button type="submit" class="dmd-agent-btn primary" <?= (!$myDeskModules||!$myDeskLicensed)?'disabled':'' ?>>Enregistrer les modules MyDesk</button></div>
            </form>
        </section>

