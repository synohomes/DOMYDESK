<?php
require_once __DIR__ . '/_public.php';
$payload = dmd_agent_public_body();
$validated = dmd_agent_signed_request_validate($payload, 'POST', '/adm/agent/api/agent_remote.php', dmd_agent_remote_ip());
if (empty($validated['ok'])) dmd_agent_public_send($validated);
$body = $validated['body'];
$agentId = $validated['agent_id'];
$action = strtolower(trim((string)($body['action'] ?? '')));

// Réponse d'une commande de contrôle Remote passée par le canal temps réel.
// Ce canal évite la file générale DMD-Agent pour les commandes propres à une
// session Remote déjà active (écrans, profil, presse-papiers, stop).
if ($action === 'control_result') {
    $requestId = dmd_agent_remote_control_request_id((string)($body['request_id'] ?? ''));
    if ($requestId === '') dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_control_request_invalid'));
    $ok = !empty($body['control_ok']);
    $error = substr((string)($body['control_error'] ?? ''),0,1200);
    $result = array_key_exists('control_result',$body) ? $body['control_result'] : null;
    if (!dmd_agent_remote_control_result_write($agentId,$requestId,$ok,$result,$error)) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>500,'code'=>'remote_control_result_store_failed'));
    }
    $responseBody=array('status'=>'active','stored'=>true,'request_id'=>$requestId,'server_time'=>time());
    dmd_agent_public_send(dmd_agent_signed_response($agentId,$validated['nonce'],$responseBody));
}

// Les entrées clavier/souris restent sur un canal séparé du flux écran.
// inputs_wait garde la requête ouverte quelques centaines de ms et répond dès
// qu'un évènement arrive : en LAN, plus de délai imposé par un polling fixe.
if ($action === 'inputs_wait') {
    $waitMs = max(20, min(400, (int)($body['wait_ms'] ?? 250)));
    $deadline = microtime(true) + ($waitMs / 1000);
    $inputs = array();
    do {
        $inputs = dmd_agent_remote_take_inputs($agentId, 80);
        if ($inputs) break;
        usleep(8000);
    } while (microtime(true) < $deadline);
    $responseBody = array('status'=>'active','inputs'=>$inputs,'server_time'=>time(),'input_mode'=>'dedicated-wait');
    dmd_agent_public_send(dmd_agent_signed_response($agentId, $validated['nonce'], $responseBody));
}
if ($action === 'inputs' || $action === 'poll') {
    $inputs = dmd_agent_remote_take_inputs($agentId, 80);
    $responseBody = array('status'=>'active','inputs'=>$inputs,'server_time'=>time(),'input_mode'=>'dedicated');
    dmd_agent_public_send(dmd_agent_signed_response($agentId, $validated['nonce'], $responseBody));
}

// DMDStream v1 : aucun JPEG. Le serveur conserve les paquets zlib delta/keyframe
// et le navigateur les reconstruit dans un canvas.
if ($action === 'stream') {
    $codec = strtolower(trim((string)($body['stream_codec'] ?? '')));
    $pixelFormat = strtoupper(trim((string)($body['pixel_format'] ?? '')));
    $streamB64 = (string)($body['stream_base64'] ?? '');
    $sessionId = substr(trim((string)($body['session_id'] ?? $agentId)), 0, 96);
    if ($sessionId === '') $sessionId = $agentId;
    $seq = max(0, (int)($body['sequence'] ?? 0));
    $baseSequence = max(0, (int)($body['base_sequence'] ?? 0));
    $width = max(0, (int)($body['width'] ?? 0));
    $height = max(0, (int)($body['height'] ?? 0));
    $chunkIndex = max(0, (int)($body['chunk_index'] ?? 0));
    $chunkCount = max(1, (int)($body['chunk_count'] ?? 1));
    $frameSha256 = strtolower(trim((string)($body['frame_sha256'] ?? '')));
    $keyframe = !empty($body['keyframe']);
    $control = !empty($body['control']);

    $h264 = ($codec === 'dmd-h264-annexb-v1');
    if (!$h264 && $codec !== 'dmdstream-key-xor-zlib-v2') dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_codec_invalid'));
    if ($h264) {
        if ($pixelFormat !== 'H264') dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_pixel_format_invalid'));
    } elseif ($pixelFormat !== 'BGR24') {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_pixel_format_invalid'));
    }
    if ($seq < 1 || $width < 1 || $height < 1 || $width > 4096 || $height > 4096) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_geometry_invalid'));
    }
    if (($keyframe && $baseSequence !== $seq) || (!$keyframe && ($baseSequence < 1 || $baseSequence >= $seq))) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_base_invalid'));
    }
    if ($chunkCount < 1 || $chunkCount > 32 || $chunkIndex >= $chunkCount) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_chunk_metadata_invalid'));
    }
    if ($streamB64 === '' || strlen($streamB64) > 820000) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>413,'code'=>'remote_stream_payload_invalid'));
    }
    $compressed = base64_decode($streamB64, true);
    if (!is_string($compressed) || strlen($compressed) < 1 || strlen($compressed) > 600000) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_base64_invalid'));
    }
    // Compatibilité avec un paquet mono-bloc : le hash peut être dérivé côté serveur.
    if ($frameSha256 === '' && $chunkCount === 1 && $chunkIndex === 0) $frameSha256 = hash('sha256', $compressed);
    if (!preg_match('/^[a-f0-9]{64}$/', $frameSha256)) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_stream_hash_invalid'));
    }

    $stored = dmd_agent_remote_store_stream_chunk(
        $agentId, $sessionId, $seq, $width, $height, $compressed,
        $chunkIndex, $chunkCount, $frameSha256, $keyframe, $control, $baseSequence, $codec
    );
    if (empty($stored['ok'])) {
        dmd_agent_public_send(array('ok'=>false,'_http'=>500,'code'=>(string)($stored['code'] ?? 'remote_stream_store_failed')));
    }

    $responseBody = array(
        'status'=>'active',
        'stored'=>!empty($stored['stored']),
        'partial'=>!empty($stored['partial']),
        'stale'=>!empty($stored['stale']),
        'sequence'=>(int)($stored['sequence'] ?? $seq),
        'base_sequence'=>(int)($stored['base_sequence'] ?? $baseSequence),
        'chunk_index'=>$chunkIndex,
        'chunk_count'=>$chunkCount,
        'stream_codec'=>$codec,
        'pixel_format'=>$h264 ? 'H264' : 'BGR24',
        'input_mode'=>'dedicated',
        'server_time'=>time(),
    );
    dmd_agent_public_send(dmd_agent_signed_response($agentId, $validated['nonce'], $responseBody));
}

dmd_agent_public_send(array('ok'=>false,'_http'=>400,'code'=>'remote_action_invalid'));
