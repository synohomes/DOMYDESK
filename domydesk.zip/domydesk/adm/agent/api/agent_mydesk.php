<?php
require_once __DIR__ . '/_public.php';
$payload = dmd_agent_public_body();
$validated = dmd_agent_signed_request_validate($payload, 'POST', '/adm/agent/api/agent_mydesk.php', dmd_agent_remote_ip());
if (empty($validated['ok'])) dmd_agent_public_send($validated);
$device = $validated['device'];
// Persiste immédiatement le nonce validé pour empêcher tout rejeu de requête MyDesk.
if (!dmd_agent_json_write($validated['device_file'], $device, 0640)) dmd_agent_public_send(dmd_agent_api_result(false, 500, 'device_write_failed'));
if (!dmd_agent_mydesk_device_enabled($device)) dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array('ok'=>false,'status'=>'disabled','error'=>'mydesk_not_enabled_for_agent')));
$body = $validated['body'];
$action = trim((string)(isset($body['action']) ? $body['action'] : ''));
if ($action === 'catalog') {
    $licenseEnvelope = function_exists('dmd_license_raw_envelope') ? dmd_license_raw_envelope() : '';
    dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array(
        'ok'=>true,
        'status'=>'active',
        'modules'=>dmd_agent_mydesk_public_catalog($device, dmd_agent_mydesk_runtime_context($body)),
        'license_envelope'=>$licenseEnvelope,
    )));
}
if ($action === 'launch') {
    $moduleId = trim((string)(isset($body['module_id']) ? $body['module_id'] : ''));
    $launch = dmd_agent_mydesk_launch_token_create($device, $moduleId, dmd_agent_mydesk_runtime_context($body));
    if (empty($launch['ok'])) dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array('ok'=>false,'status'=>'refused','error'=>(string)(isset($launch['error'])?$launch['error']:'launch_refused'))));
    dmd_agent_log('mydesk_launch_created','success',array('agent_id'=>$validated['agent_id'],'module_id'=>$moduleId));
    dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array('ok'=>true,'status'=>'launch_ready','launch_url'=>$launch['launch_url'])));
}
if ($action === 'notifications') {
    $notifications = dmd_agent_mydesk_notifications_for_agent($validated['agent_id'], 5);
    dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array(
        'ok'=>true,
        'status'=>'active',
        'notifications'=>$notifications
    )));
}
if ($action === 'notifications_ack') {
    $ids = isset($body['ids']) && is_array($body['ids']) ? $body['ids'] : array();
    if (count($ids) > 20) $ids = array_slice($ids, 0, 20);
    $ack = dmd_agent_mydesk_notifications_ack($validated['agent_id'], $ids);
    dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array(
        'ok'=>true,
        'status'=>'acknowledged',
        'acknowledged'=>$ack
    )));
}
dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], array('ok'=>false,'status'=>'refused','error'=>'action_invalid')));
