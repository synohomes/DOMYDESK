<?php
// Ancien endpoint de l'installateur "online" : volontairement neutralisé.
// DMD-Installer AUTONOME-H264-WS contient déjà DMD-Agent/Update/Remote.
http_response_code(410);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
echo json_encode(array(
    'ok' => false,
    'code' => 'online_installer_retired',
    'message' => 'Cet endpoint est désactivé. Utiliser DMD-Installer AUTONOME-H264-WS.'
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
