<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$payload);
$action=strtolower(trim((string)($payload['action']??'')));

function dmd_maint_update_dir(){ return dirname(dirname(dirname(__DIR__))) . '/updates'; }
function dmd_maint_is_pe($file){
    if(!is_file($file)||!is_readable($file)||(int)filesize($file)<2)return false;
    $fh=@fopen($file,'rb');if(!$fh)return false;$magic=fread($fh,2);fclose($fh);return $magic==='MZ';
}
function dmd_maint_version_parts($version){
    $version=trim((string)$version);
    if(!preg_match('/^(\d+)\.(\d+)\.(\d+)(?:[-_].*)?$/',$version,$m))return null;
    return array((int)$m[1],(int)$m[2],(int)$m[3]);
}
function dmd_maint_version_compare($a,$b){
    $av=dmd_maint_version_parts($a);$bv=dmd_maint_version_parts($b);
    if($av&&$bv){
        $aLegacy=$av[0]===29&&$av[1]===9;
        $bLegacy=$bv[0]===29&&$bv[1]===9;
        $aCanonical=$av[0]===26;
        $bCanonical=$bv[0]===26;
        // Migration de la série publiée par erreur en 29.09.xxx vers la
        // nomenclature canonique 26.09.xxx. À build égal, le bridge legacy
        // reste prioritaire ; dès que le build canonique est supérieur, il
        // devient la version disponible.
        if($aCanonical&&$bLegacy){
            if($av[1]>9)return 1;
            if($av[1]<9)return -1;
            if($av[2]>$bv[2])return 1;
            if($av[2]<$bv[2])return -1;
            return -1;
        }
        if($aLegacy&&$bCanonical){
            if($bv[1]>9)return -1;
            if($bv[1]<9)return 1;
            if($bv[2]>$av[2])return -1;
            if($bv[2]<$av[2])return 1;
            return 1;
        }
    }
    return version_compare((string)$a,(string)$b);
}
function dmd_maint_update_packages(){
    $dir=dmd_maint_update_dir();if(!is_dir($dir))return array();$out=array();
    foreach((array)glob($dir.'/update.*.exe') as $file){
        $name=basename($file);
        if(!preg_match('/^update\.([0-9A-Za-z][0-9A-Za-z._-]{0,31})\.exe$/i',$name,$m))continue;
        $version=(string)$m[1];
        $bootstrapName='DMD-Agent.'.$version.'.exe';
        $bootstrap=$dir.'/'.$bootstrapName;
        if(!dmd_maint_is_pe($file)||!dmd_maint_is_pe($bootstrap))continue;
        $out[]=array(
            'file'=>$file,'name'=>$name,'version'=>$version,'size'=>(int)filesize($file),
            'bootstrap_file'=>$bootstrap,'bootstrap_name'=>$bootstrapName,'bootstrap_size'=>(int)filesize($bootstrap)
        );
    }
    usort($out,function($a,$b){return dmd_maint_version_compare((string)$b['version'],(string)$a['version']);});
    return $out;
}
function dmd_maint_update_latest(){ $rows=dmd_maint_update_packages();return $rows?$rows[0]:array(); }
function dmd_maint_update_find($version){
    $version=trim((string)$version);
    if($version==='')return array();
    foreach(dmd_maint_update_packages() as $row){if(strcasecmp((string)($row['version']??''),$version)===0)return $row;}
    return array();
}
function dmd_maint_agent_ids($raw){$out=array();foreach((array)$raw as $id){$id=dmd_agent_safe_agent_id($id);if($id!=='')$out[$id]=$id;}return array_values($out);}
function dmd_maint_stage_command($agentId,$version,$stage){
    foreach(dmd_agent_command_history($agentId,30) as $cmd){
        if(!is_array($cmd)||(string)($cmd['type']??'')!=='update_agent')continue;
        $p=(isset($cmd['payload'])&&is_array($cmd['payload']))?$cmd['payload']:array();
        if((string)($p['version']??'')!==$version||(string)($p['stage']??'')!==$stage)continue;
        return $cmd;
    }
    return array();
}
function dmd_maint_reboot_policy($raw){
    if(!is_array($raw))$raw=array();
    $mode=strtolower(trim((string)($raw['mode']??'none')));
    if(!in_array($mode,array('none','now','countdown','at'),true))$mode='none';
    $delay=(int)($raw['delay_seconds']??900);
    $delay=max(60,min(604800,$delay));
    $executeAt=(int)($raw['execute_at_ts']??0);
    $now=time();
    if($mode==='now')$delay=60;
    if($mode==='at'){
        if($executeAt<$now+60)$executeAt=$now+60;
        if($executeAt>$now+604800)$executeAt=$now+604800;
    }else{
        $executeAt=0;
    }
    $message=trim((string)($raw['message']??'DoMyDesk : redémarrage planifié après maintenance. Enregistrez votre travail.'));
    $message=preg_replace('/[\x00-\x1F\x7F]+/u',' ',$message);
    if(!is_string($message)||$message==='')$message='DoMyDesk : redémarrage planifié après maintenance. Enregistrez votre travail.';
    if(strlen($message)>260)$message=substr($message,0,260);
    return array(
        'mode'=>$mode,
        'delay_seconds'=>$mode==='countdown'||$mode==='now'?$delay:0,
        'execute_at_ts'=>$mode==='at'?$executeAt:0,
        'message'=>$message,
        'notify_user'=>true,
    );
}
function dmd_maint_queue_stage($agentId,$stage,$version,$url,$sha,$force,$email,$rebootPolicy=array()){
    $commandPayload=array(
        'version'=>$version,'url'=>$url,'sha256'=>$sha,'force'=>$force,
        'authenticode_thumbprint'=>'','stage'=>$stage
    );
    if($stage==='package'){
        $policy=dmd_maint_reboot_policy($rebootPolicy);
        $commandPayload['reboot_mode']=$policy['mode'];
        $commandPayload['reboot_delay_seconds']=$policy['delay_seconds'];
        $commandPayload['reboot_execute_at_ts']=$policy['execute_at_ts'];
        $commandPayload['reboot_message']=$policy['message'];
        $commandPayload['reboot_notify_user']=true;
    }
    return dmd_agent_queue_command($agentId,'update_agent',$commandPayload,$email,'core.update',1800);
}

if($action==='agent_binary_info'){
    $requestedVersion=trim((string)($payload['version']??''));
    $pkg=$requestedVersion!==''?dmd_maint_update_find($requestedVersion):dmd_maint_update_latest();
    if(!$pkg)dmd_json_response(array('ok'=>false,'error'=>'update_package_pair_missing'),404);
    dmd_json_response(array(
        'ok'=>true,'version'=>$pkg['version'],'filename'=>$pkg['name'],'bootstrap_filename'=>$pkg['bootstrap_name'],
        'sha256'=>strtolower((string)hash_file('sha256',$pkg['file'])),'size'=>$pkg['size'],
        'bootstrap_sha256'=>strtolower((string)hash_file('sha256',$pkg['bootstrap_file'])),'bootstrap_size'=>$pkg['bootstrap_size']
    ));
}

if($action==='agent_update'){
    $ids=dmd_maint_agent_ids($payload['agent_ids']??array());if(!$ids)dmd_json_response(array('ok'=>false,'error'=>'agent_ids_missing'),400);
    $requestedVersion=trim((string)($payload['version']??''));
    $pkg=$requestedVersion!==''?dmd_maint_update_find($requestedVersion):dmd_maint_update_latest();
    if(!$pkg)dmd_json_response(array('ok'=>false,'error'=>$requestedVersion!==''?'update_version_not_found':'update_package_pair_missing','version'=>$requestedVersion),404);
    $version=(string)$pkg['version'];$force=!empty($payload['force']);
    $packageSha=strtolower((string)hash_file('sha256',$pkg['file']));
    $bootstrapSha=strtolower((string)hash_file('sha256',$pkg['bootstrap_file']));
    $rebootPolicy=dmd_maint_reboot_policy(isset($payload['reboot_policy'])&&is_array($payload['reboot_policy'])?$payload['reboot_policy']:array());
    $rebootAgentIds=dmd_maint_agent_ids($payload['reboot_agent_ids']??array());
    $rebootSet=array_fill_keys($rebootAgentIds,true);
    $commands=array();
    foreach($ids as $agentId){
        $deviceFile=dmd_agent_device_file($agentId);$device=($deviceFile!==''&&is_file($deviceFile))?dmd_agent_json_read($deviceFile,array()):array();
        if(!$device||($device['status']??'')!=='active'){$commands[]=array('agent_id'=>$agentId,'status'=>'error','stage'=>'error','error'=>'agent_not_active');continue;}
        $enrollment=!empty($device['enrollment_id'])?dmd_agent_load_enrollment($device['enrollment_id']):array();
        $serverUrl=rtrim((string)($enrollment['server_url']??''),'/');if($serverUrl===''){$commands[]=array('agent_id'=>$agentId,'status'=>'error','stage'=>'error','error'=>'server_url_missing');continue;}
        $currentVersion=trim((string)($device['agent_version']??''));
        $updateProtocol=max(0,(int)($device['update_protocol']??0));
        $agentRebootPolicy=isset($rebootSet[$agentId])?$rebootPolicy:dmd_maint_reboot_policy(array('mode'=>'none'));

        // Seuls les anciens Agents (sans protocole update v2) reçoivent le
        // binaire de transition DMD-Agent.<version>.exe. Un Agent v2 reçoit
        // toujours le package autonome update.<version>.exe, même si sa version
        // actuelle est différente de la version cible.
        if($updateProtocol<2){
            $previous=dmd_maint_stage_command($agentId,$version,'bootstrap');
            $prevStatus=strtolower((string)($previous['status']??''));
            $prevCompleted=(int)($previous['completed_ts']??0);
            if(in_array($prevStatus,array('queued','delivered'),true)){
                $commands[]=array('agent_id'=>$agentId,'status'=>$prevStatus,'stage'=>'bootstrap_wait','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>'','reboot_policy'=>$agentRebootPolicy);
                continue;
            }
            if($prevStatus==='completed'&&$prevCompleted>0&&(time()-$prevCompleted)<120){
                $commands[]=array('agent_id'=>$agentId,'status'=>'waiting','stage'=>'bootstrap_wait','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>'Attente du redémarrage du nouvel Agent','reboot_policy'=>$agentRebootPolicy);
                continue;
            }
            if($prevStatus==='completed'){
                $commands[]=array('agent_id'=>$agentId,'status'=>'error','stage'=>'error','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>'Le nouvel Agent ne s’est pas reconnecté après le bootstrap','reboot_policy'=>$agentRebootPolicy);
                continue;
            }
            if(in_array($prevStatus,array('failed','expired','cancelled'),true)){
                $commands[]=array('agent_id'=>$agentId,'status'=>'error','stage'=>'error','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>(string)($previous['error']??'Échec du bootstrap Agent'),'reboot_policy'=>$agentRebootPolicy);
                continue;
            }
            $url=$serverUrl.'/updates/'.rawurlencode($pkg['bootstrap_name']);
            $q=dmd_maint_queue_stage($agentId,'bootstrap',$version,$url,$bootstrapSha,true,$email,array('mode'=>'none'));
            $commands[]=array('agent_id'=>$agentId,'status'=>!empty($q['ok'])?'queued':'error','stage'=>'bootstrap','command_id'=>$q['command']['command_id']??'','version'=>$version,'error'=>$q['error']??'','reboot_policy'=>$agentRebootPolicy);
            continue;
        }

        $previous=dmd_maint_stage_command($agentId,$version,'package');
        $prevStatus=strtolower((string)($previous['status']??''));
        if(in_array($prevStatus,array('queued','delivered','downloading','verified','installing'),true)){
            $commands[]=array('agent_id'=>$agentId,'status'=>$prevStatus,'stage'=>'package','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>'','reboot_policy'=>$agentRebootPolicy);
            continue;
        }
        if($prevStatus==='completed'&&!$force){
            $commands[]=array('agent_id'=>$agentId,'status'=>'completed','stage'=>'package','command_id'=>$previous['command_id']??'','version'=>$version,'error'=>'','reboot_policy'=>$agentRebootPolicy);
            continue;
        }
        $url=$serverUrl.'/updates/'.rawurlencode($pkg['name']);
        // Après un bootstrap legacy, DMD-Agent porte déjà la version cible mais
        // DMD-Update/Remote/MyDesk n'ont pas encore été remplacés. Dans ce cas
        // le package complet doit impérativement être forcé une première fois.
        $packageForce=$force||strcasecmp($currentVersion,$version)===0;
        $q=dmd_maint_queue_stage($agentId,'package',$version,$url,$packageSha,$packageForce,$email,$agentRebootPolicy);
        $commands[]=array('agent_id'=>$agentId,'status'=>!empty($q['ok'])?'queued':'error','stage'=>'package','command_id'=>$q['command']['command_id']??'','version'=>$version,'error'=>$q['error']??'','reboot_policy'=>$agentRebootPolicy);
    }
    dmd_system_log('agent_bulk_update','maintenance','warning','Mise à jour DoMyDesk demandée.',array(
        'agents'=>$ids,'version'=>$version,'requested_version'=>$requestedVersion,'package'=>$pkg['name'],'bootstrap'=>$pkg['bootstrap_name'],'force'=>$force,
        'reboot_policy'=>$rebootPolicy,'reboot_agents'=>$rebootAgentIds,
    ));
    dmd_json_response(array('ok'=>true,'commands'=>$commands,'version'=>$version,'filename'=>$pkg['name'],'bootstrap_filename'=>$pkg['bootstrap_name'],'sha256'=>$packageSha,'reboot_policy'=>$rebootPolicy,'reboot_agents'=>$rebootAgentIds));
}


if($action==='agent_runtime_info'){
    $agentId=dmd_agent_safe_agent_id($payload['agent_id']??'');
    if($agentId==='')dmd_json_response(array('ok'=>false,'error'=>'agent_invalid'),400);
    $deviceFile=dmd_agent_device_file($agentId);
    $device=($deviceFile!==''&&is_file($deviceFile))?dmd_agent_json_read($deviceFile,array()):array();
    if(!$device)dmd_json_response(array('ok'=>false,'error'=>'agent_not_found'),404);
    $pkg=dmd_maint_update_latest();
    $lastSeenTs=0;
    $lastSeenRaw=(string)($device['last_seen_at']??'');
    if($lastSeenRaw!==''){$tmp=@strtotime($lastSeenRaw);if($tmp!==false)$lastSeenTs=(int)$tmp;}
    dmd_json_response(array(
        'ok'=>true,
        'agent'=>array(
            'agent_id'=>$agentId,
            'hostname'=>(string)($device['hostname']??''),
            'agent_version'=>(string)($device['agent_version']??''),
            'update_protocol'=>(int)($device['update_protocol']??0),
            'last_ip'=>(string)($device['last_ip']??''),
            'last_seen_at'=>$lastSeenRaw,
            'online'=>$lastSeenTs>0 && (time()-$lastSeenTs)<=180,
            'status'=>(string)($device['status']??''),
        ),
        'package'=>$pkg?array(
            'version'=>(string)$pkg['version'],
            'filename'=>(string)$pkg['name'],
            'bootstrap_filename'=>(string)$pkg['bootstrap_name'],
            'size'=>(int)$pkg['size'],
            'bootstrap_size'=>(int)$pkg['bootstrap_size'],
        ):null,
    ));
}

if($action==='windows_update'){
    $ids=dmd_maint_agent_ids($payload['agent_ids']??array());if(!$ids)dmd_json_response(array('ok'=>false,'error'=>'agent_ids_missing'),400);
    $mode=strtolower(trim((string)($payload['mode']??'scan')));if(!in_array($mode,array('scan','install'),true))dmd_json_response(array('ok'=>false,'error'=>'mode_invalid'),400);
    $commandType=$mode==='scan'?'windows_update.scan':'windows_update.install';$ttl=$mode==='scan'?600:3600;$commands=array();
    foreach($ids as $agentId){$commandPayload=$mode==='install'?array('all'=>true,'update_ids'=>array()):array();$q=dmd_agent_queue_command($agentId,$commandType,$commandPayload,$email,'software.update',$ttl);$commands[]=array('agent_id'=>$agentId,'status'=>!empty($q['ok'])?'queued':'error','command_id'=>$q['command']['command_id']??'','error'=>$q['error']??'');}
    dmd_system_log('agent_windows_update_'.$mode,'maintenance','warning','Commande Windows Update groupée.',array('agents'=>$ids,'mode'=>$mode));
    dmd_json_response(array('ok'=>true,'commands'=>$commands));
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'),400);
