<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$rows = isset($payload['rows']) && is_array($payload['rows']) ? array_slice($payload['rows'], 0, 600) : array();
$filters = isset($payload['filters']) && is_array($payload['filters']) ? $payload['filters'] : array();
if (!$rows) dmd_json_response(array('ok'=>false,'error'=>'Aucune entrée à exporter.'), 400);

function dmd_update_pdf_text($s){
    $s=(string)$s;
    if(function_exists('iconv')){$x=@iconv('UTF-8','Windows-1252//TRANSLIT',$s);if($x!==false)$s=$x;}
    return str_replace(array('\\','(',')',"\r","\n","\t"),array('\\\\','\\(','\\)',' ',' ',' '),$s);
}
function dmd_update_pdf_obj($id,$body){return $id." 0 obj\n".$body."\nendobj\n";}
function dmd_update_pdf_cut($s,$max){$s=trim((string)$s);return strlen($s)>$max?substr($s,0,max(0,$max-3)).'...':$s;}
function dmd_update_pdf_wrap($s,$maxChars,$maxLines=4){
    $s=trim(preg_replace('/\s+/',' ',(string)$s));
    if($s==='')return array('—');
    $words=preg_split('/\s+/',$s);$lines=array();$line='';
    foreach($words as $word){
        if(strlen($word)>$maxChars){
            if($line!==''){$lines[]=$line;$line='';}
            while(strlen($word)>$maxChars){$lines[]=substr($word,0,$maxChars);$word=substr($word,$maxChars);if(count($lines)>=$maxLines)break 2;}
            $line=$word;continue;
        }
        $candidate=$line===''?$word:$line.' '.$word;
        if(strlen($candidate)<=$maxChars){$line=$candidate;}else{$lines[]=$line;$line=$word;if(count($lines)>=$maxLines)break;}
    }
    if(count($lines)<$maxLines&&$line!=='')$lines[]=$line;
    if(count($lines)>$maxLines)$lines=array_slice($lines,0,$maxLines);
    if($lines){
        $joined=implode(' ',$lines);
        if(strlen($joined)<strlen($s))$lines[count($lines)-1]=rtrim(substr($lines[count($lines)-1],0,max(0,$maxChars-3))).'...';
    }
    return $lines?:array('—');
}
function dmd_update_pdf_date($row){
    $ts=(int)($row['timestamp']??0);
    if($ts>0)return date('d/m/Y H:i:s',$ts);
    $iso=trim((string)($row['date_iso']??''));
    if($iso!==''){$t=@strtotime($iso);if($t!==false)return date('d/m/Y H:i:s',$t);}
    return '—';
}
function dmd_update_pdf_actor($row){
    $name=trim((string)($row['actor_name']??''));$mail=trim((string)($row['actor']??''));
    if($name!==''&&$mail!=='')return $name.' - '.$mail;
    return $name!==''?$name:($mail!==''?$mail:'Système / Agent');
}
function dmd_update_pdf_clean_row($r){
    if(!is_array($r))$r=array();
    $status=strtolower(trim((string)($r['status']??'')));
    $state=trim((string)($r['state']??''));
    if($state==='')$state=$status==='success'?'Réussite':($status==='error'?'Échec':'En cours');
    $cause=trim((string)($r['cause']??''));
    if($cause==='')$cause=$status==='success'?'Mise à jour terminée avec succès.':'—';
    return array(
        'date'=>dmd_update_pdf_date($r),
        'actor'=>dmd_update_pdf_actor($r),
        'action'=>trim((string)($r['action']??'Mise à jour Agent')),
        'target'=>trim((string)($r['hostname']??$r['agent_id']??'—')),
        'build'=>trim((string)($r['build']??'—')),
        'state'=>$state,
        'cause'=>$cause,
    );
}
function dmd_update_pdf_page_header($pageNo,$pageCount,$filterText){
    $c="0.45 w\n";
    $c.="BT /F1 15 Tf 30 558 Td (".dmd_update_pdf_text('DoMyDesk - Journal des mises à jour Agent').") Tj ET\n";
    $sub='Export: '.date('d/m/Y H:i:s').' | Entrées exportées: '.$GLOBALS['dmd_update_pdf_row_count'];
    if($filterText!=='')$sub.=' | Filtres: '.$filterText;
    $c.="BT /F1 7.5 Tf 30 543 Td (".dmd_update_pdf_text(dmd_update_pdf_cut($sub,150)).") Tj ET\n";
    $c.="BT /F1 7 Tf 750 20 Td (".dmd_update_pdf_text('Page '.$pageNo.' / '.$pageCount).") Tj ET\n";
    return $c;
}
function dmd_update_pdf_table_header($y){
    $headers=array(array(30,'Date / heure'),array(126,'Utilisateur'),array(245,'Action'),array(350,'PC / cible'),array(452,'Build'),array(520,'Résultat'),array(590,'Cause / détail'));
    $c="30 $y m 812 $y l S\n";
    foreach($headers as $h)$c.="BT /F1 7 Tf ".$h[0]." ".($y-12)." Td (".dmd_update_pdf_text($h[1]).") Tj ET\n";
    $c.="30 ".($y-18)." m 812 ".($y-18)." l S\n";
    return $c;
}
function dmd_update_pdf_build($rows,$filters){
    $clean=array_map('dmd_update_pdf_clean_row',$rows);
    $GLOBALS['dmd_update_pdf_row_count']=count($clean);
    $filterBits=array();
    $st=trim((string)($filters['status']??''));if($st!==''&&$st!=='all')$filterBits[]='état='.$st;
    $q=trim((string)($filters['search']??''));if($q!=='')$filterBits[]='recherche='.dmd_update_pdf_cut($q,45);
    $filterText=implode(', ',$filterBits);
    $cols=array(
        array('key'=>'date','x'=>30,'chars'=>23,'lines'=>2),
        array('key'=>'actor','x'=>126,'chars'=>27,'lines'=>3),
        array('key'=>'action','x'=>245,'chars'=>24,'lines'=>3),
        array('key'=>'target','x'=>350,'chars'=>22,'lines'=>3),
        array('key'=>'build','x'=>452,'chars'=>15,'lines'=>2),
        array('key'=>'state','x'=>520,'chars'=>15,'lines'=>2),
        array('key'=>'cause','x'=>590,'chars'=>48,'lines'=>4),
    );
    $pages=array();$current=array();$y=505;
    foreach($clean as $row){
        $wrapped=array();$maxLines=1;
        foreach($cols as $col){$lines=dmd_update_pdf_wrap($row[$col['key']]??'',$col['chars'],$col['lines']);$wrapped[$col['key']]=$lines;$maxLines=max($maxLines,count($lines));}
        $height=max(18,7+$maxLines*8);
        if($y-$height<40&&$current){$pages[]=$current;$current=array();$y=505;}
        $current[]=array('row'=>$row,'wrapped'=>$wrapped,'height'=>$height);
        $y-=$height;
    }
    if($current||!$pages)$pages[]=$current;
    $contents=array();$pageCount=count($pages);
    foreach($pages as $pi=>$items){
        $c=dmd_update_pdf_page_header($pi+1,$pageCount,$filterText);
        $y=523;$c.=dmd_update_pdf_table_header($y);$y-=18;
        foreach($items as $item){
            $h=$item['height'];$top=$y;$base=$top-10;
            foreach($cols as $col){
                $lines=$item['wrapped'][$col['key']]??array('—');
                foreach($lines as $li=>$line){$ty=$base-$li*8;$c.="BT /F1 6.2 Tf ".$col['x']." $ty Td (".dmd_update_pdf_text($line).") Tj ET\n";}
            }
            $y-=$h;$c.="30 $y m 812 $y l S\n";
        }
        $contents[]=$c;
    }
    $objects=array(1=>'<< /Type /Catalog /Pages 2 0 R >>',3=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    $kids=array();$next=4;
    foreach($contents as $content){$contentId=$next++;$pageId=$next++;$objects[$contentId]='<< /Length '.strlen($content).' >>'."\nstream\n".$content."endstream";$objects[$pageId]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents '.$contentId.' 0 R >>';$kids[]=$pageId.' 0 R';}
    $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';ksort($objects);
    $pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=array(0=>0);$max=max(array_keys($objects));
    for($i=1;$i<=$max;$i++){if(!isset($objects[$i]))continue;$offsets[$i]=strlen($pdf);$pdf.=dmd_update_pdf_obj($i,$objects[$i]);}
    $xref=strlen($pdf);$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";
    for($i=1;$i<=$max;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i]??0)."\n";
    $pdf.="trailer\n<< /Size ".($max+1)." /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
    return $pdf;
}

$pdf=dmd_update_pdf_build($rows,$filters);
dmd_system_log('agent_update_logs_export','maintenance','info','Export PDF du journal des mises à jour Agent.',array('rows'=>count($rows),'filters'=>$filters));
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="DMD-Agent-Journal-Mises-a-jour-'.date('Ymd-His').'.pdf"');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Content-Length: '.strlen($pdf));
echo $pdf;
exit;
