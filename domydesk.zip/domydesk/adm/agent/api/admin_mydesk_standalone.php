<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$serverUrl = rtrim(trim((string)($payload['server_url'] ?? '')), '/');
$check = dmd_agent_validate_server_url($serverUrl);
if (empty($check['ok'])) dmd_json_response($check, 400);
$issued = dmd_agent_mydesk_client_issue($check['server_url'], '', $email);
if (empty($issued['ok'])) dmd_json_response($issued, 400);
$bootstrap = json_encode($issued['bootstrap'], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if ($bootstrap === false) dmd_json_response(array('ok'=>false,'error'=>'mydesk_bootstrap_encode_failed'),500);
$bootstrap .= "\n";

$binDir = dirname(__DIR__) . '/bin/windows-x64';
$names = array('DMD-MyDesk-Setup.exe','DMD-MyDesk.exe','domydesk.ico');
if (is_file($binDir.'/WebView2Loader.dll')) $names[]='WebView2Loader.dll';
$files=array();
foreach($names as $name){
    $path=$binDir.'/'.$name;
    if(!is_file($path)) dmd_json_response(array('ok'=>false,'error'=>'binary_missing','file'=>$name),404);
    $raw=@file_get_contents($path);$isExe=strtolower(pathinfo($name,PATHINFO_EXTENSION))==='exe';
    if($raw===false||($isExe&&substr($raw,0,2)!=='MZ')) dmd_json_response(array('ok'=>false,'error'=>'binary_invalid','file'=>$name),500);
    $files[$name]=$raw;
}
$files['mydesk-bootstrap.json']=$bootstrap;
$manifest='';foreach($files as $name=>$raw)$manifest.=hash('sha256',$raw).'  '.$name."\r\n";
$files['MANIFEST-SHA256.txt']=$manifest;
$files['LISEZ-MOI.txt'] =
    "DMD-MyDesk 1.13.3 - installation autonome\r\n\r\n".
    "Ce package installe DMD-MyDesk SANS installer ni modifier DMD-Agent.\r\n".
    "1. Extraire entièrement ce ZIP sur le PC.\r\n".
    "2. Lancer DMD-MyDesk-Setup.exe en administrateur.\r\n".
    "3. DMD-MyDesk reçoit sa propre identité cliente liée à cette instance DoMyDesk.\r\n\r\n".
    "Le bootstrap est signé par l'instance et supprimé après installation.\r\n";

function dmd_mydesk_1133_zip_time($ts){$p=getdate($ts);$y=max(1980,min(2107,(int)$p['year']));return array(((int)$p['hours']<<11)|((int)$p['minutes']<<5)|((int)$p['seconds']>>1),(($y-1980)<<9)|((int)$p['mon']<<5)|(int)$p['mday']);}
function dmd_mydesk_1133_zip_store($files){list($t,$d)=dmd_mydesk_1133_zip_time(time());$body='';$central='';$off=0;$count=0;foreach($files as $name=>$content){$name=ltrim(str_replace('\\','/',(string)$name),'/');if($name===''||strpos($name,'../')!==false)continue;$content=(string)$content;$size=strlen($content);$crc=crc32($content);$local=pack('VvvvvvVVVvv',0x04034b50,20,0,0,$t,$d,$crc,$size,$size,strlen($name),0).$name;$body.=$local.$content;$central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,$t,$d,$crc,$size,$size,strlen($name),0,0,0,0,0,$off).$name;$off+=strlen($local)+$size;$count++;}return $body.$central.pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($central),strlen($body),0);}
$zip=dmd_mydesk_1133_zip_store($files);
dmd_agent_log('mydesk_standalone_pack_generated','success',array('client_id'=>$issued['client']['client_id']??'','actor'=>$email));
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="DMD-MyDesk-1.13.3-Windows-x64.zip"');
header('Content-Length: '.strlen($zip));
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-DMD-MyDesk-Version: 1.13.3');
echo $zip;exit;
