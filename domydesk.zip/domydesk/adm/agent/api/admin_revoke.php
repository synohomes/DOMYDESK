<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$id = isset($payload['agent_id']) ? $payload['agent_id'] : '';
$reason = isset($payload['reason']) ? $payload['reason'] : '';
$result = dmd_agent_revoke_device($id, $email, $reason);
if (!empty($result['ok'])) {
    dmd_system_log('agent_revoked', $id, 'warning', 'Révocation et purge d’un DMD-Agent.', array('audit_id'=>isset($result['audit_id'])?$result['audit_id']:'','reason'=>$reason));
}
dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
