<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$payload);
$action=isset($payload['action'])?(string)$payload['action']:'';
$result=array('ok'=>false,'error'=>'action_invalid');
switch($action){
    case 'save_pc_group':
        $result=dmd_agent_access_save_pc_group($payload['group_id']??'', $payload['name']??'', $payload['description']??'', $payload['agent_ids']??array(), $email); break;
    case 'delete_pc_group':
        $result=dmd_agent_access_delete_pc_group($payload['group_id']??'', $email); break;
    case 'save_user_group':
        $result=dmd_agent_access_save_user_group($payload['group_id']??'', $payload['name']??'', $payload['description']??'', $payload['users']??array(), $email); break;
    case 'delete_user_group':
        $result=dmd_agent_access_delete_user_group($payload['group_id']??'', $email); break;
    case 'save_policy':
        $result=dmd_agent_access_save_policy($payload['policy_id']??'', $payload['subject_type']??'', $payload['subject_id']??'', !empty($payload['all_pcs']), $payload['pc_group_ids']??array(), $payload['agent_ids']??array(), $payload['permissions']??array(), $email); break;
    case 'delete_policy':
        $result=dmd_agent_access_delete_policy($payload['policy_id']??'', $email); break;
}
if(!empty($result['ok'])) dmd_system_log('agent_admin_access_updated',$action,'success','Administration des groupes/droits DMD-Agent mise à jour.',array('action'=>$action,'actor'=>$email));
dmd_json_response($result,!empty($result['ok'])?200:400);
