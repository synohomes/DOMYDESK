<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/remote_ws.php';

dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$action = trim((string)($payload['action'] ?? ''));

if ($action === 'read') {
    $settings = dmd_remote_ws_internet_settings_read();
    dmd_json_response(array(
        'ok'=>true,
        'settings'=>$settings,
        'status'=>dmd_remote_ws_internet_status($settings),
    ));
}

if ($action === 'save') {
    $result = dmd_remote_ws_internet_settings_write(array(
        'enabled'=>!empty($payload['enabled']),
        'public_base_url'=>$payload['public_base_url'] ?? '',
        'ws_path'=>$payload['ws_path'] ?? '',
        'proxy_mode'=>$payload['proxy_mode'] ?? 'auto',
    ), $email);
    if (empty($result['ok'])) dmd_json_response($result, 400);

    // Prépare la configuration du relais pour son prochain démarrage.
    // Aucun arrêt/redémarrage du processus actif n'est déclenché ici.
    $relayConfig = dmd_remote_ws_prepare_config();
    if (empty($relayConfig['ok'])) {
        dmd_system_log('agent_remote_internet_settings', 'save', 'warning', 'Configuration Internet Remote enregistrée, mais préparation du relais impossible.', array('actor'=>$email,'error'=>$relayConfig['error'] ?? 'unknown'));
    } else {
        dmd_system_log('agent_remote_internet_settings', 'save', 'success', 'Configuration Internet Remote enregistrée.', array('actor'=>$email,'settings'=>$result['settings']));
    }

    dmd_json_response(array(
        'ok'=>true,
        'settings'=>$result['settings'],
        'relay_config_ok'=>!empty($relayConfig['ok']),
        'status'=>dmd_remote_ws_internet_status($result['settings']),
    ));
}

if ($action === 'test') {
    $settings = dmd_remote_ws_internet_settings_read();
    dmd_json_response(array(
        'ok'=>true,
        'settings'=>$settings,
        'status'=>dmd_remote_ws_internet_status($settings),
    ));
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
