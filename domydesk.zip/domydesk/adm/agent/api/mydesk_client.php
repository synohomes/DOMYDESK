<?php
require_once dirname(__DIR__) . '/includes/agent_core.php';
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    http_response_code(405); header('Allow: POST'); exit;
}
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$raw = (string)file_get_contents('php://input');
if (strlen($raw) > 1048576) { http_response_code(413); exit; }
$auth = dmd_agent_mydesk_client_validate_request($raw, 'POST', '/adm/agent/api/mydesk_client.php');
if (empty($auth['ok'])) {
    http_response_code((int)($auth['http'] ?? 403));
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array('ok'=>false,'error'=>(string)($auth['error']??'request_refused')));
    exit;
}
$client = $auth['client']; $nonce = (string)$auth['nonce'];
$body = json_decode($raw, true); if (!is_array($body)) $body = array();
$action = strtolower(trim((string)($body['action'] ?? '')));
$runtime = dmd_agent_mydesk_client_context($body);
$data = array(); $ok = true; $error = '';

switch ($action) {
    case 'catalog':
        $catalog = dmd_agent_mydesk_public_catalog(array(), $runtime);
        $limit = dmd_agent_mydesk_license_limit();
        $settings = dmd_agent_mydesk_settings_read(); $configured = 0;
        foreach (dmd_agent_mydesk_manifest_modules() as $m) if (dmd_agent_mydesk_module_enabled($m,$settings)) $configured++;
        if ($limit >= 0 && $configured > $limit) { $ok=false; $error='mydesk_license_configuration_invalid'; break; }
        $data = array(
            'modules'=>$catalog,
            'agent_id'=>(string)(dmd_agent_mydesk_device_for_enrollment((string)($client['linked_enrollment_id']??''))['agent_id']??''),
            'license_envelope'=>function_exists('dmd_license_raw_envelope') ? dmd_license_raw_envelope() : '',
            'license_state'=>dmd_agent_mydesk_license_state(),
        );
        break;
    case 'launch':
        $moduleId = trim((string)($body['module_id'] ?? ''));
        $r = dmd_agent_mydesk_client_launch_token_create($client, $moduleId, $runtime);
        if (empty($r['ok'])) { $ok=false; $error=(string)($r['error']??'launch_refused'); break; }
        $data = array('launch_url'=>$r['launch_url'],'agent_id'=>(string)($r['agent_id']??''));
        break;
    case 'notifications':
        $data = array('notifications'=>dmd_agent_mydesk_notifications_for_client($client,(int)($body['limit']??5)));
        break;
    case 'notifications_ack':
        $data = array('acked'=>dmd_agent_mydesk_notifications_ack_client($client,(array)($body['ids']??array())));
        break;
    case 'license':
        $data = array('license_envelope'=>function_exists('dmd_license_raw_envelope') ? dmd_license_raw_envelope() : '', 'license_state'=>dmd_agent_mydesk_license_state());
        break;
    default:
        $ok=false; $error='action_invalid';
}

$resp = dmd_agent_mydesk_client_signed_response($client,$nonce,$data,$ok,$error);
if (!is_array($resp)) { http_response_code(500); exit; }
header('Content-Type: application/json; charset=utf-8');
echo json_encode($resp, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
