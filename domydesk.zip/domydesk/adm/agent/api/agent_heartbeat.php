<?php
require_once __DIR__ . '/_public.php';
$payload = dmd_agent_public_body();
$validated = dmd_agent_signed_request_validate($payload, 'POST', '/adm/agent/api/agent_heartbeat.php', dmd_agent_remote_ip());
if (empty($validated['ok'])) dmd_agent_public_send($validated);
$device = $validated['device'];
$body = $validated['body'];
$device['last_seen_at'] = gmdate('c');
$device['last_seen_ts'] = time();

// Conserver l'adresse de transport réelle pour l'audit, mais utiliser
// exclusivement une IPv4 remontée par le poste dans le parc / l'interface.
// Ainsi une connexion HTTP en IPv6 (ex. fe80::...) ne remplace plus l'IPv4
// du PC dans DoMyDesk.
$transportIp = trim((string)dmd_agent_remote_ip());
$device['last_transport_ip'] = $transportIp;
$reportedIpv4 = '';
if (isset($body['inventory']) && is_array($body['inventory'])) {
    $inv = $body['inventory'];
    $candidates = array();
    if (isset($inv['active_interface']) && is_array($inv['active_interface'])) {
        $candidates[] = $inv['active_interface']['ipv4'] ?? '';
    }
    if (isset($inv['network']) && is_array($inv['network'])) {
        foreach ($inv['network'] as $iface) {
            if (!is_array($iface) || !isset($iface['ips']) || !is_array($iface['ips'])) continue;
            foreach ($iface['ips'] as $ipValue) $candidates[] = $ipValue;
        }
    }
    foreach ($candidates as $candidate) {
        $candidate = trim((string)$candidate);
        if (($slash = strpos($candidate, '/')) !== false) $candidate = substr($candidate, 0, $slash);
        if (!filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) continue;
        if (strpos($candidate, '127.') === 0 || $candidate === '0.0.0.0') continue;
        $reportedIpv4 = $candidate;
        break;
    }
}
if ($reportedIpv4 === '' && filter_var($transportIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    $reportedIpv4 = $transportIp;
}
if ($reportedIpv4 === '') {
    $existingIpv4 = trim((string)($device['last_ip'] ?? ''));
    if (filter_var($existingIpv4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) $reportedIpv4 = $existingIpv4;
}
$device['last_ip'] = $reportedIpv4 !== '' ? $reportedIpv4 : 'IP inconnue';
if (!empty($body['agent_version'])) $device['agent_version'] = substr((string)$body['agent_version'], 0, 64);
if (isset($body['update_protocol'])) $device['update_protocol'] = max(0, min(9, (int)$body['update_protocol']));
if (isset($body['inventory']) && is_array($body['inventory'])) {
    $device['last_inventory'] = $body['inventory'];

    // Conserver définitivement le nom donné lors de l'enrôlement.
    // Pour les anciennes fiches, le resolver sait aussi le récupérer dans
    // security-*.php via enrollment_created si l'historique a été supprimé.
    if (trim((string)($device['enrollment_name'] ?? '')) === '') {
        $enrollmentName = function_exists('dmd_agent_enrollment_name_for_device')
            ? dmd_agent_enrollment_name_for_device($device)
            : '';

        if ($enrollmentName !== ''
            && strlen($enrollmentName) <= 255
            && !preg_match('/[\x00-\x1F\x7F]/', $enrollmentName)) {
            $device['enrollment_name'] = $enrollmentName;
        }
    }

    // Le PC peut être renommé après son enrôlement. Le hostname courant envoyé
    // par DMD-Agent devient alors la source de vérité pour la fiche et le parc.
    $reportedHostname = trim((string)($body['inventory']['hostname'] ?? ''));
    if ($reportedHostname !== '' && strlen($reportedHostname) <= 255 && !preg_match('/[\x00-\x1F\x7F]/', $reportedHostname)) {
        $device['hostname'] = $reportedHostname;
    }

    // L'architecture est elle aussi une donnée runtime de l'Agent.
    $reportedArch = trim((string)($body['inventory']['arch'] ?? ''));
    if ($reportedArch !== '' && strlen($reportedArch) <= 32 && preg_match('/^[A-Za-z0-9_.-]+$/', $reportedArch)) {
        $device['arch'] = $reportedArch;
    }
}
if (isset($body['capabilities']) && is_array($body['capabilities'])) $device['reported_capabilities'] = dmd_agent_normalize_capabilities($body['capabilities']);
if (isset($body['results']) && is_array($body['results'])) {
    $device['last_command_results'] = array_slice($body['results'], -20);
    dmd_agent_command_apply_results($validated['agent_id'], $body['results']);
}
if (!dmd_agent_json_write($validated['device_file'], $device, 0640)) dmd_agent_public_send(dmd_agent_api_result(false, 500, 'device_write_failed'));
$fastCommandChannel = isset($body['command_channel']) && (int)$body['command_channel'] >= 2;
$responseBody = array(
    'status'=>'active',
    'message'=>'heartbeat_ok',
    // Les agents récents utilisent un canal de commandes léger toutes les 2 s.
    // Les anciens agents continuent de recevoir leurs commandes par heartbeat.
    'commands'=>$fastCommandChannel ? array() : dmd_agent_command_collect($validated['agent_id'], 12),
    // Une vraie licence signée est transmise à l'Agent pour vérification native et cache offline.
    // Pendant la période de lancement, aucun faux fichier n'est nécessaire : le fallback 2026 est embarqué dans l'Agent.
    'license_envelope'=>function_exists('dmd_license_raw_envelope') ? dmd_license_raw_envelope() : '',
);
dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'], $validated['nonce'], $responseBody));
