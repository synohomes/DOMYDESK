<?php
require_once __DIR__ . '/_public.php';
require_once dirname(__DIR__, 3) . '/core/dmd_system_services.php';
$payload = dmd_agent_public_body();
$validated = dmd_agent_signed_request_validate($payload, 'POST', '/adm/agent/api/agent_commands.php', dmd_agent_remote_ip());
if (empty($validated['ok'])) dmd_agent_public_send($validated);
$body = $validated['body'];
$agentId = $validated['agent_id'];
$hadResults = isset($body['results']) && is_array($body['results']) && !empty($body['results']);

if ($hadResults) {
    dmd_agent_command_apply_results($agentId, $body['results']);
}
$commands = dmd_agent_command_collect($agentId, 8);
$hasWork = $hadResults || !empty($commands);
$nextPollMS = function_exists('dmd_agent_command_next_poll_ms')
    ? dmd_agent_command_next_poll_ms($agentId, $hasWork)
    : ($hasWork ? 80 : 500);

$responseBody = array(
    'status'=>'active',
    'message'=>'command_poll_ok_b8',
    'commands'=>$commands,
    'next_poll_ms'=>$nextPollMS,
);
dmd_agent_public_send(dmd_agent_signed_response($agentId, $validated['nonce'], $responseBody));
