<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$name = isset($payload['target_name']) ? $payload['target_name'] : '';
$expires = isset($payload['expires_minutes']) ? (int)$payload['expires_minutes'] : 1440;
$mode = isset($payload['approval_mode']) ? $payload['approval_mode'] : 'manual';
$serverUrls = isset($payload['server_urls']) && is_array($payload['server_urls']) ? $payload['server_urls'] : array(isset($payload['server_url']) ? $payload['server_url'] : '');
// Compatibilité : un ancien panneau qui n'envoie pas include_remote conserve
// l'ancien comportement (Remote inclus). Le nouveau panneau l'envoie toujours.
$includeRemote = array_key_exists('include_remote', $payload) ? !empty($payload['include_remote']) : true;
$includeMyDesk = !empty($payload['include_mydesk']);
$pcGroupId = isset($payload['pc_group_id']) ? trim((string)$payload['pc_group_id']) : '';
$caps = dmd_agent_capabilities_for_components($includeRemote, $includeMyDesk);
$result = dmd_agent_create_enrollment($email, $name, $expires, $mode, $caps, $serverUrls, $includeMyDesk, $pcGroupId);

if (!empty($result['ok'])) {
    $linkResult = dmd_agent_create_install_link($result['bootstrap'] ?? array(), $email);
    if (!empty($linkResult['ok']) && !empty($linkResult['install_link'])) {
        $result['install_link'] = $linkResult['install_link'];
    } else {
        $result['install_link_error'] = (string)($linkResult['error'] ?? 'install_link_failed');
        dmd_agent_log('enrollment_install_link_create_failed', 'warning', array(
            'enrollment_id'=>(string)($result['enrollment']['enrollment_id'] ?? ''),
            'error'=>$result['install_link_error'],
            'actor'=>(string)$email,
        ));
    }

    dmd_system_log(
        'agent_enrollment_created',
        $result['enrollment']['enrollment_id'],
        'success',
        'Création d’un enrôlement sécurisé DMD-Agent.',
        array('target_name'=>$name,'approval_mode'=>$mode,'pc_group_id'=>$pcGroupId)
    );
}

dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
