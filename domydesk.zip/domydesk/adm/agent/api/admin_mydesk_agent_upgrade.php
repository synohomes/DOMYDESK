<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
if ($agentId === '') dmd_json_response(array('ok'=>false,'error'=>'agent_id_invalid'),400);
$file = dmd_agent_device_file($agentId);
$device = ($file !== '' && is_file($file)) ? dmd_agent_json_read($file,array()) : array();
if (!$device || (string)($device['status']??'') !== 'active') dmd_json_response(array('ok'=>false,'error'=>'agent_not_active'),404);

// La licence décide si MyDesk peut être activé. Le module reste dépendant de DMD-Agent.
$ent = function_exists('dmd_license_entitlement') ? dmd_license_entitlement('dmd_mydesk') : array('enabled'=>true,'modules_max'=>5);
if (empty($ent['enabled']) || (int)($ent['modules_max']??0) === 0) dmd_json_response(array('ok'=>false,'error'=>'mydesk_license_required'),403);

$caps = array_unique(array_merge(
    isset($device['capabilities']) && is_array($device['capabilities']) ? $device['capabilities'] : array(),
    isset($device['reported_capabilities']) && is_array($device['reported_capabilities']) ? $device['reported_capabilities'] : array()
));
if (!in_array('mydesk.client',$caps,true)) $caps[]='mydesk.client';

// Le pack de migration transporte un NOUVEAU certificat Agent signé pour le même
// Agent ID / la même clé machine, avec mydesk.client. Aucun ré-enrôlement.
$existingCert = isset($device['certificate']) && is_array($device['certificate']) ? $device['certificate'] : array();
$certCaps = isset($existingCert['payload']['capabilities']) && is_array($existingCert['payload']['capabilities']) ? $existingCert['payload']['capabilities'] : array();
if (!in_array('mydesk.client',$certCaps,true)) {
    $reissued = dmd_agent_reissue_device_certificate_capabilities($agentId,$caps,$email);
    if (empty($reissued['ok'])) dmd_json_response($reissued,500);
    $device = $reissued['device'];
    $certificate = $reissued['certificate'];
    $caps = $reissued['capabilities'];
} else {
    $certificate = $existingCert;
    $caps = dmd_agent_normalize_capabilities($certCaps);
}

$grant = array(
    'schema'=>1,
    'format'=>'DMD-MYDESK-UPGRADE-V1',
    'instance_id'=>(string)($device['instance_id']??''),
    'agent_id'=>$agentId,
    'device_public_key'=>(string)($device['device_public_key']??''),
    'device_key_fingerprint'=>(string)($device['device_key_fingerprint']??''),
    'capabilities'=>array_values($caps),
    'certificate'=>$certificate,
);
if ($grant['instance_id']==='' || $grant['device_public_key']==='' || $grant['device_key_fingerprint']==='' || !$certificate) {
    dmd_json_response(array('ok'=>false,'error'=>'device_identity_incomplete'),500);
}
$grantRaw = json_encode($grant,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if ($grantRaw===false) dmd_json_response(array('ok'=>false,'error'=>'upgrade_grant_encode_failed'),500);
$grantRaw .= "\n";

$binDir = dirname(__DIR__) . '/bin/windows-x64';
$names = array('DMD-Installer.exe');
if (dmd_agent_caps_use_remote($caps)) $names[]='DMD-Remote.exe';
if (is_file($binDir.'/WebView2Loader.dll')) $names[]='WebView2Loader.dll';
$files=array();
foreach($names as $name){
    $path=$binDir.'/'.$name;
    if(!is_file($path)) dmd_json_response(array('ok'=>false,'error'=>'binary_missing','file'=>$name),404);
    $raw=@file_get_contents($path);$isExe=strtolower(pathinfo($name,PATHINFO_EXTENSION))==='exe';
    if($raw===false||($isExe&&substr($raw,0,2)!=='MZ')) dmd_json_response(array('ok'=>false,'error'=>'binary_invalid','file'=>$name),500);
    $files[$name]=$raw;
}
$files['mydesk-upgrade.json']=$grantRaw;
$manifest='';foreach($files as $name=>$raw)$manifest.=hash('sha256',$raw).'  '.$name."\r\n";
$files['MANIFEST-SHA256.txt']=$manifest;
$files['LISEZ-MOI.txt'] =
    "DMD-Agent / DMD-MyDesk 1.4.0 - migration d'un poste existant\r\n\r\n".
    "DMD-Agent reste obligatoire. DMD-MyDesk est un composant optionnel dépendant de cet Agent.\r\n".
    "Ce pack conserve l'Agent ID, la clé machine et l'enrôlement existants.\r\n".
    "Il ajoute/valide la capability mydesk.client avec un certificat signé par cette instance DoMyDesk.\r\n".
    "Il supprime aussi les restes du client MyDesk autonome 1.13.3 s'ils existent.\r\n\r\n".
    "1. Copier ce ZIP sur CE PC uniquement.\r\n".
    "2. Extraire tous les fichiers.\r\n".
    "3. Lancer DMD-Installer.exe en administrateur.\r\n".
    "4. L’installateur détecte DMD-Agent et passe automatiquement en mode updater/réparation.\r\n";

function dmd_agent_140_zip_time($ts){$p=getdate($ts);$y=max(1980,min(2107,(int)$p['year']));return array(((int)$p['hours']<<11)|((int)$p['minutes']<<5)|((int)$p['seconds']>>1),(($y-1980)<<9)|((int)$p['mon']<<5)|(int)$p['mday']);}
function dmd_agent_140_zip_store($files){list($t,$d)=dmd_agent_140_zip_time(time());$body='';$central='';$off=0;$count=0;foreach($files as $name=>$content){$name=ltrim(str_replace('\\','/',(string)$name),'/');if($name===''||strpos($name,'../')!==false)continue;$content=(string)$content;$size=strlen($content);$crc=crc32($content);$local=pack('VvvvvvVVVvv',0x04034b50,20,0,0,$t,$d,$crc,$size,$size,strlen($name),0).$name;$body.=$local.$content;$central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,$t,$d,$crc,$size,$size,strlen($name),0,0,0,0,0,$off).$name;$off+=strlen($local)+$size;$count++;}return $body.$central.pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($central),strlen($body),0);}
$zip=dmd_agent_140_zip_store($files);
$host=preg_replace('/[^A-Za-z0-9._-]+/','-',(string)($device['hostname']??'PC'));if($host==='')$host='PC';
$filename='DMD-Agent-1.4.0-MyDesk-UPGRADE-'.$host.'-'.$agentId.'.zip';
dmd_agent_log('mydesk_140_upgrade_pack_generated','success',array('agent_id'=>$agentId,'actor'=>$email,'capability'=>'mydesk.client'));
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Content-Length: '.strlen($zip));
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-DMD-Agent-Version: 1.4.0');
header('X-DMD-MyDesk-Dependency: DMD-Agent');
echo $zip;exit;
