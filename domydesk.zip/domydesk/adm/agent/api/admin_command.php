<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/software_packages.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$action = strtolower(trim((string)($payload['action'] ?? '')));
$agentId = dmd_agent_safe_agent_id($payload['agent_id'] ?? '');
if ($agentId === '') dmd_json_response(array('ok'=>false,'error'=>'agent_invalid'), 400);

if ($action === 'interactive_touch') {
    $ok = function_exists('dmd_agent_command_mark_interactive') ? dmd_agent_command_mark_interactive($agentId, 45) : true;
    dmd_json_response(array('ok'=>(bool)$ok,'agent_id'=>$agentId,'interactive_for'=>45), $ok ? 200 : 500);
}

if ($action === 'wol') {
    $deviceFile = dmd_agent_device_file($agentId);
    $device = ($deviceFile !== '' && is_file($deviceFile)) ? dmd_agent_json_read($deviceFile, array()) : array();
    if (!$device) dmd_json_response(array('ok'=>false,'error'=>'agent_not_found'), 404);

    $caps = array_unique(array_merge(
        isset($device['capabilities']) && is_array($device['capabilities']) ? $device['capabilities'] : array(),
        isset($device['reported_capabilities']) && is_array($device['reported_capabilities']) ? $device['reported_capabilities'] : array()
    ));
    if (!in_array('system.power', $caps, true)) dmd_json_response(array('ok'=>false,'error'=>'capability_denied'), 403);

    $candidates = array();
    $pushMac = function($value) use (&$candidates) {
        if (!is_scalar($value)) return;
        $m = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', (string)$value));
        if (strlen($m) === 12 && $m !== '000000000000') $candidates[] = $m;
    };
    $walk = function($node, $depth = 0) use (&$walk, $pushMac) {
        if ($depth > 5 || !is_array($node)) return;
        foreach ($node as $k=>$v) {
            $key = strtolower((string)$k);
            if (in_array($key, array('mac','mac_address','macaddress','physical_address','physicaladdress'), true)) $pushMac($v);
            if (is_array($v)) $walk($v, $depth + 1);
        }
    };
    foreach (array('network','last_inventory','telemetry','last_telemetry','hardware') as $key) if (isset($device[$key])) $walk($device[$key]);
    $candidates = array_values(array_unique($candidates));
    if (!$candidates) dmd_json_response(array('ok'=>false,'error'=>'wol_mac_missing'), 400);
    $mac = $candidates[0];
    $macBin = pack('H*', $mac);
    $packet = str_repeat(chr(0xFF), 6) . str_repeat($macBin, 16);
    $targets = array('255.255.255.255');
    $lastIp = trim((string)($device['last_ip'] ?? ''));
    if (filter_var($lastIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $parts = explode('.', $lastIp);
        if (count($parts) === 4) $targets[] = $parts[0].'.'.$parts[1].'.'.$parts[2].'.255';
    }
    $sent = 0; $errors = array();
    if (function_exists('socket_create')) {
        $sock = @socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
        if ($sock !== false) {
            @socket_set_option($sock, SOL_SOCKET, SO_BROADCAST, 1);
            foreach (array_unique($targets) as $target) foreach (array(9,7) as $port) {
                $n = @socket_sendto($sock, $packet, strlen($packet), 0, $target, $port);
                if ($n === strlen($packet)) $sent++; else $errors[] = $target.':'.$port;
            }
            @socket_close($sock);
        }
    }
    if ($sent === 0) {
        foreach (array_unique($targets) as $target) foreach (array(9,7) as $port) {
            $fp = @stream_socket_client('udp://'.$target.':'.$port, $errno, $errstr, 1, STREAM_CLIENT_CONNECT);
            if ($fp) { $n=@fwrite($fp,$packet); @fclose($fp); if ($n===strlen($packet)) $sent++; }
        }
    }
    if ($sent === 0) dmd_json_response(array('ok'=>false,'error'=>'wol_send_failed','targets'=>$errors), 500);
    dmd_system_log('agent_wol_sent',$agentId,'warning','Wake-on-LAN envoyé depuis DoMyDesk.',array('mac'=>substr($mac,0,6).'******','packets'=>$sent));
    dmd_json_response(array('ok'=>true,'agent_id'=>$agentId,'packets'=>$sent));
}


if ($action === 'status') {
    if (function_exists('dmd_agent_command_mark_interactive')) dmd_agent_command_mark_interactive($agentId, 20);
    $commandId = dmd_agent_command_safe_id($payload['command_id'] ?? '');
    if ($commandId === '') dmd_json_response(array('ok'=>false,'error'=>'command_invalid'), 400);
    $command = dmd_agent_command_status($agentId, $commandId);
    if (!$command) dmd_json_response(array('ok'=>false,'error'=>'command_not_found'), 404);
    dmd_json_response(array('ok'=>true,'command'=>$command));
}

if ($action !== 'queue') dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);

$operation = strtolower(trim((string)($payload['operation'] ?? '')));
$params = isset($payload['params']) && is_array($payload['params']) ? $payload['params'] : array();
$catalog = array(
    'processes.list'   => array('command'=>'processes.list','capability'=>'system.processes','ttl'=>180,'audit'=>'agent_processes_list'),
    'processes.kill'   => array('command'=>'processes.kill','capability'=>'system.processes','ttl'=>180,'audit'=>'agent_process_kill'),
    'processes.start'  => array('command'=>'processes.start','capability'=>'system.processes','ttl'=>300,'audit'=>'agent_process_start'),
    'processes.restart'=> array('command'=>'processes.restart','capability'=>'system.processes','ttl'=>300,'audit'=>'agent_process_restart'),
    'services.list'    => array('command'=>'services.list','capability'=>'system.services','ttl'=>180,'audit'=>'agent_services_list'),
    'services.control' => array('command'=>'services.control','capability'=>'system.services','ttl'=>300,'audit'=>'agent_service_control'),
    'services.configure'=>array('command'=>'services.configure','capability'=>'system.services','ttl'=>300,'audit'=>'agent_service_configure'),
    'system.restart'    => array('command'=>'system.restart','capability'=>'system.power','ttl'=>180,'audit'=>'agent_system_restart'),
    'system.shutdown'   => array('command'=>'system.shutdown','capability'=>'system.power','ttl'=>180,'audit'=>'agent_system_shutdown'),
    'system.terminal'   => array('command'=>'system.terminal','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_terminal_exec'),
    'system.rename'     => array('command'=>'system.rename','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_system_rename'),
    'sessions.list'     => array('command'=>'sessions.list','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_sessions_list'),
    'sessions.logoff'   => array('command'=>'sessions.logoff','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_session_logoff'),
    'sessions.disconnect'=>array('command'=>'sessions.disconnect','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_session_disconnect'),
    'filesystem.roots'  => array('command'=>'filesystem.roots','capability'=>'filesystem.roots','ttl'=>180,'audit'=>'agent_files_roots'),
    'filesystem.list'   => array('command'=>'filesystem.list','capability'=>'filesystem.list','ttl'=>180,'audit'=>'agent_files_list'),
    'filesystem.read'   => array('command'=>'filesystem.read','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_files_read'),
    'filesystem.write'  => array('command'=>'filesystem.write','capability'=>'filesystem.write','ttl'=>600,'audit'=>'agent_files_write'),
    'filesystem.mkdir'  => array('command'=>'filesystem.mkdir','capability'=>'filesystem.mkdir','ttl'=>300,'audit'=>'agent_files_mkdir'),
    'filesystem.delete' => array('command'=>'filesystem.delete','capability'=>'filesystem.write','ttl'=>300,'audit'=>'agent_files_delete'),
    'filesystem.rename' => array('command'=>'filesystem.rename','capability'=>'filesystem.write','ttl'=>300,'audit'=>'agent_files_rename'),
    'filesystem.archive'=> array('command'=>'filesystem.archive','capability'=>'filesystem.write','ttl'=>1200,'audit'=>'agent_files_archive'),
    'filesystem.extract'=> array('command'=>'filesystem.extract','capability'=>'filesystem.write','ttl'=>1200,'audit'=>'agent_files_extract'),
    'software.list'      => array('command'=>'software.list','capability'=>'software.list','ttl'=>300,'audit'=>'agent_software_list'),
    'software.running'   => array('command'=>'software.running','capability'=>'software.list','ttl'=>180,'audit'=>'agent_software_running'),
    'registry.list'      => array('command'=>'registry.list','capability'=>'system.registry.read','ttl'=>180,'audit'=>'agent_registry_list'),
    'registry.get'       => array('command'=>'registry.get','capability'=>'system.registry.read','ttl'=>180,'audit'=>'agent_registry_get'),
    'registry.set'       => array('command'=>'registry.set','capability'=>'system.registry.write','ttl'=>300,'audit'=>'agent_registry_set'),
    'registry.delete'    => array('command'=>'registry.delete','capability'=>'system.registry.write','ttl'=>300,'audit'=>'agent_registry_delete'),
    'devices.removable.list' => array('command'=>'devices.removable.list','capability'=>'system.removable','ttl'=>180,'audit'=>'agent_removable_list'),
    'devices.removable.eject'=> array('command'=>'devices.removable.eject','capability'=>'system.removable','ttl'=>180,'audit'=>'agent_removable_eject'),
    'devices.removable.block'=> array('command'=>'devices.removable.block','capability'=>'system.removable','ttl'=>300,'audit'=>'agent_removable_block'),
    'devices.removable.unblock'=>array('command'=>'devices.removable.unblock','capability'=>'system.removable','ttl'=>300,'audit'=>'agent_removable_unblock'),
    'network.paths.list' => array('command'=>'network.paths.list','capability'=>'system.networkpaths','ttl'=>180,'audit'=>'agent_network_paths_list'),
    'network.paths.add'  => array('command'=>'network.paths.add','capability'=>'system.networkpaths','ttl'=>300,'audit'=>'agent_network_paths_add'),
    'network.paths.remove'=> array('command'=>'network.paths.remove','capability'=>'system.networkpaths','ttl'=>300,'audit'=>'agent_network_paths_remove'),
    'network.adapters.list'=>array('command'=>'network.adapters.list','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_network_adapters_list'),
    'network.configure'   => array('command'=>'network.configure','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_network_configure'),
    'network.adapter.control'=>array('command'=>'network.adapter.control','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_network_adapter_control'),
    'network.ports.list'  => array('command'=>'network.ports.list','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_network_ports_list'),
    'backup.files.start'  => array('command'=>'backup.files.start','capability'=>'filesystem.read','ttl'=>86400,'audit'=>'agent_backup_files_start'),
    'backup.files.status' => array('command'=>'backup.files.status','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_files_status'),
    'backup.files.stop'   => array('command'=>'backup.files.stop','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_files_stop'),
    'backup.targets.list' => array('command'=>'backup.targets.list','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_targets_list'),
    'backup.target.configure' => array('command'=>'backup.target.configure','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_target_configure'),
    'backup.target.delete' => array('command'=>'backup.target.delete','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_target_delete'),
    'backup.target.test' => array('command'=>'backup.target.test','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_target_test'),
    'backup.smb.discover' => array('command'=>'backup.smb.discover','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_smb_discover'),
    'backup.providers.list' => array('command'=>'backup.providers.list','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_providers_list'),
    'backup.provider.action' => array('command'=>'backup.provider.action','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_provider_action'),
    'backup.provider.status' => array('command'=>'backup.provider.status','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_provider_status'),
    'backup.provider.stop' => array('command'=>'backup.provider.stop','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_provider_stop'),
    'backup.provider.config.get' => array('command'=>'backup.provider.config.get','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_provider_config_get'),
    'backup.provider.config.set' => array('command'=>'backup.provider.config.set','capability'=>'filesystem.read','ttl'=>600,'audit'=>'agent_backup_provider_config_set'),
    'backup.provider.recovery.iso' => array('command'=>'backup.provider.recovery.iso','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_provider_recovery_iso'),
    'backup.image.list' => array('command'=>'backup.image.list','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_image_list'),
    'backup.image.start' => array('command'=>'backup.image.start','capability'=>'filesystem.read','ttl'=>300,'audit'=>'agent_backup_image_start'),
    'backup.image.status' => array('command'=>'backup.image.status','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_image_status'),
    'backup.image.stop' => array('command'=>'backup.image.stop','capability'=>'filesystem.read','ttl'=>180,'audit'=>'agent_backup_image_stop'),
    'network.localnets.list' => array('command'=>'network.localnets.list','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_network_localnets_list'),
    'network.scan.start'   => array('command'=>'network.scan.start','capability'=>'system.terminal','ttl'=>900,'audit'=>'agent_network_scan_start'),
    'network.scan.status'  => array('command'=>'network.scan.status','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_network_scan_status'),
    'network.scan.stop'    => array('command'=>'network.scan.stop','capability'=>'system.terminal','ttl'=>180,'audit'=>'agent_network_scan_stop'),
    'firewall.list'       => array('command'=>'firewall.list','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_firewall_list'),
    'firewall.add'        => array('command'=>'firewall.add','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_firewall_add'),
    'firewall.set'        => array('command'=>'firewall.set','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_firewall_set'),
    'firewall.delete'     => array('command'=>'firewall.delete','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_firewall_delete'),
    'storage.disks.list'  => array('command'=>'storage.disks.list','capability'=>'filesystem.roots','ttl'=>300,'audit'=>'agent_storage_disks_list'),
    'storage.format'      => array('command'=>'storage.format','capability'=>'system.removable','ttl'=>600,'audit'=>'agent_storage_format'),
    'security.status'     => array('command'=>'security.status','capability'=>'system.terminal','ttl'=>300,'audit'=>'agent_security_status'),
    'security.defender.action'=>array('command'=>'security.defender.action','capability'=>'system.terminal','ttl'=>3600,'audit'=>'agent_defender_action'),
    // Compatibilité certificats existants : software.install réutilise la capability Agent
    // software.uninstall. Le binaire est étendu sans ré-enrôler ni réémettre les clés/certificats.
    'software.install'   => array('command'=>'software.install','capability'=>'software.uninstall','ttl'=>1800,'audit'=>'agent_software_install'),
    'software.uninstall' => array('command'=>'software.uninstall','capability'=>'software.uninstall','ttl'=>1200,'audit'=>'agent_software_uninstall'),
    'software.winget.search'=>array('command'=>'software.winget.search','capability'=>'software.update','ttl'=>180,'audit'=>'agent_software_winget_search'),
    'software.winget.install'=>array('command'=>'software.winget.install','capability'=>'software.update','ttl'=>1800,'audit'=>'agent_software_winget_install'),
    'software.winget.uninstall'=>array('command'=>'software.winget.uninstall','capability'=>'software.update','ttl'=>1200,'audit'=>'agent_software_winget_uninstall'),
    'software.updates.scan' => array('command'=>'software.updates.scan','capability'=>'software.update','ttl'=>300,'audit'=>'agent_software_updates_scan'),
    'software.updates.apply'=> array('command'=>'software.updates.apply','capability'=>'software.update','ttl'=>1800,'audit'=>'agent_software_updates_apply'),
    // Patch Agent R8 admin 02 : Windows Update natif. Les deux anciens noms restent
    // acceptés côté PHP pour ne pas casser une page admin encore en cache.
    'windows_update.scan'    => array('command'=>'windows_update.scan','capability'=>'software.update','ttl'=>600,'audit'=>'agent_windows_update_scan'),
    'windows_update.install' => array('command'=>'windows_update.install','capability'=>'software.update','ttl'=>3600,'audit'=>'agent_windows_update_install'),
    'windows_update.history' => array('command'=>'windows_update.history','capability'=>'software.update','ttl'=>600,'audit'=>'agent_windows_update_history'),
    'windows.updates.scan'   => array('command'=>'windows_update.scan','capability'=>'software.update','ttl'=>600,'audit'=>'agent_windows_update_scan_compat'),
    'windows.updates.apply'  => array('command'=>'windows_update.install','capability'=>'software.update','ttl'=>3600,'audit'=>'agent_windows_update_install_compat'),
    'remote.screen'       => array('command'=>'remote.start','capability'=>'remote.screen','ttl'=>180,'audit'=>'agent_remote_screen'),
    'remote.control'      => array('command'=>'remote.start_control','capability'=>'remote.control','ttl'=>180,'audit'=>'agent_remote_control'),
    'remote.stop'         => array('command'=>'remote.stop','capability'=>'remote.screen','ttl'=>180,'audit'=>'agent_remote_stop'),
    'remote.clipboard.get'=> array('command'=>'remote.clipboard.get','capability'=>'remote.clipboard','ttl'=>180,'audit'=>'agent_remote_clipboard_get'),
    'remote.clipboard.set'=> array('command'=>'remote.clipboard.set','capability'=>'remote.clipboard','ttl'=>180,'audit'=>'agent_remote_clipboard_set'),
);
if (!isset($catalog[$operation])) dmd_json_response(array('ok'=>false,'error'=>'operation_invalid'), 400);

if (strpos($operation, 'remote.') === 0) {
    $lic = dmd_agent_remote_license_compliant();
    if (empty($lic['ok']) || (int)$lic['allowed'] === 0) {
        dmd_system_log('agent_remote_license_refused',$agentId,'warning','Remote refusé par la licence DMD-Agent.',array('used'=>$lic['used'],'allowed'=>$lic['allowed']));
        dmd_json_response(array('ok'=>false,'error'=>'remote_license_refused','used'=>$lic['used'],'allowed'=>$lic['allowed']), 403);
    }
}

// Strict server-side payload validation before the command enters the signed channel.
$clean = array();
if ($operation === 'processes.list') {
    $offset = isset($params['offset']) ? max(0, (int)$params['offset']) : 0;
    $limit = isset($params['limit']) ? max(5, min(25, (int)$params['limit'])) : 25;
    $clean = array('offset'=>$offset, 'limit'=>$limit);
} elseif ($operation === 'processes.start') {
    $path = trim((string)($params['path'] ?? ''));
    $arguments = trim((string)($params['arguments'] ?? ''));
    if ($path === '' || strlen($path) > 32000 || preg_match('/[\x00\r\n]/', $path)) dmd_json_response(array('ok'=>false,'error'=>'process_path_invalid'),400);
    if (strlen($arguments) > 16000 || preg_match('/[\x00\r\n]/', $arguments)) dmd_json_response(array('ok'=>false,'error'=>'process_arguments_invalid'),400);
    $clean = array('path'=>$path,'arguments'=>$arguments);
} elseif ($operation === 'processes.restart') {
    $pid = isset($params['pid']) ? (int)$params['pid'] : 0;
    if ($pid <= 0) dmd_json_response(array('ok'=>false,'error'=>'pid_invalid'),400);
    $clean = array('pid'=>$pid);
} elseif ($operation === 'services.list') {
    $offset = isset($params['offset']) ? max(0, (int)$params['offset']) : 0;
    $limit = isset($params['limit']) ? max(10, min(40, (int)$params['limit'])) : 40;
    $clean = array('offset'=>$offset, 'limit'=>$limit);
} elseif ($operation === 'processes.kill') {
    $pid = isset($params['pid']) ? (int)$params['pid'] : 0;
    if ($pid <= 0) dmd_json_response(array('ok'=>false,'error'=>'pid_invalid'), 400);
    $clean['pid'] = $pid;
} elseif ($operation === 'services.control') {
    $name = trim((string)($params['name'] ?? ''));
    $verb = strtolower(trim((string)($params['operation'] ?? 'restart')));
    if (!preg_match('/^[A-Za-z0-9_.-]{1,256}$/', $name)) dmd_json_response(array('ok'=>false,'error'=>'service_invalid'), 400);
    if (!in_array($verb, array('start','stop','restart'), true)) dmd_json_response(array('ok'=>false,'error'=>'service_operation_invalid'), 400);
    if (strcasecmp($name, 'agentdmd') === 0 || strcasecmp($name, 'DMD-Agent') === 0) dmd_json_response(array('ok'=>false,'error'=>'agent_service_protected'), 400);
    $clean = array('name'=>$name,'operation'=>$verb);
} elseif ($operation === 'services.configure') {
    $name = trim((string)($params['name'] ?? ''));
    $mode = strtolower(trim((string)($params['start_mode'] ?? '')));
    if (!preg_match('/^[A-Za-z0-9_.-]{1,256}$/',$name)) dmd_json_response(array('ok'=>false,'error'=>'service_invalid'),400);
    if (strcasecmp($name,'agentdmd')===0 || strcasecmp($name,'DMD-Agent')===0) dmd_json_response(array('ok'=>false,'error'=>'agent_service_protected'),400);
    if (!in_array($mode,array('auto','automatic','delayed','manual','disabled'),true)) dmd_json_response(array('ok'=>false,'error'=>'service_start_mode_invalid'),400);
    $clean = array('name'=>$name,'start_mode'=>$mode);
} elseif ($operation === 'system.rename') {
    $newName = strtoupper(trim((string)($params['new_name'] ?? '')));
    if (!preg_match('/^[A-Z0-9](?:[A-Z0-9-]{0,13}[A-Z0-9])?$/',$newName)) dmd_json_response(array('ok'=>false,'error'=>'computer_name_invalid'),400);
    $clean = array('new_name'=>$newName);
} elseif ($operation === 'sessions.list') {
    $clean = array();
} elseif ($operation === 'sessions.logoff' || $operation === 'sessions.disconnect') {
    $sessionId = isset($params['session_id']) ? (int)$params['session_id'] : 0;
    if ($sessionId <= 0) dmd_json_response(array('ok'=>false,'error'=>'session_id_invalid'),400);
    $clean = array('session_id'=>$sessionId);
} elseif ($operation === 'system.restart' || $operation === 'system.shutdown') {
    $delay = isset($params['delay_seconds']) ? (int)$params['delay_seconds'] : 60;
    $delay = max(45, min(604800, $delay));
    $message = trim((string)($params['message'] ?? ''));
    $message = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $message);
    if (!is_string($message)) $message = '';
    if (strlen($message) > 260) $message = substr($message, 0, 260);
    $clean = array('delay_seconds'=>$delay);
    if ($message !== '') $clean['message'] = $message;
} elseif ($operation === 'system.terminal') {
    $command = trim((string)($params['command'] ?? ''));
    $shell = strtolower(trim((string)($params['shell'] ?? 'powershell')));
    $timeout = isset($params['timeout_seconds']) ? (int)$params['timeout_seconds'] : 45;
    if ($command === '' || strlen($command) > 8192) dmd_json_response(array('ok'=>false,'error'=>'terminal_command_invalid'), 400);
    if (!in_array($shell, array('powershell','cmd'), true)) dmd_json_response(array('ok'=>false,'error'=>'terminal_shell_invalid'), 400);
    $clean = array('command'=>$command,'shell'=>$shell,'timeout_seconds'=>max(1,min(120,$timeout)));
} elseif (in_array($operation, array('remote.screen','remote.control','remote.stop','remote.clipboard.get'), true)) {
    $clean = array();
} elseif ($operation === 'remote.clipboard.set') {
    $text = (string)($params['text'] ?? ''); if (strlen($text) > 262144) $text = substr($text, 0, 262144);
    $clean = array('text'=>$text);
} elseif ($operation === 'software.running') {
    $clean = array('offset'=>max(0,(int)($params['offset'] ?? 0)),'limit'=>max(5,min(50,(int)($params['limit'] ?? 25))));
} elseif (in_array($operation, array('registry.list','registry.get','registry.set','registry.delete'), true)) {
    $hive = strtoupper(trim((string)($params['hive'] ?? 'HKLM')));
    if (!in_array($hive,array('HKLM','HKCU','HKU','HKCR','HKCC'),true)) dmd_json_response(array('ok'=>false,'error'=>'registry_hive_invalid'),400);
    $path = trim((string)($params['path'] ?? '')); if (strlen($path)>16000 || preg_match('/[\x00\r\n]/',$path)) dmd_json_response(array('ok'=>false,'error'=>'registry_path_invalid'),400);
    $clean=array('hive'=>$hive,'path'=>$path);
    if ($operation==='registry.get' || $operation==='registry.set' || $operation==='registry.delete') {
        $name=(string)($params['name'] ?? ''); if(strlen($name)>1024 || preg_match('/[\x00\r\n]/',$name)) dmd_json_response(array('ok'=>false,'error'=>'registry_name_invalid'),400); $clean['name']=$name;
    }
    if ($operation==='registry.set') {
        $type=strtolower(trim((string)($params['value_type'] ?? 'string'))); if(!in_array($type,array('string','expandstring','multistring','dword','qword','binary'),true)) dmd_json_response(array('ok'=>false,'error'=>'registry_type_invalid'),400);
        $value=(string)($params['value'] ?? ''); if(strlen($value)>65536) dmd_json_response(array('ok'=>false,'error'=>'registry_value_too_large'),400); $clean['value_type']=$type; $clean['value']=$value;
    }
    if ($operation==='registry.delete') { $scope=strtolower(trim((string)($params['scope'] ?? 'value'))); if(!in_array($scope,array('value','key'),true)) dmd_json_response(array('ok'=>false,'error'=>'registry_scope_invalid'),400); $clean['scope']=$scope; $clean['recursive']=!empty($params['recursive']); }
} elseif ($operation === 'devices.removable.list') {
    $clean=array();
} elseif ($operation === 'devices.removable.eject') {
    $letter=strtoupper(trim((string)($params['letter'] ?? ''))); if(!preg_match('/^[A-Z]:?$/',$letter)) dmd_json_response(array('ok'=>false,'error'=>'drive_letter_invalid'),400); $clean=array('letter'=>$letter);
} elseif ($operation === 'devices.removable.block' || $operation === 'devices.removable.unblock') {
    $instanceId = trim((string)($params['instance_id'] ?? ''));
    $global = !empty($params['global']) || $instanceId === '';
    if (strlen($instanceId) > 4096 || preg_match('/[\x00\r\n]/',$instanceId)) dmd_json_response(array('ok'=>false,'error'=>'usb_instance_invalid'),400);
    $clean = array('instance_id'=>$instanceId,'global'=>$global);
} elseif ($operation === 'network.paths.list') {
    $clean=array();
} elseif ($operation === 'network.paths.add') {
    $local=strtoupper(trim((string)($params['local_path'] ?? '')));
    if(strlen($local)===1) $local .= ':';
    if(!preg_match('/^[A-Z]:$/',$local)) {
        dmd_json_response(array('ok'=>false,'error'=>'network_drive_invalid'),400);
    }

    // Accepte \\serveur\partage, /serveur/partage, \serveur\partage
    // et même serveur\partage puis normalise toujours en UNC canonique.
    $remote=trim((string)($params['remote_path'] ?? '')," \t\n\r\0\x0B\"'");
    $remote=str_replace('/','\\',$remote);
    if(strlen($remote)>2048 || preg_match('/[\x00-\x1F]/',$remote)) {
        dmd_json_response(array('ok'=>false,'error'=>'network_path_invalid'),400);
    }
    $remoteBody=ltrim($remote,'\\');
    $uncParts=array_values(array_filter(explode('\\',$remoteBody),function($v){return trim($v)!=='';}));
    if(count($uncParts)<2 || strlen($uncParts[0])>255 || strlen($uncParts[1])>255) {
        dmd_json_response(array('ok'=>false,'error'=>'network_path_invalid'),400);
    }
    foreach($uncParts as $part){
        if($part==='.' || $part==='..' || preg_match('/[<>:"|?*]/',$part)) {
            dmd_json_response(array('ok'=>false,'error'=>'network_path_invalid'),400);
        }
    }
    $remote='\\\\'.implode('\\',$uncParts);
    $clean=array('local_path'=>$local,'remote_path'=>$remote);
} elseif ($operation === 'network.paths.remove') {
    $local=strtoupper(trim((string)($params['local_path'] ?? ''))); if(!preg_match('/^[A-Z]:?$/',$local)) dmd_json_response(array('ok'=>false,'error'=>'network_path_invalid'),400); $clean=array('local_path'=>$local);
} elseif ($operation === 'backup.files.start') {
    $sources = $params['sources'] ?? array();
    if (is_string($sources)) $sources = preg_split('/\r?\n/', $sources, -1, PREG_SPLIT_NO_EMPTY);
    if (!is_array($sources)) $sources = array();
    $sources = array_values(array_filter(array_map(function($v){ return trim((string)$v); }, $sources), function($v){ return $v !== ''; }));
    if (count($sources) > 32) dmd_json_response(array('ok'=>false,'error'=>'backup_sources_invalid'),400);
    foreach ($sources as $src) if (strlen($src) > 32000 || preg_match('/[\x00\r\n]/',$src)) dmd_json_response(array('ok'=>false,'error'=>'backup_source_invalid'),400);
    $presets=$params['source_presets']??array();
    if(is_string($presets))$presets=preg_split('/[,;\s]+/',$presets,-1,PREG_SPLIT_NO_EMPTY);
    if(!is_array($presets))$presets=array();
    $allowedPresets=array('profiles.all','profiles.desktop','profiles.documents','profiles.pictures','profiles.videos','profiles.music','profiles.downloads','profiles.onedrive','public.all');
    $presets=array_values(array_unique(array_filter(array_map(function($v){return strtolower(trim((string)$v));},$presets),function($v)use($allowedPresets){return in_array($v,$allowedPresets,true);})));
    if(!$sources && !$presets)dmd_json_response(array('ok'=>false,'error'=>'backup_sources_invalid'),400);
    $targetId = strtoupper(trim((string)($params['target_id'] ?? '')));
    $destination = trim((string)($params['destination'] ?? ''));
    if ($targetId === '' && ($destination === '' || strlen($destination) > 32000 || preg_match('/[\x00\r\n]/',$destination))) dmd_json_response(array('ok'=>false,'error'=>'backup_target_required'),400);
    if ($targetId !== '' && !preg_match('/^BKT-[A-Z0-9._-]{4,64}$/',$targetId)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_invalid'),400);
    $retentionCount=max(1,min(100,(int)($params['retention_count'] ?? 5)));
    $cleanList = function($raw,$max) {
        if (is_string($raw)) $raw = preg_split('/\r?\n/', $raw, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($raw)) return array();
        $out=array(); foreach($raw as $v){$v=trim((string)$v);if($v==='')continue;if(strlen($v)>1024||preg_match('/[\x00\r\n]/',$v))continue;$out[]=$v;if(count($out)>=$max)break;} return array_values(array_unique($out));
    };
    $clean = array('sources'=>$sources,'source_presets'=>$presets,'retention_count'=>$retentionCount,'exclude_dirs'=>$cleanList($params['exclude_dirs'] ?? array(),32),'exclude_files'=>$cleanList($params['exclude_files'] ?? array(),32));
    if ($targetId !== '') $clean['target_id']=$targetId; else $clean['destination']=$destination;
} elseif ($operation === 'backup.files.status' || $operation === 'backup.files.stop') {
    $jobId = strtoupper(trim((string)($params['job_id'] ?? '')));
    if ($jobId !== '' && !preg_match('/^BKP-[A-Z0-9._-]{1,64}$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'backup_job_invalid'),400);
    $clean = $jobId === '' ? array() : array('job_id'=>$jobId);
} elseif ($operation === 'backup.targets.list') {
    $clean = array();
} elseif ($operation === 'backup.target.configure') {
    $targetId = strtoupper(trim((string)($params['target_id'] ?? '')));
    if ($targetId !== '' && !preg_match('/^BKT-[A-Z0-9._-]{4,64}$/',$targetId)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_invalid'),400);
    $type = strtolower(trim((string)($params['target_type'] ?? '')));
    if (!in_array($type,array('local','smb','webdav'),true)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_type_invalid'),400);
    $name = trim((string)($params['name'] ?? 'Sauvegarde'));
    if ($name==='' || strlen($name)>80 || preg_match('/[\x00\r\n]/',$name)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_name_invalid'),400);
    $folder = trim((string)($params['folder'] ?? ''));
    $username = trim((string)($params['username'] ?? ''));
    $password = (string)($params['password'] ?? '');
    if (strlen($folder)>2048 || strlen($username)>320 || strlen($password)>2048 || preg_match('/[\x00\r\n]/',$folder.$username.$password)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_fields_invalid'),400);
    $clean=array('target_id'=>$targetId,'target_type'=>$type,'name'=>$name,'folder'=>$folder,'username'=>$username,'password'=>$password);
    if($type==='local'){
        $path=trim((string)($params['local_path']??'')); if($path===''||strlen($path)>32000||preg_match('/[\x00\r\n]/',$path)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_local_invalid'),400); $clean['local_path']=$path;
    } elseif($type==='smb'){
        $server=trim((string)($params['server']??''));$share=trim((string)($params['share']??''));
        if($server===''||$share===''||strlen($server)>255||strlen($share)>255||preg_match('/[\x00\r\n]/',$server.$share)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_smb_invalid'),400);
        $clean['server']=$server;$clean['share']=$share;
    } else {
        $url=trim((string)($params['webdav_url']??'')); if($url===''||strlen($url)>2048||!preg_match('#^https?://#i',$url)||preg_match('/[\x00\r\n]/',$url)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_webdav_invalid'),400); $clean['webdav_url']=$url;
    }
} elseif ($operation === 'backup.target.delete' || $operation === 'backup.target.test') {
    $targetId = strtoupper(trim((string)($params['target_id'] ?? '')));
    if (!preg_match('/^BKT-[A-Z0-9._-]{4,64}$/',$targetId)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_invalid'),400);
    $clean=array('target_id'=>$targetId);
} elseif ($operation === 'backup.providers.list') {
    $clean=array();
} elseif ($operation === 'backup.provider.action') {
    $provider=strtolower(trim((string)($params['provider']??'')));
    $verb=strtolower(trim((string)($params['action']??'')));
    $jobId=trim((string)($params['job_id']??''));
    if(!preg_match('/^[a-z0-9._-]{1,80}$/',$provider)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_invalid'),400);
    if(!in_array($verb,array('backup','active_full','standalone_full'),true)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_action_invalid'),400);
    if($jobId!==''&&!preg_match('/^\{?[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}?$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_job_invalid'),400);
    $clean=array('provider'=>$provider,'action'=>$verb,'job_id'=>$jobId);
} elseif ($operation === 'backup.provider.status') {
    $jobId=strtoupper(trim((string)($params['job_id']??'')));
    if($jobId!==''&&!preg_match('/^BP[ER]-[A-Z0-9._-]{1,64}$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_run_invalid'),400);
    $clean=$jobId===''?array():array('job_id'=>$jobId);
} elseif ($operation === 'backup.provider.stop') {
    $jobId=strtoupper(trim((string)($params['job_id']??'')));
    if($jobId!==''&&!preg_match('/^BP[ER]-[A-Z0-9._-]{1,64}$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_run_invalid'),400);
    $clean=$jobId===''?array():array('job_id'=>$jobId);
} elseif ($operation === 'backup.provider.config.get') {
    $provider=strtolower(trim((string)($params['provider']??'veeam-agent-windows')));
    if(!preg_match('/^[a-z0-9._-]{1,80}$/',$provider)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_invalid'),400);
    $clean=array('provider'=>$provider);
} elseif ($operation === 'backup.provider.config.set') {
    $provider=strtolower(trim((string)($params['provider']??'veeam-agent-windows')));
    $configXml=(string)($params['config_xml']??'');
    $username=trim((string)($params['username']??''));
    $password=(string)($params['password']??'');
    if(!preg_match('/^[a-z0-9._-]{1,80}$/',$provider)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_invalid'),400);
    if($configXml===''||strlen($configXml)>57344||strpos($configXml,"\0")!==false) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_config_invalid'),400);
    if(strlen($username)>512||preg_match('/[\x00\r\n]/',$username)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_username_invalid'),400);
    if(strlen($password)>4096||strpos($password,"\0")!==false) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_password_invalid'),400);
    $clean=array('provider'=>$provider,'config_xml'=>$configXml,'username'=>$username,'password'=>$password);
} elseif ($operation === 'backup.provider.recovery.iso') {
    $provider=strtolower(trim((string)($params['provider']??'veeam-agent-windows')));
    $path=trim((string)($params['path']??''));
    if(!preg_match('/^[a-z0-9._-]{1,80}$/',$provider)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_invalid'),400);
    if($path===''||strlen($path)>32000||preg_match('/[\x00\r\n]/',$path)||!preg_match('/\.iso$/i',$path)) dmd_json_response(array('ok'=>false,'error'=>'backup_provider_recovery_path_invalid'),400);
    $clean=array('provider'=>$provider,'path'=>$path);
} elseif ($operation === 'backup.image.list') {
    $clean=array();
} elseif ($operation === 'backup.image.start') {
    $targetId=strtoupper(trim((string)($params['target_id']??'')));
    if(!preg_match('/^BKT-[A-Z0-9._-]{4,64}$/',$targetId)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_invalid'),400);
    $allCritical=!array_key_exists('all_critical',$params)||!empty($params['all_critical']);
    $volumes=array();
    foreach((array)($params['volumes']??array()) as $v){
        $v=strtoupper(rtrim(trim((string)$v),"\\/"));
        if(!preg_match('/^[A-Z]:$/',$v)) dmd_json_response(array('ok'=>false,'error'=>'backup_image_volume_invalid'),400);
        if(!in_array($v,$volumes,true)) $volumes[]=$v;
        if(count($volumes)>26) dmd_json_response(array('ok'=>false,'error'=>'backup_image_volumes_invalid'),400);
    }
    if(!$allCritical&&!count($volumes)) dmd_json_response(array('ok'=>false,'error'=>'backup_image_source_required'),400);
    $clean=array('target_id'=>$targetId,'all_critical'=>$allCritical,'volumes'=>$volumes);
} elseif ($operation === 'backup.image.status' || $operation === 'backup.image.stop') {
    $jobId=strtoupper(trim((string)($params['job_id']??'')));
    if($jobId!==''&&!preg_match('/^IMG-[A-Z0-9._-]{1,64}$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'backup_image_run_invalid'),400);
    $clean=$jobId===''?array():array('job_id'=>$jobId);
} elseif ($operation === 'backup.smb.discover') {
    $targetId = strtoupper(trim((string)($params['target_id'] ?? '')));
    if ($targetId !== '' && !preg_match('/^BKT-[A-Z0-9._-]{4,64}$/',$targetId)) dmd_json_response(array('ok'=>false,'error'=>'backup_target_invalid'),400);
    $server=trim((string)($params['server']??''));
    $share=trim((string)($params['share']??''));
    $folder=trim((string)($params['folder']??''));
    $username=trim((string)($params['username']??''));
    $password=(string)($params['password']??'');
    if($targetId==='' && ($server===''||strlen($server)>255||preg_match('/[\\\/:*?"<>|\x00\r\n]/',$server))) dmd_json_response(array('ok'=>false,'error'=>'backup_smb_server_invalid'),400);
    if(strlen($share)>255||strlen($folder)>2048||strlen($username)>320||strlen($password)>2048||preg_match('/[\x00\r\n]/',$share.$folder.$username.$password)) dmd_json_response(array('ok'=>false,'error'=>'backup_smb_fields_invalid'),400);
    $clean=array('target_id'=>$targetId,'server'=>$server,'share'=>$share,'folder'=>$folder,'username'=>$username,'password'=>$password);
} elseif ($operation === 'network.localnets.list') {
    $clean=array();
} elseif ($operation === 'network.scan.start') {
    $cidr = trim((string)($params['cidr'] ?? ''));
    if (!preg_match('/^([0-9]{1,3}(?:\.[0-9]{1,3}){3})\/(\d{1,2})$/',$cidr,$m) || !filter_var($m[1],FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) dmd_json_response(array('ok'=>false,'error'=>'network_scan_cidr_invalid'),400);
    $prefix=(int)$m[2]; if($prefix<22||$prefix>32)dmd_json_response(array('ok'=>false,'error'=>'network_scan_range_too_large'),400);
    $portsRaw=$params['ports']??array(); if(is_string($portsRaw))$portsRaw=preg_split('/[,;\s]+/',$portsRaw,-1,PREG_SPLIT_NO_EMPTY); if(!is_array($portsRaw))$portsRaw=array();
    $ports=array(); foreach($portsRaw as $v){$n=(int)$v;if($n<1||$n>65535)dmd_json_response(array('ok'=>false,'error'=>'network_scan_port_invalid'),400);$ports[]=$n;} $ports=array_values(array_unique($ports)); sort($ports); if(count($ports)>24)dmd_json_response(array('ok'=>false,'error'=>'network_scan_ports_too_many'),400);
    $timeout=max(100,min(2000,(int)($params['timeout_ms']??250)));
    $clean=array('cidr'=>$cidr,'ports'=>$ports,'timeout_ms'=>$timeout,'resolve_names'=>!isset($params['resolve_names'])||!empty($params['resolve_names']));
} elseif ($operation === 'network.scan.status' || $operation === 'network.scan.stop') {
    $jobId = strtoupper(trim((string)($params['job_id'] ?? '')));
    if ($jobId !== '' && !preg_match('/^NET-[A-Z0-9._-]{1,64}$/',$jobId)) dmd_json_response(array('ok'=>false,'error'=>'network_scan_job_invalid'),400);
    $clean = $jobId === '' ? array() : array('job_id'=>$jobId);
} elseif ($operation === 'network.adapters.list') {
    $alias = trim((string)($params['alias'] ?? ''));
    if (strlen($alias) > 256 || preg_match('/[\x00\r\n]/',$alias)) dmd_json_response(array('ok'=>false,'error'=>'network_alias_invalid'),400);
    $clean = $alias === '' ? array() : array('alias'=>$alias);
} elseif ($operation === 'network.configure') {
    $alias = trim((string)($params['alias'] ?? ''));
    $dhcp = !empty($params['dhcp']);
    $ipv4 = trim((string)($params['ipv4'] ?? ''));
    $prefix = isset($params['prefix_length']) ? (int)$params['prefix_length'] : 24;
    $gateway = trim((string)($params['gateway'] ?? ''));
    $dnsRaw = $params['dns'] ?? array();
    if (is_string($dnsRaw)) $dnsRaw = preg_split('/[,;\s]+/', $dnsRaw, -1, PREG_SPLIT_NO_EMPTY);
    $dns = is_array($dnsRaw) ? array_values(array_filter(array_map('trim',array_map('strval',$dnsRaw)),fn($v)=>$v!=='')) : array();
    if ($alias === '' || strlen($alias) > 256 || preg_match('/[\x00\r\n]/',$alias)) dmd_json_response(array('ok'=>false,'error'=>'network_alias_invalid'),400);
    if (!$dhcp && !filter_var($ipv4,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) dmd_json_response(array('ok'=>false,'error'=>'ipv4_invalid'),400);
    if (!$dhcp && ($prefix < 0 || $prefix > 32)) dmd_json_response(array('ok'=>false,'error'=>'prefix_invalid'),400);
    if ($gateway !== '' && !filter_var($gateway,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) dmd_json_response(array('ok'=>false,'error'=>'gateway_invalid'),400);
    if (count($dns) > 16) dmd_json_response(array('ok'=>false,'error'=>'dns_too_many'),400);
    foreach($dns as $dnsIp) if(!filter_var($dnsIp,FILTER_VALIDATE_IP)) dmd_json_response(array('ok'=>false,'error'=>'dns_invalid'),400);
    $clean = array('alias'=>$alias,'dhcp'=>$dhcp,'ipv4'=>$ipv4,'prefix_length'=>$prefix,'gateway'=>$gateway,'dns'=>$dns,'restart'=>!isset($params['restart']) || !empty($params['restart']));
} elseif ($operation === 'network.adapter.control') {
    $alias = trim((string)($params['alias'] ?? ''));
    $verb = strtolower(trim((string)($params['operation'] ?? 'restart')));
    if ($alias === '' || strlen($alias) > 256 || preg_match('/[\x00\r\n]/',$alias)) dmd_json_response(array('ok'=>false,'error'=>'network_alias_invalid'),400);
    if (!in_array($verb,array('enable','disable','restart'),true)) dmd_json_response(array('ok'=>false,'error'=>'network_operation_invalid'),400);
    $clean = array('alias'=>$alias,'operation'=>$verb);
} elseif ($operation === 'network.ports.list') {
    $clean = array('offset'=>max(0,(int)($params['offset'] ?? 0)),'limit'=>max(20,min(100,(int)($params['limit'] ?? 80))));
} elseif ($operation === 'firewall.list') {
    $query = trim((string)($params['query'] ?? '')); if(strlen($query)>200)$query=substr($query,0,200);
    $clean = array('query'=>$query,'offset'=>max(0,(int)($params['offset'] ?? 0)),'limit'=>max(20,min(80,(int)($params['limit'] ?? 60))));
} elseif ($operation === 'firewall.delete') {
    $name = trim((string)($params['name'] ?? ''));
    if ($name === '' || strlen($name)>512 || preg_match('/[\x00\r\n]/',$name)) dmd_json_response(array('ok'=>false,'error'=>'firewall_name_invalid'),400);
    $clean = array('name'=>$name);
} elseif ($operation === 'firewall.add' || $operation === 'firewall.set') {
    $name = trim((string)($params['name'] ?? ''));
    $direction = strtolower(trim((string)($params['direction'] ?? 'inbound')));
    $fwAction = strtolower(trim((string)($params['action'] ?? 'allow')));
    $protocol = strtoupper(trim((string)($params['protocol'] ?? 'ANY')));
    if ($name === '' || strlen($name)>512 || preg_match('/[\x00\r\n]/',$name)) dmd_json_response(array('ok'=>false,'error'=>'firewall_name_invalid'),400);
    if (!in_array($direction,array('inbound','outbound'),true) || !in_array($fwAction,array('allow','block'),true) || !in_array($protocol,array('TCP','UDP','ANY'),true)) dmd_json_response(array('ok'=>false,'error'=>'firewall_rule_invalid'),400);
    $clean = array('name'=>$name,'display_name'=>trim((string)($params['display_name'] ?? $name)),'direction'=>$direction,'action'=>$fwAction,'protocol'=>$protocol,'local_port'=>trim((string)($params['local_port'] ?? '')),'remote_port'=>trim((string)($params['remote_port'] ?? '')),'program'=>trim((string)($params['program'] ?? '')),'remote_address'=>trim((string)($params['remote_address'] ?? '')),'enabled'=>!isset($params['enabled']) || !empty($params['enabled']));
    foreach($clean as $v) if(is_string($v) && (strlen($v)>4096 || preg_match('/[\x00\r\n]/',$v))) dmd_json_response(array('ok'=>false,'error'=>'firewall_parameter_invalid'),400);
} elseif ($operation === 'storage.disks.list') {
    $clean = array();
} elseif ($operation === 'storage.format') {
    if (empty($params['confirm'])) dmd_json_response(array('ok'=>false,'error'=>'format_confirmation_required'),400);
    $filesystem = strtoupper(trim((string)($params['filesystem'] ?? 'NTFS')));
    if (!in_array($filesystem,array('NTFS','EXFAT','FAT32'),true)) dmd_json_response(array('ok'=>false,'error'=>'filesystem_invalid'),400);
    $drive = strtoupper(rtrim(trim((string)($params['drive_letter'] ?? '')),':'));
    $disk = isset($params['disk_number']) ? (int)$params['disk_number'] : -1;
    $whole = !empty($params['whole_disk']);
    if ($drive !== '' && !preg_match('/^[A-Z]$/',$drive)) dmd_json_response(array('ok'=>false,'error'=>'drive_letter_invalid'),400);
    if ($drive === '' && $disk < 0) dmd_json_response(array('ok'=>false,'error'=>'format_target_missing'),400);
    if ($disk >= 0 && !$whole) dmd_json_response(array('ok'=>false,'error'=>'whole_disk_required'),400);
    $label = trim((string)($params['label'] ?? '')); if(strlen($label)>64 || preg_match('/[\x00\r\n]/',$label)) dmd_json_response(array('ok'=>false,'error'=>'label_invalid'),400);
    $clean = array('confirm'=>true,'filesystem'=>$filesystem,'label'=>$label,'drive_letter'=>$drive,'disk_number'=>$disk,'whole_disk'=>$whole);
} elseif ($operation === 'security.status') {
    $clean = array();
} elseif ($operation === 'security.defender.action') {
    $verb = strtolower(trim((string)($params['operation'] ?? '')));
    if (!in_array($verb,array('scan_quick','scan_full','signatures_update','realtime_enable','realtime_disable'),true)) dmd_json_response(array('ok'=>false,'error'=>'defender_operation_invalid'),400);
    $clean = array('operation'=>$verb);
} elseif ($operation === 'software.list') {
    $query = trim((string)($params['query'] ?? '')); if (strlen($query) > 120) $query = substr($query, 0, 120);
    $clean = array('offset'=>max(0,(int)($params['offset'] ?? 0)),'limit'=>max(10,min(60,(int)($params['limit'] ?? 40))),'query'=>$query);
} elseif ($operation === 'software.install') {
    $packageId = strtoupper(trim((string)($params['package_id'] ?? '')));
    $token = trim((string)($params['token'] ?? ''));
    $arguments = trim((string)($params['arguments'] ?? ''));
    $timeout = isset($params['timeout_seconds']) ? (int)$params['timeout_seconds'] : 1200;
    if (!preg_match('/^PKG-[A-F0-9]{24}$/', $packageId)) dmd_json_response(array('ok'=>false,'error'=>'package_id_invalid'), 400);
    if (!preg_match('/^[A-Fa-f0-9]{64}$/', $token)) dmd_json_response(array('ok'=>false,'error'=>'package_token_invalid'), 400);
    if (strlen($arguments) > 4096 || preg_match('/[\x00\r\n]/', $arguments)) dmd_json_response(array('ok'=>false,'error'=>'installer_arguments_invalid'), 400);
    $pkgCheck = dmd_agent_software_package_validate($packageId,$token,false);
    if (empty($pkgCheck['ok'])) dmd_json_response($pkgCheck,400);
    $pkg = $pkgCheck['package'];

    $deviceFile = dmd_agent_device_file($agentId);
    $device = ($deviceFile !== '' && is_file($deviceFile)) ? dmd_agent_json_read($deviceFile,array()) : array();
    if (!$device || (string)($device['status'] ?? '') !== 'active') dmd_json_response(array('ok'=>false,'error'=>'agent_not_active'),400);
    $enrollment = !empty($device['enrollment_id']) ? dmd_agent_load_enrollment($device['enrollment_id']) : array();
    $serverUrl = rtrim((string)($enrollment['server_url'] ?? ''),'/');
    if ($serverUrl === '') dmd_json_response(array('ok'=>false,'error'=>'server_url_missing'),400);
    $downloadUrl = $serverUrl . '/adm/agent/api/agent_software_package.php?package_id=' . rawurlencode($packageId) . '&token=' . rawurlencode($token);
    $clean = array(
        'url'=>$downloadUrl,
        'sha256'=>(string)$pkg['sha256'],
        'filename'=>(string)$pkg['file_name'],
        'arguments'=>$arguments,
        'timeout_seconds'=>max(60,min(1800,$timeout)),
    );
} elseif ($operation === 'software.uninstall') {
    $id = strtoupper(trim((string)($params['id'] ?? '')));
    if (!preg_match('/^SW-[A-F0-9]{24}$/', $id)) dmd_json_response(array('ok'=>false,'error'=>'software_id_invalid'), 400);
    $clean = array('id'=>$id);
} elseif ($operation === 'software.winget.search') {
    $query = trim((string)($params['query'] ?? ''));
    if (strlen($query)<2 || strlen($query)>180 || preg_match('/[\x00\r\n]/',$query)) dmd_json_response(array('ok'=>false,'error'=>'winget_query_invalid'),400);
    $clean = array('query'=>$query);
} elseif ($operation === 'software.winget.install' || $operation === 'software.winget.uninstall') {
    $id = trim((string)($params['id'] ?? ''));
    if ($id==='' || strlen($id)>220 || preg_match('/[\x00\r\n]/',$id)) dmd_json_response(array('ok'=>false,'error'=>'winget_id_invalid'),400);
    $clean = array('id'=>$id);
} elseif ($operation === 'software.updates.scan') {
    $clean = array('include_unknown'=>!isset($params['include_unknown']) || !empty($params['include_unknown']));
} elseif ($operation === 'software.updates.apply') {
    $id = trim((string)($params['id'] ?? ''));
    if ($id !== '' && !preg_match('/^[A-Za-z0-9._+\-]{2,180}$/', $id)) dmd_json_response(array('ok'=>false,'error'=>'winget_id_invalid'), 400);
    $clean = array('id'=>$id,'all'=>$id === '' ? true : !empty($params['all']));
} elseif ($operation === 'windows_update.scan' || $operation === 'windows.updates.scan') {
    $clean = array('force'=>!empty($params['force']));
} elseif ($operation === 'windows_update.install' || $operation === 'windows.updates.apply') {
    $ids = $params['update_ids'] ?? array(); if(!is_array($ids))$ids=array();
    $ids = array_values(array_filter(array_map('strval',$ids),fn($v)=>preg_match('/^[A-Fa-f0-9-]{8,64}$/',$v)));
    $clean = array('update_ids'=>$ids,'all'=>!isset($params['all']) || !empty($params['all']));
} elseif ($operation === 'windows_update.history') {
    $clean = array('limit'=>max(1,min(200,(int)($params['limit'] ?? 50))));
} elseif ($operation === 'filesystem.roots') {
    $clean = array();
} elseif ($operation === 'filesystem.list') {
    $path = trim((string)($params['path'] ?? ''));
    if ($path === '' || strlen($path) > 32000) dmd_json_response(array('ok'=>false,'error'=>'path_invalid'), 400);
    $clean = array('path'=>$path,'offset'=>max(0,(int)($params['offset'] ?? 0)),'limit'=>max(10,min(120,(int)($params['limit'] ?? 80))));
} elseif ($operation === 'filesystem.read') {
    $path = trim((string)($params['path'] ?? ''));
    if ($path === '' || strlen($path) > 32000) dmd_json_response(array('ok'=>false,'error'=>'path_invalid'), 400);
    $clean = array('path'=>$path,'offset'=>max(0,(int)($params['offset'] ?? 0)),'length'=>max(1,min(28672,(int)($params['length'] ?? 28672))));
} elseif ($operation === 'filesystem.write') {
    $path = trim((string)($params['path'] ?? ''));
    $data = (string)($params['data_base64'] ?? '');
    if ($path === '' || strlen($path) > 32000 || strlen($data) > 42000) dmd_json_response(array('ok'=>false,'error'=>'file_write_payload_invalid'), 400);
    if ($data !== '' && !preg_match('/^[A-Za-z0-9+\/=]+$/', $data)) dmd_json_response(array('ok'=>false,'error'=>'file_write_base64_invalid'), 400);
    $clean = array('path'=>$path,'offset'=>max(0,(int)($params['offset'] ?? 0)),'truncate'=>!empty($params['truncate']),'data_base64'=>$data);
} elseif ($operation === 'filesystem.mkdir') {
    $path = trim((string)($params['path'] ?? '')); $name = trim((string)($params['name'] ?? ''));
    if ($path === '' || $name === '' || strlen($path) > 32000 || strlen($name) > 240) dmd_json_response(array('ok'=>false,'error'=>'mkdir_payload_invalid'), 400);
    $clean = array('path'=>$path,'name'=>$name);
} elseif ($operation === 'filesystem.delete') {
    $path = trim((string)($params['path'] ?? ''));
    if ($path === '' || strlen($path) > 32000) dmd_json_response(array('ok'=>false,'error'=>'path_invalid'), 400);
    $clean = array('path'=>$path,'recursive'=>!empty($params['recursive']));
} elseif ($operation === 'filesystem.rename') {
    $path = trim((string)($params['path'] ?? '')); $name = trim((string)($params['name'] ?? ''));
    if ($path === '' || $name === '' || strlen($path) > 32000 || strlen($name) > 240) dmd_json_response(array('ok'=>false,'error'=>'rename_payload_invalid'), 400);
    $clean = array('path'=>$path,'name'=>$name);
} elseif ($operation === 'filesystem.archive') {
    $path=trim((string)($params['path']??''));$archive=trim((string)($params['archive_path']??''));if($path===''||$archive===''||strlen($path)>32000||strlen($archive)>32000)dmd_json_response(array('ok'=>false,'error'=>'archive_payload_invalid'),400);$clean=array('path'=>$path,'archive_path'=>$archive);
} elseif ($operation === 'filesystem.extract') {
    $path=trim((string)($params['path']??''));$archive=trim((string)($params['archive_path']??''));if($path===''||$archive===''||strlen($path)>32000||strlen($archive)>32000)dmd_json_response(array('ok'=>false,'error'=>'extract_payload_invalid'),400);$clean=array('path'=>$path,'archive_path'=>$archive);
}

$meta = $catalog[$operation];
$queued = dmd_agent_queue_command($agentId, $meta['command'], $clean, $email, $meta['capability'], $meta['ttl']);
if (empty($queued['ok'])) dmd_json_response($queued, 400);

$severity = in_array($operation, array('processes.kill','processes.start','processes.restart','services.control','services.configure','system.rename','sessions.logoff','sessions.disconnect','system.restart','system.shutdown','system.terminal','filesystem.write','filesystem.mkdir','filesystem.delete','filesystem.rename','software.install','software.uninstall','software.winget.install','software.winget.uninstall','software.updates.apply','windows_update.install','windows.updates.apply','registry.set','registry.delete','devices.removable.eject','devices.removable.block','devices.removable.unblock','network.paths.add','network.paths.remove','network.configure','network.adapter.control','backup.files.start','backup.files.stop','backup.target.configure','backup.target.delete','backup.provider.action','backup.provider.stop','backup.provider.config.set','backup.provider.recovery.iso','backup.image.start','backup.image.stop','network.scan.start','network.scan.stop','firewall.add','firewall.set','firewall.delete','storage.format','security.defender.action','filesystem.archive','filesystem.extract'), true) ? 'warning' : 'info';
$auditParams = $clean;
if ($operation === 'software.install' && isset($auditParams['url'])) $auditParams['url'] = '[package_url_redacted]';
if (in_array($operation,array('backup.target.configure','backup.smb.discover','backup.provider.config.set'),true) && array_key_exists('password',$auditParams)) $auditParams['password'] = $auditParams['password'] !== '' ? '[redacted]' : '';
if ($operation === 'backup.provider.config.set' && array_key_exists('config_xml',$auditParams)) $auditParams['config_xml'] = '[veeam_config_redacted]';
dmd_system_log($meta['audit'], $agentId, $severity, 'Commande DMD-Agent depuis l’administration.', array(
    'operation'=>$operation,
    'command_id'=>$queued['command']['command_id'] ?? '',
    'params'=>$auditParams,
));

$responseCommand = $queued['command'];
if (in_array($operation,array('backup.target.configure','backup.smb.discover','backup.provider.config.set'),true) && isset($responseCommand['payload']) && is_array($responseCommand['payload']) && array_key_exists('password',$responseCommand['payload'])) {
    $responseCommand['payload']['password'] = $responseCommand['payload']['password'] !== '' ? '[redacted]' : '';
}
if ($operation === 'backup.provider.config.set' && isset($responseCommand['payload']) && is_array($responseCommand['payload']) && array_key_exists('config_xml',$responseCommand['payload'])) {
    $responseCommand['payload']['config_xml'] = '[veeam_config_redacted]';
}
dmd_json_response(array('ok'=>true,'command'=>$responseCommand));
