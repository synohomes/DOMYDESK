<?php
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$version=trim((string)($_GET['version']??''));
if(!preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]{0,31}$/',$version)){
    http_response_code(400);
    exit;
}

$root=dirname(dirname(dirname(__DIR__)));
$file=$root.'/updates/update.'.$version.'.exe';
if(!is_file($file)){
    http_response_code(404);
    exit;
}

$size=(int)filesize($file);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="update.'.$version.'.exe"');
header('Content-Length: '.$size);
$fh=fopen($file,'rb');
if(!$fh){
    http_response_code(500);
    exit;
}
while(!feof($fh)){
    echo fread($fh,1024*1024);
    if(connection_aborted())break;
}
fclose($fh);
