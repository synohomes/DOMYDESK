<?php
require_once dirname(__DIR__) . '/includes/software_packages.php';
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') { http_response_code(405); exit; }
$id = (string)($_GET['package_id'] ?? '');
$token = (string)($_GET['token'] ?? '');
$result = dmd_agent_software_package_validate($id,$token,true);
if (empty($result['ok'])) { http_response_code(404); header('Cache-Control: no-store'); exit; }
$p = $result['package']; $file = (string)$p['_blob'];
if (!is_file($file)) { http_response_code(404); exit; }
header('Content-Type: application/octet-stream');
header('Content-Length: '.(string)filesize($file));
header('Content-Disposition: attachment; filename="DMD-Software-Package.'.($p['extension']==='msi'?'msi':'exe').'"');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
@set_time_limit(0);
$fh = @fopen($file,'rb'); if (!$fh) { http_response_code(500); exit; }
while (!feof($fh)) { $buf=fread($fh,1024*1024); if ($buf===false) break; echo $buf; flush(); }
fclose($fh); exit;
