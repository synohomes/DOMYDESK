<?php
require_once dirname(__DIR__) . '/includes/agent_core.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Content-Type-Options: nosniff');
$identity = dmd_agent_verify_instance_identity();
if (empty($identity['ok'])) { http_response_code(503); echo json_encode(array('ok'=>false,'code'=>'instance_identity_invalid','state'=>isset($identity['state'])?$identity['state']:'unknown')); exit; }
$payload = array(
    'schema' => 1,
    'protocol_version' => DMD_AGENT_PROTOCOL,
    'instance_id' => $identity['manifest']['instance_id'],
    'identity_algorithm' => 'Ed25519',
    'public_key' => $identity['public_key'],
    'public_key_fingerprint' => $identity['manifest']['public_key_fingerprint'],
    'server_time' => gmdate('c'),
    'nonce' => dmd_agent_b64url_encode(random_bytes(16)),
);
$signature = dmd_agent_sign_payload($payload);
echo json_encode(array('ok'=>true,'payload'=>$payload,'signature_algorithm'=>'Ed25519','signature'=>$signature), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
