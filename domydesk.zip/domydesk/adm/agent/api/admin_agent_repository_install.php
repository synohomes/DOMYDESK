<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/agent_repository.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$itemKey = strtolower(trim((string)($payload['item_key'] ?? '')));

@ini_set('output_buffering', '0');
@ini_set('zlib.output_compression', '0');
while (ob_get_level() > 0) @ob_end_flush();
header('Content-Type: application/x-ndjson; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('X-Accel-Buffering: no');
header('X-Content-Type-Options: nosniff');

function dmd_repo_event($stage, $progress, $message, $extra = array()) {
    $row = array_merge(array(
        'stage'=>(string)$stage,
        'progress'=>max(0,min(100,(int)$progress)),
        'message'=>(string)$message,
    ), is_array($extra) ? $extra : array());
    echo json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    @flush();
}

$lock = null;
$zipTmp = '';
$exeTmp = '';
try {
    dmd_repo_event('scan', 4, 'Analyse du dépôt Agent…');
    $found = dmd_agent_repo_find_item($itemKey);
    if (empty($found['ok']) || empty($found['item'])) throw new RuntimeException((string)($found['error'] ?? 'item_not_found'));
    $item = $found['item'];

    $stateDir = dmd_agent_repo_state_dir();
    if (!dmd_agent_repo_ensure_dir($stateDir)) throw new RuntimeException('repository_state_dir_failed');
    $lockPath = $stateDir . '/install.lock';
    $lock = @fopen($lockPath, 'c+');
    if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) throw new RuntimeException('repository_install_busy');

    dmd_repo_event('download', 10, 'Téléchargement de ' . (string)$item['name'] . '…', array('version'=>$item['version']));
    $zipTmp = $stateDir . '/release-' . bin2hex(random_bytes(8)) . '.zip';
    $download = dmd_agent_repo_download_file($item['download_url'], $zipTmp, function($pct, $downloaded, $total) {
        if ($pct >= 0) {
            $global = 10 + (int)floor(min(100,$pct) * 0.64);
            dmd_repo_event('download', $global, 'Téléchargement… ' . $pct . '%', array('download_percent'=>$pct,'downloaded'=>$downloaded,'total'=>$total));
        } else {
            dmd_repo_event('download', 34, 'Téléchargement en cours…', array('downloaded'=>$downloaded,'total'=>$total));
        }
    });
    if (empty($download['ok'])) throw new RuntimeException((string)($download['error'] ?? 'download_failed'));

    dmd_repo_event('verify', 78, 'Vérification du ZIP et du SHA-256…', array('zip_sha256'=>$download['sha256'] ?? ''));
    if (!is_file($zipTmp) || filesize($zipTmp) > DMD_AGENT_REPOSITORY_MAX_ZIP_BYTES) throw new RuntimeException('zip_size_invalid');

    dmd_repo_event('extract', 86, 'Extraction sécurisée de DMD-Installer.exe…');
    $exeTmp = $stateDir . '/installer-' . bin2hex(random_bytes(8)) . '.exe';
    $extract = dmd_agent_repo_extract_installer($zipTmp, $exeTmp);
    if (empty($extract['ok'])) throw new RuntimeException((string)($extract['error'] ?? 'installer_extract_failed'));

    dmd_repo_event('prepare', 94, 'Préparation de l’installateur pour les enrôlements…', array('exe_sha256'=>$extract['sha256'] ?? ''));
    $published = dmd_agent_repo_publish_installer($exeTmp, array(
        'version'=>$item['version'],
        'name'=>$item['name'],
        'item_key'=>$item['item_key'],
        'installed_by'=>$email,
    ));
    if (empty($published['ok'])) throw new RuntimeException((string)($published['error'] ?? 'installer_publish_failed'));

    if (function_exists('dmd_system_log')) {
        dmd_system_log('agent_repository_activated', (string)$item['version'], 'success', 'Installateur DMD-Agent activé depuis le dépôt distant.', array('source_name'=>$item['name'],'sha256'=>$published['local']['sha256'] ?? ''));
    }
    dmd_repo_event('done', 100, 'Agents DoMyDesk activés.', array('ok'=>true,'local'=>dmd_agent_repo_public_local_status(),'version'=>$item['version'],'source_name'=>$item['name']));
} catch (Throwable $e) {
    dmd_repo_event('error', 100, 'Activation impossible : ' . $e->getMessage(), array('ok'=>false,'error'=>$e->getMessage()));
} finally {
    if ($zipTmp !== '') @unlink($zipTmp);
    if ($exeTmp !== '') @unlink($exeTmp);
    if (is_resource($lock)) { @flock($lock, LOCK_UN); @fclose($lock); }
}
