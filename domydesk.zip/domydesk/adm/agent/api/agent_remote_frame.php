<?php
require_once dirname(__DIR__) . '/includes/agent_core.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
http_response_code(410);
echo json_encode(array(
    'ok'=>false,
    'code'=>'remote_binary_frame_retired',
    'message'=>'DMD-Remote 1.4.0 utilise exclusivement DMDStream via agent_remote.php.'
), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
exit;
