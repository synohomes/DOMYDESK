<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array()); dmd_api_require_csrf('agent_admin', $payload);
$result = dmd_agent_self_test();
if (!empty($result['ok'])) dmd_system_log('agent_secure_self_test', 'DMD-Agent', 'success', 'Autotest du protocole d’enrôlement sécurisé réussi.');
else dmd_system_log('agent_secure_self_test', 'DMD-Agent', 'error', 'Autotest du protocole d’enrôlement sécurisé en échec.', $result);
dmd_json_response($result, !empty($result['ok']) ? 200 : 500);
