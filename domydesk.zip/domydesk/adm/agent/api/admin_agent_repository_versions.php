<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/agent_repository.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$result = dmd_agent_repo_public_catalog();
if (empty($result['ok'])) {
    dmd_json_response(array(
        'ok'=>false,
        'error'=>(string)($result['error'] ?? 'repo_scan_failed'),
        'details'=>$result['details'] ?? null,
        'local'=>dmd_agent_repo_public_local_status(),
    ), 502);
}
dmd_json_response($result, 200);
