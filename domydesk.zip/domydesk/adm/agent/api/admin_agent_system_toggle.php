<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/agent_repository.php';

dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$enabled = !empty($payload['enabled']);
$result = dmd_agent_system_set_enabled($enabled, isset($email) ? (string)$email : '');

if (empty($result['ok'])) {
    dmd_json_response($result, 500);
}

if (function_exists('dmd_system_log')) {
    dmd_system_log(
        $enabled ? 'agent_system_enabled' : 'agent_system_disabled',
        $enabled ? 'enabled' : 'disabled',
        'success',
        $enabled ? 'Système Agents DoMyDesk activé.' : 'Système Agents DoMyDesk désactivé.',
        array('actor'=>isset($email) ? (string)$email : '')
    );
}

dmd_json_response($result, 200);
