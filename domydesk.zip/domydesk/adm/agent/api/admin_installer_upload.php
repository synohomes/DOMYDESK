<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
dmd_api_require_csrf('agent_admin', $_POST);

const DMD_INSTALLER_UPLOAD_MAX_ARCHIVE = 134217728; // 128 MiB
const DMD_INSTALLER_UPLOAD_MAX_EXE = 100663296;     // 96 MiB, cohérent avec le téléchargement Agent
const DMD_INSTALLER_MARKER = 'DMD-INSTALLER-AUTONOME-H264-WS';

function dmd_installer_upload_fail($error, $status = 400, $extra = array()) {
    dmd_json_response(array_merge(array('ok'=>false,'error'=>$error), $extra), $status);
}

function dmd_installer_validate_exe($path) {
    if (!is_file($path) || !is_readable($path)) return array('ok'=>false,'error'=>'installer_missing');
    $size = @filesize($path);
    if ($size === false || $size < 1024 || $size > DMD_INSTALLER_UPLOAD_MAX_EXE) return array('ok'=>false,'error'=>'installer_size_invalid');
    $fh = @fopen($path, 'rb');
    if (!$fh) return array('ok'=>false,'error'=>'installer_unreadable');
    $magic = fread($fh, 2);
    if ($magic !== 'MZ') { fclose($fh); return array('ok'=>false,'error'=>'installer_mz_missing'); }
    rewind($fh);
    $marker = DMD_INSTALLER_MARKER;
    $carry = '';
    $found = false;
    while (!feof($fh)) {
        $chunk = fread($fh, 1048576);
        if ($chunk === false) break;
        $hay = $carry . $chunk;
        if (strpos($hay, $marker) !== false) { $found = true; break; }
        $carry = substr($hay, -strlen($marker));
    }
    fclose($fh);
    if (!$found) return array('ok'=>false,'error'=>'installer_marker_missing');
    return array('ok'=>true,'size'=>(int)$size,'sha256'=>strtolower(hash_file('sha256',$path)));
}

if (empty($_FILES['installer_zip']) || !is_array($_FILES['installer_zip'])) {
    dmd_installer_upload_fail('installer_zip_missing');
}
$file = $_FILES['installer_zip'];
if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    dmd_installer_upload_fail('installer_zip_upload_error', 400, array('upload_error'=>(int)($file['error'] ?? -1)));
}
$size = (int)($file['size'] ?? 0);
$tmpUpload = (string)($file['tmp_name'] ?? '');
$name = (string)($file['name'] ?? '');
if ($size < 1 || $size > DMD_INSTALLER_UPLOAD_MAX_ARCHIVE) dmd_installer_upload_fail('installer_zip_size_invalid');
if (!is_uploaded_file($tmpUpload)) dmd_installer_upload_fail('installer_zip_not_uploaded');
if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'zip') dmd_installer_upload_fail('installer_zip_extension_invalid');
$entryStream = null;
$entrySize = 0;
$matches = 0;
$archiveClose = static function(){};

if (class_exists('ZipArchive')) {
    $zip = new ZipArchive();
    $open = $zip->open($tmpUpload, ZipArchive::RDONLY);
    if ($open !== true) dmd_installer_upload_fail('installer_zip_open_failed');
    $entryName = '';
    for ($i=0; $i<$zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (!is_array($stat)) continue;
        $entry = str_replace('\\','/',(string)($stat['name'] ?? ''));
        if ($entry === '' || substr($entry,-1)==='/') continue;
        if (strcasecmp(basename($entry), 'DMD-Installer.exe') === 0) {
            $matches++;
            $entryName = (string)($stat['name'] ?? '');
            $entrySize = (int)($stat['size'] ?? 0);
        }
    }
    if ($matches === 1 && $entryName !== '') $entryStream = $zip->getStream($entryName);
    $archiveClose = static function() use ($zip){ $zip->close(); };
} elseif (class_exists('PharData')) {
    try {
        $phar = new PharData($tmpUpload);
        $entryPath = '';
        $it = new RecursiveIteratorIterator($phar, RecursiveIteratorIterator::LEAVES_ONLY);
        foreach ($it as $entry) {
            if (!$entry instanceof SplFileInfo || !$entry->isFile()) continue;
            if (strcasecmp($entry->getFilename(), 'DMD-Installer.exe') !== 0) continue;
            $matches++;
            $entryPath = $entry->getPathname();
            $entrySize = (int)$entry->getSize();
        }
        if ($matches === 1 && $entryPath !== '') $entryStream = @fopen($entryPath, 'rb');
        $archiveClose = static function(){};
    } catch (Throwable $e) {
        dmd_installer_upload_fail('installer_zip_open_failed');
    }
} else {
    dmd_installer_upload_fail('zip_reader_missing', 500);
}

if ($matches !== 1 || !$entryStream) {
    $archiveClose();
    dmd_installer_upload_fail($matches === 0 ? 'installer_exe_missing_in_zip' : ($matches > 1 ? 'installer_exe_duplicate_in_zip' : 'installer_exe_stream_failed'));
}
if ($entrySize < 1024 || $entrySize > DMD_INSTALLER_UPLOAD_MAX_EXE) {
    fclose($entryStream);
    $archiveClose();
    dmd_installer_upload_fail('installer_exe_size_invalid');
}

$binDir = dirname(__DIR__) . '/bin/windows-x64';
if (!is_dir($binDir) && !@mkdir($binDir, 0755, true) && !is_dir($binDir)) {
    fclose($entryStream);
    $archiveClose();
    dmd_installer_upload_fail('installer_bin_dir_create_failed', 500);
}
$destination = $binDir . '/DMD-Installer.exe';
$staged = $binDir . '/.DMD-Installer.upload-' . bin2hex(random_bytes(8)) . '.exe';
$out = @fopen($staged, 'wb');
if (!$out) {
    fclose($entryStream);
    $archiveClose();
    dmd_installer_upload_fail('installer_stage_open_failed', 500);
}
$written = 0;
$copyOK = true;
while (!feof($entryStream)) {
    $chunk = fread($entryStream, 1048576);
    if ($chunk === false) { $copyOK = false; break; }
    if ($chunk === '') continue;
    $written += strlen($chunk);
    if ($written > DMD_INSTALLER_UPLOAD_MAX_EXE) { $copyOK = false; break; }
    if (fwrite($out, $chunk) !== strlen($chunk)) { $copyOK = false; break; }
}
fflush($out);
fclose($out);
fclose($entryStream);
$archiveClose();
if (!$copyOK || $written < 1024) {
    @unlink($staged);
    dmd_installer_upload_fail('installer_extract_failed');
}

$validation = dmd_installer_validate_exe($staged);
if (empty($validation['ok'])) {
    @unlink($staged);
    dmd_installer_upload_fail((string)($validation['error'] ?? 'installer_invalid'));
}

$backup = $binDir . '/.DMD-Installer.replace-old.exe';
@unlink($backup);
$hadOld = is_file($destination);
if ($hadOld && !@rename($destination, $backup)) {
    @unlink($staged);
    dmd_installer_upload_fail('installer_backup_failed', 500);
}
if (!@rename($staged, $destination)) {
    if ($hadOld && is_file($backup)) @rename($backup, $destination);
    @unlink($staged);
    dmd_installer_upload_fail('installer_replace_failed', 500);
}
@chmod($destination, 0644);
@unlink($backup);
clearstatcache(true, $destination);

$final = dmd_installer_validate_exe($destination);
if (empty($final['ok'])) dmd_installer_upload_fail('installer_post_replace_validation_failed', 500);

dmd_system_log('agent_installer_upload','maintenance','warning','DMD-Installer remplacé depuis une archive ZIP.',array(
    'source_name'=>$name,
    'size'=>$final['size'],
    'sha256'=>$final['sha256'],
));

dmd_json_response(array(
    'ok'=>true,
    'file'=>'adm/agent/bin/windows-x64/DMD-Installer.exe',
    'size'=>$final['size'],
    'sha256'=>$final['sha256'],
    'updated_at'=>gmdate('c'),
));
