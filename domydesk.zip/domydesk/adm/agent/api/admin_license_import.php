<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
if (!function_exists('dmd_license_install_raw')) dmd_json_response(array('ok'=>false,'error'=>'license_engine_unavailable'), 500);
$raw = isset($payload['license_text']) ? (string)$payload['license_text'] : '';
if (strlen($raw) > 262144) dmd_json_response(array('ok'=>false,'error'=>'license_too_large'), 413);
$result = dmd_license_install_raw($raw);
if (!empty($result['ok'])) {
    dmd_system_log('dmd_license_import','license','success','Licence SynoHomes signée importée.',array('license_id'=>$result['status']['license_id']??'','revision'=>$result['status']['revision']??0));
}
dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
