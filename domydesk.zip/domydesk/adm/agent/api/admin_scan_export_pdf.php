<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$payload);

function dmd_scan_pdf_text($s){
    $s=(string)$s;
    if(function_exists('iconv')){$x=@iconv('UTF-8','Windows-1252//TRANSLIT',$s);if($x!==false)$s=$x;}
    $s=str_replace(array('\\','(',')',"\r","\n"),array('\\\\','\\(','\\)',' ',' '),$s);
    return $s;
}
function dmd_scan_pdf_cut($s,$n){$s=(string)$s;return strlen($s)>$n?substr($s,0,max(0,$n-3)).'...':$s;}
function dmd_scan_pdf_obj($id,$body){return $id." 0 obj\n".$body."\nendobj\n";}
function dmd_scan_pdf_build($scan,$meta){
    $hosts=isset($scan['result']['hosts'])&&is_array($scan['result']['hosts'])?$scan['result']['hosts']:(isset($scan['hosts'])&&is_array($scan['hosts'])?$scan['hosts']:array());
    $summary=isset($scan['summary'])&&is_array($scan['summary'])?$scan['summary']:array();
    $cidr=(string)($scan['cidr']??($summary['cidr']??($scan['result']['cidr']??'')));
    $hostsScanned=(int)($scan['result']['hosts_scanned']??($summary['hosts_scanned']??count($hosts)));
    $hostsFound=(int)($scan['result']['hosts_found']??($summary['hosts_found']??count($hosts)));
    $durationMs=(int)($scan['result']['duration_ms']??($summary['elapsed_ms']??0));
    $rowsPerPage=24;
    $pages=array_chunk($hosts,$rowsPerPage);if(!$pages)$pages=array(array());
    $pageContents=array();
    foreach($pages as $pi=>$rows){
        $c="0.7 w\n";
        $c.="BT /F1 16 Tf 32 558 Td (".dmd_scan_pdf_text('DoMyDesk - Scan réseau').") Tj ET\n";
        $sub='Sonde: '.($meta['hostname']?:$meta['agent_id']).' | Réseau: '.($cidr?:'—').' | Export: '.date('d/m/Y H:i:s');
        $c.="BT /F1 8 Tf 32 540 Td (".dmd_scan_pdf_text($sub).") Tj ET\n";
        $stats='Hôtes scannés: '.$hostsScanned.'   Détectés: '.$hostsFound.($durationMs>0?'   Durée: '.round($durationMs/1000,1).' s':'');
        $c.="BT /F1 8 Tf 32 526 Td (".dmd_scan_pdf_text($stats).") Tj ET\n";
        // header table
        $top=505;$rowH=18;
        $c.="32 $top m 810 $top l S\n";
        $headers=array(array(36,'IP'),array(118,'Nom'),array(390,'MAC'),array(525,'Ports / détection'));
        foreach($headers as $h){$c.="BT /F1 8 Tf ".$h[0]." ".($top-13)." Td (".dmd_scan_pdf_text($h[1]).") Tj ET\n";}
        $c.="32 ".($top-$rowH)." m 810 ".($top-$rowH)." l S\n";
        $y=$top-$rowH-13;
        foreach($rows as $r){
            if(!is_array($r))$r=array();
            $ip=dmd_scan_pdf_cut((string)($r['ip']??''),18);
            $name=dmd_scan_pdf_cut((string)($r['hostname']??'—'),45);
            $mac=dmd_scan_pdf_cut((string)($r['mac']??'—'),24);
            $ports='';
            if(isset($r['open_ports'])&&is_array($r['open_ports']))$ports=implode(', ',array_map('strval',$r['open_ports']));
            if(isset($r['detected_by'])&&is_array($r['detected_by'])&&$r['detected_by'])$ports.=($ports?' | ':'').implode('/',array_map('strval',$r['detected_by']));
            if($ports==='')$ports='—';$ports=dmd_scan_pdf_cut($ports,46);
            foreach(array(array(36,$ip),array(118,$name),array(390,$mac),array(525,$ports)) as $cell){$c.="BT /F1 7.5 Tf ".$cell[0]." $y Td (".dmd_scan_pdf_text($cell[1]).") Tj ET\n";}
            $lineY=$y-5;$c.="32 $lineY m 810 $lineY l S\n";$y-=$rowH;
        }
        $pageNo='Page '.($pi+1).' / '.count($pages);
        $c.="BT /F1 7 Tf 745 20 Td (".dmd_scan_pdf_text($pageNo).") Tj ET\n";
        $pageContents[]=$c;
    }
    $objects=array();
    $objects[1]='<< /Type /Catalog /Pages 2 0 R >>';
    $objects[3]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    $kids=array();$next=4;
    foreach($pageContents as $content){
        $contentId=$next++;$pageId=$next++;
        $objects[$contentId]='<< /Length '.strlen($content).' >>' . "\nstream\n".$content."endstream";
        $objects[$pageId]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 3 0 R >> >> /Contents '.$contentId.' 0 R >>';
        $kids[]=$pageId.' 0 R';
    }
    $objects[2]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';
    ksort($objects);
    $pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=array(0=>0);
    $max=max(array_keys($objects));
    for($i=1;$i<=$max;$i++){
        if(!isset($objects[$i]))continue;
        $offsets[$i]=strlen($pdf);$pdf.=dmd_scan_pdf_obj($i,$objects[$i]);
    }
    $xref=strlen($pdf);$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";
    for($i=1;$i<=$max;$i++){$off=$offsets[$i]??0;$pdf.=sprintf('%010d 00000 n ', $off)."\n";}
    $pdf.="trailer\n<< /Size ".($max+1)." /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
    return $pdf;
}

$agentId=dmd_agent_safe_agent_id($payload['agent_id']??'');
$scan=isset($payload['scan'])&&is_array($payload['scan'])?$payload['scan']:array();
if($agentId===''||!$scan)dmd_json_response(array('ok'=>false,'error'=>'scan_missing'),400);
$deviceFile=dmd_agent_device_file($agentId);$device=($deviceFile!==''&&is_file($deviceFile))?dmd_agent_json_read($deviceFile,array()):array();
$meta=array('agent_id'=>$agentId,'hostname'=>(string)($device['hostname']??''));
$pdf=dmd_scan_pdf_build($scan,$meta);
dmd_system_log('agent_network_scan_export','maintenance','info','Export PDF d’un scan réseau.',array('agent_id'=>$agentId,'hostname'=>$meta['hostname'],'cidr'=>(string)($scan['cidr']??($scan['summary']['cidr']??''))));
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="DMD-Scan-'.preg_replace('/[^A-Za-z0-9._-]+/','_',($meta['hostname']?:$agentId)).'-'.date('Ymd-His').'.pdf"');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Content-Length: '.strlen($pdf));
echo $pdf;
exit;
