<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$enabled = isset($payload['enabled_modules']) && is_array($payload['enabled_modules']) ? $payload['enabled_modules'] : array();
$result = dmd_agent_mydesk_settings_save($enabled, $email);
dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
