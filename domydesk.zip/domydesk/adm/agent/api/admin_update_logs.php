<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$action = strtolower(trim((string)($payload['action'] ?? 'list')));
$allowedUpdateSystemActions = array(
    'agent_bulk_update'=>true,
    'agent_update_result'=>true,
    'agent_update_packages_upload'=>true,
    'agent_update_packages_delete'=>true,
);

if ($action === 'purge') {
    $commandsRemoved = 0;
    $systemLogsRemoved = 0;
    $filesRewritten = 0;

    /* Retire uniquement les anciennes commandes d'update déjà terminées.
       Une mise à jour encore active / en attente n'est jamais supprimée. */
    foreach (dmd_agent_list_devices() as $device) {
        if (!is_array($device)) continue;
        $agentId = dmd_agent_safe_agent_id($device['agent_id'] ?? '');
        if ($agentId === '') continue;
        $removed = dmd_agent_command_with_lock($agentId, function (&$data) {
            dmd_agent_command_cleanup_data($data);
            $count = 0;
            foreach ((array)($data['commands'] ?? array()) as $id => $command) {
                if (!is_array($command) || strtolower((string)($command['type'] ?? '')) !== 'update_agent') continue;
                $status = strtolower(trim((string)($command['status'] ?? '')));
                if (!in_array($status, array('completed','failed','expired','cancelled','error'), true)) continue;
                unset($data['commands'][$id]);
                $count++;
            }
            return $count;
        });
        if (is_int($removed)) $commandsRemoved += $removed;
    }

    /* Retire uniquement les événements qui alimentent ce journal.
       Les autres audits système DoMyDesk sont conservés. */
    $root = DMD_SYSTEM_ROOT . '/data/sys_logs';
    if (is_dir($root)) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $fileInfo) {
            if (!$fileInfo->isFile() || strtolower($fileInfo->getExtension()) !== 'json') continue;
            $file = $fileInfo->getPathname();
            $fp = @fopen($file, 'c+');
            if (!$fp) continue;
            if (!@flock($fp, LOCK_EX)) { @fclose($fp); continue; }
            rewind($fp);
            $raw = stream_get_contents($fp);
            $items = array();
            if ($raw !== false && trim($raw) !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) $items = $decoded;
            }
            $next = array();
            $removedHere = 0;
            foreach ($items as $log) {
                if (is_array($log) && isset($allowedUpdateSystemActions[(string)($log['action'] ?? '')])) {
                    $removedHere++;
                    continue;
                }
                $next[] = $log;
            }
            if ($removedHere > 0) {
                $json = json_encode($next, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if ($json !== false) {
                    rewind($fp);
                    @ftruncate($fp, 0);
                    if (@fwrite($fp, $json) !== false) {
                        @fflush($fp);
                        $systemLogsRemoved += $removedHere;
                        $filesRewritten++;
                    }
                }
            }
            @flock($fp, LOCK_UN);
            @fclose($fp);
            @chmod($file, 0640);
        }
    }

    dmd_system_log('agent_update_logs_purge', 'journal_updates_agent', 'warning',
        'Journal des mises à jour Agent purgé par un administrateur.',
        array('commands_removed'=>$commandsRemoved,'system_logs_removed'=>$systemLogsRemoved,'files_rewritten'=>$filesRewritten));

    dmd_json_response(array(
        'ok'=>true,
        'commands_removed'=>$commandsRemoved,
        'system_logs_removed'=>$systemLogsRemoved,
        'files_rewritten'=>$filesRewritten,
    ));
}

if ($action !== 'list') dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);

$limit = max(20, min(1000, (int)($payload['limit'] ?? 500)));
$rows = array();
$seenCommands = array();
$devices = dmd_agent_list_devices();
$deviceMap = array();
foreach ($devices as $device) {
    if (!is_array($device)) continue;
    $aid = dmd_agent_safe_agent_id($device['agent_id'] ?? '');
    if ($aid === '') continue;
    $deviceMap[$aid] = $device;
}

function dmd_update_log_status($status) {
    $s = strtolower(trim((string)$status));
    if ($s === 'completed' || $s === 'success' || $s === 'succeeded' || $s === 'ok') return 'success';
    if (in_array($s, array('failed','error','expired','cancelled','failure'), true)) return 'error';
    return 'running';
}
function dmd_update_log_state_label($status) {
    $s = strtolower(trim((string)$status));
    $map = array(
        'queued'=>'En attente','delivered'=>'Transmise','downloading'=>'Téléchargement',
        'verified'=>'Vérifiée','installing'=>'Installation','waiting'=>'Attente',
        'completed'=>'Réussite','failed'=>'Échec','error'=>'Échec','expired'=>'Expirée',
        'cancelled'=>'Annulée','success'=>'Réussite','warning'=>'Demandée','running'=>'En cours'
    );
    return $map[$s] ?? ($status !== '' ? (string)$status : '—');
}
function dmd_update_log_cause($command) {
    $error = trim((string)($command['error'] ?? ''));
    if ($error !== '') return $error;
    $message = trim((string)($command['message'] ?? ''));
    if ($message !== '') return $message;
    $result = isset($command['result']) && is_array($command['result']) ? $command['result'] : array();
    foreach (array('error','error_message','message','detail','reason') as $k) {
        $v = trim((string)($result[$k] ?? ''));
        if ($v !== '') return $v;
    }
    return '';
}
function dmd_update_log_actor_name($actor) {
    $actor = dmd_sys_safe_email((string)$actor);
    if ($actor === '') return '';
    $p = dmd_sys_profile($actor);
    if (!is_array($p)) return '';
    $name = trim((string)($p['prenom'] ?? '') . ' ' . (string)($p['nom'] ?? ''));
    return $name;
}
function dmd_update_log_host($device, $agentId) {
    $host = trim((string)($device['hostname'] ?? ''));
    return $host !== '' ? $host : $agentId;
}

/* Résultats réels conservés dans l'historique des commandes Agent. */
foreach ($deviceMap as $agentId => $device) {
    foreach (dmd_agent_command_history($agentId, 100) as $command) {
        if (!is_array($command) || strtolower((string)($command['type'] ?? '')) !== 'update_agent') continue;
        $commandId = (string)($command['command_id'] ?? '');
        if ($commandId !== '') $seenCommands[$commandId] = true;
        $p = isset($command['payload']) && is_array($command['payload']) ? $command['payload'] : array();
        $stage = strtolower(trim((string)($p['stage'] ?? 'package')));
        $status = strtolower(trim((string)($command['status'] ?? 'queued')));
        $normalized = dmd_update_log_status($status);
        $cause = dmd_update_log_cause($command);
        if ($normalized === 'success' && $cause === '') $cause = 'Mise à jour terminée avec succès.';
        if ($normalized === 'error' && $cause === '') $cause = 'Échec sans détail retourné par l’Agent.';
        $actor = trim((string)($command['created_by'] ?? ''));
        $ts = (int)($command['completed_ts'] ?? 0);
        if ($ts <= 0) $ts = (int)($command['updated_ts'] ?? 0);
        if ($ts <= 0) $ts = (int)($command['created_ts'] ?? 0);
        $rows[] = array(
            'id'=>'cmd:'.$commandId,
            'source'=>'agent_command',
            'timestamp'=>$ts,
            'date_iso'=>$ts > 0 ? date('c',$ts) : '',
            'created_ts'=>(int)($command['created_ts'] ?? 0),
            'completed_ts'=>(int)($command['completed_ts'] ?? 0),
            'actor'=>$actor,
            'actor_name'=>dmd_update_log_actor_name($actor),
            'agent_id'=>$agentId,
            'hostname'=>dmd_update_log_host($device,$agentId),
            'build'=>(string)($p['version'] ?? ''),
            'stage'=>$stage,
            'action'=>$stage === 'bootstrap' ? 'Bootstrap DMD-Agent' : 'Mise à jour Agent',
            'status'=>$normalized,
            'state'=>dmd_update_log_state_label($status),
            'cause'=>$cause,
            'command_id'=>$commandId,
            'details'=>array(
                'force'=>!empty($p['force']),
                'reboot_mode'=>(string)($p['reboot_mode'] ?? 'none'),
                'result'=>isset($command['result']) ? $command['result'] : null,
            ),
        );
    }
}

/* Audit serveur : demandes, imports/suppressions et résultats devenus persistants. */
$root = DMD_SYSTEM_ROOT . '/data/sys_logs';
$files = array();
if (is_dir($root)) {
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'json') $files[] = $file->getPathname();
    }
}
rsort($files, SORT_STRING);
$allowed = $allowedUpdateSystemActions;
$scanned = 0;
foreach ($files as $file) {
    if ($scanned >= 180 || count($rows) >= $limit * 3) break;
    $scanned++;
    $items = dmd_sys_json_read($file, array());
    if (!is_array($items)) continue;
    foreach ($items as $log) {
        if (!is_array($log)) continue;
        $actionName = (string)($log['action'] ?? '');
        if (!isset($allowed[$actionName])) continue;
        $extra = isset($log['extra']) && is_array($log['extra']) ? $log['extra'] : array();
        $commandId = trim((string)($extra['command_id'] ?? ''));
        if ($actionName === 'agent_update_result' && $commandId !== '' && isset($seenCommands[$commandId])) continue;
        $actor = trim((string)($log['user'] ?? ''));
        if ($actor === '') $actor = trim((string)($extra['actor'] ?? ''));
        $statusRaw = strtolower(trim((string)($log['status'] ?? 'info')));
        $status = $statusRaw === 'success' ? 'success' : ($statusRaw === 'error' || $statusRaw === 'failed' ? 'error' : 'running');
        $rowAction = $actionName;
        $target = trim((string)($log['target'] ?? ''));
        $hostname = '';
        $build = trim((string)($extra['version'] ?? ''));
        $cause = trim((string)($log['details'] ?? ''));
        $state = dmd_update_log_state_label($statusRaw);
        if ($actionName === 'agent_bulk_update') {
            $rowAction = 'Demande de mise à jour';
            $agents = isset($extra['agents']) && is_array($extra['agents']) ? $extra['agents'] : array();
            $names = array();
            foreach ($agents as $aid) {
                $aid = dmd_agent_safe_agent_id($aid);
                if ($aid === '') continue;
                $names[] = isset($deviceMap[$aid]) ? dmd_update_log_host($deviceMap[$aid],$aid) : $aid;
            }
            $hostname = count($names) <= 4 ? implode(', ',$names) : (count($names).' PC');
            $state = 'Demandée';
            $status = 'running';
            $cause = 'Déploiement demandé depuis DoMyDesk.';
        } elseif ($actionName === 'agent_update_packages_upload') {
            $rowAction = 'Import ZIP de mise à jour';
            $versions = isset($extra['versions']) && is_array($extra['versions']) ? $extra['versions'] : array();
            if ($build === '' && $versions) $build = implode(', ',array_map('strval',$versions));
            $hostname = 'Dépôt /updates/';
            $state = $status === 'error' ? 'Échec' : 'Réussite';
            $status = $status === 'error' ? 'error' : 'success';
            if ($cause === '') $cause = $status === 'success' ? 'Archive importée dans le dépôt.' : 'Import impossible.';
        } elseif ($actionName === 'agent_update_packages_delete') {
            $rowAction = 'Suppression de mise à jour';
            $hostname = 'Dépôt /updates/';
            $state = $status === 'error' ? 'Échec' : 'Réussite';
            $status = $status === 'error' ? 'error' : 'success';
            if ($cause === '') $cause = $status === 'success' ? 'Fichiers supprimés du dépôt.' : 'Suppression impossible.';
        } elseif ($actionName === 'agent_update_result') {
            $rowAction = (string)($extra['stage'] ?? '') === 'bootstrap' ? 'Bootstrap DMD-Agent' : 'Mise à jour Agent';
            $aid = dmd_agent_safe_agent_id((string)($extra['agent_id'] ?? $target));
            if ($aid !== '') {
                $target = $aid;
                $hostname = isset($deviceMap[$aid]) ? dmd_update_log_host($deviceMap[$aid],$aid) : $aid;
            }
            $state = $status === 'success' ? 'Réussite' : 'Échec';
            if ($cause === '') $cause = trim((string)($extra['cause'] ?? ''));
        }
        $ts = (int)($log['timestamp'] ?? 0);
        $rows[] = array(
            'id'=>'sys:'.(string)($log['id'] ?? md5($file.json_encode($log))),
            'source'=>'system_log',
            'timestamp'=>$ts,
            'date_iso'=>(string)($log['date_iso'] ?? ($ts > 0 ? date('c',$ts) : '')),
            'created_ts'=>$ts,
            'completed_ts'=>$ts,
            'actor'=>$actor,
            'actor_name'=>trim((string)($log['user_name'] ?? '')) ?: dmd_update_log_actor_name($actor),
            'agent_id'=>$target,
            'hostname'=>$hostname !== '' ? $hostname : $target,
            'build'=>$build,
            'stage'=>(string)($extra['stage'] ?? ''),
            'action'=>$rowAction,
            'status'=>$status,
            'state'=>$state,
            'cause'=>$cause,
            'command_id'=>$commandId,
            'details'=>$extra,
        );
    }
}

usort($rows, function($a,$b){ return (int)($b['timestamp'] ?? 0) <=> (int)($a['timestamp'] ?? 0); });
if (count($rows) > $limit) $rows = array_slice($rows,0,$limit);

dmd_json_response(array('ok'=>true,'rows'=>$rows,'count'=>count($rows),'generated_at'=>date('c')));
