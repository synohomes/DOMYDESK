<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
$binDir = dirname(__DIR__) . '/bin/windows-x64';
$installer = $binDir . '/DMD-Installer.exe';
if (!is_file($installer)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Installateur introuvable : DMD-Installer.exe';
    exit;
}
$raw = @file_get_contents($installer);
if ($raw === false || substr($raw, 0, 2) !== 'MZ') {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'DMD-Installer.exe est invalide.';
    exit;
}
if (strpos($raw, 'DMD-INSTALLER-AUTONOME-H264-WS') === false) {
    http_response_code(409);
    header('Content-Type: text/plain; charset=utf-8');
    echo "DMD-Installer.exe n'est pas autonome AUTONOME-H264-WS.";
    exit;
}
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="DMD-Installer.exe"');
header('Content-Length: ' . strlen($raw));
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-DMD-Installer: autonomous');
echo $raw;
exit;
