<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array()); dmd_api_require_csrf('agent_admin', $payload);
$id = isset($payload['enrollment_id']) ? $payload['enrollment_id'] : '';
$decision = isset($payload['decision']) ? $payload['decision'] : '';
$result = dmd_agent_admin_decision($id, $decision, $email);
if (!empty($result['ok'])) dmd_system_log('agent_enrollment_' . $decision, $id, $decision==='approve'?'success':'warning', 'Décision sur un enrôlement DMD-Agent.');
dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
