<?php
require_once __DIR__ . '/_public.php';
dmd_agent_public_send(dmd_agent_enroll_finish(dmd_agent_public_body(), dmd_agent_remote_ip()));
