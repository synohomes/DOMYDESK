<?php
require_once __DIR__ . '/_public.php';
require_once dirname(__DIR__) . '/includes/remote_ws.php';
$payload = dmd_agent_public_body();
$validated = dmd_agent_signed_request_validate($payload, 'POST', '/adm/agent/api/remote_ticket.php', dmd_agent_remote_ip());
if (empty($validated['ok'])) dmd_agent_public_send($validated);
$device = $validated['device'];
$caps = isset($device['capabilities']) && is_array($device['capabilities']) ? $device['capabilities'] : array();
if (!in_array('remote.screen', $caps, true)) dmd_agent_public_send(array('ok'=>false,'_http'=>403,'code'=>'remote_not_authorized'));
$permissions = array('video','control','screen');
if (in_array('remote.control',$caps,true)) $permissions[]='input';
if (in_array('remote.clipboard',$caps,true)) $permissions[]='clipboard';
$issued = dmd_remote_ws_issue_ticket('agent', $validated['agent_id'], $permissions, 180);
if (empty($issued['ok'])) dmd_agent_public_send(array('ok'=>false,'_http'=>503,'code'=>(string)($issued['error']??'remote_ws_unavailable'),'details'=>$issued));
$body = array('ticket'=>$issued['ticket'],'remote_url'=>$issued['remote_url'],'expires_at'=>$issued['expires_at'],'permissions'=>$issued['permissions']);
dmd_agent_public_send(dmd_agent_signed_response($validated['agent_id'],$validated['nonce'],$body));
