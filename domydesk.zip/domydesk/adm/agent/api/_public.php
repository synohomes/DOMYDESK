<?php
require_once dirname(__DIR__) . '/includes/agent_core.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
$contentLength = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
$scriptName = strtolower((string)(isset($_SERVER['SCRIPT_NAME']) ? basename($_SERVER['SCRIPT_NAME']) : ''));
$maxPublicBody = $scriptName === 'agent_remote.php' ? 10485760 : (in_array($scriptName, array('agent_commands.php','agent_heartbeat.php'), true) ? 1048576 : 65536);
if ($contentLength > $maxPublicBody) { http_response_code(413); echo json_encode(array('ok'=>false,'code'=>'payload_too_large')); exit; }
function dmd_agent_public_body() {
    $raw = (string)file_get_contents('php://input');
    $body = json_decode($raw, true);
    return is_array($body) ? $body : array();
}
function dmd_agent_public_send($result) {
    $status = isset($result['_http']) ? (int)$result['_http'] : (empty($result['ok']) ? 400 : 200);
    unset($result['_http']); http_response_code($status);
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
if (strtoupper(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET') !== 'POST') {
    dmd_agent_public_send(array('ok' => false, '_http' => 405, 'code' => 'method_not_allowed'));
}
