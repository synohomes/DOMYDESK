<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/software_packages.php';
require_once dirname(__DIR__) . '/includes/maintenance_software_library.php';
dmd_api_require_method('POST');

$isMultipart = isset($_SERVER['CONTENT_TYPE']) && stripos((string)$_SERVER['CONTENT_TYPE'],'multipart/form-data')!==false;
$payload = $isMultipart ? $_POST : dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$action = strtolower(trim((string)($payload['action']??'')));

if($action==='list'){
    $d=dmd_agent_maint_software_read();
    dmd_json_response(array('ok'=>true,'items'=>array_values($d['items'])));
}
if($action==='add_file'){
    if(empty($_FILES['package']))dmd_json_response(array('ok'=>false,'error'=>'package_missing'),400);
    $r=dmd_agent_maint_software_add_file($_FILES['package'],$payload['name']??'',$payload['arguments']??'',$email);
    if(empty($r['ok']))dmd_json_response($r,400);
    dmd_system_log('agent_software_library_add',$r['item']['id'],'warning','Logiciel ajouté à la bibliothèque DMD-Agent.',array('name'=>$r['item']['name'],'source'=>'file'));
    dmd_json_response($r);
}
if($action==='add_winget'){
    $r=dmd_agent_maint_software_add_winget($payload['name']??'',$payload['winget_id']??'',$email);
    if(empty($r['ok']))dmd_json_response($r,400);
    dmd_system_log('agent_software_library_add',$r['item']['id'],'warning','Entrée Winget ajoutée à la bibliothèque DMD-Agent.',array('name'=>$r['item']['name'],'winget_id'=>$r['item']['winget_id']));
    dmd_json_response($r);
}
if($action==='delete'){
    $r=dmd_agent_maint_software_delete($payload['id']??'');
    if(empty($r['ok']))dmd_json_response($r,400);
    dmd_system_log('agent_software_library_delete',(string)($payload['id']??''),'warning','Entrée supprimée de la bibliothèque DMD-Agent.',array());
    dmd_json_response($r);
}

if($action==='deploy_install' || $action==='deploy_winget_uninstall'){
    $agentIds=array_values(array_unique(array_filter(array_map('strval',(array)($payload['agent_ids']??array())))));
    if(!$agentIds)dmd_json_response(array('ok'=>false,'error'=>'agent_ids_missing'),400);
    $items=array();
    if($action==='deploy_install'){
        foreach((array)($payload['item_ids']??array()) as $id){$row=dmd_agent_maint_software_item($id);if($row)$items[]=$row;}
    } else {
        $row=dmd_agent_maint_software_item($payload['item_id']??'');if($row)$items[]=$row;
    }
    if(!$items)dmd_json_response(array('ok'=>false,'error'=>'items_missing'),400);

    $commands=array();
    foreach($agentIds as $rawAgentId){
        $agentId=dmd_agent_safe_agent_id($rawAgentId);
        if($agentId===''){ $commands[]=array('agent_id'=>$rawAgentId,'status'=>'error','error'=>'agent_invalid'); continue; }
        foreach($items as $item){
            if(($item['source']??'')==='file'){
                if($action!=='deploy_install'){ $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'status'=>'error','error'=>'file_uninstall_resolved_client_side'); continue; }
                $pkg=dmd_agent_maint_software_transient_package($item,$email);
                if(empty($pkg['ok'])){ $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'status'=>'error','error'=>$pkg['error']??'package_failed'); continue; }
                $deviceFile=dmd_agent_device_file($agentId);
                $device=($deviceFile!==''&&is_file($deviceFile))?dmd_agent_json_read($deviceFile,array()):array();
                if(!$device||($device['status']??'')!=='active'){ $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'status'=>'error','error'=>'agent_not_active'); continue; }
                $enrollment=!empty($device['enrollment_id'])?dmd_agent_load_enrollment($device['enrollment_id']):array();
                $serverUrl=rtrim((string)($enrollment['server_url']??''),'/');
                if($serverUrl===''){ $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'status'=>'error','error'=>'server_url_missing'); continue; }
                $p=$pkg['package'];$token=$pkg['token'];
                $url=$serverUrl.'/adm/agent/api/agent_software_package.php?package_id='.rawurlencode($p['package_id']).'&token='.rawurlencode($token);
                $q=dmd_agent_queue_command($agentId,'software.install',array(
                    'url'=>$url,'sha256'=>(string)$p['sha256'],'filename'=>(string)$p['file_name'],
                    'arguments'=>(string)($item['arguments']??''),'timeout_seconds'=>1200
                ),$email,'software.uninstall',1800);
                $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'item_name'=>$item['name'],'status'=>!empty($q['ok'])?'queued':'error','command_id'=>$q['command']['command_id']??'','error'=>$q['error']??'');
            } else {
                $wingetId=trim((string)($item['winget_id']??''));
                if(!preg_match('/^[A-Za-z0-9._+:-]{1,220}$/',$wingetId)){ $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'status'=>'error','error'=>'winget_id_invalid'); continue; }
                $wingetCommand=$action==='deploy_winget_uninstall'?'software.winget.uninstall':'software.winget.install';
                $q=dmd_agent_queue_command($agentId,$wingetCommand,array('id'=>$wingetId),$email,'software.update',1800);
                $commands[]=array('agent_id'=>$agentId,'item_id'=>$item['id'],'item_name'=>$item['name'],'status'=>!empty($q['ok'])?'queued':'error','command_id'=>$q['command']['command_id']??'','error'=>$q['error']??'');
            }
        }
    }
    dmd_system_log($action==='deploy_install'?'agent_software_bulk_install':'agent_software_bulk_uninstall','maintenance','warning','Déploiement logiciel de masse depuis Maintenance.',array('agents'=>$agentIds,'items'=>array_map(function($x){return $x['id'];},$items)));
    dmd_json_response(array('ok'=>true,'commands'=>$commands));
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'),400);
