<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload=dmd_json_body(array());
dmd_api_require_csrf('agent_admin',$payload);
$action=isset($payload['action'])?(string)$payload['action']:'';
if($action!=='save_remote_notice') dmd_json_response(array('ok'=>false,'error'=>'action_invalid'),400);
$result=dmd_agent_remote_notice_settings_write(array(
    'enabled'=>!empty($payload['enabled']),
    'show_on_view'=>!empty($payload['show_on_view']),
    'show_operator'=>!empty($payload['show_operator']),
),$email);
if(!empty($result['ok'])) dmd_system_log('agent_remote_notice_settings','save','success','Paramètres d’avertissement Remote enregistrés.',array('actor'=>$email,'settings'=>$result['settings']));
dmd_json_response($result,!empty($result['ok'])?200:400);
