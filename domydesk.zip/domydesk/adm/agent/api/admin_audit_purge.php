<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';

dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$action = isset($payload['action']) ? (string)$payload['action'] : '';
if ($action !== 'purge_all') {
    dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
}

$auditDir = DMD_AGENT_VAR . '/audits';
$files = glob($auditDir . '/AUD-*.php') ?: array();

$deleted = 0;
$failed = array();

foreach ($files as $file) {
    $name = basename($file);

    // Garde-fous : uniquement les archives AUD-*.php dans le dossier audits.
    if (!preg_match('/^AUD-[A-Za-z0-9_-]+\.php$/D', $name)) {
        $failed[] = $name;
        continue;
    }

    $realDir = realpath($auditDir);
    $realFile = realpath($file);
    if ($realDir === false || $realFile === false || strpos($realFile, $realDir . DIRECTORY_SEPARATOR) !== 0) {
        $failed[] = $name;
        continue;
    }

    if (@unlink($realFile)) {
        $deleted++;
    } else {
        $failed[] = $name;
    }
}

if (function_exists('dmd_system_log')) {
    dmd_system_log(
        'agent_audits_purged',
        'audits',
        empty($failed) ? 'warning' : 'error',
        'Purge des archives DMD-Agent.',
        array(
            'deleted' => $deleted,
            'failed' => $failed,
            'actor' => $email
        )
    );
}

dmd_json_response(array(
    'ok' => empty($failed),
    'deleted' => $deleted,
    'failed' => $failed
), empty($failed) ? 200 : 500);
