<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$mode = isset($payload['mode']) ? trim((string)$payload['mode']) : '';

function dmd_admin_delete_enrollment_record($id) {
    $id = dmd_agent_safe_enrollment_id($id);
    if ($id === '') return array('ok'=>false,'error'=>'invalid_enrollment_id');
    $file = dmd_agent_enrollment_file($id);
    if ($file === '' || !is_file($file)) return array('ok'=>false,'error'=>'not_found');
    $e = dmd_agent_load_enrollment($id);
    if (!$e) return array('ok'=>false,'error'=>'invalid_enrollment');
    if (!@unlink($file)) return array('ok'=>false,'error'=>'delete_failed');
    return array('ok'=>true,'id'=>$id,'enrollment'=>$e);
}

if ($mode === 'delete_one') {
    $id = isset($payload['enrollment_id']) ? (string)$payload['enrollment_id'] : '';
    $res = dmd_admin_delete_enrollment_record($id);
    if (empty($res['ok'])) dmd_json_response($res, $res['error']==='not_found' ? 404 : 400);

    $e = $res['enrollment'];
    dmd_system_log(
        'agent_enrollment_deleted',
        $res['id'],
        'warning',
        'Suppression manuelle d’un enrôlement DMD-Agent de l’historique.',
        array(
            'status'=>(string)($e['status']??''),
            'target_name'=>(string)($e['target_name']??''),
            'actor'=>$email,
            'active_device_untouched'=>true,
        )
    );
    dmd_json_response(array('ok'=>true,'deleted'=>1,'enrollment_ids'=>array($res['id'])), 200);
}

if ($mode === 'delete_all') {
    $deleted = array();
    $failed = array();
    foreach (dmd_agent_list_enrollments() as $e) {
        $id = isset($e['enrollment_id']) ? (string)$e['enrollment_id'] : '';
        $res = dmd_admin_delete_enrollment_record($id);
        if (!empty($res['ok'])) $deleted[] = $res['id'];
        else $failed[] = array('id'=>$id,'error'=>$res['error']??'delete_failed');
    }
    dmd_system_log(
        'agent_enrollments_deleted_all',
        'all',
        'warning',
        'Suppression manuelle de l’historique des enrôlements DMD-Agent.',
        array('deleted'=>count($deleted),'failed'=>$failed,'actor'=>$email,'active_devices_untouched'=>true)
    );
    dmd_json_response(array('ok'=>empty($failed),'deleted'=>count($deleted),'enrollment_ids'=>$deleted,'failed'=>$failed), empty($failed) ? 200 : 500);
}

if ($mode === 'renew') {
    $oldId = dmd_agent_safe_enrollment_id(isset($payload['enrollment_id']) ? $payload['enrollment_id'] : '');
    if ($oldId === '') dmd_json_response(array('ok'=>false,'error'=>'invalid_enrollment_id'), 400);
    $old = dmd_agent_load_enrollment($oldId);
    if (!$old) dmd_json_response(array('ok'=>false,'error'=>'not_found'), 404);

    // Reprend la durée initialement choisie, avec les mêmes bornes que la création standard.
    $createdTs = isset($old['created_ts']) ? (int)$old['created_ts'] : 0;
    $expiresTs = isset($old['expires_ts']) ? (int)$old['expires_ts'] : 0;
    $minutes = ($createdTs > 0 && $expiresTs > $createdTs) ? (int)round(($expiresTs - $createdTs) / 60) : 1440;
    if ($minutes < 5) $minutes = 5;
    if ($minutes > 10080) $minutes = 10080;

    $serverUrls = isset($old['server_endpoints']) && is_array($old['server_endpoints']) && $old['server_endpoints']
        ? $old['server_endpoints']
        : array(trim((string)($old['server_url'] ?? '')));
    if (!$serverUrls && isset($payload['server_urls']) && is_array($payload['server_urls'])) $serverUrls = $payload['server_urls'];
    $targetName = trim((string)($old['target_name'] ?? 'PC'));
    $approvalMode = (($old['approval_mode'] ?? 'manual') === 'auto') ? 'auto' : 'manual';
    $caps = isset($old['capabilities']) && is_array($old['capabilities']) ? $old['capabilities'] : dmd_agent_default_capabilities();

    $new = dmd_agent_create_enrollment($email, $targetName, $minutes, $approvalMode, $caps, $serverUrls, !empty($old['include_mydesk']));
    if (empty($new['ok'])) dmd_json_response(array('ok'=>false,'error'=>$new['error']??'renew_create_failed'), 400);

    $newId = (string)($new['enrollment']['enrollment_id'] ?? '');
    $oldFile = dmd_agent_enrollment_file($oldId);
    if ($oldFile === '' || !is_file($oldFile) || !@unlink($oldFile)) {
        // Fail closed: si l’ancienne invitation ne peut pas être invalidée, on retire aussi la nouvelle.
        $newFile = dmd_agent_enrollment_file($newId);
        if ($newFile !== '' && is_file($newFile)) @unlink($newFile);
        dmd_json_response(array('ok'=>false,'error'=>'old_invitation_invalidation_failed'), 500);
    }

    dmd_system_log(
        'agent_enrollment_renewed',
        $newId,
        'success',
        'Relance d’une invitation d’enrôlement DMD-Agent.',
        array(
            'old_enrollment_id'=>$oldId,
            'new_enrollment_id'=>$newId,
            'target_name'=>$targetName,
            'expires_minutes'=>$minutes,
            'old_status'=>(string)($old['status']??''),
            'actor'=>$email,
        )
    );

    dmd_json_response(array(
        'ok'=>true,
        'replaced_enrollment_id'=>$oldId,
        'enrollment'=>$new['enrollment'],
        'bootstrap'=>$new['bootstrap'],
        'expires_minutes'=>$minutes,
    ), 200);
}

dmd_json_response(array('ok'=>false,'error'=>'invalid_mode'), 400);
