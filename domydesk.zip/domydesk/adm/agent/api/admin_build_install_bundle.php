<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

function dmd_inst_fail($status, $message) {
    http_response_code((int)$status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo (string)$message;
    exit;
}

$bootstrap = isset($payload['bootstrap']) && is_array($payload['bootstrap']) ? $payload['bootstrap'] : array();
if (!$bootstrap) dmd_inst_fail(400, 'Bootstrap absent.');

$identity = dmd_agent_verify_instance_identity();
if (empty($identity['ok'])) dmd_inst_fail(503, 'Identité DMD-Agent invalide.');

$enrollmentId = dmd_agent_safe_enrollment_id(isset($bootstrap['enrollment_id']) ? $bootstrap['enrollment_id'] : '');
$instanceId = trim((string)(isset($bootstrap['instance_id']) ? $bootstrap['instance_id'] : ''));
$token = (string)(isset($bootstrap['enrollment_token']) ? $bootstrap['enrollment_token'] : '');
$enrollment = $enrollmentId !== '' ? dmd_agent_load_enrollment($enrollmentId) : array();

if (!$enrollment || $token === '' || !hash_equals((string)$identity['manifest']['instance_id'], $instanceId) || !dmd_agent_verify_token($enrollment, $token)) {
    dmd_inst_fail(403, 'Bootstrap non reconnu ou token invalide.');
}
if (dmd_agent_enrollment_expired($enrollment)) dmd_inst_fail(410, 'Cet enrôlement a expiré.');

$caps = isset($enrollment['capabilities']) && is_array($enrollment['capabilities']) ? array_values($enrollment['capabilities']) : array();
$derived = function_exists('dmd_agent_install_components_from_capabilities')
    ? dmd_agent_install_components_from_capabilities($caps)
    : array('agent'=>true,'remote'=>dmd_agent_caps_use_remote($caps),'mydesk'=>in_array('mydesk.client',$caps,true));
$components = isset($enrollment['install_components']) && is_array($enrollment['install_components'])
    ? array('agent'=>true,'remote'=>!empty($enrollment['install_components']['remote']),'mydesk'=>!empty($enrollment['install_components']['mydesk']))
    : $derived;

if ((bool)$components['remote'] !== (bool)$derived['remote'] || (bool)$components['mydesk'] !== (bool)$derived['mydesk']) {
    dmd_inst_fail(409, 'Enrôlement incohérent : composants et capabilities ne correspondent pas.');
}
$installerPath = dirname(__DIR__) . '/bin/windows-x64/DMD-Installer.exe';
if (!is_file($installerPath)) dmd_inst_fail(404, 'Installateur introuvable : adm/agent/bin/windows-x64/DMD-Installer.exe');
if (!is_readable($installerPath)) dmd_inst_fail(500, 'DMD-Installer.exe existe mais PHP ne peut pas le lire. Vérifie les permissions du fichier.');

$installerSize = @filesize($installerPath);
if ($installerSize === false || $installerSize < 1024) dmd_inst_fail(500, 'DMD-Installer.exe est vide ou sa taille est invalide.');

$fh = @fopen($installerPath, 'rb');
if (!$fh) dmd_inst_fail(500, 'DMD-Installer.exe est inaccessible à PHP.');
$magic = fread($fh, 2);
fclose($fh);
if ($magic !== 'MZ') dmd_inst_fail(500, 'DMD-Installer.exe est invalide : signature Windows MZ absente.');

/* Vérifie le build attendu par blocs, sans charger l'EXE entier en mémoire. */
$marker = 'DMD-INSTALLER-AUTONOME-H264-WS';
$markerFound = false;
$scan = @fopen($installerPath, 'rb');
$carry = '';
if ($scan) {
    while (!feof($scan)) {
        $chunk = fread($scan, 1048576);
        if ($chunk === false) break;
        $hay = $carry . $chunk;
        if (strpos($hay, $marker) !== false) { $markerFound = true; break; }
        $carry = substr($hay, -strlen($marker));
    }
    fclose($scan);
}
if (!$markerFound) dmd_inst_fail(409, "DMD-Installer.exe n'est pas le build autonome attendu. Recompile avec BUILD-DMD-INSTALLER.ps1 puis recopie-le dans adm/agent/bin/windows-x64/.");

$canonical = array(
    'schema'=>1,
    'protocol_version'=>isset($enrollment['protocol_version']) ? (int)$enrollment['protocol_version'] : DMD_AGENT_PROTOCOL,
    'instance_id'=>(string)$identity['manifest']['instance_id'],
    'server_url'=>rtrim((string)(isset($enrollment['server_url']) ? $enrollment['server_url'] : ''), '/'),
    'transport_policy'=>(string)(isset($enrollment['transport_policy']) ? $enrollment['transport_policy'] : ''),
    'server_endpoints'=>isset($enrollment['server_endpoints']) && is_array($enrollment['server_endpoints']) ? array_values($enrollment['server_endpoints']) : array(),
    'instance_public_key'=>(string)$identity['public_key'],
    'instance_public_key_fingerprint'=>(string)$identity['manifest']['public_key_fingerprint'],
    'enrollment_id'=>$enrollmentId,
    'enrollment_token'=>$token,
    'expires_at'=>(string)(isset($enrollment['expires_at']) ? $enrollment['expires_at'] : ''),
    'requested_capabilities'=>$caps,
    'install_components'=>$components,
    'bootstrap_signature_format'=>'DMD-BOOTSTRAP-V1',
);
$canonical['bootstrap_signature'] = dmd_agent_sign_message(dmd_agent_bootstrap_message($canonical));
if ($canonical['bootstrap_signature'] === false) dmd_inst_fail(500, 'Signature du bootstrap impossible.');

$bootstrapRaw = json_encode($canonical, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
if ($bootstrapRaw === false) dmd_inst_fail(500, 'Bootstrap JSON invalide.');
$bootstrapRaw .= "\r\n";

/*
 * ZIP "store" streamé directement vers le navigateur.
 * Aucun tempnam(), aucun ZipArchive et aucun chargement du gros EXE en RAM.
 * C'est volontaire pour fonctionner sur les NAS où /tmp peut être non inscriptible
 * ou où memory_limit est faible.
 */
function dmd_inst_zip_time($ts) {
    $p = getdate($ts);
    $year = max(1980, min(2107, (int)$p['year']));
    return array(
        ((int)$p['hours'] << 11) | ((int)$p['minutes'] << 5) | ((int)$p['seconds'] >> 1),
        (($year - 1980) << 9) | ((int)$p['mon'] << 5) | (int)$p['mday']
    );
}
function dmd_inst_crc_file_u32($path) {
    $hex = @hash_file('crc32b', $path);
    if ($hex === false || strlen($hex) !== 8) return false;
    return (int)hexdec($hex);
}
function dmd_inst_crc_string_u32($data) {
    $hex = hash('crc32b', $data);
    return (int)hexdec($hex);
}
function dmd_inst_local_header($name, $crc, $size, $dosTime, $dosDate) {
    return pack('VvvvvvVVVvv', 0x04034b50, 20, 0, 0, $dosTime, $dosDate, $crc, $size, $size, strlen($name), 0) . $name;
}
function dmd_inst_central_header($name, $crc, $size, $offset, $dosTime, $dosDate) {
    return pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0, 0, $dosTime, $dosDate, $crc, $size, $size, strlen($name), 0, 0, 0, 0, 0, $offset) . $name;
}
function dmd_inst_echo_file($path) {
    $in = @fopen($path, 'rb');
    if (!$in) return false;
    while (!feof($in)) {
        $chunk = fread($in, 1048576);
        if ($chunk === false) { fclose($in); return false; }
        if ($chunk !== '') echo $chunk;
    }
    fclose($in);
    return true;
}

list($dosTime, $dosDate) = dmd_inst_zip_time(time());
$nameExe = 'DMD-Installer.exe';
$nameJson = 'bootstrap.json';
$sizeExe = (int)$installerSize;
$sizeJson = strlen($bootstrapRaw);
$crcExe = dmd_inst_crc_file_u32($installerPath);
if ($crcExe === false) dmd_inst_fail(500, 'Impossible de calculer le CRC de DMD-Installer.exe.');
$crcJson = dmd_inst_crc_string_u32($bootstrapRaw);

$localExe = dmd_inst_local_header($nameExe, $crcExe, $sizeExe, $dosTime, $dosDate);
$offsetExe = 0;
$offsetJson = strlen($localExe) + $sizeExe;
$localJson = dmd_inst_local_header($nameJson, $crcJson, $sizeJson, $dosTime, $dosDate);
$centralOffset = $offsetJson + strlen($localJson) + $sizeJson;
$central = dmd_inst_central_header($nameExe, $crcExe, $sizeExe, $offsetExe, $dosTime, $dosDate)
         . dmd_inst_central_header($nameJson, $crcJson, $sizeJson, $offsetJson, $dosTime, $dosDate);
$eocd = pack('VvvvvVVv', 0x06054b50, 0, 0, 2, 2, strlen($central), $centralOffset, 0);
$totalSize = $centralOffset + strlen($central) + strlen($eocd);

$safeTarget = preg_replace('/[^A-Za-z0-9._-]+/', '-', (string)(isset($enrollment['target_name']) ? $enrollment['target_name'] : 'PC'));
$safeTarget = trim((string)$safeTarget, '-');
if ($safeTarget === '') $safeTarget = 'PC';
$filename = 'DMD-Installer-' . $safeTarget . '-' . $enrollmentId . '.zip';

/* Évite qu'un buffer HTML / compression corrompe le ZIP binaire. */
@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
while (ob_get_level() > 0) { @ob_end_clean(); }

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . $totalSize);
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Content-Encoding: identity');
header('X-DMD-Agent-Version: 1.4.0');
header('X-DMD-Installer: autonomous-enrollment-stream');

echo $localExe;
if (!dmd_inst_echo_file($installerPath)) exit;
echo $localJson;
echo $bootstrapRaw;
echo $central;
echo $eocd;
exit;
