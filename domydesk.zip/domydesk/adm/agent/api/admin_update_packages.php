<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');

$contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
$isMultipart = strpos($contentType, 'multipart/form-data') !== false;
$payload = $isMultipart ? $_POST : dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);
$action = strtolower(trim((string)($payload['action'] ?? 'list')));

function dmd_update_mgr_dir() {
    $dir = dirname(dirname(dirname(__DIR__))) . '/updates';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}
function dmd_update_mgr_name_ok($name) {
    return preg_match('/^(?:update|DMD-Agent)\.[0-9A-Za-z][0-9A-Za-z._-]{0,31}\.exe$/i', (string)$name) === 1;
}
function dmd_update_mgr_version($name) {
    return preg_match('/^(?:update|DMD-Agent)\.([0-9A-Za-z][0-9A-Za-z._-]{0,31})\.exe$/i', (string)$name, $m) ? (string)$m[1] : '';
}
function dmd_update_mgr_kind($name) {
    return stripos((string)$name, 'DMD-Agent.') === 0 ? 'bootstrap' : 'package';
}
function dmd_update_mgr_version_parts($version) {
    return preg_match('/^(\d+)\.(\d+)\.(\d+)(?:[-_].*)?$/', trim((string)$version), $m) ? array((int)$m[1],(int)$m[2],(int)$m[3]) : null;
}
function dmd_update_mgr_version_compare($a,$b) {
    $av=dmd_update_mgr_version_parts($a); $bv=dmd_update_mgr_version_parts($b);
    if($av&&$bv){
        $aLegacy=$av[0]===29&&$av[1]===9; $bLegacy=$bv[0]===29&&$bv[1]===9;
        $aCanonical=$av[0]===26; $bCanonical=$bv[0]===26;
        if($aCanonical&&$bLegacy){ if($av[1]>9)return 1; if($av[1]<9)return -1; if($av[2]>$bv[2])return 1; if($av[2]<$bv[2])return -1; return -1; }
        if($aLegacy&&$bCanonical){ if($bv[1]>9)return -1; if($bv[1]<9)return 1; if($bv[2]>$av[2])return -1; if($bv[2]<$av[2])return 1; return 1; }
    }
    return version_compare((string)$a,(string)$b);
}
function dmd_update_mgr_is_pe($file) {
    if (!is_file($file) || !is_readable($file) || (int)@filesize($file) < 2) return false;
    $fh = @fopen($file, 'rb'); if (!$fh) return false;
    $magic = fread($fh, 2); fclose($fh);
    return $magic === 'MZ';
}
function dmd_update_mgr_rows() {
    $dir = dmd_update_mgr_dir();
    $rows = array();
    foreach ((array)@scandir($dir) as $name) {
        if ($name === '.' || $name === '..' || !dmd_update_mgr_name_ok($name)) continue;
        $file = $dir . DIRECTORY_SEPARATOR . $name;
        if (!is_file($file)) continue;
        $version = dmd_update_mgr_version($name);
        $kind = dmd_update_mgr_kind($name);
        $pairName = ($kind === 'package' ? 'DMD-Agent.' : 'update.') . $version . '.exe';
        $rows[] = array(
            'name'=>$name,
            'version'=>$version,
            'kind'=>$kind,
            'size'=>(int)@filesize($file),
            'modified_at'=>gmdate('c', (int)@filemtime($file)),
            'valid_pe'=>dmd_update_mgr_is_pe($file),
            'pair_present'=>is_file($dir . DIRECTORY_SEPARATOR . $pairName) && dmd_update_mgr_is_pe($dir . DIRECTORY_SEPARATOR . $pairName),
        );
    }
    usort($rows, function($a,$b){
        $vc = dmd_update_mgr_version_compare((string)$b['version'], (string)$a['version']);
        if ($vc !== 0) return $vc;
        return strcmp((string)$a['kind'], (string)$b['kind']);
    });
    return $rows;
}
function dmd_update_mgr_snapshot() {
    $rows = dmd_update_mgr_rows();
    $pairs = array(); $bytes = 0;
    foreach ($rows as $r) {
        $bytes += (int)$r['size'];
        $v=(string)$r['version'];
        if(!isset($pairs[$v])) $pairs[$v]=array(
            'version'=>$v,'complete'=>false,'total_size'=>0,'modified_at'=>'',
            'package_name'=>'','package_size'=>0,'package_valid'=>false,'bootstrap_name'=>'','bootstrap_size'=>0,'bootstrap_valid'=>false,
        );
        $pairs[$v]['total_size'] += (int)$r['size'];
        if($pairs[$v]['modified_at']==='' || strcmp((string)$r['modified_at'],(string)$pairs[$v]['modified_at'])>0) $pairs[$v]['modified_at']=$r['modified_at'];
        if($r['kind']==='package') { $pairs[$v]['package_name']=$r['name']; $pairs[$v]['package_size']=(int)$r['size']; $pairs[$v]['package_valid']=!empty($r['valid_pe']); }
        else { $pairs[$v]['bootstrap_name']=$r['name']; $pairs[$v]['bootstrap_size']=(int)$r['size']; $pairs[$v]['bootstrap_valid']=!empty($r['valid_pe']); }
    }
    $pairRows=array_values($pairs);
    foreach($pairRows as &$p) $p['complete']=$p['package_name']!==''&&$p['bootstrap_name']!==''&&!empty($p['package_valid'])&&!empty($p['bootstrap_valid']);
    unset($p);
    usort($pairRows,function($a,$b){return dmd_update_mgr_version_compare((string)$b['version'],(string)$a['version']);});
    $latest=''; foreach($pairRows as $p){if(!empty($p['complete'])){$latest=(string)$p['version'];break;}}
    return array('files'=>$rows,'pairs'=>$pairRows,'count'=>count($rows),'pair_count'=>count($pairRows),'total_bytes'=>$bytes,'latest_version'=>$latest);
}
function dmd_update_mgr_publish_file($tmp,$dest){
    if(@rename($tmp,$dest)) return true;
    if(is_file($dest) && !@unlink($dest)) return false;
    return @rename($tmp,$dest);
}

if ($action === 'list') {
    dmd_json_response(array('ok'=>true)+dmd_update_mgr_snapshot());
}

if ($action === 'delete') {
    $names = isset($payload['files']) && is_array($payload['files']) ? $payload['files'] : array();
    $names = array_values(array_unique(array_map('strval', $names)));
    if (!$names) dmd_json_response(array('ok'=>false,'error'=>'files_missing'),400);
    $dir = dmd_update_mgr_dir();
    $deleted = array(); $errors = array();
    foreach ($names as $name) {
        $name = basename(str_replace('\\','/',trim($name)));
        if (!dmd_update_mgr_name_ok($name)) { $errors[$name]='name_invalid'; continue; }
        $path = $dir . DIRECTORY_SEPARATOR . $name;
        if (!is_file($path)) { $errors[$name]='not_found'; continue; }
        if (@unlink($path)) $deleted[]=$name; else $errors[$name]='delete_failed';
    }
    dmd_system_log('agent_update_packages_delete','maintenance','warning','Suppression de packages DMD-Agent.',array('files'=>$deleted,'errors'=>$errors,'actor'=>$email));
    $list=dmd_update_mgr_snapshot();
    dmd_json_response(array('ok'=>count($deleted)>0,'deleted'=>$deleted,'errors'=>$errors)+$list, count($deleted)>0?200:400);
}

if ($action === 'upload') {
    if (!class_exists('ZipArchive')) dmd_json_response(array('ok'=>false,'error'=>'ziparchive_missing'),500);
    if (!isset($_FILES['package_zip']) || !is_array($_FILES['package_zip'])) dmd_json_response(array('ok'=>false,'error'=>'zip_missing'),400);
    $f=$_FILES['package_zip'];
    $uploadError=(int)($f['error']??UPLOAD_ERR_NO_FILE);
    if ($uploadError!==UPLOAD_ERR_OK || !is_uploaded_file((string)($f['tmp_name']??''))) {
        dmd_json_response(array('ok'=>false,'error'=>'zip_upload_failed','upload_error'=>$uploadError),400);
    }
    $zip = new ZipArchive();
    if ($zip->open((string)$f['tmp_name']) !== true) dmd_json_response(array('ok'=>false,'error'=>'zip_invalid'),400);
    $dir=dmd_update_mgr_dir();
    $ignored=array(); $errors=array(); $totalUncompressed=0; $staged=array();
    $stage=$dir.DIRECTORY_SEPARATOR.'.dmd-upload-'.bin2hex(random_bytes(6));
    if(!@mkdir($stage,0700,true) && !is_dir($stage)){ $zip->close(); dmd_json_response(array('ok'=>false,'error'=>'stage_create_failed'),500); }
    try {
        for ($i=0;$i<$zip->numFiles;$i++) {
            $st=$zip->statIndex($i); if(!is_array($st))continue;
            $entry=(string)($st['name']??'');
            if ($entry==='' || substr($entry,-1)==='/') continue;
            $name=basename(str_replace('\\','/',$entry));
            $size=(int)($st['size']??0); $totalUncompressed += max(0,$size);
            if ($totalUncompressed > 4294967296) { $errors[$entry]='archive_too_large'; break; }
            if (!dmd_update_mgr_name_ok($name)) { $ignored[]=$entry; continue; }
            $stream=$zip->getStream($entry); if(!$stream){$errors[$entry]='read_failed';continue;}
            $tmp=$stage.DIRECTORY_SEPARATOR.$name;
            $out=@fopen($tmp,'wb'); if(!$out){fclose($stream);$errors[$entry]='write_failed';continue;}
            stream_copy_to_stream($stream,$out); fclose($stream); fclose($out);
            if(!dmd_update_mgr_is_pe($tmp)){@unlink($tmp);$errors[$entry]='not_windows_executable';continue;}
            $staged[$name]=$tmp;
        }

        $versions=array();
        foreach($staged as $name=>$tmp){
            $v=dmd_update_mgr_version($name); if($v!=='')$versions[$v]=true;
        }
        if(!$versions){
            dmd_json_response(array('ok'=>false,'error'=>'no_update_file_in_zip','ignored'=>$ignored,'errors'=>$errors)+dmd_update_mgr_snapshot(),400);
        }

        $publish=array(); $rejectedVersions=array();
        foreach(array_keys($versions) as $v){
            $package='update.'.$v.'.exe'; $bootstrap='DMD-Agent.'.$v.'.exe';
            $hasPackage=isset($staged[$package]) || dmd_update_mgr_is_pe($dir.DIRECTORY_SEPARATOR.$package);
            $hasBootstrap=isset($staged[$bootstrap]) || dmd_update_mgr_is_pe($dir.DIRECTORY_SEPARATOR.$bootstrap);
            if(!$hasPackage || !$hasBootstrap){
                $rejectedVersions[$v]='pair_incomplete';
                continue;
            }
            if(isset($staged[$package]))$publish[$package]=$staged[$package];
            if(isset($staged[$bootstrap]))$publish[$bootstrap]=$staged[$bootstrap];
        }
        if(!$publish){
            dmd_json_response(array('ok'=>false,'error'=>'update_pair_incomplete','versions'=>$rejectedVersions,'ignored'=>$ignored,'errors'=>$errors)+dmd_update_mgr_snapshot(),400);
        }

        $installed=array();
        foreach($publish as $name=>$tmp){
            $dest=$dir.DIRECTORY_SEPARATOR.$name;
            if(!dmd_update_mgr_publish_file($tmp,$dest)){ $errors[$name]='move_failed'; continue; }
            @chmod($dest,0644); $installed[]=$name; unset($staged[$name]);
        }
        $installedVersions=array_values(array_unique(array_map('dmd_update_mgr_version',$installed)));
        dmd_system_log('agent_update_packages_upload','maintenance','warning','Import manuel de packages DMD-Agent.',array(
            'archive'=>(string)($f['name']??'update.zip'),'installed'=>$installed,'versions'=>$installedVersions,
            'ignored'=>$ignored,'errors'=>$errors,'rejected_versions'=>$rejectedVersions,'actor'=>$email
        ));
        $list=dmd_update_mgr_snapshot();
        dmd_json_response(array('ok'=>count($installed)>0,'installed'=>$installed,'installed_versions'=>$installedVersions,'ignored'=>$ignored,'errors'=>$errors,'rejected_versions'=>$rejectedVersions)+$list, count($installed)>0?200:400);
    } finally {
        $zip->close();
        foreach((array)@scandir($stage) as $n){if($n!=='.'&&$n!=='..')@unlink($stage.DIRECTORY_SEPARATOR.$n);} @rmdir($stage);
    }
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'),400);
