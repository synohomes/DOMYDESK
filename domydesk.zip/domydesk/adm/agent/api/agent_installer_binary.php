<?php
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
$file = dirname(__DIR__) . '/bin/windows-x64/DMD-Installer.exe';
if (!is_file($file) || !is_readable($file)) { http_response_code(404); exit; }
$size = @filesize($file);
if ($size === false || $size < 1024 || $size > 100663296) { http_response_code(500); exit; }
$fh = @fopen($file, 'rb');
if (!$fh) { http_response_code(500); exit; }
$magic = fread($fh, 2);
if ($magic !== 'MZ') { fclose($fh); http_response_code(500); exit; }
rewind($fh);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="DMD-Installer.exe"');
header('Content-Length: ' . $size);
while (!feof($fh)) {
    $chunk = fread($fh, 1048576);
    if ($chunk === false) break;
    if ($chunk !== '') echo $chunk;
    if (connection_aborted()) break;
}
fclose($fh);
exit;
