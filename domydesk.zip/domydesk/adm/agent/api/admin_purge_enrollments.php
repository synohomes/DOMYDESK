<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('agent_admin', $payload);

$mode = isset($payload['mode']) ? (string)$payload['mode'] : 'expired';
$deleted = 0;
$deletedIds = array();

$deleteExpired = function($id) use (&$deleted, &$deletedIds) {
    $id = dmd_agent_safe_enrollment_id($id);
    if ($id === '') return false;
    $file = dmd_agent_enrollment_file($id);
    if ($file === '' || !is_file($file)) return false;
    $e = dmd_agent_load_enrollment($id);
    if (!$e) return false;

    // Refresh the status before deciding. This never deletes a live/pending enrollment.
    if (dmd_agent_enrollment_expired($e) && !in_array((string)($e['status'] ?? ''), array('completed','rejected','expired'), true)) {
        $e['status'] = 'expired';
        dmd_agent_save_enrollment($e);
    }
    if ((string)($e['status'] ?? '') !== 'expired') return false;

    if (!@unlink($file)) return false;
    $deleted++;
    $deletedIds[] = $id;
    return true;
};

if ($mode === 'one') {
    $id = isset($payload['enrollment_id']) ? (string)$payload['enrollment_id'] : '';
    if (!$deleteExpired($id)) {
        dmd_json_response(array('ok'=>false,'error'=>'not_expired_or_delete_failed'), 400);
    }
} elseif ($mode === 'expired') {
    foreach (dmd_agent_list_enrollments() as $e) {
        if ((string)($e['status'] ?? '') !== 'expired') continue;
        $deleteExpired((string)($e['enrollment_id'] ?? ''));
    }
} else {
    dmd_json_response(array('ok'=>false,'error'=>'invalid_mode'), 400);
}

dmd_system_log(
    'agent_enrollment_purge',
    $mode === 'one' ? (isset($deletedIds[0]) ? $deletedIds[0] : '') : 'expired',
    'warning',
    'Purge d’enrôlement(s) DMD-Agent expiré(s).',
    array('mode'=>$mode,'deleted'=>$deleted,'enrollment_ids'=>$deletedIds,'actor'=>$email)
);

dmd_json_response(array('ok'=>true,'deleted'=>$deleted,'enrollment_ids'=>$deletedIds), 200);
