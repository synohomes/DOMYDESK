<?php
require_once dirname(__DIR__) . '/includes/admin_bootstrap.php';
require_once dirname(__DIR__) . '/includes/software_packages.php';
dmd_api_require_method('POST');
dmd_api_require_csrf('agent_admin', $_POST);
if (empty($_FILES['package'])) dmd_json_response(array('ok'=>false,'error'=>'package_missing'),400);
$result = dmd_agent_software_package_create_upload($_FILES['package'], $email);
if (empty($result['ok'])) dmd_json_response($result,400);
$p = $result['package'];
dmd_system_log('agent_software_package_upload',$p['package_id'],'warning','Package logiciel déposé pour installation distante.',array(
    'file_name'=>$p['file_name'],'size'=>$p['size'],'sha256'=>$p['sha256'],'expires_at'=>$p['expires_at']
));
dmd_json_response(array('ok'=>true,'package'=>array(
    'package_id'=>$p['package_id'],'file_name'=>$p['file_name'],'size'=>$p['size'],'sha256'=>$p['sha256'],'expires_at'=>$p['expires_at']
),'token'=>$result['token']));
