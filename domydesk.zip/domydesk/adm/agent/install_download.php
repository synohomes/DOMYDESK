<?php
require_once __DIR__ . '/includes/agent_core.php';

function dmd_install_download_fail($status, $message) {
    http_response_code((int)$status);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('Pragma: no-cache');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');
    echo (string)$message;
    exit;
}

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
    dmd_install_download_fail(405, 'Méthode non autorisée.');
}

$token = trim((string)($_GET['t'] ?? ''));
$type = strtolower(trim((string)($_GET['file'] ?? '')));

$loaded = dmd_agent_install_link_load($token, true);
if (empty($loaded['ok'])) {
    $error = (string)($loaded['error'] ?? 'install_link_invalid');
    $http = in_array($error, array('install_link_expired','enrollment_expired'), true) ? 410
        : ($error === 'install_link_consumed' ? 409 : 404);
    dmd_install_download_fail($http, 'Lien d’installation invalide, expiré ou déjà utilisé.');
}

$row = $loaded['row'];

@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
while (ob_get_level() > 0) { @ob_end_clean(); }

header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('Content-Encoding: identity');

if ($type === 'installer') {
    $installer = dmd_agent_installer_binary_validate();
    if (empty($installer['ok'])) {
        dmd_install_download_fail(503, 'DMD-Installer.exe est indisponible.');
    }

    dmd_agent_install_link_increment($token, 'installer_downloads');
    dmd_agent_log('enrollment_installer_binary_downloaded', 'success', array(
        'enrollment_id'=>(string)($row['enrollment_id'] ?? ''),
        'size'=>(int)$installer['size'],
    ));

    header('Content-Type: application/vnd.microsoft.portable-executable');
    header('Content-Disposition: attachment; filename="DMD-Installer.exe"');
    header('Content-Length: ' . (int)$installer['size']);
    header('X-DMD-SHA256: ' . (string)$installer['sha256']);

    $fh = @fopen($installer['path'], 'rb');
    if (!$fh) exit;
    while (!feof($fh)) {
        $chunk = fread($fh, 1048576);
        if ($chunk === false) break;
        if ($chunk !== '') echo $chunk;
    }
    fclose($fh);
    exit;
}

if ($type === 'bootstrap') {
    $raw = dmd_agent_install_link_bootstrap_raw($row);
    if ($raw === '') dmd_install_download_fail(500, 'Bootstrap temporaire invalide.');

    dmd_agent_install_link_increment($token, 'bootstrap_downloads');
    dmd_agent_log('enrollment_bootstrap_downloaded', 'success', array(
        'enrollment_id'=>(string)($row['enrollment_id'] ?? ''),
    ));

    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="bootstrap.json"');
    header('Content-Length: ' . strlen($raw));
    header('X-DMD-SHA256: ' . strtolower(hash('sha256', $raw)));

    echo $raw;
    exit;
}

dmd_install_download_fail(400, 'Type de fichier invalide.');
