<?php
/**
 * DMD-Agent command queue.
 * Loaded by agent_core.php after the enrollment/access helpers.
 */
if (!function_exists('dmd_agent_command_safe_id')) {
    function dmd_agent_command_safe_id($id) {
        $id = strtoupper(trim((string)$id));
        return preg_match('/^CMD-[A-F0-9]{24}$/', $id) ? $id : '';
    }
}

if (!function_exists('dmd_agent_command_queue_file')) {
    function dmd_agent_command_queue_file($agentId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        return $agentId === '' ? '' : DMD_AGENT_VAR . '/commands/' . $agentId . '.php';
    }
}

if (!function_exists('dmd_agent_command_lock_file')) {
    function dmd_agent_command_lock_file($agentId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        return $agentId === '' ? '' : DMD_AGENT_VAR . '/commands/' . $agentId . '.lock';
    }
}

if (!function_exists('dmd_agent_command_default_queue')) {
    function dmd_agent_command_default_queue() {
        return array('schema'=>1, 'commands'=>array(), 'interactive_until_ts'=>0);
    }
}

if (!function_exists('dmd_agent_command_queue_read')) {
    function dmd_agent_command_queue_read($agentId) {
        $file = dmd_agent_command_queue_file($agentId);
        if ($file === '') return dmd_agent_command_default_queue();
        $data = dmd_agent_json_read($file, dmd_agent_command_default_queue());
        if (!isset($data['commands']) || !is_array($data['commands'])) $data['commands'] = array();
        $data['schema'] = 1;
        if (!isset($data['interactive_until_ts'])) $data['interactive_until_ts'] = 0;
        return $data;
    }
}

if (!function_exists('dmd_agent_command_queue_write')) {
    function dmd_agent_command_queue_write($agentId, $data) {
        $file = dmd_agent_command_queue_file($agentId);
        if ($file === '') return false;
        if (!is_array($data)) $data = dmd_agent_command_default_queue();
        if (!isset($data['commands']) || !is_array($data['commands'])) $data['commands'] = array();
        $data['schema'] = 1;
        if (!isset($data['interactive_until_ts'])) $data['interactive_until_ts'] = 0;
        return dmd_agent_json_write($file, $data, 0640);
    }
}

if (!function_exists('dmd_agent_command_with_lock')) {
    function dmd_agent_command_with_lock($agentId, $callback) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        if ($agentId === '' || !is_callable($callback)) return null;
        $dir = DMD_AGENT_VAR . '/commands';
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return null;
        @chmod($dir, 0750);
        $lockFile = dmd_agent_command_lock_file($agentId);
        $fh = @fopen($lockFile, 'c+');
        if (!$fh) return null;
        $result = null;
        if (@flock($fh, LOCK_EX)) {
            try {
                $data = dmd_agent_command_queue_read($agentId);
                $result = call_user_func_array($callback, array(&$data));
                dmd_agent_command_queue_write($agentId, $data);
            } catch (Throwable $e) {
                $result = null;
            }
            @flock($fh, LOCK_UN);
        }
        @fclose($fh);
        @chmod($lockFile, 0640);
        return $result;
    }
}

if (!function_exists('dmd_agent_command_payload_size_ok')) {
    function dmd_agent_command_payload_size_ok($payload) {
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($json) && strlen($json) <= 65536;
    }
}

if (!function_exists('dmd_agent_command_trim_result')) {
    function dmd_agent_command_trim_result($result) {
        $json = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (is_string($json) && strlen($json) <= 49152) return $result;
        return array('truncated'=>true, 'message'=>'Résultat trop volumineux pour le canal heartbeat.', 'size'=>is_string($json)?strlen($json):0);
    }
}

if (!function_exists('dmd_agent_command_cleanup_data')) {
    function dmd_agent_command_cleanup_data(&$data) {
        if (!isset($data['commands']) || !is_array($data['commands'])) $data['commands'] = array();
        $now = time();
        foreach ($data['commands'] as $id => &$command) {
            if (!is_array($command)) { unset($data['commands'][$id]); continue; }
            $status = (string)(isset($command['status']) ? $command['status'] : 'queued');
            $expiresTs = isset($command['expires_ts']) ? (int)$command['expires_ts'] : 0;
            if (($status === 'queued' || $status === 'delivered') && $expiresTs > 0 && $now > $expiresTs) {
                $command['status'] = 'expired';
                $command['completed_ts'] = $now;
                $command['completed_at'] = gmdate('c', $now);
                $command['error'] = 'command_expired';
            }
        }
        unset($command);
        if (count($data['commands']) > 240) {
            uasort($data['commands'], function($a,$b){ return (int)(isset($b['created_ts'])?$b['created_ts']:0) <=> (int)(isset($a['created_ts'])?$a['created_ts']:0); });
            $data['commands'] = array_slice($data['commands'], 0, 240, true);
        }
    }
}

if (!function_exists('dmd_agent_command_mark_interactive')) {
    function dmd_agent_command_mark_interactive($agentId, $seconds = 45) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $seconds = max(5, min(300, (int)$seconds));
        if ($agentId === '') return false;
        $until = time() + $seconds;
        $result = dmd_agent_command_with_lock($agentId, function(&$data) use ($until) {
            dmd_agent_command_cleanup_data($data);
            $current = isset($data['interactive_until_ts']) ? (int)$data['interactive_until_ts'] : 0;
            $data['interactive_until_ts'] = max($current, $until);
            return true;
        });
        return $result === true;
    }
}

if (!function_exists('dmd_agent_command_interactive_until')) {
    function dmd_agent_command_interactive_until($agentId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        if ($agentId === '') return 0;
        $result = dmd_agent_command_with_lock($agentId, function(&$data) {
            dmd_agent_command_cleanup_data($data);
            return isset($data['interactive_until_ts']) ? (int)$data['interactive_until_ts'] : 0;
        });
        return is_int($result) ? $result : 0;
    }
}

if (!function_exists('dmd_agent_command_next_poll_ms')) {
    function dmd_agent_command_next_poll_ms($agentId, $hasWork = false) {
        if ($hasWork) return 80;
        $until = dmd_agent_command_interactive_until($agentId);
        return $until >= time() ? 120 : 500;
    }
}

if (!function_exists('dmd_agent_queue_command')) {
    function dmd_agent_queue_command($agentId, $type, $payload, $actor, $requiredCapability = '', $ttlSeconds = 300) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $type = strtolower(trim((string)$type));
        $actor = substr(trim((string)$actor), 0, 180);
        $requiredCapability = trim((string)$requiredCapability);
        $ttlSeconds = max(30, min(3600, (int)$ttlSeconds));
        if ($agentId === '' || !preg_match('/^[a-z0-9._:-]{2,80}$/', $type)) return array('ok'=>false,'error'=>'command_invalid');
        if (!is_array($payload)) $payload = array();
        if (!dmd_agent_command_payload_size_ok($payload)) return array('ok'=>false,'error'=>'payload_too_large');
        $deviceFile = dmd_agent_device_file($agentId);
        if ($deviceFile === '' || !is_file($deviceFile)) return array('ok'=>false,'error'=>'agent_not_found');
        $device = dmd_agent_json_read($deviceFile, array());
        if (!$device || (string)(isset($device['status'])?$device['status']:'') !== 'active') return array('ok'=>false,'error'=>'agent_inactive');
        if ($requiredCapability !== '') {
            $caps = array_unique(array_merge((array)(isset($device['capabilities'])?$device['capabilities']:array()), (array)(isset($device['reported_capabilities'])?$device['reported_capabilities']:array())));
            if (!in_array($requiredCapability, $caps, true)) return array('ok'=>false,'error'=>'capability_missing');
        }
        $id = dmd_agent_short_id('CMD', 12);
        $now = time();
        $command = array(
            'schema'=>1,
            'command_id'=>$id,
            'agent_id'=>$agentId,
            'type'=>$type,
            'payload'=>$payload,
            'required_capability'=>$requiredCapability,
            'status'=>'queued',
            'created_ts'=>$now,
            'created_at'=>gmdate('c', $now),
            'created_by'=>$actor,
            'expires_ts'=>$now+$ttlSeconds,
            'expires_at'=>gmdate('c', $now+$ttlSeconds),
            'deliveries'=>0,
            'last_delivered_ts'=>0,
            'last_delivered_at'=>'',
            'completed_ts'=>0,
            'completed_at'=>'',
            'result'=>null,
            'error'=>'',
        );
        $saved = dmd_agent_command_with_lock($agentId, function(&$data) use ($id, $command, $now) {
            dmd_agent_command_cleanup_data($data);
            $data['commands'][$id] = $command;
            $data['interactive_until_ts'] = max((int)($data['interactive_until_ts'] ?? 0), $now + 45);
            return true;
        });
        if (!$saved) return array('ok'=>false,'error'=>'queue_write_failed');
        dmd_agent_log('command_queued', 'success', array('agent_id'=>$agentId,'command_id'=>$id,'type'=>$type,'actor'=>$actor));
        return array('ok'=>true,'command'=>$command);
    }
}

if (!function_exists('dmd_agent_command_collect')) {
    function dmd_agent_command_collect($agentId, $limit = 12) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $limit = max(1, min(30, (int)$limit));
        if ($agentId === '') return array();
        $result = dmd_agent_command_with_lock($agentId, function(&$data) use ($limit) {
            dmd_agent_command_cleanup_data($data);
            $now = time();
            $out = array();
            foreach ($data['commands'] as &$command) {
                if (!is_array($command)) continue;
                $status = (string)(isset($command['status']) ? $command['status'] : 'queued');
                if ($status !== 'queued' && $status !== 'delivered') continue;
                $last = isset($command['last_delivered_ts']) ? (int)$command['last_delivered_ts'] : 0;
                if ($status === 'delivered' && $last > 0 && ($now - $last) < 20) continue;
                $deliveries = isset($command['deliveries']) ? (int)$command['deliveries'] : 0;
                if ($deliveries >= 20) {
                    $command['status'] = 'failed';
                    $command['error'] = 'agent_no_ack';
                    $command['completed_ts'] = $now;
                    $command['completed_at'] = gmdate('c', $now);
                    continue;
                }
                $command['status'] = 'delivered';
                $command['deliveries'] = $deliveries + 1;
                $command['last_delivered_ts'] = $now;
                $command['last_delivered_at'] = gmdate('c', $now);
                $wire = array(
                    'command_id'=>(string)$command['command_id'],
                    'type'=>(string)$command['type'],
                    'payload'=>(isset($command['payload']) && is_array($command['payload']) && count($command['payload']) > 0) ? $command['payload'] : (object)array(),
                    'created_at'=>(string)$command['created_at'],
                    'expires_at'=>(string)$command['expires_at'],
                );
                // update_agent est historiquement lu par le binaire Agent avec
                // version/url/sha256 au premier niveau. On conserve le payload
                // générique dans le stockage serveur mais on aplatit uniquement
                // ces champs lors de l'envoi signé.
                if ((string)$command['type'] === 'update_agent') {
                    $p = (isset($command['payload']) && is_array($command['payload'])) ? $command['payload'] : array();
                    $wire['version'] = (string)($p['version'] ?? '');
                    $wire['url'] = (string)($p['url'] ?? '');
                    $wire['sha256'] = (string)($p['sha256'] ?? '');
                    $wire['force'] = !empty($p['force']);
                    $wire['authenticode_thumbprint'] = (string)($p['authenticode_thumbprint'] ?? '');
                }
                $out[] = $wire;
                if (count($out) >= $limit) break;
            }
            unset($command);
            return $out;
        });
        return is_array($result) ? $result : array();
    }
}

if (!function_exists('dmd_agent_command_apply_results')) {
    function dmd_agent_command_apply_results($agentId, $results) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        if ($agentId === '' || !is_array($results)) return 0;
        $results = array_slice($results, -40);
        $count = dmd_agent_command_with_lock($agentId, function(&$data) use ($results, $agentId) {
            dmd_agent_command_cleanup_data($data);
            $updated = 0;
            $now = time();
            foreach ($results as $row) {
                if (!is_array($row)) continue;
                $id = dmd_agent_command_safe_id(isset($row['command_id']) ? $row['command_id'] : (isset($row['id']) ? $row['id'] : ''));
                if ($id === '' || !isset($data['commands'][$id]) || !is_array($data['commands'][$id])) continue;
                $status = strtolower(trim((string)(isset($row['status']) ? $row['status'] : 'completed')));
                if (in_array($status, array('ok','success','succeeded','done'), true)) $status = 'completed';
                if (in_array($status, array('error','failure'), true)) $status = 'failed';
                if (!in_array($status, array('downloading','verified','installing','completed','failed'), true)) continue;
                $command =& $data['commands'][$id];
                $command['status'] = $status;
                $command['result'] = dmd_agent_command_trim_result(isset($row['result']) ? $row['result'] : (isset($row['data']) ? $row['data'] : null));
                $command['error'] = substr((string)(isset($row['error']) ? $row['error'] : ''), 0, 1000);
                $command['message'] = substr((string)(isset($row['message']) ? $row['message'] : ''), 0, 1000);
                $command['updated_ts'] = $now;
                $command['updated_at'] = gmdate('c', $now);
                if ($status === 'completed' || $status === 'failed') {
                    $command['completed_ts'] = $now;
                    $command['completed_at'] = gmdate('c', $now);
                }
                $data['interactive_until_ts'] = max((int)($data['interactive_until_ts'] ?? 0), $now + 20);
                $updated++;
                if ($status === 'completed' || $status === 'failed') {
                    dmd_agent_log('command_result', $status === 'completed' ? 'success' : 'error', array('agent_id'=>$agentId,'command_id'=>$id,'type'=>(string)$command['type'],'error'=>$command['error']));

                    // Conserve un audit persistant spécifique aux mises à jour Agent.
                    // Le marqueur évite d'écrire plusieurs fois le même résultat si
                    // l'Agent renvoie son dernier état terminal sur plusieurs polls.
                    if ((string)$command['type'] === 'update_agent' && empty($command['update_audit_logged']) && function_exists('dmd_system_log')) {
                        $auditPayload = isset($command['payload']) && is_array($command['payload']) ? $command['payload'] : array();
                        $auditResult = isset($command['result']) && is_array($command['result']) ? $command['result'] : array();
                        $auditCause = trim((string)$command['error']);
                        if ($auditCause === '') $auditCause = trim((string)($command['message'] ?? ''));
                        if ($auditCause === '') {
                            foreach (array('error','error_message','message','detail','reason') as $auditKey) {
                                $auditValue = trim((string)($auditResult[$auditKey] ?? ''));
                                if ($auditValue !== '') { $auditCause = $auditValue; break; }
                            }
                        }
                        if ($auditCause === '') $auditCause = $status === 'completed' ? 'Mise à jour terminée avec succès.' : 'Échec sans détail retourné par l’Agent.';
                        dmd_system_log(
                            'agent_update_result',
                            $agentId,
                            $status === 'completed' ? 'success' : 'error',
                            $auditCause,
                            array(
                                'agent_id'=>$agentId,
                                'command_id'=>$id,
                                'actor'=>(string)($command['created_by'] ?? ''),
                                'version'=>(string)($auditPayload['version'] ?? ''),
                                'stage'=>(string)($auditPayload['stage'] ?? 'package'),
                                'cause'=>$auditCause,
                                'result'=>$auditResult,
                            )
                        );
                        $command['update_audit_logged'] = true;
                    }
                }
                unset($command);
            }
            return $updated;
        });
        return is_int($count) ? $count : 0;
    }
}

if (!function_exists('dmd_agent_command_status')) {
    function dmd_agent_command_status($agentId, $commandId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $commandId = dmd_agent_command_safe_id($commandId);
        if ($agentId === '' || $commandId === '') return array();
        $result = dmd_agent_command_with_lock($agentId, function(&$data) use ($commandId) {
            dmd_agent_command_cleanup_data($data);
            return isset($data['commands'][$commandId]) && is_array($data['commands'][$commandId]) ? $data['commands'][$commandId] : array();
        });
        return is_array($result) ? $result : array();
    }
}

if (!function_exists('dmd_agent_command_history')) {
    function dmd_agent_command_history($agentId, $limit = 50) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $limit = max(1, min(100, (int)$limit));
        if ($agentId === '') return array();
        $result = dmd_agent_command_with_lock($agentId, function(&$data) use ($limit) {
            dmd_agent_command_cleanup_data($data);
            $rows = array_values($data['commands']);
            usort($rows, function($a,$b){ return (int)(isset($b['created_ts'])?$b['created_ts']:0) <=> (int)(isset($a['created_ts'])?$a['created_ts']:0); });
            return array_slice($rows, 0, $limit);
        });
        return is_array($result) ? $result : array();
    }
}

if (!function_exists('dmd_agent_command_pending_count')) {
    function dmd_agent_command_pending_count($agentId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        if ($agentId === '') return 0;
        $result = dmd_agent_command_with_lock($agentId, function(&$data) {
            dmd_agent_command_cleanup_data($data);
            $count = 0;
            foreach ($data['commands'] as $command) {
                $status = is_array($command) ? (string)(isset($command['status'])?$command['status']:'') : '';
                if ($status === 'queued' || $status === 'delivered') $count++;
            }
            return $count;
        });
        return is_int($result) ? $result : 0;
    }
}

if (!function_exists('dmd_agent_command_cancel')) {
    function dmd_agent_command_cancel($agentId, $commandId, $actor) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        $commandId = dmd_agent_command_safe_id($commandId);
        if ($agentId === '' || $commandId === '') return array('ok'=>false,'error'=>'command_invalid');
        $result = dmd_agent_command_with_lock($agentId, function(&$data) use ($commandId, $actor) {
            dmd_agent_command_cleanup_data($data);
            if (!isset($data['commands'][$commandId]) || !is_array($data['commands'][$commandId])) return array('ok'=>false,'error'=>'command_not_found');
            $command =& $data['commands'][$commandId];
            if (!in_array((string)$command['status'], array('queued','delivered'), true)) return array('ok'=>false,'error'=>'command_not_pending');
            $now = time();
            $command['status'] = 'cancelled';
            $command['completed_ts'] = $now;
            $command['completed_at'] = gmdate('c', $now);
            $command['error'] = 'cancelled_by:' . substr(trim((string)$actor), 0, 180);
            unset($command);
            return array('ok'=>true);
        });
        return is_array($result) ? $result : array('ok'=>false,'error'=>'queue_write_failed');
    }
}
