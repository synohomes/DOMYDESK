<?php
/**
 * Dépôt distant DMD-Agent.
 *
 * Le dépôt ne contient aucune version codée en dur : les ZIP présents dans le
 * dossier OneDrive public sont découverts à la demande. Seul l'URL du dossier
 * public est configurée ici.
 */
if (!defined('DMD_AGENT_RELEASE_ONEDRIVE_URL')) {
    define('DMD_AGENT_RELEASE_ONEDRIVE_URL', 'https://1drv.ms/f/c/515115639c39fd9d/IgBkeW2aVHHfRZFQ9xDTSnSFAYSsgYPr3HewbtOvpz9xqr0?e=C6W9fx');
}
if (!defined('DMD_AGENT_REPOSITORY_MAX_ZIP_BYTES')) define('DMD_AGENT_REPOSITORY_MAX_ZIP_BYTES', 536870912); // 512 Mio
if (!defined('DMD_AGENT_REPOSITORY_MAX_EXE_BYTES')) define('DMD_AGENT_REPOSITORY_MAX_EXE_BYTES', 268435456); // 256 Mio

function dmd_agent_repo_base64url($value) {
    return rtrim(strtr(base64_encode((string)$value), '+/', '-_'), '=');
}

function dmd_agent_repo_share_id() {
    return 'u!' . dmd_agent_repo_base64url(DMD_AGENT_RELEASE_ONEDRIVE_URL);
}

function dmd_agent_repo_state_dir() {
    if (defined('DMD_AGENT_VAR')) return rtrim(DMD_AGENT_VAR, '/\\') . '/repository';
    return dirname(__DIR__) . '/var/repository';
}

function dmd_agent_repo_state_file() {
    return dmd_agent_repo_state_dir() . '/installed.json';
}

function dmd_agent_repo_installer_path() {
    return dirname(__DIR__) . '/bin/windows-x64/DMD-Installer.exe';
}

function dmd_agent_repo_ensure_dir($dir) {
    if (is_dir($dir)) return true;
    return @mkdir($dir, 0750, true) || is_dir($dir);
}

function dmd_agent_repo_read_json_file($file, $fallback = array()) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_agent_repo_write_json_file($file, $data) {
    $dir = dirname($file);
    if (!dmd_agent_repo_ensure_dir($dir)) return false;
    $tmp = $file . '.tmp-' . bin2hex(random_bytes(5));
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false || @file_put_contents($tmp, $json . "\n", LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

function dmd_agent_repo_is_pe_file($file) {
    if (!is_file($file) || filesize($file) < 1024) return false;
    $fh = @fopen($file, 'rb');
    if (!$fh) return false;
    $sig = fread($fh, 2);
    fclose($fh);
    return $sig === "MZ";
}

function dmd_agent_repo_local_status() {
    $file = dmd_agent_repo_installer_path();
    $ready = dmd_agent_repo_is_pe_file($file);
    $state = dmd_agent_repo_read_json_file(dmd_agent_repo_state_file(), array());
    $sha = $ready ? @hash_file('sha256', $file) : '';
    $stateSha = strtolower(trim((string)($state['sha256'] ?? '')));
    if ($stateSha !== '' && $sha !== '' && !hash_equals($stateSha, strtolower($sha))) $state = array();
    return array(
        'ready' => $ready,
        'path' => $file,
        'size' => $ready ? (int)@filesize($file) : 0,
        'sha256' => $sha ?: '',
        'version' => trim((string)($state['version'] ?? '')),
        'source_name' => trim((string)($state['source_name'] ?? '')),
        'installed_at' => trim((string)($state['installed_at'] ?? '')),
        'installed_by' => trim((string)($state['installed_by'] ?? '')),
    );
}

function dmd_agent_repo_public_local_status() {
    $status = dmd_agent_repo_local_status();
    unset($status['path']);
    return $status;
}

/* ============================================================
 * Activation explicite du système Agents DoMyDesk
 * ============================================================
 * - Installation neuve sans EXE : désactivé par défaut.
 * - Installation existante avec DMD-Installer.exe / devices : migration
 *   automatique en "actif" tant qu'aucun choix explicite n'a été enregistré.
 * - Désactiver ne supprime PAS les agents ni l'installateur déjà téléchargé.
 */
function dmd_agent_system_state_file() {
    return dmd_agent_repo_state_dir() . '/system.json';
}

function dmd_agent_system_detect_existing_installation() {
    if (!empty(dmd_agent_repo_local_status()['ready'])) return true;

    if (defined('DMD_AGENT_VAR')) {
        $deviceFiles = glob(rtrim(DMD_AGENT_VAR, '/\\') . '/devices/AGT-*.php') ?: array();
        if ($deviceFiles) return true;

        $enrollmentFiles = glob(rtrim(DMD_AGENT_VAR, '/\\') . '/enrollments/ENR-*.php') ?: array();
        if ($enrollmentFiles) return true;
    }

    return false;
}

function dmd_agent_system_status() {
    $file = dmd_agent_system_state_file();
    $saved = dmd_agent_repo_read_json_file($file, array());

    if (array_key_exists('enabled', $saved)) {
        $enabled = !empty($saved['enabled']);
        $explicit = true;
    } else {
        $enabled = dmd_agent_system_detect_existing_installation();
        $explicit = false;
    }

    return array(
        'enabled'=>$enabled,
        'explicit'=>$explicit,
        'updated_at'=>trim((string)($saved['updated_at'] ?? '')),
        'updated_by'=>trim((string)($saved['updated_by'] ?? '')),
        'installer'=>dmd_agent_repo_public_local_status(),
    );
}

function dmd_agent_system_set_enabled($enabled, $actor = '') {
    $data = array(
        'schema'=>1,
        'enabled'=>(bool)$enabled,
        'updated_at'=>gmdate('c'),
        'updated_by'=>(string)$actor,
    );

    if (!dmd_agent_repo_write_json_file(dmd_agent_system_state_file(), $data)) {
        return array('ok'=>false,'error'=>'agent_system_state_write_failed');
    }

    if (function_exists('dmd_agent_log')) {
        dmd_agent_log(
            !empty($enabled) ? 'agent_system_enabled' : 'agent_system_disabled',
            'success',
            array('actor'=>(string)$actor)
        );
    }

    return array('ok'=>true,'system'=>dmd_agent_system_status());
}



function dmd_agent_repo_browser_user_agent() {
    return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        . '(KHTML, like Gecko) Chrome/125.0 Safari/537.36 DoMyDesk-AgentRepository/1.1';
}

function dmd_agent_repo_curl_request($url, $options = array()) {
    if (!function_exists('curl_init')) return array('ok'=>false,'error'=>'curl_required');
    $url = trim((string)$url);
    if (stripos($url, 'https://') !== 0) return array('ok'=>false,'error'=>'https_required');

    $method = strtoupper(trim((string)($options['method'] ?? 'GET')));
    $headers = isset($options['headers']) && is_array($options['headers']) ? $options['headers'] : array();
    $body = array_key_exists('body', $options) ? (string)$options['body'] : null;
    $maxBytes = max(1024, (int)($options['max_bytes'] ?? 8388608));
    $timeout = max(5, (int)($options['timeout'] ?? 30));
    $cookieFile = trim((string)($options['cookie_file'] ?? ''));
    $follow = !array_key_exists('follow', $options) || !empty($options['follow']);

    $response = '';
    $tooLarge = false;

    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_FOLLOWLOCATION => $follow,
        CURLOPT_MAXREDIRS => 8,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_USERAGENT => dmd_agent_repo_browser_user_agent(),
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_WRITEFUNCTION => function($ch, $chunk) use (&$response, &$tooLarge, $maxBytes) {
            if (strlen($response) + strlen($chunk) > $maxBytes) {
                $tooLarge = true;
                return 0;
            }
            $response .= $chunk;
            return strlen($chunk);
        },
    ));

    if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
    if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);

    if ($cookieFile !== '') {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body === null ? '' : $body);
    } elseif ($method !== 'GET') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }

    if ($headers) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $ok = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $err = curl_error($ch);
    curl_close($ch);

    if ($tooLarge) return array('ok'=>false,'error'=>'response_too_large','http'=>$http,'effective_url'=>$effective);
    if (!$ok || $http < 200 || $http >= 400) {
        return array(
            'ok'=>false,
            'error'=>'http_failed',
            'http'=>$http,
            'details'=>$err,
            'effective_url'=>$effective,
            'body'=>substr($response, 0, 2000),
        );
    }

    return array(
        'ok'=>true,
        'http'=>$http,
        'body'=>$response,
        'effective_url'=>$effective,
        'content_type'=>$contentType,
    );
}

/**
 * Depuis fin 2024 / 2025, api.onedrive.com n'autorise plus l'énumération
 * anonyme fiable d'un partage OneDrive Personal. Le navigateur OneDrive
 * utilise désormais my.microsoftpersonalcontent.com avec un jeton anonyme
 * court délivré par api-badgerp.svc.ms.
 *
 * Cette fonction reproduit uniquement ce flux public en lecture seule :
 *   1. ouvre le lien 1drv.ms pour obtenir redeem + id/resid ;
 *   2. obtient un jeton anonyme de consultation ;
 *   3. "redeem" le partage ;
 *   4. lit les enfants du dossier public.
 */
function dmd_agent_repo_badger_token() {
    $tokenRes = dmd_agent_repo_curl_request('https://api-badgerp.svc.ms/v1.0/token', array(
        'method'=>'POST',
        'timeout'=>25,
        'max_bytes'=>1048576,
        'headers'=>array(
            'Content-Type: application/json',
            'Accept: application/json',
            'AppId: 1141147648',
            'Origin: https://onedrive.live.com',
            'Referer: https://onedrive.live.com/',
        ),
        'body'=>json_encode(array('appId'=>'5cbed6ac-a083-4e14-b191-b4ba07653de2')),
    ));

    if (empty($tokenRes['ok'])) {
        return array('ok'=>false,'error'=>'repo_anonymous_token_failed','details'=>$tokenRes);
    }

    $json = json_decode((string)$tokenRes['body'], true);
    $token = trim((string)($json['token'] ?? ''));
    if ($token === '') {
        return array('ok'=>false,'error'=>'repo_anonymous_token_invalid','details'=>array('body'=>substr((string)$tokenRes['body'],0,500)));
    }

    return array('ok'=>true,'token'=>$token);
}

function dmd_agent_repo_onedrive_personal_rows() {
    if (!function_exists('curl_init')) return array('ok'=>false,'error'=>'curl_required');

    /*
     * OneDrive Personal "migratedtospo" :
     * Le partage public est d'abord autorisé avec un Badger token.
     * IMPORTANT : le share-id est le base64url du LIEN DE PARTAGE ORIGINAL.
     * On n'utilise pas le paramètre redeem comme share-id.
     */
    $badger = dmd_agent_repo_badger_token();
    if (empty($badger['ok'])) return $badger;

    $token = (string)$badger['token'];
    $shareId = dmd_agent_repo_share_id();

    $headers = array(
        'Accept: application/json',
        'Authorization: Badger ' . $token,
        'Prefer: autoredeem',
        'Origin: https://onedrive.live.com',
        'Referer: https://onedrive.live.com/',
    );

    $shareEndpoints = array(
        'https://my.microsoftpersonalcontent.com/_api/v2.0/shares/' . rawurlencode($shareId) . '/driveitem?%24expand=children',
        'https://api.onedrive.com/v1.0/shares/' . rawurlencode($shareId) . '/driveItem?%24expand=children',
    );

    $share = null;
    $lastError = null;

    foreach ($shareEndpoints as $url) {
        $res = dmd_agent_repo_curl_request($url, array(
            'method'=>'GET',
            'timeout'=>35,
            'max_bytes'=>16777216,
            'headers'=>$headers,
        ));

        if (empty($res['ok'])) {
            $lastError = $res;
            continue;
        }

        $decoded = json_decode((string)$res['body'], true);
        if (!is_array($decoded)) {
            $lastError = array('error'=>'repo_share_json_invalid','body'=>substr((string)$res['body'],0,1000));
            continue;
        }

        $share = $decoded;
        break;
    }

    if (!is_array($share)) {
        return array('ok'=>false,'error'=>'repo_share_authorization_failed','details'=>$lastError);
    }

    if (isset($share['children']) && is_array($share['children'])) {
        return array(
            'ok'=>true,
            'rows'=>$share['children'],
            'source'=>'OneDrive Personal',
        );
    }

    /*
     * Certains tenants n'incluent pas children malgré $expand.
     * Après l'appel share ci-dessus, le Badger token est autorisé sur le
     * dossier : on peut donc lire les enfants par driveId + itemId.
     */
    $itemId = trim((string)($share['id'] ?? ''));
    $parent = isset($share['parentReference']) && is_array($share['parentReference'])
        ? $share['parentReference']
        : array();
    $driveId = trim((string)($parent['driveId'] ?? ''));

    if ($itemId === '' || $driveId === '') {
        return array(
            'ok'=>false,
            'error'=>'repo_share_root_invalid',
            'details'=>array('has_item_id'=>$itemId!=='','has_drive_id'=>$driveId!==''),
        );
    }

    $childrenEndpoints = array(
        'https://my.microsoftpersonalcontent.com/_api/v2.0/drives/'
            . rawurlencode($driveId) . '/items/' . rawurlencode($itemId)
            . '/children?%24top=200',
        'https://api.onedrive.com/v1.0/drives/'
            . rawurlencode($driveId) . '/items/' . rawurlencode($itemId)
            . '/children?%24top=200',
    );

    $lastError = null;
    foreach ($childrenEndpoints as $url) {
        $res = dmd_agent_repo_curl_request($url, array(
            'method'=>'GET',
            'timeout'=>35,
            'max_bytes'=>16777216,
            'headers'=>$headers,
        ));

        if (empty($res['ok'])) {
            $lastError = $res;
            continue;
        }

        $data = json_decode((string)$res['body'], true);
        if (!is_array($data)) {
            $lastError = array('error'=>'repo_children_json_invalid','body'=>substr((string)$res['body'],0,1000));
            continue;
        }

        return array(
            'ok'=>true,
            'rows'=>isset($data['value']) && is_array($data['value']) ? $data['value'] : array(),
            'source'=>'OneDrive Personal',
        );
    }

    return array('ok'=>false,'error'=>'repo_children_failed','details'=>$lastError);
}

function dmd_agent_repo_extract_version($name) {
    $base = preg_replace('/\.zip$/i', '', basename((string)$name));
    if (preg_match('/(?<!\d)(\d{1,4}(?:[._-]\d+){1,3})(?!\d)/', $base, $m)) {
        return str_replace(array('_','-'), '.', $m[1]);
    }
    return trim((string)$base);
}

function dmd_agent_repo_version_sort_value($version) {
    $v = trim((string)$version);
    return preg_match('/^\d+(?:\.\d+){1,3}$/', $v) ? $v : '0.0.0';
}

function dmd_agent_repo_catalog() {
    $scan = dmd_agent_repo_onedrive_personal_rows();
    if (empty($scan['ok'])) return $scan;

    $items = array();
    foreach ((array)$scan['rows'] as $row) {
        if (!is_array($row)) continue;

        $name = trim((string)($row['name'] ?? ''));
        if ($name === '' || !preg_match('/\.zip$/i', $name)) continue;

        // Ignore explicit folders even if their name happens to end in .zip.
        if (isset($row['folder']) && is_array($row['folder'])) continue;

        $id = trim((string)($row['id'] ?? ''));
        $size = max(0, (int)($row['size'] ?? 0));
        if ($size <= 0 || $size > DMD_AGENT_REPOSITORY_MAX_ZIP_BYTES) continue;

        $modified = trim((string)($row['lastModifiedDateTime'] ?? ($row['modifiedDateTime'] ?? '')));
        $download = trim((string)(
            $row['@content.downloadUrl']
            ?? $row['@microsoft.graph.downloadUrl']
            ?? ''
        ));

        if ($download === '' || stripos($download, 'https://') !== 0) continue;

        $version = dmd_agent_repo_extract_version($name);
        $key = hash('sha256', $id . "\n" . $name . "\n" . $size . "\n" . $modified);

        $items[] = array(
            'item_key'=>$key,
            'id'=>$id,
            'name'=>$name,
            'version'=>$version,
            'size'=>$size,
            'modified_at'=>$modified,
            'download_url'=>$download,
        );
    }

    usort($items, function($a, $b) {
        $av = dmd_agent_repo_version_sort_value($a['version'] ?? '');
        $bv = dmd_agent_repo_version_sort_value($b['version'] ?? '');
        $cmp = version_compare($bv, $av);
        if ($cmp !== 0) return $cmp;
        return strcmp((string)($b['modified_at'] ?? ''), (string)($a['modified_at'] ?? ''));
    });

    return array(
        'ok'=>true,
        'items'=>$items,
        'source'=>'OneDrive',
        'source_url'=>DMD_AGENT_RELEASE_ONEDRIVE_URL,
    );
}

function dmd_agent_repo_public_catalog() {
    $catalog = dmd_agent_repo_catalog();
    if (empty($catalog['ok'])) return $catalog;
    $items = array();
    foreach ($catalog['items'] as $row) {
        $items[] = array(
            'item_key'=>$row['item_key'],
            'name'=>$row['name'],
            'version'=>$row['version'],
            'size'=>$row['size'],
            'modified_at'=>$row['modified_at'],
        );
    }
    return array('ok'=>true,'items'=>$items,'source'=>$catalog['source'],'local'=>dmd_agent_repo_public_local_status());
}

function dmd_agent_repo_find_item($itemKey) {
    $itemKey = strtolower(trim((string)$itemKey));
    if (!preg_match('/^[a-f0-9]{64}$/', $itemKey)) return array('ok'=>false,'error'=>'item_invalid');
    $catalog = dmd_agent_repo_catalog();
    if (empty($catalog['ok'])) return $catalog;
    foreach ($catalog['items'] as $item) {
        if (hash_equals($itemKey, strtolower((string)$item['item_key']))) return array('ok'=>true,'item'=>$item);
    }
    return array('ok'=>false,'error'=>'item_not_found');
}

function dmd_agent_repo_download_file_once($url, $dest, $progressCallback = null, $extraHeaders = array()) {
    if (stripos((string)$url, 'https://') !== 0) return array('ok'=>false,'error'=>'download_https_required');

    $fh = @fopen($dest, 'wb');
    if (!$fh) return array('ok'=>false,'error'=>'temp_write_failed');

    $written = 0;
    $max = DMD_AGENT_REPOSITORY_MAX_ZIP_BYTES;
    $lastPct = -1;
    $ch = curl_init($url);

    curl_setopt_array($ch, array(
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 8,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_TIMEOUT => 900,
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_USERAGENT => dmd_agent_repo_browser_user_agent(),
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_NOPROGRESS => false,
        CURLOPT_WRITEFUNCTION => function($ch, $chunk) use ($fh, &$written, $max) {
            $len = strlen($chunk);
            if ($written + $len > $max) return 0;
            $n = fwrite($fh, $chunk);
            if ($n === false) return 0;
            $written += $n;
            return $n;
        },
    ));

    if ($extraHeaders) curl_setopt($ch, CURLOPT_HTTPHEADER, $extraHeaders);

    $progress = function($resource, $downloadTotal, $downloaded, $uploadTotal = 0, $uploaded = 0) use ($progressCallback, &$lastPct) {
        if (!$progressCallback) return 0;
        $pct = $downloadTotal > 0 ? (int)floor(($downloaded / $downloadTotal) * 100) : -1;
        if ($pct !== $lastPct && ($pct < 0 || $pct === 100 || $pct % 2 === 0)) {
            $lastPct = $pct;
            call_user_func($progressCallback, $pct, (int)$downloaded, (int)$downloadTotal);
        }
        return 0;
    };

    if (defined('CURLOPT_XFERINFOFUNCTION')) curl_setopt($ch, CURLOPT_XFERINFOFUNCTION, $progress);
    else curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, $progress);

    if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
    if (defined('CURLOPT_REDIR_PROTOCOLS') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);

    $ok = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    fclose($fh);

    if (!$ok || $http < 200 || $http >= 300) {
        @unlink($dest);
        return array('ok'=>false,'error'=>'download_failed','http'=>$http,'details'=>$err);
    }

    if (!is_file($dest) || filesize($dest) < 128) {
        @unlink($dest);
        return array('ok'=>false,'error'=>'download_empty');
    }

    return array(
        'ok'=>true,
        'bytes'=>(int)filesize($dest),
        'sha256'=>hash_file('sha256', $dest),
    );
}

function dmd_agent_repo_download_file($url, $dest, $progressCallback = null) {
    if (!function_exists('curl_init')) return array('ok'=>false,'error'=>'curl_required_for_download');

    $first = dmd_agent_repo_download_file_once($url, $dest, $progressCallback);
    if (!empty($first['ok'])) return $first;

    /*
     * Les nouveaux liens OneDrive Personal pointent souvent vers
     * my.microsoftpersonalcontent.com avec un paramètre tempauth. Certains
     * nœuds Microsoft demandent aussi ce tempauth comme Bearer.
     */
    $parts = @parse_url((string)$url);
    $host = is_array($parts) ? strtolower((string)($parts['host'] ?? '')) : '';
    $query = array();
    if (is_array($parts) && isset($parts['query'])) parse_str((string)$parts['query'], $query);
    $tempAuth = trim((string)($query['tempauth'] ?? ''));

    if ((int)($first['http'] ?? 0) === 401
        && $tempAuth !== ''
        && substr($host, -strlen('microsoftpersonalcontent.com')) === 'microsoftpersonalcontent.com') {
        return dmd_agent_repo_download_file_once(
            $url,
            $dest,
            $progressCallback,
            array('Authorization: Bearer ' . $tempAuth)
        );
    }

    return $first;
}

function dmd_agent_repo_extract_installer($zipFile, $exeDest) {
    if (!class_exists('ZipArchive')) return array('ok'=>false,'error'=>'ziparchive_missing');
    $zip = new ZipArchive();
    $open = $zip->open($zipFile);
    if ($open !== true) return array('ok'=>false,'error'=>'zip_invalid','zip_code'=>$open);

    $candidates = array();
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (!is_array($stat)) continue;
        $name = str_replace('\\', '/', (string)($stat['name'] ?? ''));
        if (strtolower(basename($name)) !== 'dmd-installer.exe') continue;
        $size = max(0, (int)($stat['size'] ?? 0));
        if ($size <= 0 || $size > DMD_AGENT_REPOSITORY_MAX_EXE_BYTES) continue;
        $candidates[] = array('index'=>$i,'name'=>$name,'size'=>$size,'depth'=>substr_count(trim($name, '/'), '/'));
    }
    if (!$candidates) { $zip->close(); return array('ok'=>false,'error'=>'installer_not_found_in_zip'); }
    usort($candidates, function($a,$b){ return ($a['depth'] <=> $b['depth']) ?: strcmp($a['name'],$b['name']); });
    $chosen = $candidates[0];
    $stream = $zip->getStream($chosen['name']);
    if (!$stream) { $zip->close(); return array('ok'=>false,'error'=>'installer_stream_failed'); }
    $out = @fopen($exeDest, 'wb');
    if (!$out) { fclose($stream); $zip->close(); return array('ok'=>false,'error'=>'installer_temp_write_failed'); }
    $written = stream_copy_to_stream($stream, $out, DMD_AGENT_REPOSITORY_MAX_EXE_BYTES + 1);
    fclose($stream); fclose($out); $zip->close();
    if ($written === false || $written <= 0 || $written > DMD_AGENT_REPOSITORY_MAX_EXE_BYTES) { @unlink($exeDest); return array('ok'=>false,'error'=>'installer_extract_failed'); }
    if (!dmd_agent_repo_is_pe_file($exeDest)) { @unlink($exeDest); return array('ok'=>false,'error'=>'installer_pe_invalid'); }
    return array('ok'=>true,'entry'=>$chosen['name'],'bytes'=>(int)$written,'sha256'=>hash_file('sha256',$exeDest));
}

function dmd_agent_repo_publish_installer($sourceExe, $meta = array()) {
    if (!dmd_agent_repo_is_pe_file($sourceExe)) return array('ok'=>false,'error'=>'installer_pe_invalid');
    $target = dmd_agent_repo_installer_path();
    $dir = dirname($target);
    if (!dmd_agent_repo_ensure_dir($dir)) return array('ok'=>false,'error'=>'installer_dir_failed');
    if (!is_writable($dir)) return array('ok'=>false,'error'=>'installer_dir_not_writable','path'=>$dir);

    $new = $dir . '/.DMD-Installer.new-' . bin2hex(random_bytes(6)) . '.exe';
    if (!@copy($sourceExe, $new)) return array('ok'=>false,'error'=>'installer_copy_failed');
    @chmod($new, 0750);
    if (!dmd_agent_repo_is_pe_file($new)) { @unlink($new); return array('ok'=>false,'error'=>'installer_copy_invalid'); }

    $backup = '';
    if (is_file($target)) {
        $backup = $dir . '/.DMD-Installer.previous-' . bin2hex(random_bytes(5)) . '.exe';
        if (!@rename($target, $backup)) { @unlink($new); return array('ok'=>false,'error'=>'installer_backup_failed'); }
    }
    if (!@rename($new, $target)) {
        @unlink($new);
        if ($backup !== '' && is_file($backup)) @rename($backup, $target);
        return array('ok'=>false,'error'=>'installer_publish_failed');
    }
    @chmod($target, 0750);
    if ($backup !== '') @unlink($backup);

    $sha = hash_file('sha256', $target);
    $state = array(
        'schema'=>1,
        'version'=>trim((string)($meta['version'] ?? '')),
        'source_name'=>trim((string)($meta['name'] ?? '')),
        'source_item_key'=>trim((string)($meta['item_key'] ?? '')),
        'sha256'=>$sha,
        'size'=>(int)filesize($target),
        'installed_at'=>gmdate('c'),
        'installed_by'=>trim((string)($meta['installed_by'] ?? '')),
    );
    dmd_agent_repo_write_json_file(dmd_agent_repo_state_file(), $state);
    return array('ok'=>true,'local'=>dmd_agent_repo_public_local_status());
}
