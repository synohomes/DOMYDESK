<?php
if (!defined('DMD_AGENT_VAR')) require_once __DIR__ . '/agent_core.php';
require_once __DIR__ . '/software_packages.php';

function dmd_agent_maint_software_root() {
    $root = DMD_AGENT_VAR . '/instance/private/software_library';
    if (!is_dir($root)) @mkdir($root, 0750, true);
    if (!is_dir($root . '/files')) @mkdir($root . '/files', 0750, true);
    return $root;
}
function dmd_agent_maint_software_index_file() { return dmd_agent_maint_software_root() . '/library.php'; }
function dmd_agent_maint_software_read() {
    $d = dmd_agent_json_read(dmd_agent_maint_software_index_file(), array('schema'=>1,'items'=>array()));
    if (!is_array($d)) $d = array();
    if (!isset($d['items']) || !is_array($d['items'])) $d['items'] = array();
    return $d;
}
function dmd_agent_maint_software_write($d) {
    $d['schema'] = 1;
    $d['updated_at'] = gmdate('c');
    return dmd_agent_json_write(dmd_agent_maint_software_index_file(), $d, 0640);
}
function dmd_agent_maint_software_safe_id($id) {
    $id = strtoupper(trim((string)$id));
    return preg_match('/^LIB-[A-F0-9]{20}$/', $id) ? $id : '';
}
function dmd_agent_maint_software_item($id) {
    $id = dmd_agent_maint_software_safe_id($id);
    if ($id === '') return array();
    $d = dmd_agent_maint_software_read();
    foreach ($d['items'] as $row) if (is_array($row) && (string)($row['id']??'') === $id) return $row;
    return array();
}
function dmd_agent_maint_software_name($name, $fallback='Logiciel') {
    $name = trim((string)$name);
    if ($name === '') $name = $fallback;
    $name = preg_replace('/[\x00-\x1F\x7F]/u','',$name);
    return substr($name,0,120);
}
function dmd_agent_maint_software_add_winget($name,$wingetId,$actor='') {
    $name = dmd_agent_maint_software_name($name,'Winget');
    $wingetId = trim((string)$wingetId);
    if (!preg_match('/^[A-Za-z0-9._+-]{2,180}$/',$wingetId)) return array('ok'=>false,'error'=>'winget_id_invalid');
    try { $id='LIB-'.strtoupper(bin2hex(random_bytes(10))); } catch(Exception $e) { return array('ok'=>false,'error'=>'random_failed'); }
    $row=array('id'=>$id,'name'=>$name,'source'=>'winget','winget_id'=>$wingetId,'created_at'=>gmdate('c'),'created_by'=>(string)$actor);
    $d=dmd_agent_maint_software_read();$d['items'][]=$row;
    if(!dmd_agent_maint_software_write($d)) return array('ok'=>false,'error'=>'library_write_failed');
    return array('ok'=>true,'item'=>$row);
}
function dmd_agent_maint_software_add_file($upload,$name,$arguments,$actor='') {
    if (!is_array($upload) || !isset($upload['error']) || (int)$upload['error'] !== UPLOAD_ERR_OK) return array('ok'=>false,'error'=>'upload_invalid');
    $tmp=(string)($upload['tmp_name']??'');$orig=basename(str_replace('\\','/',(string)($upload['name']??'')));$size=(int)($upload['size']??0);
    if($tmp===''||!is_uploaded_file($tmp)) return array('ok'=>false,'error'=>'upload_invalid');
    if($size<=0||$size>512*1024*1024) return array('ok'=>false,'error'=>'package_size_invalid');
    $ext=strtolower(pathinfo($orig,PATHINFO_EXTENSION));
    if(!in_array($ext,array('exe','msi'),true)) return array('ok'=>false,'error'=>'package_extension_refused');
    if(!dmd_agent_software_package_signature_ok($tmp,$ext)) return array('ok'=>false,'error'=>'package_signature_invalid');
    $sha=strtolower((string)@hash_file('sha256',$tmp));
    if(!preg_match('/^[a-f0-9]{64}$/',$sha)) return array('ok'=>false,'error'=>'package_hash_failed');
    $arguments=trim((string)$arguments);
    if(strlen($arguments)>4096||preg_match('/[\x00\r\n]/',$arguments)) return array('ok'=>false,'error'=>'installer_arguments_invalid');
    try{$id='LIB-'.strtoupper(bin2hex(random_bytes(10)));}catch(Exception $e){return array('ok'=>false,'error'=>'random_failed');}
    $dest=dmd_agent_maint_software_root().'/files/'.$id.'.'.$ext;
    if(!@move_uploaded_file($tmp,$dest)) return array('ok'=>false,'error'=>'package_store_failed');
    @chmod($dest,0640);
    $display=dmd_agent_maint_software_name($name,pathinfo($orig,PATHINFO_FILENAME));
    $row=array('id'=>$id,'name'=>$display,'source'=>'file','file_name'=>$orig,'extension'=>$ext,'size'=>$size,'sha256'=>$sha,'arguments'=>$arguments,'created_at'=>gmdate('c'),'created_by'=>(string)$actor);
    $d=dmd_agent_maint_software_read();$d['items'][]=$row;
    if(!dmd_agent_maint_software_write($d)){@unlink($dest);return array('ok'=>false,'error'=>'library_write_failed');}
    return array('ok'=>true,'item'=>$row);
}
function dmd_agent_maint_software_delete($id) {
    $id=dmd_agent_maint_software_safe_id($id);if($id==='')return array('ok'=>false,'error'=>'item_invalid');
    $d=dmd_agent_maint_software_read();$found=false;$next=array();
    foreach($d['items'] as $row){
        if(is_array($row)&&(string)($row['id']??'')===$id){
            $found=true;
            if(($row['source']??'')==='file'){
                $ext=strtolower((string)($row['extension']??''));
                $file=dmd_agent_maint_software_root().'/files/'.$id.'.'.$ext;
                if(is_file($file))@unlink($file);
            }
            continue;
        }
        $next[]=$row;
    }
    if(!$found)return array('ok'=>false,'error'=>'item_not_found');
    $d['items']=$next;if(!dmd_agent_maint_software_write($d))return array('ok'=>false,'error'=>'library_write_failed');
    return array('ok'=>true);
}
function dmd_agent_maint_software_transient_package($item,$actor='') {
    if(!is_array($item)||($item['source']??'')!=='file')return array('ok'=>false,'error'=>'item_not_file');
    $id=(string)($item['id']??'');$ext=strtolower((string)($item['extension']??''));
    $src=dmd_agent_maint_software_root().'/files/'.$id.'.'.$ext;
    if(!is_file($src))return array('ok'=>false,'error'=>'library_file_missing');
    try{$pkgId='PKG-'.strtoupper(bin2hex(random_bytes(12)));$token=bin2hex(random_bytes(32));}catch(Exception $e){return array('ok'=>false,'error'=>'random_failed');}
    $blob=dmd_agent_software_package_blob_file($pkgId);$metaFile=dmd_agent_software_package_meta_file($pkgId);
    if($blob===''||$metaFile==='')return array('ok'=>false,'error'=>'package_path_failed');
    if(!@copy($src,$blob))return array('ok'=>false,'error'=>'package_copy_failed');@chmod($blob,0640);
    $now=time();
    $meta=array('schema'=>1,'package_id'=>$pkgId,'file_name'=>(string)$item['file_name'],'extension'=>$ext,'size'=>(int)$item['size'],'sha256'=>(string)$item['sha256'],'token_hash'=>hash('sha256',$token),'created_at'=>gmdate('c',$now),'created_ts'=>$now,'expires_at'=>gmdate('c',$now+3600),'expires_ts'=>$now+3600,'downloads'=>0,'max_downloads'=>2,'actor'=>(string)$actor);
    if(!dmd_agent_json_write($metaFile,$meta,0640)){@unlink($blob);return array('ok'=>false,'error'=>'package_meta_failed');}
    return array('ok'=>true,'package'=>$meta,'token'=>$token);
}
function dmd_agent_maint_winget_ps($wingetId,$verb='install') {
    $wingetId=trim((string)$wingetId);
    if(!preg_match('/^[A-Za-z0-9._+-]{2,180}$/',$wingetId)) return '';
    $verb=$verb==='uninstall'?'uninstall':'install';
    $args=$verb==='install'
        ? "install --id '$wingetId' --exact --silent --accept-package-agreements --accept-source-agreements --disable-interactivity"
        : "uninstall --id '$wingetId' --exact --silent --disable-interactivity --accept-source-agreements";
    return '$w=(Get-Command winget.exe -ErrorAction SilentlyContinue);'
        .'if(-not $w){$w=Get-ChildItem "$env:ProgramFiles\WindowsApps\Microsoft.DesktopAppInstaller_*_x64__8wekyb3d8bbwe\winget.exe" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1};'
        .'if(-not $w){throw "winget introuvable"};'
        .'$p=if($w.Source){$w.Source}else{$w.FullName};'
        .'& $p '.$args.';exit $LASTEXITCODE';
}
