<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$baseDir = dirname(__DIR__, 3);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_security.php';
require_once __DIR__ . '/agent_core.php';

$email = isset($_SESSION['user']['email']) ? dmd_sys_safe_email($_SESSION['user']['email']) : '';
$profile = $email !== '' ? dmd_sys_profile($email) : array();
$role = (string)(isset($profile['role_system']) ? $profile['role_system'] : '');
if ($email === '' || $role !== 'superadmin') {
    http_response_code(403);
    echo '<!doctype html><html lang="fr"><meta charset="utf-8"><body><p>Accès réservé au Superadmin.</p></body></html>';
    exit;
}
$csrfAgent = dmd_csrf_token('agent_admin');
