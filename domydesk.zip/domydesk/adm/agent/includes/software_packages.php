<?php
if (!defined('DMD_AGENT_VAR')) require_once __DIR__ . '/agent_core.php';

function dmd_agent_software_package_root() {
    $root = DMD_AGENT_VAR . '/instance/private/software_packages';
    if (!is_dir($root)) @mkdir($root, 0750, true);
    return $root;
}
function dmd_agent_software_package_safe_id($id) {
    $id = strtoupper(trim((string)$id));
    return preg_match('/^PKG-[A-F0-9]{24}$/', $id) ? $id : '';
}
function dmd_agent_software_package_meta_file($id) {
    $id = dmd_agent_software_package_safe_id($id);
    return $id === '' ? '' : dmd_agent_software_package_root() . '/' . $id . '.php';
}
function dmd_agent_software_package_blob_file($id) {
    $id = dmd_agent_software_package_safe_id($id);
    return $id === '' ? '' : dmd_agent_software_package_root() . '/' . $id . '.dat';
}
function dmd_agent_software_package_cleanup() {
    $now = time();
    foreach (glob(dmd_agent_software_package_root() . '/PKG-*.php') ?: array() as $metaFile) {
        $row = dmd_agent_json_read($metaFile, array());
        $expires = (int)($row['expires_ts'] ?? 0);
        if (!$row || $expires <= 0 || $expires < ($now - 3600)) {
            $id = strtoupper(pathinfo($metaFile, PATHINFO_FILENAME));
            $blob = dmd_agent_software_package_blob_file($id);
            if ($blob !== '' && is_file($blob)) @unlink($blob);
            @unlink($metaFile);
        }
    }
}
function dmd_agent_software_package_signature_ok($file, $ext) {
    $fh = @fopen($file, 'rb');
    if (!$fh) return false;
    $head = (string)@fread($fh, 8);
    @fclose($fh);
    if ($ext === 'exe') return strlen($head) >= 2 && substr($head, 0, 2) === "MZ";
    if ($ext === 'msi') return strlen($head) >= 8 && bin2hex(substr($head, 0, 8)) === 'd0cf11e0a1b11ae1';
    return false;
}
function dmd_agent_software_package_create_upload($upload, $actor = '') {
    dmd_agent_software_package_cleanup();
    if (!is_array($upload) || !isset($upload['error'])) return array('ok'=>false,'error'=>'upload_missing');
    $err = (int)$upload['error'];
    if ($err !== UPLOAD_ERR_OK) {
        $map = array(
            UPLOAD_ERR_INI_SIZE=>'upload_too_large_php', UPLOAD_ERR_FORM_SIZE=>'upload_too_large_form',
            UPLOAD_ERR_PARTIAL=>'upload_partial', UPLOAD_ERR_NO_FILE=>'upload_missing',
            UPLOAD_ERR_NO_TMP_DIR=>'upload_tmp_missing', UPLOAD_ERR_CANT_WRITE=>'upload_write_failed',
            UPLOAD_ERR_EXTENSION=>'upload_blocked_extension'
        );
        return array('ok'=>false,'error'=>$map[$err] ?? ('upload_error_'.$err));
    }
    $tmp = (string)($upload['tmp_name'] ?? '');
    $name = trim((string)($upload['name'] ?? ''));
    $size = (int)($upload['size'] ?? 0);
    if ($tmp === '' || !is_uploaded_file($tmp)) return array('ok'=>false,'error'=>'upload_invalid');
    if ($size <= 0 || $size > (512 * 1024 * 1024)) return array('ok'=>false,'error'=>'package_size_invalid');
    $base = basename(str_replace('\\','/',$name));
    if ($base === '' || strlen($base) > 240) return array('ok'=>false,'error'=>'package_name_invalid');
    $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    if (!in_array($ext, array('exe','msi'), true)) return array('ok'=>false,'error'=>'package_extension_refused');
    if (!dmd_agent_software_package_signature_ok($tmp, $ext)) return array('ok'=>false,'error'=>'package_signature_invalid');
    $sha = strtolower((string)@hash_file('sha256', $tmp));
    if (!preg_match('/^[a-f0-9]{64}$/', $sha)) return array('ok'=>false,'error'=>'package_hash_failed');
    try {
        $id = 'PKG-' . strtoupper(bin2hex(random_bytes(12)));
        $token = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        return array('ok'=>false,'error'=>'package_random_failed');
    }
    $blob = dmd_agent_software_package_blob_file($id);
    $metaFile = dmd_agent_software_package_meta_file($id);
    if ($blob === '' || $metaFile === '') return array('ok'=>false,'error'=>'package_path_failed');
    if (!@move_uploaded_file($tmp, $blob)) return array('ok'=>false,'error'=>'package_store_failed');
    @chmod($blob, 0640);
    $now = time();
    $meta = array(
        'schema'=>1, 'package_id'=>$id, 'file_name'=>$base, 'extension'=>$ext,
        'size'=>$size, 'sha256'=>$sha, 'token_hash'=>hash('sha256',$token),
        'created_at'=>gmdate('c',$now), 'created_ts'=>$now, 'expires_at'=>gmdate('c',$now+1800),
        'expires_ts'=>$now+1800, 'downloads'=>0, 'max_downloads'=>5, 'actor'=>(string)$actor,
    );
    if (!dmd_agent_json_write($metaFile, $meta, 0640)) {
        @unlink($blob);
        return array('ok'=>false,'error'=>'package_meta_failed');
    }
    return array('ok'=>true,'package'=>$meta,'token'=>$token);
}
function dmd_agent_software_package_validate($id, $token, $touch = false) {
    dmd_agent_software_package_cleanup();
    $id = dmd_agent_software_package_safe_id($id);
    $token = trim((string)$token);
    if ($id === '' || !preg_match('/^[A-Fa-f0-9]{64}$/', $token)) return array('ok'=>false,'error'=>'package_token_invalid');
    $metaFile = dmd_agent_software_package_meta_file($id);
    $blob = dmd_agent_software_package_blob_file($id);
    $meta = dmd_agent_json_read($metaFile, array());
    if (!$meta || !is_file($blob)) return array('ok'=>false,'error'=>'package_not_found');
    if ((int)($meta['expires_ts'] ?? 0) < time()) return array('ok'=>false,'error'=>'package_expired');
    $expected = (string)($meta['token_hash'] ?? '');
    $got = hash('sha256',$token);
    if ($expected === '' || !hash_equals($expected,$got)) return array('ok'=>false,'error'=>'package_token_invalid');
    $downloads = (int)($meta['downloads'] ?? 0); $max = max(1,(int)($meta['max_downloads'] ?? 5));
    if ($downloads >= $max) return array('ok'=>false,'error'=>'package_download_limit');
    if ($touch) {
        $meta['downloads'] = $downloads + 1;
        $meta['last_download_at'] = gmdate('c');
        if (!dmd_agent_json_write($metaFile,$meta,0640)) return array('ok'=>false,'error'=>'package_meta_update_failed');
    }
    $meta['_blob'] = $blob;
    return array('ok'=>true,'package'=>$meta);
}
