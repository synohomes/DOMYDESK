<?php
/**
 * DoMyDesk - DMD-Agent secure enrollment core (protocol v1, mono-instance).
 * PHP 7.3+ / ext-sodium required for the secure Agent identity.
 *
 * IMPORTANT: this subsystem is intentionally independent from DoMyCo/VPS heartbeat.
 */

if (!defined('DMD_AGENT_ROOT')) {
    define('DMD_AGENT_ROOT', dirname(__DIR__, 3));
}
if (!defined('DMD_AGENT_VAR')) {
    define('DMD_AGENT_VAR', DMD_AGENT_ROOT . '/var/agent');
}
if (!defined('DMD_AGENT_PROTOCOL')) {
    define('DMD_AGENT_PROTOCOL', 1);
}

$__dmdLicenseCore = DMD_AGENT_ROOT . '/core/dmd_license.php';
if (is_file($__dmdLicenseCore)) require_once $__dmdLicenseCore;
unset($__dmdLicenseCore);

function dmd_agent_private_htaccess() {
    return "Options -Indexes\n"
        . "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
        . "<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n";
}

function dmd_agent_storage_layout() {
    return array(
        DMD_AGENT_VAR,
        DMD_AGENT_VAR . '/instance',
        DMD_AGENT_VAR . '/instance/private',
        DMD_AGENT_VAR . '/enrollments',
        DMD_AGENT_VAR . '/install-links',
        DMD_AGENT_VAR . '/devices',
        DMD_AGENT_VAR . '/packages',
        DMD_AGENT_VAR . '/commands',
        DMD_AGENT_VAR . '/updates',
        DMD_AGENT_VAR . '/logs',
        DMD_AGENT_VAR . '/security',
        DMD_AGENT_VAR . '/access',
        DMD_AGENT_VAR . '/audits',
        DMD_AGENT_VAR . '/remote',
        DMD_AGENT_VAR . '/remote-control',
        DMD_AGENT_VAR . '/mydesk',
        DMD_AGENT_VAR . '/mydesk/tokens',
        DMD_AGENT_VAR . '/mydesk/notifications',
        DMD_AGENT_VAR . '/mydesk/sessions',
    );
}

function dmd_agent_atomic_write($file, $contents, $mode = 0640) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $tmp = dirname($file) . '/.' . basename($file) . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(8)) . '.php';
    if (@file_put_contents($tmp, $contents, LOCK_EX) === false) return false;
    @chmod($tmp, $mode);
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    @chmod($file, $mode);
    return true;
}

function dmd_agent_data_guard() {
    return "<?php http_response_code(404); header('Cache-Control: no-store'); exit; ?>\n";
}
function dmd_agent_strip_guard($raw) {
    $guard = dmd_agent_data_guard();
    if (strncmp((string)$raw, $guard, strlen($guard)) === 0) return substr((string)$raw, strlen($guard));
    return (string)$raw;
}
function dmd_agent_json_read($file, $fallback = array()) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $fallback;
    $raw = dmd_agent_strip_guard($raw);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_agent_json_write($file, $data, $mode = 0640) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    return dmd_agent_atomic_write($file, dmd_agent_data_guard() . $json . "\n", $mode);
}
function dmd_agent_secret_write($file, $raw, $mode = 0600) {
    return dmd_agent_atomic_write($file, dmd_agent_data_guard() . base64_encode($raw) . "\n", $mode);
}
function dmd_agent_secret_read($file) {
    if (!is_file($file)) return '';
    $raw = @file_get_contents($file);
    if ($raw === false) return '';
    $encoded = trim(dmd_agent_strip_guard($raw));
    $bin = base64_decode($encoded, true);
    return is_string($bin) ? $bin : '';
}

function dmd_agent_log($event, $status, $details = array()) {
    $ts = time();
    $entry = array(
        'timestamp' => $ts,
        'date_iso' => gmdate('c', $ts),
        'event' => (string)$event,
        'status' => (string)$status,
        'ip' => isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '',
        'details' => is_array($details) ? $details : array('message' => (string)$details),
    );
    $file = DMD_AGENT_VAR . '/logs/security-' . gmdate('Y-m') . '.php';
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    if (!is_file($file)) @file_put_contents($file, dmd_agent_data_guard(), LOCK_EX);
    @file_put_contents($file, json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
    @chmod($file, 0640);
}

function dmd_agent_b64url_encode($raw) {
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}
function dmd_agent_b64url_decode($text) {
    $text = strtr((string)$text, '-_', '+/');
    $pad = strlen($text) % 4;
    if ($pad) $text .= str_repeat('=', 4 - $pad);
    return base64_decode($text, true);
}
function dmd_agent_fingerprint($raw) {
    return strtoupper(implode(':', str_split(hash('sha256', $raw), 2)));
}
function dmd_agent_short_id($prefix, $bytes = 12) {
    return $prefix . '-' . strtoupper(bin2hex(random_bytes($bytes)));
}

function dmd_agent_init_storage() {
    $errors = array();
    foreach (dmd_agent_storage_layout() as $dir) {
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            $errors[] = 'mkdir:' . $dir;
            continue;
        }
        @chmod($dir, 0750);
    }
    $ht = dmd_agent_private_htaccess();
    foreach (array(DMD_AGENT_VAR, DMD_AGENT_VAR . '/instance/private') as $dir) {
        $file = $dir . '/.htaccess';
        if (!is_file($file) || @file_get_contents($file) !== $ht) {
            if (!dmd_agent_atomic_write($file, $ht, 0640)) $errors[] = 'htaccess:' . $file;
        }
    }
    $marker = DMD_AGENT_VAR . '/README-PRIVATE.txt';
    if (!is_file($marker)) {
        dmd_agent_atomic_write($marker, "PRIVATE DMD-AGENT DATA - HTTP ACCESS MUST BE DENIED.\nDo not move private keys to a public/download folder.\n", 0640);
    }
    return $errors;
}

function dmd_agent_legacy_instance_id() {
    $file = DMD_AGENT_ROOT . '/data/id_domydesk.txt';
    if (!is_file($file)) return '';
    return trim((string)@file_get_contents($file));
}

function dmd_agent_crypto_available() {
    return function_exists('sodium_crypto_sign_keypair')
        && function_exists('sodium_crypto_sign_detached')
        && function_exists('sodium_crypto_sign_verify_detached');
}

function dmd_agent_instance_paths() {
    return array(
        'manifest' => DMD_AGENT_VAR . '/instance/instance.php',
        'signature' => DMD_AGENT_VAR . '/instance/instance_signature.php',
        'public' => DMD_AGENT_VAR . '/instance/public_key.php',
        'private' => DMD_AGENT_VAR . '/instance/private/private_key.php',
        'pepper' => DMD_AGENT_VAR . '/instance/private/enrollment_pepper.php',
    );
}

function dmd_agent_manifest_canonical($manifest) {
    $ordered = array(
        'schema' => (int)$manifest['schema'],
        'protocol_version' => (int)$manifest['protocol_version'],
        'instance_id' => (string)$manifest['instance_id'],
        'identity_algorithm' => (string)$manifest['identity_algorithm'],
        'public_key_fingerprint' => (string)$manifest['public_key_fingerprint'],
        'legacy_id_sha256' => (string)$manifest['legacy_id_sha256'],
        'created_at' => (string)$manifest['created_at'],
    );
    return json_encode($ordered, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

function dmd_agent_ensure_instance_identity() {
    $storageErrors = dmd_agent_init_storage();
    if ($storageErrors) return array('ok' => false, 'state' => 'storage_error', 'errors' => $storageErrors);
    if (!dmd_agent_crypto_available()) {
        return array('ok' => false, 'state' => 'crypto_unavailable', 'message' => 'Extension PHP Sodium absente. L’identité Agent ne sera pas créée en mode dégradé.');
    }
    $legacy = dmd_agent_legacy_instance_id();
    if ($legacy === '') return array('ok' => false, 'state' => 'missing_instance_id', 'message' => 'data/id_domydesk.txt est absent ou vide.');

    $p = dmd_agent_instance_paths();
    $exists = array();
    foreach ($p as $k => $file) $exists[$k] = is_file($file);
    $count = count(array_filter($exists));

    if ($count === 0) {
        $kp = sodium_crypto_sign_keypair();
        $secret = sodium_crypto_sign_secretkey($kp);
        $public = sodium_crypto_sign_publickey($kp);
        $manifest = array(
            'schema' => 1,
            'protocol_version' => DMD_AGENT_PROTOCOL,
            'instance_id' => $legacy,
            'identity_algorithm' => 'Ed25519',
            'public_key_fingerprint' => dmd_agent_fingerprint($public),
            'legacy_id_sha256' => hash('sha256', $legacy),
            'created_at' => gmdate('c'),
        );
        $canonical = dmd_agent_manifest_canonical($manifest);
        $sig = sodium_crypto_sign_detached($canonical, $secret);
        $ok = dmd_agent_secret_write($p['private'], $secret, 0600)
            && dmd_agent_secret_write($p['public'], $public, 0640)
            && dmd_agent_json_write($p['manifest'], $manifest, 0640)
            && dmd_agent_secret_write($p['signature'], $sig, 0640)
            && dmd_agent_secret_write($p['pepper'], random_bytes(32), 0600);
        if (!$ok) return array('ok' => false, 'state' => 'identity_write_failed', 'message' => 'Impossible d’écrire tous les fichiers d’identité.');
        dmd_agent_log('instance_identity_created', 'success', array('instance_id' => $legacy, 'fingerprint' => $manifest['public_key_fingerprint']));
    } elseif ($count !== count($p)) {
        dmd_agent_log('instance_identity_partial', 'critical', array('files' => $exists));
        return array('ok' => false, 'state' => 'identity_partial', 'message' => 'Identité partielle détectée. Régénération automatique interdite.', 'files' => $exists);
    }
    return dmd_agent_verify_instance_identity();
}

function dmd_agent_load_secret_key() { $p = dmd_agent_instance_paths(); return dmd_agent_secret_read($p['private']); }
function dmd_agent_load_public_key() { $p = dmd_agent_instance_paths(); return dmd_agent_secret_read($p['public']); }
function dmd_agent_load_pepper() { $p = dmd_agent_instance_paths(); return dmd_agent_secret_read($p['pepper']); }

function dmd_agent_verify_instance_identity() {
    if (!dmd_agent_crypto_available()) return array('ok' => false, 'state' => 'crypto_unavailable');
    $p = dmd_agent_instance_paths();
    foreach ($p as $file) if (!is_file($file)) return array('ok' => false, 'state' => 'identity_missing_file');
    $manifest = dmd_agent_json_read($p['manifest'], array());
    $required = array('schema','protocol_version','instance_id','identity_algorithm','public_key_fingerprint','legacy_id_sha256','created_at');
    foreach ($required as $key) if (!array_key_exists($key, $manifest)) return array('ok' => false, 'state' => 'manifest_invalid', 'message' => 'Champ identité manquant: ' . $key);
    $public = dmd_agent_load_public_key();
    $secret = dmd_agent_load_secret_key();
    $sig = dmd_agent_secret_read($p['signature']);
    if ($public === '' || $secret === '' || $sig === '') return array('ok' => false, 'state' => 'key_decode_failed');
    if (strlen($public) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || strlen($secret) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) return array('ok' => false, 'state' => 'key_length_invalid');
    $derivedPublic = sodium_crypto_sign_publickey_from_secretkey($secret);
    if (!hash_equals($public, $derivedPublic)) {
        dmd_agent_log('instance_private_public_mismatch', 'critical');
        return array('ok' => false, 'state' => 'key_pair_mismatch', 'message' => 'Clé privée et clé publique ne correspondent plus.');
    }
    $canonical = dmd_agent_manifest_canonical($manifest);
    if (!sodium_crypto_sign_verify_detached($sig, $canonical, $public)) {
        dmd_agent_log('instance_signature_invalid', 'critical');
        return array('ok' => false, 'state' => 'signature_invalid', 'message' => 'Signature de l’identité DoMyDesk invalide.');
    }
    if (!hash_equals((string)$manifest['public_key_fingerprint'], dmd_agent_fingerprint($public))) {
        dmd_agent_log('instance_fingerprint_mismatch', 'critical');
        return array('ok' => false, 'state' => 'fingerprint_mismatch');
    }
    $legacy = dmd_agent_legacy_instance_id();
    if ($legacy === '' || !hash_equals((string)$manifest['instance_id'], $legacy) || !hash_equals((string)$manifest['legacy_id_sha256'], hash('sha256', $legacy))) {
        dmd_agent_log('legacy_instance_id_tamper', 'critical', array('sealed_id' => (string)$manifest['instance_id'], 'current_sha256' => hash('sha256', $legacy)));
        return array('ok' => false, 'state' => 'instance_id_tampered', 'message' => 'data/id_domydesk.txt ne correspond plus à l’identité scellée.');
    }
    return array('ok' => true, 'state' => 'valid', 'manifest' => $manifest, 'public_key' => base64_encode($public));
}

function dmd_agent_sign_payload($data) {
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return false;
    $secret = dmd_agent_load_secret_key();
    $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return base64_encode(sodium_crypto_sign_detached($json, $secret));
}

function dmd_agent_token_hash($token) {
    $pepper = dmd_agent_load_pepper();
    if ($pepper === '') return '';
    return hash_hmac('sha256', (string)$token, $pepper);
}
function dmd_agent_verify_token($enrollment, $token) {
    if (empty($enrollment['token_hash']) || !is_string($enrollment['token_hash'])) return false;
    $actual = dmd_agent_token_hash((string)$token);
    return $actual !== '' && hash_equals((string)$enrollment['token_hash'], $actual);
}

function dmd_agent_safe_enrollment_id($id) {
    $id = strtoupper(trim((string)$id));
    return preg_match('/^ENR-[A-F0-9]{24}$/', $id) ? $id : '';
}
function dmd_agent_safe_agent_id($id) {
    $id = strtoupper(trim((string)$id));
    return preg_match('/^AGT-[A-F0-9]{32}$/', $id) ? $id : '';
}
function dmd_agent_enrollment_file($id) {
    $id = dmd_agent_safe_enrollment_id($id);
    return $id === '' ? '' : DMD_AGENT_VAR . '/enrollments/' . $id . '.php';
}
function dmd_agent_device_file($id) {
    $id = dmd_agent_safe_agent_id($id);
    return $id === '' ? '' : DMD_AGENT_VAR . '/devices/' . $id . '.php';
}

function dmd_agent_default_capabilities() {
    // Tous les composants Agent sont inclus de série. DMD-MyDesk reste le seul
    // composant optionnel lors d'un nouvel enrôlement.
    return dmd_agent_standard_capabilities();
}
function dmd_agent_known_capabilities() {
    return array(
        'core.heartbeat','core.commands','core.update','inventory.basic',
        'filesystem.roots','filesystem.list','filesystem.read','filesystem.write','filesystem.mkdir',
        'remote.screen','remote.control','remote.clipboard','remote.files',
        'software.list','software.uninstall','software.update','system.processes','system.services','system.terminal','system.power','system.update',
        'system.registry.read','system.registry.write','system.removable','system.networkpaths',
        'mydesk.client'
    );
}
function dmd_agent_standard_capabilities() {
    return array_values(array_filter(dmd_agent_known_capabilities(), function($cap) {
        return $cap !== 'mydesk.client';
    }));
}

function dmd_agent_core_only_capabilities() {
    return array_values(array_filter(dmd_agent_known_capabilities(), function($cap) {
        return strpos((string)$cap, 'remote.') !== 0 && (string)$cap !== 'mydesk.client';
    }));
}
function dmd_agent_capabilities_for_components($includeRemote, $includeMyDesk) {
    $caps = dmd_agent_core_only_capabilities();
    if (!empty($includeRemote)) {
        foreach (dmd_agent_known_capabilities() as $cap) {
            if (strpos((string)$cap, 'remote.') === 0 && !in_array($cap, $caps, true)) $caps[] = $cap;
        }
    }
    if (!empty($includeMyDesk) && !in_array('mydesk.client', $caps, true)) $caps[] = 'mydesk.client';
    return array_values($caps);
}
function dmd_agent_install_components_from_capabilities($caps) {
    $remote = false;
    $mydesk = false;
    foreach ((array)$caps as $cap) {
        $cap = trim((string)$cap);
        if (strpos($cap, 'remote.') === 0) $remote = true;
        if ($cap === 'mydesk.client') $mydesk = true;
    }
    return array('agent'=>true, 'remote'=>$remote, 'mydesk'=>$mydesk);
}
function dmd_agent_normalize_capabilities($items) {
    if (!is_array($items)) $items = array();
    $known = dmd_agent_known_capabilities();
    $out = array();
    foreach ($items as $item) {
        $item = trim((string)$item);
        if (in_array($item, $known, true) && !in_array($item, $out, true)) $out[] = $item;
    }
    foreach (dmd_agent_default_capabilities() as $required) if (!in_array($required, $out, true)) $out[] = $required;
    return $out;
}

function dmd_agent_caps_use_remote($caps) {
    foreach ((array)$caps as $cap) if (strpos((string)$cap, 'remote.') === 0) return true;
    return false;
}
function dmd_agent_remote_license_limit() {
    if (!function_exists('dmd_license_quota')) return -1;
    return (int)dmd_license_quota('dmd_agent','remote_targets_max',0);
}
/**
 * Détermine si un PC actif consomme réellement une place DMD-Remote.
 *
 * La source de vérité est le choix signé de l'enrôlement
 * (install_components.remote). Les capabilities remontées par le client ne
 * doivent jamais, à elles seules, créer une consommation de licence.
 */
function dmd_agent_remote_device_uses_slot($device) {
    if (!is_array($device) || (string)($device['status'] ?? 'active') !== 'active') return false;

    $enrollmentId = dmd_agent_safe_enrollment_id($device['enrollment_id'] ?? '');
    if ($enrollmentId !== '') {
        $e = dmd_agent_load_enrollment($enrollmentId);
        if (is_array($e) && $e) {
            if (isset($e['install_components']) && is_array($e['install_components']) && array_key_exists('remote', $e['install_components'])) {
                return !empty($e['install_components']['remote']);
            }
            if (array_key_exists('include_remote', $e)) return !empty($e['include_remote']);
            if (isset($e['capabilities']) && is_array($e['capabilities'])) return dmd_agent_caps_use_remote($e['capabilities']);
        }
    }

    // Compatibilité pour les anciens PC dont le fichier d'enrôlement n'existe plus :
    // seules les capabilities AUTORISÉES côté serveur sont prises en compte.
    // reported_capabilities est volontairement ignoré ici.
    $caps = isset($device['capabilities']) && is_array($device['capabilities']) ? $device['capabilities'] : array();
    return dmd_agent_caps_use_remote($caps);
}

/** Nombre de PC actifs sur lesquels DMD-Remote est réellement autorisé/installé. */
function dmd_agent_remote_active_usage() {
    $used = 0;
    foreach (dmd_agent_list_devices() as $d) {
        if (dmd_agent_remote_device_uses_slot($d)) $used++;
    }
    return $used;
}

/**
 * Réservations Remote encore en cours d'enrôlement.
 * Elles bloquent une place pour éviter de générer plus de packages Remote que
 * le quota, mais elles ne doivent PAS être affichées comme des PC Remote actifs.
 */
function dmd_agent_remote_pending_reservations() {
    $reserved = 0;
    foreach (dmd_agent_list_enrollments() as $e) {
        if (!is_array($e) || !$e) continue;
        $st = (string)($e['status'] ?? '');
        // approved possède déjà un device : il est compté dans active_usage.
        if (!in_array($st, array('created','challenge','pending_approval'), true)) continue;
        if (function_exists('dmd_agent_enrollment_expired') && dmd_agent_enrollment_expired($e)) continue;

        $remote = null;
        if (isset($e['install_components']) && is_array($e['install_components']) && array_key_exists('remote', $e['install_components'])) {
            $remote = !empty($e['install_components']['remote']);
        } elseif (array_key_exists('include_remote', $e)) {
            $remote = !empty($e['include_remote']);
        } else {
            $remote = dmd_agent_caps_use_remote($e['capabilities'] ?? array());
        }
        if ($remote) $reserved++;
    }
    return $reserved;
}

/**
 * Quota engagé = Remote réellement actifs + packages Remote encore réservés.
 * Cette valeur sert à l'enforcement de licence, pas à l'affichage "Remote actifs".
 */
function dmd_agent_remote_license_usage() {
    return dmd_agent_remote_active_usage() + dmd_agent_remote_pending_reservations();
}
function dmd_agent_remote_license_compliant() {
    $limit = dmd_agent_remote_license_limit();
    $used = dmd_agent_remote_license_usage();
    return array('ok'=>$limit<0 || $used<=$limit,'used'=>$used,'allowed'=>$limit);
}
function dmd_agent_mydesk_selected_count($settings = null) {
    if (!is_array($settings)) $settings=dmd_agent_mydesk_settings_read();
    $count=0;
    foreach (dmd_agent_mydesk_manifest_modules() as $module) if (dmd_agent_mydesk_module_enabled($module,$settings)) $count++;
    return $count;
}

function dmd_agent_sha256_hex($raw) { return hash('sha256', (string)$raw); }
function dmd_agent_caps_hash($caps) {
    $caps = is_array($caps) ? array_values($caps) : array();
    sort($caps, SORT_STRING);
    return hash('sha256', implode("\n", $caps));
}
/**
 * Chemin Web de l'instance DoMyDesk courante.
 * Exemple : /domydesk lorsque l'API courante est sous
 * /domydesk/adm/agent/api/...
 */
function dmd_agent_current_web_base_path() {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));

    foreach (array('/adm/agent/', '/adm/') as $marker) {
        $pos = strpos($script, $marker);
        if ($pos !== false) {
            $base = rtrim(substr($script, 0, $pos), '/');
            return $base === '/' ? '' : $base;
        }
    }

    return '';
}

/**
 * Vérifie qu'une URL de base pointe réellement vers l'API Agent de DoMyDesk.
 * enroll_start.php refuse volontairement GET avec :
 *   HTTP 405 + {"ok":false,"code":"method_not_allowed"}
 *
 * Aucun redirect n'est suivi et le timeout est volontairement court.
 */
function dmd_agent_probe_server_base_url($baseUrl) {
    $probeUrl = rtrim((string)$baseUrl, '/') . '/adm/agent/api/enroll_start.php';
    $body = '';
    $status = 0;
    $contentType = '';

    if (function_exists('curl_init')) {
        $ch = @curl_init($probeUrl);
        if ($ch !== false) {
            @curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            @curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            @curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
            @curl_setopt($ch, CURLOPT_TIMEOUT, 3);
            @curl_setopt($ch, CURLOPT_MAXREDIRS, 0);
            @curl_setopt($ch, CURLOPT_USERAGENT, 'DoMyDesk-Agent-Enrollment-Discovery/1.0');
            @curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json'));

            $raw = @curl_exec($ch);
            if (is_string($raw)) $body = $raw;
            $status = (int)@curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $contentType = strtolower((string)@curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
            @curl_close($ch);
        }
    } else {
        $context = @stream_context_create(array(
            'http' => array(
                'method' => 'GET',
                'timeout' => 3,
                'ignore_errors' => true,
                'follow_location' => 0,
                'header' => "Accept: application/json\r\nUser-Agent: DoMyDesk-Agent-Enrollment-Discovery/1.0\r\n",
            ),
        ));

        $raw = @file_get_contents($probeUrl, false, $context);
        if (is_string($raw)) $body = $raw;

        if (isset($http_response_header) && is_array($http_response_header)) {
            foreach ($http_response_header as $header) {
                if (preg_match('#^HTTP/\S+\s+(\d{3})#i', (string)$header, $m)) {
                    $status = (int)$m[1];
                } elseif (stripos((string)$header, 'Content-Type:') === 0) {
                    $contentType = strtolower(trim(substr((string)$header, strlen('Content-Type:'))));
                }
            }
        }
    }

    if ($status !== 405) return false;

    $json = json_decode($body, true);
    if (!is_array($json)) return false;

    return (($json['ok'] ?? null) === false)
        && ((string)($json['code'] ?? '') === 'method_not_allowed');
}

/**
 * Si l'administrateur saisit seulement l'hôte/IP, DoMyDesk recherche
 * automatiquement le bon point de montage de CETTE instance :
 *
 *   http://192.168.1.50
 * devient par exemple
 *   http://192.168.1.50/domydesk
 *
 * Un chemin explicitement saisi par l'administrateur n'est jamais modifié.
 */
function dmd_agent_resolve_server_base_url($url, $parts) {
    $scheme = strtolower((string)$parts['scheme']);
    $host = (string)$parts['host'];
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';

    // IPv6 doit rester entre crochets dans l'URL reconstruite.
    if (strpos($host, ':') !== false && $host[0] !== '[') {
        $host = '[' . $host . ']';
    }

    $origin = $scheme . '://' . $host . $port;
    $path = isset($parts['path']) ? rtrim((string)$parts['path'], '/') : '';

    // Un chemin a été explicitement fourni : on le respecte intégralement.
    if ($path !== '' && $path !== '/') {
        return $origin . $path;
    }

    // 1. L'instance est peut-être exposée directement à la racine.
    if (dmd_agent_probe_server_base_url($origin)) {
        return $origin;
    }

    // 2. Même chemin Web que l'instance DoMyDesk actuellement ouverte.
    $currentPath = dmd_agent_current_web_base_path();
    if ($currentPath !== '') {
        $candidate = $origin . $currentPath;
        if (dmd_agent_probe_server_base_url($candidate)) {
            return $candidate;
        }
    }

    // 3. Chemin standard /domydesk.
    if ($currentPath !== '/domydesk') {
        $candidate = $origin . '/domydesk';
        if (dmd_agent_probe_server_base_url($candidate)) {
            return $candidate;
        }
    }

    /*
     * Si le serveur DoMyDesk ne peut pas joindre lui-même cette adresse
     * (DNS public, hairpin NAT, nom résolu uniquement côté poste cible...),
     * on ne bloque pas l'enrôlement : on applique le chemin courant de
     * l'instance, qui est le meilleur fallback déterministe.
     */
    if ($currentPath !== '') {
        return $origin . $currentPath;
    }

    return $origin;
}

function dmd_agent_validate_server_url($url) {
    $url = rtrim(trim((string)$url), '/');
    if ($url === '' || strlen($url) > 500) return array('ok'=>false,'error'=>'server_url_invalid');

    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
        return array('ok'=>false,'error'=>'server_url_invalid');
    }

    $scheme = strtolower((string)$parts['scheme']);
    if ($scheme !== 'http' && $scheme !== 'https') {
        return array('ok'=>false,'error'=>'server_url_scheme_invalid');
    }

    if (isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
        return array('ok'=>false,'error'=>'server_url_forbidden_parts');
    }

    $resolvedUrl = dmd_agent_resolve_server_base_url($url, $parts);

    return array(
        'ok'=>true,
        'server_url'=>$resolvedUrl,
        'transport_policy'=>$scheme === 'https' ? 'https_required' : 'dev_http_allowed'
    );
}

function dmd_agent_validate_server_endpoints($values) {
    if (!is_array($values)) $values = array($values);

    $endpoints = array();
    $seen = array();

    foreach ($values as $value) {
        $rawUrl = is_array($value) ? (string)($value['url'] ?? '') : (string)$value;
        if (trim($rawUrl) === '') continue;

        $check = dmd_agent_validate_server_url($rawUrl);
        if (empty($check['ok'])) return $check;

        $url = (string)$check['server_url'];
        $key = strtolower($url);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;

        $endpoints[] = array(
            'url' => $url,
            'transport_policy' => (string)$check['transport_policy'],
        );

        if (count($endpoints) >= 8) break;
    }

    if (!$endpoints) return array('ok'=>false,'error'=>'server_urls_required');

    return array(
        'ok'=>true,
        'server_url'=>$endpoints[0]['url'],
        'transport_policy'=>$endpoints[0]['transport_policy'],
        'server_endpoints'=>$endpoints,
    );
}

function dmd_agent_server_endpoints_hash($endpoints) {
    if (!is_array($endpoints) || !$endpoints) return '';
    $lines = array();

    foreach ($endpoints as $endpoint) {
        if (!is_array($endpoint)) continue;
        $url = rtrim(trim((string)($endpoint['url'] ?? '')), '/');
        $policy = trim((string)($endpoint['transport_policy'] ?? ''));
        if ($url === '' || $policy === '') continue;
        $lines[] = $url . "\t" . $policy;
    }

    return $lines ? hash('sha256', implode("\n", $lines)) : '';
}

function dmd_agent_sign_message($message) {
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return false;
    $secret = dmd_agent_load_secret_key();
    return base64_encode(sodium_crypto_sign_detached((string)$message, $secret));
}
function dmd_agent_bootstrap_message($b) {
    $message = "DMD-BOOTSTRAP-V1\n"
        . (int)$b['protocol_version'] . "\n"
        . (string)$b['instance_id'] . "\n"
        . rtrim((string)$b['server_url'], '/') . "\n"
        . (string)$b['transport_policy'] . "\n"
        . (string)$b['instance_public_key_fingerprint'] . "\n"
        . (string)$b['enrollment_id'] . "\n"
        . hash('sha256', (string)$b['enrollment_token']) . "\n"
        . (string)$b['expires_at'] . "\n"
        . dmd_agent_caps_hash(isset($b['requested_capabilities']) ? $b['requested_capabilities'] : array());

    $endpointsHash = dmd_agent_server_endpoints_hash($b['server_endpoints'] ?? array());
    if ($endpointsHash !== '') $message .= "\n" . $endpointsHash;

    return $message;
}
function dmd_agent_certificate_message($p) {
    return "DMD-DEVICE-CERT-V1\n"
        . (int)$p['protocol_version'] . "\n"
        . (string)$p['agent_id'] . "\n"
        . (string)$p['instance_id'] . "\n"
        . (string)$p['device_public_key'] . "\n"
        . (string)$p['device_key_fingerprint'] . "\n"
        . (string)$p['hostname'] . "\n"
        . (string)$p['issued_at'] . "\n"
        . (string)$p['valid_until'] . "\n"
        . dmd_agent_caps_hash(isset($p['capabilities']) ? $p['capabilities'] : array());
}
function dmd_agent_certificate_bundle_hash($cert) {
    return hash('sha256', "DMD-CERT-BUNDLE-V1\n" . dmd_agent_certificate_message($cert['payload']) . "\n" . (string)$cert['signature']);
}

function dmd_agent_resolve_pc_group_selection($groupId) {
    $groupId = trim((string)$groupId);
    if ($groupId === '') {
        return array('ok'=>true, 'group_id'=>'', 'group_name'=>'');
    }

    $groupId = dmd_agent_access_safe_id($groupId, 'PCG');
    if ($groupId === '') {
        return array('ok'=>false, 'error'=>'pc_group_id_invalid');
    }

    $data = dmd_agent_access_read_pc_groups();
    if (!isset($data['groups'][$groupId]) || !is_array($data['groups'][$groupId])) {
        return array('ok'=>false, 'error'=>'pc_group_not_found');
    }

    return array(
        'ok'=>true,
        'group_id'=>$groupId,
        'group_name'=>trim((string)($data['groups'][$groupId]['name'] ?? '')),
    );
}

function dmd_agent_create_enrollment($creator, $targetName, $expiresMinutes, $approvalMode, $capabilities, $serverUrls, $includeMyDesk = false, $pcGroupId = '') {
    $identity = dmd_agent_ensure_instance_identity();
    if (empty($identity['ok'])) return array('ok' => false, 'error' => 'instance_identity_invalid', 'identity' => $identity);
    $urlCheck = dmd_agent_validate_server_endpoints($serverUrls);
    if (empty($urlCheck['ok'])) return $urlCheck;

    $groupCheck = dmd_agent_resolve_pc_group_selection($pcGroupId);
    if (empty($groupCheck['ok'])) return $groupCheck;
    $targetName = trim((string)$targetName);
    if ($targetName === '' || strlen($targetName) > 100) return array('ok' => false, 'error' => 'target_name_invalid');
    $expiresMinutes = (int)$expiresMinutes;
    if ($expiresMinutes < 5) $expiresMinutes = 5;
    if ($expiresMinutes > 10080) $expiresMinutes = 10080;
    $approvalMode = $approvalMode === 'auto' ? 'auto' : 'manual';
    $token = dmd_agent_b64url_encode(random_bytes(32));
    $id = dmd_agent_short_id('ENR', 12);
    $now = time();

    /*
     * Le choix des composants vient désormais du JSON d'enrôlement.
     * $capabilities est normalisé en "Agent seul + options Remote/MyDesk".
     * Ainsi requested_capabilities (signé) et install_components restent
     * obligatoirement cohérents.
     */
    $requested = is_array($capabilities) ? array_values($capabilities) : array();
    $requestedComponents = dmd_agent_install_components_from_capabilities($requested);
    $includeRemote = !empty($requestedComponents['remote']);
    $includeMyDesk = !empty($includeMyDesk) || !empty($requestedComponents['mydesk']);
    $caps = dmd_agent_capabilities_for_components($includeRemote, $includeMyDesk);

    if ($includeMyDesk) {
        $myDeskEnt = function_exists('dmd_license_entitlement') ? dmd_license_entitlement('dmd_mydesk') : array('enabled'=>true,'modules_max'=>5);
        if (empty($myDeskEnt['enabled']) || (int)($myDeskEnt['modules_max'] ?? 0) === 0) {
            dmd_agent_log('mydesk_license_required','warning',array('actor'=>(string)$creator));
            return array('ok'=>false,'error'=>'mydesk_license_required');
        }
    }

    if ($includeRemote) {
        $remoteLimit = dmd_agent_remote_license_limit();
        $remoteUsed = dmd_agent_remote_license_usage();
        if ($remoteLimit === 0 || ($remoteLimit > 0 && $remoteUsed >= $remoteLimit)) {
            dmd_agent_log('remote_license_limit_exceeded','warning',array('used'=>$remoteUsed,'allowed'=>$remoteLimit,'actor'=>(string)$creator));
            return array('ok'=>false,'error'=>'remote_target_limit_exceeded','used'=>$remoteUsed,'allowed'=>$remoteLimit);
        }
    }

    $installComponents = array(
        'agent' => true,
        'remote' => $includeRemote,
        'mydesk' => $includeMyDesk,
    );

    $enrollment = array(
        'schema' => 1,
        'protocol_version' => DMD_AGENT_PROTOCOL,
        'enrollment_id' => $id,
        'instance_id' => $identity['manifest']['instance_id'],
        'server_url' => $urlCheck['server_url'],
        'transport_policy' => $urlCheck['transport_policy'],
        'server_endpoints' => $urlCheck['server_endpoints'],
        'target_name' => $targetName,
        'target_pc_group_id' => (string)$groupCheck['group_id'],
        'target_pc_group_name' => (string)$groupCheck['group_name'],
        'created_by' => (string)$creator,
        'created_at' => gmdate('c', $now),
        'created_ts' => $now,
        'expires_at' => gmdate('c', $now + $expiresMinutes * 60),
        'expires_ts' => $now + $expiresMinutes * 60,
        'approval_mode' => $approvalMode,
        'capabilities' => $caps,
        'install_components' => $installComponents,
        // Compatibilité avec les anciennes parties du panneau.
        'include_remote' => $includeRemote,
        'include_mydesk' => $includeMyDesk,
        'status' => 'created',
        'token_hash' => dmd_agent_token_hash($token),
        'attempts' => 0,
        'candidate' => null,
        'challenge' => null,
        'certificate' => null,
    );
    $file = dmd_agent_enrollment_file($id);
    if ($file === '' || !dmd_agent_json_write($file, $enrollment, 0640)) return array('ok' => false, 'error' => 'write_failed');

    $bootstrap = array(
        'schema' => 1,
        'protocol_version' => DMD_AGENT_PROTOCOL,
        'instance_id' => $identity['manifest']['instance_id'],
        'server_url' => $urlCheck['server_url'],
        'transport_policy' => $urlCheck['transport_policy'],
        'server_endpoints' => $urlCheck['server_endpoints'],
        'instance_public_key' => $identity['public_key'],
        'instance_public_key_fingerprint' => $identity['manifest']['public_key_fingerprint'],
        'enrollment_id' => $id,
        'enrollment_token' => $token,
        'expires_at' => $enrollment['expires_at'],
        'requested_capabilities' => $caps,
        'install_components' => $installComponents,
        'bootstrap_signature_format' => 'DMD-BOOTSTRAP-V1',
    );
    $bootstrap['bootstrap_signature'] = dmd_agent_sign_message(dmd_agent_bootstrap_message($bootstrap));
    if ($bootstrap['bootstrap_signature'] === false) { @unlink($file); return array('ok'=>false,'error'=>'bootstrap_sign_failed'); }

    dmd_agent_log('enrollment_created', 'success', array(
        'enrollment_id'=>$id,
        'target_name'=>$targetName,
        'approval_mode'=>$approvalMode,
        'transport_policy'=>$urlCheck['transport_policy'],
        'include_remote'=>$includeRemote,
        'include_mydesk'=>$includeMyDesk,
        'pc_group_id'=>(string)$groupCheck['group_id'],
        'pc_group_name'=>(string)$groupCheck['group_name'],
        'install_components'=>$installComponents,
    ));
    return array('ok'=>true,'enrollment'=>$enrollment,'token'=>$token,'bootstrap'=>$bootstrap);
}


/* ============================================================
 * LIEN TEMPORAIRE D'INSTALLATION
 * ============================================================
 *
 * Le lien public ne contient JAMAIS le token d'enrôlement directement.
 * Il contient un jeton aléatoire distinct. Le bootstrap complet reste
 * temporairement dans var/agent/install-links (zone privée) jusqu'à
 * expiration / début d'enrôlement.
 */

function dmd_agent_install_link_dir() {
    return DMD_AGENT_VAR . '/install-links';
}

function dmd_agent_install_link_token_valid($token) {
    return is_string($token) && preg_match('/^[A-Za-z0-9_-]{40,100}$/', $token);
}

function dmd_agent_install_link_file_for_token($token) {
    if (!dmd_agent_install_link_token_valid($token)) return '';
    return dmd_agent_install_link_dir() . '/LNK-' . strtoupper(hash('sha256', $token)) . '.php';
}

function dmd_agent_install_link_bootstrap_raw($row) {
    $bootstrap = isset($row['bootstrap']) && is_array($row['bootstrap']) ? $row['bootstrap'] : array();
    if (!$bootstrap) return '';
    $raw = json_encode($bootstrap, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($raw === false) return '';
    return $raw . "\r\n";
}

function dmd_agent_install_link_cleanup() {
    $dir = dmd_agent_install_link_dir();
    if (!is_dir($dir)) return;

    $now = time();
    foreach (glob($dir . '/LNK-*.php') ?: array() as $file) {
        $row = dmd_agent_json_read($file, array());
        if (!$row) {
            @unlink($file);
            continue;
        }

        $expiresTs = (int)($row['expires_ts'] ?? 0);
        if ($expiresTs <= 0 || $expiresTs < $now) {
            @unlink($file);
            continue;
        }

        $enrollmentId = dmd_agent_safe_enrollment_id($row['enrollment_id'] ?? '');
        if ($enrollmentId === '') {
            @unlink($file);
            continue;
        }

        $e = dmd_agent_load_enrollment($enrollmentId);
        if (!$e || (string)($e['status'] ?? '') !== 'created' || dmd_agent_enrollment_expired($e)) {
            @unlink($file);
        }
    }
}

function dmd_agent_create_install_link($bootstrap, $creator = '') {
    if (!is_array($bootstrap)) return array('ok'=>false, 'error'=>'bootstrap_invalid');

    $enrollmentId = dmd_agent_safe_enrollment_id($bootstrap['enrollment_id'] ?? '');
    $enrollmentToken = (string)($bootstrap['enrollment_token'] ?? '');
    if ($enrollmentId === '' || $enrollmentToken === '') {
        return array('ok'=>false, 'error'=>'bootstrap_incomplete');
    }

    $e = dmd_agent_load_enrollment($enrollmentId);
    if (!$e) return array('ok'=>false, 'error'=>'enrollment_not_found');
    if (dmd_agent_enrollment_expired($e)) return array('ok'=>false, 'error'=>'enrollment_expired');
    if ((string)($e['status'] ?? '') !== 'created') return array('ok'=>false, 'error'=>'enrollment_not_available');
    if (!dmd_agent_verify_token($e, $enrollmentToken)) return array('ok'=>false, 'error'=>'enrollment_token_invalid');

    dmd_agent_install_link_cleanup();

    $dir = dmd_agent_install_link_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
        return array('ok'=>false, 'error'=>'install_link_dir_create_failed');
    }
    @chmod($dir, 0750);

    $token = dmd_agent_b64url_encode(random_bytes(32));
    $tokenHash = hash('sha256', $token);
    $file = dmd_agent_install_link_file_for_token($token);
    if ($file === '') return array('ok'=>false, 'error'=>'install_link_token_failed');

    $expiresTs = (int)($e['expires_ts'] ?? 0);
    if ($expiresTs <= time()) return array('ok'=>false, 'error'=>'enrollment_expired');

    $row = array(
        'schema'=>1,
        'token_hash'=>$tokenHash,
        'enrollment_id'=>$enrollmentId,
        'instance_id'=>(string)($e['instance_id'] ?? ''),
        'target_name'=>(string)($e['target_name'] ?? ''),
        'created_at'=>gmdate('c'),
        'created_ts'=>time(),
        'created_by'=>(string)$creator,
        'expires_at'=>gmdate('c', $expiresTs),
        'expires_ts'=>$expiresTs,
        'bootstrap'=>$bootstrap,
        'launcher_downloads'=>0,
        'installer_downloads'=>0,
        'bootstrap_downloads'=>0,
        'last_access_at'=>null,
    );

    if (!dmd_agent_json_write($file, $row, 0640)) {
        return array('ok'=>false, 'error'=>'install_link_write_failed');
    }

    $bases = array();
    $endpoints = isset($bootstrap['server_endpoints']) && is_array($bootstrap['server_endpoints'])
        ? $bootstrap['server_endpoints']
        : array();

    foreach ($endpoints as $endpoint) {
        if (!is_array($endpoint)) continue;
        $base = rtrim(trim((string)($endpoint['url'] ?? '')), '/');
        if ($base !== '' && !in_array($base, $bases, true)) $bases[] = $base;
    }

    $primary = rtrim(trim((string)($bootstrap['server_url'] ?? '')), '/');
    if ($primary !== '' && !in_array($primary, $bases, true)) array_unshift($bases, $primary);
    if (!$bases) return array('ok'=>false, 'error'=>'install_link_server_url_missing');

    $urls = array();
    foreach ($bases as $index=>$base) {
        $urls[] = $base . '/adm/agent/install.php?t=' . rawurlencode($token) . '&e=' . (int)$index;
    }

    dmd_agent_log('enrollment_install_link_created', 'success', array(
        'enrollment_id'=>$enrollmentId,
        'target_name'=>(string)($e['target_name'] ?? ''),
        'expires_at'=>gmdate('c', $expiresTs),
        'endpoints'=>count($urls),
        'actor'=>(string)$creator,
    ));

    return array(
        'ok'=>true,
        'install_link'=>array(
            'url'=>$urls[0],
            'urls'=>$urls,
            'expires_at'=>gmdate('c', $expiresTs),
            'enrollment_id'=>$enrollmentId,
        ),
    );
}

function dmd_agent_install_link_load($token, $touch = false) {
    if (!dmd_agent_install_link_token_valid($token)) return array('ok'=>false, 'error'=>'install_link_invalid');

    $file = dmd_agent_install_link_file_for_token($token);
    if ($file === '' || !is_file($file)) return array('ok'=>false, 'error'=>'install_link_not_found');

    $row = dmd_agent_json_read($file, array());
    if (!$row) {
        @unlink($file);
        return array('ok'=>false, 'error'=>'install_link_invalid');
    }

    $expectedHash = hash('sha256', $token);
    if (empty($row['token_hash']) || !hash_equals((string)$row['token_hash'], $expectedHash)) {
        @unlink($file);
        return array('ok'=>false, 'error'=>'install_link_invalid');
    }

    if ((int)($row['expires_ts'] ?? 0) < time()) {
        @unlink($file);
        return array('ok'=>false, 'error'=>'install_link_expired');
    }

    $enrollmentId = dmd_agent_safe_enrollment_id($row['enrollment_id'] ?? '');
    $e = $enrollmentId !== '' ? dmd_agent_load_enrollment($enrollmentId) : array();
    if (!$e || dmd_agent_enrollment_expired($e)) {
        @unlink($file);
        return array('ok'=>false, 'error'=>'enrollment_expired');
    }

    /*
     * Dès qu'un Agent s'est présenté, le lien de distribution devient
     * inutilisable. Cela évite qu'un second PC récupère le même bootstrap.
     */
    if ((string)($e['status'] ?? '') !== 'created') {
        @unlink($file);
        return array('ok'=>false, 'error'=>'install_link_consumed');
    }

    $bootstrap = isset($row['bootstrap']) && is_array($row['bootstrap']) ? $row['bootstrap'] : array();
    $bootstrapToken = (string)($bootstrap['enrollment_token'] ?? '');
    if ($bootstrapToken === '' || !dmd_agent_verify_token($e, $bootstrapToken)) {
        @unlink($file);
        return array('ok'=>false, 'error'=>'install_link_token_invalid');
    }

    if ($touch) {
        $row['last_access_at'] = gmdate('c');
        dmd_agent_json_write($file, $row, 0640);
    }

    return array('ok'=>true, 'file'=>$file, 'row'=>$row, 'enrollment'=>$e);
}

function dmd_agent_install_link_increment($token, $field) {
    $allowed = array('launcher_downloads','installer_downloads','bootstrap_downloads');
    if (!in_array((string)$field, $allowed, true)) return false;

    $loaded = dmd_agent_install_link_load($token, false);
    if (empty($loaded['ok'])) return false;

    $row = $loaded['row'];
    $row[$field] = (int)($row[$field] ?? 0) + 1;
    $row['last_access_at'] = gmdate('c');
    return dmd_agent_json_write($loaded['file'], $row, 0640);
}

function dmd_agent_install_link_endpoint_bases($row) {
    $bootstrap = isset($row['bootstrap']) && is_array($row['bootstrap']) ? $row['bootstrap'] : array();
    $bases = array();

    foreach ((array)($bootstrap['server_endpoints'] ?? array()) as $endpoint) {
        if (!is_array($endpoint)) continue;
        $base = rtrim(trim((string)($endpoint['url'] ?? '')), '/');
        if ($base !== '' && !in_array($base, $bases, true)) $bases[] = $base;
    }

    $primary = rtrim(trim((string)($bootstrap['server_url'] ?? '')), '/');
    if ($primary !== '' && !in_array($primary, $bases, true)) array_unshift($bases, $primary);

    return $bases;
}

function dmd_agent_install_link_endpoint_base($row, $index) {
    $bases = dmd_agent_install_link_endpoint_bases($row);
    if (!$bases) return '';
    $index = (int)$index;
    if ($index < 0 || $index >= count($bases)) $index = 0;
    return $bases[$index];
}

function dmd_agent_installer_binary_path() {
    return dirname(__DIR__) . '/bin/windows-x64/DMD-Installer.exe';
}

function dmd_agent_installer_binary_validate($path = '') {
    if ($path === '') $path = dmd_agent_installer_binary_path();
    if (!is_file($path) || !is_readable($path)) return array('ok'=>false, 'error'=>'installer_not_found');

    $size = @filesize($path);
    if ($size === false || $size < 1024) return array('ok'=>false, 'error'=>'installer_invalid_size');

    $fh = @fopen($path, 'rb');
    if (!$fh) return array('ok'=>false, 'error'=>'installer_unreadable');
    $magic = fread($fh, 2);
    fclose($fh);
    if ($magic !== 'MZ') return array('ok'=>false, 'error'=>'installer_invalid_pe');

    $sha = @hash_file('sha256', $path);
    if (!is_string($sha) || strlen($sha) !== 64) return array('ok'=>false, 'error'=>'installer_hash_failed');

    return array('ok'=>true, 'path'=>$path, 'size'=>(int)$size, 'sha256'=>strtolower($sha));
}

function dmd_agent_remote_ip() {
    // Intentionally DO NOT trust X-Forwarded-For / CF-Connecting-IP here.
    // Trusted proxy support can be explicitly configured later.
    return isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}
function dmd_agent_ip_key($ip) { return hash('sha256', (string)$ip); }
function dmd_agent_security_file() { return DMD_AGENT_VAR . '/security/ip_state.php'; }
function dmd_agent_security_state() { return dmd_agent_json_read(dmd_agent_security_file(), array('ips' => array())); }
function dmd_agent_security_is_banned($ip) {
    $state = dmd_agent_security_state(); $key = dmd_agent_ip_key($ip); $now = time();
    return !empty($state['ips'][$key]['banned_until']) && (int)$state['ips'][$key]['banned_until'] > $now;
}
function dmd_agent_security_failure($ip, $reason) {
    $file = dmd_agent_security_file();
    $state = dmd_agent_json_read($file, array('ips' => array()));
    if (!isset($state['ips']) || !is_array($state['ips'])) $state['ips'] = array();
    $key = dmd_agent_ip_key($ip); $now = time();
    $row = isset($state['ips'][$key]) && is_array($state['ips'][$key]) ? $state['ips'][$key] : array('window_start' => $now, 'failures' => 0, 'banned_until' => 0);
    if (($now - (int)$row['window_start']) > 600) { $row['window_start'] = $now; $row['failures'] = 0; }
    $row['failures'] = (int)$row['failures'] + 1;
    $row['last_failure'] = $now; $row['last_reason'] = (string)$reason;
    if ($row['failures'] >= 5) { $row['banned_until'] = $now + 1800; dmd_agent_log('agent_api_ip_banned', 'critical', array('ip_hash' => $key, 'reason' => $reason, 'until' => $row['banned_until'])); }
    $state['ips'][$key] = $row; dmd_agent_json_write($file, $state, 0640);
}
function dmd_agent_security_success($ip) {
    $file = dmd_agent_security_file(); $state = dmd_agent_json_read($file, array('ips' => array())); $key = dmd_agent_ip_key($ip);
    if (isset($state['ips'][$key])) { unset($state['ips'][$key]); dmd_agent_json_write($file, $state, 0640); }
}

function dmd_agent_api_result($ok, $http, $code, $extra = array()) {
    return array_merge(array('ok' => (bool)$ok, '_http' => (int)$http, 'code' => (string)$code), is_array($extra) ? $extra : array());
}
function dmd_agent_load_enrollment($id) {
    $file = dmd_agent_enrollment_file($id);
    if ($file === '' || !is_file($file)) return array();
    return dmd_agent_json_read($file, array());
}
function dmd_agent_save_enrollment($enrollment) {
    if (empty($enrollment['enrollment_id'])) return false;
    $file = dmd_agent_enrollment_file($enrollment['enrollment_id']);
    return $file !== '' && dmd_agent_json_write($file, $enrollment, 0640);
}

/**
 * Retourne le nom saisi par l'administrateur lors de l'enrôlement.
 *
 * IMPORTANT : ce nom est volontairement distinct du hostname Windows courant.
 * Pour les anciennes fiches créées avant la persistance de enrollment_name,
 * on peut le récupérer dans le journal security-* grâce à l'événement
 * enrollment_created qui contient enrollment_id + target_name.
 */
function dmd_agent_enrollment_name_for_device($device) {
    if (!is_array($device)) return '';

    foreach (array('enrollment_name','enrollment_target_name','target_name') as $key) {
        $value = trim((string)($device[$key] ?? ''));
        if ($value !== '') return $value;
    }

    $enrollmentId = dmd_agent_safe_enrollment_id($device['enrollment_id'] ?? '');
    if ($enrollmentId === '') return '';

    // Source normale : fichier d'enrôlement encore présent.
    $enrollment = dmd_agent_load_enrollment($enrollmentId);
    if (is_array($enrollment)) {
        $value = trim((string)($enrollment['target_name'] ?? ''));
        if ($value !== '') return $value;
    }

    // Compatibilité des PC déjà enrôlés dont l'historique a été supprimé.
    // dmd_agent_create_enrollment() journalise systématiquement target_name.
    $files = glob(DMD_AGENT_VAR . '/logs/security-*.php');
    if (!is_array($files) || !$files) return '';
    rsort($files, SORT_STRING);

    foreach ($files as $logFile) {
        $fh = @fopen($logFile, 'rb');
        if (!$fh) continue;

        while (($line = fgets($fh)) !== false) {
            $line = trim($line);
            if ($line === '' || $line[0] !== '{') continue;

            $entry = json_decode($line, true);
            if (!is_array($entry) || (string)($entry['event'] ?? '') !== 'enrollment_created') continue;

            $details = isset($entry['details']) && is_array($entry['details']) ? $entry['details'] : array();
            if ((string)($details['enrollment_id'] ?? '') !== $enrollmentId) continue;

            $value = trim((string)($details['target_name'] ?? ''));
            if ($value !== '') {
                fclose($fh);
                return $value;
            }
        }
        fclose($fh);
    }

    return '';
}

function dmd_agent_enrollment_expired($e) { return empty($e['expires_ts']) || time() > (int)$e['expires_ts']; }

function dmd_agent_challenge_message($e) {
    if (empty($e['challenge']) || empty($e['candidate'])) return '';
    return "DMD-ENROLL-PROOF-V1\n"
        . (string)$e['instance_id'] . "\n"
        . (string)$e['enrollment_id'] . "\n"
        . (string)$e['challenge']['challenge_id'] . "\n"
        . (string)$e['challenge']['challenge'] . "\n"
        . (string)$e['candidate']['device_key_fingerprint'];
}

function dmd_agent_validate_enrollment_base($payload, $ip) {
    if (dmd_agent_security_is_banned($ip)) return dmd_agent_api_result(false, 429, 'ip_temporarily_banned');
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return dmd_agent_api_result(false, 503, 'instance_identity_invalid');
    $id = dmd_agent_safe_enrollment_id(isset($payload['enrollment_id']) ? $payload['enrollment_id'] : '');
    if ($id === '') { dmd_agent_security_failure($ip, 'bad_enrollment_id'); return dmd_agent_api_result(false, 400, 'enrollment_id_invalid'); }
    $e = dmd_agent_load_enrollment($id);
    if (!$e) { dmd_agent_security_failure($ip, 'unknown_enrollment'); return dmd_agent_api_result(false, 404, 'enrollment_unknown'); }
    $instanceId = trim((string)(isset($payload['instance_id']) ? $payload['instance_id'] : ''));
    if (!hash_equals((string)$e['instance_id'], $instanceId)) { dmd_agent_security_failure($ip, 'instance_mismatch'); return dmd_agent_api_result(false, 403, 'instance_mismatch'); }
    $token = (string)(isset($payload['enrollment_token']) ? $payload['enrollment_token'] : '');
    if (!dmd_agent_verify_token($e, $token)) { dmd_agent_security_failure($ip, 'token_invalid'); return dmd_agent_api_result(false, 403, 'token_invalid'); }
    if (dmd_agent_enrollment_expired($e)) {
        if (!in_array($e['status'], array('completed','rejected','expired'), true)) { $e['status'] = 'expired'; dmd_agent_save_enrollment($e); }
        return dmd_agent_api_result(false, 410, 'enrollment_expired');
    }
    if ($e['status'] === 'rejected') return dmd_agent_api_result(false, 403, 'enrollment_rejected');
    return array('ok' => true, 'identity' => $identity, 'enrollment' => $e, 'token' => $token);
}

function dmd_agent_enroll_start($payload, $ip) {
    $base = dmd_agent_validate_enrollment_base($payload, $ip);
    if (empty($base['ok'])) return $base;
    $e = $base['enrollment'];
    $pubB64 = trim((string)(isset($payload['device_public_key']) ? $payload['device_public_key'] : ''));
    $pub = base64_decode($pubB64, true);
    if (!is_string($pub) || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) { dmd_agent_security_failure($ip, 'device_public_key_invalid'); return dmd_agent_api_result(false, 400, 'device_public_key_invalid'); }
    $fp = dmd_agent_fingerprint($pub);
    if (!empty($e['candidate']['device_key_fingerprint']) && !hash_equals((string)$e['candidate']['device_key_fingerprint'], $fp)) {
        dmd_agent_security_failure($ip, 'enrollment_key_already_bound');
        return dmd_agent_api_result(false, 409, 'enrollment_already_bound_to_another_device');
    }
    if (in_array($e['status'], array('pending_approval','approved','completed'), true)) {
        return dmd_agent_api_result(true, 200, $e['status'], array('status' => $e['status']));
    }
    $hostname = trim((string)(isset($payload['hostname']) ? $payload['hostname'] : ''));
    if ($hostname === '') $hostname = $e['target_name'];
    $e['candidate'] = array(
        'device_public_key' => $pubB64,
        'device_key_fingerprint' => $fp,
        'hostname' => substr($hostname, 0, 120),
        'platform' => substr(trim((string)(isset($payload['platform']) ? $payload['platform'] : 'unknown')), 0, 80),
        'arch' => substr(trim((string)(isset($payload['arch']) ? $payload['arch'] : 'unknown')), 0, 40),
        'agent_version' => substr(trim((string)(isset($payload['agent_version']) ? $payload['agent_version'] : 'unknown')), 0, 40),
        'hardware' => isset($payload['hardware']) && is_array($payload['hardware']) ? $payload['hardware'] : array(),
        'inventory' => isset($payload['inventory']) && is_array($payload['inventory']) ? $payload['inventory'] : array(),
        'first_ip' => $ip,
        'bound_at' => gmdate('c'),
    );
    $e['challenge'] = array(
        'challenge_id' => dmd_agent_short_id('CHL', 12),
        'challenge' => dmd_agent_b64url_encode(random_bytes(32)),
        'created_ts' => time(),
        'expires_ts' => time() + 300,
    );
    $e['status'] = 'challenge'; $e['attempts'] = (int)$e['attempts'] + 1;
    if (!dmd_agent_save_enrollment($e)) return dmd_agent_api_result(false, 500, 'write_failed');
    dmd_agent_security_success($ip);
    dmd_agent_log('enrollment_challenge_issued', 'success', array('enrollment_id' => $e['enrollment_id'], 'device_fingerprint' => $fp));
    return dmd_agent_api_result(true, 200, 'challenge', array(
        'status' => 'challenge',
        'challenge_id' => $e['challenge']['challenge_id'],
        'challenge' => $e['challenge']['challenge'],
        'challenge_expires_at' => gmdate('c', $e['challenge']['expires_ts']),
        'proof_format' => 'DMD-ENROLL-PROOF-V1',
    ));
}

function dmd_agent_assign_agent_to_pc_group($groupId, $agentId, $actor = 'enrollment') {
    $groupId = dmd_agent_access_safe_id($groupId, 'PCG');
    $agentId = dmd_agent_safe_agent_id($agentId);

    if ($groupId === '') return array('ok'=>false, 'error'=>'pc_group_id_invalid');
    if ($agentId === '') return array('ok'=>false, 'error'=>'agent_id_invalid');

    $data = dmd_agent_access_read_pc_groups();
    if (!isset($data['groups'][$groupId]) || !is_array($data['groups'][$groupId])) {
        return array('ok'=>false, 'error'=>'pc_group_not_found');
    }

    $ids = isset($data['groups'][$groupId]['agent_ids']) && is_array($data['groups'][$groupId]['agent_ids'])
        ? array_values($data['groups'][$groupId]['agent_ids'])
        : array();

    if (!in_array($agentId, $ids, true)) {
        $ids[] = $agentId;
        $data['groups'][$groupId]['agent_ids'] = array_values(array_unique($ids));
        $data['groups'][$groupId]['updated_at'] = gmdate('c');
        $data['groups'][$groupId]['updated_by'] = (string)$actor;

        if (!dmd_agent_access_write_pc_groups($data)) {
            return array('ok'=>false, 'error'=>'pc_group_write_failed');
        }
    }

    dmd_agent_log('agent_auto_assigned_pc_group', 'success', array(
        'agent_id'=>$agentId,
        'group_id'=>$groupId,
        'group_name'=>(string)($data['groups'][$groupId]['name'] ?? ''),
        'actor'=>(string)$actor,
    ));

    return array(
        'ok'=>true,
        'group_id'=>$groupId,
        'group_name'=>(string)($data['groups'][$groupId]['name'] ?? ''),
    );
}

function dmd_agent_issue_device_certificate(&$e) {
    if (empty($e['candidate']) || empty($e['candidate']['device_public_key'])) return array('ok' => false, 'error' => 'candidate_missing');
    $agentId = dmd_agent_short_id('AGT', 16); $now = time();
    $payload = array(
        'schema' => 1,
        'protocol_version' => DMD_AGENT_PROTOCOL,
        'agent_id' => $agentId,
        'instance_id' => $e['instance_id'],
        'device_public_key' => $e['candidate']['device_public_key'],
        'device_key_fingerprint' => $e['candidate']['device_key_fingerprint'],
        'hostname' => $e['candidate']['hostname'],
        'capabilities' => $e['capabilities'],
        'issued_at' => gmdate('c', $now),
        'valid_until' => gmdate('c', $now + 365 * 86400),
    );
    $sig = dmd_agent_sign_message(dmd_agent_certificate_message($payload));
    if ($sig === false) return array('ok' => false, 'error' => 'sign_failed');
    $cert = array('payload' => $payload, 'signature_algorithm' => 'Ed25519', 'signature_format' => 'DMD-DEVICE-CERT-V1', 'signature' => $sig);
    $device = array(
        'schema' => 1,
        'agent_id' => $agentId,
        'instance_id' => $e['instance_id'],
        'status' => 'active',
        'hostname' => $e['candidate']['hostname'],
        'platform' => $e['candidate']['platform'],
        'arch' => $e['candidate']['arch'],
        'agent_version' => $e['candidate']['agent_version'],
        'hardware' => $e['candidate']['hardware'],
        'last_inventory' => isset($e['candidate']['inventory']) && is_array($e['candidate']['inventory']) ? $e['candidate']['inventory'] : array(),
        'device_public_key' => $e['candidate']['device_public_key'],
        'device_key_fingerprint' => $e['candidate']['device_key_fingerprint'],
        'capabilities' => $e['capabilities'],
        'enrollment_id' => $e['enrollment_id'],
        // Nom saisi par l'administrateur lors de l'enrôlement.
        // Ne jamais le remplacer par le hostname Windows remonté ensuite.
        'enrollment_name' => trim((string)($e['target_name'] ?? '')),
        'created_at' => gmdate('c', $now),
        'last_seen_at' => null,
        'certificate' => $cert,
    );
    $file = dmd_agent_device_file($agentId);
    if ($file === '' || !dmd_agent_json_write($file, $device, 0640)) return array('ok' => false, 'error' => 'device_write_failed');
    $e['certificate'] = $cert; $e['agent_id'] = $agentId; $e['status'] = 'approved'; $e['approved_at'] = gmdate('c');
    if (!dmd_agent_save_enrollment($e)) { @unlink($file); return array('ok' => false, 'error' => 'enrollment_update_failed'); }

    $targetGroupId = trim((string)($e['target_pc_group_id'] ?? ''));
    if ($targetGroupId !== '') {
        $assigned = dmd_agent_assign_agent_to_pc_group($targetGroupId, $agentId, 'enrollment:auto');
        if (!empty($assigned['ok'])) {
            $e['assigned_pc_group_id'] = (string)$assigned['group_id'];
            $e['assigned_pc_group_name'] = (string)$assigned['group_name'];
            $e['assigned_pc_group_at'] = gmdate('c');
            dmd_agent_save_enrollment($e);
        } else {
            dmd_agent_log('agent_auto_assign_pc_group_failed', 'warning', array(
                'agent_id'=>$agentId,
                'enrollment_id'=>(string)($e['enrollment_id'] ?? ''),
                'group_id'=>$targetGroupId,
                'error'=>(string)($assigned['error'] ?? 'unknown'),
            ));
        }
    }

    dmd_agent_log('agent_certificate_issued', 'success', array('agent_id' => $agentId, 'enrollment_id' => $e['enrollment_id']));
    return array('ok' => true, 'agent_id' => $agentId, 'certificate' => $cert);
}


function dmd_agent_reissue_device_certificate_capabilities($agentId, $capabilities, $actor = '') {
    $agentId = dmd_agent_safe_agent_id($agentId);
    if ($agentId === '') return array('ok'=>false,'error'=>'agent_id_invalid');
    $file = dmd_agent_device_file($agentId);
    if ($file === '' || !is_file($file)) return array('ok'=>false,'error'=>'agent_not_found');
    $device = dmd_agent_json_read($file, array());
    if (!$device || (string)($device['status']??'') !== 'active') return array('ok'=>false,'error'=>'agent_not_active');
    $caps = dmd_agent_normalize_capabilities($capabilities);
    $now = time();
    $payload = array(
        'schema'=>1,
        'protocol_version'=>DMD_AGENT_PROTOCOL,
        'agent_id'=>$agentId,
        'instance_id'=>(string)($device['instance_id']??''),
        'device_public_key'=>(string)($device['device_public_key']??''),
        'device_key_fingerprint'=>(string)($device['device_key_fingerprint']??''),
        'hostname'=>(string)($device['hostname']??''),
        'capabilities'=>$caps,
        'issued_at'=>gmdate('c',$now),
        'valid_until'=>gmdate('c',$now + 365*86400),
    );
    if ($payload['instance_id']==='' || $payload['device_public_key']==='' || $payload['device_key_fingerprint']==='') return array('ok'=>false,'error'=>'device_identity_incomplete');
    $sig=dmd_agent_sign_message(dmd_agent_certificate_message($payload));
    if ($sig===false) return array('ok'=>false,'error'=>'sign_failed');
    $cert=array('payload'=>$payload,'signature_algorithm'=>'Ed25519','signature_format'=>'DMD-DEVICE-CERT-V1','signature'=>$sig);
    $device['capabilities']=$caps;
    $device['certificate']=$cert;
    $device['capabilities_updated_at']=gmdate('c',$now);
    $device['capabilities_updated_by']=(string)$actor;
    if (!dmd_agent_json_write($file,$device,0640)) return array('ok'=>false,'error'=>'device_write_failed');
    $enrollmentId=(string)($device['enrollment_id']??'');
    if ($enrollmentId!=='') {
        $e=dmd_agent_load_enrollment($enrollmentId);
        if ($e) {
            $e['capabilities']=$caps;
            $e['certificate']=$cert;
            $e['capabilities_updated_at']=gmdate('c',$now);
            $e['capabilities_updated_by']=(string)$actor;
            dmd_agent_save_enrollment($e);
        }
    }
    dmd_agent_log('agent_capabilities_reissued','success',array('agent_id'=>$agentId,'capabilities'=>$caps,'actor'=>(string)$actor));
    return array('ok'=>true,'device'=>$device,'certificate'=>$cert,'capabilities'=>$caps);
}

function dmd_agent_enroll_finish($payload, $ip) {
    $base = dmd_agent_validate_enrollment_base($payload, $ip);
    if (empty($base['ok'])) return $base;
    $e = $base['enrollment'];
    if ($e['status'] === 'approved' || $e['status'] === 'completed') return dmd_agent_api_result(true, 200, $e['status'], array('status' => $e['status'], 'agent_id' => isset($e['agent_id']) ? $e['agent_id'] : null));
    if ($e['status'] !== 'challenge' || empty($e['challenge']) || empty($e['candidate'])) return dmd_agent_api_result(false, 409, 'challenge_required');
    if (time() > (int)$e['challenge']['expires_ts']) { $e['status'] = 'created'; $e['challenge'] = null; dmd_agent_save_enrollment($e); return dmd_agent_api_result(false, 410, 'challenge_expired'); }
    $challengeId = trim((string)(isset($payload['challenge_id']) ? $payload['challenge_id'] : ''));
    if (!hash_equals((string)$e['challenge']['challenge_id'], $challengeId)) { dmd_agent_security_failure($ip, 'challenge_id_invalid'); return dmd_agent_api_result(false, 403, 'challenge_invalid'); }
    $sig = base64_decode(trim((string)(isset($payload['signature']) ? $payload['signature'] : '')), true);
    $pub = base64_decode((string)$e['candidate']['device_public_key'], true);
    $msg = dmd_agent_challenge_message($e);
    if (!is_string($sig) || !is_string($pub) || !sodium_crypto_sign_verify_detached($sig, $msg, $pub)) {
        dmd_agent_security_failure($ip, 'proof_invalid'); return dmd_agent_api_result(false, 403, 'proof_invalid');
    }
    $e['proof_verified'] = true; $e['proof_verified_at'] = gmdate('c'); $e['challenge'] = null;
    if ($e['approval_mode'] === 'manual') {
        $e['status'] = 'pending_approval';
        if (!dmd_agent_save_enrollment($e)) return dmd_agent_api_result(false, 500, 'write_failed');
        dmd_agent_security_success($ip);
        dmd_agent_log('enrollment_pending_approval', 'success', array('enrollment_id' => $e['enrollment_id'], 'hostname' => $e['candidate']['hostname']));
        return dmd_agent_api_result(true, 202, 'pending_approval', array('status' => 'pending_approval'));
    }
    $issued = dmd_agent_issue_device_certificate($e);
    if (empty($issued['ok'])) return dmd_agent_api_result(false, 500, 'certificate_issue_failed');
    dmd_agent_security_success($ip);
    return dmd_agent_api_result(true, 200, 'approved', array('status' => 'approved', 'agent_id' => $issued['agent_id'], 'certificate' => $issued['certificate']));
}

function dmd_agent_enroll_status($payload, $ip) {
    $base = dmd_agent_validate_enrollment_base($payload, $ip);
    if (empty($base['ok'])) return $base;
    $e = $base['enrollment'];
    $pubB64 = trim((string)(isset($payload['device_public_key']) ? $payload['device_public_key'] : ''));
    if (!empty($e['candidate']['device_public_key']) && !hash_equals((string)$e['candidate']['device_public_key'], $pubB64)) {
        dmd_agent_security_failure($ip, 'status_device_key_mismatch'); return dmd_agent_api_result(false, 403, 'device_key_mismatch');
    }
    $extra = array('status' => $e['status']);
    if ($e['status'] === 'approved' && !empty($e['certificate'])) { $extra['agent_id'] = $e['agent_id']; $extra['certificate'] = $e['certificate']; }
    return dmd_agent_api_result(true, 200, $e['status'], $extra);
}

function dmd_agent_completion_message($e) {
    if (empty($e['certificate']) || empty($e['agent_id'])) return '';
    return "DMD-ENROLL-COMPLETE-V1\n" . $e['instance_id'] . "\n" . $e['enrollment_id'] . "\n" . $e['agent_id'] . "\n" . dmd_agent_certificate_bundle_hash($e['certificate']);
}
function dmd_agent_enroll_complete($payload, $ip) {
    $base = dmd_agent_validate_enrollment_base($payload, $ip);
    if (empty($base['ok'])) return $base;
    $e = $base['enrollment'];
    if ($e['status'] === 'completed') return dmd_agent_api_result(true, 200, 'completed', array('status' => 'completed'));
    if ($e['status'] !== 'approved' || empty($e['certificate']) || empty($e['candidate'])) return dmd_agent_api_result(false, 409, 'approval_required');
    $sig = base64_decode(trim((string)(isset($payload['signature']) ? $payload['signature'] : '')), true);
    $pub = base64_decode((string)$e['candidate']['device_public_key'], true);
    $msg = dmd_agent_completion_message($e);
    if (!is_string($sig) || !is_string($pub) || !sodium_crypto_sign_verify_detached($sig, $msg, $pub)) { dmd_agent_security_failure($ip, 'completion_proof_invalid'); return dmd_agent_api_result(false, 403, 'completion_proof_invalid'); }
    $e['status'] = 'completed'; $e['completed_at'] = gmdate('c'); $e['token_hash'] = null; $e['token_consumed_at'] = gmdate('c');
    if (!dmd_agent_save_enrollment($e)) return dmd_agent_api_result(false, 500, 'write_failed');
    dmd_agent_security_success($ip);
    dmd_agent_log('enrollment_completed_token_destroyed', 'success', array('enrollment_id' => $e['enrollment_id'], 'agent_id' => $e['agent_id']));
    return dmd_agent_api_result(true, 200, 'completed', array('status' => 'completed', 'agent_id' => $e['agent_id']));
}

function dmd_agent_admin_decision($enrollmentId, $decision, $actor) {
    $e = dmd_agent_load_enrollment($enrollmentId);
    if (!$e) return array('ok' => false, 'error' => 'not_found');
    if ($decision === 'approve') {
        if ($e['status'] !== 'pending_approval' || empty($e['proof_verified'])) return array('ok' => false, 'error' => 'not_pending_or_unverified');
        $issued = dmd_agent_issue_device_certificate($e);
        if (empty($issued['ok'])) return $issued;
        dmd_agent_log('enrollment_approved_by_admin', 'success', array('enrollment_id' => $enrollmentId, 'agent_id' => $issued['agent_id'], 'actor' => $actor));
        return array('ok' => true, 'agent_id' => $issued['agent_id']);
    }
    if ($decision === 'reject') {
        if (in_array($e['status'], array('completed','rejected'), true)) return array('ok' => false, 'error' => 'already_final');
        $e['status'] = 'rejected'; $e['rejected_at'] = gmdate('c'); $e['rejected_by'] = (string)$actor; $e['token_hash'] = null;
        dmd_agent_save_enrollment($e); dmd_agent_log('enrollment_rejected_by_admin', 'warning', array('enrollment_id' => $enrollmentId, 'actor' => $actor));
        return array('ok' => true);
    }
    return array('ok' => false, 'error' => 'decision_invalid');
}

function dmd_agent_access_files() {
    return array(
        'pc_groups' => DMD_AGENT_VAR . '/access/pc_groups.php',
        'user_groups' => DMD_AGENT_VAR . '/access/user_groups.php',
        'policies' => DMD_AGENT_VAR . '/access/policies.php',
    );
}

function dmd_agent_access_default_pc_groups() { return array('version'=>1,'groups'=>array()); }
function dmd_agent_access_default_user_groups() { return array('version'=>1,'groups'=>array()); }
function dmd_agent_access_default_policies() { return array('version'=>1,'policies'=>array()); }

function dmd_agent_access_read_pc_groups() {
    $f=dmd_agent_access_files();
    $d=dmd_agent_json_read($f['pc_groups'], dmd_agent_access_default_pc_groups());
    if (!isset($d['groups']) || !is_array($d['groups'])) $d['groups']=array();
    return $d;
}
function dmd_agent_access_write_pc_groups($data) {
    $f=dmd_agent_access_files();
    if (!is_array($data)) return false;
    $data['version']=1;
    if (!isset($data['groups']) || !is_array($data['groups'])) $data['groups']=array();
    return dmd_agent_json_write($f['pc_groups'],$data,0640);
}
function dmd_agent_access_read_user_groups() {
    $f=dmd_agent_access_files();
    $d=dmd_agent_json_read($f['user_groups'], dmd_agent_access_default_user_groups());
    if (!isset($d['groups']) || !is_array($d['groups'])) $d['groups']=array();
    return $d;
}
function dmd_agent_access_write_user_groups($data) {
    $f=dmd_agent_access_files();
    if (!is_array($data)) return false;
    $data['version']=1;
    if (!isset($data['groups']) || !is_array($data['groups'])) $data['groups']=array();
    return dmd_agent_json_write($f['user_groups'],$data,0640);
}
function dmd_agent_access_read_policies() {
    $f=dmd_agent_access_files();
    $d=dmd_agent_json_read($f['policies'], dmd_agent_access_default_policies());
    if (!isset($d['policies']) || !is_array($d['policies'])) $d['policies']=array();
    return $d;
}
function dmd_agent_access_write_policies($data) {
    $f=dmd_agent_access_files();
    if (!is_array($data)) return false;
    $data['version']=1;
    if (!isset($data['policies']) || !is_array($data['policies'])) $data['policies']=array();
    return dmd_agent_json_write($f['policies'],$data,0640);
}

function dmd_agent_access_safe_id($id,$prefix) {
    $id=strtoupper(trim((string)$id));
    return preg_match('/^'.preg_quote($prefix,'/').'-[A-F0-9]{12,64}$/',$id) ? $id : '';
}
function dmd_agent_access_clean_name($name,$max=80) {
    $name=trim(preg_replace('/[\\x00-\\x1F\\x7F]+/u',' ',(string)$name));
    if (function_exists('mb_substr')) $name=mb_substr($name,0,$max,'UTF-8'); else $name=substr($name,0,$max);
    return $name;
}
function dmd_agent_access_clean_description($text,$max=240) {
    $text=trim(preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]+/u',' ',(string)$text));
    if (function_exists('mb_substr')) $text=mb_substr($text,0,$max,'UTF-8'); else $text=substr($text,0,$max);
    return $text;
}
function dmd_agent_access_known_agent_ids() {
    $ids=array(); foreach(dmd_agent_list_devices() as $d){ if(!empty($d['agent_id'])) $ids[]=(string)$d['agent_id']; }
    return array_values(array_unique($ids));
}
function dmd_agent_access_known_users() {
    $out=array();
    $dirs=glob(DMD_AGENT_ROOT.'/users/profiles/*/profile/profile.json') ?: array();
    foreach($dirs as $file){
        $raw=@file_get_contents($file); $p=$raw!==false?json_decode($raw,true):null; if(!is_array($p)) continue;
        $email=trim((string)(isset($p['email'])?$p['email']:basename(dirname(dirname($file))))); if($email==='') continue;
        $out[$email]=array(
            'email'=>$email,
            'prenom'=>(string)(isset($p['prenom'])?$p['prenom']:''),
            'nom'=>(string)(isset($p['nom'])?$p['nom']:''),
            'role_system'=>(string)(isset($p['role_system'])?$p['role_system']:'user'),
            'role_metier'=>(string)(isset($p['role_metier'])?$p['role_metier']:''),
        );
    }
    ksort($out,SORT_NATURAL|SORT_FLAG_CASE); return array_values($out);
}
function dmd_agent_access_user_exists($email) {
    $email=trim((string)$email); if($email==='') return false;
    foreach(dmd_agent_access_known_users() as $u){ if(strcasecmp($u['email'],$email)===0) return true; }
    return false;
}
function dmd_agent_access_save_pc_group($groupId,$name,$description,$agentIds,$actor) {
    $name=dmd_agent_access_clean_name($name); if($name==='') return array('ok'=>false,'error'=>'group_name_required');
    $groupId=dmd_agent_access_safe_id($groupId,'PCG'); if($groupId==='') $groupId=dmd_agent_short_id('PCG',8);
    $known=array_flip(dmd_agent_access_known_agent_ids()); $clean=array();
    foreach((array)$agentIds as $id){ $id=dmd_agent_safe_agent_id($id); if($id!=='' && isset($known[$id])) $clean[]=$id; }
    $clean=array_values(array_unique($clean));
    $data=dmd_agent_access_read_pc_groups(); $now=gmdate('c'); $existing=isset($data['groups'][$groupId])&&is_array($data['groups'][$groupId])?$data['groups'][$groupId]:array();
    $data['groups'][$groupId]=array(
        'group_id'=>$groupId,'name'=>$name,'description'=>dmd_agent_access_clean_description($description),'agent_ids'=>$clean,
        'created_at'=>isset($existing['created_at'])?$existing['created_at']:$now,'created_by'=>isset($existing['created_by'])?$existing['created_by']:(string)$actor,
        'updated_at'=>$now,'updated_by'=>(string)$actor,
    );
    if(!dmd_agent_access_write_pc_groups($data)) return array('ok'=>false,'error'=>'write_failed');
    dmd_agent_log('pc_group_saved','success',array('group_id'=>$groupId,'actor'=>$actor,'members'=>count($clean)));
    return array('ok'=>true,'group'=>$data['groups'][$groupId]);
}
function dmd_agent_access_delete_pc_group($groupId,$actor) {
    $groupId=dmd_agent_access_safe_id($groupId,'PCG'); if($groupId==='') return array('ok'=>false,'error'=>'group_id_invalid');
    $data=dmd_agent_access_read_pc_groups(); if(!isset($data['groups'][$groupId])) return array('ok'=>false,'error'=>'not_found');
    unset($data['groups'][$groupId]); if(!dmd_agent_access_write_pc_groups($data)) return array('ok'=>false,'error'=>'write_failed');
    $pol=dmd_agent_access_read_policies(); $changed=false;
    foreach($pol['policies'] as $id=>$p){ if(!is_array($p))continue; $before=isset($p['pc_group_ids'])?(array)$p['pc_group_ids']:array(); $after=array_values(array_diff($before,array($groupId))); if($after!==$before){$pol['policies'][$id]['pc_group_ids']=$after;$changed=true;} }
    if($changed) dmd_agent_access_write_policies($pol);
    dmd_agent_log('pc_group_deleted','warning',array('group_id'=>$groupId,'actor'=>$actor)); return array('ok'=>true);
}
function dmd_agent_access_save_user_group($groupId,$name,$description,$users,$actor) {
    $name=dmd_agent_access_clean_name($name); if($name==='') return array('ok'=>false,'error'=>'group_name_required');
    $groupId=dmd_agent_access_safe_id($groupId,'UGR'); if($groupId==='') $groupId=dmd_agent_short_id('UGR',8);
    $clean=array(); foreach((array)$users as $email){$email=trim((string)$email);if($email!==''&&dmd_agent_access_user_exists($email))$clean[]=$email;} $clean=array_values(array_unique($clean));
    $data=dmd_agent_access_read_user_groups(); $now=gmdate('c'); $existing=isset($data['groups'][$groupId])&&is_array($data['groups'][$groupId])?$data['groups'][$groupId]:array();
    $data['groups'][$groupId]=array('group_id'=>$groupId,'name'=>$name,'description'=>dmd_agent_access_clean_description($description),'users'=>$clean,'created_at'=>isset($existing['created_at'])?$existing['created_at']:$now,'created_by'=>isset($existing['created_by'])?$existing['created_by']:(string)$actor,'updated_at'=>$now,'updated_by'=>(string)$actor);
    if(!dmd_agent_access_write_user_groups($data)) return array('ok'=>false,'error'=>'write_failed');
    dmd_agent_log('user_group_saved','success',array('group_id'=>$groupId,'actor'=>$actor,'members'=>count($clean))); return array('ok'=>true,'group'=>$data['groups'][$groupId]);
}
function dmd_agent_access_delete_user_group($groupId,$actor) {
    $groupId=dmd_agent_access_safe_id($groupId,'UGR'); if($groupId==='') return array('ok'=>false,'error'=>'group_id_invalid');
    $data=dmd_agent_access_read_user_groups(); if(!isset($data['groups'][$groupId])) return array('ok'=>false,'error'=>'not_found'); unset($data['groups'][$groupId]);
    if(!dmd_agent_access_write_user_groups($data)) return array('ok'=>false,'error'=>'write_failed');
    $pol=dmd_agent_access_read_policies(); foreach(array_keys($pol['policies']) as $id){$p=$pol['policies'][$id];if(is_array($p)&&($p['subject_type']??'')==='user_group'&&($p['subject_id']??'')===$groupId)unset($pol['policies'][$id]);} dmd_agent_access_write_policies($pol);
    dmd_agent_log('user_group_deleted','warning',array('group_id'=>$groupId,'actor'=>$actor)); return array('ok'=>true);
}

function dmd_agent_remote_permissions_catalog() {
    return array(
        'remote'=>array('label'=>'Remote','permissions'=>array(
            'remote.screen'=>array('label'=>'Voir l’écran','requires'=>'remote.screen'),
            'remote.control'=>array('label'=>'Clavier / souris','requires'=>'remote.control'),
            'remote.clipboard'=>array('label'=>'Presse-papiers','requires'=>'remote.clipboard'),
        )),
        'files'=>array('label'=>'Fichiers','permissions'=>array(
            'files.browse'=>array('label'=>'Parcourir','requires'=>'filesystem.list'),
            'files.download'=>array('label'=>'Télécharger','requires'=>'filesystem.read'),
            'files.upload'=>array('label'=>'Envoyer','requires'=>'filesystem.write'),
            'files.mkdir'=>array('label'=>'Créer un dossier','requires'=>'filesystem.mkdir'),
            'files.delete'=>array('label'=>'Supprimer','requires'=>'filesystem.write'),
            'files.rename'=>array('label'=>'Renommer','requires'=>'filesystem.write'),
        )),
        'software'=>array('label'=>'Logiciels','permissions'=>array(
            'software.view'=>array('label'=>'Voir les logiciels','requires'=>'software.list'),
            'software.uninstall'=>array('label'=>'Désinstaller','requires'=>'software.uninstall'),
            'software.update'=>array('label'=>'Mettre à jour les logiciels','requires'=>'software.update'),
        )),
        'registry'=>array('label'=>'Registre','permissions'=>array(
            'registry.read'=>array('label'=>'Consulter le registre','requires'=>'system.registry.read'),
            'registry.write'=>array('label'=>'Modifier le registre','requires'=>'system.registry.write'),
        )),
        'devices'=>array('label'=>'Périphériques / réseau','permissions'=>array(
            'devices.manage'=>array('label'=>'Gérer USB / lecteurs','requires'=>'system.removable'),
            'network.manage'=>array('label'=>'Gérer les chemins réseau','requires'=>'system.networkpaths'),
        )),
        'maintenance'=>array('label'=>'Sauvegarde / sonde réseau','permissions'=>array(
            'backup.run'=>array('label'=>'Lancer et consulter les sauvegardes','requires'=>'filesystem.read'),
            'network.scan'=>array('label'=>'Lancer et consulter les scans réseau','requires'=>'system.terminal'),
        )),
        'system'=>array('label'=>'Système','permissions'=>array(
            'processes.view'=>array('label'=>'Voir les processus','requires'=>'system.processes'),
            'processes.kill'=>array('label'=>'Arrêter un processus','requires'=>'system.processes'),
            'services.view'=>array('label'=>'Voir les services','requires'=>'system.services'),
            'services.control'=>array('label'=>'Contrôler les services','requires'=>'system.services'),
            'system.terminal'=>array('label'=>'Terminal PowerShell / CMD','requires'=>'system.terminal'),
            'system.update'=>array('label'=>'Mises à jour Windows','requires'=>'system.update'),
            'system.restart'=>array('label'=>'Redémarrer','requires'=>'system.power'),
            'system.shutdown'=>array('label'=>'Éteindre','requires'=>'system.power'),
        )),
    );
}
function dmd_agent_remote_known_permissions() {
    $out=array(); foreach(dmd_agent_remote_permissions_catalog() as $section){foreach($section['permissions'] as $key=>$meta)$out[]=$key;} return $out;
}
function dmd_agent_access_save_policy($policyId,$subjectType,$subjectId,$allPcs,$pcGroupIds,$agentIds,$permissions,$actor) {
    $subjectType=(string)$subjectType; if(!in_array($subjectType,array('user','user_group'),true))return array('ok'=>false,'error'=>'subject_type_invalid');
    $subjectId=trim((string)$subjectId);
    if($subjectType==='user'){if(!dmd_agent_access_user_exists($subjectId))return array('ok'=>false,'error'=>'user_invalid');}
    else{$subjectId=dmd_agent_access_safe_id($subjectId,'UGR');$ugs=dmd_agent_access_read_user_groups();if($subjectId===''||!isset($ugs['groups'][$subjectId]))return array('ok'=>false,'error'=>'user_group_invalid');}
    $policyId=dmd_agent_access_safe_id($policyId,'POL'); if($policyId==='')$policyId=dmd_agent_short_id('POL',8);
    $pcg=dmd_agent_access_read_pc_groups(); $cleanGroups=array(); foreach((array)$pcGroupIds as $id){$id=dmd_agent_access_safe_id($id,'PCG');if($id!==''&&isset($pcg['groups'][$id]))$cleanGroups[]=$id;} $cleanGroups=array_values(array_unique($cleanGroups));
    $known=array_flip(dmd_agent_access_known_agent_ids());$cleanAgents=array();foreach((array)$agentIds as $id){$id=dmd_agent_safe_agent_id($id);if($id!==''&&isset($known[$id]))$cleanAgents[]=$id;}$cleanAgents=array_values(array_unique($cleanAgents));
    $allowed=array_flip(dmd_agent_remote_known_permissions());$cleanPerms=array();foreach((array)$permissions as $perm){$perm=trim((string)$perm);if(isset($allowed[$perm]))$cleanPerms[]=$perm;}$cleanPerms=array_values(array_unique($cleanPerms));
    if(!$allPcs&&!$cleanGroups&&!$cleanAgents)return array('ok'=>false,'error'=>'scope_required'); if(!$cleanPerms)return array('ok'=>false,'error'=>'permissions_required');
    $data=dmd_agent_access_read_policies();$now=gmdate('c');$existing=isset($data['policies'][$policyId])&&is_array($data['policies'][$policyId])?$data['policies'][$policyId]:array();
    $data['policies'][$policyId]=array('policy_id'=>$policyId,'subject_type'=>$subjectType,'subject_id'=>$subjectId,'all_pcs'=>(bool)$allPcs,'pc_group_ids'=>$cleanGroups,'agent_ids'=>$cleanAgents,'permissions'=>$cleanPerms,'enabled'=>true,'created_at'=>isset($existing['created_at'])?$existing['created_at']:$now,'created_by'=>isset($existing['created_by'])?$existing['created_by']:(string)$actor,'updated_at'=>$now,'updated_by'=>(string)$actor);
    if(!dmd_agent_access_write_policies($data))return array('ok'=>false,'error'=>'write_failed'); dmd_agent_log('remote_policy_saved','success',array('policy_id'=>$policyId,'actor'=>$actor,'subject_type'=>$subjectType,'subject_id'=>$subjectId)); return array('ok'=>true,'policy'=>$data['policies'][$policyId]);
}
function dmd_agent_access_delete_policy($policyId,$actor) {
    $policyId=dmd_agent_access_safe_id($policyId,'POL');if($policyId==='')return array('ok'=>false,'error'=>'policy_id_invalid');$d=dmd_agent_access_read_policies();if(!isset($d['policies'][$policyId]))return array('ok'=>false,'error'=>'not_found');unset($d['policies'][$policyId]);if(!dmd_agent_access_write_policies($d))return array('ok'=>false,'error'=>'write_failed');dmd_agent_log('remote_policy_deleted','warning',array('policy_id'=>$policyId,'actor'=>$actor));return array('ok'=>true);
}
function dmd_agent_access_pc_groups_for_agent($agentId) {
    $out=array();$d=dmd_agent_access_read_pc_groups();foreach($d['groups'] as $g){if(is_array($g)&&in_array($agentId,isset($g['agent_ids'])?(array)$g['agent_ids']:array(),true))$out[]=$g;}return $out;
}
function dmd_agent_access_user_group_ids($email) {
    $ids=array();$d=dmd_agent_access_read_user_groups();foreach($d['groups'] as $id=>$g){if(is_array($g)&&in_array($email,isset($g['users'])?(array)$g['users']:array(),true))$ids[]=$id;}return $ids;
}
function dmd_agent_access_policy_matches_agent($p,$agentId) {
    if(!is_array($p)||empty($p['enabled']))return false;if(!empty($p['all_pcs']))return true;if(in_array($agentId,isset($p['agent_ids'])?(array)$p['agent_ids']:array(),true))return true;
    $groups=dmd_agent_access_pc_groups_for_agent($agentId);$ids=array();foreach($groups as $g)$ids[]=$g['group_id'];return (bool)array_intersect($ids,isset($p['pc_group_ids'])?(array)$p['pc_group_ids']:array());
}
function dmd_agent_access_effective_permissions($email,$agentId) {
    $profileFile=DMD_AGENT_ROOT.'/users/profiles/'.basename((string)$email).'/profile/profile.json';$profile=array();if(is_file($profileFile)){$raw=@file_get_contents($profileFile);$profile=json_decode((string)$raw,true);if(!is_array($profile))$profile=array();}
    if((string)(isset($profile['role_system'])?$profile['role_system']:'')==='superadmin')return dmd_agent_remote_known_permissions();
    $userGroups=dmd_agent_access_user_group_ids($email);$out=array();$d=dmd_agent_access_read_policies();foreach($d['policies'] as $p){if(!is_array($p)||empty($p['enabled']))continue;$subjectMatch=(($p['subject_type']??'')==='user'&&strcasecmp((string)($p['subject_id']??''),(string)$email)===0)||(($p['subject_type']??'')==='user_group'&&in_array((string)($p['subject_id']??''),$userGroups,true));if(!$subjectMatch||!dmd_agent_access_policy_matches_agent($p,$agentId))continue;$out=array_merge($out,isset($p['permissions'])?(array)$p['permissions']:array());}return array_values(array_unique($out));
}
function dmd_agent_access_check($email,$agentId,$permission) { return in_array((string)$permission,dmd_agent_access_effective_permissions($email,$agentId),true); }

function dmd_agent_audit_file($auditId) {
    $id=dmd_agent_access_safe_id($auditId,'AUD'); return $id===''?'':DMD_AGENT_VAR.'/audits/'.$id.'.php';
}
function dmd_agent_audit_payload_message($payload) {
    return "DMD-AGENT-AUDIT-V1\n".json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
}
function dmd_agent_audit_collect_events($agentId,$enrollmentId,$limit=80) {
    $events=array();$files=glob(DMD_AGENT_VAR.'/logs/security-*.php')?:array();sort($files,SORT_STRING);
    foreach($files as $file){$raw=@file_get_contents($file);if($raw===false)continue;$raw=dmd_agent_strip_guard($raw);foreach(preg_split('/\\r?\\n/',$raw) as $line){if(trim($line)==='')continue;$row=json_decode($line,true);if(!is_array($row))continue;$blob=json_encode($row,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);if(($agentId!==''&&strpos($blob,$agentId)!==false)||($enrollmentId!==''&&strpos($blob,$enrollmentId)!==false))$events[]=$row;}}
    if(count($events)>$limit)$events=array_slice($events,-$limit);return $events;
}
function dmd_agent_audit_sanitize_snapshot($value, $depth = 0) {
    if ($depth > 8) return '[profondeur limitée]';

    if (is_array($value)) {
        $out = array();

        foreach ($value as $key => $item) {
            $keyString = strtolower((string)$key);

            /*
             * Une archive doit rester exploitable sans devenir un coffre à
             * secrets. Les jetons, nonces, mots de passe et secrets temporaires
             * ne sont jamais copiés dans l'audit.
             */
            if (preg_match('/(?:token|secret|private|password|passwd|authorization|cookie|nonce)/i', $keyString)) {
                continue;
            }

            $out[$key] = dmd_agent_audit_sanitize_snapshot($item, $depth + 1);
        }

        return $out;
    }

    if (is_object($value)) {
        return dmd_agent_audit_sanitize_snapshot((array)$value, $depth + 1);
    }

    if (is_string($value)) {
        if (strlen($value) > 65536) {
            return substr($value, 0, 65536) . "\n[contenu tronqué]";
        }
        return $value;
    }

    if (is_scalar($value) || $value === null) return $value;

    return (string)$value;
}

function dmd_agent_audit_enrollment_snapshot($enrollmentId) {
    $enrollmentId = dmd_agent_safe_enrollment_id($enrollmentId);
    if ($enrollmentId === '') return array();

    $e = dmd_agent_load_enrollment($enrollmentId);
    if (!$e || !is_array($e)) return array();

    $snapshot = array(
        'enrollment_id' => (string)($e['enrollment_id'] ?? $enrollmentId),
        'instance_id' => (string)($e['instance_id'] ?? ''),
        'target_name' => (string)($e['target_name'] ?? ''),
        'created_by' => (string)($e['created_by'] ?? ''),
        'created_at' => (string)($e['created_at'] ?? ''),
        'expires_at' => (string)($e['expires_at'] ?? ''),
        'approval_mode' => (string)($e['approval_mode'] ?? ''),
        'status' => (string)($e['status'] ?? ''),
        'server_url' => (string)($e['server_url'] ?? ''),
        'transport_policy' => (string)($e['transport_policy'] ?? ''),
        'server_endpoints' => isset($e['server_endpoints']) && is_array($e['server_endpoints']) ? $e['server_endpoints'] : array(),
        'install_components' => isset($e['install_components']) && is_array($e['install_components']) ? $e['install_components'] : array(),
        'capabilities' => isset($e['capabilities']) && is_array($e['capabilities']) ? $e['capabilities'] : array(),
        'target_pc_group_id' => (string)($e['target_pc_group_id'] ?? ''),
        'target_pc_group_name' => (string)($e['target_pc_group_name'] ?? ''),
        'assigned_pc_group_id' => (string)($e['assigned_pc_group_id'] ?? ''),
        'assigned_pc_group_name' => (string)($e['assigned_pc_group_name'] ?? ''),
        'assigned_pc_group_at' => (string)($e['assigned_pc_group_at'] ?? ''),
        'proof_verified' => !empty($e['proof_verified']),
        'proof_verified_at' => (string)($e['proof_verified_at'] ?? ''),
        'approved_at' => (string)($e['approved_at'] ?? ''),
        'completed_at' => (string)($e['completed_at'] ?? ''),
        'capabilities_updated_at' => (string)($e['capabilities_updated_at'] ?? ''),
        'capabilities_updated_by' => (string)($e['capabilities_updated_by'] ?? ''),
    );

    return dmd_agent_audit_sanitize_snapshot($snapshot);
}

function dmd_agent_create_revoke_audit($device,$actor,$reason='') {
    if(!is_array($device)||empty($device['agent_id']))return array('ok'=>false,'error'=>'invalid_device');

    $agentId=(string)$device['agent_id'];
    $enrollmentId=(string)($device['enrollment_id'] ?? '');

    $groups=dmd_agent_access_pc_groups_for_agent($agentId);
    $groupSummary=array();
    foreach($groups as $g) {
        if (!is_array($g)) continue;
        $groupSummary[]=array(
            'group_id'=>(string)($g['group_id'] ?? ''),
            'name'=>(string)($g['name'] ?? ''),
            'description'=>(string)($g['description'] ?? ''),
            'created_at'=>(string)($g['created_at'] ?? ''),
            'created_by'=>(string)($g['created_by'] ?? ''),
            'updated_at'=>(string)($g['updated_at'] ?? ''),
            'updated_by'=>(string)($g['updated_by'] ?? ''),
        );
    }

    $certificate = isset($device['certificate']) && is_array($device['certificate'])
        ? dmd_agent_audit_sanitize_snapshot($device['certificate'])
        : array();

    $auditId=dmd_agent_short_id('AUD',10);
    $payload=array(
        'schema'=>2,
        'audit_id'=>$auditId,
        'type'=>'agent_revocation',
        'created_at'=>gmdate('c'),
        'instance_id'=>(string)($device['instance_id'] ?? ''),

        'agent'=>array(
            'agent_id'=>$agentId,
            'status'=>(string)($device['status'] ?? ''),
            'hostname'=>(string)($device['hostname'] ?? ''),
            'enrollment_name'=>dmd_agent_enrollment_name_for_device($device),
            'platform'=>(string)($device['platform'] ?? ''),
            'arch'=>(string)($device['arch'] ?? ''),
            'agent_version'=>(string)($device['agent_version'] ?? ''),
            'device_key_fingerprint'=>(string)($device['device_key_fingerprint'] ?? ''),
            'enrollment_id'=>$enrollmentId,
            'created_at'=>(string)($device['created_at'] ?? ''),
            'last_seen_at'=>(string)($device['last_seen_at'] ?? ''),
            'last_ip'=>(string)($device['last_ip'] ?? ''),
            'hardware'=>isset($device['hardware'])&&is_array($device['hardware'])?dmd_agent_audit_sanitize_snapshot($device['hardware']):array(),
            'last_inventory'=>isset($device['last_inventory'])&&is_array($device['last_inventory'])?dmd_agent_audit_sanitize_snapshot($device['last_inventory']):array(),
            'telemetry'=>isset($device['telemetry'])&&is_array($device['telemetry'])
                ? dmd_agent_audit_sanitize_snapshot($device['telemetry'])
                : (isset($device['last_telemetry'])&&is_array($device['last_telemetry'])
                    ? dmd_agent_audit_sanitize_snapshot($device['last_telemetry'])
                    : array()),
            'network'=>isset($device['network'])&&is_array($device['network'])?dmd_agent_audit_sanitize_snapshot($device['network']):array(),
            'open_ports'=>isset($device['open_ports'])&&is_array($device['open_ports'])
                ? array_slice(dmd_agent_audit_sanitize_snapshot($device['open_ports']),0,512)
                : array(),
            'capabilities'=>isset($device['capabilities'])?(array)$device['capabilities']:array(),
            'reported_capabilities'=>isset($device['reported_capabilities'])?(array)$device['reported_capabilities']:array(),
            'capabilities_updated_at'=>(string)($device['capabilities_updated_at'] ?? ''),
            'capabilities_updated_by'=>(string)($device['capabilities_updated_by'] ?? ''),
            'certificate'=>$certificate,
        ),

        /*
         * Snapshot de l'enrôlement avant purge. Aucun token / secret / nonce
         * n'est conservé.
         */
        'enrollment'=>dmd_agent_audit_enrollment_snapshot($enrollmentId),

        /*
         * Snapshot technique complet de la fiche Device. Cela garantit que
         * les nouveaux champs ajoutés à l'Agent seront automatiquement
         * disponibles dans l'archive sans devoir modifier l'audit à chaque
         * évolution du protocole.
         */
        'device_snapshot'=>dmd_agent_audit_sanitize_snapshot($device),

        'pc_groups'=>$groupSummary,
        'access_policies'=>dmd_agent_access_policy_snapshot_for_agent($agentId),
        'revocation'=>array(
            'revoked_at'=>gmdate('c'),
            'revoked_by'=>(string)$actor,
            'reason'=>dmd_agent_access_clean_description($reason,500)
        ),
        'events'=>dmd_agent_audit_collect_events($agentId,$enrollmentId,120),
    );

    $sig=dmd_agent_sign_message(dmd_agent_audit_payload_message($payload));
    if($sig===false)return array('ok'=>false,'error'=>'audit_sign_failed');

    $bundle=array(
        'schema'=>2,
        'payload'=>$payload,
        'signature_algorithm'=>'Ed25519',
        'signature_format'=>'DMD-AGENT-AUDIT-V1',
        'signature'=>$sig
    );

    $file=dmd_agent_audit_file($auditId);
    if($file===''||!dmd_agent_json_write($file,$bundle,0640))return array('ok'=>false,'error'=>'audit_write_failed');

    dmd_agent_log('agent_revoke_audit_created','success',array(
        'audit_id'=>$auditId,
        'agent_id'=>$agentId,
        'enrollment_id'=>$enrollmentId,
        'schema'=>2,
        'events'=>count($payload['events']),
        'groups'=>count($groupSummary),
        'policies'=>count($payload['access_policies']),
    ));

    return array('ok'=>true,'audit_id'=>$auditId,'bundle'=>$bundle);
}
function dmd_agent_verify_audit_bundle($bundle) {
    if(!is_array($bundle)||!isset($bundle['payload'])||!is_array($bundle['payload'])||($bundle['signature_format']??'')!=='DMD-AGENT-AUDIT-V1')return false;$pub=dmd_agent_load_public_key();$sig=base64_decode((string)($bundle['signature']??''),true);if($pub===''||!is_string($sig))return false;return sodium_crypto_sign_verify_detached($sig,dmd_agent_audit_payload_message($bundle['payload']),$pub);
}
function dmd_agent_list_audits() {
    $out=array();foreach(glob(DMD_AGENT_VAR.'/audits/AUD-*.php')?:array() as $file){$b=dmd_agent_json_read($file,array());if(!$b||empty($b['payload']))continue;$p=$b['payload'];$p['signature_valid']=dmd_agent_verify_audit_bundle($b);$out[]=$p;}usort($out,function($a,$b){return strcmp((string)($b['created_at']??''),(string)($a['created_at']??''));});return $out;
}
function dmd_agent_remove_agent_from_pc_groups($agentId) {
    $d=dmd_agent_access_read_pc_groups();$changed=false;foreach($d['groups'] as $id=>$g){if(!is_array($g))continue;$before=isset($g['agent_ids'])?(array)$g['agent_ids']:array();$after=array_values(array_diff($before,array($agentId)));if($after!==$before){$d['groups'][$id]['agent_ids']=$after;$d['groups'][$id]['updated_at']=gmdate('c');$changed=true;}}if($changed)dmd_agent_access_write_pc_groups($d);
}
function dmd_agent_access_policy_snapshot_for_agent($agentId) {
    $out=array();$d=dmd_agent_access_read_policies();foreach($d['policies'] as $p){if(!is_array($p)||empty($p['enabled'])||!dmd_agent_access_policy_matches_agent($p,$agentId))continue;$out[]=array('policy_id'=>(string)($p['policy_id']??''),'subject_type'=>(string)($p['subject_type']??''),'subject_id'=>(string)($p['subject_id']??''),'all_pcs'=>!empty($p['all_pcs']),'pc_group_ids'=>isset($p['pc_group_ids'])?(array)$p['pc_group_ids']:array(),'direct_agent'=>(bool)in_array($agentId,isset($p['agent_ids'])?(array)$p['agent_ids']:array(),true),'permissions'=>isset($p['permissions'])?(array)$p['permissions']:array());}return $out;
}
function dmd_agent_remove_agent_from_policies($agentId) {
    $d=dmd_agent_access_read_policies();$changed=false;foreach($d['policies'] as $id=>$p){if(!is_array($p))continue;$before=isset($p['agent_ids'])?(array)$p['agent_ids']:array();$after=array_values(array_diff($before,array($agentId)));if($after!==$before){$d['policies'][$id]['agent_ids']=$after;$d['policies'][$id]['updated_at']=gmdate('c');$changed=true;}if(empty($d['policies'][$id]['all_pcs'])&&empty($d['policies'][$id]['agent_ids'])&&empty($d['policies'][$id]['pc_group_ids'])){unset($d['policies'][$id]);$changed=true;}}if($changed)dmd_agent_access_write_policies($d);
}
function dmd_agent_safe_remove_tree($path,$root) {
    $rootReal=realpath($root);$pathReal=realpath($path);if($rootReal===false||$pathReal===false||strpos($pathReal,$rootReal.DIRECTORY_SEPARATOR)!==0)return false;if(is_dir($pathReal)){foreach(scandir($pathReal)?:array() as $n){if($n==='.'||$n==='..')continue;dmd_agent_safe_remove_tree($pathReal.DIRECTORY_SEPARATOR.$n,$rootReal);}return @rmdir($pathReal);}return @unlink($pathReal);
}
function dmd_agent_revoke_device($agentId, $actor, $reason = '') {
    $file = dmd_agent_device_file($agentId);
    if ($file === '' || !is_file($file)) return array('ok' => false, 'error' => 'not_found');
    $device = dmd_agent_json_read($file, array());
    if (!$device) return array('ok' => false, 'error' => 'invalid_device');
    $enrollmentId=isset($device['enrollment_id'])?(string)$device['enrollment_id']:'';
    // Fail closed immediately: from this write onward signed Agent requests are refused.
    $device['status']='revoked';$device['revoked_at']=gmdate('c');$device['revoked_by']=(string)$actor;$device['revocation_reason']=dmd_agent_access_clean_description($reason,500);
    if(!dmd_agent_json_write($file,$device,0640)) return array('ok'=>false,'error'=>'revoke_write_failed');
    $audit=dmd_agent_create_revoke_audit($device,$actor,$reason);
    if(empty($audit['ok'])) { dmd_agent_log('agent_revoked_audit_failed','critical',array('agent_id'=>$agentId,'actor'=>$actor,'error'=>$audit['error']??'audit_failed')); return array('ok'=>false,'error'=>'audit_failed_agent_is_revoked'); }
    dmd_agent_remove_agent_from_pc_groups($agentId); dmd_agent_remove_agent_from_policies($agentId);
    if(!@unlink($file)) return array('ok'=>false,'error'=>'device_delete_failed_agent_is_revoked','audit_id'=>$audit['audit_id']);
    if($enrollmentId!==''){ $ef=dmd_agent_enrollment_file($enrollmentId); if($ef!==''&&is_file($ef)) @unlink($ef); }
    $cmdRoot=DMD_AGENT_VAR.'/commands'; foreach(array($cmdRoot.'/'.$agentId.'.php',$cmdRoot.'/'.$agentId) as $candidate){if(is_file($candidate))@unlink($candidate);elseif(is_dir($candidate))dmd_agent_safe_remove_tree($candidate,$cmdRoot);}
    $remoteRoot=DMD_AGENT_VAR.'/remote'; foreach(array($remoteRoot.'/'.$agentId.'.php',$remoteRoot.'/'.$agentId.'.frame.php',$remoteRoot.'/'.$agentId.'.lock',$remoteRoot.'/'.$agentId.'.inputs.php',$remoteRoot.'/'.$agentId.'.inputs.lock') as $candidate){if(is_file($candidate))@unlink($candidate);}
    dmd_agent_remote_stream_reset_files($agentId);
    dmd_agent_log('agent_revoked_and_purged', 'warning', array('agent_id' => $agentId, 'actor' => $actor, 'audit_id'=>$audit['audit_id'], 'reason'=>dmd_agent_access_clean_description($reason,500)));
    return array('ok' => true,'audit_id'=>$audit['audit_id'],'purged'=>true);
}

function dmd_agent_list_enrollments() {
    $out = array();
    foreach (glob(DMD_AGENT_VAR . '/enrollments/ENR-*.php') ?: array() as $file) {
        $e = dmd_agent_json_read($file, array()); if (!$e) continue;
        if (dmd_agent_enrollment_expired($e) && !in_array($e['status'], array('completed','rejected','expired'), true)) { $e['status'] = 'expired'; dmd_agent_save_enrollment($e); }
        $out[] = $e;
    }
    usort($out, function($a,$b){ return (int)$b['created_ts'] <=> (int)$a['created_ts']; });
    return $out;
}
function dmd_agent_list_devices() {
    $out = array();
    foreach (glob(DMD_AGENT_VAR . '/devices/AGT-*.php') ?: array() as $file) { $d = dmd_agent_json_read($file, array()); if ($d) $out[] = $d; }
    usort($out, function($a,$b){ return strcmp((string)$b['created_at'], (string)$a['created_at']); });
    return $out;
}



function dmd_agent_remote_state_file($agentId) {
    $agentId = dmd_agent_safe_agent_id($agentId);
    return $agentId === '' ? '' : DMD_AGENT_VAR . '/remote/' . $agentId . '.php';
}
function dmd_agent_remote_frame_file($agentId) {
    $agentId = dmd_agent_safe_agent_id($agentId);
    return $agentId === '' ? '' : DMD_AGENT_VAR . '/remote/' . $agentId . '.frame.php';
}

function dmd_agent_remote_stream_dir($agentId) {
    $agentId = dmd_agent_safe_agent_id($agentId);
    return $agentId === '' ? '' : DMD_AGENT_VAR . '/remote/' . $agentId . '.stream';
}
function dmd_agent_remote_stream_reset_files($agentId) {
    $dir = dmd_agent_remote_stream_dir($agentId);
    if ($dir === '') return false;
    if (is_dir($dir)) {
        foreach (array('/*.dmds.php','/*.part.php') as $pattern) {
            foreach (glob($dir . $pattern) ?: array() as $file) @unlink($file);
        }
        @rmdir($dir);
    }
    return true;
}
function dmd_agent_remote_stream_prune($agentId, $keep = 600) {
    $dir = dmd_agent_remote_stream_dir($agentId);
    if ($dir === '' || !is_dir($dir)) return;
    $keep = max(120, min(1200, (int)$keep));
    $files = glob($dir . '/*.dmds.php') ?: array();
    sort($files, SORT_STRING);
    $cut = count($files) - $keep;
    if ($cut > 0) {
        for ($i = 0; $i < $cut; $i++) @unlink($files[$i]);
    }
    $expireBefore = time() - 90;
    foreach (glob($dir . '/*.dmds.php') ?: array() as $file) {
        $mtime = @filemtime($file);
        if ($mtime !== false && $mtime < $expireBefore) @unlink($file);
    }
    $partialExpireBefore = time() - 45;
    foreach (glob($dir . '/*.part.php') ?: array() as $file) {
        $mtime = @filemtime($file);
        if ($mtime !== false && $mtime < $partialExpireBefore) @unlink($file);
    }
}
function dmd_agent_remote_store_stream_packet($agentId, $sessionId, $sequence, $width, $height, $compressed, $keyframe, $control, $baseSequence = 0, $codec = 'dmdstream-key-xor-zlib-v2') {
    $agentId = dmd_agent_safe_agent_id($agentId);
    $sequence = max(1, (int)$sequence);
    $baseSequence = max(1, (int)$baseSequence);
    $width = max(1, min(4096, (int)$width));
    $height = max(1, min(4096, (int)$height));
    $codec = strtolower(trim((string)$codec));
    $h264 = ($codec === 'dmd-h264-annexb-v1');
    if (!$h264 && $codec !== 'dmdstream-key-xor-zlib-v2') return array('ok'=>false,'code'=>'remote_stream_codec_invalid');
    if (!empty($keyframe)) $baseSequence = $sequence;
    if (empty($keyframe) && ($baseSequence < 1 || $baseSequence >= $sequence)) return array('ok'=>false,'code'=>'remote_stream_base_invalid');
    if ($agentId === '' || !is_string($compressed) || strlen($compressed) < 2 || strlen($compressed) > 7340032) {
        return array('ok'=>false,'code'=>'remote_stream_packet_invalid');
    }
    $dir = dmd_agent_remote_stream_dir($agentId);
    if ($dir === '') return array('ok'=>false,'code'=>'remote_stream_dir_invalid');
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return array('ok'=>false,'code'=>'remote_stream_dir_create_failed');

    $result = dmd_agent_remote_with_lock($agentId, function(&$state) use ($agentId,$dir,$sessionId,$sequence,$baseSequence,$width,$height,$compressed,$keyframe,$control,$codec) {
        $current = max(0, (int)($state['sequence'] ?? 0));
        $wasActive = !empty($state['active']) && (time() - (int)($state['updated_ts'] ?? 0)) <= 60;
        $restart = !$wasActive || ($sequence === 1 && $current > 1);
        if ($restart) {
            foreach (glob($dir . '/*.dmds.php') ?: array() as $old) @unlink($old);
            $current = 0;
        }
        if ($sequence <= $current) return array('ok'=>true,'stored'=>false,'stale'=>true,'sequence'=>$current);

        $flag = !empty($keyframe) ? 'K' : 'D';
        $name = sprintf('%020d_%s_B%020d_%dx%d.dmds.php', $sequence, $flag, $baseSequence, $width, $height);
        $packetFile = $dir . '/' . $name;
        if (!dmd_agent_atomic_write($packetFile, dmd_agent_data_guard() . $compressed, 0640)) {
            return array('ok'=>false,'code'=>'remote_stream_store_failed');
        }

        $now = time();
        $state['schema']=3;
        $state['session_id']=substr((string)$sessionId,0,96);
        $state['sequence']=$sequence;
        $state['base_sequence']=$baseSequence;
        $state['width']=$width;
        $state['height']=$height;
        $state['control']=!empty($control);
        $state['active']=true;
        $state['updated_ts']=$now;
        $state['updated_at']=gmdate('c',$now);
        $state['transport']='dmdstream';
        $state['stream_codec']=$codec;
        $state['pixel_format']=$codec === 'dmd-h264-annexb-v1' ? 'H264' : 'BGR24';
        $state['keyframe']=!empty($keyframe);
        $state['frame_bytes']=strlen($compressed);
        $state['frame_received_ms']=(int)round(microtime(true)*1000);
        return array('ok'=>true,'stored'=>true,'stale'=>false,'sequence'=>$sequence,'base_sequence'=>$baseSequence);
    });

    if (is_array($result) && !empty($result['stored']) && (!empty($keyframe) || ($sequence % 24) === 0)) {
        dmd_agent_remote_stream_prune($agentId, 600);
    }
    return is_array($result) ? $result : array('ok'=>false,'code'=>'remote_stream_lock_failed');
}
function dmd_agent_remote_store_stream_chunk($agentId, $sessionId, $sequence, $width, $height, $chunk, $chunkIndex, $chunkCount, $frameSha256, $keyframe, $control, $baseSequence = 0, $codec = 'dmdstream-key-xor-zlib-v2') {
    $agentId = dmd_agent_safe_agent_id($agentId);
    $sequence = max(1, (int)$sequence);
    $baseSequence = max(1, (int)$baseSequence);
    $width = max(1, min(4096, (int)$width));
    $height = max(1, min(4096, (int)$height));
    $chunkIndex = max(0, (int)$chunkIndex);
    $chunkCount = max(1, min(32, (int)$chunkCount));
    $frameSha256 = strtolower(trim((string)$frameSha256));
    $codec = strtolower(trim((string)$codec));
    if (!empty($keyframe)) $baseSequence = $sequence;
    $h264 = ($codec === 'dmd-h264-annexb-v1');
    if (!$h264 && $codec !== 'dmdstream-key-xor-zlib-v2') return array('ok'=>false,'code'=>'remote_stream_codec_invalid');
    if (empty($keyframe) && ($baseSequence < 1 || $baseSequence >= $sequence)) return array('ok'=>false,'code'=>'remote_stream_base_invalid');
    if ($agentId === '' || !is_string($chunk) || strlen($chunk) < 1 || strlen($chunk) > 600000) {
        return array('ok'=>false,'code'=>'remote_stream_chunk_invalid');
    }
    if ($chunkIndex >= $chunkCount || !preg_match('/^[a-f0-9]{64}$/', $frameSha256)) {
        return array('ok'=>false,'code'=>'remote_stream_chunk_metadata_invalid');
    }

    if ($sequence === 1 && $chunkIndex === 0) {
        dmd_agent_remote_stream_reset_files($agentId);
        dmd_agent_remote_with_lock($agentId, function(&$state) {
            $state['sequence'] = 0;
            $state['active'] = false;
            return true;
        });
    }

    $dir = dmd_agent_remote_stream_dir($agentId);
    if ($dir === '') return array('ok'=>false,'code'=>'remote_stream_dir_invalid');
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return array('ok'=>false,'code'=>'remote_stream_dir_create_failed');

    $touch = dmd_agent_remote_with_lock($agentId, function(&$state) use ($sessionId,$sequence,$baseSequence,$width,$height,$control,$codec) {
        $current = max(0, (int)($state['sequence'] ?? 0));
        if ($sequence <= $current) return array('ok'=>true,'stale'=>true,'sequence'=>$current);
        $now = time();
        $state['schema']=3;
        $state['session_id']=substr((string)$sessionId,0,96);
        $state['width']=$width;
        $state['height']=$height;
        $state['control']=!empty($control);
        $state['active']=true;
        $state['updated_ts']=$now;
        $state['updated_at']=gmdate('c',$now);
        $state['transport']='dmdstream';
        $state['stream_codec']=$codec;
        $state['pixel_format']=$codec === 'dmd-h264-annexb-v1' ? 'H264' : 'BGR24';
        $state['pending_sequence']=$sequence;
        $state['pending_base_sequence']=$baseSequence;
        return array('ok'=>true,'stale'=>false,'sequence'=>$current);
    });
    if (!is_array($touch) || empty($touch['ok'])) return array('ok'=>false,'code'=>'remote_stream_lock_failed');
    if (!empty($touch['stale'])) return array('ok'=>true,'stored'=>false,'stale'=>true,'sequence'=>(int)$touch['sequence']);

    $partName = sprintf('%020d_%04dof%04d_%s.part.php', $sequence, $chunkIndex, $chunkCount, $frameSha256);
    $partFile = $dir . '/' . $partName;
    if (!dmd_agent_atomic_write($partFile, dmd_agent_data_guard() . $chunk, 0640)) {
        return array('ok'=>false,'code'=>'remote_stream_chunk_store_failed');
    }

    $parts = array();
    $total = 0;
    for ($i=0; $i<$chunkCount; $i++) {
        $f = $dir . '/' . sprintf('%020d_%04dof%04d_%s.part.php', $sequence, $i, $chunkCount, $frameSha256);
        if (!is_file($f)) return array('ok'=>true,'stored'=>false,'partial'=>true,'stale'=>false,'sequence'=>$sequence,'received'=>$chunkIndex+1,'chunks'=>$chunkCount);
        $raw = @file_get_contents($f);
        if ($raw === false) return array('ok'=>false,'code'=>'remote_stream_chunk_read_failed');
        $raw = dmd_agent_strip_guard($raw);
        if (!is_string($raw) || $raw === '') return array('ok'=>false,'code'=>'remote_stream_chunk_empty');
        $total += strlen($raw);
        if ($total > 7340032) return array('ok'=>false,'code'=>'remote_stream_frame_too_large');
        $parts[] = $raw;
    }
    $compressed = implode('', $parts);
    if (!hash_equals($frameSha256, hash('sha256', $compressed))) {
        foreach (glob($dir . '/' . sprintf('%020d_', $sequence) . '*.part.php') ?: array() as $f) @unlink($f);
        return array('ok'=>false,'code'=>'remote_stream_frame_hash_invalid');
    }

    $stored = dmd_agent_remote_store_stream_packet($agentId, $sessionId, $sequence, $width, $height, $compressed, $keyframe, $control, $baseSequence, $codec);
    foreach (glob($dir . '/' . sprintf('%020d_', $sequence) . '*.part.php') ?: array() as $f) @unlink($f);
    return is_array($stored) ? $stored : array('ok'=>false,'code'=>'remote_stream_store_failed');
}
function dmd_agent_remote_stream_packets($agentId, $after = 0, $limit = 8, $maxBytes = 7340032, $viewerBase = 0, $fresh = false) {
    $agentId = dmd_agent_safe_agent_id($agentId);
    if ($agentId === '') return array();
    $dir = dmd_agent_remote_stream_dir($agentId);
    if ($dir === '' || !is_dir($dir)) return array();
    $after = max(0, (int)$after);
    $viewerBase = max(0, (int)$viewerBase);
    $maxBytes = max(262144, min(8388608, (int)$maxBytes));
    $state = dmd_agent_remote_state($agentId);
    $codec = strtolower(trim((string)($state['stream_codec'] ?? 'dmdstream-key-xor-zlib-v2')));
    $h264 = ($codec === 'dmd-h264-annexb-v1');

    $rows = array();
    foreach (glob($dir . '/*.dmds.php') ?: array() as $file) {
        $base = basename($file);
        if (preg_match('/^(\d{20})_([KD])_B(\d{20})_(\d+)x(\d+)\.dmds\.php$/', $base, $m)) {
            $rows[] = array(
                'file'=>$file,'sequence'=>(int)$m[1],'keyframe'=>$m[2]==='K',
                'base_sequence'=>(int)$m[3],'width'=>(int)$m[4],'height'=>(int)$m[5],
                'stream_codec'=>$codec
            );
        }
    }
    if (!$rows) return array();
    usort($rows, function($a,$b){ return $a['sequence'] <=> $b['sequence']; });

    $selected = array();
    if ($h264) {
        // H.264 est séquentiel : on renvoie plusieurs access-units dans l'ordre.
        // Si le viewer a perdu une séquence, on repart de la dernière IDR.
        $limit = max(1, min(32, (int)$limit));
        $bySeq = array(); $latestSeq = 0;
        foreach ($rows as $row) { $sq=(int)$row['sequence']; $bySeq[$sq]=$row; if($sq>$latestSeq)$latestSeq=$sq; }
        $start = $after + 1;
        if ($after <= 0 || !isset($bySeq[$start])) {
            $keySeq=0;
            foreach ($rows as $row) if(!empty($row['keyframe']) && (int)$row['sequence']>$keySeq) $keySeq=(int)$row['sequence'];
            if($keySeq<1) return array();
            // Nouveau viewer : ne pas rejouer une GOP déjà ancienne. On attend
            // la prochaine IDR si la dernière est trop loin du live-edge. Avec
            // l'IDR périodique DMD-Remote, l'attente reste courte et le viewer
            // rejoint directement le direct au lieu de rattraper des dizaines
            // de paquets historiques.
            if(!empty($fresh) && $after<=0 && ($latestSeq-$keySeq)>8) return array();
            $start=$keySeq;
        }
        for($sq=$start; $sq<=$latestSeq && count($selected)<$limit; $sq++) {
            if(!isset($bySeq[$sq])) break;
            $selected[]=$bySeq[$sq];
        }
    } else {
        // Ancien DMDStream XOR : un delta dépend de sa keyframe de base.
        $latest = null;
        for ($i=count($rows)-1; $i>=0; $i--) {
            if ((int)$rows[$i]['sequence'] > $after) { $latest=$rows[$i]; break; }
        }
        if (!$latest) return array();
        $baseSeq = (int)$latest['base_sequence'];
        if (!empty($latest['keyframe'])) {
            $selected[] = $latest;
        } else {
            if ($viewerBase !== $baseSeq) {
                $key = null;
                for ($i=count($rows)-1; $i>=0; $i--) {
                    if (!empty($rows[$i]['keyframe']) && (int)$rows[$i]['sequence'] === $baseSeq) { $key=$rows[$i]; break; }
                }
                if (!$key) return array();
                $selected[] = $key;
            }
            $selected[] = $latest;
        }
    }

    $out = array();
    $totalBytes = 0;
    foreach ($selected as $row) {
        $raw=@file_get_contents($row['file']);
        if ($raw===false) continue;
        $raw=dmd_agent_strip_guard($raw);
        if (!is_string($raw) || $raw==='') continue;
        $len=strlen($raw);
        if ($out && ($totalBytes+$len)>$maxBytes) break;
        $totalBytes += $len;
        $out[] = array(
            'sequence'=>(int)$row['sequence'],
            'base_sequence'=>(int)$row['base_sequence'],
            'width'=>(int)$row['width'],
            'height'=>(int)$row['height'],
            'keyframe'=>!empty($row['keyframe']),
            'stream_codec'=>(string)$row['stream_codec'],
            'pixel_format'=>$h264 ? 'H264' : 'BGR24',
            'stream_base64'=>base64_encode($raw),
        );
    }
    return $out;
}
function dmd_agent_remote_with_lock($agentId, $callback) {
    $file = dmd_agent_remote_state_file($agentId);
    if ($file === '') return null;
    $lockFile = DMD_AGENT_VAR . '/remote/' . $agentId . '.lock';
    $dir = dirname($lockFile); if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $fh = @fopen($lockFile, 'c+'); if (!$fh) return null;
    if (!@flock($fh, LOCK_EX)) { @fclose($fh); return null; }
    $state = dmd_agent_json_read($file, array('schema'=>1,'agent_id'=>$agentId,'sequence'=>0,'inputs'=>array(),'updated_ts'=>0));
    if (!isset($state['inputs']) || !is_array($state['inputs'])) $state['inputs'] = array();
    $result = call_user_func_array($callback, array(&$state));
    dmd_agent_json_write($file, $state, 0640);
    @flock($fh, LOCK_UN); @fclose($fh);
    return $result;
}
// b5 : la file clavier/souris est physiquement séparée de l'état/frame Remote.
// Le b4 écrivait le fichier d'état ~28 fois/s même quand la file était vide,
// ce qui saturait PHP + le stockage du NAS et finissait par créer plusieurs
// secondes de retard. Ici on n'écrit QUE lorsqu'un évènement existe réellement.
function dmd_agent_remote_inputs_file($agentId) {
    $agentId=dmd_agent_safe_agent_id($agentId);
    return $agentId===''?'':DMD_AGENT_VAR.'/remote/'.$agentId.'.inputs.php';
}
function dmd_agent_remote_inputs_lock_file($agentId) {
    $agentId=dmd_agent_safe_agent_id($agentId);
    return $agentId===''?'':DMD_AGENT_VAR.'/remote/'.$agentId.'.inputs.lock';
}
function dmd_agent_remote_take_inputs($agentId, $limit = 40) {
    $agentId=dmd_agent_safe_agent_id($agentId); $limit=max(1,min(80,(int)$limit));
    if($agentId==='') return array();
    $file=dmd_agent_remote_inputs_file($agentId); $lockFile=dmd_agent_remote_inputs_lock_file($agentId);
    // File absente = file vide : aucun lock, aucune lecture JSON, aucune écriture.
    if(!is_file($file)) return array();
    $dir=dirname($file); if(!is_dir($dir)) @mkdir($dir,0750,true);
    $fh=@fopen($lockFile,'c+'); if(!$fh || !@flock($fh,LOCK_EX)){if($fh)@fclose($fh);return array();}
    $data=is_file($file)?dmd_agent_json_read($file,array('schema'=>1,'inputs'=>array())):array('schema'=>1,'inputs'=>array());
    $all=(isset($data['inputs'])&&is_array($data['inputs']))?$data['inputs']:array();
    if(!$all){if(is_file($file))@unlink($file);@flock($fh,LOCK_UN);@fclose($fh);return array();}
    $inputs=array_slice($all,0,$limit); $remain=array_slice($all,count($inputs));
    if($remain)dmd_agent_json_write($file,array('schema'=>1,'inputs'=>$remain,'updated_ts'=>time()),0640); else @unlink($file);
    @flock($fh,LOCK_UN);@fclose($fh); return $inputs;
}
function dmd_agent_remote_queue_input($agentId, $event) {
    return dmd_agent_remote_queue_inputs($agentId,array($event));
}
function dmd_agent_remote_queue_inputs($agentId, $events) {
    $agentId=dmd_agent_safe_agent_id($agentId);
    if($agentId==='' || !is_array($events) || !$events) return false;
    $events=array_values(array_filter($events,'is_array')); if(!$events)return false;
    if(count($events)>64)$events=array_slice($events,0,64);
    $file=dmd_agent_remote_inputs_file($agentId); $lockFile=dmd_agent_remote_inputs_lock_file($agentId);
    $dir=dirname($file); if(!is_dir($dir)) @mkdir($dir,0750,true);
    $fh=@fopen($lockFile,'c+'); if(!$fh || !@flock($fh,LOCK_EX)){if($fh)@fclose($fh);return false;}
    $data=is_file($file)?dmd_agent_json_read($file,array('schema'=>1,'inputs'=>array())):array('schema'=>1,'inputs'=>array());
    $inputs=(isset($data['inputs'])&&is_array($data['inputs']))?$data['inputs']:array();
    if(count($inputs)>120)$inputs=array_slice($inputs,-80);
    foreach($events as $event){
        $last=count($inputs)-1;
        if(($event['type']??'')==='move' && $last>=0 && (($inputs[$last]['type']??'')==='move'))$inputs[$last]=$event;
        else $inputs[]=$event;
    }
    if(count($inputs)>160)$inputs=array_slice($inputs,-120);
    $ok=dmd_agent_json_write($file,array('schema'=>1,'inputs'=>$inputs,'updated_ts'=>time()),0640)!==false;
    @flock($fh,LOCK_UN);@fclose($fh); return $ok;
}
function dmd_agent_remote_control_request_id($requestId) {
    $requestId = trim((string)$requestId);
    return preg_match('/^[A-Za-z0-9_-]{8,96}$/', $requestId) ? $requestId : '';
}
function dmd_agent_remote_control_result_file($agentId, $requestId) {
    $agentId=dmd_agent_safe_agent_id($agentId); $requestId=dmd_agent_remote_control_request_id($requestId);
    if($agentId===''||$requestId==='')return '';
    return DMD_AGENT_VAR.'/remote-control/'.$agentId.'/'.$requestId.'.php';
}
function dmd_agent_remote_control_result_write($agentId,$requestId,$ok,$result=null,$error='') {
    $file=dmd_agent_remote_control_result_file($agentId,$requestId); if($file==='')return false;
    $dir=dirname($file); if(!is_dir($dir))@mkdir($dir,0750,true);
    foreach(glob($dir.'/*.php')?:array() as $old){ if(@filemtime($old)!==false && time()-@filemtime($old)>180)@unlink($old); }
    return dmd_agent_json_write($file,array('schema'=>1,'ready'=>true,'ok'=>(bool)$ok,'result'=>$result,'error'=>substr((string)$error,0,1200),'updated_ts'=>time()),0640)!==false;
}
function dmd_agent_remote_control_result_read($agentId,$requestId,$consume=false) {
    $file=dmd_agent_remote_control_result_file($agentId,$requestId); if($file===''||!is_file($file))return array('ready'=>false);
    $row=dmd_agent_json_read($file,array('ready'=>false)); if($consume)@unlink($file); return $row;
}

function dmd_agent_remote_state($agentId) {
    $file=dmd_agent_remote_state_file($agentId); if($file===''||!is_file($file)) return array();
    $state=dmd_agent_json_read($file,array()); if(!$state) return array();
    $state['active']=!empty($state['active']) && (time()-(int)($state['updated_ts']??0))<=60;
    unset($state['inputs']); return $state;
}
function dmd_agent_remote_stop_state($agentId) {
    $result=dmd_agent_remote_with_lock($agentId,function(&$state){$state['active']=false;$state['updated_ts']=time();$state['updated_at']=gmdate('c');$state['inputs']=array();return true;});
    $inputFile=dmd_agent_remote_inputs_file($agentId); if($inputFile!==''&&is_file($inputFile))@unlink($inputFile);
    dmd_agent_remote_stream_reset_files($agentId);
    return $result;
}


function dmd_agent_mydesk_manifest_modules() {
    // DMD-MyDesk 1.4.0 : découverte 100 % dynamique.
    // AUCUN module n'est connu en dur. Le seul indicateur est le manifeste :
    //   "mydesk_compatible": true
    // accompagné du bloc racine "mydesk".
    $root = DMD_AGENT_ROOT . '/modules';
    $out = array();
    if (!is_dir($root)) return $out;
    $items = @scandir($root);
    if (!is_array($items)) return $out;
    foreach ($items as $folder) {
        if ($folder === '.' || $folder === '..' || $folder === '' || $folder[0] === '.') continue;
        $dir = $root . '/' . $folder;
        if (!is_dir($dir)) continue;
        $file = $dir . '/dmd_module.json';
        if (!is_file($file)) continue;
        $manifest = json_decode((string)@file_get_contents($file), true);
        if (!is_array($manifest) || ($manifest['mydesk_compatible'] ?? false) !== true) continue;
        $id = trim((string)($manifest['id'] ?? ''));
        $mydesk = isset($manifest['mydesk']) && is_array($manifest['mydesk']) ? $manifest['mydesk'] : array();
        if ($id === '' || !$mydesk) continue;
        $entry = str_replace('\\', '/', trim((string)($mydesk['entrypoint'] ?? '')));
        if ($entry === '' || strpos($entry, '..') !== false || $entry[0] === '/' || !is_file($dir . '/' . $entry)) continue;
        $label = trim((string)($mydesk['label'] ?? ($manifest['name'] ?? $id)));
        if ($label === '') $label = $id;
        $icon = str_replace('\\', '/', trim((string)($mydesk['icon'] ?? (is_file($dir.'/icon.png') ? 'icon.png' : ''))));
        if ($icon !== '' && (strpos($icon, '..') !== false || $icon[0] === '/' || !is_file($dir.'/'.$icon))) $icon = '';
        $window = isset($mydesk['window']) && is_array($mydesk['window']) ? $mydesk['window'] : array();
        $features = array();
        foreach ((array)($mydesk['features'] ?? array()) as $feature) {
            $feature = strtolower(trim((string)$feature));
            if ($feature !== '' && preg_match('/^[a-z0-9._-]{1,64}$/',$feature)) $features[$feature] = true;
        }
        $out[$id] = array(
            'id'=>$id,
            'folder'=>$folder,
            'label'=>$label,
            'description'=>trim((string)($manifest['description'] ?? '')),
            'entrypoint'=>$entry,
            'icon'=>$icon,
            'presentation'=>trim((string)($mydesk['presentation'] ?? 'window')) ?: 'window',
            'min_runtime'=>trim((string)($mydesk['min_runtime'] ?? '1.4.0')) ?: '1.4.0',
            'features'=>array_keys($features),
            'window'=>$window,
            'default_view'=>'compact',
        );
    }
    ksort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}
function dmd_agent_mydesk_settings_file() { return DMD_AGENT_VAR . '/mydesk/settings.php'; }
function dmd_agent_mydesk_settings_read() {
    $d = dmd_agent_json_read(dmd_agent_mydesk_settings_file(), array());
    if (!isset($d['modules']) || !is_array($d['modules'])) $d['modules'] = array();
    return $d;
}
function dmd_agent_mydesk_module_enabled($module, $settings = null) {
    if (!is_array($module) || empty($module['id'])) return false;
    if (!is_array($settings)) $settings = dmd_agent_mydesk_settings_read();
    $id = (string)$module['id'];
    if (array_key_exists($id, $settings['modules'])) return !empty($settings['modules'][$id]);
    // Un module compatible n'est JAMAIS activé automatiquement : seul le
    // Superadmin l'active explicitement dans Administration > DMD-MyDesk.
    return false;
}
function dmd_agent_mydesk_license_limit() {
    if (!function_exists('dmd_license_quota')) return 5;
    return (int)dmd_license_quota('dmd_mydesk','modules_max',0);
}
function dmd_agent_mydesk_license_state() {
    return function_exists('dmd_license_status') ? dmd_license_status() : array('ok'=>true,'source'=>'launch','state'=>'launch','entitlements'=>array('dmd_mydesk'=>array('enabled'=>true,'modules_max'=>5)));
}
function dmd_agent_mydesk_settings_save($enabledIds, $actor) {
    $catalog = dmd_agent_mydesk_manifest_modules();
    $wanted = array();
    foreach ((array)$enabledIds as $id) { $id = trim((string)$id); if (isset($catalog[$id])) $wanted[$id] = true; }
    $limit = dmd_agent_mydesk_license_limit();
    if ($limit < 0) $limit = PHP_INT_MAX;
    if (count($wanted) > $limit) {
        dmd_agent_log('mydesk_license_limit_exceeded','warning',array('selected'=>count($wanted),'allowed'=>$limit,'actor'=>(string)$actor));
        return array('ok'=>false,'error'=>'mydesk_module_limit_exceeded','selected'=>count($wanted),'allowed'=>$limit);
    }
    $map = array(); foreach ($catalog as $id=>$module) $map[$id] = isset($wanted[$id]);
    $data = array('schema'=>2,'modules'=>$map,'updated_at'=>gmdate('c'),'updated_by'=>(string)$actor);
    if (!dmd_agent_json_write(dmd_agent_mydesk_settings_file(), $data, 0640)) return array('ok'=>false,'error'=>'write_failed');
    dmd_agent_log('mydesk_settings_updated','success',array('enabled_modules'=>array_keys($wanted),'updated_by'=>(string)$actor,'license_limit'=>$limit));
    return array('ok'=>true,'settings'=>$data,'selected'=>count($wanted),'allowed'=>$limit);
}
function dmd_agent_mydesk_device_enabled($device) {
    $caps = array_unique(array_merge(isset($device['capabilities'])&&is_array($device['capabilities'])?$device['capabilities']:array(), isset($device['reported_capabilities'])&&is_array($device['reported_capabilities'])?$device['reported_capabilities']:array()));
    return in_array('mydesk.client', $caps, true);
}
function dmd_agent_mydesk_runtime_context($body) {
    $body = is_array($body) ? $body : array();
    $version = trim((string)($body['runtime_version'] ?? '1.4.0'));
    if ($version === '') $version = '1.4.0';
    $features = isset($body['runtime_features']) && is_array($body['runtime_features']) ? $body['runtime_features'] : array();
    $clean = array();
    foreach ($features as $feature) {
        $feature = strtolower(trim((string)$feature));
        if ($feature !== '' && preg_match('/^[a-z0-9._-]{1,64}$/',$feature)) $clean[$feature] = true;
    }
    return array('version'=>$version,'features'=>array_keys($clean));
}
function dmd_agent_mydesk_module_runtime_compatible($module, $client) {
    if (!is_array($module) || !is_array($client)) return false;
    $clientVersion = trim((string)($client['version'] ?? ''));
    $minRuntime = trim((string)($module['min_runtime'] ?? '1.4.0'));
    if ($clientVersion === '' || !preg_match('/^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$/',$clientVersion)) return false;
    if ($minRuntime !== '' && version_compare($clientVersion,$minRuntime,'<')) return false;
    $have = array_fill_keys((array)($client['features'] ?? array()), true);
    foreach ((array)($module['features'] ?? array()) as $feature) {
        $feature = strtolower(trim((string)$feature));
        if ($feature !== '' && empty($have[$feature])) return false;
    }
    return true;
}
function dmd_agent_mydesk_public_catalog($device = array(), $client = array()) {
    $settings = dmd_agent_mydesk_settings_read(); $out = array();
    $limit = dmd_agent_mydesk_license_limit();
    // Fail closed sur la configuration GLOBALE, avant tout filtrage par runtime.
    // Ainsi une configuration altérée à 500 modules ne peut pas être masquée en
    // renvoyant seulement quelques modules compatibles à un client donné.
    $configured = dmd_agent_mydesk_selected_count($settings);
    if ($limit >= 0 && $configured > $limit) {
        dmd_agent_log('mydesk_catalog_fail_closed','critical',array('configured'=>$configured,'licensed'=>$limit));
        return array();
    }
    foreach (dmd_agent_mydesk_manifest_modules() as $module) {
        if (!dmd_agent_mydesk_module_enabled($module, $settings)) continue;
        if (!dmd_agent_mydesk_module_runtime_compatible($module, $client)) continue;
        $out[] = array('id'=>$module['id'],'label'=>$module['label'],'description'=>$module['description'],'icon'=>$module['icon'],'presentation'=>$module['presentation'],'window'=>$module['window'],'default_view'=>'compact','min_runtime'=>$module['min_runtime'],'features'=>$module['features']);
    }
    if ($limit >= 0 && count($out) > $limit) {
        dmd_agent_log('mydesk_catalog_fail_closed','critical',array('configured'=>$configured,'returned'=>count($out),'licensed'=>$limit));
        return array();
    }
    return $out;
}
function dmd_agent_mydesk_launch_token_create($device, $moduleId, $client = array()) {
    $catalog = dmd_agent_mydesk_manifest_modules(); $settings = dmd_agent_mydesk_settings_read();
    if (!isset($catalog[$moduleId]) || !dmd_agent_mydesk_module_enabled($catalog[$moduleId], $settings)) return array('ok'=>false,'error'=>'module_not_available');
    if (!dmd_agent_mydesk_module_runtime_compatible($catalog[$moduleId], $client)) return array('ok'=>false,'error'=>'mydesk_runtime_incompatible');
    $token = dmd_agent_b64url_encode(random_bytes(32)); $hash = hash('sha256',$token); $now=time();
    $row = array('schema'=>1,'token_hash'=>$hash,'agent_id'=>(string)$device['agent_id'],'hostname'=>(string)(isset($device['hostname'])?$device['hostname']:''),'module_id'=>$moduleId,'created_at'=>gmdate('c',$now),'created_ts'=>$now,'expires_ts'=>$now+900);
    $file = DMD_AGENT_VAR . '/mydesk/tokens/TOK-' . strtoupper($hash) . '.php';
    if (!dmd_agent_json_write($file,$row,0640)) return array('ok'=>false,'error'=>'token_write_failed');
    $enrollment = !empty($device['enrollment_id']) ? dmd_agent_load_enrollment($device['enrollment_id']) : array();
    $serverUrl = rtrim((string)(isset($enrollment['server_url'])?$enrollment['server_url']:''),'/');
    if ($serverUrl === '') return array('ok'=>false,'error'=>'server_url_missing');
    return array('ok'=>true,'launch_url'=>$serverUrl.'/mydesk/launch.php?token='.rawurlencode($token));
}
function dmd_agent_mydesk_launch_token_peek($token) {
    $token=trim((string)$token); if (!preg_match('/^[A-Za-z0-9_-]{30,100}$/',$token)) return array();
    $hash=hash('sha256',$token); $file=DMD_AGENT_VAR.'/mydesk/tokens/TOK-'.strtoupper($hash).'.php'; $row=dmd_agent_json_read($file,array());
    if (!$row || empty($row['token_hash']) || !hash_equals((string)$row['token_hash'],$hash) || (int)(isset($row['expires_ts'])?$row['expires_ts']:0)<time()) { if(is_file($file))@unlink($file); return array(); }
    $row['_file']=$file; return $row;
}
function dmd_agent_mydesk_launch_token_consume($token) { $row=dmd_agent_mydesk_launch_token_peek($token); if($row&&!empty($row['_file'])) @unlink($row['_file']); return $row; }


/**
 * Associe temporairement un compte DoMyDesk à l'Agent depuis lequel MyDesk vient
 * d'être ouvert. Cette association permet aux notifications ciblées utilisateur
 * d'être remises au poste sans donner au service Agent le mot de passe/session Web.
 */
function dmd_agent_mydesk_session_link($agentId, $email, $ttl = 28800) {
    $agentId = trim((string)$agentId); $email = strtolower(trim((string)$email));
    if ($agentId === '' || $email === '') return false;
    $ttl = max(300, min(86400, (int)$ttl));
    $file = DMD_AGENT_VAR . '/mydesk/sessions/SES-' . strtoupper(hash('sha256', $agentId)) . '.php';
    return dmd_agent_json_write($file, array(
        'schema'=>1, 'agent_id'=>$agentId, 'user_email'=>$email,
        'linked_ts'=>time(), 'expires_ts'=>time()+$ttl,
    ), 0640);
}
function dmd_agent_mydesk_session_user($agentId) {
    $agentId = trim((string)$agentId); if ($agentId === '') return '';
    $file = DMD_AGENT_VAR . '/mydesk/sessions/SES-' . strtoupper(hash('sha256', $agentId)) . '.php';
    $row = dmd_agent_json_read($file, array());
    if (!$row || (string)($row['agent_id'] ?? '') !== $agentId || (int)($row['expires_ts'] ?? 0) < time()) { @unlink($file); return ''; }
    return strtolower(trim((string)($row['user_email'] ?? '')));
}

/**
 * API générique pour les modules : crée une notification native DMD-MyDesk.
 * Cible possible : agent_id, user_email, ou les deux.
 * Aucun module n'est codé en dur dans DMD-Agent.
 */
function dmd_agent_mydesk_notify($agentId, $moduleId, $title, $message, $options = array()) {
    $agentId = trim((string)$agentId); $moduleId = trim((string)$moduleId);
    $title = trim((string)$title); $message = trim((string)$message);
    $options = is_array($options) ? $options : array();
    $userEmail = strtolower(trim((string)($options['user_email'] ?? '')));
    if ($agentId === '' && $userEmail === '') return array('ok'=>false,'error'=>'target_required');
    if ($title === '') $title = 'DMD-MyDesk';
    if (function_exists('mb_substr')) { $title = mb_substr($title,0,80,'UTF-8'); $message = mb_substr($message,0,500,'UTF-8'); }
    else { $title = substr($title,0,160); $message = substr($message,0,1000); }
    if ($moduleId !== '') {
        $mods = dmd_agent_mydesk_manifest_modules();
        if (!isset($mods[$moduleId])) return array('ok'=>false,'error'=>'module_unknown');
    }
    try { $id = 'NTF-' . strtoupper(bin2hex(random_bytes(12))); }
    catch (Throwable $e) { $id = 'NTF-' . strtoupper(hash('sha256', uniqid('',true).mt_rand())); }
    $ttl = max(60, min(604800, (int)($options['expires_in'] ?? 86400)));
    $row = array(
        'schema'=>1, 'id'=>$id, 'agent_id'=>$agentId, 'user_email'=>$userEmail,
        'module_id'=>$moduleId, 'title'=>$title, 'message'=>$message,
        'created_ts'=>time(), 'created_at'=>gmdate('c'), 'expires_ts'=>time()+$ttl,
    );
    $file = DMD_AGENT_VAR . '/mydesk/notifications/' . $id . '.php';
    if (!dmd_agent_json_write($file, $row, 0640)) return array('ok'=>false,'error'=>'write_failed');
    return array('ok'=>true,'id'=>$id);
}
function dmd_agent_mydesk_notification_matches_agent($row, $agentId) {
    if (!is_array($row)) return false;
    $targetAgent = trim((string)($row['agent_id'] ?? ''));
    if ($targetAgent !== '' && hash_equals($targetAgent, (string)$agentId)) return true;
    $targetUser = strtolower(trim((string)($row['user_email'] ?? '')));
    if ($targetUser === '') return false;
    $linked = dmd_agent_mydesk_session_user($agentId);
    return $linked !== '' && hash_equals($targetUser, $linked);
}
function dmd_agent_mydesk_notifications_for_agent($agentId, $limit = 5) {
    $agentId = trim((string)$agentId); if ($agentId === '') return array();
    $limit = max(1,min(20,(int)$limit)); $dir = DMD_AGENT_VAR . '/mydesk/notifications';
    if (!is_dir($dir)) @mkdir($dir,0750,true);
    $rows = array();
    foreach ((array)glob($dir.'/NTF-*.php') as $file) {
        $row = dmd_agent_json_read($file,array());
        if (!$row) { @unlink($file); continue; }
        if ((int)($row['expires_ts'] ?? 0) < time()) { @unlink($file); continue; }
        if (!dmd_agent_mydesk_notification_matches_agent($row,$agentId)) continue;
        $rows[] = $row;
    }
    usort($rows,function($a,$b){ return ((int)($a['created_ts'] ?? 0)) <=> ((int)($b['created_ts'] ?? 0)); });
    $rows = array_slice($rows,0,$limit); $out=array();
    foreach ($rows as $row) $out[] = array(
        'id'=>(string)($row['id'] ?? ''), 'module_id'=>(string)($row['module_id'] ?? ''),
        'title'=>(string)($row['title'] ?? 'DMD-MyDesk'), 'message'=>(string)($row['message'] ?? ''),
        'created_at'=>(string)($row['created_at'] ?? ''),
    );
    return $out;
}
function dmd_agent_mydesk_notifications_ack($agentId, $ids) {
    $agentId=trim((string)$agentId); $ids=is_array($ids)?array_slice($ids,0,20):array(); $done=0;
    foreach ($ids as $id) {
        $id=trim((string)$id); if (!preg_match('/^NTF-[A-F0-9]{16,80}$/',$id)) continue;
        $file=DMD_AGENT_VAR.'/mydesk/notifications/'.$id.'.php'; $row=dmd_agent_json_read($file,array());
        if (!$row || !dmd_agent_mydesk_notification_matches_agent($row,$agentId)) continue;
        if (@unlink($file)) $done++;
    }
    return $done;
}


/* DMD-MyDesk 1.4.0 dépend exclusivement de l'identité DMD-Agent. */

function dmd_agent_signed_request_message($method, $path, $instanceId, $agentId, $timestamp, $nonce, $bodyRaw) {
    return "DMD-AGENT-REQUEST-V1\n"
        . strtoupper((string)$method) . "\n"
        . (string)$path . "\n"
        . (string)$instanceId . "\n"
        . (string)$agentId . "\n"
        . (int)$timestamp . "\n"
        . (string)$nonce . "\n"
        . hash('sha256', (string)$bodyRaw);
}
function dmd_agent_signed_response_message($instanceId, $agentId, $requestNonce, $serverTime, $bodyRaw) {
    return "DMD-AGENT-RESPONSE-V1\n"
        . (string)$instanceId . "\n"
        . (string)$agentId . "\n"
        . (string)$requestNonce . "\n"
        . (int)$serverTime . "\n"
        . hash('sha256', (string)$bodyRaw);
}
function dmd_agent_signed_request_validate($payload, $method, $path, $ip) {
    if (!is_array($payload)) return dmd_agent_api_result(false, 400, 'signed_request_invalid');
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return dmd_agent_api_result(false, 503, 'instance_identity_invalid');
    if ((int)(isset($payload['schema'])?$payload['schema']:0) !== 1 || (int)(isset($payload['protocol_version'])?$payload['protocol_version']:0) !== DMD_AGENT_PROTOCOL) return dmd_agent_api_result(false, 400, 'protocol_invalid');
    $instanceId = trim((string)(isset($payload['instance_id'])?$payload['instance_id']:''));
    if (!hash_equals((string)$identity['manifest']['instance_id'], $instanceId)) return dmd_agent_api_result(false, 403, 'instance_mismatch');
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id'])?$payload['agent_id']:'');
    if ($agentId === '') return dmd_agent_api_result(false, 400, 'agent_id_invalid');
    $file = dmd_agent_device_file($agentId);
    if ($file === '' || !is_file($file)) return dmd_agent_api_result(false, 404, 'agent_unknown');
    $device = dmd_agent_json_read($file, array());
    if (!$device) return dmd_agent_api_result(false, 403, 'agent_invalid');
    if ((string)(isset($device['status'])?$device['status']:'') !== 'active') return dmd_agent_api_result(false, 403, 'agent_revoked');
    if (!hash_equals((string)$device['instance_id'], $instanceId)) return dmd_agent_api_result(false, 403, 'device_instance_mismatch');
    $timestamp = (int)(isset($payload['timestamp'])?$payload['timestamp']:0);
    if ($timestamp <= 0 || abs(time() - $timestamp) > 300) return dmd_agent_api_result(false, 401, 'timestamp_out_of_range');
    $nonce = trim((string)(isset($payload['nonce'])?$payload['nonce']:''));
    if (!preg_match('/^[A-Za-z0-9_-]{16,96}$/', $nonce)) return dmd_agent_api_result(false, 400, 'nonce_invalid');
    $recent = isset($device['recent_nonces']) && is_array($device['recent_nonces']) ? $device['recent_nonces'] : array();
    $now = time(); $filtered = array();
    foreach ($recent as $row) {
        if (!is_array($row) || empty($row['nonce']) || empty($row['ts'])) continue;
        if (($now - (int)$row['ts']) <= 600) {
            if (hash_equals((string)$row['nonce'], $nonce)) return dmd_agent_api_result(false, 409, 'nonce_replayed');
            $filtered[] = $row;
        }
    }
    $bodyB64 = (string)(isset($payload['body_b64'])?$payload['body_b64']:'');
    $bodyRaw = dmd_agent_b64url_decode($bodyB64);
    $maxSignedBody = ((string)$path === '/adm/agent/api/agent_remote.php') ? 1700000 : (in_array((string)$path, array('/adm/agent/api/agent_commands.php','/adm/agent/api/agent_heartbeat.php'), true) ? 786432 : 65536);
    if (!is_string($bodyRaw) || strlen($bodyRaw) > $maxSignedBody) return dmd_agent_api_result(false, 400, 'body_invalid');
    $body = json_decode($bodyRaw, true);
    if (!is_array($body)) return dmd_agent_api_result(false, 400, 'body_json_invalid');
    if ((string)(isset($payload['signature_format'])?$payload['signature_format']:'') !== 'DMD-AGENT-REQUEST-V1') return dmd_agent_api_result(false, 400, 'signature_format_invalid');
    $sig = base64_decode((string)(isset($payload['signature'])?$payload['signature']:''), true);
    $pub = base64_decode((string)(isset($device['device_public_key'])?$device['device_public_key']:''), true);
    if (!is_string($sig) || !is_string($pub) || strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES) return dmd_agent_api_result(false, 403, 'signature_invalid');
    $msg = dmd_agent_signed_request_message($method, $path, $instanceId, $agentId, $timestamp, $nonce, $bodyRaw);
    if (!sodium_crypto_sign_verify_detached($sig, $msg, $pub)) {
        dmd_agent_log('agent_signed_request_invalid', 'critical', array('agent_id'=>$agentId,'ip'=>$ip));
        return dmd_agent_api_result(false, 403, 'signature_invalid');
    }
    $filtered[] = array('nonce'=>$nonce,'ts'=>$now);
    if (count($filtered) > 24) $filtered = array_slice($filtered, -24);
    $device['recent_nonces'] = $filtered;
    return array('ok'=>true,'device'=>$device,'device_file'=>$file,'body'=>$body,'body_raw'=>$bodyRaw,'nonce'=>$nonce,'agent_id'=>$agentId,'instance_id'=>$instanceId);
}
function dmd_agent_signed_response($agentId, $requestNonce, $body) {
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return dmd_agent_api_result(false, 503, 'instance_identity_invalid');
    $bodyRaw = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($bodyRaw === false) return dmd_agent_api_result(false, 500, 'response_encode_failed');
    $serverTime = time();
    $signature = dmd_agent_sign_message(dmd_agent_signed_response_message($identity['manifest']['instance_id'], $agentId, $requestNonce, $serverTime, $bodyRaw));
    if ($signature === false) return dmd_agent_api_result(false, 500, 'response_sign_failed');
    return array(
        'ok'=>true,
        '_http'=>200,
        'schema'=>1,
        'protocol_version'=>DMD_AGENT_PROTOCOL,
        'instance_id'=>$identity['manifest']['instance_id'],
        'agent_id'=>$agentId,
        'request_nonce'=>$requestNonce,
        'server_time'=>$serverTime,
        'body_b64'=>dmd_agent_b64url_encode($bodyRaw),
        'signature_format'=>'DMD-AGENT-RESPONSE-V1',
        'signature'=>$signature,
    );
}


function dmd_agent_self_test() {
    $identity = dmd_agent_ensure_instance_identity();
    if (empty($identity['ok'])) return array('ok' => false, 'stage' => 'identity', 'details' => $identity);
    $created = dmd_agent_create_enrollment('self-test', 'DMD-SELFTEST', 5, 'auto', array('core.heartbeat'), 'https://selftest.invalid/domydesk');
    if (empty($created['ok'])) return array('ok' => false, 'stage' => 'create_enrollment', 'details' => $created);
    $enr = $created['enrollment']['enrollment_id']; $token = $created['token'];
    $kp = sodium_crypto_sign_keypair(); $secret = sodium_crypto_sign_secretkey($kp); $public = sodium_crypto_sign_publickey($kp); $pubB64 = base64_encode($public);
    $basePayload = array('instance_id' => $identity['manifest']['instance_id'], 'enrollment_id' => $enr, 'enrollment_token' => $token, 'device_public_key' => $pubB64);
    $start = dmd_agent_enroll_start(array_merge($basePayload, array('hostname' => 'SELFTEST-PC', 'platform' => 'test', 'arch' => 'amd64', 'agent_version' => 'selftest')), '127.0.0.1');
    if (empty($start['ok'])) return array('ok' => false, 'stage' => 'start', 'details' => $start);
    $e = dmd_agent_load_enrollment($enr); $proof = base64_encode(sodium_crypto_sign_detached(dmd_agent_challenge_message($e), $secret));
    $finish = dmd_agent_enroll_finish(array_merge($basePayload, array('challenge_id' => $start['challenge_id'], 'signature' => $proof)), '127.0.0.1');
    if (empty($finish['ok']) || $finish['code'] !== 'approved') return array('ok' => false, 'stage' => 'finish', 'details' => $finish);
    $e = dmd_agent_load_enrollment($enr); $completeSig = base64_encode(sodium_crypto_sign_detached(dmd_agent_completion_message($e), $secret));
    $complete = dmd_agent_enroll_complete(array_merge($basePayload, array('signature' => $completeSig)), '127.0.0.1');
    if (empty($complete['ok']) || $complete['code'] !== 'completed') return array('ok' => false, 'stage' => 'complete', 'details' => $complete);
    $agentId = $complete['agent_id'];
    @unlink(dmd_agent_enrollment_file($enr)); @unlink(dmd_agent_device_file($agentId));
    dmd_agent_log('secure_enrollment_self_test', 'success');
    return array('ok' => true, 'stages' => array('identity' => 'ok','create' => 'ok','challenge' => 'ok','proof_of_possession' => 'ok','certificate' => 'ok','token_destruction' => 'ok','cleanup' => 'ok'));
}

// Command queue helpers are part of the Agent core contract.
// Keep this include at the end so every consumer of agent_core.php (heartbeat, module, admin APIs) gets the same command functions.
require_once __DIR__ . '/agent_commands.php';

/**
 * Politique d'avertissement local lors d'une session DMD-Remote.
 * Stockée côté DoMyDesk uniquement et injectée dans la commande signée Remote.
 */
function dmd_agent_remote_notice_settings_defaults() {
    return array(
        'version' => 1,
        'enabled' => true,
        'show_on_view' => false,
        'show_operator' => true,
        'updated_at' => '',
        'updated_by' => '',
    );
}
function dmd_agent_remote_notice_settings_file() {
    return DMD_AGENT_VAR . '/security/remote_notice.php';
}
function dmd_agent_remote_notice_settings_read() {
    $out = dmd_agent_remote_notice_settings_defaults();
    $data = dmd_agent_json_read(dmd_agent_remote_notice_settings_file(), array());
    if (!is_array($data)) return $out;
    $out['enabled'] = !array_key_exists('enabled', $data) || !empty($data['enabled']);
    $out['show_on_view'] = !empty($data['show_on_view']);
    $out['show_operator'] = !array_key_exists('show_operator', $data) || !empty($data['show_operator']);
    $out['updated_at'] = trim((string)($data['updated_at'] ?? ''));
    $out['updated_by'] = trim((string)($data['updated_by'] ?? ''));
    return $out;
}
function dmd_agent_remote_notice_settings_write($settings, $updatedBy = '') {
    $clean = dmd_agent_remote_notice_settings_defaults();
    $clean['enabled'] = !empty($settings['enabled']);
    $clean['show_on_view'] = !empty($settings['show_on_view']);
    $clean['show_operator'] = !array_key_exists('show_operator', (array)$settings) || !empty($settings['show_operator']);
    $clean['updated_at'] = gmdate('c');
    $clean['updated_by'] = trim((string)$updatedBy);
    $ok = dmd_agent_json_write(dmd_agent_remote_notice_settings_file(), $clean, 0640);
    return array('ok'=>(bool)$ok,'settings'=>$clean,'error'=>$ok?'':'write_failed');
}
