<?php
if (!defined('DMD_AGENT_VAR')) require_once __DIR__ . '/agent_core.php';

if (!function_exists('dmd_agent_update_job_dir')) {
    function dmd_agent_update_job_dir() {
        return DMD_AGENT_VAR . '/update_jobs';
    }
}
if (!function_exists('dmd_agent_update_job_file')) {
    function dmd_agent_update_job_file($agentId) {
        $agentId = dmd_agent_safe_agent_id($agentId);
        return $agentId === '' ? '' : dmd_agent_update_job_dir() . '/' . $agentId . '.php';
    }
}
if (!function_exists('dmd_agent_update_job_read')) {
    function dmd_agent_update_job_read($agentId) {
        $file = dmd_agent_update_job_file($agentId);
        if ($file === '' || !is_file($file)) return array();
        $row = dmd_agent_json_read($file, array());
        return is_array($row) ? $row : array();
    }
}
if (!function_exists('dmd_agent_update_job_write')) {
    function dmd_agent_update_job_write($agentId, $job) {
        $file = dmd_agent_update_job_file($agentId);
        if ($file === '' || !is_array($job)) return false;
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $job['updated_ts'] = time();
        $job['updated_at'] = gmdate('c');
        return dmd_agent_json_write($file, $job, 0640);
    }
}
if (!function_exists('dmd_agent_update_package_dir')) {
    function dmd_agent_update_package_dir() {
        return dirname(dirname(dirname(__DIR__))) . '/updates';
    }
}
if (!function_exists('dmd_agent_update_package_set')) {
    function dmd_agent_update_package_set($version) {
        $version = trim((string)$version);
        if (!preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]{0,31}$/', $version)) return array();
        $dir = dmd_agent_update_package_dir();
        $agent = $dir . '/DMD-Agent.' . $version . '.exe';
        $package = $dir . '/update.' . $version . '.exe';
        if (!is_file($agent) || !is_file($package) || !is_readable($agent) || !is_readable($package)) return array();
        foreach (array($agent,$package) as $pe) {
            $fh=@fopen($pe,'rb');
            if(!$fh) return array();
            $magic=@fread($fh,2); @fclose($fh);
            if($magic!=="MZ") return array();
        }
        return array(
            'version'=>$version,
            'agent_file'=>$agent,
            'agent_name'=>basename($agent),
            'agent_sha256'=>strtolower((string)hash_file('sha256', $agent)),
            'agent_size'=>(int)filesize($agent),
            'package_file'=>$package,
            'package_name'=>basename($package),
            'package_sha256'=>strtolower((string)hash_file('sha256', $package)),
            'package_size'=>(int)filesize($package),
            'mtime'=>max((int)filemtime($agent),(int)filemtime($package)),
        );
    }
}
if (!function_exists('dmd_agent_update_latest_set')) {
    function dmd_agent_update_latest_set() {
        $dir = dmd_agent_update_package_dir();
        if (!is_dir($dir)) return array();
        $rows = array();
        foreach ((array)glob($dir . '/update.*.exe') as $file) {
            $name = basename($file);
            if (!preg_match('/^update\.([0-9A-Za-z][0-9A-Za-z._-]{0,31})\.exe$/i', $name, $m)) continue;
            $set = dmd_agent_update_package_set((string)$m[1]);
            if ($set) $rows[] = $set;
        }
        usort($rows, function($a,$b){
            $n = strnatcasecmp((string)$b['version'], (string)$a['version']);
            return $n !== 0 ? $n : ((int)$b['mtime'] <=> (int)$a['mtime']);
        });
        return $rows ? $rows[0] : array();
    }
}
if (!function_exists('dmd_agent_update_server_url')) {
    function dmd_agent_update_server_url($agentId) {
        $deviceFile = dmd_agent_device_file($agentId);
        $device = ($deviceFile !== '' && is_file($deviceFile)) ? dmd_agent_json_read($deviceFile, array()) : array();
        if (!$device) return '';
        $enrollment = !empty($device['enrollment_id']) ? dmd_agent_load_enrollment($device['enrollment_id']) : array();
        return rtrim((string)($enrollment['server_url'] ?? ''), '/');
    }
}
if (!function_exists('dmd_agent_update_mark_bootstrap_done')) {
    function dmd_agent_update_mark_bootstrap_done($agentId, $commandId) {
        $commandId = dmd_agent_command_safe_id($commandId);
        if ($commandId === '') return false;
        $done = dmd_agent_command_with_lock($agentId, function(&$data) use ($commandId) {
            dmd_agent_command_cleanup_data($data);
            if (!isset($data['commands'][$commandId]) || !is_array($data['commands'][$commandId])) return false;
            $c =& $data['commands'][$commandId];
            $c['status'] = 'completed';
            $c['completed_ts'] = time();
            $c['completed_at'] = gmdate('c');
            $c['result'] = array('bootstrap_agent_running'=>true);
            $c['error'] = '';
            return true;
        });
        return $done === true;
    }
}
if (!function_exists('dmd_agent_update_queue_package_stage')) {
    function dmd_agent_update_queue_package_stage($agentId, $job) {
        $serverUrl = dmd_agent_update_server_url($agentId);
        if ($serverUrl === '') return array('ok'=>false,'error'=>'server_url_missing');
        $version = (string)($job['version'] ?? '');
        $sha = (string)($job['package_sha256'] ?? '');
        $url = $serverUrl . '/updates/' . rawurlencode((string)($job['package_name'] ?? ('update.' . $version . '.exe')));
        $q = dmd_agent_queue_command($agentId, 'update_agent', array(
            'version'=>$version,'url'=>$url,'sha256'=>$sha,'force'=>true,'authenticode_thumbprint'=>''
        ), 'system:update-stage2', 'core.update', 3600);
        if (empty($q['ok'])) return $q;
        $job['stage'] = 'package_queued';
        $job['package_command_id'] = (string)($q['command']['command_id'] ?? '');
        $job['package_queued_ts'] = time();
        $job['package_queued_at'] = gmdate('c');
        dmd_agent_update_job_write($agentId, $job);
        return array('ok'=>true,'job'=>$job,'command'=>$q['command']);
    }
}
if (!function_exists('dmd_agent_update_job_maybe_advance')) {
    function dmd_agent_update_job_maybe_advance($agentId, $reportedVersion, $updateProtocol) {
        $job = dmd_agent_update_job_read($agentId);
        if (!$job) return array();
        if (!empty($job['package_command_id'])) return $job;
        $target = trim((string)($job['version'] ?? ''));
        if ($target === '') return $job;
        if ((int)$updateProtocol < 2) return $job;
        if (strcasecmp(trim((string)$reportedVersion), $target) !== 0) return $job;
        dmd_agent_update_mark_bootstrap_done($agentId, (string)($job['bootstrap_command_id'] ?? ''));
        $r = dmd_agent_update_queue_package_stage($agentId, $job);
        return !empty($r['job']) ? $r['job'] : $job;
    }
}
if (!function_exists('dmd_agent_update_job_status')) {
    function dmd_agent_update_job_status($agentId) {
        $job = dmd_agent_update_job_read($agentId);
        if (!$job) return array('ok'=>false,'error'=>'update_job_not_found');
        $status = 'queued';
        $phase = 'bootstrap';
        $message = 'Préparation du nouvel Agent';
        $result = null;
        $error = '';
        $commandId = (string)($job['package_command_id'] ?? '');
        if ($commandId !== '') {
            $phase = 'package';
            $cmd = dmd_agent_command_status($agentId, $commandId);
            if ($cmd) {
                $status = (string)($cmd['status'] ?? 'queued');
                $result = $cmd['result'] ?? null;
                $error = (string)($cmd['error'] ?? '');
                if (is_array($result) && trim((string)($result['message'] ?? '')) !== '') $message = (string)$result['message'];
                else $message = array(
                    'queued'=>'Package en attente de remise au PC',
                    'delivered'=>'Package remis au PC',
                    'downloading'=>'Téléchargement du package DoMyDesk',
                    'verified'=>'Package vérifié',
                    'installing'=>'Installation DoMyDesk en cours',
                    'completed'=>'Mise à jour DoMyDesk terminée',
                    'failed'=>'Échec de la mise à jour DoMyDesk',
                    'expired'=>'Commande de mise à jour expirée',
                )[$status] ?? $status;
            }
        } else {
            $bootId = (string)($job['bootstrap_command_id'] ?? '');
            $cmd = $bootId !== '' ? dmd_agent_command_status($agentId, $bootId) : array();
            if ($cmd) {
                $bs = (string)($cmd['status'] ?? 'queued');
                if (in_array($bs, array('failed','expired','cancelled'), true)) {
                    $status = 'failed'; $error = (string)($cmd['error'] ?? 'bootstrap_failed');
                    $message = 'Échec de la mise à niveau du moteur Agent';
                } else {
                    $status = $bs === 'completed' ? 'installing' : $bs;
                    $message = $bs === 'completed' ? 'Nouvel Agent démarré, préparation du package complet' : 'Mise à niveau du moteur Agent';
                    $created = (int)($job['created_ts'] ?? 0);
                    if ($bs === 'completed' && $created > 0 && time() - $created > 240) {
                        $status = 'failed'; $error = 'bootstrap_agent_not_seen';
                        $message = 'Le nouvel Agent ne s’est pas reconnecté avec le protocole update';
                    }
                }
            }
        }
        return array(
            'ok'=>true,'agent_id'=>$agentId,'version'=>(string)($job['version'] ?? ''),
            'status'=>$status,'phase'=>$phase,'message'=>$message,'error'=>$error,
            'result'=>$result,'command_id'=>$commandId !== '' ? $commandId : (string)($job['bootstrap_command_id'] ?? ''),
        );
    }
}
