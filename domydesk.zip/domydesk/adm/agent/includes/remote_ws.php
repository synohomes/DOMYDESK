<?php
/* DoMyDesk - transport WebSocket interne DMD-Remote. */
if (!defined('DMD_AGENT_VAR')) {
    require_once __DIR__ . '/agent_core.php';
}

function dmd_remote_ws_b64url(string $raw): string {
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
}

function dmd_remote_ws_config_path(): string {
    return DMD_AGENT_VAR . '/remote_ws_config.php';
}

function dmd_remote_ws_log_path(): string {
    return DMD_AGENT_VAR . '/logs/remote-ws.log';
}

function dmd_remote_ws_daemon_path(): string {
    return DMD_AGENT_ROOT . '/modules/DMD-RemoteAgent/ws/DMD-RemoteAgent_ws.php';
}

function dmd_remote_ws_port(): int {
    return 49380;
}

function dmd_remote_ws_expected_marker(): string {
    return 'DMDREMOTE-WS-RECOVERY-R8';
}


/* -------------------------------------------------------------------------
 * Configuration d'accès DMD-Remote depuis Internet.
 * Le relais reste interne à DoMyDesk ; seule son URL HTTPS/WSS publique est
 * configurable depuis Administration > Agent > Remote.
 * ---------------------------------------------------------------------- */
function dmd_remote_ws_internet_settings_file(): string {
    return DMD_AGENT_VAR . '/remote_internet.php';
}

function dmd_remote_ws_internet_settings_defaults(): array {
    return array(
        'schema'=>2,
        'enabled'=>false,
        'public_base_url'=>'',
        'ws_path'=>'/modules/DMD-RemoteAgent/ws',
        'proxy_mode'=>'auto',
        'updated_at'=>'',
        'updated_by'=>'',
    );
}

function dmd_remote_ws_internet_normalize_base_url($url): string {
    $url = rtrim(trim((string)$url), '/');
    if ($url === '' || strlen($url) > 500) return '';
    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) return '';
    $scheme = strtolower((string)$parts['scheme']);
    if ($scheme !== 'https' && $scheme !== 'http') return '';
    if (isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) return '';
    return $url;
}

function dmd_remote_ws_internet_normalize_path($path): string {
    $path = trim((string)$path);
    if ($path === '') $path = '/modules/DMD-RemoteAgent/ws';
    if ($path[0] !== '/') $path = '/' . $path;
    $path = '/' . ltrim(preg_replace('#/+#', '/', $path), '/');
    $path = rtrim($path, '/');
    if ($path === '') $path = '/modules/DMD-RemoteAgent/ws';
    if (strlen($path) > 220 || strpos($path, '..') !== false || !preg_match('#^/[A-Za-z0-9._~!$&\'()*+,;=:@%/-]+$#', $path)) return '';
    return $path;
}

function dmd_remote_ws_internet_settings_read(): array {
    $out = dmd_remote_ws_internet_settings_defaults();
    $data = dmd_agent_json_read(dmd_remote_ws_internet_settings_file(), array());
    if (!is_array($data)) return $out;
    $out['enabled'] = !empty($data['enabled']);
    $base = dmd_remote_ws_internet_normalize_base_url($data['public_base_url'] ?? '');
    if ($base !== '') $out['public_base_url'] = $base;
    $path = dmd_remote_ws_internet_normalize_path($data['ws_path'] ?? '');
    if ($path !== '') $out['ws_path'] = $path;
    $mode = strtolower(trim((string)($data['proxy_mode'] ?? 'auto')));
    if (!in_array($mode, array('auto','apache','nginx','synology','manual'), true)) $mode = 'auto';
    $out['proxy_mode'] = $mode;
    $out['updated_at'] = trim((string)($data['updated_at'] ?? ''));
    $out['updated_by'] = trim((string)($data['updated_by'] ?? ''));
    return $out;
}

function dmd_remote_ws_internet_settings_write(array $settings, string $updatedBy = ''): array {
    $enabled = !empty($settings['enabled']);
    $base = dmd_remote_ws_internet_normalize_base_url($settings['public_base_url'] ?? '');
    if ($enabled && $base === '') return array('ok'=>false,'error'=>'remote_access_url_invalid');
    if ($enabled && stripos($base, 'http://') !== 0 && stripos($base, 'https://') !== 0) return array('ok'=>false,'error'=>'remote_access_url_scheme_invalid');
    $path = dmd_remote_ws_internet_normalize_path($settings['ws_path'] ?? '');
    if ($path === '') return array('ok'=>false,'error'=>'websocket_path_invalid');
    $mode = strtolower(trim((string)($settings['proxy_mode'] ?? 'auto')));
    if (!in_array($mode, array('auto','apache','nginx','synology','manual'), true)) return array('ok'=>false,'error'=>'proxy_mode_invalid');
    $clean = array(
        'schema'=>2,
        'enabled'=>$enabled,
        'public_base_url'=>$base,
        'ws_path'=>$path,
        'proxy_mode'=>$mode,
        'updated_at'=>gmdate('c'),
        'updated_by'=>trim($updatedBy),
    );
    if (!dmd_agent_json_write(dmd_remote_ws_internet_settings_file(), $clean, 0640)) return array('ok'=>false,'error'=>'remote_internet_settings_write_failed');
    return array('ok'=>true,'settings'=>$clean);
}

function dmd_remote_ws_current_server_url(): string {
    return rtrim(dmd_remote_ws_origin() . dmd_remote_ws_base_path(), '/');
}

function dmd_remote_ws_enrollment_server_url(): string {
    $cfg = dmd_remote_ws_internet_settings_read();
    if (!empty($cfg['enabled']) && !empty($cfg['public_base_url'])) return rtrim((string)$cfg['public_base_url'], '/');
    return dmd_remote_ws_current_server_url();
}

function dmd_remote_ws_configured_public_url(?array $cfg = null): string {
    if (!is_array($cfg)) $cfg = dmd_remote_ws_internet_settings_read();
    if (!empty($cfg['enabled']) && !empty($cfg['public_base_url'])) {
        return rtrim((string)$cfg['public_base_url'], '/') . (string)$cfg['ws_path'];
    }
    return '';
}

function dmd_remote_ws_public_health_url(?array $cfg = null): string {
    $base = dmd_remote_ws_configured_public_url($cfg);
    return $base === '' ? '' : rtrim($base, '/') . '/health';
}

function dmd_remote_ws_to_websocket_url(string $url): string {
    if (strpos($url, 'https://') === 0) return 'wss://' . substr($url, 8);
    if (strpos($url, 'http://') === 0) return 'ws://' . substr($url, 7);
    return $url;
}

function dmd_remote_ws_proxy_detected_mode(): string {
    $server = strtolower((string)($_SERVER['SERVER_SOFTWARE'] ?? ''));
    if (strpos($server, 'apache') !== false) return 'apache';
    if (strpos($server, 'nginx') !== false) return 'nginx';
    if (is_dir('/var/packages/WebStation') || is_dir('/usr/syno')) return 'synology';
    return 'manual';
}

function dmd_remote_ws_proxy_snippet(?array $cfg = null): string {
    if (!is_array($cfg)) $cfg = dmd_remote_ws_internet_settings_read();
    $base = trim((string)($cfg['public_base_url'] ?? ''));
    $path = trim((string)($cfg['ws_path'] ?? '/modules/DMD-RemoteAgent/ws'));
    if ($base === '') return '';
    $parts = @parse_url($base);
    $basePath = rtrim((string)($parts['path'] ?? ''), '/');
    $publicPath = preg_replace('#/+#', '/', $basePath . '/' . ltrim($path, '/'));
    if ($publicPath === '') $publicPath = '/modules/DMD-RemoteAgent/ws';
    $mode = (string)($cfg['proxy_mode'] ?? 'auto');
    if ($mode === 'auto') $mode = dmd_remote_ws_proxy_detected_mode();
    if ($mode === 'apache') {
        return "# Déjà fourni par DoMyDesk dans modules/DMD-RemoteAgent/ws/.htaccess\n"
            . "# Le dossier public attendu est : " . $publicPath . "/";
    }
    if ($mode === 'synology') {
        return "Source HTTPS/WSS : " . $publicPath . "/\n"
            . "Destination interne : http://127.0.0.1:" . dmd_remote_ws_port() . "/\n"
            . "En-têtes : Upgrade = \$http_upgrade ; Connection = upgrade";
    }
    return "location ^~ " . $publicPath . "/ {\n"
        . "    proxy_pass http://127.0.0.1:" . dmd_remote_ws_port() . "/;\n"
        . "    proxy_http_version 1.1;\n"
        . "    proxy_set_header Upgrade \$http_upgrade;\n"
        . "    proxy_set_header Connection \"upgrade\";\n"
        . "    proxy_set_header Host \$host;\n"
        . "    proxy_read_timeout 3600s;\n"
        . "    proxy_send_timeout 3600s;\n"
        . "}";
}

function dmd_remote_ws_public_http_probe(string $url, int $timeout = 4): array {
    if ($url === '') return array('ok'=>false,'status'=>0,'body'=>'','error'=>'url_missing');
    $headers = array('Accept: text/plain','Cache-Control: no-cache');
    if (function_exists('curl_init')) {
        $ch = @curl_init($url);
        if ($ch) {
            @curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_FOLLOWLOCATION=>false,
                CURLOPT_CONNECTTIMEOUT=>$timeout,
                CURLOPT_TIMEOUT=>$timeout,
                CURLOPT_HTTPHEADER=>$headers,
                CURLOPT_SSL_VERIFYPEER=>true,
                CURLOPT_SSL_VERIFYHOST=>2,
            ));
            $body = @curl_exec($ch);
            $status = (int)@curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $error = $body === false ? (string)@curl_error($ch) : '';
            @curl_close($ch);
            return array('ok'=>$status >= 200 && $status < 300,'status'=>$status,'body'=>is_string($body)?trim($body):'','error'=>$error);
        }
    }
    $ctx = @stream_context_create(array('http'=>array('method'=>'GET','timeout'=>$timeout,'ignore_errors'=>true,'header'=>implode("\r\n",$headers)), 'ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true)));
    $body = @file_get_contents($url, false, $ctx);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header) && isset($http_response_header[0]) && preg_match('#\s([0-9]{3})\s#', $http_response_header[0], $m)) $status = (int)$m[1];
    return array('ok'=>$status >= 200 && $status < 300,'status'=>$status,'body'=>is_string($body)?trim($body):'','error'=>$body===false?'request_failed':'');
}

function dmd_remote_ws_public_upgrade_probe(string $remoteUrl, int $timeout = 4): array {
    $parts = @parse_url($remoteUrl);
    if (!is_array($parts) || empty($parts['host'])) return array('ok'=>false,'status'=>0,'error'=>'remote_url_invalid');
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    if ($scheme !== 'https' && $scheme !== 'http') return array('ok'=>false,'status'=>0,'error'=>'remote_scheme_invalid');
    $host = (string)$parts['host'];
    $tls = $scheme === 'https';
    $port = isset($parts['port']) ? (int)$parts['port'] : ($tls ? 443 : 80);
    $path = rtrim((string)($parts['path'] ?? ''), '/') . '/view/control?ticket=invalid';
    $errno = 0; $errstr = '';
    if ($tls) {
        $ctx = @stream_context_create(array('ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'SNI_enabled'=>true)));
        $target = 'ssl://' . $host . ':' . $port;
    } else {
        $ctx = @stream_context_create(array());
        $target = 'tcp://' . $host . ':' . $port;
    }
    $fp = @stream_socket_client($target, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
    if (!is_resource($fp)) return array('ok'=>false,'status'=>0,'error'=>$errstr !== '' ? $errstr : 'connect_failed');
    @stream_set_timeout($fp, $timeout);
    $key = base64_encode(random_bytes(16));
    $defaultPort = $tls ? 443 : 80;
    $hostHeader = $host . (($port !== $defaultPort) ? ':' . $port : '');
    $req = "GET " . $path . " HTTP/1.1\r\nHost: " . $hostHeader . "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: " . $key . "\r\n\r\n";
    @fwrite($fp, $req);
    $raw = '';
    while (!feof($fp) && strlen($raw) < 8192) {
        $chunk = @fread($fp, 2048);
        if (!is_string($chunk) || $chunk === '') break;
        $raw .= $chunk;
        if (strpos($raw, "\r\n\r\n") !== false) break;
    }
    @fclose($fp);
    $status = 0;
    if (preg_match('#^HTTP/1\.[01]\s+([0-9]{3})#', $raw, $m)) $status = (int)$m[1];
    return array('ok'=>$status === 403,'status'=>$status,'error'=>$status===403?'':($status?('unexpected_http_'.$status):'no_http_response'));
}

function dmd_remote_ws_internet_status(?array $cfg = null): array {
    if (!is_array($cfg)) $cfg = dmd_remote_ws_internet_settings_read();
    $enabled = !empty($cfg['enabled']);
    $publicBase = dmd_remote_ws_internet_normalize_base_url($cfg['public_base_url'] ?? '');
    $wsPath = dmd_remote_ws_internet_normalize_path($cfg['ws_path'] ?? '');
    $schemeOk = stripos($publicBase, 'http://') === 0 || stripos($publicBase, 'https://') === 0;
    $configured = $enabled && $publicBase !== '' && $wsPath !== '' && $schemeOk;
    $local = dmd_remote_ws_health();
    $relayOnline = !empty($local['online']) && hash_equals(dmd_remote_ws_expected_marker(), (string)($local['marker'] ?? ''));
    $publicWs = $configured ? dmd_remote_ws_configured_public_url($cfg) : '';
    $healthUrl = $configured ? dmd_remote_ws_public_health_url($cfg) : '';
    $publicHealth = array('ok'=>false,'status'=>0,'body'=>'','error'=>$configured?'not_tested':'not_configured');
    $upgrade = array('ok'=>false,'status'=>0,'error'=>$configured?'not_tested':'not_configured');
    if ($configured) {
        $publicHealth = dmd_remote_ws_public_http_probe($healthUrl);
        $publicHealth['ok'] = !empty($publicHealth['ok']) && hash_equals(dmd_remote_ws_expected_marker(), (string)($publicHealth['body'] ?? ''));
        $upgrade = dmd_remote_ws_public_upgrade_probe($publicWs);
    }
    $operational = $configured && $relayOnline && !empty($publicHealth['ok']) && !empty($upgrade['ok']);
    return array(
        'enabled'=>$enabled,
        'configured'=>$configured,
        'operational'=>$operational,
        'server_url'=>dmd_remote_ws_enrollment_server_url(),
        'remote_url'=>$publicWs,
        'websocket_url'=>$publicWs !== '' ? dmd_remote_ws_to_websocket_url($publicWs) : '',
        'health_url'=>$healthUrl,
        'relay'=>array('host'=>'127.0.0.1','port'=>dmd_remote_ws_port(),'online'=>$relayOnline,'marker'=>(string)($local['marker'] ?? '')),
        'public_health'=>$publicHealth,
        'websocket_upgrade'=>$upgrade,
        'proxy_detected'=>dmd_remote_ws_proxy_detected_mode(),
        'proxy_snippet'=>dmd_remote_ws_proxy_snippet($cfg),
    );
}

function dmd_remote_ws_health(): array {
    $errno = 0;
    $errstr = '';
    $fp = @fsockopen('127.0.0.1', dmd_remote_ws_port(), $errno, $errstr, 0.20);
    if (!is_resource($fp)) return array('online'=>false,'marker'=>'');
    @fwrite($fp, "GET /health HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n");
    @stream_set_timeout($fp, 0, 300000);
    $raw = '';
    while (!feof($fp)) {
        $chunk = @fread($fp, 4096);
        if (!is_string($chunk) || $chunk === '') break;
        $raw .= $chunk;
        if (strlen($raw) > 8192) break;
    }
    @fclose($fp);
    $online = strpos($raw, ' 200 ') !== false;
    $marker = '';
    $pos = strpos($raw, "\r\n\r\n");
    if ($pos !== false) $marker = trim(substr($raw, $pos + 4));
    return array('online'=>$online,'marker'=>$marker);
}

function dmd_remote_ws_online(): bool {
    $health = dmd_remote_ws_health();
    return !empty($health['online']) && hash_equals(dmd_remote_ws_expected_marker(), (string)($health['marker'] ?? ''));
}

function dmd_remote_ws_origin(): string {
    $https = strtolower((string)($_SERVER['HTTPS'] ?? ''));
    $proto = ($https !== '' && $https !== 'off' && $https !== '0') ? 'https' : 'http';
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        $forwarded = strtolower(trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_PROTO'])[0]));
        if ($forwarded === 'http' || $forwarded === 'https') $proto = $forwarded;
    }
    $host = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_HOST'])) $host = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_HOST'])[0]);
    if ($host === '') $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') $host = trim((string)($_SERVER['SERVER_NAME'] ?? 'localhost'));
    if (!preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host)) $host = 'localhost';
    return $proto . '://' . $host;
}

function dmd_remote_ws_base_path(): string {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    foreach (array('/adm/agent/api/', '/adm/agent/', '/modules/DMD-RemoteAgent/') as $needle) {
        $pos = strpos($script, $needle);
        if ($pos !== false) {
            $base = substr($script, 0, $pos);
            return $base === '/' ? '' : rtrim($base, '/');
        }
    }
    return '';
}

function dmd_remote_ws_public_url(): string {
    $internet = dmd_remote_ws_internet_settings_read();
    $configured = dmd_remote_ws_configured_public_url($internet);
    if (!empty($internet['enabled']) && $configured !== '') return $configured;

    $origin = dmd_remote_ws_origin();
    $parts = @parse_url($origin);
    $scheme = strtolower((string)($parts['scheme'] ?? 'http'));
    // Mode LAN/DEV conservé tel quel pour ne pas modifier le Remote existant.
    if ($scheme === 'http') {
        $host = (string)($parts['host'] ?? 'localhost');
        if (strpos($host, ':') !== false && $host[0] !== '[') $host = '[' . $host . ']';
        return 'http://' . $host . ':' . dmd_remote_ws_port();
    }
    return $origin . dmd_remote_ws_base_path() . '/modules/DMD-RemoteAgent/ws';
}

function dmd_remote_ws_prepare_config(): array {
    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return array('ok'=>false,'error'=>'instance_identity_invalid');
    $daemon = dmd_remote_ws_daemon_path();
    if (!is_file($daemon)) return array('ok'=>false,'error'=>'remote_ws_daemon_missing','path'=>$daemon);
    if (!is_dir(DMD_AGENT_VAR) && !@mkdir(DMD_AGENT_VAR, 0750, true) && !is_dir(DMD_AGENT_VAR)) {
        return array('ok'=>false,'error'=>'remote_ws_var_unwritable');
    }

    // Secret local persistant du relais. Le ticket reste un bearer très court,
    // mais le daemon n'a plus besoin que le PHP CLI charge ext-sodium.
    $old = dmd_agent_json_read(dmd_remote_ws_config_path(), array());
    $ticketSecret = '';
    if (!empty($old['ticket_secret'])) {
        $candidate = base64_decode((string)$old['ticket_secret'], true);
        if (is_string($candidate) && strlen($candidate) === 32) $ticketSecret = $candidate;
    }
    if ($ticketSecret === '') $ticketSecret = random_bytes(32);

    $config = array(
        'schema'=>2,
        'listen'=>(!empty(dmd_remote_ws_internet_settings_read()['enabled']) ? '127.0.0.1:' : (strpos(dmd_remote_ws_origin(), 'http://') === 0 ? '0.0.0.0:' : '127.0.0.1:')) . dmd_remote_ws_port(),
        'instance_id'=>(string)$identity['manifest']['instance_id'],
        'instance_public_key'=>(string)$identity['public_key'],
        'ticket_secret'=>base64_encode($ticketSecret),
    );
    if (!dmd_agent_json_write(dmd_remote_ws_config_path(), $config, 0640)) {
        return array('ok'=>false,'error'=>'remote_ws_config_write_failed');
    }
    return array('ok'=>true,'path'=>dmd_remote_ws_config_path(),'config'=>$config,'ticket_secret'=>$ticketSecret);
}

function dmd_remote_ws_capture_command($cmd, &$rc = null) {
    $rc = 1;
    if (function_exists('exec')) {
        $out = array();
        @exec($cmd, $out, $rc);
        return implode("\n", $out);
    }
    if (function_exists('shell_exec')) {
        $out = @shell_exec($cmd . ' 2>&1');
        $rc = is_string($out) ? 0 : 1;
        return is_string($out) ? $out : '';
    }
    if (function_exists('proc_open')) {
        $spec = array(0=>array('file','/dev/null','r'),1=>array('pipe','w'),2=>array('pipe','w'));
        $proc = @proc_open(array('/bin/sh','-c',$cmd), $spec, $pipes);
        if (!is_resource($proc)) return '';
        $out = isset($pipes[1]) ? stream_get_contents($pipes[1]) : '';
        $err = isset($pipes[2]) ? stream_get_contents($pipes[2]) : '';
        foreach ($pipes as $pipe) if (is_resource($pipe)) @fclose($pipe);
        $rc = @proc_close($proc);
        return (string)$out . (string)$err;
    }
    return '';
}

function dmd_remote_ws_php_candidates(): array {
    $candidates = array();
    $forced = trim((string)getenv('DMD_REMOTE_PHP'));
    if ($forced !== '') $candidates[] = $forced;

    $maj = defined('PHP_MAJOR_VERSION') ? (int)PHP_MAJOR_VERSION : 8;
    $min = defined('PHP_MINOR_VERSION') ? (int)PHP_MINOR_VERSION : 0;
    $tag = (string)$maj . (string)$min;
    $pkg = 'PHP' . $maj . '.' . $min;
    foreach (array(
        '/var/packages/'.$pkg.'/target/usr/local/bin/php'.$tag,
        '/var/packages/'.$pkg.'/target/usr/local/bin/php',
        '/usr/local/bin/php'.$tag,
        '/usr/bin/php'.$tag,
        '/usr/local/bin/php',
        '/usr/bin/php',
        '/opt/php/bin/php'
    ) as $path) $candidates[] = $path;

    foreach (array('/var/packages/PHP*/target/usr/local/bin/php*','/usr/local/bin/php*','/usr/bin/php*') as $pattern) {
        $found = @glob($pattern);
        if (is_array($found)) foreach ($found as $path) $candidates[] = $path;
    }
    if (defined('PHP_BINARY')) $candidates[] = (string)PHP_BINARY;

    $unique = array();
    foreach ($candidates as $path) {
        $path = trim((string)$path);
        if ($path === '' || isset($unique[$path]) || !is_file($path) || !is_executable($path)) continue;
        $base = strtolower(basename($path));
        if (strpos($base, 'fpm') !== false || strpos($base, 'cgi') !== false || strpos($base, 'config') !== false) continue;
        $unique[$path] = true;
    }
    return array_keys($unique);
}

function dmd_remote_ws_probe_php($path): array {
    $code = 'echo PHP_VERSION_ID,"|",PHP_SAPI,"|",(function_exists("stream_socket_server")?"1":"0");';
    $rc = 1;
    $out = dmd_remote_ws_capture_command(escapeshellarg($path).' -r '.escapeshellarg($code), $rc);
    $parts = explode('|', trim((string)$out));
    $version = isset($parts[0]) ? (int)$parts[0] : 0;
    $sapi = isset($parts[1]) ? strtolower(trim((string)$parts[1])) : '';
    $stream = isset($parts[2]) ? trim((string)$parts[2]) === '1' : false;
    return array(
        'ok'=>$rc === 0 && $version >= 70300 && $sapi === 'cli' && $stream,
        'version'=>$version,
        'sapi'=>$sapi,
        'stream'=>$stream,
        'path'=>$path,
    );
}

function dmd_remote_ws_find_php_cli(): string {
    $usable = array();
    $currentMM = intdiv((int)PHP_VERSION_ID, 100);
    foreach (dmd_remote_ws_php_candidates() as $path) {
        $probe = dmd_remote_ws_probe_php($path);
        if (empty($probe['ok'])) continue;
        $mm = intdiv((int)$probe['version'], 100);
        $score = ($mm === $currentMM ? 1000000 : 0) + (int)$probe['version'];
        $usable[] = array('path'=>$path,'score'=>$score);
    }
    if (!$usable) return '';
    usort($usable, function($a,$b){ return $b['score'] <=> $a['score']; });
    return (string)$usable[0]['path'];
}
function dmd_remote_ws_pid_path(): string {
    return DMD_AGENT_VAR . '/remote-ws.pid';
}

function dmd_remote_ws_start_process(string $php, string $daemon, string $config, string $log): array {
    // Pas de dépendance à "nohup" : certains NAS Synology ne l'exposent pas
    // au contexte PHP-FPM. Le shell lance le daemon détaché et retourne son PID.
    $runner = escapeshellarg($php)
        . ' ' . escapeshellarg($daemon)
        . ' --config ' . escapeshellarg($config)
        . ' >> ' . escapeshellarg($log) . ' 2>&1 < /dev/null';
    $cmd = $runner . ' & echo $!';
    $rc = 1;
    $out = trim((string)dmd_remote_ws_capture_command($cmd, $rc));
    if ($rc !== 0 || !preg_match('/([0-9]+)\s*$/', $out, $m)) {
        return array('ok'=>false,'pid'=>0,'output'=>$out,'rc'=>$rc);
    }
    $pid = (int)$m[1];
    if ($pid > 1) @file_put_contents(dmd_remote_ws_pid_path(), (string)$pid, LOCK_EX);
    return array('ok'=>$pid > 1,'pid'=>$pid,'output'=>$out,'rc'=>$rc);
}

function dmd_remote_ws_stop_pid($pid): void {
    $pid = (int)$pid;
    if ($pid <= 1) return;
    $cmdline = @file_get_contents('/proc/'.$pid.'/cmdline');
    if (is_string($cmdline) && $cmdline !== '' && strpos($cmdline, basename(dmd_remote_ws_daemon_path())) === false) return;
    if (function_exists('posix_kill')) { @posix_kill($pid, 15); return; }
    if (function_exists('exec')) @exec('kill '.intval($pid).' >/dev/null 2>&1');
}

function dmd_remote_ws_stop_all_known_daemons(): void {
    $needle = basename(dmd_remote_ws_daemon_path());
    $self = function_exists('getmypid') ? (int)getmypid() : 0;
    $items = @glob('/proc/[0-9]*/cmdline');
    if (!is_array($items)) return;
    foreach ($items as $cmdlinePath) {
        $pid = (int)basename(dirname($cmdlinePath));
        if ($pid <= 1 || $pid === $self) continue;
        $cmdline = @file_get_contents($cmdlinePath);
        if (!is_string($cmdline) || $cmdline === '') continue;
        $cmdline = str_replace("\0", ' ', $cmdline);
        if (strpos($cmdline, $needle) === false) continue;
        if (function_exists('posix_kill')) {
            @posix_kill($pid, 15);
        } elseif (function_exists('exec')) {
            @exec('kill '.intval($pid).' >/dev/null 2>&1');
        }
    }
}

function dmd_remote_ws_log_tail(string $path): string {
    if (!is_file($path)) return '';
    $size = @filesize($path);
    if (!is_int($size) || $size <= 0) return '';
    $fp = @fopen($path, 'rb');
    if (!is_resource($fp)) return '';
    $take = min(8192, $size);
    @fseek($fp, -$take, SEEK_END);
    $raw = (string)@fread($fp, $take);
    @fclose($fp);
    $raw = preg_replace('/[^\x09\x0A\x0D\x20-\x7E\x80-\xFF]/', '', $raw);
    return trim((string)$raw);
}

function dmd_remote_ws_ensure_daemon(): array {
    $health = dmd_remote_ws_health();
    if (!empty($health['online']) && hash_equals(dmd_remote_ws_expected_marker(), (string)($health['marker'] ?? ''))) {
        return array('ok'=>true,'started'=>false);
    }
    // Si un ancien relais tourne encore sur 49380, on le ferme proprement à
    // partir du PID déjà enregistré. Le prochain démarrage charge alors le
    // fichier PHP qui vient réellement d'être installé.
    if (!empty($health['online'])) {
        $pid = is_file(dmd_remote_ws_pid_path()) ? (int)trim((string)@file_get_contents(dmd_remote_ws_pid_path())) : 0;
        if ($pid > 1) dmd_remote_ws_stop_pid($pid);
        for ($i=0; $i<15; $i++) {
            usleep(100000);
            $probe = dmd_remote_ws_health();
            if (empty($probe['online'])) break;
        }
        $probe = dmd_remote_ws_health();
        if (!empty($probe['online'])) {
            // PID obsolète ou ancien daemon lancé avant le fichier PID actuel :
            // on cible uniquement les processus PHP exécutant DMD-RemoteAgent_ws.php.
            dmd_remote_ws_stop_all_known_daemons();
            for ($i=0; $i<30; $i++) {
                usleep(100000);
                $probe = dmd_remote_ws_health();
                if (empty($probe['online'])) break;
            }
        }
        $probe = dmd_remote_ws_health();
        if (!empty($probe['online'])) {
            return array('ok'=>false,'error'=>'remote_ws_old_daemon_still_running','marker'=>(string)($probe['marker'] ?? ''));
        }
    }
    $prepared = dmd_remote_ws_prepare_config();
    if (empty($prepared['ok'])) return $prepared;
    if (PHP_OS_FAMILY === 'Windows') return array('ok'=>false,'error'=>'remote_ws_server_requires_unix_php');

    $php = dmd_remote_ws_find_php_cli();
    if ($php === '') return array('ok'=>false,'error'=>'remote_ws_php_cli_compatible_missing');

    $daemon = dmd_remote_ws_daemon_path();
    $log = dmd_remote_ws_log_path();
    if (!is_dir(dirname($log))) @mkdir(dirname($log), 0750, true);
    @file_put_contents($log, "\n[".date('c')."] DMD-Remote WS start avec ".$php."\n", FILE_APPEND|LOCK_EX);

    $started = dmd_remote_ws_start_process($php, $daemon, (string)$prepared['path'], $log);
    if (empty($started['ok'])) {
        return array('ok'=>false,'error'=>'remote_ws_process_start_unavailable','php'=>$php,'log'=>$log,'detail'=>dmd_remote_ws_log_tail($log));
    }

    for ($i=0; $i<60; $i++) {
        usleep(100000);
        if (dmd_remote_ws_online()) return array('ok'=>true,'started'=>true,'php'=>$php,'pid'=>(int)$started['pid']);
    }

    dmd_remote_ws_stop_pid((int)$started['pid']);
    return array('ok'=>false,'error'=>'remote_ws_start_failed','log'=>$log,'php'=>$php,'detail'=>dmd_remote_ws_log_tail($log));
}
function dmd_remote_ws_issue_ticket(string $kind, string $agentId, array $permissions, int $ttl = 180): array {
    $kind = $kind === 'agent' ? 'agent' : 'viewer';
    $agentId = dmd_agent_safe_agent_id($agentId);
    if ($agentId === '') return array('ok'=>false,'error'=>'agent_id_invalid');

    $daemon = dmd_remote_ws_ensure_daemon();
    if (empty($daemon['ok'])) return $daemon;

    $identity = dmd_agent_verify_instance_identity();
    if (empty($identity['ok'])) return array('ok'=>false,'error'=>'instance_identity_invalid');
    $cfg = dmd_agent_json_read(dmd_remote_ws_config_path(), array());
    $secret = !empty($cfg['ticket_secret']) ? base64_decode((string)$cfg['ticket_secret'], true) : false;
    if (!is_string($secret) || strlen($secret) !== 32) return array('ok'=>false,'error'=>'remote_ticket_secret_invalid');

    $allowed = array('video','control','screen','input','clipboard');
    $perms = array();
    foreach ($permissions as $permission) {
        $permission = trim((string)$permission);
        if (in_array($permission, $allowed, true) && !in_array($permission, $perms, true)) $perms[] = $permission;
    }
    $ttl = max(30, min(300, $ttl));
    $claims = array(
        'v'=>1,
        'instance_id'=>(string)$identity['manifest']['instance_id'],
        'kind'=>$kind,
        'agent_id'=>$agentId,
        'permissions'=>$perms,
        'exp'=>time()+$ttl,
        'nonce'=>dmd_remote_ws_b64url(random_bytes(18)),
    );
    $payload = json_encode($claims, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if (!is_string($payload)) return array('ok'=>false,'error'=>'remote_ticket_encode_failed');
    $signature = hash_hmac('sha256', $payload, $secret, true);
    if (function_exists('sodium_memzero')) @sodium_memzero($secret);
    return array(
        'ok'=>true,
        'ticket'=>dmd_remote_ws_b64url($payload).'.'.dmd_remote_ws_b64url($signature),
        'remote_url'=>dmd_remote_ws_public_url(),
        'expires_at'=>$claims['exp'],
        'permissions'=>$perms,
    );
}
