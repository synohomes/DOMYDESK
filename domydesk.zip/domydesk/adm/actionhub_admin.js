(function () {
    'use strict';

    const cfg = window.DMDActionHubAdminConfig || {};
    const state = {
        scenarios: [],
        trashUsers: [],
        trashTotal: 0,
        currentTrashUser: null,
        trashItems: [],
        catalog: [],
        users: [],
        draft: null,
        busy: false,
        searchTimer: null,
        openStepIndex: 0
    };

    const listEl = document.getElementById('ahScenarioList');
    const countEl = document.getElementById('ahScenarioCount');
    const resourceListEl = document.getElementById('ahResourceList');
    const resourceCountEl = document.getElementById('ahResourceCount');
    const trashModal = document.getElementById('ahTrashModal');
    const trashItemsEl = document.getElementById('ahTrashItems');
    const trashModalTitle = document.getElementById('ahTrashModalTitle');
    const trashModalSubtitle = document.getElementById('ahTrashModalSubtitle');
    const trashModalCount = document.getElementById('ahTrashModalCount');
    const trashEmptyBtn = document.getElementById('ahTrashEmpty');
    const messageEl = document.getElementById('ahAdminMessage');
    const searchEl = document.getElementById('ahScenarioSearch');
    const modal = document.getElementById('ahScenarioModal');
    const stepsEl = document.getElementById('ahScenarioSteps');

    function esc(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[ch];
        });
    }

    function safeText(value, fallback) {
        const text = String(value == null ? '' : value).trim();
        return text !== '' ? text : (fallback || '');
    }

    function showMessage(text, type) {
        if (!messageEl) return;
        messageEl.hidden = !text;
        messageEl.textContent = text || '';
        messageEl.classList.remove('is-ok', 'is-error');
        if (type === 'ok') messageEl.classList.add('is-ok');
        if (type === 'error') messageEl.classList.add('is-error');
    }

    async function request(action, method, payload, query) {
        const params = new URLSearchParams(Object.assign({ action: action }, query || {}));
        const options = {
            method: method || 'GET',
            cache: 'no-store',
            headers: {}
        };

        if ((method || 'GET').toUpperCase() !== 'GET') {
            if (cfg.csrfToken) options.headers['X-DMD-CSRF'] = cfg.csrfToken;
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(payload || {});
        }

        const response = await fetch(cfg.apiUrl + '?' + params.toString(), options);
        let data = {};
        try { data = await response.json(); } catch (e) { data = {}; }

        if (!response.ok || !data.ok) {
            const error = new Error(data.message || data.error || (action + '_failed'));
            error.data = data;
            throw error;
        }
        return data;
    }

    function scenarioKeywordsText(scenario) {
        return Array.isArray(scenario && scenario.keywords)
            ? scenario.keywords.join(', ')
            : safeText(scenario && scenario.keywords, '');
    }

    function formatDate(timestamp) {
        const ts = Number(timestamp || 0);
        if (!ts) return 'Jamais';
        try {
            return new Intl.DateTimeFormat('fr-FR', {
                dateStyle: 'short',
                timeStyle: 'short'
            }).format(new Date(ts * 1000));
        } catch (e) {
            return new Date(ts * 1000).toLocaleString();
        }
    }

    function renderList() {
        if (!listEl) return;
        const items = Array.isArray(state.scenarios) ? state.scenarios : [];
        if (countEl) {
            countEl.textContent = items.length + ' scénario' + (items.length > 1 ? 's' : '');
        }

        if (!items.length) {
            listEl.innerHTML = '<div class="ah-admin-empty">Aucun scénario ActionHub. Clique sur « Nouveau scénario » pour en créer un.</div>';
            return;
        }

        listEl.innerHTML = items.map(function (scenario) {
            const steps = Number(scenario.step_count || (Array.isArray(scenario.steps) ? scenario.steps.length : 0)) || 0;
            const keywords = scenarioKeywordsText(scenario);
            const dashboard = !!(scenario.workspace && scenario.workspace.create_dashboard);
            const lastRun = scenario.last_run_at ? formatDate(scenario.last_run_at) : 'Jamais exécuté';
            const lastState = scenario.last_run_at
                ? (scenario.last_run_ok ? '✓ Dernière exécution OK' : '✗ Dernière exécution en erreur')
                : '';

            return '<article class="ah-admin-card">' +
                '<div class="ah-admin-card-main">' +
                    '<strong>⚡ ' + esc(scenario.name || 'Scénario') + '</strong>' +
                    '<div class="ah-admin-card-meta">' +
                        '<span class="ah-admin-chip">' + steps + ' étape' + (steps > 1 ? 's' : '') + '</span>' +
                        (dashboard ? '<span class="ah-admin-chip">🖥 Dashboard</span>' : '') +
                        (keywords ? '<span class="ah-admin-chip">🔎 ' + esc(keywords) + '</span>' : '') +
                        '<span class="ah-admin-chip">🕘 ' + esc(lastRun) + '</span>' +
                        (lastState ? '<span class="ah-admin-chip">' + esc(lastState) + '</span>' : '') +
                    '</div>' +
                    (scenario.description ? '<p>' + esc(scenario.description) + '</p>' : '') +
                '</div>' +
                '<div class="ah-admin-card-actions">' +
                    '<button type="button" data-ah-edit="' + esc(scenario.id) + '">Modifier</button>' +
                    '<button type="button" data-ah-duplicate="' + esc(scenario.id) + '">Dupliquer</button>' +
                    '<button type="button" class="is-danger" data-ah-delete="' + esc(scenario.id) + '">Supprimer</button>' +
                '</div>' +
            '</article>';
        }).join('');
    }

    async function loadScenarios(query) {
        const data = await request('scenarios', 'GET', null, { q: safeText(query, '') });
        state.scenarios = Array.isArray(data.scenarios) ? data.scenarios : [];
        renderList();
    }

    function trashUserSearchText(user) {
        return [
            user && user.name,
            user && user.email,
            user && user.role_system,
            user && user.count
        ].map(function (value) { return safeText(value, '').toLowerCase(); }).join(' ');
    }

    function renderTrashUsers(query) {
        if (!resourceListEl) return;
        if (!cfg.isSuperadmin) {
            if (resourceCountEl) resourceCountEl.textContent = 'Accès Superadmin';
            resourceListEl.innerHTML = '<div class="ah-admin-empty">La consultation et la purge des corbeilles ActionHub sont réservées au Superadmin.</div>';
            return;
        }

        const needle = safeText(query, '').toLowerCase();
        const allUsers = Array.isArray(state.trashUsers) ? state.trashUsers : [];
        const users = needle
            ? allUsers.filter(function (user) { return trashUserSearchText(user).includes(needle); })
            : allUsers;
        const visibleTotal = users.reduce(function (sum, user) { return sum + Number(user && user.count || 0); }, 0);

        if (resourceCountEl) {
            resourceCountEl.textContent = visibleTotal + ' élément' + (visibleTotal > 1 ? 's' : '') + ' en corbeille';
        }

        if (!users.length) {
            resourceListEl.innerHTML = '<div class="ah-admin-empty">' +
                (needle ? 'Aucune corbeille utilisateur ne correspond à cette recherche.' : 'Toutes les corbeilles ActionHub sont vides.') +
                '</div>';
            return;
        }

        resourceListEl.innerHTML = users.map(function (user) {
            const count = Number(user && user.count || 0);
            const name = safeText(user && user.name, safeText(user && user.email, 'Utilisateur'));
            const email = safeText(user && user.email, '');
            const role = safeText(user && user.role_system, 'user');
            const last = user && user.last_trashed_at ? formatDate(user.last_trashed_at) : '—';
            return '<article class="ah-admin-card ah-admin-trash-user-card">' +
                '<div class="ah-admin-card-main">' +
                    '<strong>🗑 ' + esc(name) + '</strong>' +
                    '<div class="ah-admin-card-meta">' +
                        '<span class="ah-admin-chip">' + esc(email) + '</span>' +
                        '<span class="ah-admin-chip">' + esc(role) + '</span>' +
                        '<span class="ah-admin-chip">' + count + ' élément' + (count > 1 ? 's' : '') + '</span>' +
                    '</div>' +
                    '<small>Dernier retrait : ' + esc(last) + '</small>' +
                '</div>' +
                '<div class="ah-admin-card-actions">' +
                    '<button type="button" data-ah-trash-open="' + esc(email) + '">Ouvrir</button>' +
                '</div>' +
            '</article>';
        }).join('');
    }

    async function loadTrashUsers() {
        if (!cfg.isSuperadmin) {
            state.trashUsers = [];
            state.trashTotal = 0;
            renderTrashUsers(searchEl ? searchEl.value : '');
            return;
        }
        const data = await request('trash_users', 'GET');
        state.trashUsers = Array.isArray(data.users) ? data.users : [];
        state.trashTotal = Number(data.total || 0);
        renderTrashUsers(searchEl ? searchEl.value : '');
    }

    function trashEventHtml(event) {
        const action = safeText(event && event.action, safeText(event && event.label, 'action'));
        const label = safeText(event && event.label, '');
        const target = safeText(event && event.target, '');
        const status = safeText(event && event.status, 'info');
        const details = safeText(event && event.details, '');
        const when = event && event.timestamp ? formatDate(event.timestamp) : '—';
        return '<div class="ah-admin-trash-event">' +
            '<div class="ah-admin-trash-event-head">' +
                '<strong>' + esc(action) + '</strong>' +
                '<span class="ah-admin-chip">' + esc(status) + '</span>' +
                '<small>' + esc(when) + '</small>' +
            '</div>' +
            (label && label !== action ? '<div class="ah-admin-trash-event-line"><b>Action :</b> ' + esc(label) + '</div>' : '') +
            (target ? '<div class="ah-admin-trash-event-line"><b>Cible :</b> ' + esc(target) + '</div>' : '') +
            (details ? '<div class="ah-admin-trash-event-line"><b>Détails :</b> ' + esc(details) + '</div>' : '') +
        '</div>';
    }

    function renderTrashItems() {
        if (!trashItemsEl) return;
        const items = Array.isArray(state.trashItems) ? state.trashItems : [];
        if (trashModalCount) trashModalCount.textContent = items.length + ' élément' + (items.length > 1 ? 's' : '');
        if (trashEmptyBtn) trashEmptyBtn.disabled = !items.length || state.busy;

        if (!items.length) {
            trashItemsEl.innerHTML = '<div class="ah-admin-empty">Cette corbeille est vide.</div>';
            return;
        }

        trashItemsEl.innerHTML = items.map(function (item) {
            const resource = item && item.resource && typeof item.resource === 'object' ? item.resource : {};
            const label = safeText(resource.name || resource.label, resource.id || 'Ressource');
            const type = safeText(resource.type, 'object');
            const source = safeText(item && item.module, safeText(resource.source, ''));
            const status = safeText(item && item.last_status, '—');
            const movedAt = item && item.trashed_at ? formatDate(item.trashed_at) : '—';
            const lastSeen = item && item.last_seen ? formatDate(item.last_seen) : '—';
            const events = Array.isArray(item && item.events) ? item.events : [];
            const eventHtml = events.length
                ? events.slice().reverse().map(trashEventHtml).join('')
                : '<div class="ah-admin-empty">Aucune action détaillée enregistrée pour cette ressource.</div>';

            return '<details class="ah-admin-trash-item">' +
                '<summary>' +
                    '<span class="ah-admin-trash-item-main">' +
                        '<strong>📦 ' + esc(label) + '</strong>' +
                        '<small>Retiré le ' + esc(movedAt) + ' · dernière activité ' + esc(lastSeen) + '</small>' +
                    '</span>' +
                    '<span class="ah-admin-trash-item-meta">' +
                        '<span class="ah-admin-chip">' + esc(type) + '</span>' +
                        (source ? '<span class="ah-admin-chip">' + esc(source) + '</span>' : '') +
                        '<span class="ah-admin-chip">' + esc(status) + '</span>' +
                        '<span class="ah-admin-chip">' + events.length + ' action' + (events.length > 1 ? 's' : '') + '</span>' +
                    '</span>' +
                '</summary>' +
                '<div class="ah-admin-trash-events">' + eventHtml + '</div>' +
            '</details>';
        }).join('');
    }

    async function openTrash(userEmail) {
        if (!cfg.isSuperadmin || !userEmail || state.busy) return;
        state.busy = true;
        try {
            if (trashModal) {
                trashModal.classList.add('is-open');
                trashModal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('ah-admin-modal-open');
            }
            if (trashItemsEl) trashItemsEl.innerHTML = '<div class="ah-admin-empty">Chargement de la corbeille…</div>';
            const data = await request('trash_items', 'GET', null, { user: userEmail, limit: 500 });
            state.currentTrashUser = data.owner || { email: userEmail, name: userEmail };
            state.trashItems = Array.isArray(data.items) ? data.items : [];
            const name = safeText(state.currentTrashUser.name, userEmail);
            if (trashModalTitle) trashModalTitle.textContent = '🗑 Corbeille — ' + name;
            if (trashModalSubtitle) trashModalSubtitle.textContent = userEmail + ' · les objets réels des modules ne sont jamais supprimés ici.';
            renderTrashItems();
        } catch (error) {
            closeTrashModal();
            showMessage(error.message || 'Impossible d’ouvrir cette corbeille.', 'error');
        } finally {
            state.busy = false;
            if (trashEmptyBtn) trashEmptyBtn.disabled = !state.trashItems.length;
        }
    }

    function closeTrashModal() {
        if (!trashModal) return;
        trashModal.classList.remove('is-open');
        trashModal.setAttribute('aria-hidden', 'true');
        state.currentTrashUser = null;
        state.trashItems = [];
        if (!modal || !modal.classList.contains('is-open')) document.body.classList.remove('ah-admin-modal-open');
    }

    async function emptyCurrentTrash() {
        if (!cfg.isSuperadmin || state.busy || !state.currentTrashUser) return;
        const owner = state.currentTrashUser;
        const count = state.trashItems.length;
        if (!count) return;
        const name = safeText(owner.name, owner.email || 'cet utilisateur');
        const ok = window.confirm(
            'Vider définitivement la corbeille ActionHub de « ' + name + ' » (' + count + ' élément' + (count > 1 ? 's' : '') + ') ?\n\n' +
            'Les historiques ActionHub contenus dans cette corbeille seront supprimés définitivement.\n' +
            'Les VM, tickets, entités Home Assistant et autres objets réels ne seront jamais supprimés.'
        );
        if (!ok) return;

        state.busy = true;
        if (trashEmptyBtn) trashEmptyBtn.disabled = true;
        try {
            const result = await request('trash_empty', 'POST', { user: owner.email });
            const deleted = Number(result.deleted || count);
            closeTrashModal();
            await loadTrashUsers();
            showMessage('Corbeille de ' + name + ' vidée : ' + deleted + ' élément' + (deleted > 1 ? 's' : '') + ' supprimé' + (deleted > 1 ? 's' : '') + ' définitivement.', 'ok');
        } catch (error) {
            showMessage(error.message || 'Impossible de vider cette corbeille.', 'error');
        } finally {
            state.busy = false;
            if (trashEmptyBtn && trashModal && trashModal.classList.contains('is-open')) trashEmptyBtn.disabled = !state.trashItems.length;
        }
    }

    async function loadCatalog() {
        if (state.catalog.length) return;
        const data = await request('scenario_catalog', 'GET');
        state.catalog = Array.isArray(data.catalog) ? data.catalog : [];
        state.users = Array.isArray(data.users) ? data.users : [];
    }

    function catalogActions() {
        const out = [];
        state.catalog.forEach(function (module) {
            const moduleId = safeText(module && module.module, '');
            const moduleName = safeText(module && module.name, moduleId);
            (Array.isArray(module && module.actions) ? module.actions : []).forEach(function (action) {
                out.push({
                    module: moduleId,
                    moduleName: moduleName,
                    id: safeText(action && action.id, ''),
                    label: safeText(action && action.label, ''),
                    group: safeText(action && action.group, 'Général'),
                    description: safeText(action && action.description, ''),
                    dangerous: !!(action && action.dangerous),
                    confirm: safeText(action && action.confirm, ''),
                    inputs: Array.isArray(action && action.inputs) ? action.inputs : []
                });
            });
        });
        return out.filter(function (action) { return action.module && action.id; });
    }

    function findAction(moduleId, actionId) {
        return catalogActions().find(function (action) {
            return action.module === moduleId && action.id === actionId;
        }) || null;
    }

    function moduleCatalog() {
        return state.catalog.map(function (module) {
            return { id: safeText(module && module.module, ''), name: safeText(module && module.name, safeText(module && module.module, '')) };
        }).filter(function (module) { return module.id; });
    }

    function actionsForModule(moduleId) {
        return catalogActions().filter(function (action) { return action.module === moduleId; });
    }

    function groupsForModule(moduleId) {
        const seen = new Set();
        const groups = [];
        actionsForModule(moduleId).forEach(function (action) {
            const group = safeText(action.group, 'Général');
            if (!seen.has(group)) { seen.add(group); groups.push(group); }
        });
        return groups;
    }

    function actionsForGroup(moduleId, group) {
        return actionsForModule(moduleId).filter(function (action) { return safeText(action.group, 'Général') === group; });
    }

    function resetStepToAction(step, action) {
        if (!step || !action) return;
        step.module = action.module;
        step.action_id = action.id;
        step.payload = {};
        action.inputs.forEach(function (input) { step.payload[input.id] = defaultValueForInput(input); });
    }

    function defaultValueForInput(input) {
        if (!input || typeof input !== 'object') return '';
        if (input.type === 'boolean') return !!input.default;
        if (input.type === 'users') return Array.isArray(input.default) ? input.default.slice() : [];
        if (input.type === 'list') return Array.isArray(input.default) ? input.default.join('\n') : safeText(input.default, '');
        if (input.type === 'select') {
            if (input.default != null && String(input.default) !== '') return String(input.default);
            const options = Array.isArray(input.options) ? input.options : [];
            for (const option of options) {
                const value = safeText(option && option.value, '');
                if (value !== '') return value;
            }
            return '';
        }
        return input.default == null ? '' : input.default;
    }

    function newStep() {
        const action = catalogActions()[0] || null;
        const payload = {};
        if (action) {
            action.inputs.forEach(function (input) {
                payload[input.id] = defaultValueForInput(input);
            });
        }
        return {
            id: 'step_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            module: action ? action.module : '',
            action_id: action ? action.id : '',
            payload: payload
        };
    }

    function draftFromScenario(scenario) {
        const source = scenario && typeof scenario === 'object' ? scenario : {};
        return {
            id: safeText(source.id, ''),
            name: safeText(source.name, ''),
            description: safeText(source.description, ''),
            keywords: scenarioKeywordsText(source),
            workspace: {
                create_dashboard: !!(source.workspace && source.workspace.create_dashboard),
                dashboard_name: safeText(source.workspace && source.workspace.dashboard_name, '')
            },
            steps: Array.isArray(source.steps) ? source.steps.map(function (step, index) {
                return {
                    id: safeText(step && step.id, 'step_' + (index + 1)),
                    module: safeText(step && step.module, ''),
                    action_id: safeText(step && step.action_id, ''),
                    payload: Object.assign({}, (step && step.payload) || {})
                };
            }) : []
        };
    }

    function inputHtml(input, value, stepIndex) {
        const id = safeText(input && input.id, '');
        const label = safeText(input && input.label, id);
        const required = input && input.required ? ' *' : '';
        const placeholder = input && input.placeholder ? ' placeholder="' + esc(input.placeholder) + '"' : '';
        const attr = 'data-ah-step-input="' + stepIndex + '" data-ah-input-id="' + esc(id) + '"';
        let control = '';

        const fieldType = safeText(input && input.type, 'text');
        const wideField = ['textarea', 'list', 'users'].includes(fieldType);

        if (input.type === 'textarea' || input.type === 'list') {
            const textValue = Array.isArray(value) ? value.join('\n') : String(value == null ? '' : value);
            control = '<textarea ' + attr + placeholder + ' rows="' + (input.type === 'list' ? 3 : 2) + '">' + esc(textValue) + '</textarea>';
        } else if (input.type === 'users') {
            const selected = Array.isArray(value) ? value.map(String) : [];
            const users = state.users.map(function (user) {
                const email = safeText(user && user.email, '');
                const name = safeText(user && user.name, email) || email;
                if (!email) return '';
                return '<label class="ah-admin-user-choice" title="' + esc(name + ' — ' + email) + '">' +
                    '<input type="checkbox" data-ah-users-step="' + stepIndex + '" data-ah-users-input="' + esc(id) + '" value="' + esc(email) + '"' + (selected.includes(email) ? ' checked' : '') + '>' +
                    '<span class="ah-admin-user-choice-copy"><strong>' + esc(name) + '</strong><small>' + esc(email) + '</small></span>' +
                '</label>';
            }).join('');
            const selectedCount = selected.filter(Boolean).length;
            const summaryText = selectedCount
                ? selectedCount + ' utilisateur' + (selectedCount > 1 ? 's' : '') + ' sélectionné' + (selectedCount > 1 ? 's' : '')
                : 'Choisir les utilisateurs';
            control = '<details class="ah-admin-users-dropdown">' +
                '<summary><span data-ah-users-summary="' + stepIndex + '|' + esc(id) + '">' + esc(summaryText) + '</span><span class="ah-admin-users-chevron">▾</span></summary>' +
                '<div class="ah-admin-user-options">' + (users || '<div class="ah-admin-user-empty">Aucun autre utilisateur disponible.</div>') + '</div>' +
            '</details>';
            const safeIdClass = id.replace(/[^a-zA-Z0-9_-]+/g, '-');
            return '<div class="ah-admin-field ah-admin-field-users ah-admin-field-id-' + esc(safeIdClass) + ' is-wide"><span>' + esc(label + required) + '</span>' + control + (input.help ? '<small>' + esc(input.help) + '</small>' : '') + '</div>';
        } else if (input.type === 'select') {
            const options = (Array.isArray(input.options) ? input.options : []).map(function (option) {
                const optionValue = safeText(option && option.value, '');
                return '<option value="' + esc(optionValue) + '"' + (String(value == null ? '' : value) === optionValue ? ' selected' : '') + '>' + esc((option && option.label) || optionValue) + '</option>';
            }).join('');
            control = '<select ' + attr + '>' + options + '</select>';
        } else if (input.type === 'boolean') {
            control = '<label class="ah-admin-checkline"><input ' + attr + ' type="checkbox"' + (value ? ' checked' : '') + '><span>' + esc(label) + '</span></label>';
            return '<div class="ah-admin-field">' + control + (input.help ? '<small>' + esc(input.help) + '</small>' : '') + '</div>';
        } else {
            const type = input.type === 'date' || input.type === 'number' ? input.type : 'text';
            control = '<input ' + attr + ' type="' + type + '" value="' + esc(value == null ? '' : value) + '"' + placeholder + '>';
        }

        const safeIdClass = id.replace(/[^a-zA-Z0-9_-]+/g, '-');
        return '<label class="ah-admin-field ah-admin-field-' + esc(fieldType) + ' ah-admin-field-id-' + esc(safeIdClass) + (wideField ? ' is-wide' : '') + '"><span>' + esc(label + required) + '</span>' + control + (input.help ? '<small>' + esc(input.help) + '</small>' : '') + '</label>';
    }

    function updateUsersDropdownSummary(field) {
        if (!field) return;
        const stepIndex = Number(field.dataset.ahUsersStep);
        const inputId = safeText(field.dataset.ahUsersInput, '');
        if (!Number.isFinite(stepIndex) || !inputId) return;

        const selector = '[data-ah-users-step="' + stepIndex + '"][data-ah-users-input="' + CSS.escape(inputId) + '"]:checked';
        const checked = Array.from(document.querySelectorAll(selector));
        const details = field.closest('.ah-admin-users-dropdown');
        const summary = details ? details.querySelector('[data-ah-users-summary]') : null;
        if (!summary) return;

        const count = checked.length;
        summary.textContent = count
            ? count + ' utilisateur' + (count > 1 ? 's' : '') + ' sélectionné' + (count > 1 ? 's' : '')
            : 'Choisir les utilisateurs';
    }

    function syncDraftHeaderFromForm() {
        if (!state.draft) return;
        state.draft.id = safeText(document.getElementById('ahScenarioId').value, '');
        state.draft.name = document.getElementById('ahScenarioName').value;
        state.draft.keywords = document.getElementById('ahScenarioKeywords').value;
        state.draft.description = document.getElementById('ahScenarioDescription').value;
        state.draft.workspace = state.draft.workspace || {};
        state.draft.workspace.create_dashboard = !!document.getElementById('ahCreateDashboard').checked;
        state.draft.workspace.dashboard_name = document.getElementById('ahDashboardName').value;
    }

    function syncStepInputsFromDom() {
        if (!state.draft || !Array.isArray(state.draft.steps)) return;

        document.querySelectorAll('[data-ah-step-input]').forEach(function (field) {
            const index = Number(field.dataset.ahStepInput);
            const inputId = safeText(field.dataset.ahInputId, '');
            if (!state.draft.steps[index] || !inputId) return;
            state.draft.steps[index].payload[inputId] = field.type === 'checkbox' ? !!field.checked : field.value;
        });

        document.querySelectorAll('[data-ah-users-input]').forEach(function (field) {
            const index = Number(field.dataset.ahUsersStep);
            const inputId = safeText(field.dataset.ahUsersInput, '');
            if (!state.draft.steps[index] || !inputId) return;
            const selector = '[data-ah-users-step="' + index + '"][data-ah-users-input="' + CSS.escape(inputId) + '"]:checked';
            state.draft.steps[index].payload[inputId] = Array.from(document.querySelectorAll(selector)).map(function (item) { return item.value; });
        });
    }

    function stepSummary(step, action, index) {
        const payload = step && step.payload && typeof step.payload === 'object' ? step.payload : {};
        const title = safeText(payload.title, '');
        const target = title ? ' · ' + title : '';
        return 'Étape ' + (index + 1) + ' · ' + safeText(action && action.moduleName, step.module || '') + ' — ' + safeText(action && action.label, step.action_id || 'Action') + target;
    }

    function renderSteps() {
        if (!stepsEl || !state.draft) return;
        const actions = catalogActions();

        if (!actions.length) {
            stepsEl.innerHTML = '<div class="ah-admin-empty">Aucun module installé ne déclare encore d’action compatible avec les scénarios.</div>';
            return;
        }

        if (!state.draft.steps.length) state.draft.steps.push(newStep());
        if (state.openStepIndex < -1 || state.openStepIndex >= state.draft.steps.length) state.openStepIndex = 0;

        stepsEl.innerHTML = state.draft.steps.map(function (step, index) {
            let action = findAction(step.module, step.action_id);
            if (!action) {
                action = actions[0];
                step.module = action.module;
                step.action_id = action.id;
                step.payload = {};
                action.inputs.forEach(function (input) { step.payload[input.id] = defaultValueForInput(input); });
            }

            const moduleOptions = moduleCatalog().map(function (module) {
                return '<option value="' + esc(module.id) + '"' + (module.id === step.module ? ' selected' : '') + '>' + esc(module.name) + '</option>';
            }).join('');
            const currentGroup = safeText(action.group, 'Général');
            const groupOptions = groupsForModule(step.module).map(function (group) {
                return '<option value="' + esc(group) + '"' + (group === currentGroup ? ' selected' : '') + '>' + esc(group) + '</option>';
            }).join('');
            const actionOptions = actionsForGroup(step.module, currentGroup).map(function (candidate) {
                return '<option value="' + esc(candidate.id) + '"' + (candidate.id === step.action_id ? ' selected' : '') + '>' + esc(candidate.label) + '</option>';
            }).join('');

            const fields = action.inputs.map(function (input) {
                return inputHtml(input, step.payload ? step.payload[input.id] : '', index);
            }).join('');
            const isOpen = index === state.openStepIndex;

            return '<article class="ah-admin-step' + (isOpen ? ' is-open' : '') + '">' +
                '<div class="ah-admin-step-head">' +
                    '<span class="ah-admin-step-number">' + (index + 1) + '</span>' +
                    '<span class="ah-admin-step-summary" title="' + esc(stepSummary(step, action, index)) + '">' + esc(stepSummary(step, action, index)) + '</span>' +
                    '<button type="button" class="ah-admin-step-toggle" data-ah-step-toggle="' + index + '">' + (isOpen ? 'Réduire' : 'Configurer') + '</button>' +
                    '<button type="button" class="ah-admin-step-remove" data-ah-step-remove="' + index + '" aria-label="Supprimer cette étape">×</button>' +
                '</div>' +
                '<div class="ah-admin-step-body">' +
                    '<div class="ah-admin-step-selector">' +
                        '<label class="ah-admin-field"><span>Module</span><select data-ah-step-module="' + index + '">' + moduleOptions + '</select></label>' +
                        '<label class="ah-admin-field"><span>Catégorie</span><select data-ah-step-group="' + index + '">' + groupOptions + '</select></label>' +
                        '<label class="ah-admin-field"><span>Action</span><select data-ah-step-action="' + index + '">' + actionOptions + '</select></label>' +
                    '</div>' +
                    (action.description ? '<p class="ah-admin-step-description">' + esc(action.description) + '</p>' : '') +
                    '<div class="ah-admin-step-fields">' + fields + '</div>' +
                '</div>' +
            '</article>';
        }).join('');
    }

    function openModal(scenario, duplicate) {
        state.draft = draftFromScenario(scenario || {});
        if (duplicate) {
            state.draft.id = '';
            state.draft.name = safeText(state.draft.name, 'Scénario') + ' - copie';
        }
        if (!state.draft.steps.length) state.draft.steps.push(newStep());
        state.openStepIndex = 0;

        document.getElementById('ahScenarioId').value = state.draft.id || '';
        document.getElementById('ahScenarioName').value = state.draft.name || '';
        document.getElementById('ahScenarioKeywords').value = state.draft.keywords || '';
        document.getElementById('ahScenarioDescription').value = state.draft.description || '';
        document.getElementById('ahCreateDashboard').checked = !!state.draft.workspace.create_dashboard;
        document.getElementById('ahDashboardName').value = state.draft.workspace.dashboard_name || '';
        document.getElementById('ahDashboardNameWrap').hidden = !state.draft.workspace.create_dashboard;
        document.getElementById('ahScenarioModalTitle').textContent = state.draft.id ? 'Modifier le scénario' : 'Nouveau scénario';

        renderSteps();
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('ah-admin-modal-open');
        window.setTimeout(function () { document.getElementById('ahScenarioName').focus(); }, 40);
    }

    function closeModal() {
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('ah-admin-modal-open');
        state.draft = null;
    }

    async function saveScenario() {
        if (!state.draft || state.busy) return;
        syncDraftHeaderFromForm();
        syncStepInputsFromDom();

        if (!safeText(state.draft.name, '')) {
            showMessage('Le nom du scénario est obligatoire.', 'error');
            return;
        }

        state.busy = true;
        document.getElementById('ahScenarioSave').disabled = true;
        try {
            const data = await request('scenario_save', 'POST', { scenario: state.draft });
            closeModal();
            showMessage('Scénario « ' + safeText(data.scenario && data.scenario.name, '') + ' » enregistré.', 'ok');
            await loadScenarios(searchEl ? searchEl.value : '');
        } catch (error) {
            showMessage(error.message || 'Impossible d’enregistrer le scénario.', 'error');
        } finally {
            state.busy = false;
            document.getElementById('ahScenarioSave').disabled = false;
        }
    }

    async function deleteScenario(id) {
        if (!id || state.busy) return;
        const scenario = state.scenarios.find(function (item) { return String(item.id || '') === String(id); });
        if (!window.confirm('Supprimer définitivement le scénario « ' + safeText(scenario && scenario.name, id) + ' » ?')) return;

        state.busy = true;
        try {
            await request('scenario_delete', 'POST', { id: id });
            showMessage('Scénario supprimé.', 'ok');
            await loadScenarios(searchEl ? searchEl.value : '');
        } catch (error) {
            showMessage(error.message || 'Impossible de supprimer le scénario.', 'error');
        } finally {
            state.busy = false;
        }
    }

    document.getElementById('ahNewScenario').addEventListener('click', function () { openModal(null, false); });
    document.getElementById('ahRefresh').addEventListener('click', function () {
        Promise.all([
            loadScenarios(searchEl ? searchEl.value : ''),
            loadTrashUsers()
        ]).catch(function (error) {
            showMessage(error.message || 'Actualisation impossible.', 'error');
        });
    });
    document.getElementById('ahScenarioModalClose').addEventListener('click', closeModal);
    document.getElementById('ahScenarioCancel').addEventListener('click', closeModal);
    document.getElementById('ahScenarioSave').addEventListener('click', saveScenario);
    document.getElementById('ahAddStep').addEventListener('click', function () {
        if (!state.draft) return;
        syncDraftHeaderFromForm();
        syncStepInputsFromDom();
        state.draft.steps.push(newStep());
        state.openStepIndex = state.draft.steps.length - 1;
        renderSteps();
    });

    document.getElementById('ahCreateDashboard').addEventListener('change', function () {
        document.getElementById('ahDashboardNameWrap').hidden = !this.checked;
    });

    if (searchEl) {
        searchEl.addEventListener('input', function () {
            window.clearTimeout(state.searchTimer);
            state.searchTimer = window.setTimeout(function () {
                renderTrashUsers(searchEl.value);
                loadScenarios(searchEl.value).catch(function (error) {
                    showMessage(error.message || 'Recherche impossible.', 'error');
                });
            }, 160);
        });
    }

    if (resourceListEl) {
        resourceListEl.addEventListener('click', function (event) {
            const open = event.target.closest('[data-ah-trash-open]');
            if (open) openTrash(String(open.dataset.ahTrashOpen || ''));
        });
    }

    if (document.getElementById('ahTrashModalClose')) document.getElementById('ahTrashModalClose').addEventListener('click', closeTrashModal);
    if (trashEmptyBtn) trashEmptyBtn.addEventListener('click', emptyCurrentTrash);
    if (trashModal) trashModal.addEventListener('click', function (event) {
        if (event.target === trashModal) closeTrashModal();
    });

    listEl.addEventListener('click', function (event) {
        const edit = event.target.closest('[data-ah-edit]');
        if (edit) {
            const scenario = state.scenarios.find(function (item) { return String(item.id || '') === String(edit.dataset.ahEdit || ''); });
            if (scenario) openModal(scenario, false);
            return;
        }

        const duplicate = event.target.closest('[data-ah-duplicate]');
        if (duplicate) {
            const scenario = state.scenarios.find(function (item) { return String(item.id || '') === String(duplicate.dataset.ahDuplicate || ''); });
            if (scenario) openModal(scenario, true);
            return;
        }

        const del = event.target.closest('[data-ah-delete]');
        if (del) deleteScenario(String(del.dataset.ahDelete || ''));
    });

    stepsEl.addEventListener('change', function (event) {
        const userChoice = event.target.closest('[data-ah-users-input]');
        if (userChoice) {
            updateUsersDropdownSummary(userChoice);
            return;
        }

        const moduleSelect = event.target.closest('[data-ah-step-module]');
        const groupSelect = event.target.closest('[data-ah-step-group]');
        const actionSelect = event.target.closest('[data-ah-step-action]');
        if ((!moduleSelect && !groupSelect && !actionSelect) || !state.draft) return;
        syncDraftHeaderFromForm();
        syncStepInputsFromDom();

        const index = Number(
            moduleSelect ? moduleSelect.dataset.ahStepModule :
            groupSelect ? groupSelect.dataset.ahStepGroup :
            actionSelect.dataset.ahStepAction
        );
        const step = state.draft.steps[index];
        if (!step) return;

        let action = null;
        if (moduleSelect) action = actionsForModule(String(moduleSelect.value || ''))[0] || null;
        else if (groupSelect) action = actionsForGroup(step.module, String(groupSelect.value || ''))[0] || null;
        else action = findAction(step.module, String(actionSelect.value || ''));

        if (!action) return;
        resetStepToAction(step, action);
        renderSteps();
    });

    stepsEl.addEventListener('click', function (event) {
        const toggle = event.target.closest('[data-ah-step-toggle]');
        if (toggle && state.draft) {
            syncDraftHeaderFromForm();
            syncStepInputsFromDom();
            const index = Number(toggle.dataset.ahStepToggle);
            state.openStepIndex = state.openStepIndex === index ? -1 : index;
            renderSteps();
            return;
        }

        const remove = event.target.closest('[data-ah-step-remove]');
        if (!remove || !state.draft) return;
        syncDraftHeaderFromForm();
        syncStepInputsFromDom();
        const index = Number(remove.dataset.ahStepRemove);
        state.draft.steps.splice(index, 1);
        if (!state.draft.steps.length) state.draft.steps.push(newStep());
        if (state.openStepIndex >= state.draft.steps.length) state.openStepIndex = state.draft.steps.length - 1;
        if (state.openStepIndex > index) state.openStepIndex--;
        renderSteps();
    });

    modal.addEventListener('click', function (event) {
        if (event.target === modal) closeModal();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        if (trashModal && trashModal.classList.contains('is-open')) {
            closeTrashModal();
            return;
        }
        if (modal.classList.contains('is-open')) closeModal();
    });

    Promise.all([loadCatalog(), loadScenarios(''), loadTrashUsers()]).catch(function (error) {
        showMessage(error.message || 'Impossible de charger ActionHub.', 'error');
        if (listEl) listEl.innerHTML = '<div class="ah-admin-empty">Impossible de charger les scénarios ActionHub.</div>';
        if (resourceListEl && cfg.isSuperadmin) resourceListEl.innerHTML = '<div class="ah-admin-empty">Impossible de charger les corbeilles ActionHub.</div>';
    });
})();
