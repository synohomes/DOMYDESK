<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_security.php';
require_once $baseDir . '/core/dmd_mfa.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_theme_assets.php';

$currentEmail = isset($_SESSION['user']['email']) ? dmd_safe_user_key($_SESSION['user']['email']) : '';
$currentProfile = $currentEmail !== '' ? dmd_read_profile($currentEmail) : array();
if ($currentEmail === '' || (string)($currentProfile['role_system'] ?? '') !== 'superadmin') {
    http_response_code(403);
    echo '<!doctype html><html lang="fr"><meta charset="utf-8"><body><p>Accès réservé au Superadmin.</p></body></html>';
    exit;
}

$theme = 'default';
$themePath = dmd_user_dir($currentEmail) . 'theme.json';
if (is_file($themePath)) {
    $themeData = json_decode((string)@file_get_contents($themePath), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file($baseDir . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    }
}

$message = '';
$error = '';
$csrf = dmd_csrf_token('mfa_admin_requests');
$currentMfaEnabled = dmd_mfa_enabled($currentEmail);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'mfa_admin_requests')) {
        $error = 'Formulaire expiré. Rechargez la page.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        $target = dmd_safe_user_key((string)($_POST['target_email'] ?? ''));
        $requestId = trim((string)($_POST['request_id'] ?? ''));
        $request = $target !== '' ? dmd_mfa_disable_request($target) : array();

        if (!in_array($action, array('approve', 'reject'), true) || $target === '' || $requestId === '') {
            $error = 'Demande invalide.';
        } elseif (empty($request) || !hash_equals((string)($request['request_id'] ?? ''), $requestId)) {
            $error = 'Cette demande n’est plus disponible ou a déjà été traitée.';
        } else {
            $password = (string)($_POST['current_password'] ?? '');
            $hash = (string)($currentProfile['motdepasse'] ?? ($currentProfile['password'] ?? ''));
            if ($hash === '' || !password_verify($password, $hash)) {
                $error = 'Mot de passe Superadmin incorrect.';
            } elseif ($currentMfaEnabled) {
                $usedRecovery = false;
                $adminCode = (string)($_POST['mfa_code'] ?? '');
                if (!dmd_mfa_verify_user_code($currentEmail, $adminCode, $usedRecovery)) {
                    $error = 'Code MFA Superadmin incorrect.';
                }
            }

            if ($error === '') {
                if ($action === 'approve') {
                    $targetProfile = dmd_read_profile($target);
                    $effectivePolicyBefore = dmd_mfa_effective_policy($target, $targetProfile);
                    $policyBefore = dmd_mfa_policy_read();
                    $createdDisabledException = false;

                    /*
                     * Si le MFA est imposé par le groupe ou la politique globale,
                     * l'approbation doit créer une exception utilisateur "disabled".
                     * Sinon, désactiver le secret seul provoquerait une réinscription
                     * MFA obligatoire dès la connexion suivante.
                     */
                    if ($effectivePolicyBefore === 'required') {
                        $policyAfter = $policyBefore;
                        if (!isset($policyAfter['users']) || !is_array($policyAfter['users'])) {
                            $policyAfter['users'] = array();
                        }
                        $policyAfter['users'][$target] = 'disabled';

                        if (!dmd_mfa_policy_write($policyAfter, $currentEmail)) {
                            $error = 'Impossible de créer l’exception utilisateur nécessaire à la désactivation MFA.';
                        } else {
                            $createdDisabledException = true;
                        }
                    }

                    if ($error === '' && !dmd_mfa_disable($target, $currentEmail)) {
                        /*
                         * Ne laisse pas une exception "disabled" nouvellement créée
                         * si l'effacement effectif du MFA a échoué.
                         */
                        if ($createdDisabledException && !dmd_mfa_policy_write($policyBefore, $currentEmail)) {
                            $error = 'Impossible de désactiver le MFA et impossible de restaurer la politique précédente. Vérifiez immédiatement la politique MFA de ce compte.';
                        } else {
                            $error = 'Impossible de désactiver le MFA du compte.';
                        }
                    }

                    if ($error === '') {
                        $effectivePolicyAfter = dmd_mfa_effective_policy($target, dmd_read_profile($target));
                        $message = 'Désactivation MFA approuvée pour ' . $target . '.';
                        if ($createdDisabledException) {
                            $message .= ' Une exception utilisateur « Désactivé » a été créée.';
                        }

                        dmd_system_log('mfa_disable_approved', $target, 'warning', 'Désactivation MFA approuvée par un Superadmin.', array(
                            'approved_by' => $currentEmail,
                            'request_id' => $requestId,
                            'policy_before' => $effectivePolicyBefore,
                            'policy_after' => $effectivePolicyAfter,
                            'disabled_exception_created' => $createdDisabledException,
                        ));

                        $notifyText = 'Votre demande a été validée par un Superadmin. Microsoft Authenticator est désormais désactivé sur votre compte.';
                        if ($createdDisabledException) {
                            $notifyText .= ' Une exception individuelle désactive également l’obligation MFA pour votre compte.';
                        }
                        dmd_notify_user($target, 'security', 'Désactivation MFA approuvée', $notifyText, array('level' => 'warning'));
                    }
                } else {
                    if (!dmd_mfa_clear_disable_request($target, $requestId)) {
                        $error = 'Impossible de refuser la demande.';
                    } else {
                        $message = 'Demande MFA refusée pour ' . $target . '. Le MFA reste actif.';
                        dmd_system_log('mfa_disable_rejected', $target, 'success', 'Demande de désactivation MFA refusée par un Superadmin.', array('rejected_by' => $currentEmail, 'request_id' => $requestId));
                        dmd_notify_user($target, 'security', 'Désactivation MFA refusée', 'Votre demande de désactivation MFA a été refusée par un Superadmin. Votre MFA reste actif.', array('level' => 'info'));
                    }
                }
            }
        }
    }
}

$requests = dmd_mfa_pending_disable_requests();
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Validations MFA - DoMyDesk</title>
    <link rel="stylesheet" href="../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <link rel="stylesheet" href="../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/pages/profile_edit.css">
    <?= dmd_theme_extra_links($baseDir, '../theme', $theme, 'profile_edit') ?>
    <style>
        .dmd-mfa-admin-wrap{max-width:1100px;margin:24px auto;padding:0 18px}.dmd-mfa-request-grid{display:grid;gap:14px}.dmd-mfa-request{border:1px solid var(--border-color);border-radius:10px;padding:16px;background:var(--card-bg,transparent)}.dmd-mfa-request-head{display:flex;gap:14px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap}.dmd-mfa-request-meta{opacity:.78;font-size:.92em}.dmd-mfa-admin-form{display:grid;grid-template-columns:minmax(180px,1fr) minmax(160px,.7fr) auto auto;gap:10px;align-items:end;margin-top:14px}.dmd-mfa-admin-form label{display:grid;gap:5px}.dmd-mfa-empty{padding:24px;text-align:center;opacity:.8}@media(max-width:850px){.dmd-mfa-admin-form{grid-template-columns:1fr}}
    </style>
</head>
<body>
<?php include $baseDir . '/header.php'; ?>
<main class="dmd-mfa-admin-wrap">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">🔐 Validations MFA</h1>
            <p class="pe-subtitle">Une désactivation demandée par un utilisateur ne prend effet qu’après validation Superadmin.</p>
        </div>
        <div><a class="btn" href="site_settings.php">← Administration</a></div>
    </div>

    <?php if ($message !== ''): ?><div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="pe-msg pe-msg-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

    <?php if (empty($requests)): ?>
        <div class="dmd-mfa-request dmd-mfa-empty">✅ Aucune demande de désactivation MFA en attente.</div>
    <?php else: ?>
        <div class="dmd-mfa-request-grid">
            <?php foreach ($requests as $item): ?>
                <?php
                    $displayName = trim((string)$item['first_name'] . ' ' . (string)$item['last_name']);
                    if ($displayName === '') $displayName = (string)$item['email'];
                    $requestedTs = strtotime((string)$item['requested_at']);
                ?>
                <section class="dmd-mfa-request">
                    <div class="dmd-mfa-request-head">
                        <div>
                            <strong><?= htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') ?></strong><br>
                            <span><?= htmlspecialchars((string)$item['email'], ENT_QUOTES, 'UTF-8') ?></span>
                            <div class="dmd-mfa-request-meta">Rôle : <?= htmlspecialchars((string)$item['role_system'], ENT_QUOTES, 'UTF-8') ?> · Demande : <?= $requestedTs ? htmlspecialchars(date('d/m/Y H:i', $requestedTs), ENT_QUOTES, 'UTF-8') : 'date inconnue' ?></div>
                        </div>
                        <span>⏳ MFA toujours actif</span>
                    </div>

                    <form method="post" class="dmd-mfa-admin-form" autocomplete="off">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="target_email" value="<?= htmlspecialchars((string)$item['email'], ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="request_id" value="<?= htmlspecialchars((string)$item['request_id'], ENT_QUOTES, 'UTF-8') ?>">
                        <label>Mot de passe Superadmin
                            <input type="password" name="current_password" required>
                        </label>
                        <?php if ($currentMfaEnabled): ?>
                            <label>Code MFA Superadmin
                                <input name="mfa_code" inputmode="numeric" autocomplete="one-time-code" required>
                            </label>
                        <?php else: ?>
                            <div class="dmd-mfa-request-meta">Votre compte Superadmin n’a pas de MFA actif : le mot de passe suffit pour cette validation.</div>
                        <?php endif; ?>
                        <button type="submit" class="btn" name="action" value="approve" onclick="return confirm('Approuver la désactivation MFA de ce compte ?');">Approuver</button>
                        <button type="submit" name="action" value="reject">Refuser</button>
                    </form>
                </section>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
</body>
</html>
