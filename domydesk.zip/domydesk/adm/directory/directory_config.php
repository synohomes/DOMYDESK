<?php
if (!$isSuperadmin) {
    http_response_code(403);
    exit('Accès réservé au Superadmin.');
}
$dmdDirectoryConfig = $dmdDirectoryConfig ?? dmd_directory_config_read(false);
$dmdDirectoryDetected = $dmdDirectoryDetected ?? dmd_directory_detect_local_domain((string)($dmdDirectoryConfig['domain'] ?? ''), (string)($dmdDirectoryConfig['host'] ?? ''));
$dmdDirectoryRoleMap = is_array($dmdDirectoryConfig['role_group_map'] ?? null) ? $dmdDirectoryConfig['role_group_map'] : [];
$dmdDirectoryCaInfo = dmd_directory_ca_info();
// IMPORTANT : les exemples affichés dans l'aide restent volontairement génériques.
// Ne jamais réinjecter le domaine, les DN, hôtes ou comptes réels de l'instance dans la procédure.
$dmdDirectoryExampleDomain = 'entreprise.local';
$dmdDirectoryDerivedBaseDn = 'DC=entreprise,DC=local';
$dmdDirectoryExampleHost = 'dc01.entreprise.local';
$dmdDirectoryExampleManagedOu = 'OU=DoMyDesk,DC=entreprise,DC=local';
$dmdDirectoryExampleBind = 'svc_domydesk@entreprise.local';
$dmdDirectoryExampleDelegationGroup = 'GG-DOMYDESK-LDAP';
$dmdDirectoryDisplayedSecurity = 'ldaps';
$dmdDirectoryDisplayedPort = 636;
?>
<style id="dmd-directory-ui-style">
.dmd-directory-ui{
    --dmd-dir-border:var(--border-color,var(--border,rgba(127,127,127,.32)));
    --dmd-dir-card:var(--card-bg,var(--panel-bg,transparent));
    --dmd-dir-input:var(--input-bg,rgba(0,0,0,.10));
    --dmd-dir-text:var(--text-color,var(--text,inherit));
    --dmd-dir-muted:var(--muted-color,var(--text-muted,rgba(220,225,232,.72)));
    --dmd-dir-accent:var(--accent-color,var(--accent,#d3ad53));
    display:grid;
    gap:14px;
    padding:14px !important;
    font-size:.94em;
}
.dmd-directory-ui *{box-sizing:border-box}
.dmd-directory-ui .pe-note{line-height:1.42;color:var(--dmd-dir-muted)}
.dmd-directory-ui code{font-size:.92em;overflow-wrap:anywhere}
.dmd-directory-ui .dmd-dir-intro{margin:0;padding:0 2px}
.dmd-directory-ui .dmd-dir-status-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:0}
.dmd-directory-ui .dmd-dir-status-card{min-width:0;padding:10px 12px;border:1px solid var(--dmd-dir-border);border-radius:10px;background:var(--dmd-dir-card)}
.dmd-directory-ui .dmd-dir-status-card>strong{display:block;font-size:.9em;margin-bottom:4px}
.dmd-directory-ui .dmd-dir-status-card .dmd-security-status{display:block;white-space:normal}
.dmd-directory-ui .dmd-dir-titlebar{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:2px}
.dmd-directory-ui .dmd-dir-titlebar h3{margin:0;font-size:1.06rem}
.dmd-directory-ui .dmd-dir-help-button,.dmd-directory-ui .dmd-directory-help-trigger{display:inline-flex!important;align-items:center;justify-content:center;width:26px!important;height:26px!important;min-width:26px!important;padding:0!important;border-radius:50%!important;font-weight:800;cursor:pointer}
.dmd-directory-ui .dmd-dir-callout{margin:0;padding:10px 12px;border:1px solid var(--dmd-dir-border);border-left:3px solid var(--dmd-dir-accent);border-radius:9px;background:color-mix(in srgb,var(--dmd-dir-accent) 6%,transparent)}
.dmd-directory-ui .dmd-dir-detection{margin:0;padding:0 2px}
.dmd-directory-ui .dmd-dir-card{margin:0;padding:13px;border:1px solid var(--dmd-dir-border);border-radius:11px;background:var(--dmd-dir-card);display:grid;gap:11px}
.dmd-directory-ui .dmd-dir-card-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0;padding-bottom:8px;border-bottom:1px solid var(--dmd-dir-border)}
.dmd-directory-ui .dmd-dir-card-title h3{margin:0;font-size:1rem}
.dmd-directory-ui .dmd-security-grid.dmd-dir-toggles{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:0}
.dmd-directory-ui .dmd-dir-toggle{padding:10px;border:1px solid var(--dmd-dir-border);border-radius:9px;min-width:0;background:color-mix(in srgb,var(--dmd-dir-input) 70%,transparent)}
.dmd-directory-ui .dmd-dir-toggle>label,.dmd-directory-ui .dmd-dir-toggle>strong{display:flex;align-items:center;gap:7px;margin:0 0 4px;font-weight:700}
.dmd-directory-ui .dmd-dir-toggle input[type="checkbox"]{width:auto;min-height:0;margin:0}
.dmd-directory-ui .dmd-dir-ca{padding:11px;border:1px solid var(--dmd-dir-border);border-radius:9px;background:color-mix(in srgb,var(--dmd-dir-input) 55%,transparent)}
.dmd-directory-ui .dmd-dir-ca-head{display:flex;align-items:center;gap:7px;margin-bottom:6px}
.dmd-directory-ui .dmd-dir-ca input[type="file"]{margin:7px 0}
.dmd-directory-ui .pe-form-row{gap:10px}
.dmd-directory-ui .pe-form-row>div,.dmd-directory-ui .dmd-dir-field{min-width:0}
.dmd-directory-ui label{font-weight:700}
.dmd-directory-ui input[type="text"],.dmd-directory-ui input[type="email"],.dmd-directory-ui input[type="password"],.dmd-directory-ui input[type="number"],.dmd-directory-ui select,.dmd-directory-ui input[type="file"]{min-height:36px;padding:7px 9px}
.dmd-directory-ui input[readonly]{opacity:.82}
.dmd-directory-ui .dmd-dir-scope-note{margin:0;padding:9px 11px;border-radius:8px;background:color-mix(in srgb,var(--dmd-dir-input) 65%,transparent)}
.dmd-directory-ui .dmd-dir-actions{margin-top:2px;padding-top:9px;border-top:1px solid var(--dmd-dir-border)}
.dmd-directory-ui .dmd-dir-actions button{min-height:34px}
.dmd-directory-ui .dmd-dir-section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin:0}
.dmd-directory-ui .dmd-dir-section-head h3{margin:0;font-size:1rem}
.dmd-directory-ui .dmd-dir-section-head .pe-note{margin:3px 0 0}
.dmd-directory-ui .dmd-dir-import-toolbar{display:grid;grid-template-columns:minmax(220px,1.2fr) minmax(220px,1fr) auto;gap:9px;align-items:end}
.dmd-directory-ui .dmd-dir-import-toolbar .pe-actions{margin:0;align-self:end}
.dmd-directory-ui .dmd-dir-user-list{display:grid;gap:7px;margin-top:2px}
.dmd-directory-ui .dmd-dir-user-head,.dmd-directory-ui .dmd-dir-user-row{display:grid;grid-template-columns:44px minmax(210px,1.35fr) minmax(150px,.9fr) minmax(145px,.85fr) minmax(235px,1.25fr) 86px;gap:10px;align-items:center}
.dmd-directory-ui .dmd-dir-user-head{position:sticky;top:0;z-index:2;padding:8px 10px;font-size:.78em;font-weight:800;text-transform:uppercase;letter-spacing:.035em;color:var(--dmd-dir-muted);background:var(--dmd-dir-card);border-bottom:1px solid var(--dmd-dir-border)}
.dmd-directory-ui .dmd-dir-user-row{padding:9px 10px;border:1px solid var(--dmd-dir-border);border-radius:9px;background:color-mix(in srgb,var(--dmd-dir-input) 35%,transparent)}
.dmd-directory-ui .dmd-dir-user-row:hover{background:color-mix(in srgb,var(--dmd-dir-accent) 5%,var(--dmd-dir-input))}
.dmd-directory-ui .dmd-dir-user-row>div{min-width:0}
.dmd-directory-ui .dmd-dir-user-select{text-align:center}
.dmd-directory-ui .dmd-dir-user-select input{width:17px;height:17px}
.dmd-directory-ui .dmd-dir-user-name{font-weight:800;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dmd-directory-ui .dmd-dir-subline{display:block;margin-top:2px;font-size:.82em;color:var(--dmd-dir-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dmd-directory-ui .dmd-dir-email-ad{font-size:.88em;overflow-wrap:anywhere}
.dmd-directory-ui .dmd-dir-email-editor input[type="email"]{width:100%;min-width:0;margin:0}
.dmd-directory-ui .dmd-dir-merge{display:flex;align-items:center;gap:6px;margin-top:6px;font-size:.82em;font-weight:600;line-height:1.25;color:var(--dmd-dir-muted)}
.dmd-directory-ui .dmd-dir-merge input{flex:0 0 auto}
.dmd-directory-ui .dmd-dir-merge-note{margin-top:5px;font-size:.78em;line-height:1.3;color:var(--dmd-dir-muted)}
.dmd-directory-ui .dmd-dir-state{display:inline-flex;align-items:center;justify-content:center;min-height:25px;padding:3px 7px;border:1px solid var(--dmd-dir-border);border-radius:999px;font-size:.79em;font-weight:800;white-space:nowrap}
.dmd-directory-ui .dmd-dir-linked-list,.dmd-directory-ui .dmd-dir-role-list,.dmd-directory-ui .dmd-dir-group-list{display:grid;gap:7px}
.dmd-directory-ui .dmd-dir-linked-row{display:grid;grid-template-columns:minmax(190px,1.2fr) minmax(170px,1fr) 130px 90px 150px;gap:10px;align-items:center;padding:9px 10px;border:1px solid var(--dmd-dir-border);border-radius:9px;background:color-mix(in srgb,var(--dmd-dir-input) 32%,transparent)}
.dmd-directory-ui .dmd-dir-linked-row>div{min-width:0}
.dmd-directory-ui .dmd-dir-linked-label{font-size:.75em;text-transform:uppercase;letter-spacing:.03em;color:var(--dmd-dir-muted);display:none}
.dmd-directory-ui .dmd-dir-legacy-table{width:100%;table-layout:auto}
.dmd-directory-ui .dmd-dir-legacy-table th,.dmd-directory-ui .dmd-dir-legacy-table td{padding:8px 10px;vertical-align:middle}
.dmd-directory-ui .dmd-dir-legacy-table .dmd-security-status{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dmd-directory-ui .table-wrap{max-width:100%;overflow:auto;border-radius:9px}
#dmd-directory-help-modal .dmd-dir-help-dialog{width:min(980px,96vw)!important;border-radius:12px!important}
.dmd-directory-ui .dmd-dir-empty{padding:10px 12px;border:1px dashed var(--dmd-dir-border);border-radius:9px;color:var(--dmd-dir-muted)}
@media(max-width:1150px){
 .dmd-directory-ui .dmd-dir-status-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
 .dmd-directory-ui .dmd-dir-import-toolbar{grid-template-columns:1fr 1fr}.dmd-directory-ui .dmd-dir-import-toolbar .pe-actions{grid-column:1/-1}
 .dmd-directory-ui .dmd-dir-user-head{display:none}
 .dmd-directory-ui .dmd-dir-user-row{grid-template-columns:36px minmax(0,1.2fr) minmax(0,1fr) 92px;align-items:start}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-email-ad{grid-column:2/3}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-email-editor{grid-column:3/4;grid-row:1/3}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-state-cell{grid-column:4/5;grid-row:1/3;align-self:center}
 .dmd-directory-ui .dmd-dir-linked-row{grid-template-columns:1fr 1fr 110px;align-items:start}
 .dmd-directory-ui .dmd-dir-linked-row>div:nth-child(4),.dmd-directory-ui .dmd-dir-linked-row>div:nth-child(5){grid-column:auto}
}
@media(max-width:760px){
 .dmd-directory-ui{padding:10px!important}
 .dmd-directory-ui .dmd-dir-status-grid,.dmd-directory-ui .dmd-security-grid.dmd-dir-toggles,.dmd-directory-ui .dmd-dir-import-toolbar{grid-template-columns:1fr}
 .dmd-directory-ui .dmd-dir-user-row{grid-template-columns:32px 1fr 88px}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-ident{grid-column:2/3}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-email-ad{grid-column:2/4}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-email-editor{grid-column:2/4;grid-row:auto}
 .dmd-directory-ui .dmd-dir-user-row .dmd-dir-state-cell{grid-column:3/4;grid-row:1/2}
 .dmd-directory-ui .dmd-dir-linked-row{grid-template-columns:1fr}
 .dmd-directory-ui .dmd-dir-linked-label{display:block;margin-bottom:2px}
}
</style>

<div class="dmd-security-panel dmd-directory-ui">
    <?php if (!empty($dmdDirectoryErrors)): ?>
        <div class="pe-msg pe-msg-error" style="margin:0 0 10px 0;">
            <?php foreach ($dmdDirectoryErrors as $dmdDirectoryError): ?><?= htmlspecialchars((string)$dmdDirectoryError, ENT_QUOTES, 'UTF-8') ?><br><?php endforeach; ?>
        </div>
    <?php elseif (!empty($dmdDirectorySuccess) && $dmdDirectoryMessage !== ''): ?>
        <div class="pe-msg pe-msg-success" style="margin:0 0 10px 0;"><?= htmlspecialchars((string)$dmdDirectoryMessage, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <p class="pe-note dmd-dir-intro"><strong>Configuration Superadmin uniquement.</strong> DoMyDesk peut lire l’annuaire, importer uniquement les comptes sélectionnés et, si vous l’autorisez, gérer des groupes limités à l’OU DoMyDesk. Les mots de passe utilisateurs AD ne sont jamais stockés.</p>

    <div class="dmd-dir-status-grid">
        <div class="dmd-dir-status-card">
            <strong>Extension PHP LDAP</strong>
            <span class="dmd-security-status"><?= dmd_directory_ldap_available() ? '✅ Disponible' : '❌ Absente — php-ldap requis' ?></span>
        </div>
        <div class="dmd-dir-status-card">
            <strong>Annuaire</strong>
            <span class="dmd-security-status"><?= !empty($dmdDirectoryConfig['enabled']) ? '✅ Activé' : '⚪ Désactivé' ?></span>
        </div>
        <div class="dmd-dir-status-card">
            <strong>Authentification AD</strong>
            <span class="dmd-security-status"><?= !empty($dmdDirectoryConfig['authentication_enabled']) ? '✅ Activée' : '⚪ Désactivée' ?></span>
        </div>
        <div class="dmd-dir-status-card">
            <strong>Écritures AD</strong>
            <span class="dmd-security-status"><?= !empty($dmdDirectoryConfig['write_enabled']) ? '⚠️ Autorisées dans l’OU gérée' : '🔒 Lecture seule' ?></span>
        </div>
    </div>

    <div class="dmd-dir-titlebar">
        <h3>Connexion LDAP / Active Directory</h3>
        <button type="button" id="dmd-directory-help-open" class="dmd-dir-help-button" aria-label="Afficher la procédure complète Active Directory" title="Procédure complète Active Directory / LDAPS" >?</button>
    </div>
    <div class="pe-note dmd-dir-callout">
        <strong>⚠️ Certificat LDAPS obligatoire.</strong> Le contrôleur Active Directory doit posséder un certificat serveur valide pour son <strong>FQDN</strong> et écouter en <strong>LDAPS / 636</strong>. Le certificat public de l’autorité qui l’a signé doit ensuite être importé <strong>dans DoMyDesk</strong>. Cliquez sur <strong>?</strong> pour la procédure complète côté Active Directory.
    </div>
    <?php if (!empty($dmdDirectoryDetected['detected'])): ?>
        <p class="pe-note dmd-dir-detection">Domaine détecté sur l’hébergeur : <strong><?= htmlspecialchars((string)$dmdDirectoryDetected['domain'], ENT_QUOTES, 'UTF-8') ?></strong><?php if (!empty($dmdDirectoryDetected['host'])): ?> — contrôleur proposé : <strong><?= htmlspecialchars((string)$dmdDirectoryDetected['host'], ENT_QUOTES, 'UTF-8') ?></strong><?php endif; ?>.</p>
    <?php else: ?>
        <p class="pe-note dmd-dir-detection">Aucun domaine n’est détecté automatiquement. Saisissez le domaine DNS et le FQDN du contrôleur ; DoMyDesk peut fonctionner même si l’hébergeur n’est pas lui-même membre de l’Active Directory.</p>
    <?php endif; ?>

    <div id="dmd-directory-help-modal" aria-hidden="true" style="display:none;position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.62);align-items:center;justify-content:center;padding:18px;">
        <div role="dialog" aria-modal="true" aria-labelledby="dmd-directory-help-title" class="dmd-dir-help-dialog" style="max-height:90vh;overflow:auto;background:var(--panel-bg, var(--bg2, #101820));color:var(--text, inherit);border:1px solid var(--border, rgba(127,127,127,.45));border-radius:10px;box-shadow:0 18px 60px rgba(0,0,0,.45);">
            <div style="position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;background:inherit;border-bottom:1px solid var(--border, rgba(127,127,127,.35));">
                <div>
                    <strong id="dmd-directory-help-title" style="font-size:15px;">Procédure complète Active Directory / LDAPS</strong>
                    <div class="pe-note">À réaliser une seule fois pour chaque environnement Active Directory.</div>
                </div>
                <button type="button" id="dmd-directory-help-close" aria-label="Fermer la procédure">Fermer</button>
            </div>
            <div style="padding:14px;">
                <div class="pe-msg pe-msg-error" style="margin:0 0 12px 0;">
                    <strong>Prérequis obligatoire :</strong> DoMyDesk utilise uniquement <strong>LDAPS / 636</strong>. Le contrôleur doit donc posséder un certificat serveur LDAP valide. LDAP 389 non chiffré et le contournement de la vérification TLS ne sont pas utilisés.
                </div>

                <ol style="margin:0;padding-left:22px;display:grid;gap:12px;">
                    <li>
                        <strong>Vérifier le nom DNS du contrôleur.</strong><br>
                        Le contrôleur doit avoir un FQDN stable, par exemple <code><?= htmlspecialchars($dmdDirectoryExampleHost, ENT_QUOTES, 'UTF-8') ?></code>. Ce nom doit être résolu depuis l’hébergeur DoMyDesk et doit être présent dans le certificat LDAPS. Dans DoMyDesk, utilisez le <strong>FQDN</strong>, pas l’adresse IP.
                    </li>

                    <li>
                        <strong>Disposer d’une autorité de certification.</strong><br>
                        Si votre entreprise possède déjà une PKI/autorité de certification capable d’émettre un certificat serveur pour le contrôleur, utilisez-la et passez à l’étape suivante.<br>
                        <strong>Si aucune autorité n’existe</strong>, sur un serveur Windows prévu pour AD CS : <em>Gestionnaire de serveur → Ajouter des rôles et fonctionnalités → Services de certificats Active Directory → Autorité de certification</em>. Pour une petite infrastructure/laboratoire, vous pouvez créer une <strong>Autorité de certification d’entreprise → Racine → Nouvelle clé privée → RSA Microsoft Software Key Storage Provider → 4096 bits → SHA256</strong>, avec un nom générique tel que <code>ENTREPRISE-ROOT-CA</code>. Une PKI de production peut être hébergée sur un serveur dédié selon votre politique interne.
                    </li>

                    <li>
                        <strong>Émettre un certificat serveur pour le contrôleur de domaine.</strong><br>
                        Sur le contrôleur : <code>certlm.msc</code> → <em>Personnel → Certificats → Toutes les tâches → Demander un nouveau certificat</em> → stratégie d’inscription Active Directory → modèle <strong>Contrôleur de domaine</strong> / <strong>Domain Controller Authentication</strong> selon les modèles disponibles → <strong>Inscrire</strong>.<br>
                        Vérifiez ensuite que le certificat :
                        <ul style="margin:6px 0 0 18px;">
                            <li>contient le <strong>FQDN exact</strong> du contrôleur dans le sujet/SAN ;</li>
                            <li>autorise <strong>Authentification du serveur / Server Authentication</strong> ;</li>
                            <li>possède sa <strong>clé privée</strong> sur le contrôleur ;</li>
                            <li>est valide et chaîné vers votre autorité de certification.</li>
                        </ul>
                        Si LDAPS n’est pas pris en compte immédiatement après l’inscription, redémarrez le contrôleur ou le service AD DS selon votre procédure de maintenance.
                    </li>

                    <li>
                        <strong>Tester LDAPS sur le contrôleur avant DoMyDesk.</strong><br>
                        Ouvrez <code>ldp.exe</code> → <em>Connexion → Se connecter</em> → serveur <code><?= htmlspecialchars($dmdDirectoryExampleHost, ENT_QUOTES, 'UTF-8') ?></code> → port <code>636</code> → <strong>SSL coché</strong>. Le test est bon si la connexion s’établit et si le <strong>RootDSE</strong> est affiché. Si ce test échoue, corrigez d’abord le certificat/LDAPS côté Active Directory.
                    </li>

                    <li>
                        <strong>Exporter uniquement le certificat public de l’autorité.</strong><br>
                        Dans <code>certlm.msc</code>, ouvrez le certificat de votre autorité de certification → <em>Détails → Copier dans un fichier</em> → <strong>ne jamais exporter la clé privée</strong> → format <strong>X.509 Base-64 (.CER)</strong> (ou PEM/CRT). Ce fichier public sera importé dans DoMyDesk ; aucune installation dans le magasin de certificats du NAS/Linux/Windows hébergeur n’est nécessaire.
                    </li>

                    <li>
                        <strong>Créer le groupe de délégation DoMyDesk.</strong><br>
                        Dans Active Directory, créez <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code> en <strong>Groupe de sécurité / Global</strong>. Ce groupe reçoit les droits LDAP ; il ne doit pas être un groupe d’administration du domaine.
                    </li>

                    <li>
                        <strong>Créer le compte de service LDAP.</strong><br>
                        Créez <code>svc_domydesk</code> comme <strong>utilisateur standard du domaine</strong>, avec un mot de passe dédié. Décochez <strong>« L’utilisateur doit changer le mot de passe à la prochaine ouverture de session »</strong>, vérifiez que le compte est actif, puis ajoutez-le à <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code>.<br>
                        <strong>Ne l’ajoutez jamais</strong> à <code>Domain Admins</code>, <code>Enterprise Admins</code>, <code>Administrators</code>, <code>Account Operators</code> ou un groupe équivalent.
                    </li>

                    <li>
                        <strong>Déléguer uniquement la lecture des utilisateurs et groupes.</strong><br>
                        DoMyDesk scanne récursivement <strong>toute la Base DN</strong> configurée, donc les utilisateurs peuvent rester dans leurs OU actuelles. Sur la racine du domaine ou sur chaque OU que DoMyDesk doit parcourir : <em>Délégation de contrôle</em> → ajoutez <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code> → accordez uniquement les droits de <strong>lecture des informations Utilisateur</strong> et, pour les groupes, <strong>Lire toutes les propriétés</strong>. Aucun droit d’écriture sur les utilisateurs n’est nécessaire.
                    </li>

                    <li>
                        <strong>Créer l’OU gérée par DoMyDesk uniquement si vous voulez des écritures AD.</strong><br>
                        Créez manuellement par exemple <code><?= htmlspecialchars($dmdDirectoryExampleManagedOu, ENT_QUOTES, 'UTF-8') ?></code>. Si DoMyDesk doit créer/modifier ses propres groupes, déléguez à <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code> <strong>uniquement sur cette OU</strong> : créer/supprimer les objets Groupe, lire/écrire leurs propriétés et modifier l’appartenance aux groupes. Ne donnez aucun droit d’écriture sur les comptes Utilisateur. Si vous ne voulez que lire/importer l’AD, laissez les écritures DoMyDesk désactivées.
                    </li>

                    <li>
                        <strong>Configurer DoMyDesk.</strong><br>
                        Dans ce formulaire, renseignez :
                        <ul style="margin:6px 0 0 18px;">
                            <li><strong>Domaine</strong> : <code><?= htmlspecialchars($dmdDirectoryExampleDomain, ENT_QUOTES, 'UTF-8') ?></code> ;</li>
                            <li><strong>Contrôleur AD</strong> : son FQDN exact, par exemple <code><?= htmlspecialchars($dmdDirectoryExampleHost, ENT_QUOTES, 'UTF-8') ?></code> ;</li>
                            <li><strong>Base DN</strong> : par exemple <code><?= htmlspecialchars($dmdDirectoryDerivedBaseDn, ENT_QUOTES, 'UTF-8') ?></code> ;</li>
                            <li><strong>Compte de service</strong> : par exemple <code><?= htmlspecialchars($dmdDirectoryExampleBind, ENT_QUOTES, 'UTF-8') ?></code> ;</li>
                            <li><strong>Certificat CA</strong> : importez le <code>.cer/.crt/.pem</code> public exporté à l’étape 5 ;</li>
                            <li><strong>OU gérée</strong> : uniquement si vous activez les écritures de groupes.</li>
                        </ul>
                        Enregistrez la configuration, ressaisissez le mot de passe du compte de service puis lancez <strong>Tester la connexion</strong>.
                    </li>

                    <li>
                        <strong>Importer les utilisateurs.</strong><br>
                        Cliquez sur <strong>Charger les utilisateurs AD</strong>. DoMyDesk recherche les comptes dans <strong>toutes les OU et sous-OU sous la Base DN</strong>. Cochez uniquement les comptes à importer. Une adresse email DoMyDesk est obligatoire : si l’attribut <code>mail</code> est vide dans AD, saisissez l’adresse directement dans DoMyDesk avant l’import ; elle n’est pas réécrite dans l’AD.
                    </li>

                    <li>
                        <strong>Activer ensuite l’authentification AD.</strong><br>
                        Après un premier import réussi, activez <strong>« Autoriser la connexion avec le mot de passe AD »</strong>. Les utilisateurs AD utilisent alors leur mot de passe Active Directory via LDAPS ; DoMyDesk ne stocke pas leurs mots de passe utilisateurs.
                    </li>
                </ol>

                <div style="margin-top:14px;padding:10px;border:1px solid var(--border, rgba(127,127,127,.35));border-radius:8px;">
                    <strong>Diagnostic rapide</strong>
                    <ul style="margin:6px 0 0 18px;">
                        <li><strong>Port 636 inaccessible</strong> : vérifier le certificat serveur, l’écoute LDAPS et le pare-feu du contrôleur.</li>
                        <li><strong>Erreur de certificat TLS</strong> : vérifier que la CA publique est importée dans DoMyDesk et que le FQDN saisi correspond au certificat du contrôleur.</li>
                        <li><strong>Identifiants refusés</strong> : vérifier le compte de service, son mot de passe, son état et l’absence de changement de mot de passe obligatoire.</li>
                        <li><strong>0 utilisateur chargé</strong> : vérifier la Base DN et les droits de lecture ; DoMyDesk ne nécessite pas que les utilisateurs soient dans l’OU DoMyDesk.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <form method="post" class="pe-form dmd-dir-card dmd-dir-config-card" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
        <div class="dmd-security-grid dmd-dir-toggles">
            <div class="dmd-dir-toggle">
                <label><input type="checkbox" name="directory_enabled" value="1" <?= !empty($dmdDirectoryConfig['enabled']) ? 'checked' : '' ?>> Activer l’annuaire</label>
                <div class="pe-note">Active la connexion LDAP et permet de charger/importer les utilisateurs AD sélectionnés.</div>
            </div>
            <div class="dmd-dir-toggle">
                <label><input type="checkbox" id="dmd-directory-authentication-enabled" name="directory_authentication_enabled" value="1" <?= !empty($dmdDirectoryConfig['authentication_enabled']) ? 'checked' : '' ?>> Autoriser la connexion avec le mot de passe AD</label>
                <div class="pe-note">À activer après le premier import réussi. Les utilisateurs AD se connecteront avec leur identifiant/mot de passe Active Directory ; DoMyDesk ne stocke pas leur mot de passe AD. La connexion LDAP doit être protégée par TLS.</div>
            </div>
            <div class="dmd-dir-toggle">
                <label><input type="checkbox" name="directory_write_enabled" value="1" <?= !empty($dmdDirectoryConfig['write_enabled']) ? 'checked' : '' ?>> Autoriser les écritures uniquement dans l’OU gérée</label>
                <div class="pe-note">À cocher uniquement si vous avez délégué les droits d’écriture sur les <strong>groupes</strong> dans l’OU DoMyDesk décrite ci-dessus. Laissez décoché pour une utilisation lecture/import uniquement.</div>
            </div>
            <div class="dmd-dir-toggle">
                <strong>Vérification TLS</strong><br>
                <span class="dmd-security-status">🔒 Obligatoire</span>
                <div class="pe-note">La vérification du certificat ne peut pas être désactivée. Une autorité privée se charge directement dans DoMyDesk.</div>
            </div>
        </div>

        <div class="dmd-dir-ca">
            <div class="dmd-dir-ca-head"><strong>Certificat de l’autorité Active Directory</strong> <button type="button" class="dmd-directory-help-trigger" aria-label="Aide certificat Active Directory" title="Procédure certificat LDAPS">?</button></div>
            <?php if (!empty($dmdDirectoryCaInfo['installed'])): ?>
                <div class="pe-note" style="margin:4px 0 8px 0;">
                    ✅ CA installée dans DoMyDesk : <strong><?= htmlspecialchars((string)($dmdDirectoryCaInfo['subject_cn'] ?: 'Certificat importé'), ENT_QUOTES, 'UTF-8') ?></strong>
                    <?php if (!empty($dmdDirectoryCaInfo['valid_to'])): ?> — expire le <?= htmlspecialchars(date('d/m/Y', strtotime((string)$dmdDirectoryCaInfo['valid_to'])), ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                    <?php if (!empty($dmdDirectoryCaInfo['fingerprint_sha256'])): ?><br><code><?= htmlspecialchars((string)$dmdDirectoryCaInfo['fingerprint_sha256'], ENT_QUOTES, 'UTF-8') ?></code><?php endif; ?>
                </div>
            <?php else: ?>
                <div class="pe-note" style="margin:4px 0 8px 0;"><strong>⚠️ CA non importée.</strong> Sélectionnez le fichier public de votre autorité Active Directory puis cliquez sur <strong>Importer / remplacer la CA</strong>. Le bouton <strong>Tester la connexion</strong> peut aussi importer automatiquement le fichier sélectionné avant le test. DoMyDesk utilise ensuite <strong>LDAPS / 636</strong>.</div>
            <?php endif; ?>
            <input type="hidden" name="MAX_FILE_SIZE" value="1048576">
            <input type="file" name="directory_ca_certificate" accept=".cer,.crt,.pem,application/x-x509-ca-cert,application/pkix-cert">
            <div class="pe-note">Formats acceptés : <code>.cer</code>, <code>.crt</code>, <code>.pem</code>. DoMyDesk valide le certificat X.509 et le conserve dans son espace privé ; aucune installation sur le NAS/Linux/Windows hôte n’est nécessaire.</div>
            <div class="pe-actions">
                <button type="submit" name="import_directory_ca" value="1">Importer / remplacer la CA</button>
                <?php if (!empty($dmdDirectoryCaInfo['installed'])): ?><button type="submit" name="delete_directory_ca" value="1" class="btn-del" onclick="return confirm('Supprimer la CA Active Directory importée dans DoMyDesk ?')">Supprimer la CA</button><?php endif; ?>
            </div>
        </div>

        <div class="pe-form-row">
            <div>
                <label>Domaine</label>
                <input type="text" name="directory_domain" value="<?= htmlspecialchars((string)($dmdDirectoryConfig['domain'] ?: ($dmdDirectoryDetected['domain'] ?? '')), ENT_QUOTES, 'UTF-8') ?>" placeholder="entreprise.local">
                <div class="pe-note">Nom DNS du domaine Active Directory. Exemple générique : <code><?= htmlspecialchars($dmdDirectoryExampleDomain, ENT_QUOTES, 'UTF-8') ?></code>. Ce champ contient le <strong>domaine</strong>, pas le nom du contrôleur de domaine et pas un compte utilisateur.</div>
            </div>
            <div>
                <label>Contrôleur AD (FQDN recommandé)</label>
                <input type="text" name="directory_host" value="<?= htmlspecialchars((string)($dmdDirectoryConfig['host'] ?: ($dmdDirectoryDetected['host'] ?? '')), ENT_QUOTES, 'UTF-8') ?>" placeholder="dc01.entreprise.local">
                <div class="pe-note"><strong>FQDN du serveur Windows qui porte le rôle Contrôleur de domaine.</strong> Exemple générique : <code><?= htmlspecialchars($dmdDirectoryExampleHost, ENT_QUOTES, 'UTF-8') ?></code>. Utilisez le nom DNS présent dans le certificat LDAPS, pas l’adresse IP et pas le compte de service LDAP. Vous pouvez le laisser vide puis cliquer sur <strong>Détecter le contrôleur AD</strong>. Pour LDAPS, le FQDN doit correspondre au nom présent dans le certificat du contrôleur.</div>
            </div>
        </div>

        <div class="pe-form-row">
            <div>
                <label>Sécurité</label>
                <input type="text" value="LDAPS — obligatoire" readonly>
                <input type="hidden" name="directory_security" value="ldaps">
                <div class="pe-note">DoMyDesk utilise uniquement <strong>LDAPS</strong>. StartTLS/389 et LDAP non chiffré ne sont plus utilisés par l’intégration Active Directory.</div>
            </div>
            <div>
                <label>Port</label>
                <input type="number" name="directory_port" id="dmd-directory-port" value="636" readonly>
                <div class="pe-note"><code>636</code> fixe pour LDAPS.</div>
            </div>
            <div>
                <label>Timeout (s)</label>
                <input type="number" min="2" max="30" name="directory_timeout" value="<?= (int)($dmdDirectoryConfig['timeout'] ?? 8) ?>">
                <div class="pe-note">Temps maximal d’attente d’une connexion/requête LDAP. <code>8</code> secondes convient généralement sur le même réseau.</div>
            </div>
        </div>

        <div>
            <label>Base DN</label>
            <input type="text" name="directory_base_dn" value="<?= htmlspecialchars((string)($dmdDirectoryConfig['base_dn'] ?: ($dmdDirectoryDetected['base_dn'] ?? '')), ENT_QUOTES, 'UTF-8') ?>" placeholder="DC=entreprise,DC=local">
            <div class="pe-note">Racine LDAP du domaine. Exemple générique : pour <code><?= htmlspecialchars($dmdDirectoryExampleDomain, ENT_QUOTES, 'UTF-8') ?></code>, la Base DN est <code><?= htmlspecialchars($dmdDirectoryDerivedBaseDn, ENT_QUOTES, 'UTF-8') ?></code>. Cette valeur sert de point de départ aux recherches LDAP.</div>
        </div>

        <div class="pe-note dmd-dir-scope-note">
            <strong>Périmètre de lecture :</strong> DoMyDesk parcourt automatiquement <strong>toute la Base DN</strong> ci-dessus, y compris toutes les OU et sous-OU.
            Les utilisateurs et groupes n'ont pas à être déplacés dans une OU DoMyDesk. L'OU gérée ci-dessous sert <strong>uniquement aux écritures créées par DoMyDesk</strong>.
        </div>

        <div>
            <label>OU gérée par DoMyDesk</label>
            <input type="text" name="directory_managed_ou_dn" value="<?= htmlspecialchars((string)($dmdDirectoryConfig['managed_ou_dn'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="OU=DoMyDesk,DC=entreprise,DC=local">
            <div class="pe-note">OU <strong>dédiée aux écritures DoMyDesk</strong>, par exemple <code><?= htmlspecialchars($dmdDirectoryExampleManagedOu, ENT_QUOTES, 'UTF-8') ?></code>. Recommandé : créez cette OU manuellement dans AD puis déléguez uniquement les droits Groupe indiqués en haut du formulaire. DoMyDesk ne doit pas recevoir de droits d’écriture ailleurs.</div>
        </div>

        <div class="pe-form-row">
            <div>
                <label>Compte de service LDAP</label>
                <input type="text" name="directory_bind_user" value="<?= htmlspecialchars((string)($dmdDirectoryConfig['bind_user'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="svc_domydesk@entreprise.local">
                <div class="pe-note">Compte de service créé dans l'AD puis ajouté au groupe <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code>. Vous pouvez saisir son <strong>UPN</strong> (<code><?= htmlspecialchars($dmdDirectoryExampleBind, ENT_QUOTES, 'UTF-8') ?></code>), son login court (<code>svc_domydesk</code>) ou son DN complet. DoMyDesk essaie automatiquement les formes UPN, <code>DOMAINE\utilisateur</code> et, si possible, le DN dans l’OU utilisateurs. Le compte doit être <strong>activé</strong> et ne doit <strong>pas</strong> être configuré pour changer son mot de passe à la prochaine ouverture de session.</div>
            </div>
            <div>
                <label>Mot de passe du compte de service</label>
                <input type="password" name="directory_bind_password" value="" autocomplete="new-password" placeholder="<?= !empty($dmdDirectoryConfig['has_bind_password']) ? 'Déjà enregistré — laisser vide pour conserver' : 'Obligatoire lors de la première configuration' ?>">
                <div class="pe-note"><strong>Important :</strong> ce mot de passe est celui du compte Active Directory indiqué à gauche. Si vous changez ce mot de passe dans l’AD, vous devez le ressaisir ici puis cliquer sur <strong>Enregistrer la configuration AD</strong>. <strong>Pour « Tester la connexion », vous devez toujours ressaisir le mot de passe actuel :</strong> le test n’utilise plus le secret enregistré en arrière-plan. Le secret enregistré reste utilisé normalement par DoMyDesk après validation de la configuration.</div>
            </div>
        </div>

        <p class="pe-note"><strong>Ordre conseillé :</strong> 1) créer <code><?= htmlspecialchars($dmdDirectoryExampleDelegationGroup, ENT_QUOTES, 'UTF-8') ?></code> → 2) créer <code>svc_domydesk</code> et l'ajouter à ce groupe → 3) déléguer la lecture au groupe → 4) créer l'OU DoMyDesk → 5) remplir les champs → 6) Enregistrer → 7) Tester la connexion → 8) importer quelques utilisateurs → 9) activer l'authentification AD → 10) seulement ensuite, si nécessaire, déléguer/activer les écritures de groupes.</p>
        <p class="pe-note">Le secret du compte de service est chiffré dans <code>var/directory/config.json</code> avec une clé privée séparée dans <code>var/security/</code>.</p>
        <div class="pe-actions dmd-dir-actions">
            <button type="submit" name="save_directory_config" value="1">Enregistrer la configuration AD</button>
            <button type="submit" name="test_directory_connection" value="1">Tester la connexion</button>
            <button type="submit" name="detect_directory" value="1">Détecter le contrôleur AD (DNS)</button>
        </div>
    </form>

    <div class="dmd-dir-section-head"><div><h3>OU DoMyDesk</h3><p class="pe-note">Zone réservée aux écritures créées par DoMyDesk.</p></div></div>
    <form method="post" class="pe-form dmd-dir-card">
        <p class="pe-note"><strong>Recommandé :</strong> créez l’OU DoMyDesk manuellement dans Active Directory et saisissez son DN dans le formulaire ci-dessus. Le bouton ci-dessous peut aussi tenter de la créer, mais uniquement si vous avez volontairement délégué au compte de service le droit de créer une OU dans le conteneur parent. Ce droit supplémentaire n’est pas nécessaire au fonctionnement normal.</p>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
        <div><strong><?= htmlspecialchars((string)($dmdDirectoryConfig['managed_ou_dn'] ?: 'Aucune OU gérée configurée'), ENT_QUOTES, 'UTF-8') ?></strong></div>
        <div class="pe-actions"><button type="submit" name="create_directory_ou" value="1" <?= empty($dmdDirectoryConfig['write_enabled']) ? 'disabled' : '' ?>>Créer / vérifier cette OU dans l’AD</button></div>
    </form>

    <div class="dmd-dir-section-head"><div><h3>Importer des utilisateurs AD</h3><p class="pe-note">Sélection manuelle, scan récursif de toute la Base DN et fusion non destructive avec les comptes locaux.</p></div></div>
    <form method="post" class="pe-form dmd-dir-card dmd-dir-import-card">
        <p class="pe-note">La liste est recherchée récursivement dans toutes les OU. Une adresse email DoMyDesk est obligatoire. Si l’attribut <code>mail</code> est vide dans AD, le Superadmin la renseigne ici avant l’import ; cette adresse n’est pas écrite dans l’AD. <strong>Si l’adresse existe déjà localement, la fusion conserve le compte et ses données.</strong></p>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
        <div class="dmd-dir-import-toolbar">
            <div><label>Recherche</label><input type="text" name="directory_search" value="<?= htmlspecialchars($dmdDirectorySearch ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Nom, login, UPN ou email"></div>
            <div><label>Rôle métier à l’import</label><select name="directory_import_role" required><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>" <?= $m === dmd_default_registration_role() ? 'selected' : '' ?>><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></div>
            <div class="pe-actions"><button type="submit" name="load_directory_users" value="1">Charger les utilisateurs</button><button type="submit" name="sync_directory_users" value="1">Synchroniser importés</button></div>
        </div>

        <?php if (!empty($dmdDirectoryUsers)): ?>
            <div class="dmd-dir-user-list" aria-label="Utilisateurs Active Directory">
                <div class="dmd-dir-user-head" aria-hidden="true">
                    <div>Importer</div><div>Utilisateur AD</div><div>Identifiant</div><div>Email AD</div><div>Compte DoMyDesk</div><div>État</div>
                </div>
            <?php foreach ($dmdDirectoryUsers as $adUser):
                $key = sha1((string)$adUser['dn']);
                $already = dmd_directory_find_profile_by_guid((string)$adUser['object_guid']);
                $suggestedEmail = filter_var((string)$adUser['mail'], FILTER_VALIDATE_EMAIL) ? strtolower((string)$adUser['mail']) : '';
                $suggestedExistingProfile = [];
                $suggestedExistingLocal = false;
                $suggestedExistingOtherAd = false;
                if ($suggestedEmail !== '' && is_dir(DMD_DIRECTORY_ROOT . '/users/profiles/' . $suggestedEmail)) {
                    $suggestedExistingProfile = dmd_read_profile($suggestedEmail);
                    $suggestedExistingLocal = !dmd_directory_profile_is_ad($suggestedExistingProfile);
                    $suggestedExistingOtherAd = dmd_directory_profile_is_ad($suggestedExistingProfile)
                        && strtolower((string)($suggestedExistingProfile['ad']['object_guid'] ?? '')) !== strtolower((string)$adUser['object_guid']);
                }
                $adDisplayName = (string)($adUser['display_name'] ?: trim($adUser['given_name'] . ' ' . $adUser['surname']));
            ?>
                <div class="dmd-dir-user-row">
                    <div class="dmd-dir-user-select">
                        <input type="checkbox" aria-label="Importer <?= htmlspecialchars($adDisplayName, ENT_QUOTES, 'UTF-8') ?>" name="directory_selected[<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>]" value="1" <?= $already !== '' ? 'disabled' : '' ?>>
                    </div>
                    <div class="dmd-dir-ident">
                        <span class="dmd-dir-user-name" title="<?= htmlspecialchars($adDisplayName, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($adDisplayName, ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="dmd-dir-subline" title="<?= htmlspecialchars((string)$adUser['dn'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$adUser['dn'], ENT_QUOTES, 'UTF-8') ?></span>
                    </div>
                    <div>
                        <strong><?= htmlspecialchars((string)$adUser['sam_account_name'], ENT_QUOTES, 'UTF-8') ?></strong>
                        <span class="dmd-dir-subline" title="<?= htmlspecialchars((string)$adUser['user_principal_name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$adUser['user_principal_name'], ENT_QUOTES, 'UTF-8') ?></span>
                    </div>
                    <div class="dmd-dir-email-ad">
                        <?= $adUser['mail'] !== '' ? htmlspecialchars((string)$adUser['mail'], ENT_QUOTES, 'UTF-8') : '<span class="dmd-dir-state">⚠️ Non renseignée</span>' ?>
                    </div>
                    <div class="dmd-dir-email-editor">
                        <input type="hidden" name="directory_dn[<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>]" value="<?= htmlspecialchars((string)$adUser['dn'], ENT_QUOTES, 'UTF-8') ?>">
                        <?php if ($already !== ''): ?>
                            <span class="dmd-dir-state">✓ Déjà importé</span>
                            <span class="dmd-dir-subline" title="<?= htmlspecialchars($already, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($already, ENT_QUOTES, 'UTF-8') ?></span>
                        <?php else: ?>
                            <input type="email" name="directory_email[<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>]" value="<?= htmlspecialchars($suggestedEmail, ENT_QUOTES, 'UTF-8') ?>" placeholder="email@entreprise.fr">
                            <label class="dmd-dir-merge" title="Conserve les fichiers, modules, droits, MFA, préférences et historique du compte local.">
                                <input type="checkbox" name="directory_merge_existing[<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>]" value="1">
                                <span>Fusionner si compte existant</span>
                            </label>
                            <?php if ($suggestedExistingLocal): ?>
                                <div class="dmd-dir-merge-note">⚠️ Compte local détecté : la fusion conservera ses données et liera seulement l’identité AD.</div>
                            <?php elseif ($suggestedExistingOtherAd): ?>
                                <div class="dmd-dir-merge-note">⛔ Adresse déjà liée à une autre identité AD : fusion refusée.</div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="dmd-dir-state-cell"><span class="dmd-dir-state"><?= !empty($adUser['enabled']) ? '✅ Actif' : '⛔ Désactivé' ?></span></div>
                </div>
            <?php endforeach; ?>
            </div>
            <div class="pe-actions dmd-dir-actions"><button type="submit" name="import_directory_users" value="1">Importer / fusionner la sélection</button></div>
            <p class="pe-note"><strong>Fusion non destructive :</strong> aucun dossier utilisateur n’est supprimé ou recréé. Modules, droits, rôle, MFA, dashboard, préférences et historique existants sont conservés.</p>
        <?php endif; ?>
    </form>

    <?php if (!empty($dmdDirectoryImportedProfiles)): ?>
        <div class="dmd-dir-section-head"><div><h3>Comptes DoMyDesk liés à AD</h3><p class="pe-note">Comptes déjà associés à une identité Active Directory.</p></div></div>
        <div class="dmd-dir-linked-list">
        <?php foreach ($dmdDirectoryImportedProfiles as $importEmail => $importProfile): $ad = is_array($importProfile['ad'] ?? null) ? $importProfile['ad'] : []; ?>
            <div class="dmd-dir-linked-row">
                <div><span class="dmd-dir-linked-label">Compte DoMyDesk</span><strong><?= htmlspecialchars(trim((string)($importProfile['prenom'] ?? '') . ' ' . (string)($importProfile['nom'] ?? '')), ENT_QUOTES, 'UTF-8') ?></strong><span class="dmd-dir-subline"><?= htmlspecialchars($importEmail, ENT_QUOTES, 'UTF-8') ?></span></div>
                <div><span class="dmd-dir-linked-label">Identité AD</span><strong><?= htmlspecialchars((string)($ad['sam_account_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong><span class="dmd-dir-subline"><?= htmlspecialchars((string)($ad['user_principal_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span></div>
                <div><span class="dmd-dir-linked-label">Rôle</span><?= htmlspecialchars((string)($importProfile['role_metier'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
                <div><span class="dmd-dir-linked-label">État</span><span class="dmd-dir-state"><?= ($importProfile['account_status'] ?? 'active') === 'active' ? '✅ Actif' : '⛔ Suspendu' ?></span></div>
                <div><span class="dmd-dir-linked-label">Dernière synchro</span><?= htmlspecialchars((string)($ad['last_sync_at'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="dmd-dir-section-head"><div><h3>Groupes DoMyDesk ↔ Active Directory</h3><p class="pe-note">Liaison facultative des rôles DoMyDesk avec des groupes AD gérés dans l’OU dédiée.</p></div></div>
    <form method="post" class="pe-form dmd-dir-card">
        <p class="pe-note">DoMyDesk ne modifie que les groupes qu’il a créés/liés dans son OU gérée. Les comptes locaux restent dans DoMyDesk mais ne peuvent pas être ajoutés à l’AD.</p>
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
        <div class="pe-form-row">
            <div><label>Nom du groupe/rôle DoMyDesk</label><input type="text" name="directory_role_name" placeholder="Techniciens" required></div>
            <div><label>Nom du groupe AD</label><input type="text" name="directory_group_name" placeholder="GG-DMD-Techniciens" required></div>
            <div><label>Portée AD</label><select name="directory_group_scope"><option value="global">Global</option><option value="domain_local">Domain Local</option><option value="universal">Universal</option></select></div>
        </div>
        <div class="pe-actions"><button type="submit" name="create_directory_role_group" value="1" <?= empty($dmdDirectoryConfig['write_enabled']) ? 'disabled' : '' ?>>Créer dans DoMyDesk et Active Directory</button><button type="submit" name="load_directory_groups" value="1">Lister les groupes AD</button></div>
    </form>

    <?php if ($dmdDirectoryRoleMap): ?>
        <div class="table-wrap"><table class="roles-table dmd-dir-legacy-table"><thead><tr><th>Groupe DoMyDesk</th><th>Groupe AD géré</th><th>Actions</th></tr></thead><tbody>
        <?php foreach ($dmdDirectoryRoleMap as $role => $map): ?>
            <tr><td><strong><?= htmlspecialchars((string)$role, ENT_QUOTES, 'UTF-8') ?></strong></td><td><?= htmlspecialchars((string)($map['group_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?><br><span class="dmd-security-status"><?= htmlspecialchars((string)($map['group_dn'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span></td><td>
                <form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="directory_sync_role" value="<?= htmlspecialchars((string)$role, ENT_QUOTES, 'UTF-8') ?>"><button type="submit" name="sync_directory_role_group" value="1">Synchroniser membres</button></form>
                <form method="post" style="display:inline"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="directory_unlink_role" value="<?= htmlspecialchars((string)$role, ENT_QUOTES, 'UTF-8') ?>"><button type="submit" name="unlink_directory_role_group" value="1" class="btn-del" onclick="return confirm('Supprimer uniquement la liaison DoMyDesk ↔ AD ? Le groupe AD restera en place.')">Délier</button></form>
            </td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>

    <?php if (!empty($dmdDirectoryGroups)): ?>
        <h3>Groupes trouvés dans l’AD</h3>
        <div class="table-wrap"><table class="roles-table dmd-dir-legacy-table"><thead><tr><th>Groupe</th><th>DN</th><th>Membres</th></tr></thead><tbody><?php foreach ($dmdDirectoryGroups as $group): ?><tr><td><strong><?= htmlspecialchars((string)$group['cn'], ENT_QUOTES, 'UTF-8') ?></strong></td><td><?= htmlspecialchars((string)$group['dn'], ENT_QUOTES, 'UTF-8') ?></td><td><?= count($group['members'] ?? []) ?></td></tr><?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
</div>

<script>
(function () {
    const modal = document.getElementById('dmd-directory-help-modal');
    const openMain = document.getElementById('dmd-directory-help-open');
    const closeBtn = document.getElementById('dmd-directory-help-close');
    const extraTriggers = document.querySelectorAll('.dmd-directory-help-trigger');
    if (!modal) return;
    // Le panneau AD est lui-même dans une popup scrollable : déplacer l'aide au niveau du body évite tout clipping.
    if (modal.parentElement !== document.body) document.body.appendChild(modal);

    const openHelp = function () {
        modal.style.display = 'flex';
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        if (closeBtn) closeBtn.focus();
    };
    const closeHelp = function () {
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        if (openMain) openMain.focus();
    };

    if (openMain) openMain.addEventListener('click', openHelp);
    extraTriggers.forEach(function (button) { button.addEventListener('click', openHelp); });
    if (closeBtn) closeBtn.addEventListener('click', closeHelp);
    modal.addEventListener('click', function (event) { if (event.target === modal) closeHelp(); });
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') closeHelp();
    });
})();
</script>
