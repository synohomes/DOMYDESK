<?php
/**
 * Actions Superadmin de l'annuaire. Ce fichier est inclus par adm/site_settings.php.
 */
require_once $baseDir . '/core/directory/dmd_ad_sync.php';

$dmdDirectoryConfig = dmd_directory_config_read(false);
$dmdDirectoryDetected = dmd_directory_detect_local_domain((string)($dmdDirectoryConfig['domain'] ?? ''), (string)($dmdDirectoryConfig['host'] ?? ''));
$dmdDirectoryUsers = [];
$dmdDirectoryGroups = [];
$dmdDirectoryImportedProfiles = [];
$dmdDirectorySearch = trim((string)($_POST['directory_search'] ?? ''));
$dmdDirectoryErrors = [];
$dmdDirectorySuccess = false;
$dmdDirectoryMessage = '';

foreach (glob($baseDir . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dmdDirectoryProfileDir) {
    $dmdDirectoryProfileEmail = basename($dmdDirectoryProfileDir);
    $dmdDirectoryProfile = dmd_read_profile($dmdDirectoryProfileEmail);
    if (dmd_directory_profile_is_ad($dmdDirectoryProfile)) {
        $dmdDirectoryImportedProfiles[$dmdDirectoryProfileEmail] = $dmdDirectoryProfile;
    }
}
ksort($dmdDirectoryImportedProfiles, SORT_NATURAL | SORT_FLAG_CASE);

$dmdDirectoryActionNames = [
    'save_directory_config',
    'import_directory_ca',
    'delete_directory_ca',
    'test_directory_connection',
    'detect_directory',
    'load_directory_users',
    'import_directory_users',
    'sync_directory_users',
    'create_directory_ou',
    'load_directory_groups',
    'create_directory_role_group',
    'sync_directory_role_group',
    'unlink_directory_role_group',
];
$dmdDirectoryAction = '';
foreach ($dmdDirectoryActionNames as $dmdDirectoryActionName) {
    if (isset($_POST[$dmdDirectoryActionName])) {
        $dmdDirectoryAction = $dmdDirectoryActionName;
        break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $dmdDirectoryAction !== '') {
    $reopenPopup = 'popup-security-admin';
    if (!$isSuperadmin) {
        $dmdDirectoryErrors[] = 'Action Active Directory réservée au Superadmin.';
    } elseif (!hash_equals((string)($_SESSION['csrf_site_settings'] ?? ''), (string)($_POST['csrf_token'] ?? ''))) {
        $dmdDirectoryErrors[] = 'Action Active Directory refusée : formulaire expiré ou invalide.';
    } else {
        switch ($dmdDirectoryAction) {
            case 'import_directory_ca':
                $upload = $_FILES['directory_ca_certificate'] ?? null;
                if (!is_array($upload) || (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                    $code = is_array($upload) ? (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
                    $labels = [
                        UPLOAD_ERR_INI_SIZE => 'Le certificat dépasse la taille autorisée par PHP.',
                        UPLOAD_ERR_FORM_SIZE => 'Le certificat dépasse la taille autorisée par le formulaire.',
                        UPLOAD_ERR_PARTIAL => 'Le certificat n’a été envoyé que partiellement.',
                        UPLOAD_ERR_NO_FILE => 'Sélectionnez le certificat CA (.cer, .crt ou .pem).',
                    ];
                    $dmdDirectoryErrors[] = $labels[$code] ?? ('Échec de l’import du certificat CA (code ' . $code . ').');
                    break;
                }
                $import = dmd_directory_ca_import((string)($upload['tmp_name'] ?? ''), (string)($upload['name'] ?? ''));
                if (empty($import['ok'])) {
                    $dmdDirectoryErrors[] = (string)($import['error'] ?? 'Impossible d’importer le certificat CA.');
                    break;
                }
                // Une CA importée sert à la connexion LDAPS. Revenir automatiquement
                // au mode sûr 636 évite de rester bloqué sur une ancienne configuration
                // StartTLS/389 issue des diagnostics précédents.
                $rawCfg = dmd_directory_config_read_raw();
                $rawCfg['security'] = 'ldaps';
                $rawCfg['port'] = 636;
                $rawCfg['verify_certificate'] = true;
                $rawCfg['last_updated_at'] = date('c');
                $rawCfg['last_updated_by'] = $email;
                dmd_directory_json_write(dmd_directory_config_file(), $rawCfg);

                $dmdDirectoryConfig = dmd_directory_config_read(false);
                // Conserver à l'écran les valeurs actuellement saisies dans le même formulaire.
                foreach ([
                    'domain' => 'directory_domain',
                    'host' => 'directory_host',
                    'base_dn' => 'directory_base_dn',
                    'user_base_dn' => 'directory_user_base_dn',
                    'group_base_dn' => 'directory_group_base_dn',
                    'managed_ou_dn' => 'directory_managed_ou_dn',
                    'bind_user' => 'directory_bind_user',
                    'timeout' => 'directory_timeout',
                ] as $cfgKey => $postKey) {
                    if (isset($_POST[$postKey])) $dmdDirectoryConfig[$cfgKey] = trim((string)$_POST[$postKey]);
                }
                $dmdDirectoryConfig['security'] = 'ldaps';
                $dmdDirectoryConfig['port'] = 636;
                $dmdDirectorySuccess = true;
                $info = $import['info'] ?? [];
                $dmdDirectoryMessage = 'Certificat de l’autorité Active Directory importé. DoMyDesk est passé automatiquement en LDAPS / 636.';
                if (!empty($info['subject_cn'])) $dmdDirectoryMessage .= ' CA : ' . $info['subject_cn'] . '.';
                if (function_exists('dmd_system_log')) dmd_system_log('directory_ca_imported', 'Active Directory', 'warning', $dmdDirectoryMessage, ['actor' => $email, 'subject_cn' => (string)($info['subject_cn'] ?? ''), 'fingerprint_sha256' => (string)($info['fingerprint_sha256'] ?? '')]);
                break;

            case 'delete_directory_ca':
                if (!dmd_directory_ca_delete()) {
                    $dmdDirectoryErrors[] = 'Impossible de supprimer le certificat CA de DoMyDesk.';
                    break;
                }
                $dmdDirectorySuccess = true;
                $dmdDirectoryMessage = 'Certificat de l’autorité Active Directory supprimé de DoMyDesk.';
                if (function_exists('dmd_system_log')) dmd_system_log('directory_ca_deleted', 'Active Directory', 'warning', $dmdDirectoryMessage, ['actor' => $email]);
                break;

            case 'save_directory_config':
                // Active Directory est volontairement fixé à LDAPS/636.
                // Les anciennes valeurs StartTLS/389 ne sont plus acceptées.
                $postedSecurity = 'ldaps';
                $postedPort = 636;
                $postedAuthenticationEnabled = !empty($_POST['directory_authentication_enabled']);

                $save = dmd_directory_config_write([
                    'enabled' => !empty($_POST['directory_enabled']),
                    'authentication_enabled' => $postedAuthenticationEnabled,
                    'write_enabled' => !empty($_POST['directory_write_enabled']),
                    'host' => $_POST['directory_host'] ?? '',
                    'port' => $postedPort,
                    'security' => $postedSecurity,
                    'verify_certificate' => true,
                    'timeout' => $_POST['directory_timeout'] ?? 8,
                    'domain' => $_POST['directory_domain'] ?? '',
                    'base_dn' => $_POST['directory_base_dn'] ?? '',
                    'user_base_dn' => $_POST['directory_user_base_dn'] ?? '',
                    'group_base_dn' => $_POST['directory_group_base_dn'] ?? '',
                    'managed_ou_dn' => $_POST['directory_managed_ou_dn'] ?? '',
                    'bind_user' => $_POST['directory_bind_user'] ?? '',
                    'bind_password' => $_POST['directory_bind_password'] ?? '',
                ], $email);
                if (!empty($save['ok'])) {
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = 'Configuration Active Directory enregistrée en LDAPS / 636.';
                    $dmdDirectoryConfig = dmd_directory_config_read(false);
                    if (function_exists('dmd_system_log')) dmd_system_log('directory_config_updated', 'Active Directory', 'warning', $dmdDirectoryMessage, ['actor' => $email, 'host' => $dmdDirectoryConfig['host'] ?? '', 'domain' => $dmdDirectoryConfig['domain'] ?? '', 'write_enabled' => !empty($dmdDirectoryConfig['write_enabled'])]);
                } else {
                    $dmdDirectoryErrors[] = (string)($save['error'] ?? 'Impossible d’enregistrer la configuration Active Directory.');
                }
                break;

            case 'test_directory_connection':
                // Le test porte sur les valeurs actuellement affichées dans le formulaire,
                // sans obliger le Superadmin à enregistrer une mauvaise configuration avant de la tester.
                // Si le Superadmin a sélectionné une CA dans le formulaire puis clique
                // directement sur « Tester », on l'importe avant le test.
                $testUpload = $_FILES['directory_ca_certificate'] ?? null;
                if (is_array($testUpload) && (int)($testUpload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
                    $testImport = dmd_directory_ca_import((string)($testUpload['tmp_name'] ?? ''), (string)($testUpload['name'] ?? ''));
                    if (empty($testImport['ok'])) {
                        $dmdDirectoryErrors[] = (string)($testImport['error'] ?? 'Impossible d’importer le certificat CA sélectionné.');
                        break;
                    }
                }
                if (!dmd_directory_ca_exists()) {
                    $dmdDirectoryErrors[] = 'Importez d’abord le certificat public de l’autorité Active Directory (.cer/.crt/.pem). Le test DoMyDesk utilise uniquement LDAPS/636.';
                    break;
                }

                $testCfg = dmd_directory_config_read(true);
                $testCfg['domain'] = strtolower(trim((string)($_POST['directory_domain'] ?? $testCfg['domain'] ?? ''), " .\t\r\n"));
                $testCfg['host'] = rtrim(trim((string)($_POST['directory_host'] ?? $testCfg['host'] ?? '')), '.');
                $testCfg['security'] = 'ldaps';
                $testCfg['port'] = 636;
                $testCfg['verify_certificate'] = true;
                $testCfg['timeout'] = max(2, min(30, (int)($_POST['directory_timeout'] ?? $testCfg['timeout'] ?? 8)));
                $testCfg['base_dn'] = trim((string)($_POST['directory_base_dn'] ?? $testCfg['base_dn'] ?? ''));
                if ($testCfg['base_dn'] === '' && $testCfg['domain'] !== '') $testCfg['base_dn'] = dmd_directory_domain_to_base_dn($testCfg['domain']);
                $testCfg['user_base_dn'] = $testCfg['base_dn'];
                $testCfg['group_base_dn'] = $testCfg['base_dn'];
                $testCfg['managed_ou_dn'] = trim((string)($_POST['directory_managed_ou_dn'] ?? $testCfg['managed_ou_dn'] ?? ''));
                $postedBindUser = trim((string)($_POST['directory_bind_user'] ?? $testCfg['bind_user'] ?? ''));
                $testCfg['bind_user'] = $postedBindUser;
                $postedPassword = (string)($_POST['directory_bind_password'] ?? '');

                // Un test doit toujours utiliser explicitement le secret saisi maintenant.
                // On n'utilise jamais le secret stocké en arrière-plan : cela rendrait le
                // résultat ambigu après un changement de compte ou de mot de passe AD.
                if ($postedBindUser === '') {
                    $dmdDirectoryErrors[] = 'Saisissez le compte de service LDAP à tester.';
                    break;
                }
                if ($postedPassword === '') {
                    $dmdDirectoryErrors[] = 'Pour tester la connexion Active Directory, saisissez le mot de passe actuel du compte de service dans le champ « Mot de passe du compte de service ». Le test n’utilise plus le secret enregistré en arrière-plan.';
                    break;
                }
                $testCfg['bind_password'] = $postedPassword;
                $credentialSource = 'saisi';

                if ($testCfg['host'] === '' && $testCfg['domain'] !== '') {
                    $controllers = dmd_directory_discover_domain_controllers($testCfg['domain']);
                    if (!empty($controllers[0])) $testCfg['host'] = $controllers[0];
                }

                $test = dmd_directory_test_connection($testCfg);
                if (!empty($test['ok'])) {
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = (string)($test['message'] ?? 'Connexion Active Directory validée.');
                    $dmdDirectoryMessage .= ' Test effectué avec le mot de passe saisi dans ce formulaire. S’il a changé dans l’AD, cliquez ensuite sur « Enregistrer la configuration AD » pour le conserver dans DoMyDesk.';
                    // Garde à l'écran les valeurs réellement testées, sans les enregistrer automatiquement.
                    $dmdDirectoryConfig = array_replace($dmdDirectoryConfig, $testCfg);
                    $dmdDirectoryConfig['bind_password'] = '';
                    $dmdDirectoryConfig['has_bind_password'] = !empty(dmd_directory_config_read(false)['has_bind_password']) || $postedPassword !== '';
                } else {
                    $sourceLabel = $credentialSource === 'saisi'
                        ? 'Le test a utilisé le mot de passe saisi dans le formulaire.'
                        : 'Le test a utilisé le mot de passe déjà enregistré dans DoMyDesk.';
                    $dmdDirectoryErrors[] = (string)($test['error'] ?? 'Test Active Directory en échec.') . ' ' . $sourceLabel;
                    $dmdDirectoryConfig = array_replace($dmdDirectoryConfig, $testCfg);
                    $dmdDirectoryConfig['bind_password'] = '';
                    $dmdDirectoryConfig['has_bind_password'] = !empty(dmd_directory_config_read(false)['has_bind_password']) || $postedPassword !== '';
                }
                break;

            case 'detect_directory':
                $domainHint = strtolower(trim((string)($_POST['directory_domain'] ?? $dmdDirectoryConfig['domain'] ?? ''), " .\t\r\n"));
                $hostHint = rtrim(trim((string)($_POST['directory_host'] ?? $dmdDirectoryConfig['host'] ?? '')), '.');
                $dmdDirectoryDetected = dmd_directory_detect_local_domain($domainHint, $hostHint);
                if (!empty($dmdDirectoryDetected['domain']) && !empty($dmdDirectoryDetected['host'])) {
                    $dmdDirectorySuccess = true;
                    $source = (string)($dmdDirectoryDetected['source'] ?? '');
                    $dmdDirectoryMessage = $source === 'configured_host'
                        ? 'Contrôleur Active Directory validé par DNS : ' . $dmdDirectoryDetected['host'] . '.'
                        : 'Contrôleur Active Directory trouvé via les enregistrements DNS SRV : ' . $dmdDirectoryDetected['host'] . '.';
                    $dmdDirectoryConfig['domain'] = (string)$dmdDirectoryDetected['domain'];
                    $dmdDirectoryConfig['host'] = (string)$dmdDirectoryDetected['host'];
                    if (empty($dmdDirectoryConfig['base_dn'])) $dmdDirectoryConfig['base_dn'] = (string)($dmdDirectoryDetected['base_dn'] ?? '');
                    $dmdDirectoryConfig['security'] = 'ldaps';
                    $dmdDirectoryConfig['port'] = 636;
                } elseif (!empty($dmdDirectoryDetected['domain'])) {
                    $dmdDirectoryErrors[] = 'Le domaine « ' . $dmdDirectoryDetected['domain'] . ' » est bien pris en compte, mais DoMyDesk ne voit aucun contrôleur via DNS SRV. Saisissez le FQDN du contrôleur dans le champ « Contrôleur AD » puis relancez la détection.';
                    $dmdDirectoryConfig['domain'] = (string)$dmdDirectoryDetected['domain'];
                } else {
                    $dmdDirectoryErrors[] = 'Saisissez le domaine DNS Active Directory dans le champ « Domaine », puis relancez la détection.';
                }
                break;

            case 'load_directory_users':
                $list = dmd_directory_list_users($dmdDirectorySearch);
                if (!empty($list['ok'])) {
                    $dmdDirectoryUsers = $list['users'] ?? [];
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = count($dmdDirectoryUsers) . ' utilisateur(s) Active Directory chargé(s).';
                } else {
                    $dmdDirectoryErrors[] = (string)($list['error'] ?? 'Impossible de charger les utilisateurs Active Directory.');
                }
                break;

            case 'import_directory_users':
                $selected = is_array($_POST['directory_selected'] ?? null) ? $_POST['directory_selected'] : [];
                $dns = is_array($_POST['directory_dn'] ?? null) ? $_POST['directory_dn'] : [];
                $emails = is_array($_POST['directory_email'] ?? null) ? $_POST['directory_email'] : [];
                $mergeExisting = is_array($_POST['directory_merge_existing'] ?? null) ? $_POST['directory_merge_existing'] : [];
                $role = trim((string)($_POST['directory_import_role'] ?? ''));
                $cfg = dmd_directory_config_read(false);
                $allowedBase = trim((string)($cfg['base_dn'] ?? ''));
                $imported = 0;
                $merged = 0;
                foreach ($selected as $key => $flag) {
                    if (!$flag) continue;
                    $dn = trim((string)($dns[$key] ?? ''));
                    $targetEmail = strtolower(trim((string)($emails[$key] ?? '')));
                    if ($dn === '' || $allowedBase === '' || !dmd_directory_dn_is_within($dn, $allowedBase)) {
                        $dmdDirectoryErrors[] = 'Import refusé : utilisateur hors du périmètre LDAP configuré.';
                        continue;
                    }
                    if (!filter_var($targetEmail, FILTER_VALIDATE_EMAIL)) {
                        $dmdDirectoryErrors[] = 'Import refusé pour ' . $dn . ' : indiquez une adresse email DoMyDesk valide.';
                        continue;
                    }
                    $read = dmd_directory_read_ad_user($dn);
                    if (empty($read['ok'])) {
                        $dmdDirectoryErrors[] = (string)($read['error'] ?? ('Impossible de relire ' . $dn));
                        continue;
                    }
                    $allowMerge = !empty($mergeExisting[$key]);
                    $imp = dmd_directory_import_user($read['user'], $targetEmail, $role, $email, $allowMerge);
                    if (!empty($imp['ok'])) {
                        if (!empty($imp['merged'])) $merged++;
                        else $imported++;
                    } else {
                        $dmdDirectoryErrors[] = $targetEmail . ' : ' . (string)($imp['error'] ?? 'import impossible');
                    }
                }
                if (($imported + $merged) > 0) {
                    $dmdDirectorySuccess = true;
                    $parts = [];
                    if ($imported > 0) $parts[] = $imported . ' nouveau(x) compte(s) importé(s)';
                    if ($merged > 0) $parts[] = $merged . ' compte(s) DoMyDesk existant(s) fusionné(s) avec Active Directory';
                    $dmdDirectoryMessage = implode(' ; ', $parts) . '. Aucune donnée utilisateur existante n’a été supprimée.';
                } elseif (!$dmdDirectoryErrors) {
                    $dmdDirectoryErrors[] = 'Sélectionnez au moins un utilisateur à importer.';
                }
                // Recharge la liste après import pour garder l'écran utilisable.
                $list = dmd_directory_list_users($dmdDirectorySearch);
                if (!empty($list['ok'])) $dmdDirectoryUsers = $list['users'] ?? [];
                break;

            case 'sync_directory_users':
                $sync = dmd_directory_sync_all_imported_users();
                $dmdDirectorySuccess = true;
                $dmdDirectoryMessage = 'Synchronisation AD : ' . (int)$sync['updated'] . ' compte(s) mis à jour, ' . (int)$sync['suspended'] . ' suspendu(s), ' . (int)$sync['failed'] . ' échec(s).';
                foreach (($sync['errors'] ?? []) as $syncError) $dmdDirectoryErrors[] = $syncError;
                break;

            case 'create_directory_ou':
                $cfg = dmd_directory_config_read(false);
                $ouDn = trim((string)($cfg['managed_ou_dn'] ?? ''));
                if ($ouDn === '') {
                    $dmdDirectoryErrors[] = 'Renseignez puis enregistrez d’abord le DN de l’OU gérée.';
                } else {
                    $create = dmd_directory_create_ou($ouDn);
                    if (!empty($create['ok'])) {
                        $dmdDirectorySuccess = true;
                        $dmdDirectoryMessage = (string)($create['message'] ?? 'OU DoMyDesk créée.');
                        if (function_exists('dmd_system_log')) dmd_system_log('directory_ou_created', $ouDn, 'warning', $dmdDirectoryMessage, ['actor' => $email]);
                    } else $dmdDirectoryErrors[] = (string)($create['error'] ?? 'Création de l’OU impossible.');
                }
                break;

            case 'load_directory_groups':
                $list = dmd_directory_list_groups();
                if (!empty($list['ok'])) {
                    $dmdDirectoryGroups = $list['groups'] ?? [];
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = count($dmdDirectoryGroups) . ' groupe(s) Active Directory chargé(s).';
                } else $dmdDirectoryErrors[] = (string)($list['error'] ?? 'Impossible de charger les groupes AD.');
                break;

            case 'create_directory_role_group':
                $role = trim((string)($_POST['directory_role_name'] ?? ''));
                $groupName = trim((string)($_POST['directory_group_name'] ?? ''));
                $scope = trim((string)($_POST['directory_group_scope'] ?? 'global'));
                if ($role === '' || $groupName === '') {
                    $dmdDirectoryErrors[] = 'Nom du groupe DoMyDesk et nom du groupe AD obligatoires.';
                    break;
                }
                $create = dmd_directory_create_group($groupName, $scope);
                if (empty($create['ok'])) {
                    $dmdDirectoryErrors[] = (string)($create['error'] ?? 'Création groupe AD impossible.');
                    break;
                }
                if (!in_array($role, $metiers, true)) {
                    $newRoles = $metiers;
                    $newRoles[] = $role;
                    $newRoles = array_values(array_unique(array_filter(array_map('trim', $newRoles))));
                    sort($newRoles, SORT_NATURAL | SORT_FLAG_CASE);
                    if (!dmd_json_write($rolesFile, $newRoles)) {
                        $dmdDirectoryErrors[] = 'Le groupe AD a été créé mais le rôle métier DoMyDesk n’a pas pu être enregistré.';
                        break;
                    }
                    $metiers = dmd_roles_catalog();
                }
                if (!dmd_directory_set_role_group_map($role, (string)$create['dn'], (string)$create['name'], $email)) {
                    $dmdDirectoryErrors[] = 'Groupe créé mais liaison DoMyDesk ↔ AD non enregistrée.';
                    break;
                }
                $dmdDirectorySuccess = true;
                $dmdDirectoryMessage = 'Groupe DoMyDesk « ' . $role . ' » créé/lié au groupe AD « ' . $groupName . ' ».';
                $dmdDirectoryConfig = dmd_directory_config_read(false);
                if (function_exists('dmd_system_log')) dmd_system_log('directory_group_created', $groupName, 'warning', $dmdDirectoryMessage, ['actor' => $email, 'role_metier' => $role, 'group_dn' => $create['dn']]);
                break;

            case 'sync_directory_role_group':
                $role = trim((string)($_POST['directory_sync_role'] ?? ''));
                $sync = dmd_directory_sync_role_to_ad($role);
                if (!empty($sync['ok'])) {
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = 'Groupe « ' . $role . ' » synchronisé vers AD : ' . (int)($sync['count'] ?? 0) . ' membre(s) AD.';
                    $skipped = $sync['skipped_local_accounts'] ?? [];
                    if ($skipped) $dmdDirectoryMessage .= ' ' . count($skipped) . ' compte(s) local(aux) DoMyDesk ignoré(s), car sans identité AD.';
                } else $dmdDirectoryErrors[] = (string)($sync['error'] ?? 'Synchronisation du groupe impossible.');
                break;

            case 'unlink_directory_role_group':
                $role = trim((string)($_POST['directory_unlink_role'] ?? ''));
                if ($role === '') $dmdDirectoryErrors[] = 'Groupe DoMyDesk invalide.';
                elseif (dmd_directory_remove_role_group_map($role, $email)) {
                    $dmdDirectorySuccess = true;
                    $dmdDirectoryMessage = 'Liaison DoMyDesk ↔ AD supprimée. Le groupe AD n’a pas été supprimé.';
                    $dmdDirectoryConfig = dmd_directory_config_read(false);
                } else $dmdDirectoryErrors[] = 'Impossible de supprimer la liaison du groupe.';
                break;
        }
    }
}

// Rafraîchit la liste des comptes AD importés après les actions.
$dmdDirectoryImportedProfiles = [];
foreach (glob($baseDir . '/users/profiles/*', GLOB_ONLYDIR) ?: [] as $dmdDirectoryProfileDir) {
    $dmdDirectoryProfileEmail = basename($dmdDirectoryProfileDir);
    $dmdDirectoryProfile = dmd_read_profile($dmdDirectoryProfileEmail);
    if (dmd_directory_profile_is_ad($dmdDirectoryProfile)) $dmdDirectoryImportedProfiles[$dmdDirectoryProfileEmail] = $dmdDirectoryProfile;
}
ksort($dmdDirectoryImportedProfiles, SORT_NATURAL | SORT_FLAG_CASE);
