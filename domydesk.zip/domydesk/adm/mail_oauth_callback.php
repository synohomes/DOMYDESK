<?php
session_start();
$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';

$email = trim((string)($_SESSION['user']['email'] ?? ''));
if ($email === '') { header('Location: ../login.php'); exit; }
$profile = dmd_read_profile($email);
$role = strtolower(trim((string)($profile['role_system'] ?? 'user')));
if (!in_array($role, array('admin','superadmin'), true)) { header('Location: ../dashboard.php'); exit; }

$provider = strtolower(trim((string)($_GET['provider'] ?? '')));
$state = trim((string)($_GET['state'] ?? ''));
if ($provider === '' && function_exists('dmd_mail_oauth_provider_for_state')) $provider = dmd_mail_oauth_provider_for_state($state);
$code = trim((string)($_GET['code'] ?? ''));
$providerError = trim((string)($_GET['error'] ?? ''));
$providerErrorDescription = trim((string)($_GET['error_description'] ?? ''));

if ($providerError !== '') {
    $msg = 'Connexion OAuth refusée : ' . $providerError;
    if ($providerErrorDescription !== '') $msg .= ' — ' . $providerErrorDescription;
    $_SESSION['dmd_mail_oauth_flash'] = array('type'=>'error','message'=>$msg);
} else {
    $error = '';
    $ok = function_exists('dmd_mail_oauth_complete') && dmd_mail_oauth_complete($provider, $state, $code, $error);
    if ($ok) {
        $label = $provider === 'google' ? 'Google Gmail' : 'Microsoft';
        $_SESSION['dmd_mail_oauth_flash'] = array('type'=>'success','message'=>$label . ' connecté directement à ce DoMyDesk.');
        if (function_exists('dmd_system_log')) dmd_system_log('mail_oauth_connected', $provider, 'success', $label . ' connecté localement à DoMyDesk Mail.');
    } else {
        $_SESSION['dmd_mail_oauth_flash'] = array('type'=>'error','message'=>$error !== '' ? $error : 'Échec de la connexion OAuth.');
        if (function_exists('dmd_system_log')) dmd_system_log('mail_oauth_connect_failed', $provider, 'error', $error);
    }
}
?>
<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>DoMyDesk Mail</title></head><body>
<script>
(function(){
  try {
    if (window.opener && !window.opener.closed) {
      window.opener.location.href = 'notifications.php';
      window.close();
      return;
    }
  } catch (e) {}
  window.location.href = 'notifications.php';
})();
</script>
<noscript><a href="notifications.php">Retour aux notifications</a></noscript>
</body></html>
