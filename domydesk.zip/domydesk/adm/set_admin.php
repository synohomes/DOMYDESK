<?php
session_start();
require_once dirname(__DIR__) . '/core/dmd_permissions.php';

$email = $_SESSION['user']['email'] ?? '';

if ($email === '') {
    http_response_code(403);
    exit('Accès refusé.');
}

$profile = dmd_read_profile($email);

/*
 * Ancien outil 1.1.x conservé uniquement pour compatibilité.
 * Il ne peut plus servir à promouvoir un simple utilisateur.
 */
if (!dmd_is_system_admin_profile($profile)) {
    http_response_code(403);
    exit('Accès refusé : la promotion administrateur se gère depuis l’administration DoMyDesk.');
}

$profile['role_system'] = 'admin';

if (!dmd_write_profile($email, $profile)) {
    http_response_code(500);
    exit('Impossible de sauvegarder le profil.');
}

$_SESSION['user']['role_system'] = 'admin';
$_SESSION['role_system'] = 'admin';

echo "✅ Rôle administrateur confirmé pour <strong>" . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . "</strong>.<br>";
echo "<a href='site_settings.php'>➡️ Retour à l’administration</a>";
?>
