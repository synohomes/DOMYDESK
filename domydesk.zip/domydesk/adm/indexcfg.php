<?php
session_start();
require_once dirname(__DIR__) . '/core/dmd_permissions.php';
require_once dirname(__DIR__) . '/core/dmd_system_services.php';

/* ==========================================================
   adm/indexcfg.php
   Administration de la page d'accueil DoMyDesk
   Modifie : data/indexcfg.json
   Historise : data/indexcfg/history/[date_email]/
   ========================================================== */

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE && is_array($data)) ? $data : $fallback;
}

function json_write(string $file, array $data): bool {
    $dir = dirname($file);

    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    return file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    ) !== false;
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function clean_array_text(array $items, array $fields): array {
    $clean = [];

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $row = [];
        $hasContent = false;

        foreach ($fields as $field) {
            $value = trim((string)($item[$field] ?? ''));
            $row[$field] = $value;

            if ($value !== '') {
                $hasContent = true;
            }
        }

        if ($hasContent) {
            $clean[] = $row;
        }
    }

    return $clean;
}

function folder_safe_email(string $email): string {
    return preg_replace('/[^a-zA-Z0-9@._-]/', '_', $email);
}

/* ==========================================================
   Sécurité admin
   ========================================================== */

if (empty($_SESSION['user']['email'])) {
    header('Location: ../login.php');
    exit;
}

$currentEmail = $_SESSION['user']['email'];
$currentProfile = dmd_read_profile($currentEmail);
$currentRole = $currentProfile['role_system'] ?? 'user';

if (!dmd_is_system_admin_profile($currentProfile)) {
    header('Location: ../profile_edit.php');
    exit;
}

/* ==========================================================
   Thème utilisateur
   ========================================================== */

$theme = 'default2';
$userDir = __DIR__ . '/../users/profiles/' . $currentEmail;
$themeJson = $userDir . '/theme.json';

if (is_file($themeJson)) {
    $themeData = json_read($themeJson, []);

    if (
        !empty($themeData['theme']) &&
        is_file(__DIR__ . '/../theme/' . basename($themeData['theme']) . '/style.css')
    ) {
        $theme = basename($themeData['theme']);
    }
} else {
    $profileFile = dmd_profile_path($currentEmail, true);

    if (is_file($profileFile)) {
        $profileData = json_read($profileFile, []);

        if (
            !empty($profileData['theme']) &&
            is_file(__DIR__ . '/../theme/' . basename($profileData['theme']) . '/style.css')
        ) {
            $theme = basename($profileData['theme']);
        }
    }
}

/* ==========================================================
   Fichiers
   ========================================================== */

$configFile = __DIR__ . '/../data/indexcfg.json';
$historyRoot = __DIR__ . '/../data/indexcfg/history';

$defaultConfig = [
    'hero' => [
        'eyebrow' => 'Bureau web modulaire',
        'title' => 'Pilote ton univers numérique',
        'title_span' => 'depuis un seul endroit.',
        'lead' => 'DoMyDesk rassemble tes modules, tes outils, tes services et tes informations dans une interface claire, rapide et personnalisable selon ton thème.',
        'buttons' => [
            [
                'label' => 'Se connecter',
                'url' => 'login.php',
                'class' => 'primary'
            ],
            [
                'label' => 'Créer un compte',
                'url' => 'register.php',
                'class' => ''
            ],
            [
                'label' => 'Voir les vidéos',
                'url' => 'https://www.youtube.com/watch?v=E3nn6WN2faM&list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM',
                'class' => ''
            ]
        ]
    ],
    'visual' => [
        'enabled' => true,
        'windows' => [
            [
                'lines' => ['big', 'mid', 'small']
            ],
            [
                'lines' => ['big', '', 'mid']
            ],
            [
                'lines' => ['big', 'small']
            ]
        ]
    ],
    'stats' => [
        [
            'value' => '100%',
            'text' => 'Interface web depuis navigateur.'
        ],
        [
            'value' => '0 DB',
            'text' => 'Logique simple par fichiers.'
        ],
        [
            'value' => 'Modules',
            'text' => 'Activation selon les besoins.'
        ],
        [
            'value' => 'Thèmes',
            'text' => 'Style utilisateur respecté.'
        ]
    ],
    'features_panel' => [
        'kicker' => 'Centre de contrôle',
        'title' => 'Tout est pensé pour aller vite.',
        'description' => 'Une page d’accueil propre, utile et cohérente avec DoMyDesk.',
        'features' => [
            [
                'icon' => '▦',
                'title' => 'Modules à la carte',
                'text' => 'Active uniquement ce dont tu as besoin et garde un bureau propre.'
            ],
            [
                'icon' => '◈',
                'title' => 'Thème respecté',
                'text' => 'La page utilise les variables du thème, sans imposer une couleur fixe.'
            ],
            [
                'icon' => '⚙',
                'title' => 'Accès rapide',
                'text' => 'Bureau, modules et paramètres restent accessibles dès l’accueil.'
            ]
        ]
    ],
    'news_panel' => [
        'kicker' => 'Actualités',
        'title' => 'Dernières nouvelles',
        'description' => 'Les informations publiées dans data/news/news.php.'
    ],
    'mini_footer' => 'DoMyDesk reste simple : un bureau web, des modules, des thèmes, et une interface pensée pour évoluer.'
];

$config = json_read($configFile, $defaultConfig);

$success = '';
$error = '';

/* ==========================================================
   Sauvegarde
   ========================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldConfig = $config;

    $newConfig = [
        'hero' => [
            'eyebrow' => trim((string)($_POST['hero']['eyebrow'] ?? '')),
            'title' => trim((string)($_POST['hero']['title'] ?? '')),
            'title_span' => trim((string)($_POST['hero']['title_span'] ?? '')),
            'lead' => trim((string)($_POST['hero']['lead'] ?? '')),
            'buttons' => clean_array_text($_POST['hero']['buttons'] ?? [], ['label', 'url', 'class'])
        ],
        'visual' => [
            'enabled' => !empty($_POST['visual']['enabled']),
            'windows' => []
        ],
        'stats' => clean_array_text($_POST['stats'] ?? [], ['value', 'text']),
        'features_panel' => [
            'kicker' => trim((string)($_POST['features_panel']['kicker'] ?? '')),
            'title' => trim((string)($_POST['features_panel']['title'] ?? '')),
            'description' => trim((string)($_POST['features_panel']['description'] ?? '')),
            'features' => clean_array_text($_POST['features_panel']['features'] ?? [], ['icon', 'title', 'text'])
        ],
        'news_panel' => [
            'kicker' => trim((string)($_POST['news_panel']['kicker'] ?? 'Actualités')),
            'title' => trim((string)($_POST['news_panel']['title'] ?? 'Dernières nouvelles')),
            'description' => trim((string)($_POST['news_panel']['description'] ?? 'Les informations publiées dans data/news/news.php.'))
        ],
        'mini_footer' => trim((string)($_POST['mini_footer'] ?? ''))
    ];

    $visualWindows = $_POST['visual']['windows'] ?? [];

    if (is_array($visualWindows)) {
        foreach ($visualWindows as $window) {
            if (!is_array($window)) {
                continue;
            }

            $rawLines = $window['lines'] ?? [];
            $lines = [];

            if (is_array($rawLines)) {
                foreach ($rawLines as $line) {
                    $line = trim((string)$line);

                    if (in_array($line, ['', 'big', 'mid', 'small'], true)) {
                        $lines[] = $line;
                    }
                }
            }

            if (!empty($lines)) {
                $newConfig['visual']['windows'][] = [
                    'lines' => $lines
                ];
            }
        }
    }

    if (empty($newConfig['visual']['windows'])) {
        $newConfig['visual']['windows'] = $defaultConfig['visual']['windows'];
    }

    if (empty($newConfig['hero']['buttons'])) {
        $newConfig['hero']['buttons'] = $defaultConfig['hero']['buttons'];
    }

    if (empty($newConfig['stats'])) {
        $newConfig['stats'] = $defaultConfig['stats'];
    }

    if (empty($newConfig['features_panel']['features'])) {
        $newConfig['features_panel']['features'] = $defaultConfig['features_panel']['features'];
    }

    if (!is_dir($historyRoot)) {
        mkdir($historyRoot, 0775, true);
    }

    $historyFolder = $historyRoot . '/' . date('d-m-Y_H-i-s') . '_' . folder_safe_email($currentEmail);

    if (!is_dir($historyFolder)) {
        mkdir($historyFolder, 0775, true);
    }

    json_write($historyFolder . '/indexcfg-before.json', $oldConfig);

    if (json_write($configFile, $newConfig)) {
        json_write($historyFolder . '/indexcfg-after.json', $newConfig);
        $config = $newConfig;
        $success = 'Configuration de la page d’accueil enregistrée.';
        dmd_system_log('homepage_settings_updated', 'data/indexcfg.json', 'success', $success, ['history' => basename($historyFolder)]);
    } else {
        $error = 'Impossible d’enregistrer data/indexcfg.json.';
    }
}

$hero = $config['hero'] ?? $defaultConfig['hero'];
$visual = $config['visual'] ?? $defaultConfig['visual'];
$stats = $config['stats'] ?? $defaultConfig['stats'];
$featuresPanel = $config['features_panel'] ?? $defaultConfig['features_panel'];
$newsPanel = $config['news_panel'] ?? $defaultConfig['news_panel'];
$miniFooter = $config['mini_footer'] ?? $defaultConfig['mini_footer'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Configuration accueil - DoMyDesk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../theme/<?= h($theme) ?>/style.css">
<?php require_once dirname(__DIR__) . '/core/dmd_theme_assets.php'; echo dmd_theme_extra_links(dirname(__DIR__), '../theme', $theme, 'indexcfg'); ?>
</head>

<body>
<main class="dmd-home">
    <section class="panel" aria-labelledby="indexcfg-title">
        <div class="panel-head">
            <p class="panel-kicker">Administration</p>
            <h1 class="panel-title" id="indexcfg-title">Réglages de la page d’accueil</h1>
            <p class="panel-desc">
                Modifie les textes de index.php. Les actualités restent alimentées par data/news/news.php.
            </p>
        </div>

        <?php if ($success): ?>
            <div class="success-state"><?= h($success) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="error-state"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="post" class="dmd-form">
            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Hero</p>
                    <h2 class="panel-title">Bloc principal</h2>
                </div>

                <label>
                    Eyebrow
                    <input type="text" name="hero[eyebrow]" value="<?= h($hero['eyebrow'] ?? '') ?>">
                </label>

                <label>
                    Titre
                    <input type="text" name="hero[title]" value="<?= h($hero['title'] ?? '') ?>">
                </label>

                <label>
                    Partie colorée du titre
                    <input type="text" name="hero[title_span]" value="<?= h($hero['title_span'] ?? '') ?>">
                </label>

                <label>
                    Texte d’introduction
                    <textarea name="hero[lead]" rows="5"><?= h($hero['lead'] ?? '') ?></textarea>
                </label>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Boutons</p>
                    <h2 class="panel-title">Actions du hero</h2>
                    <p class="panel-desc">Classe possible : primary. Laisse vide pour un bouton standard.</p>
                </div>

                <?php
                $buttons = $hero['buttons'] ?? [];
                for ($i = 0; $i < 5; $i++):
                    $button = $buttons[$i] ?? ['label' => '', 'url' => '', 'class' => ''];
                ?>
                    <article class="feature">
                        <div class="ico"><?= $i + 1 ?></div>
                        <div>
                            <label>
                                Libellé
                                <input type="text" name="hero[buttons][<?= $i ?>][label]" value="<?= h($button['label'] ?? '') ?>">
                            </label>

                            <label>
                                URL
                                <input type="text" name="hero[buttons][<?= $i ?>][url]" value="<?= h($button['url'] ?? '') ?>">
                            </label>

                            <label>
                                Classe CSS
                                <input type="text" name="hero[buttons][<?= $i ?>][class]" value="<?= h($button['class'] ?? '') ?>">
                            </label>
                        </div>
                    </article>
                <?php endfor; ?>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Visuel</p>
                    <h2 class="panel-title">Fenêtres décoratives</h2>
                </div>

                <label>
                    <input type="checkbox" name="visual[enabled]" value="1" <?= !empty($visual['enabled']) ? 'checked' : '' ?>>
                    Afficher le visuel à droite
                </label>

                <?php
                $windows = $visual['windows'] ?? $defaultConfig['visual']['windows'];
                for ($w = 0; $w < 3; $w++):
                    $window = $windows[$w] ?? ['lines' => ['big', 'mid', 'small']];
                    $lines = $window['lines'] ?? [];
                ?>
                    <article class="feature">
                        <div class="ico"><?= $w + 1 ?></div>
                        <div>
                            <h3>Fenêtre <?= $w + 1 ?></h3>

                            <?php for ($l = 0; $l < 4; $l++): ?>
                                <label>
                                    Ligne <?= $l + 1 ?> : big, mid, small ou vide
                                    <input type="text" name="visual[windows][<?= $w ?>][lines][<?= $l ?>]" value="<?= h($lines[$l] ?? '') ?>">
                                </label>
                            <?php endfor; ?>
                        </div>
                    </article>
                <?php endfor; ?>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Stats</p>
                    <h2 class="panel-title">Points forts</h2>
                </div>

                <?php
                for ($i = 0; $i < 6; $i++):
                    $stat = $stats[$i] ?? ['value' => '', 'text' => ''];
                ?>
                    <article class="feature">
                        <div class="ico"><?= $i + 1 ?></div>
                        <div>
                            <label>
                                Valeur
                                <input type="text" name="stats[<?= $i ?>][value]" value="<?= h($stat['value'] ?? '') ?>">
                            </label>

                            <label>
                                Texte
                                <input type="text" name="stats[<?= $i ?>][text]" value="<?= h($stat['text'] ?? '') ?>">
                            </label>
                        </div>
                    </article>
                <?php endfor; ?>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Centre de contrôle</p>
                    <h2 class="panel-title">Panneau de présentation</h2>
                </div>

                <label>
                    Kicker
                    <input type="text" name="features_panel[kicker]" value="<?= h($featuresPanel['kicker'] ?? '') ?>">
                </label>

                <label>
                    Titre
                    <input type="text" name="features_panel[title]" value="<?= h($featuresPanel['title'] ?? '') ?>">
                </label>

                <label>
                    Description
                    <textarea name="features_panel[description]" rows="4"><?= h($featuresPanel['description'] ?? '') ?></textarea>
                </label>

                <?php
                $features = $featuresPanel['features'] ?? [];
                for ($i = 0; $i < 6; $i++):
                    $feature = $features[$i] ?? ['icon' => '', 'title' => '', 'text' => ''];
                ?>
                    <article class="feature">
                        <div class="ico"><?= h($feature['icon'] ?: ($i + 1)) ?></div>
                        <div>
                            <label>
                                Icône
                                <input type="text" name="features_panel[features][<?= $i ?>][icon]" value="<?= h($feature['icon'] ?? '') ?>">
                            </label>

                            <label>
                                Titre
                                <input type="text" name="features_panel[features][<?= $i ?>][title]" value="<?= h($feature['title'] ?? '') ?>">
                            </label>

                            <label>
                                Texte
                                <textarea name="features_panel[features][<?= $i ?>][text]" rows="3"><?= h($feature['text'] ?? '') ?></textarea>
                            </label>
                        </div>
                    </article>
                <?php endfor; ?>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Actualités</p>
                    <h2 class="panel-title">Textes du panneau uniquement</h2>
                    <p class="panel-desc">Le contenu des actualités reste chargé depuis data/news/news.php.</p>
                </div>

                <label>
                    Kicker
                    <input type="text" name="news_panel[kicker]" value="<?= h($newsPanel['kicker'] ?? '') ?>">
                </label>

                <label>
                    Titre
                    <input type="text" name="news_panel[title]" value="<?= h($newsPanel['title'] ?? '') ?>">
                </label>

                <label>
                    Description
                    <textarea name="news_panel[description]" rows="3"><?= h($newsPanel['description'] ?? '') ?></textarea>
                </label>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <p class="panel-kicker">Bas de page</p>
                    <h2 class="panel-title">Mini footer</h2>
                </div>

                <label>
                    Texte
                    <textarea name="mini_footer" rows="4"><?= h($miniFooter) ?></textarea>
                </label>
            </section>

            <div class="hero-actions">
                <button type="submit" class="home-btn primary">Enregistrer</button>
                <a href="../index.php" class="home-btn">Voir l’accueil</a>
                <a href="site_settings.php" class="home-btn">Retour administration</a>
            </div>
        </form>
    </section>
</main>

</body>
</html>