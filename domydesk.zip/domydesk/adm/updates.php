<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../login.php');
    exit;
}

$baseDir = dirname(__DIR__);
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_sources.php';

$systemUpdatesSourceError = '';
$GITHUB_UPDATES_JSON_URL = dmd_source_url($baseDir, 'updates_systeme', $systemUpdatesSourceError);
$profilesDir = $baseDir . '/users/profiles/';
$profileFile = dmd_profile_path($email, true);

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);

if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$roleSystem = $profileData['role_system'] ?? 'user';

if ($roleSystem !== 'superadmin') {
    dmd_system_log('system_update_access_denied', 'adm/updates.php', 'denied', 'Accès aux mises à jour système refusé : compte Superadmin requis.');
    echo '<script>if (window.top !== window.self) { window.top.location.href = "../dashboard.php"; } else { window.location.href = "../dashboard.php"; }</script>';
    echo '<noscript><meta http-equiv="refresh" content="0;url=../dashboard.php"></noscript>';
    exit;
}

$updatesDir = $baseDir . '/data/updates/';
$logsFile = $updatesDir . 'logs.json';

if (empty($_SESSION['csrf_system_updates'])) {
    $_SESSION['csrf_system_updates'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['csrf_system_updates'];

if (!is_dir($updatesDir)) {
    @mkdir($updatesDir, 0775, true);
}

$theme = 'default';
$themeJson = $profilesDir . $email . '/theme.json';

if (is_file($themeJson)) {
    $themeData = json_decode((string)file_get_contents($themeJson), true);

    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidateTheme = basename((string)$themeData['theme']);

        if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
            $theme = $candidateTheme;
        }
    }
}

$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';

if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

function dmd_updates_h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_updates_read_json(string $file, $default = []) {
    if (!is_file($file)) {
        return $default;
    }

    $data = json_decode((string)file_get_contents($file), true);

    return is_array($data) ? $data : $default;
}

function dmd_updates_write_json(string $file, array $data): bool {
    $dir = dirname($file);

    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    return file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    ) !== false;
}

function dmd_updates_clean_item(array $item): array {
    return [
        'titre' => trim((string)($item['titre'] ?? '')),
        'soustitre' => trim((string)($item['soustitre'] ?? '')),
        'date' => trim((string)($item['date'] ?? '')),
        'update' => trim((string)($item['update'] ?? '')),
        'description' => trim((string)($item['description'] ?? ''))
    ];
}

function dmd_updates_clean_log_item(array $item): array {
    $clean = dmd_updates_clean_item($item);

    $clean['installed_at'] = trim((string)($item['installed_at'] ?? ''));
    $clean['installed_by'] = trim((string)($item['installed_by'] ?? ''));

    return $clean;
}

function dmd_updates_has_main_fields(array $item): bool {
    $item = dmd_updates_clean_item($item);

    return $item['titre'] !== ''
        && $item['date'] !== ''
        && $item['update'] !== ''
        && $item['description'] !== '';
}

function dmd_updates_is_list(array $array): bool {
    if (function_exists('array_is_list')) {
        return array_is_list($array);
    }

    $i = 0;

    foreach ($array as $key => $_value) {
        if ($key !== $i++) {
            return false;
        }
    }

    return true;
}

function dmd_updates_url_dir(string $url): string {
    $pos = strrpos($url, '/');

    if ($pos === false) {
        return $url;
    }

    return substr($url, 0, $pos);
}

function dmd_updates_filename_from_title(string $title): string {
    $title = trim($title);
    $title = str_replace(['/', '\\', "\0"], '-', $title);

    return $title;
}

function dmd_updates_build_candidate_zip_urls(array $item, string $jsonUrl): array {
    $urls = [];

    foreach (['zip_url', 'url_zip', 'download_url', 'zip', 'url'] as $field) {
        if (!empty($item[$field])) {
            $urls[] = trim((string)$item[$field]);
        }
    }

    $base = dmd_updates_url_dir($jsonUrl);

    $titre = dmd_updates_filename_from_title((string)($item['titre'] ?? ''));
    $soustitre = dmd_updates_filename_from_title((string)($item['soustitre'] ?? ''));
    $update = dmd_updates_filename_from_title((string)($item['update'] ?? ''));

    foreach ([$titre, $soustitre, $update] as $name) {
        if ($name !== '') {
            $urls[] = $base . '/' . rawurlencode($name) . '.zip';
            $urls[] = $base . '/updates/' . rawurlencode($name) . '.zip';
            $urls[] = $base . '/zips/' . rawurlencode($name) . '.zip';
        }
    }

    return array_values(array_unique(array_filter($urls)));
}

function dmd_updates_fetch_catalog($raw, string $sourceUrl): array {
    if ($raw === false || trim((string)$raw) === '') {
        return [];
    }

    $json = json_decode((string)$raw, true);

    if (!is_array($json)) {
        return [];
    }

    if (isset($json['updates']) && is_array($json['updates'])) {
        $json = $json['updates'];
    }

    if (!dmd_updates_is_list($json)) {
        return [];
    }

    $items = [];

    foreach ($json as $item) {
        if (!is_array($item)) {
            continue;
        }

        $clean = dmd_updates_clean_item($item);

        if (!dmd_updates_has_main_fields($clean)) {
            continue;
        }

        $clean['_zip_urls'] = dmd_updates_build_candidate_zip_urls($item, $sourceUrl);

        $items[] = $clean;
    }

    return $items;
}

function dmd_updates_download_file(string $url, string $dest): bool {
    $context = stream_context_create([
        'http' => [
            'timeout' => 60,
            'user_agent' => 'DoMyDesk-Updates'
        ],
        'https' => [
            'timeout' => 60,
            'user_agent' => 'DoMyDesk-Updates'
        ]
    ]);

    $content = @file_get_contents($url, false, $context);

    if ($content === false || strlen($content) < 10) {
        return false;
    }

    return file_put_contents($dest, $content) !== false;
}

function dmd_updates_download_first_available(array $urls, string $dest): bool {
    foreach ($urls as $url) {
        $url = trim((string)$url);

        if ($url === '') {
            continue;
        }

        if (dmd_updates_download_file($url, $dest)) {
            return true;
        }
    }

    return false;
}

function dmd_updates_remove_dir(string $dir): void {
    if (!is_dir($dir)) {
        return;
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @rmdir($item->getPathname());
        } else {
            @unlink($item->getPathname());
        }
    }

    @rmdir($dir);
}

function dmd_updates_temp_dir(string $updatesDir): string {
    $base = $updatesDir . 'tmp_' . date('Y-m-d_H-i-s');
    $dir = $base;
    $i = 2;

    while (file_exists($dir)) {
        $dir = $base . '_' . $i;
        $i++;
    }

    @mkdir($dir, 0775, true);

    return $dir;
}

function dmd_updates_starts_with(string $text, string $needle): bool {
    return substr($text, 0, strlen($needle)) === $needle;
}

function dmd_updates_bad_zip_path(string $path): bool {
    $path = str_replace('\\', '/', trim($path));

    if ($path === '') {
        return true;
    }

    if (dmd_updates_starts_with($path, '/')) {
        return true;
    }

    if (preg_match('#(^|/)\.\.(/|$)#', $path)) {
        return true;
    }

    if (strpos($path, "\0") !== false) {
        return true;
    }

    $blocked = [
        '.git/',
        '.env',
        'data/updates/',
        'users/profiles/'
    ];

    foreach ($blocked as $block) {
        if (dmd_updates_starts_with($path, $block)) {
            return true;
        }
    }

    return false;
}

function dmd_updates_copy_file(string $source, string $target): bool {
    $dir = dirname($target);

    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        return false;
    }

    return @copy($source, $target);
}

function dmd_updates_zip_entries(string $zipPath, array &$errors): array {
    $errors = [];
    $entries = [];

    if (!class_exists('ZipArchive')) {
        $errors[] = 'ZipArchive n’est pas disponible.';
        return [];
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        $errors[] = 'Impossible d’ouvrir le ZIP.';
        return [];
    }

    if ($zip->numFiles > 10000) {
        $errors[] = 'Le ZIP contient trop de fichiers.';
        $zip->close();
        return [];
    }

    $total = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (!is_array($stat)) {
            $errors[] = 'Entrée ZIP illisible.';
            break;
        }

        $name = str_replace('\\', '/', (string)($stat['name'] ?? ''));
        if ($name === '' || substr($name, -1) === '/') {
            continue;
        }

        if (dmd_updates_bad_zip_path($name)) {
            $errors[] = 'Chemin interdit dans le ZIP : ' . $name;
            break;
        }

        $total += (int)($stat['size'] ?? 0);
        if ($total > 536870912) {
            $errors[] = 'Le ZIP décompressé dépasse 512 Mo.';
            break;
        }

        $entries[] = $name;
    }

    $zip->close();
    if ($errors) {
        return [];
    }

    return array_values(array_unique($entries));
}

function dmd_updates_restore_transaction(string $baseDir, string $backupDir, array $journal): void {
    foreach (array_reverse($journal) as $entry) {
        $relative = (string)($entry['path'] ?? '');
        if ($relative === '') {
            continue;
        }

        $target = $baseDir . '/' . $relative;
        if (!empty($entry['existed'])) {
            $backup = $backupDir . '/' . $relative;
            if (is_file($backup)) {
                dmd_updates_copy_file($backup, $target);
            }
        } elseif (is_file($target) || is_link($target)) {
            @unlink($target);
        }
    }
}

function dmd_updates_apply_zip(string $zipPath, string $baseDir, string $tempDir): array {
    $result = ['success' => false, 'message' => ''];

    if (!is_file($zipPath)) {
        $result['message'] = 'ZIP introuvable.';
        return $result;
    }

    $zipErrors = [];
    $entries = dmd_updates_zip_entries($zipPath, $zipErrors);
    if ($zipErrors) {
        $result['message'] = implode(' ', $zipErrors);
        return $result;
    }
    if (!$entries) {
        $result['message'] = 'Le ZIP ne contient aucun fichier applicable.';
        return $result;
    }

    $extractDir = $tempDir . '/extract';
    $backupDir = $tempDir . '/backup';
    if (!@mkdir($extractDir, 0775, true) && !is_dir($extractDir)) {
        $result['message'] = 'Impossible de préparer le dossier temporaire.';
        return $result;
    }
    if (!@mkdir($backupDir, 0775, true) && !is_dir($backupDir)) {
        $result['message'] = 'Impossible de préparer le backup temporaire.';
        return $result;
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        $result['message'] = 'Impossible d’ouvrir le ZIP.';
        return $result;
    }
    if (!$zip->extractTo($extractDir)) {
        $zip->close();
        $result['message'] = 'Extraction impossible.';
        return $result;
    }
    $zip->close();

    $journal = [];
    foreach ($entries as $relativePath) {
        if ($relativePath === 'update.json' || $relativePath === 'manifest.json') {
            continue;
        }

        $sourcePath = $extractDir . '/' . $relativePath;
        if (!is_file($sourcePath)) {
            $result['message'] = 'Fichier extrait introuvable : ' . $relativePath;
            dmd_updates_restore_transaction($baseDir, $backupDir, $journal);
            return $result;
        }

        $targetPath = $baseDir . '/' . $relativePath;
        $existed = is_file($targetPath) || is_link($targetPath);

        if ($existed) {
            $backupPath = $backupDir . '/' . $relativePath;
            if (!dmd_updates_copy_file($targetPath, $backupPath)) {
                $result['message'] = 'Backup impossible avant remplacement : ' . $relativePath;
                dmd_updates_restore_transaction($baseDir, $backupDir, $journal);
                return $result;
            }
        }

        $journal[] = ['path' => $relativePath, 'existed' => $existed];
        if (!dmd_updates_copy_file($sourcePath, $targetPath)) {
            dmd_updates_restore_transaction($baseDir, $backupDir, $journal);
            $result['message'] = 'Échec de copie : ' . $relativePath . '. Rollback effectué.';
            return $result;
        }
    }

    $result['success'] = true;
    $result['message'] = 'Update appliquée.';
    return $result;
}

function dmd_updates_acquire_lock(string $updatesDir, &$handle): bool {
    $handle = @fopen($updatesDir . 'update.lock', 'c+');
    return is_resource($handle) && @flock($handle, LOCK_EX | LOCK_NB);
}

function dmd_updates_release_lock($handle): void {
    if (is_resource($handle)) {
        @flock($handle, LOCK_UN);
        @fclose($handle);
    }
}

function dmd_updates_read_zip_meta(string $zipPath): array {
    if (!class_exists('ZipArchive') || !is_file($zipPath)) {
        return [];
    }

    $zip = new ZipArchive();

    if ($zip->open($zipPath) !== true) {
        return [];
    }

    $raw = false;

    foreach (['update.json', 'manifest.json'] as $file) {
        $index = $zip->locateName($file);

        if ($index !== false) {
            $raw = $zip->getFromIndex($index);
            break;
        }
    }

    $zip->close();

    if ($raw === false) {
        return [];
    }

    $json = json_decode((string)$raw, true);

    if (!is_array($json)) {
        return [];
    }

    $meta = dmd_updates_clean_item($json);

    if (!dmd_updates_has_main_fields($meta)) {
        return [];
    }

    return $meta;
}

function dmd_updates_manual_meta(string $uploadedName): array {
    $titre = trim(pathinfo($uploadedName, PATHINFO_FILENAME));

    if ($titre === '') {
        $titre = 'update-manuelle';
    }

    return [
        'titre' => $titre,
        'soustitre' => '',
        'date' => date('Y-m-d'),
        'update' => 'manual',
        'description' => ''
    ];
}

function dmd_updates_append_log(string $logsFile, array $item, string $email): bool {
    $logs = dmd_updates_read_json($logsFile, []);

    if (!is_array($logs)) {
        $logs = [];
    }

    $log = dmd_updates_clean_log_item($item);
    $log['installed_at'] = date('Y-m-d H:i:s');
    $log['installed_by'] = $email;

    $logs[] = $log;

    return dmd_updates_write_json($logsFile, $logs);
}

$messages = [];
$errors = [];
$catalogRawOverride = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');

    if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) {
        $errors[] = 'Jeton de sécurité invalide. Recharge la page.';
    } elseif ($action === 'refresh_catalog') {
        $refreshError = '';
        $refreshOk = false;
        $catalogRawOverride = dmd_source_load_raw($baseDir, 'updates_systeme', true, $refreshError, $refreshOk);
        if ($refreshOk) {
            $messages[] = 'Catalogue des updates système rafraîchi directement depuis GitHub.';
        } else {
            $errors[] = 'Rafraîchissement GitHub impossible' . ($refreshError !== '' ? ' : ' . $refreshError : '.') . ' Le dernier cache valide est conservé.';
        }
    } elseif ($action === 'github_update') {
        $updateLock = null;
        if (!dmd_updates_acquire_lock($updatesDir, $updateLock)) {
            $errors[] = 'Une autre mise à jour DoMyDesk est déjà en cours.';
        } else {
            try {
                $urlsRaw = (string)($_POST['zip_urls'] ?? '');
                $urlsJson = base64_decode($urlsRaw, true);
                $zipUrls = $urlsJson !== false ? json_decode((string)$urlsJson, true) : [];
                if (!is_array($zipUrls)) {
                    $zipUrls = [];
                }

                $metaRaw = (string)($_POST['meta'] ?? '');
                $metaJson = base64_decode($metaRaw, true);
                $meta = $metaJson !== false ? json_decode((string)$metaJson, true) : [];
                if (!is_array($meta)) {
                    $meta = [];
                }
                $meta = dmd_updates_clean_item($meta);

                if (!dmd_updates_has_main_fields($meta)) {
                    $errors[] = 'Update invalide.';
                } else {
                    $tempDir = dmd_updates_temp_dir($updatesDir);
                    $zipPath = $tempDir . '/source.zip';

                    if (!dmd_updates_download_first_available($zipUrls, $zipPath)) {
                        $errors[] = 'ZIP introuvable.';
                    } else {
                        $apply = dmd_updates_apply_zip($zipPath, $baseDir, $tempDir);
                        if ($apply['success']) {
                            dmd_updates_append_log($logsFile, $meta, $email);
                            $messages[] = 'Update appliquée.';
                            dmd_system_log('system_update_installed', (string)($meta['titre'] ?? 'DoMyDesk'), 'success', 'Mise à jour système appliquée depuis le catalogue GitHub.', ['update' => $meta['update'] ?? '', 'date' => $meta['date'] ?? '']);
                            dmd_notify_all('system_update_installed', 'DoMyDesk a été mis à jour', 'Une mise à jour système DoMyDesk vient d’être installée.', ['level' => 'info']);
                        } else {
                            $errors[] = $apply['message'];
                        }
                    }
                    dmd_updates_remove_dir($tempDir);
                }
            } finally {
                dmd_updates_release_lock($updateLock);
            }
        }
    } elseif ($action === 'manual_update') {
        $updateLock = null;
        if (!dmd_updates_acquire_lock($updatesDir, $updateLock)) {
            $errors[] = 'Une autre mise à jour DoMyDesk est déjà en cours.';
        } else {
            try {
                if (empty($_FILES['update_zip']['tmp_name'])) {
                    $errors[] = 'Aucun ZIP envoyé.';
                } else {
                    $uploadedName = $_FILES['update_zip']['name'] ?? 'update.zip';
                    $ext = strtolower(pathinfo($uploadedName, PATHINFO_EXTENSION));

                    if ($ext !== 'zip') {
                        $errors[] = 'Le fichier doit être un ZIP.';
                    } else {
                        $tempDir = dmd_updates_temp_dir($updatesDir);
                        $zipPath = $tempDir . '/source.zip';

                        if (!@move_uploaded_file($_FILES['update_zip']['tmp_name'], $zipPath)) {
                            $errors[] = 'Upload impossible.';
                        } else {
                            $meta = dmd_updates_read_zip_meta($zipPath);
                            if (empty($meta)) {
                                $meta = dmd_updates_manual_meta($uploadedName);
                            }

                            $apply = dmd_updates_apply_zip($zipPath, $baseDir, $tempDir);
                            if ($apply['success']) {
                                dmd_updates_append_log($logsFile, $meta, $email);
                                $messages[] = 'Update appliquée.';
                                dmd_system_log('system_update_installed_manual', (string)($meta['titre'] ?? 'DoMyDesk'), 'success', 'Mise à jour système appliquée depuis un ZIP manuel.', ['update' => $meta['update'] ?? '', 'date' => $meta['date'] ?? '']);
                                dmd_notify_all('system_update_installed', 'DoMyDesk a été mis à jour', 'Une mise à jour système DoMyDesk vient d’être installée.', ['level' => 'info']);
                            } else {
                                $errors[] = $apply['message'];
                            }
                        }
                        dmd_updates_remove_dir($tempDir);
                    }
                }
            } finally {
                dmd_updates_release_lock($updateLock);
            }
        }
    }
}

$catalogError = $systemUpdatesSourceError;
$catalogRefreshed = false;
$catalogRaw = $catalogRawOverride;
if ($catalogRaw === null) {
    $catalogRaw = dmd_source_load_raw($baseDir, 'updates_systeme', false, $catalogError, $catalogRefreshed);
}
$catalog = dmd_updates_fetch_catalog($catalogRaw, $GITHUB_UPDATES_JSON_URL);
$logs = dmd_updates_read_json($logsFile, []);

if (!is_array($logs)) {
    $logs = [];
}

$installed = array_reverse(array_values(array_filter($logs, 'is_array')));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Updates DoMyDesk</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?= dmd_updates_h($themeCssHref) ?>">
<?php require_once $baseDir . '/core/dmd_theme_assets.php'; echo dmd_theme_extra_links($baseDir, '../theme', $theme, 'updates'); ?>
<link rel="stylesheet" href="updates.css?v=<?= is_file(__DIR__ . '/updates.css') ? (int)filemtime(__DIR__ . '/updates.css') : 1 ?>">
</head>
<body>

<div class="pe-page dmd-updates-page">

    <div class="pe-head">
        <div>
            <h1 class="pe-title">Toutes les updates</h1>
            <p class="pe-subtitle">Catalogue GitHub et updates installées.</p>
        </div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= dmd_updates_h($csrf) ?>">
            <input type="hidden" name="action" value="refresh_catalog">
            <button type="submit" title="Rafraîchir immédiatement depuis GitHub">↻ Rafraîchir</button>
        </form>
    </div>

    <?php if (!empty($messages)): ?>
        <div class="pe-msg pe-msg-ok">
            <?php foreach ($messages as $message): ?>
                <?= dmd_updates_h($message) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($catalogError !== '' && $catalogRaw === false): ?>
        <div class="pe-msg pe-msg-error">Impossible de charger /sources/updatessystems.json : <?= dmd_updates_h($catalogError) ?></div>
    <?php endif; ?>

    <?php if (!empty($errors)): ?>
        <div class="pe-msg pe-msg-error">
            <?php foreach ($errors as $error): ?>
                <?= dmd_updates_h($error) ?><br>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="dmd-updates-grid">

        <section class="pe-section dmd-update-panel dmd-update-catalog">
            <h2 class="pe-section-title">Catalogue updates</h2>

            <?php if (empty($catalog)): ?>
                <p class="pe-note">Aucune update disponible.</p>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Date</th>
                                <th>Installation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($catalog as $index => $update): ?>
                                <?php
                                $popupId = 'popup-update-catalog-' . $index;
                                $zipUrls = $update['_zip_urls'] ?? [];
                                $visibleMeta = dmd_updates_clean_item($update);
                                $metaEncoded = base64_encode(json_encode($visibleMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                                $urlsEncoded = base64_encode(json_encode($zipUrls, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                                ?>
                                <tr>
                                    <td>
                                        <button type="button" class="btn" data-popup-open="<?= dmd_updates_h($popupId) ?>">
                                            <?= dmd_updates_h($update['titre']) ?>
                                        </button>
                                    </td>
                                    <td><?= dmd_updates_h($update['date']) ?></td>
                                    <td>
                                        <form method="post" accept-charset="UTF-8" onsubmit="return confirm('Installer cette update ?');">
                                            <input type="hidden" name="csrf_token" value="<?= dmd_updates_h($csrf) ?>">
                                            <input type="hidden" name="action" value="github_update">
                                            <input type="hidden" name="zip_urls" value="<?= dmd_updates_h($urlsEncoded) ?>">
                                            <input type="hidden" name="meta" value="<?= dmd_updates_h($metaEncoded) ?>">
                                            <button type="submit">Installer</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php foreach ($catalog as $index => $update): ?>
                    <?php $popupId = 'popup-update-catalog-' . $index; ?>
                    <div id="<?= dmd_updates_h($popupId) ?>" class="pe-popup" aria-hidden="true">
                        <div class="pe-popup-window">
                            <div class="pe-popup-head">
                                <h2><?= dmd_updates_h($update['titre']) ?></h2>
                                <button type="button" data-popup-close>Fermer</button>
                            </div>
                            <div class="pe-popup-body">
                                <?php if (!empty($update['soustitre'])): ?>
                                    <p><strong><?= dmd_updates_h($update['soustitre']) ?></strong></p>
                                <?php endif; ?>
                                <p class="pe-note"><?= dmd_updates_h($update['date']) ?> — <?= dmd_updates_h($update['update']) ?></p>
                                <p><?= nl2br(dmd_updates_h($update['description'])) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

        </section>

        <section class="pe-section dmd-update-panel dmd-update-installed">
            <h2 class="pe-section-title">Updates installées</h2>

            <?php if (empty($installed)): ?>
                <p class="pe-note">Aucune update installée.</p>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Date update</th>
                                <th>Installée le</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($installed as $index => $update): ?>
                                <?php
                                $update = dmd_updates_clean_log_item($update);
                                $popupId = 'popup-update-installed-' . $index;
                                ?>
                                <tr>
                                    <td>
                                        <button type="button" class="btn" data-popup-open="<?= dmd_updates_h($popupId) ?>">
                                            <?= dmd_updates_h($update['titre']) ?>
                                        </button>
                                    </td>
                                    <td><?= dmd_updates_h($update['date']) ?></td>
                                    <td><?= dmd_updates_h($update['installed_at']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php foreach ($installed as $index => $update): ?>
                    <?php
                    $update = dmd_updates_clean_log_item($update);
                    $popupId = 'popup-update-installed-' . $index;
                    ?>
                    <div id="<?= dmd_updates_h($popupId) ?>" class="pe-popup" aria-hidden="true">
                        <div class="pe-popup-window">
                            <div class="pe-popup-head">
                                <h2><?= dmd_updates_h($update['titre']) ?></h2>
                                <button type="button" data-popup-close>Fermer</button>
                            </div>
                            <div class="pe-popup-body">
                                <?php if (!empty($update['soustitre'])): ?>
                                    <p><strong><?= dmd_updates_h($update['soustitre']) ?></strong></p>
                                <?php endif; ?>
                                <p class="pe-note">Date update : <?= dmd_updates_h($update['date']) ?></p>
                                <p class="pe-note">Type update : <?= dmd_updates_h($update['update']) ?></p>
                                <p class="pe-note">Installée le : <?= dmd_updates_h($update['installed_at']) ?></p>
                                <p class="pe-note">Installée par : <?= dmd_updates_h($update['installed_by']) ?></p>
                                <p><?= nl2br(dmd_updates_h($update['description'])) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>

    </div>

    <section class="pe-section dmd-update-panel dmd-update-manual">
        <h2 class="pe-section-title">Update manuelle</h2>

        <form method="post" accept-charset="UTF-8" enctype="multipart/form-data" class="dmd-manual-form" onsubmit="return confirm('Installer ce ZIP de mise à jour ?');">
            <input type="hidden" name="csrf_token" value="<?= dmd_updates_h($csrf) ?>">
            <input type="hidden" name="action" value="manual_update">

            <label class="dmd-manual-file">
                <span>ZIP de mise à jour</span>
                <input type="file" name="update_zip" accept=".zip" required>
            </label>

            <p class="pe-note">Le ZIP doit contenir l’arborescence depuis la racine DoMyDesk.</p>

            <button type="submit">Installer le ZIP</button>
        </form>
    </section>
</div>

<script>
(function () {
    function openPopup(id) {
        const popup = document.getElementById(id);
        if (!popup) return;
        popup.classList.add('is-open');
        popup.setAttribute('aria-hidden', 'false');
        document.body.classList.add('noscroll');
    }

    function closePopup(popup) {
        if (!popup) return;
        popup.classList.remove('is-open');
        popup.setAttribute('aria-hidden', 'true');

        if (!document.querySelector('.pe-popup.is-open')) {
            document.body.classList.remove('noscroll');
        }
    }

    document.querySelectorAll('[data-popup-open]').forEach(function (button) {
        button.addEventListener('click', function () {
            openPopup(button.getAttribute('data-popup-open'));
        });
    });

    document.querySelectorAll('[data-popup-close]').forEach(function (button) {
        button.addEventListener('click', function () {
            closePopup(button.closest('.pe-popup'));
        });
    });

    document.querySelectorAll('.pe-popup').forEach(function (popup) {
        popup.addEventListener('click', function (event) {
            if (event.target === popup) {
                closePopup(popup);
            }
        });
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            document.querySelectorAll('.pe-popup.is-open').forEach(closePopup);
        }
    });
})();
</script>

</body>
</html>