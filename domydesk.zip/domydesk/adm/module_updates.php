<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

$baseDir = dirname(__DIR__);

require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_module_contract.php';
require_once $baseDir . '/core/dmd_sources.php';

$moduleUpdatesSourceError = '';
$MODULE_UPDATES_CATALOG_URL = dmd_source_url($baseDir, 'updates_modules', $moduleUpdatesSourceError);

$email = $_SESSION['user']['email'] ?? '';
if ($email === '') {
    echo '<script>if(window.top!==window.self){window.top.location.href="../login.php";}else{window.location.href="../login.php";}</script>';
    exit;
}

$profile = dmd_read_profile($email);
if (($profile['role_system'] ?? 'user') !== 'superadmin') {
    dmd_system_log('module_update_access_denied', 'adm/module_updates.php', 'denied', 'Accès aux mises à jour de modules refusé : compte Superadmin requis.');
    echo '<script>if(window.top!==window.self){window.top.location.href="../dashboard.php";}else{window.location.href="../dashboard.php";}</script>';
    exit;
}

if (empty($_SESSION['csrf_module_updates'])) {
    $_SESSION['csrf_module_updates'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_module_updates'];

$theme = 'default';
$themeJson = $baseDir . '/users/profiles/' . basename($email) . '/theme.json';
if (is_file($themeJson)) {
    $td = json_decode((string)file_get_contents($themeJson), true);
    if (is_array($td) && !empty($td['theme'])) {
        $candidate = basename((string)$td['theme']);
        if (is_file($baseDir . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}
$themeHref = '../theme/' . rawurlencode($theme) . '/style.css';
$themeFile = $baseDir . '/theme/' . $theme . '/style.css';
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}

$updatesDir = $baseDir . '/data/updates/';
$logsFile = $updatesDir . 'module_updates_logs.json';
$listFile = $baseDir . '/modules/list.json';
if (!is_dir($updatesDir)) {
    @mkdir($updatesDir, 0775, true);
}

function dmd_mu_h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function dmd_mu_read_json($file, $fallback = array()) {
    if (!is_file($file)) {
        return $fallback;
    }
    $raw = @file_get_contents($file);
    if ($raw === false || trim((string)$raw) === '') {
        return $fallback;
    }
    $d = json_decode((string)$raw, true);
    return is_array($d) ? $d : $fallback;
}

function dmd_mu_write_json_atomic($file, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }

    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        return false;
    }

    $tmp = $file . '.tmp-' . getmypid() . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }
    @chmod($tmp, 0664);

    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    @chmod($file, 0664);
    return true;
}

function dmd_mu_http_get($url, &$error = '') {
    $error = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 8,
            CURLOPT_CONNECTTIMEOUT => 12,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_USERAGENT => 'DoMyDesk-ModuleUpdates/1.2.0',
        ));
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            $error = $body === false ? $err : ('HTTP ' . $code);
            return false;
        }
        return $body;
    }

    $ctx = stream_context_create(array(
        'http' => array('timeout' => 45, 'user_agent' => 'DoMyDesk-ModuleUpdates/1.2.0'),
        'https' => array('timeout' => 45, 'user_agent' => 'DoMyDesk-ModuleUpdates/1.2.0'),
    ));
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        $error = 'Téléchargement impossible.';
        return false;
    }
    return $body;
}

function dmd_mu_is_list($array) {
    if (!is_array($array)) {
        return false;
    }
    $i = 0;
    foreach ($array as $k => $_) {
        if ($k !== $i++) {
            return false;
        }
    }
    return true;
}

function dmd_mu_clean_item($item) {
    return array(
        'titre' => trim((string)($item['titre'] ?? '')),
        'soustitre' => trim((string)($item['soustitre'] ?? '')),
        'date' => trim((string)($item['date'] ?? '')),
        'update' => trim((string)($item['update'] ?? 'Module')),
        'description' => trim((string)($item['description'] ?? '')),
        'url' => trim((string)($item['url'] ?? ($item['download_url'] ?? ''))),
        'module_id' => trim((string)($item['module_id'] ?? ($item['id'] ?? ''))),
    );
}

function dmd_mu_catalog($raw, &$error = '') {
    if ($raw === false || trim((string)$raw) === '') {
        if ($error === '') $error = 'Catalogue modules indisponible dans /sources/updatesmodules.json.';
        return array();
    }
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        $error = 'JSON du catalogue invalide.';
        return array();
    }
    if (isset($data['updates']) && is_array($data['updates'])) {
        $data = $data['updates'];
    }
    if (!dmd_mu_is_list($data)) {
        $data = array($data);
    }

    $out = array();
    foreach ($data as $item) {
        if (!is_array($item)) {
            continue;
        }
        $clean = dmd_mu_clean_item($item);
        if ($clean['titre'] === '' || $clean['url'] === '') {
            continue;
        }
        $out[] = $clean;
    }
    return $out;
}

function dmd_mu_download($url, $dest, &$error = '') {
    $body = dmd_mu_http_get($url, $error);
    if ($body === false || strlen((string)$body) < 20) {
        return false;
    }
    return @file_put_contents($dest, $body, LOCK_EX) !== false;
}

function dmd_mu_temp_dir($base) {
    $dir = rtrim($base, '/\\') . '/tmp_module_' . date('Ymd_His') . '_' . substr(bin2hex(random_bytes(4)), 0, 8);
    @mkdir($dir, 0750, true);
    @chmod($dir, 0750);
    return $dir;
}

function dmd_mu_remove_dir($dir) {
    if (!is_dir($dir) || is_link($dir)) {
        if (is_link($dir)) {
            @unlink($dir);
        }
        return;
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $item) {
        if ($item->isLink() || is_link($item->getPathname())) {
            @unlink($item->getPathname());
        } elseif ($item->isDir()) {
            @chmod($item->getPathname(), 0775);
            @rmdir($item->getPathname());
        } else {
            @chmod($item->getPathname(), 0664);
            @unlink($item->getPathname());
        }
    }
    @chmod($dir, 0775);
    @rmdir($dir);
}

function dmd_mu_copy_tree($source, $target, &$errors) {
    if (!is_dir($source) || is_link($source)) {
        $errors[] = 'Source du module invalide ou lien symbolique.';
        return false;
    }
    if (!is_dir($target) && !@mkdir($target, 0775, true) && !is_dir($target)) {
        $errors[] = 'Impossible de créer le dossier temporaire du module.';
        return false;
    }

    $source = rtrim($source, '/\\');
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($it as $item) {
        $full = $item->getPathname();
        if ($item->isLink() || is_link($full)) {
            $errors[] = 'Copie refusée : lien symbolique détecté dans le paquet.';
            return false;
        }
        $relative = ltrim(str_replace('\\', '/', substr($full, strlen($source))), '/');
        $dest = rtrim($target, '/\\') . '/' . $relative;

        if ($item->isDir()) {
            if (!is_dir($dest) && !@mkdir($dest, 0775, true) && !is_dir($dest)) {
                $errors[] = 'Impossible de créer : ' . $relative . '.';
                return false;
            }
            @chmod($dest, 0775);
        } else {
            $parent = dirname($dest);
            if (!is_dir($parent) && !@mkdir($parent, 0775, true) && !is_dir($parent)) {
                $errors[] = 'Impossible de créer le dossier de : ' . $relative . '.';
                return false;
            }
            if (!@copy($full, $dest)) {
                $errors[] = 'Impossible de copier : ' . $relative . '.';
                return false;
            }
            @chmod($dest, 0664);
        }
    }
    return true;
}

function dmd_mu_safe_extract_zip($zipPath, $extractDir, &$errors) {
    if (!class_exists('ZipArchive')) {
        $errors[] = 'ZipArchive n’est pas disponible.';
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        $errors[] = 'Impossible d’ouvrir le ZIP.';
        return false;
    }

    $totalUncompressed = 0;
    if ($zip->numFiles > 5000) {
        $zip->close();
        $errors[] = 'ZIP refusé : trop de fichiers.';
        return false;
    }

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        $name = (string)$zip->getNameIndex($i);
        $name = str_replace('\\', '/', $name);

        if ($name === '' || strpos($name, "\0") !== false || substr($name, 0, 1) === '/' || preg_match('~^[A-Za-z]:/~', $name) || preg_match('~(^|/)\.\.(/|$)~', $name)) {
            $zip->close();
            $errors[] = 'ZIP refusé : chemin dangereux détecté.';
            return false;
        }

        if (is_array($stat) && isset($stat['size'])) {
            $totalUncompressed += (int)$stat['size'];
            if ($totalUncompressed > 268435456) {
                $zip->close();
                $errors[] = 'ZIP refusé : contenu décompressé supérieur à 256 Mo.';
                return false;
            }
        }
    }

    if (!is_dir($extractDir) && !@mkdir($extractDir, 0750, true) && !is_dir($extractDir)) {
        $zip->close();
        $errors[] = 'Impossible de créer la zone temporaire.';
        return false;
    }

    if (!$zip->extractTo($extractDir)) {
        $zip->close();
        $errors[] = 'Extraction du ZIP impossible.';
        return false;
    }
    $zip->close();
    return true;
}

function dmd_mu_real_children($dir) {
    $items = @scandir($dir);
    if (!is_array($items)) {
        return array();
    }
    $out = array();
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item === '__MACOSX' || $item === '.DS_Store') {
            continue;
        }
        $out[] = $item;
    }
    return $out;
}

function dmd_mu_package_roots($stageDir, &$errors) {
    $stageDir = rtrim($stageDir, '/\\');

    /* ZIP direct : dmd_module.json à la racine. */
    if (is_file($stageDir . '/dmd_module.json')) {
        return array(array('root' => $stageDir, 'expected_id' => ''));
    }

    /* ZIP emballé dans un unique dossier. */
    $children = dmd_mu_real_children($stageDir);
    if (count($children) === 1 && is_dir($stageDir . '/' . $children[0])) {
        $wrapper = $stageDir . '/' . $children[0];
        if (is_file($wrapper . '/dmd_module.json')) {
            return array(array('root' => $wrapper, 'expected_id' => ''));
        }
        if (is_dir($wrapper . '/modules')) {
            $stageDir = $wrapper;
            $children = dmd_mu_real_children($stageDir);
        }
    }

    /* Bundle update : uniquement update.json / manifest.json et modules/. */
    if (!is_dir($stageDir . '/modules')) {
        $errors[] = 'Le ZIP doit être un module 1.2.0 direct ou contenir modules/<id>/.';
        return false;
    }

    foreach ($children as $child) {
        if ($child === 'modules' || $child === 'update.json' || $child === 'manifest.json') {
            continue;
        }
        $errors[] = 'Fichier ou dossier interdit à la racine du bundle : ' . $child . '.';
        return false;
    }

    $moduleFolders = dmd_mu_real_children($stageDir . '/modules');
    if (!$moduleFolders) {
        $errors[] = 'Le bundle ne contient aucun module.';
        return false;
    }

    $roots = array();
    foreach ($moduleFolders as $folder) {
        $root = $stageDir . '/modules/' . $folder;
        if (!is_dir($root) || is_link($root)) {
            $errors[] = 'Entrée invalide dans modules/ : ' . $folder . '.';
            return false;
        }
        if (!is_file($root . '/dmd_module.json')) {
            $errors[] = 'dmd_module.json absent pour le module ' . $folder . '.';
            return false;
        }
        $roots[] = array('root' => $root, 'expected_id' => $folder);
    }
    return $roots;
}

function dmd_mu_current_module_version($moduleDir, $expectedId, &$errors) {
    $manifestFile = rtrim($moduleDir, '/\\') . '/dmd_module.json';
    if (!is_file($manifestFile)) {
        return '';
    }
    $manifest = dmd_module_contract_read_json($manifestFile);
    if (!is_array($manifest)) {
        $errors[] = 'Le dmd_module.json actuellement installé pour ' . $expectedId . ' est invalide.';
        return false;
    }
    $currentId = dmd_module_contract_slug($manifest['id'] ?? '');
    if ($currentId === '' || strcasecmp($currentId, $expectedId) !== 0) {
        $errors[] = 'Le module installé dans /modules/' . $expectedId . ' déclare un ID incohérent.';
        return false;
    }
    $version = trim((string)($manifest['version'] ?? ''));
    if ($version !== '' && !preg_match('~^\d+(?:\.\d+){1,3}(?:[-+][0-9A-Za-z.-]+)?$~', $version)) {
        $errors[] = 'La version actuellement installée de ' . $expectedId . ' est invalide.';
        return false;
    }
    return $version;
}

function dmd_mu_upsert_list($list, $manifest) {
    if (!is_array($list)) {
        $list = array();
    }
    $id = (string)$manifest['id'];
    $found = false;

    foreach ($list as $index => $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $entryId = dmd_module_contract_slug($entry['id'] ?? '');
        if (strcasecmp($entryId, $id) !== 0) {
            continue;
        }
        $entry['id'] = $id;
        $entry['name'] = (string)$manifest['name'];
        $entry['description'] = (string)($manifest['description'] ?? ($entry['description'] ?? ''));
        $entry['storage_scope'] = (string)$manifest['storage_scope'];
        $entry['default_access'] = (string)$manifest['default_access'];
        $entry['version'] = (string)$manifest['version'];
        $entry['min_domydesk'] = (string)$manifest['min_domydesk'];
        if (empty($entry['icon'])) {
            $entry['icon'] = 'modules/' . $id . '/icon.png';
        }
        if (!array_key_exists('enabled', $entry)) {
            $entry['enabled'] = false;
        }
        $list[$index] = $entry;
        $found = true;
        break;
    }

    if (!$found) {
        $list[] = array(
            'id' => $id,
            'name' => (string)$manifest['name'],
            'description' => (string)($manifest['description'] ?? ''),
            'icon' => 'modules/' . $id . '/icon.png',
            'enabled' => false,
            'storage_scope' => (string)$manifest['storage_scope'],
            'default_access' => (string)$manifest['default_access'],
            'version' => (string)$manifest['version'],
            'min_domydesk' => (string)$manifest['min_domydesk'],
        );
    }
    return $list;
}

function dmd_mu_restore_list($listFile, $raw) {
    if ($raw === null) {
        @unlink($listFile);
        return;
    }
    @file_put_contents($listFile, $raw, LOCK_EX);
    @chmod($listFile, 0664);
}

function dmd_mu_apply_contract_zip($zipPath, $baseDir, $listFile, $catalogExpectedId = '') {
    $result = array(
        'success' => false,
        'message' => '',
        'modules' => array(),
        'files' => 0,
        'versions' => array(),
        'reinstalled' => array(),
    );
    $errors = array();
    $token = date('YmdHis') . '-' . substr(bin2hex(random_bytes(4)), 0, 8);
    $stageDir = rtrim($baseDir, '/\\') . '/data/updates/stage-' . $token;
    $modulesDir = rtrim($baseDir, '/\\') . '/modules';

    if (!dmd_mu_safe_extract_zip($zipPath, $stageDir, $errors)) {
        $result['message'] = implode(' ', $errors);
        dmd_mu_remove_dir($stageDir);
        return $result;
    }

    $roots = dmd_mu_package_roots($stageDir, $errors);
    if ($roots === false) {
        $result['message'] = implode(' ', $errors);
        dmd_mu_remove_dir($stageDir);
        return $result;
    }

    $packages = array();
    $seen = array();
    foreach ($roots as $rootInfo) {
        $manifestErrors = array();
        $manifest = dmd_module_contract_validate_manifest(
            $rootInfo['root'],
            $rootInfo['expected_id'],
            $baseDir,
            $manifestErrors
        );
        if ($manifest === false) {
            foreach ($manifestErrors as $e) {
                $errors[] = $e;
            }
            continue;
        }

        $id = (string)$manifest['id'];
        if (isset($seen[strtolower($id)])) {
            $errors[] = 'Le ZIP contient deux fois le module ' . $id . '.';
            continue;
        }
        $seen[strtolower($id)] = true;

        if ($catalogExpectedId !== '' && count($roots) === 1) {
            $expected = dmd_module_contract_slug($catalogExpectedId);
            if ($expected !== '' && strcasecmp($expected, $id) !== 0) {
                $errors[] = 'Le catalogue annonce « ' . $expected . ' » mais le ZIP contient « ' . $id . ' ».';
                continue;
            }
        }

        if (empty($manifest['data_policy']['preserve_on_update'])) {
            $errors[] = 'Mise à jour refusée pour ' . $id . ' : data_policy.preserve_on_update=false nécessite une migration destructive explicite, non autorisée par cet updater.';
            continue;
        }

        $target = $modulesDir . '/' . $id;
        if (!is_dir($target) || is_link($target)) {
            $errors[] = 'Le module ' . $id . ' n’est pas installé normalement dans /modules/' . $id . '. Utilise le Market pour une première installation.';
            continue;
        }

        $currentVersion = dmd_mu_current_module_version($target, $id, $errors);
        if ($currentVersion === false) {
            continue;
        }
        if ($currentVersion !== '' && version_compare((string)$manifest['version'], $currentVersion, '<')) {
            $errors[] = 'Downgrade refusé pour ' . $id . ' : installé ' . $currentVersion . ', ZIP ' . $manifest['version'] . '.';
            continue;
        }

        $packages[$id] = array(
            'root' => $rootInfo['root'],
            'manifest' => $manifest,
            'target' => $target,
            'current_version' => $currentVersion,
            'pending' => $modulesDir . '/.updating-' . $id . '-' . $token,
            'backup' => $modulesDir . '/.backup-' . $id . '-' . $token,
            'runtime_created' => '',
        );
    }

    if ($errors) {
        $result['message'] = implode(' ', $errors);
        dmd_mu_remove_dir($stageDir);
        return $result;
    }
    if (!$packages) {
        $result['message'] = 'Aucun module valide à mettre à jour.';
        dmd_mu_remove_dir($stageDir);
        return $result;
    }

    /* modules/list.json est vérifié avant la moindre modification. */
    $listRaw = is_file($listFile) ? @file_get_contents($listFile) : null;
    $listData = array();
    if ($listRaw !== null && trim((string)$listRaw) !== '') {
        $decoded = json_decode((string)$listRaw, true);
        if (!is_array($decoded)) {
            $result['message'] = 'Mise à jour annulée : modules/list.json est invalide. Aucun module n’a été modifié.';
            dmd_mu_remove_dir($stageDir);
            return $result;
        }
        $listData = $decoded;
    }

    /* Prépare toutes les nouvelles versions hors ligne. */
    foreach ($packages as $id => &$package) {
        dmd_mu_remove_dir($package['pending']);
        dmd_mu_remove_dir($package['backup']);
        $copyErrors = array();
        if (!dmd_mu_copy_tree($package['root'], $package['pending'], $copyErrors)) {
            foreach ($packages as $cleanup) {
                dmd_mu_remove_dir($cleanup['pending']);
            }
            $result['message'] = 'Préparation annulée pour ' . $id . ' : ' . implode(' ', $copyErrors);
            dmd_mu_remove_dir($stageDir);
            unset($package);
            return $result;
        }
    }
    unset($package);

    /* Prépare le runtime/migration avant bascule, sans écraser une donnée existante. */
    foreach ($packages as $id => &$package) {
        $runtimeErrors = array();
        $created = '';
        if (!dmd_module_contract_prepare_runtime($baseDir, $package['manifest'], $package['target'], $created, $runtimeErrors)) {
            foreach ($packages as $cleanup) {
                dmd_mu_remove_dir($cleanup['pending']);
                if (!empty($cleanup['runtime_created'])) {
                    dmd_module_contract_cleanup_created_runtime($cleanup['runtime_created']);
                }
            }
            if ($created !== '') {
                dmd_module_contract_cleanup_created_runtime($created);
            }
            $result['message'] = 'Runtime refusé pour ' . $id . ' : ' . implode(' ', $runtimeErrors);
            dmd_mu_remove_dir($stageDir);
            unset($package);
            return $result;
        }
        $package['runtime_created'] = $created;
    }
    unset($package);

    /* Sauvegarde toutes les versions installées. */
    $backedUp = array();
    foreach ($packages as $id => $package) {
        if (!@rename($package['target'], $package['backup'])) {
            foreach (array_reverse($backedUp) as $restoreId) {
                @rename($packages[$restoreId]['backup'], $packages[$restoreId]['target']);
            }
            foreach ($packages as $cleanup) {
                dmd_mu_remove_dir($cleanup['pending']);
                if (!empty($cleanup['runtime_created'])) {
                    dmd_module_contract_cleanup_created_runtime($cleanup['runtime_created']);
                }
            }
            $result['message'] = 'Mise à jour annulée : impossible de mettre ' . $id . ' en sécurité. Les modules précédents ont été restaurés.';
            dmd_mu_remove_dir($stageDir);
            return $result;
        }
        $backedUp[] = $id;
    }

    /* Active toutes les nouvelles versions. */
    $activated = array();
    foreach ($packages as $id => $package) {
        if (!@rename($package['pending'], $package['target'])) {
            foreach (array_reverse($activated) as $activeId) {
                dmd_mu_remove_dir($packages[$activeId]['target']);
            }
            foreach (array_reverse($backedUp) as $restoreId) {
                if (is_dir($packages[$restoreId]['backup'])) {
                    @rename($packages[$restoreId]['backup'], $packages[$restoreId]['target']);
                }
            }
            foreach ($packages as $cleanup) {
                dmd_mu_remove_dir($cleanup['pending']);
                if (!empty($cleanup['runtime_created'])) {
                    dmd_module_contract_cleanup_created_runtime($cleanup['runtime_created']);
                }
            }
            $result['message'] = 'Mise à jour annulée pendant l’activation de ' . $id . '. Toutes les anciennes versions ont été restaurées.';
            dmd_mu_restore_list($listFile, $listRaw);
            dmd_mu_remove_dir($stageDir);
            return $result;
        }
        $activated[] = $id;
    }

    /* Met à jour list.json seulement après activation complète. */
    $newList = $listData;
    foreach ($packages as $package) {
        $newList = dmd_mu_upsert_list($newList, $package['manifest']);
    }

    if (!dmd_mu_write_json_atomic($listFile, $newList)) {
        foreach (array_reverse($activated) as $id) {
            dmd_mu_remove_dir($packages[$id]['target']);
        }
        foreach (array_reverse($backedUp) as $id) {
            if (is_dir($packages[$id]['backup'])) {
                @rename($packages[$id]['backup'], $packages[$id]['target']);
            }
        }
        foreach ($packages as $cleanup) {
            dmd_mu_remove_dir($cleanup['pending']);
            if (!empty($cleanup['runtime_created'])) {
                dmd_module_contract_cleanup_created_runtime($cleanup['runtime_created']);
            }
        }
        dmd_mu_restore_list($listFile, $listRaw);
        $result['message'] = 'Mise à jour annulée : modules/list.json n’a pas pu être enregistré. Toutes les anciennes versions ont été restaurées.';
        dmd_mu_remove_dir($stageDir);
        return $result;
    }

    foreach ($packages as $id => $package) {
        dmd_mu_remove_dir($package['backup']);
        $result['modules'][] = $id;
        $result['files'] += count((array)$package['manifest']['package']['files']) + 1;
        $result['versions'][$id] = array(
            'before' => $package['current_version'] !== '' ? $package['current_version'] : 'legacy',
            'after' => (string)$package['manifest']['version'],
        );
        if ($package['current_version'] !== '' && version_compare((string)$package['manifest']['version'], $package['current_version'], '==')) {
            $result['reinstalled'][] = $id;
        }
    }

    sort($result['modules'], SORT_NATURAL | SORT_FLAG_CASE);
    dmd_mu_remove_dir($stageDir);
    $result['success'] = true;
    $result['message'] = 'Mise à jour appliquée après validation complète du contrat.';
    return $result;
}

function dmd_mu_append_log($file, $meta, $email, $source, $apply) {
    $logs = dmd_mu_read_json($file, array());
    if (!is_array($logs)) {
        $logs = array();
    }
    $meta = dmd_mu_clean_item($meta);
    $meta['installed_at'] = date('Y-m-d H:i:s');
    $meta['installed_by'] = $email;
    $meta['source'] = $source;
    $meta['modules'] = array_values($apply['modules'] ?? array());
    $meta['module_versions'] = $apply['versions'] ?? array();
    $meta['files_replaced'] = (int)($apply['files'] ?? 0);
    $logs[] = $meta;
    return dmd_mu_write_json_atomic($file, $logs);
}

function dmd_mu_notify_modules($modules, $title) {
    foreach ($modules as $moduleId) {
        dmd_notify_module_users(
            $moduleId,
            'module_updated',
            'Un module que vous utilisez a été mis à jour',
            $title . ' a été installé sur DoMyDesk.',
            array('level' => 'info')
        );
    }
}

$messages = array();
$errors = array();
$catalogRawOverride = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string)($_POST['csrf_token'] ?? ''))) {
        $errors[] = 'Session expirée. Recharge la page.';
    } else {
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'refresh_catalog') {
            $refreshError = '';
            $refreshOk = false;
            $catalogRawOverride = dmd_source_load_raw($baseDir, 'updates_modules', true, $refreshError, $refreshOk);
            if ($refreshOk) {
                $messages[] = 'Catalogue des updates modules rafraîchi directement depuis GitHub.';
            } else {
                $errors[] = 'Rafraîchissement GitHub impossible' . ($refreshError !== '' ? ' : ' . $refreshError : '.') . ' Le dernier cache valide est conservé.';
            }

        } elseif ($action === 'github') {
            $metaRaw = base64_decode((string)($_POST['meta'] ?? ''), true);
            $meta = $metaRaw !== false ? json_decode($metaRaw, true) : array();
            $meta = is_array($meta) ? dmd_mu_clean_item($meta) : array();

            if (empty($meta['url'])) {
                $errors[] = 'Lien ZIP manquant.';
            } else {
                $tmp = dmd_mu_temp_dir($updatesDir);
                $zipPath = $tmp . '/module.zip';
                $why = '';

                if (!dmd_mu_download($meta['url'], $zipPath, $why)) {
                    $errors[] = 'Téléchargement impossible : ' . $why;
                } else {
                    $apply = dmd_mu_apply_contract_zip($zipPath, $baseDir, $listFile, (string)($meta['module_id'] ?? ''));
                    if (!empty($apply['success'])) {
                        dmd_mu_append_log($logsFile, $meta, $email, 'github', $apply);
                        dmd_system_log(
                            'module_update_installed',
                            implode(',', $apply['modules']),
                            'success',
                            'Mise à jour de module appliquée depuis GitHub après validation du contrat 1.2.0.',
                            array('titre' => $meta['titre'], 'modules' => $apply['modules'], 'versions' => $apply['versions'], 'files' => $apply['files'])
                        );
                        dmd_mu_notify_modules($apply['modules'], $meta['titre']);
                        $messages[] = $meta['titre'] . ' : ' . count($apply['modules']) . ' module(s), ' . (int)$apply['files'] . ' fichier(s), contrat 1.2.0 validé.';
                    } else {
                        $errors[] = $apply['message'];
                        dmd_system_log('module_update_failed', (string)($meta['titre'] ?? ''), 'error', $apply['message']);
                    }
                }
                dmd_mu_remove_dir($tmp);
            }

        } elseif ($action === 'manual') {
            if (empty($_FILES['update_zip']['tmp_name']) || ($_FILES['update_zip']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                $errors[] = 'Aucun ZIP valide envoyé.';
            } elseif (strtolower(pathinfo((string)$_FILES['update_zip']['name'], PATHINFO_EXTENSION)) !== 'zip') {
                $errors[] = 'Le fichier doit être un ZIP.';
            } else {
                $tmp = dmd_mu_temp_dir($updatesDir);
                $zipPath = $tmp . '/module.zip';

                if (!@move_uploaded_file($_FILES['update_zip']['tmp_name'], $zipPath)) {
                    $errors[] = 'Upload impossible.';
                } else {
                    $apply = dmd_mu_apply_contract_zip($zipPath, $baseDir, $listFile, '');
                    $meta = array(
                        'titre' => pathinfo((string)$_FILES['update_zip']['name'], PATHINFO_FILENAME),
                        'soustitre' => 'ZIP manuel',
                        'date' => date('Y-m-d'),
                        'update' => 'Module',
                        'description' => 'Mise à jour de module installée depuis un ZIP manuel.',
                        'url' => '',
                        'module_id' => '',
                    );

                    if (!empty($apply['success'])) {
                        dmd_mu_append_log($logsFile, $meta, $email, 'manual', $apply);
                        dmd_system_log(
                            'module_update_installed_manual',
                            implode(',', $apply['modules']),
                            'success',
                            'Mise à jour de module appliquée depuis un ZIP manuel après validation du contrat 1.2.0.',
                            array('modules' => $apply['modules'], 'versions' => $apply['versions'], 'files' => $apply['files'])
                        );
                        dmd_mu_notify_modules($apply['modules'], $meta['titre']);
                        $messages[] = 'ZIP appliqué : ' . implode(', ', $apply['modules']) . ' — contrat 1.2.0 validé.';
                    } else {
                        $errors[] = $apply['message'];
                        dmd_system_log('module_update_failed_manual', (string)$meta['titre'], 'error', $apply['message']);
                    }
                }
                dmd_mu_remove_dir($tmp);
            }
        }
    }
}

$catalogError = $moduleUpdatesSourceError;
$catalogRefreshed = false;
$catalogRaw = $catalogRawOverride;
if ($catalogRaw === null) {
    $catalogRaw = dmd_source_load_raw($baseDir, 'updates_modules', false, $catalogError, $catalogRefreshed);
}
$catalog = dmd_mu_catalog($catalogRaw, $catalogError);
$installed = array_reverse(array_values(array_filter(dmd_mu_read_json($logsFile, array()), 'is_array')));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mise à jour des modules</title>
<link rel="stylesheet" href="<?= dmd_mu_h($themeHref) ?>">
<style>
body{padding:0!important;background:transparent!important}.mu-page{padding:14px;color:var(--text-color)}
.mu-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.mu-head h1{margin:0;color:var(--title-color);font-size:1.35rem}.mu-head p{margin:4px 0 0;color:var(--muted-color)}
.mu-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,320px));gap:10px;justify-content:start;align-items:start}.mu-card,.mu-section{background:var(--card-bg);border:1px solid var(--border-color);border-radius:var(--radius,14px);padding:12px}.mu-card{min-height:0}.mu-card h3,.mu-section h2{margin:0 0 5px;color:var(--title-color)}.mu-card h3{font-size:1rem}.mu-meta{color:var(--muted-color);font-size:.8rem;margin-bottom:6px}.mu-desc{line-height:1.35;font-size:.88rem}.mu-actions{display:flex;justify-content:flex-end;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}.mu-msg{padding:10px 12px;border:1px solid var(--border-color);border-radius:var(--radius,12px);background:var(--panel-bg);margin-bottom:10px}.mu-error{border-color:var(--danger-color)}.mu-ok{border-color:var(--success-color)}
.mu-note{color:var(--muted-color);font-size:.88rem}.mu-history{margin-top:14px}.mu-history-item{display:grid;grid-template-columns:1fr auto;gap:8px;padding:9px 0;border-bottom:1px solid var(--border-color)}input[type=file]{width:100%;box-sizing:border-box}.mu-badge{display:inline-block;padding:3px 7px;border:1px solid var(--border-color);border-radius:999px;font-size:.78rem}
@media(max-width:700px){.mu-head{display:block}.mu-grid{grid-template-columns:1fr}.mu-history-item{grid-template-columns:1fr}.mu-actions{justify-content:stretch}.mu-actions button{width:100%}}
</style>
<?php require_once $baseDir . '/core/dmd_theme_assets.php'; echo dmd_theme_extra_links($baseDir, '../theme', $theme, 'module_updates'); ?>
</head>
<body>
<div class="mu-page">
  <div class="mu-head">
    <div><h1>Mise à jour des modules</h1></div>
    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= dmd_mu_h($csrf) ?>">
      <input type="hidden" name="action" value="refresh_catalog">
      <button type="submit" title="Rafraîchir immédiatement depuis GitHub">↻ Rafraîchir</button>
    </form>
  </div>
  <?php foreach ($messages as $msg): ?><div class="mu-msg mu-ok"><?= dmd_mu_h($msg) ?></div><?php endforeach; ?>
  <?php foreach ($errors as $err): ?><div class="mu-msg mu-error"><?= dmd_mu_h($err) ?></div><?php endforeach; ?>

  <section class="mu-section">
    <h2>Catalogue GitHub</h2>
    <p></p>
    <?php if ($catalogError !== ''): ?><div class="mu-msg mu-error"><?= dmd_mu_h($catalogError) ?></div><?php endif; ?>
    <?php if (!$catalog): ?><p class="mu-note">Aucune mise à jour disponible.</p><?php else: ?>
      <div class="mu-grid">
      <?php foreach ($catalog as $item): $enc=base64_encode(json_encode($item, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>
        <article class="mu-card">
          <h3><?= dmd_mu_h($item['titre']) ?></h3>
          <div class="mu-meta"><?= dmd_mu_h($item['soustitre']) ?><?= $item['date']!==''?' · '.dmd_mu_h($item['date']):'' ?></div>
          <div class="mu-desc"><?= nl2br(dmd_mu_h($item['description'])) ?></div>
          <form method="post" class="mu-actions" onsubmit="return confirm('Installer cette mise à jour de module ?');">
            <input type="hidden" name="csrf_token" value="<?= dmd_mu_h($csrf) ?>">
            <input type="hidden" name="action" value="github"><input type="hidden" name="meta" value="<?= dmd_mu_h($enc) ?>">
            <button type="submit">Mettre à jour</button>
          </form>
        </article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
  <section class="mu-section mu-history">
    <h2>Historique des mises à jour modules</h2>
    <?php if (!$installed): ?><p class="mu-note">Aucune mise à jour de module enregistrée.</p><?php else: ?>
      <?php foreach ($installed as $item): ?>
        <div class="mu-history-item"><div><strong><?= dmd_mu_h($item['titre'] ?? 'Update module') ?></strong><div class="mu-meta"><?= dmd_mu_h(implode(', ', $item['modules'] ?? array())) ?> · <?= (int)($item['files_replaced'] ?? 0) ?> fichier(s)</div></div><div class="mu-meta"><?= dmd_mu_h($item['installed_at'] ?? '') ?><br><?= dmd_mu_h($item['installed_by'] ?? '') ?></div></div>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>
</div>
</body>
</html>
