<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 0);

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../../login.php');
    exit;
}

$baseDir = realpath(__DIR__ . '/../../');

if ($baseDir === false) {
    http_response_code(500);
    exit('Erreur : dossier DoMyDesk introuvable.');
}

require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_sources.php';
$profilesDir = $baseDir . '/users/profiles/';
$userDir = $profilesDir . $email . '/';
$profileFile = dmd_profile_path($email, true);

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);

if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../../login.php');
    exit;
}

$roleSystemReal = strtolower(trim((string)($profileData['role_system'] ?? 'user')));

// Le Market est réservé aux rôles système admin et superadmin.
// Si un utilisateur non autorisé tente d'y accéder, on renvoie la fenêtre
// principale DoMyDesk vers le dashboard (et non le dashboard dans la popup).
if (!in_array($roleSystemReal, ['admin', 'superadmin'], true)) {
    $dashboardUrl = '../../dashboard.php';
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Redirection</title></head><body>'
        . '<script>window.top.location.href=' . json_encode($dashboardUrl, JSON_UNESCAPED_SLASHES) . ';</script>'
        . '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') . '"></noscript>'
        . '</body></html>';
    exit;
}

$isAdmin = true;
if (empty($_SESSION['csrf_marketmodules'])) {
    $_SESSION['csrf_marketmodules'] = bin2hex(random_bytes(32));
}

function dmd_check_csrf_marketmodules(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    $token = $_POST['csrf_token'] ?? '';

    if (!is_string($token) || !hash_equals($_SESSION['csrf_marketmodules'] ?? '', $token)) {
        http_response_code(403);
        exit('Action refusée : formulaire expiré ou invalide.');
    }
}

dmd_check_csrf_marketmodules();

$theme = 'default';
$themeJson = $userDir . 'theme.json';

if (is_file($themeJson)) {
    $td = json_decode(@file_get_contents($themeJson), true) ?: [];
    if (!empty($td['theme']) && is_file($baseDir . "/theme/{$td['theme']}/style.css")) {
        $theme = basename($td['theme']);
    }
}

$uploadDir  = rtrim($baseDir, '/') . '/uploads/';
$modulesDir = rtrim($baseDir, '/') . '/modules/';
$listFile   = $modulesDir . 'list.json';
$cfgFile    = rtrim($baseDir, '/') . '/data/market/marketcfg.json';

@mkdir($uploadDir, 0775, true);
@mkdir(dirname($cfgFile), 0775, true);

$messages = [];

function slugify($s) {
    $s = preg_replace('~[^a-zA-Z0-9._-]+~', '-', (string)$s);
    return trim($s, '-');
}

function load_json($path) {
    $t = @file_get_contents($path);
    if ($t === false || trim($t) === '') {
        return [];
    }

    $j = json_decode($t, true);
    return is_array($j) ? $j : [];
}

function save_json($path, $data) {
    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @chmod($path, 0664);
}


function dmd_read_module_manifest_from_dir($moduleDir, $expectedId, &$messages) {
    $expectedId = slugify($expectedId);
    $manifestFile = rtrim($moduleDir, '/\\') . '/dmd_module.json';

    if (!is_file($manifestFile)) {
        return [
            'id' => $expectedId,
            'storage_scope' => 'legacy',
            'default_access' => 'controlled'
        ];
    }

    $manifest = load_json($manifestFile);

    if (empty($manifest) || !is_array($manifest)) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ dmd_module.json invalide.'
        ];
        return false;
    }

    $manifestId = slugify($manifest['id'] ?? '');

    if ($manifestId === '' || strcasecmp($manifestId, $expectedId) !== 0) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Le champ id de dmd_module.json doit correspondre exactement au nom du module : <strong>'
                . htmlspecialchars($expectedId, ENT_QUOTES, 'UTF-8') . '</strong>.'
        ];
        return false;
    }

    $scope = strtolower(trim((string)($manifest['storage_scope'] ?? 'legacy')));
    if (!in_array($scope, ['system', 'user', 'hybrid', 'legacy'], true)) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ storage_scope invalide dans dmd_module.json.'
        ];
        return false;
    }

    $defaultAccess = strtolower(trim((string)($manifest['default_access'] ?? 'controlled')));
    if (!in_array($defaultAccess, ['controlled', 'everyone'], true)) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ default_access invalide dans dmd_module.json.'
        ];
        return false;
    }

    $manifest['id'] = $expectedId;
    $manifest['storage_scope'] = $scope;
    $manifest['default_access'] = $defaultAccess;

    return $manifest;
}

function dmd_upsert_module_list_from_manifest($list, $id, $manifest, $sourceDescription) {
    if (!is_array($list)) {
        $list = [];
    }

    $id = slugify($id);
    $found = false;

    foreach ($list as $index => $entry) {
        if (!is_array($entry) || strcasecmp(slugify($entry['id'] ?? ''), $id) !== 0) {
            continue;
        }

        $entry['id'] = $id;
        $entry['name'] = trim((string)($manifest['name'] ?? ($entry['name'] ?? ucfirst($id))));
        $entry['description'] = trim((string)($manifest['description'] ?? ($entry['description'] ?? $sourceDescription)));
        $entry['storage_scope'] = $manifest['storage_scope'] ?? ($entry['storage_scope'] ?? 'legacy');
        $entry['default_access'] = $manifest['default_access'] ?? ($entry['default_access'] ?? 'controlled');

        if (empty($entry['icon'])) {
            $entry['icon'] = "modules/$id/icon.png";
        }

        if (!array_key_exists('enabled', $entry)) {
            $entry['enabled'] = false;
        }

        $list[$index] = $entry;
        $found = true;
        break;
    }

    if (!$found) {
        $list[] = [
            'id' => $id,
            'name' => trim((string)($manifest['name'] ?? ucfirst($id))),
            'description' => trim((string)($manifest['description'] ?? $sourceDescription)),
            'icon' => "modules/$id/icon.png",
            'enabled' => false,
            'storage_scope' => $manifest['storage_scope'] ?? 'legacy',
            'default_access' => $manifest['default_access'] ?? 'controlled'
        ];
    }

    return $list;
}

function rrmdir_recursive($dir) {
    if (is_link($dir)) {
        @unlink($dir);
        return;
    }

    if (!is_dir($dir)) {
        return;
    }

    foreach (array_diff(scandir($dir), ['.', '..']) as $item) {
        $path = rtrim($dir, '/\\') . '/' . $item;

        if (is_link($path)) {
            @unlink($path);
        } elseif (is_dir($path)) {
            rrmdir_recursive($path);
        } else {
            @chmod($path, 0664);
            @unlink($path);
        }
    }

    @chmod($dir, 0775);
    @rmdir($dir);
}


function dmd_safe_extract_zip(ZipArchive $zip, string $extractDir, array &$messages): bool {
    @mkdir($extractDir, 0775, true);

    $extractReal = realpath($extractDir);
    if ($extractReal === false) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Dossier d’extraction invalide.'
        ];
        return false;
    }

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);

        if ($name === false || $name === '') {
            continue;
        }

        $name = str_replace('\\', '/', $name);

        if (
            substr($name, 0, 1) === '/' ||
            preg_match('~(^|/)\.\.(/|$)~', $name) ||
            preg_match('~^[a-zA-Z]:/~', $name)
        ) {
            $messages[] = [
                'type' => 'error',
                'text' => '❌ ZIP refusé : chemin dangereux détecté.'
            ];
            return false;
        }
    }

    if (!$zip->extractTo($extractDir)) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Extraction ZIP impossible.'
        ];
        return false;
    }

    $rii = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($extractDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($rii as $f) {
        @chmod($f->getPathname(), $f->isDir() ? 0775 : 0664);
    }

    @chmod($extractDir, 0775);

    return true;
}

function domyco_sync_after_market_action($baseDir, &$messages) {
    $syncFile = rtrim($baseDir, '/') . '/data/domyco_sync.php';

    if (!is_file($syncFile)) {
        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Sync DomyCo impossible : data/domyco_sync.php introuvable.'
        ];
        return false;
    }

    $beforeLevel = ob_get_level();

    try {
        ob_start();
        require_once $syncFile;

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        if (!function_exists('domyco_sync_register')) {
            $messages[] = [
                'type' => 'error',
                'text' => '⚠️ Sync DomyCo impossible : fonction domyco_sync_register introuvable.'
            ];
            return false;
        }

        ob_start();
        $result = domyco_sync_register($baseDir);

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        if (!empty($result['success'])) {
            $messages[] = [
                'type' => 'success',
                'text' => '✅ Synchronisation DomyCo Register effectuée.'
            ];
            return true;
        }

        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Sync DomyCo échouée. Voir data/domyco_sync_last.json.'
        ];

        return false;

    } catch (Throwable $e) {
        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Erreur sync DomyCo : ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')
        ];

        return false;
    }
}

function remove_module_from_user_json_value($value, $idsToRemove, &$changed) {
    if (!is_array($value)) {
        return $value;
    }

    $isList = array_keys($value) === range(0, count($value) - 1);

    if ($isList) {
        $filtered = [];

        foreach ($value as $entry) {
            if (is_array($entry)) {
                $entryId = strtolower(slugify($entry['id'] ?? ''));

                if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
                    $changed = true;
                    continue;
                }
            }

            $filtered[] = $entry;
        }

        return $filtered;
    }

    if (isset($value['modules']) && is_array($value['modules'])) {
        $filtered = [];

        foreach ($value['modules'] as $entry) {
            if (is_array($entry)) {
                $entryId = strtolower(slugify($entry['id'] ?? ''));

                if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
                    $changed = true;
                    continue;
                }
            }

            $filtered[] = $entry;
        }

        $value['modules'] = $filtered;
    }

    if (isset($value['id'])) {
        $entryId = strtolower(slugify($value['id'] ?? ''));

        if ($entryId !== '' && in_array($entryId, $idsToRemove, true)) {
            $changed = true;
            return null;
        }
    }

    return $value;
}

function remove_module_from_users($baseDir, $moduleId, $moduleFolder) {
    $profilesDir = rtrim($baseDir, '/') . '/users/profiles/';

    if (!is_dir($profilesDir)) {
        return;
    }

    $idsToRemove = array_values(array_unique(array_filter([
        strtolower(slugify($moduleId)),
        strtolower(slugify($moduleFolder))
    ])));

    foreach (scandir($profilesDir) as $profileFolder) {
        if ($profileFolder === '.' || $profileFolder === '..') {
            continue;
        }

        $profileDir = $profilesDir . $profileFolder . '/';

        if (!is_dir($profileDir)) {
            continue;
        }

        foreach (glob($profileDir . '*.json') ?: [] as $jsonFile) {
            $fileName = basename($jsonFile);

            if (in_array($fileName, ['profile.json', 'theme.json', 'avatar.json'], true)) {
                continue;
            }

            $json = load_json($jsonFile);
            if (!is_array($json)) {
                continue;
            }

            $changed = false;
            $newJson = remove_module_from_user_json_value($json, $idsToRemove, $changed);

            if ($changed && $newJson !== null) {
                save_json($jsonFile, $newJson);
            }
        }
    }
}

function dmd_delete_file_or_directory(string $path): bool {
    if (is_link($path) || is_file($path)) {
        @chmod($path, 0664);
        return @unlink($path);
    }

    if (is_dir($path)) {
        rrmdir_recursive($path);
        return !is_dir($path);
    }

    return false;
}

function dmd_module_manifest_for_removal($modulesDir, $moduleId, $moduleFolder): array {
    $possibleFolders = array_values(array_unique(array_filter([
        slugify($moduleFolder),
        slugify($moduleId)
    ])));

    foreach ($possibleFolders as $folder) {
        $manifestFile = rtrim($modulesDir, '/\\') . '/' . $folder . '/dmd_module.json';
        if (!is_file($manifestFile)) {
            continue;
        }

        $manifest = load_json($manifestFile);
        if (is_array($manifest) && !empty($manifest)) {
            return $manifest;
        }
    }

    return [
        'id' => slugify($moduleId ?: $moduleFolder),
        'storage_scope' => 'legacy'
    ];
}

function dmd_remove_module_persistent_files($baseDir, $moduleId, $moduleFolder, array $manifest, &$messages): int {
    $ids = array_values(array_unique(array_filter([
        slugify($moduleId),
        slugify($moduleFolder),
        slugify($manifest['id'] ?? '')
    ])));

    $scope = strtolower(trim((string)($manifest['storage_scope'] ?? 'legacy')));
    if (!in_array($scope, ['system', 'user', 'hybrid', 'legacy'], true)) {
        $scope = 'legacy';
    }

    $removed = 0;
    $baseDir = rtrim($baseDir, '/\\');

    // Données système / partagées du module.
    if (in_array($scope, ['system', 'hybrid', 'legacy'], true)) {
        foreach ($ids as $id) {
            $path = $baseDir . '/data/modules/' . $id;
            if ((is_dir($path) || is_file($path) || is_link($path)) && dmd_delete_file_or_directory($path)) {
                $removed++;
            }
        }
    }

    // Données utilisateur du module : users/profiles/<email>/<module>/
    if (in_array($scope, ['user', 'hybrid', 'legacy'], true)) {
        $profilesRoot = $baseDir . '/users/profiles';
        if (is_dir($profilesRoot)) {
            foreach (scandir($profilesRoot) ?: [] as $profileFolder) {
                if ($profileFolder === '.' || $profileFolder === '..') {
                    continue;
                }

                $profileDir = $profilesRoot . '/' . $profileFolder;
                if (!is_dir($profileDir)) {
                    continue;
                }

                foreach ($ids as $id) {
                    $path = $profileDir . '/' . $id;
                    if ((is_dir($path) || is_file($path) || is_link($path)) && dmd_delete_file_or_directory($path)) {
                        $removed++;
                    }
                }
            }
        }
    }

    // Journaux persistants selon les conventions DoMyDesk déjà utilisées.
    foreach ($ids as $id) {
        $logCandidates = [
            $baseDir . '/data/logs/' . $id,
            $baseDir . '/data/logs/' . $id . '.json',
            $baseDir . '/data/logs/' . strtolower($id),
            $baseDir . '/data/logs/' . strtolower($id) . '.json'
        ];

        foreach (array_unique($logCandidates) as $path) {
            if ((is_dir($path) || is_file($path) || is_link($path)) && dmd_delete_file_or_directory($path)) {
                $removed++;
            }
        }
    }

    // Nettoyage des références de module dans les JSON utilisateurs uniquement
    // lorsque l'utilisateur a explicitement demandé "Module + fichiers".
    remove_module_from_users($baseDir, $moduleId, $moduleFolder);

    $messages[] = [
        'type' => 'success',
        'text' => '🧹 Fichiers persistants associés supprimés : <strong>' . (int)$removed . '</strong> élément(s).'
    ];

    return $removed;
}

function remove_module_everywhere($baseDir, $modulesDir, $listFile, $moduleId, $moduleFolder, $removeFiles, &$messages) {
    $moduleId     = slugify($moduleId);
    $moduleFolder = slugify($moduleFolder ?: $moduleId);

    if ($moduleId === '' && $moduleFolder === '') {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Module invalide.'
        ];
        return false;
    }

    // Le manifest doit être lu AVANT de supprimer le code du module.
    $manifest = dmd_module_manifest_for_removal($modulesDir, $moduleId, $moduleFolder);

    $idsToRemove = array_values(array_unique(array_filter([
        strtolower($moduleId),
        strtolower($moduleFolder)
    ])));

    $deletedFolder = false;
    $removedFromList = false;

    /*
     * 1. Suppression du dossier réel du module (le code).
     *    Les données persistantes sont volontairement traitées séparément.
     */
    $possibleFolders = array_unique(array_filter([
        $moduleFolder,
        $moduleId
    ]));

    foreach ($possibleFolders as $folder) {
        $modulePath = rtrim($modulesDir, '/\\') . '/' . $folder;

        if (is_dir($modulePath) || is_link($modulePath)) {
            dmd_delete_file_or_directory($modulePath);
            if (!is_dir($modulePath) && !is_link($modulePath)) {
                $deletedFolder = true;
            }
        }
    }

    /*
     * 2. Retrait de modules/list.json.
     */
    $list = load_json($listFile);
    $newList = [];

    foreach ($list as $module) {
        if (!is_array($module)) {
            continue;
        }

        $listId   = strtolower(slugify($module['id'] ?? ''));
        $listName = strtolower(slugify($module['name'] ?? ''));
        $icon     = strtolower((string)($module['icon'] ?? ''));

        $match = false;

        foreach ($idsToRemove as $rid) {
            if ($rid === '') {
                continue;
            }

            if ($listId === $rid || $listName === $rid) {
                $match = true;
                break;
            }

            if (strpos($icon, 'modules/' . $rid . '/') !== false || strpos($icon, '/modules/' . $rid . '/') !== false) {
                $match = true;
                break;
            }
        }

        if ($match) {
            $removedFromList = true;
            continue;
        }

        $newList[] = $module;
    }

    save_json($listFile, $newList);

    /*
     * 3. Suppression optionnelle des fichiers persistants.
     *    module_only      = on conserve absolument les données attachées.
     *    module_and_files = on supprime données système, données utilisateur et logs.
     */
    if ($removeFiles) {
        dmd_remove_module_persistent_files($baseDir, $moduleId, $moduleFolder, $manifest, $messages);
    }

    if ($deletedFolder || $removedFromList) {
        $modeLabel = $removeFiles ? 'module et fichiers associés' : 'module uniquement';
        $messages[] = [
            'type' => 'success',
            'text' => '✅ <strong>' . htmlspecialchars($moduleId ?: $moduleFolder, ENT_QUOTES, 'UTF-8')
                . '</strong> supprimé (' . htmlspecialchars($modeLabel, ENT_QUOTES, 'UTF-8') . ').'
        ];

        dmd_system_log(
            'module_removed',
            $moduleId ?: $moduleFolder,
            'success',
            'Module désinstallé depuis le Market.',
            [
                'mode' => $removeFiles ? 'module_and_files' : 'module_only',
                'storage_scope' => $manifest['storage_scope'] ?? 'legacy'
            ]
        );
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => '⚠️ Aucun dossier ni entrée list.json supprimé pour <strong>'
                . htmlspecialchars($moduleId ?: $moduleFolder, ENT_QUOTES, 'UTF-8') . '</strong>.'
        ];
    }

    return true;
}

function github_to_raw($url) {
    $url = trim((string)$url);

    if ($url === '') {
        return $url;
    }

    $url = preg_replace('~\?.*$~', '', $url);

    // Une URL raw.githubusercontent.com est déjà une URL RAW valide.
    // On la conserve telle quelle, notamment le chemin /refs/heads/<branche>/.
    if (preg_match('~^https?://raw\.githubusercontent\.com/~i', $url)) {
        return $url;
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/refs/heads/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/refs/heads/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/refs/heads/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/refs/heads/{$m[3]}/{$m[4]}";
    }

    return $url;
}

function http_download($url, $dest, &$why = null) {
    $why = '';
    $url = github_to_raw($url);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $fp = fopen($dest, 'wb');

        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-Market/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 60,
        ]);

        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);

        curl_close($ch);
        fclose($fp);

        if (!$ok || $code < 200 || $code >= 300) {
            @unlink($dest);
            $why = "HTTP $code via cURL" . ($err ? " ($err)" : "");
            return false;
        }

        if (!filesize($dest)) {
            @unlink($dest);
            $why = 'Fichier vide après cURL';
            return false;
        }

        return true;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-Market/1.0\r\n",
            'timeout' => 60
        ]
    ]);

    $data = @file_get_contents($url, false, $ctx);

    if ($data === false) {
        $why = 'file_get_contents a échoué';
        return false;
    }

    if (!strlen($data)) {
        $why = 'Réponse vide';
        return false;
    }

    if (file_put_contents($dest, $data) === false) {
        $why = "Écriture impossible: $dest";
        return false;
    }

    return true;
}

function http_get_body($url, &$why = null, bool $fresh = false) {
    $why = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);

        $headers = [
            'Accept: application/vnd.github+json, application/json, text/plain, */*'
        ];

        if ($fresh) {
            $headers[] = 'Cache-Control: no-cache, no-store, max-age=0';
            $headers[] = 'Pragma: no-cache';
        }

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-Market/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
        ]);

        if ($fresh) {
            curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
            curl_setopt($ch, CURLOPT_FORBID_REUSE, true);
        }

        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);

        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ("cURL error: " . $err) : ("HTTP $code");
            return false;
        }

        return $body;
    }

    $headers = "User-Agent: DoMyDesk-Market/1.0\r\n";
    if ($fresh) {
        $headers .= "Cache-Control: no-cache, no-store, max-age=0\r\n";
        $headers .= "Pragma: no-cache\r\n";
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => $headers,
            'timeout' => 30
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);

    if ($body === false) {
        $why = 'file_get_contents a échoué (allow_url_fopen ?)';
        return false;
    }

    return $body;
}

function dmd_market_avatar_local_url(string $baseDir, string $avatarUrl): string {
    $avatarUrl = github_to_raw($avatarUrl);
    if ($avatarUrl === '') {
        return '';
    }

    $parts = parse_url($avatarUrl);
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = strtolower((string)($parts['host'] ?? ''));

    // Le Market n'accepte ici que les avatars GitHub officiels.
    if ($scheme !== 'https' || !in_array($host, ['raw.githubusercontent.com', 'github.com'], true)) {
        return '';
    }

    $path = (string)($parts['path'] ?? '');
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (!in_array($ext, ['png', 'jpg', 'jpeg', 'webp', 'gif'], true)) {
        $ext = 'png';
    }

    $cacheDir = rtrim($baseDir, '/\\') . '/data/market/avatars/';
    @mkdir($cacheDir, 0775, true);

    $fileName = hash('sha256', $avatarUrl) . '.' . $ext;
    $cacheFile = $cacheDir . $fileName;

    if (!is_file($cacheFile) || filesize($cacheFile) < 32) {
        $tmpFile = $cacheFile . '.tmp';
        $why = '';
        @unlink($tmpFile);

        if (!http_download($avatarUrl, $tmpFile, $why)) {
            @unlink($tmpFile);
            return '';
        }

        $imageInfo = @getimagesize($tmpFile);
        if ($imageInfo === false) {
            @unlink($tmpFile);
            return '';
        }

        @chmod($tmpFile, 0664);
        if (!@rename($tmpFile, $cacheFile)) {
            @unlink($tmpFile);
            return '';
        }
        @chmod($cacheFile, 0664);
    }

    return '../../data/market/avatars/' . rawurlencode($fileName);
}

$cfg = load_json($cfgFile);

/*
 * Catalogue officiel DoMyDesk : l'URL GitHub est lue dans
 * /sources/github_sources.json et le contenu est cache dans
 * /sources/listmodules.json.
 */
$catalogUrlError = '';
$catalogUrl = dmd_source_url($baseDir, 'modules', $catalogUrlError);
$catalogForceRefresh = ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['refresh_catalog']));
$catalogWhy = '';
$catalogRefreshed = false;
$catalogRaw = dmd_source_load_raw($baseDir, 'modules', $catalogForceRefresh, $catalogWhy, $catalogRefreshed);

if ($catalogForceRefresh) {
    if ($catalogRefreshed) {
        $freshDecoded = json_decode((string)$catalogRaw, true);
        $messages[] = [
            'type' => 'success',
            'text' => '✅ Catalogue modules rafraîchi directement depuis GitHub : <strong>'
                . (is_array($freshDecoded) ? count($freshDecoded) : 0) . '</strong> module(s).'
        ];
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Rafraîchissement GitHub impossible'
                . ($catalogWhy !== '' ? ' : ' . htmlspecialchars($catalogWhy, ENT_QUOTES, 'UTF-8') : '.')
                . ' Le dernier cache local valide est conservé.'
        ];
    }
}

/*
 * Installation module depuis URL
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_url'], $_POST['module_id'])) {
    $url = trim($_POST['download_url']);
    $id  = slugify($_POST['module_id']);

    if ($url && $id) {
        $zipTmp = $uploadDir . $id . '.zip';

        if (!http_download($url, $zipTmp, $why)) {
            $messages[] = [
                'type' => 'error',
                'text' => "❌ Téléchargement échoué : " . htmlspecialchars($why, ENT_QUOTES, 'UTF-8') . " — URL : " . htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
            ];
        } else {
            $zip = new ZipArchive();

            if ($zip->open($zipTmp) === true) {
                $extractDir = $modulesDir . $id . '/';

                if (dmd_safe_extract_zip($zip, $extractDir, $messages)) {
                    $zip->close();
                    @unlink($zipTmp);

                    $manifest = dmd_read_module_manifest_from_dir($extractDir, $id, $messages);

                    if ($manifest === false) {
                        rrmdir_recursive($extractDir);
                    } else {
                        $list = load_json($listFile);
                        $list = dmd_upsert_module_list_from_manifest(
                            $list,
                            $id,
                            $manifest,
                            "Module $id installé via URL"
                        );
                        save_json($listFile, $list);

                        $messages[] = [
                            'type' => 'success',
                            'text' => "✅ Module <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8')
                                . "</strong> installé — stockage : <strong>"
                                . htmlspecialchars((string)($manifest['storage_scope'] ?? 'legacy'), ENT_QUOTES, 'UTF-8')
                                . "</strong>."
                        ];
                        dmd_system_log('module_installed', $id, 'success', 'Module installé depuis le Market.', ['source' => 'url', 'storage_scope' => $manifest['storage_scope'] ?? 'legacy']);

                        domyco_sync_after_market_action($baseDir, $messages);
                    }
                } else {
                    $zip->close();
                    @unlink($zipTmp);
                    rrmdir_recursive($extractDir);
                }

            } else {
                @unlink($zipTmp);

                $messages[] = [
                    'type' => 'error',
                    'text' => "❌ Impossible d’ouvrir le ZIP pour <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . "</strong>."
                ];
            }
        }
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => "❌ Paramètres invalides pour l’installation."
        ];
    }
}

/*
 * Installation module depuis ZIP uploadé
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['module_zip'])) {
    if ($_FILES['module_zip']['error'] === UPLOAD_ERR_OK) {
        $originalName = basename((string)$_FILES['module_zip']['name']);
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        if ($ext !== 'zip') {
            $messages[] = [
                'type' => 'error',
                'text' => "❌ Le fichier envoyé doit être un ZIP."
            ];
        } else {
            $zipPath = $uploadDir . $originalName;
            $id = slugify(pathinfo($zipPath, PATHINFO_FILENAME));

            if ($id === '') {
                $messages[] = [
                    'type' => 'error',
                    'text' => "❌ Nom de ZIP invalide."
                ];
            } elseif (move_uploaded_file($_FILES['module_zip']['tmp_name'], $zipPath)) {
                @chmod($zipPath, 0664);

                $zip = new ZipArchive();

                if ($zip->open($zipPath) === true) {
                    $extractDir = $modulesDir . $id . '/';

                    if (dmd_safe_extract_zip($zip, $extractDir, $messages)) {
                        $zip->close();
                        @unlink($zipPath);

                        $manifest = dmd_read_module_manifest_from_dir($extractDir, $id, $messages);

                        if ($manifest === false) {
                            rrmdir_recursive($extractDir);
                        } else {
                            $list = load_json($listFile);
                            $list = dmd_upsert_module_list_from_manifest(
                                $list,
                                $id,
                                $manifest,
                                "Module $id ajouté manuellement"
                            );
                            save_json($listFile, $list);

                            $messages[] = [
                                'type' => 'success',
                                'text' => "✅ Module <strong>" . htmlspecialchars($id, ENT_QUOTES, 'UTF-8')
                                    . "</strong> installé depuis un ZIP — stockage : <strong>"
                                    . htmlspecialchars((string)($manifest['storage_scope'] ?? 'legacy'), ENT_QUOTES, 'UTF-8')
                                    . "</strong>."
                            ];
                            dmd_system_log('module_installed', $id, 'success', 'Module installé depuis un ZIP manuel.', ['source' => 'zip', 'storage_scope' => $manifest['storage_scope'] ?? 'legacy']);

                            domyco_sync_after_market_action($baseDir, $messages);
                        }
                    } else {
                        $zip->close();
                        @unlink($zipPath);
                        rrmdir_recursive($extractDir);
                    }

                } else {
                    @unlink($zipPath);

                    $messages[] = [
                        'type' => 'error',
                        'text' => "❌ Erreur ouverture ZIP."
                    ];
                }
            } else {
                $messages[] = [
                    'type' => 'error',
                    'text' => "❌ Échec de l’upload du ZIP."
                ];
            }
        }
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => "❌ Code d’erreur upload : " . (int)$_FILES['module_zip']['error']
        ];
    }
}

/*
 * Suppression module
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_module'])) {
    $moduleId = slugify($_POST['remove_module'] ?? '');
    $moduleFolder = slugify($_POST['remove_module_folder'] ?? $moduleId);
    $removeMode = (string)($_POST['remove_mode'] ?? '');

    if (!in_array($removeMode, ['module_only', 'module_and_files'], true)) {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Choisissez « Module uniquement » ou « Module + fichiers ».'
        ];
    } elseif ($moduleId !== '' || $moduleFolder !== '') {
        remove_module_everywhere(
            $baseDir,
            $modulesDir,
            $listFile,
            $moduleId,
            $moduleFolder,
            $removeMode === 'module_and_files',
            $messages
        );
        domyco_sync_after_market_action($baseDir, $messages);
    } else {
        $messages[] = [
            'type' => 'error',
            'text' => '❌ Module invalide.'
        ];
    }
}

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
}

/*
 * Liste des modules installés
 * Elle lit à la fois :
 * - modules/list.json
 * - dossiers présents dans modules/
 */
$installedMap = [];

$list = load_json($listFile);

foreach ($list as $module) {
    if (!is_array($module)) {
        continue;
    }

    $id = slugify($module['id'] ?? '');

    if ($id === '') {
        continue;
    }

    $folder = $id;

    if (!empty($module['icon']) && preg_match('~modules/([^/]+)/~', (string)$module['icon'], $m)) {
        $folder = slugify($m[1]);
    }

    $installedMap[$id] = [
        'id'            => $id,
        'folder'        => $folder,
        'name'          => dmd_module_display_name($id, $module['name'] ?? $id),
        'source'        => 'list',
        'icon'          => (string)($module['icon'] ?? ('modules/' . $folder . '/icon.png')),
        'version'       => (string)($module['version'] ?? ''),
        'storage_scope' => (string)($module['storage_scope'] ?? 'legacy')
    ];
}

if (is_dir($modulesDir)) {
    foreach (scandir($modulesDir) as $folder) {
        if ($folder === '.' || $folder === '..' || $folder[0] === '.') {
            continue;
        }

        if (!is_dir($modulesDir . $folder)) {
            continue;
        }

        $folderId = slugify($folder);

        if ($folderId === '' || strtolower($folderId) === 'list.json') {
            continue;
        }

        $matched = false;

        foreach ($installedMap as $k => $mod) {
            if (strtolower($mod['folder']) === strtolower($folderId) || strtolower($mod['id']) === strtolower($folderId)) {
                $installedMap[$k]['source'] = 'list+folder';
                $installedMap[$k]['folder'] = $folderId;
                $installedMap[$k]['name'] = dmd_module_display_name(
                    $folderId,
                    $installedMap[$k]['name'] ?? $folderId
                );
                if (empty($installedMap[$k]['icon'])) {
                    $installedMap[$k]['icon'] = 'modules/' . $folderId . '/icon.png';
                }
                $matched = true;
                break;
            }
        }

        if (!$matched) {
            $manifest = load_json($modulesDir . $folderId . '/dmd_module.json');
            $installedMap[$folderId] = [
                'id'            => $folderId,
                'folder'        => $folderId,
                'name'          => dmd_module_display_name($folderId, $manifest['name'] ?? $folderId),
                'source'        => 'folder',
                'icon'          => 'modules/' . $folderId . '/icon.png',
                'version'       => (string)($manifest['version'] ?? ''),
                'storage_scope' => (string)($manifest['storage_scope'] ?? 'legacy')
            ];
        }
    }
}

ksort($installedMap);
$installed = array_values($installedMap);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Market des Modules</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="marketmodules.css?v=<?= (int)(@filemtime(__DIR__ . '/marketmodules.css') ?: time()) ?>">
<?php
require_once $baseDir . '/core/dmd_theme_assets.php';
echo dmd_theme_extra_links($baseDir, '../../theme', $theme, 'marketmodules');
?>
</head>
<body>

<div class="market-wrapper container">
  <div class="market-heading">
    <div>
      <h1>Market des modules</h1>
      <p class="market-subtitle">Parcourez les modules par catégorie, installez-les et gérez les modules déjà présents.</p>
    </div>
    <div class="market-stats" aria-label="Statistiques du Market">
      <span class="market-stat"><strong id="catalogCount">0</strong> disponibles</span>
      <span class="market-stat"><strong><?= count($installed) ?></strong> installés</span>
      <form method="post" class="inline-form">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_marketmodules'], ENT_QUOTES, 'UTF-8') ?>">
        <button
          type="submit"
          name="refresh_catalog"
          value="1"
          class="market-secondary-btn"
          title="Rafraîchir la liste des modules depuis GitHub"
        >↻ Rafraîchir</button>
      </form>
    </div>
  </div>

  <?php foreach ($messages as $m): ?>
    <div class="message <?= htmlspecialchars($m['type'], ENT_QUOTES, 'UTF-8') ?>"><?= $m['text'] ?></div>
  <?php endforeach; ?>

  <?php
  $why = $catalogWhy;
  $raw = $catalogRaw;

  $marketModules = [];
  $categories = [];

  if ($raw !== false) {
      $decoded = json_decode($raw, true);
      if (is_array($decoded)) {
          foreach ($decoded as $mod) {
              if (!is_array($mod) || empty($mod['enabled'])) {
                  continue;
              }

              $cat = trim((string)($mod['category'] ?? 'Autres'));
              if ($cat === '') {
                  $cat = 'Autres';
              }

              $marketModules[] = $mod;
              $categories[$cat] = ($categories[$cat] ?? 0) + 1;
          }
      }
  }

  ksort($categories, SORT_NATURAL | SORT_FLAG_CASE);

  $installedLookup = [];
  foreach ($installed as $mod) {
      $installedLookup[strtolower(slugify($mod['id'] ?? ''))] = true;
      $installedLookup[strtolower(slugify($mod['folder'] ?? ''))] = true;
  }
  ?>

  <section class="market-section market-filter-section" aria-labelledby="categoryTitle">
    <div class="market-filter-head">
      <div>
        <h2 id="categoryTitle">Catégories</h2>
        <p class="small">Filtrez le Market par catégorie ou recherchez directement un module.</p>
      </div>

      <div class="market-search" role="search">
        <label class="market-search-label" for="moduleSearch">Rechercher</label>
        <input type="search" id="moduleSearch" placeholder="Nom, catégorie, auteur, version…" autocomplete="off">
        <button type="button" class="market-secondary-btn" id="clearModuleSearch" hidden>Effacer</button>
      </div>
    </div>

    <?php if ($raw === false): ?>
      <div class="message error">
        Impossible de charger le catalogue modules depuis /sources/listmodules.json
        <br><span class="small">Détail : <?= htmlspecialchars($why, ENT_QUOTES, 'UTF-8') ?></span>
      </div>
    <?php elseif (empty($marketModules)): ?>
      <div class="message error">Catalogue JSON invalide ou aucun module actif.</div>
    <?php else: ?>
      <div class="category-grid" id="categoryGrid" aria-label="Catégories de modules">
        <button type="button" class="category-card is-active" id="showAllCategories">
          <span class="category-icon" aria-hidden="true">T</span>
          <span class="category-copy"><strong>Toutes les catégories</strong><small><?= count($marketModules) ?> module<?= count($marketModules) > 1 ? 's' : '' ?></small></span>
        </button>
        <?php foreach ($categories as $catName => $count): ?>
          <?php $catKey = strtolower(slugify($catName)); ?>
          <button type="button" class="category-card" data-category-filter="<?= htmlspecialchars($catKey, ENT_QUOTES, 'UTF-8') ?>">
            <span class="category-icon" aria-hidden="true">▦</span>
            <span class="category-copy">
              <strong><?= htmlspecialchars($catName, ENT_QUOTES, 'UTF-8') ?></strong>
              <small><?= (int)$count ?> module<?= $count > 1 ? 's' : '' ?></small>
            </span>
          </button>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <section class="market-section market-catalog-section" aria-labelledby="catalogTitle">
    <div class="section-title-row catalog-section-head">
      <div>
        <h2 id="catalogTitle">Modules disponibles</h2>
        <p class="small"><span id="activeCategoryLabel">Toutes les catégories</span> · <span id="visibleCatalogCount"><?= count($marketModules) ?></span> affiché<?= count($marketModules) > 1 ? 's' : '' ?></p>
      </div>
<div class="market-stats compatibility-legend" aria-label="Légende des compatibilités">

    <strong class="compatibility-legend-title">
        Modules compatibles avec :
    </strong>

    <button
        type="button"
        class="market-stat compatibility-help"
        data-compatibility="mydesk"
    >
        🧰 MyDesk
    </button>

    <button
        type="button"
        class="market-stat compatibility-help"
        data-compatibility="actionhub"
    >
        ⚡ ActionHub
    </button>

    <button
        type="button"
        class="market-stat compatibility-help"
        data-compatibility="quicksession"
    >
        🚨 Quick-Session
    </button>

</div>
</div>


<div
    id="compatibilityPopover"
    class="compatibility-popover market-section"
    hidden
>
    <div class="compatibility-popover-head">
        <strong id="compatibilityPopoverTitle"></strong>

        <button
            type="button"
            class="market-modal-close"
            id="compatibilityPopoverClose"
            aria-label="Fermer"
        >
            ×
        </button>
    </div>

    <div
        id="compatibilityPopoverText"
        class="compatibility-popover-text"
    ></div>
</div>


<style>
.compatibility-legend {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    flex-wrap: wrap;
    gap: 8px;
}

.compatibility-legend-title {
    margin-right: 4px;
    white-space: nowrap;
}

.compatibility-help {
    cursor: pointer;
    font: inherit;
}

.compatibility-popover {
    position: fixed;
    z-index: 99999;
    width: min(360px, calc(100vw - 24px));
    padding: 12px;
    margin: 0;
}

.compatibility-popover-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 8px;
}

.compatibility-popover-head strong {
    font-size: 1rem;
}

.compatibility-popover-text {
    line-height: 1.45;
    font-size: .9rem;
}

@media (max-width: 700px) {
    .compatibility-legend {
        justify-content: flex-start;
    }

    .compatibility-legend-title {
        width: 100%;
    }
}
</style>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const popover = document.getElementById('compatibilityPopover');
    const popoverTitle = document.getElementById('compatibilityPopoverTitle');
    const popoverText = document.getElementById('compatibilityPopoverText');
    const closeButton = document.getElementById('compatibilityPopoverClose');

    const compatibilityInfo = {

        mydesk: {
            title: '🧰 MyDesk',
            text: 'Le module peut être ajouté directement dans MyDesk. L’utilisateur peut ainsi l’ouvrir et l’utiliser depuis son bureau personnel DoMyDesk.'
        },

        actionhub: {
            title: '⚡ ActionHub',
            text: 'Le module expose des actions utilisables depuis ActionHub. L’utilisateur peut rechercher une action et la lancer directement sans devoir ouvrir manuellement le module.'
        },

        quicksession: {
            title: '🚨 Quick-Session',
            text: 'Le module peut être intégré à une Quick-Session. Lorsqu’une session ou une procédure le nécessite, le module peut être proposé ou ouvert avec les outils nécessaires à l’intervention.'
        }

    };


    function closeCompatibilityPopover() {
        popover.hidden = true;
    }


    function openCompatibilityPopover(button) {

        const type = button.dataset.compatibility;
        const info = compatibilityInfo[type];

        if (!info) {
            return;
        }

        popoverTitle.textContent = info.title;
        popoverText.textContent = info.text;

        popover.hidden = false;

        const buttonRect = button.getBoundingClientRect();
        const popoverRect = popover.getBoundingClientRect();

        let left = buttonRect.left;
        let top = buttonRect.bottom + 8;

        /* Empêche l'info-bulle de sortir à droite */
        if (left + popoverRect.width > window.innerWidth - 12) {
            left = window.innerWidth - popoverRect.width - 12;
        }

        /* Empêche l'info-bulle de sortir à gauche */
        if (left < 12) {
            left = 12;
        }

        /* Si pas assez de place dessous, affichage au-dessus */
        if (top + popoverRect.height > window.innerHeight - 12) {
            top = buttonRect.top - popoverRect.height - 8;
        }

        popover.style.left = left + 'px';
        popover.style.top = top + 'px';
    }


    document.querySelectorAll('.compatibility-help').forEach(function (button) {

        button.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            if (
                !popover.hidden &&
                popover.dataset.current === button.dataset.compatibility
            ) {
                closeCompatibilityPopover();
                popover.dataset.current = '';
                return;
            }

            popover.dataset.current = button.dataset.compatibility;
            openCompatibilityPopover(button);
        });

    });


    closeButton.addEventListener('click', function () {
        closeCompatibilityPopover();
    });


    document.addEventListener('click', function (event) {

        if (
            !popover.hidden &&
            !popover.contains(event.target) &&
            !event.target.closest('.compatibility-help')
        ) {
            closeCompatibilityPopover();
        }

    });


    document.addEventListener('keydown', function (event) {

        if (event.key === 'Escape') {
            closeCompatibilityPopover();
        }

    });


    window.addEventListener('resize', closeCompatibilityPopover);

    window.addEventListener('scroll', closeCompatibilityPopover, true);

});
</script>

    <?php if (!empty($marketModules)): ?>
      <div class="catalog-grid" id="catalogGrid">
        <?php foreach ($marketModules as $mod): ?>
          <?php
          $id = slugify($mod['id'] ?? ($mod['name'] ?? 'module'));
          $name = trim((string)($mod['name'] ?? $id));
          $desc = trim((string)($mod['description'] ?? ''));
          $version = trim((string)($mod['version'] ?? ''));
          $author = trim((string)($mod['author'] ?? ''));
          $category = trim((string)($mod['category'] ?? 'Autres')) ?: 'Autres';
          $categoryKey = strtolower(slugify($category));
          $avatarSource = trim((string)($mod['avatar'] ?? ''));
          $avatar = dmd_market_avatar_local_url($baseDir, $avatarSource);
          $fallbackLetter = function_exists('mb_substr') ? mb_substr($name, 0, 1, 'UTF-8') : substr($name, 0, 1);
          $dl = $mod['download_url'] ?? $mod['download'] ?? $mod['url'] ?? $mod['zip'] ?? null;
          if ($dl) {
              $dl = github_to_raw($dl);
          }
          $isInstalled = isset($installedLookup[strtolower($id)]);
          ?>
          <article
            class="module-card"
            role="button"
            tabindex="0"
            data-category="<?= htmlspecialchars($categoryKey, ENT_QUOTES, 'UTF-8') ?>"
            data-module-open
            data-module-id="<?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?>"
            data-module-name="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
            data-module-description="<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>"
            data-module-category-name="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>"
            data-module-author="<?= htmlspecialchars($author, ENT_QUOTES, 'UTF-8') ?>"
            data-module-version="<?= htmlspecialchars($version, ENT_QUOTES, 'UTF-8') ?>"
            data-module-avatar="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>"
            data-module-fallback="<?= htmlspecialchars($fallbackLetter, ENT_QUOTES, 'UTF-8') ?>"
            data-module-download="<?= htmlspecialchars((string)($dl ?? ''), ENT_QUOTES, 'UTF-8') ?>"
            data-module-installed="<?= $isInstalled ? '1' : '0' ?>"
            aria-label="Ouvrir <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
          >
            <div class="module-card-head">
              <div class="module-avatar-wrap">
                <?php if ($avatar !== ''): ?>
                  <img
                    class="module-avatar"
                    src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>"
                    alt=""
                    loading="lazy"
                    onerror="this.hidden=true;this.nextElementSibling.hidden=false;"
                  >
                  <span class="module-avatar-fallback" hidden aria-hidden="true"><?= htmlspecialchars($fallbackLetter, ENT_QUOTES, 'UTF-8') ?></span>
                <?php else: ?>
                  <span class="module-avatar-fallback" aria-hidden="true"><?= htmlspecialchars($fallbackLetter, ENT_QUOTES, 'UTF-8') ?></span>
                <?php endif; ?>
              </div>

              <div class="module-title-block">
                <h3><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></h3>
              </div>
              <?php if ($isInstalled): ?><span class="module-status-badge">Installé</span><?php endif; ?>
            </div>

            <div class="module-card-info">
              <span class="module-card-category"><?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?></span>
              <?php if ($author !== ''): ?><span><?= htmlspecialchars($author, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
              <?php if ($version !== ''): ?><span>v<?= htmlspecialchars($version, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
      <div class="empty-filter" id="emptyFilter" hidden>Aucun module ne correspond à ce filtre.</div>
    <?php endif; ?>
  </section>

  <section class="market-section installed-section" aria-labelledby="installedTitle">
    <div class="section-title-row">
      <div>
        <h2 id="installedTitle">Modules installés</h2>
        <p class="small">La désinstallation vous laisse choisir si les données persistantes doivent être conservées ou supprimées.</p>
      </div>
      <span class="market-stat"><strong><?= count($installed) ?></strong> installé<?= count($installed) > 1 ? 's' : '' ?></span>
    </div>

    <?php if (!empty($installed)): ?>
      <div class="installed-grid">
        <?php foreach ($installed as $mod): ?>
          <?php
          $localIcon = '../../modules/' . rawurlencode((string)$mod['folder']) . '/icon.png';
          $versionText = trim((string)($mod['version'] ?? ''));
          ?>
          <article class="installed-card">
            <div class="installed-main">
              <img class="installed-icon" src="<?= htmlspecialchars($localIcon, ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.hidden=false;">
              <span class="installed-icon-fallback" hidden aria-hidden="true">▣</span>
              <div class="installed-copy">
                <strong><?= htmlspecialchars($mod['name'], ENT_QUOTES, 'UTF-8') ?></strong>
                <small><?= htmlspecialchars($mod['id'], ENT_QUOTES, 'UTF-8') ?></small>
              </div>
            </div>
            <div class="installed-card-footer">
              <small class="installed-version"><?php if ($versionText !== ''): ?>v<?= htmlspecialchars($versionText, ENT_QUOTES, 'UTF-8') ?><?php else: ?>&nbsp;<?php endif; ?></small>
              <button
                type="button"
                class="uninstall-btn"
                data-uninstall-open
                data-module-id="<?= htmlspecialchars($mod['id'], ENT_QUOTES, 'UTF-8') ?>"
                data-module-folder="<?= htmlspecialchars($mod['folder'], ENT_QUOTES, 'UTF-8') ?>"
                data-module-name="<?= htmlspecialchars($mod['name'], ENT_QUOTES, 'UTF-8') ?>"
              >Désinstaller</button>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p>Aucun module installé.</p>
    <?php endif; ?>
  </section>

  <section class="market-section upload-section" aria-labelledby="uploadTitle">
    <details class="manual-install">
      <summary id="uploadTitle">
        <span>Installation manuelle</span>
        <small>Ajouter un module ZIP conforme DoMyDesk</small>
      </summary>
      <div class="manual-install-body">
        <form method="post" enctype="multipart/form-data" class="upload-form">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_marketmodules'], ENT_QUOTES, 'UTF-8') ?>">
          <input type="file" name="module_zip" accept=".zip" required>
          <button type="submit">Uploader le module ZIP</button>
        </form>
      </div>
    </details>
  </section>
</div>


<div class="market-modal" id="moduleDetailsModal" hidden aria-hidden="true">
  <div class="market-modal-backdrop" data-module-close></div>

  <div class="market-modal-dialog module-detail-dialog" role="dialog" aria-modal="true" aria-labelledby="moduleDetailName">
    <div class="market-modal-head">
      <div class="module-detail-head">
        <div class="module-detail-avatar-wrap">
          <img id="moduleDetailAvatar" class="module-detail-avatar" src="" alt="" hidden>
          <span id="moduleDetailAvatarFallback" class="module-detail-avatar-fallback" aria-hidden="true">M</span>
        </div>

        <div class="module-detail-title">
          <h2 id="moduleDetailName">Module</h2>
          <div class="module-detail-meta">
            <span id="moduleDetailCategory"></span>
            <span id="moduleDetailAuthor"></span>
            <span id="moduleDetailVersion"></span>
          </div>
        </div>
      </div>

      <button type="button" class="market-modal-close" data-module-close aria-label="Fermer">×</button>
    </div>

    <div class="module-detail-body">
      <p id="moduleDetailDescription"></p>
    </div>

    <div class="market-modal-actions module-detail-actions">
      <button type="button" class="market-secondary-btn" data-module-close>Fermer</button>

      <form method="post" class="inline-form" id="moduleDetailInstallForm">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_marketmodules'], ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="download_url" id="moduleDetailDownloadUrl" value="">
        <input type="hidden" name="module_id" id="moduleDetailId" value="">
        <button type="submit" id="moduleDetailInstallButton">Installer</button>
      </form>

      <span class="installed-badge" id="moduleDetailInstalledBadge" hidden>✓ Déjà installé</span>
      <span class="small" id="moduleDetailMissingLink" hidden>Lien d’installation manquant.</span>
    </div>
  </div>
</div>

<div class="market-modal" id="uninstallModal" hidden aria-hidden="true">
  <div class="market-modal-backdrop" data-uninstall-close></div>
  <div class="market-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="uninstallTitle">
    <div class="market-modal-head">
      <div>
        <h2 id="uninstallTitle">Désinstaller le module</h2>
        <p class="small" id="uninstallModuleName"></p>
      </div>
      <button type="button" class="market-modal-close" data-uninstall-close aria-label="Fermer">×</button>
    </div>

    <form method="post" id="uninstallForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_marketmodules'], ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="remove_module" id="removeModuleId" value="">
      <input type="hidden" name="remove_module_folder" id="removeModuleFolder" value="">

      <div class="remove-options">
        <label class="remove-option">
          <input type="radio" name="remove_mode" value="module_only" required>
          <span>
            <strong>Module uniquement</strong>
            <small>Supprime le code du module et son entrée dans DoMyDesk. Les fichiers, configurations, données utilisateur et logs persistants sont conservés.</small>
          </span>
        </label>

        <label class="remove-option remove-option-danger">
          <input type="radio" name="remove_mode" value="module_and_files" required>
          <span>
            <strong>Module + fichiers</strong>
            <small>Supprime le module ainsi que ses données persistantes DoMyDesk : données système, données utilisateurs et logs associés.</small>
          </span>
        </label>
      </div>

      <div class="market-modal-actions">
        <button type="button" class="market-secondary-btn" data-uninstall-close>Annuler</button>
        <button type="submit" class="danger-btn" id="confirmUninstall" disabled>Confirmer la désinstallation</button>
      </div>
    </form>
  </div>
</div>

<script>
(function () {
  const cards = Array.from(document.querySelectorAll('.module-card'));
  const categoryButtons = Array.from(document.querySelectorAll('[data-category-filter]'));
  const showAllButton = document.getElementById('showAllCategories');
  const activeLabel = document.getElementById('activeCategoryLabel');
  const emptyFilter = document.getElementById('emptyFilter');
  const catalogCount = document.getElementById('catalogCount');
  const visibleCatalogCount = document.getElementById('visibleCatalogCount');
  const searchInput = document.getElementById('moduleSearch');
  const clearSearchButton = document.getElementById('clearModuleSearch');
  let currentCategory = '';
  let currentCategoryLabel = 'Toutes les catégories';
  let currentSearch = '';

  const detailModal = document.getElementById('moduleDetailsModal');
  const uninstallModal = document.getElementById('uninstallModal');

  if (catalogCount) {
    catalogCount.textContent = String(cards.length);
  }

  function syncBodyModalState() {
    const detailOpen = detailModal && !detailModal.hidden;
    const uninstallOpen = uninstallModal && !uninstallModal.hidden;
    document.body.classList.toggle('market-modal-open', !!(detailOpen || uninstallOpen));
  }

  function normalizedText(value) {
    return String(value || '').toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  function applyFilters() {
    let visible = 0;
    const needle = normalizedText(currentSearch.trim());

    cards.forEach(function (card) {
      const categoryMatches = !currentCategory || card.dataset.category === currentCategory;
      const haystack = normalizedText([
        card.dataset.moduleName,
        card.dataset.moduleCategoryName,
        card.dataset.moduleAuthor,
        card.dataset.moduleVersion,
        card.dataset.moduleId
      ].join(' '));
      const searchMatches = !needle || haystack.includes(needle);
      const show = categoryMatches && searchMatches;
      card.hidden = !show;
      if (show) visible++;
    });

    categoryButtons.forEach(function (button) {
      const active = !!currentCategory && button.dataset.categoryFilter === currentCategory;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });

    if (showAllButton) {
      showAllButton.classList.toggle('is-active', !currentCategory);
      showAllButton.setAttribute('aria-pressed', !currentCategory ? 'true' : 'false');
    }

    if (activeLabel) {
      activeLabel.textContent = currentCategoryLabel;
    }
    if (visibleCatalogCount) {
      visibleCatalogCount.textContent = String(visible);
    }
    if (emptyFilter) {
      emptyFilter.hidden = visible !== 0;
    }
    if (clearSearchButton) {
      clearSearchButton.hidden = !currentSearch;
    }
  }

  function applyCategory(categoryKey, label) {
    currentCategory = categoryKey || '';
    currentCategoryLabel = label || 'Toutes les catégories';
    applyFilters();
  }

  categoryButtons.forEach(function (button) {
    button.setAttribute('aria-pressed', 'false');
    button.addEventListener('click', function () {
      const labelNode = button.querySelector('strong');
      applyCategory(button.dataset.categoryFilter, labelNode ? labelNode.textContent : 'Catégorie');
    });
  });

  if (showAllButton) {
    showAllButton.setAttribute('aria-pressed', 'true');
    showAllButton.addEventListener('click', function () {
      applyCategory('', 'Toutes les catégories');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', function () {
      currentSearch = searchInput.value || '';
      applyFilters();
    });
  }

  if (clearSearchButton) {
    clearSearchButton.addEventListener('click', function () {
      currentSearch = '';
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      applyFilters();
    });
  }

  applyFilters();

  /* Détail d'un module : clic sur la petite vignette. */
  const detailName = document.getElementById('moduleDetailName');
  const detailCategory = document.getElementById('moduleDetailCategory');
  const detailAuthor = document.getElementById('moduleDetailAuthor');
  const detailVersion = document.getElementById('moduleDetailVersion');
  const detailDescription = document.getElementById('moduleDetailDescription');
  const detailAvatar = document.getElementById('moduleDetailAvatar');
  const detailAvatarFallback = document.getElementById('moduleDetailAvatarFallback');
  const detailInstallForm = document.getElementById('moduleDetailInstallForm');
  const detailDownloadUrl = document.getElementById('moduleDetailDownloadUrl');
  const detailModuleId = document.getElementById('moduleDetailId');
  const detailInstalledBadge = document.getElementById('moduleDetailInstalledBadge');
  const detailMissingLink = document.getElementById('moduleDetailMissingLink');
  let previousDetailFocus = null;

  function openModuleDetails(card) {
    if (!detailModal) return;

    previousDetailFocus = document.activeElement;

    const avatar = card.dataset.moduleAvatar || '';
    const installed = card.dataset.moduleInstalled === '1';
    const download = card.dataset.moduleDownload || '';
    const fallback = card.dataset.moduleFallback || 'M';

    detailName.textContent = card.dataset.moduleName || card.dataset.moduleId || 'Module';
    detailCategory.textContent = card.dataset.moduleCategoryName || '';
    detailAuthor.textContent = card.dataset.moduleAuthor || '';
    detailVersion.textContent = card.dataset.moduleVersion ? ('v' + card.dataset.moduleVersion) : '';
    detailDescription.textContent = card.dataset.moduleDescription || 'Aucune description disponible.';
    detailDownloadUrl.value = download;
    detailModuleId.value = card.dataset.moduleId || '';
    detailAvatarFallback.textContent = fallback;

    if (avatar) {
      detailAvatar.src = avatar;
      detailAvatar.hidden = false;
      detailAvatarFallback.hidden = true;
    } else {
      detailAvatar.removeAttribute('src');
      detailAvatar.hidden = true;
      detailAvatarFallback.hidden = false;
    }

    detailInstallForm.hidden = installed || !download;
    detailInstalledBadge.hidden = !installed;
    detailMissingLink.hidden = installed || !!download;

    detailModal.hidden = false;
    detailModal.setAttribute('aria-hidden', 'false');
    syncBodyModalState();

    const closeButton = detailModal.querySelector('[data-module-close].market-modal-close');
    if (closeButton) closeButton.focus();
  }

  function closeModuleDetails() {
    if (!detailModal) return;
    detailModal.hidden = true;
    detailModal.setAttribute('aria-hidden', 'true');
    syncBodyModalState();

    if (previousDetailFocus && typeof previousDetailFocus.focus === 'function') {
      previousDetailFocus.focus();
    }
  }

  if (detailAvatar) {
    detailAvatar.addEventListener('error', function () {
      detailAvatar.hidden = true;
      detailAvatarFallback.hidden = false;
    });
  }

  cards.forEach(function (card) {
    card.addEventListener('click', function () {
      openModuleDetails(card);
    });

    card.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        openModuleDetails(card);
      }
    });
  });

  document.querySelectorAll('[data-module-close]').forEach(function (button) {
    button.addEventListener('click', closeModuleDetails);
  });

  /* Désinstallation des modules installés. */
  const modalName = document.getElementById('uninstallModuleName');
  const removeId = document.getElementById('removeModuleId');
  const removeFolder = document.getElementById('removeModuleFolder');
  const uninstallForm = document.getElementById('uninstallForm');
  const confirmButton = document.getElementById('confirmUninstall');
  let previousFocus = null;

  function openUninstallModal(button) {
    if (!uninstallModal || !uninstallForm) return;

    previousFocus = document.activeElement;
    removeId.value = button.dataset.moduleId || '';
    removeFolder.value = button.dataset.moduleFolder || button.dataset.moduleId || '';
    modalName.textContent = button.dataset.moduleName || button.dataset.moduleId || '';

    uninstallForm.querySelectorAll('input[name="remove_mode"]').forEach(function (radio) {
      radio.checked = false;
    });

    confirmButton.disabled = true;
    uninstallModal.hidden = false;
    uninstallModal.setAttribute('aria-hidden', 'false');
    syncBodyModalState();

    const firstRadio = uninstallForm.querySelector('input[name="remove_mode"]');
    if (firstRadio) firstRadio.focus();
  }

  function closeUninstallModal() {
    if (!uninstallModal) return;
    uninstallModal.hidden = true;
    uninstallModal.setAttribute('aria-hidden', 'true');
    syncBodyModalState();

    if (previousFocus && typeof previousFocus.focus === 'function') {
      previousFocus.focus();
    }
  }

  document.querySelectorAll('[data-uninstall-open]').forEach(function (button) {
    button.addEventListener('click', function () {
      openUninstallModal(button);
    });
  });

  document.querySelectorAll('[data-uninstall-close]').forEach(function (button) {
    button.addEventListener('click', closeUninstallModal);
  });

  if (uninstallForm) {
    uninstallForm.addEventListener('change', function () {
      confirmButton.disabled = !uninstallForm.querySelector('input[name="remove_mode"]:checked');
    });
  }

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') return;

    if (detailModal && !detailModal.hidden) {
      closeModuleDetails();
      return;
    }

    if (uninstallModal && !uninstallModal.hidden) {
      closeUninstallModal();
    }
  });
})();
</script>

</body>
</html>
