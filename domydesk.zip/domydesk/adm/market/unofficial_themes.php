<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

$email = $_SESSION['user']['email'] ?? null;
$baseDir = realpath(__DIR__ . '/../../');
if (!$email || $baseDir === false) {
    header('Location: ../../login.php');
    exit;
}

require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_unofficial_installer.php';

$profileFile = dmd_profile_path($email, true);
$profile = is_file($profileFile) ? json_decode((string)@file_get_contents($profileFile), true) : array();
$role = strtolower(trim((string)($profile['role_system'] ?? 'user')));
if ($role !== 'superadmin') {
    http_response_code(403);
    exit('Acces reserve au Superadmin.');
}

if (empty($_SESSION['csrf_unofficial_themes'])) {
    $_SESSION['csrf_unofficial_themes'] = bin2hex(random_bytes(32));
}

$theme = 'default';
$themeJson = $baseDir . '/users/profiles/' . $email . '/theme.json';
if (is_file($themeJson)) {
    $td = json_decode((string)@file_get_contents($themeJson), true);
    if (is_array($td) && !empty($td['theme']) && is_file($baseDir . '/theme/' . basename($td['theme']) . '/style.css')) {
        $theme = basename($td['theme']);
    }
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_unofficial_themes'], $token)) {
        $error = 'Formulaire expire ou invalide.';
    } elseif (empty($_POST['accept_unofficial'])) {
        $error = 'Vous devez accepter l\'avertissement avant l\'installation.';
    } else {
        $result = dmd_install_unofficial_zip('theme', $_FILES['unofficial_zip'] ?? array(), $error);
        if ($result !== false) {
            $message = 'Theme non officiel installe : ' . $result['id'] . '.';
            dmd_system_log('unofficial_theme_installed', $result['id'], 'success', 'Theme non officiel installe depuis un ZIP.', array('source' => 'zip', 'official' => false));
        }
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>⚠ Thèmes non officiels ⚠</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="unofficial.css?v=<?= (int)(@filemtime(__DIR__ . '/unofficial.css') ?: time()) ?>">
<?php
require_once $baseDir . '/core/dmd_theme_assets.php';
echo dmd_theme_extra_links($baseDir, '../../theme', $theme, 'unofficial_themes');
?>
</head>
<body>
<div class="unofficial-wrapper">
  <div class="unofficial-head">
    <h1>Thèmes non officiels</h1>
    <p>Installation manuelle d'un thème tiers au format ZIP.</p>
  </div>

  <?php if ($message !== ''): ?><div class="unofficial-message">✅ <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  <?php if ($error !== ''): ?><div class="unofficial-message">❌ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

  <section class="unofficial-warning">
    <h2>⚠ Composant non officiel</h2>
    <p>Les thèmes installés depuis cette rubrique ne sont ni vérifiés, ni validés, ni maintenus par DoMyDesk / SynoHomes.</p>
    <p>Un thème tiers peut provoquer des problèmes d'affichage, des incompatibilités ou perturber certaines fonctions de DoMyDesk.</p>
    <p><strong>DoMyDesk / SynoHomes ne pourra être tenu responsable des conséquences liées à l'utilisation d'un thème non officiel. Le support DoMyDesk / SynoHomes n'est pas tenu d'assurer le diagnostic, la réparation ou le dépannage d'une instance affectée par un thème non officiel.</strong></p>
  </section>

  <form method="post" enctype="multipart/form-data" class="unofficial-panel">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_unofficial_themes'], ENT_QUOTES, 'UTF-8') ?>">
    <label><strong>Fichier ZIP du thème</strong><br><input type="file" name="unofficial_zip" accept=".zip" required></label>
    <label class="unofficial-accept"><input type="checkbox" name="accept_unofficial" value="1" required><span>J'ai compris que ce thème est non officiel et je l'installe sous ma responsabilité.</span></label>
    <div class="unofficial-actions"><button type="submit">Installer le thème non officiel</button></div>
  </form>
</div>
</body>
</html>
