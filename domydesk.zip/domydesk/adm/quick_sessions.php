<?php
// Compatibilité des anciens favoris/liens d'administration.
header('Location: ../Quick-Session/admin.php', true, 302);
exit;
