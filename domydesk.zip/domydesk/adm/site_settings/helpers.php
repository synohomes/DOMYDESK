<?php
function dmd_admin_license_state_label($state) {
    $map = array(
        'active' => 'Active',
        'grace' => 'Période de grâce',
        'expired' => 'Expirée',
        'not_yet_valid' => 'Pas encore active',
        'launch' => 'Licence de lancement',
        'license_required' => 'Licence requise',
        'invalid' => 'Invalide',
        'instance_mismatch' => 'Mauvaise instance',
        'crypto_unavailable' => 'Cryptographie indisponible',
    );
    return $map[(string)$state] ?? ((string)$state !== '' ? strtoupper((string)$state) : 'Inconnu');
}
function dmd_admin_license_quota($value, $suffix = '') {
    $value = (int)$value;
    if ($value < 0) return 'Illimité';
    return (string)$value . ($suffix !== '' ? ' ' . $suffix : '');
}


function dmd_admin_ticketing_base_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';

    if (!preg_match('~^https?://~i', $value)) {
        $value = 'https://' . $value;
    }

    $parts = @parse_url($value);
    if (!is_array($parts) || empty($parts['host'])) return '';

    $scheme = strtolower((string)($parts['scheme'] ?? 'https'));
    if (!in_array($scheme, ['http', 'https'], true)) $scheme = 'https';

    $path = (string)($parts['path'] ?? '/');
    $path = preg_replace('~/+~', '/', $path);

    $endpointSuffix = '/modules/dmd-ticketing/dmd-ticketing_external.php';
    if (str_ends_with(strtolower($path), strtolower($endpointSuffix))) {
        $path = substr($path, 0, -strlen($endpointSuffix));
    }

    $path = '/' . trim($path, '/');
    if ($path === '/') {
        $path = '/';
    } else {
        $path .= '/';
    }

    return $scheme . '://' . (string)$parts['host']
        . (!empty($parts['port']) ? ':' . (int)$parts['port'] : '')
        . $path;
}

function dmd_admin_ticketing_endpoint_from_base(string $value): string {
    $base = dmd_admin_ticketing_base_url($value);
    if ($base === '') return '';

    return rtrim($base, '/') . '/modules/dmd-ticketing/dmd-ticketing_external.php';
}

$theme = 'default';
if ($email) {
    $themeJson = $profilesDir . $email . '/theme.json';
    if (is_file($themeJson)) {
        $themeData = json_decode((string)file_get_contents($themeJson), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidateTheme = basename((string)$themeData['theme']);
            if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
                $theme = $candidateTheme;
            }
        }
    }
}
$themeCssFile = $baseDir . '/theme/' . $theme . '/style.css';
$themeCssHref = '../theme/' . rawurlencode($theme) . '/style.css';
if (is_file($themeCssFile)) {
    $themeCssHref .= '?v=' . filemtime($themeCssFile);
}

function dmd_json_read(string $file, $default = []) {
    if (!is_file($file)) return $default;
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function dmd_json_write(string $file, array $data): bool {
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ok = file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) !== false;
    if ($ok) @chmod($file, 0664);
    return $ok;
}

function dmd_remove_dir(string $dir): bool {
    if (!is_dir($dir)) return false;
    $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
    $ri = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($ri as $file) {
        if ($file->isDir()) {
            @chmod($file->getPathname(), 0775);
            @rmdir($file->getPathname());
        } else {
            @chmod($file->getPathname(), 0664);
            @unlink($file->getPathname());
        }
    }
    @chmod($dir, 0775);
    return @rmdir($dir);
}

function dmd_set_permissions(string $path): void {
    if (!file_exists($path)) return;
    if (is_dir($path)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $item) {
            $normalized = str_replace('\\', '/', $item->getPathname());
            $isPrivateProfile = strpos($normalized, '/profile/') !== false || substr($normalized, -8) === '/profile';
            @chmod($item->getPathname(), $item->isDir() ? ($isPrivateProfile ? 0750 : 0775) : ($isPrivateProfile ? 0640 : 0664));
        }
        @chmod($path, 0775);
    } else {
        @chmod($path, 0664);
    }
}
function dmd_horizontal_menu_emojis(): array {
    return [
        '🖥️','🌎','🔅','⭐','🏃','✅','❌','📜','🛠️','🎫',
        '🏠','👤','👥','⚙️','🔐','📁','📂','📝','📌','📊',
        '📈','📉','💬','📧','🔔','🔍','🧰','🗂️','🧾','💾',
        '🖨️','🌐','🔗','🚀','⚡','💡','❤️','🔒','🔓','🧪',
        '🧭','📡','🖱️','⌨️','📱','💻','🖧','🧱','🧩','📦',
        '🛒','🎨','🧑‍💻','🗃️','🕘','📣'
    ];
}

function dmd_default_horizontal_menu(): array {
    return [
        ['title' => 'Dashboard', 'icon' => '🖥️', 'url' => '/domydesk/dashboard.php', 'type' => 'page'],
        ['title' => 'DoMyDesk public', 'icon' => '🌎', 'url' => 'https://domydesk.com/', 'type' => 'external'],
        ['title' => 'Votre DoMySocial', 'icon' => '🔅', 'url' => '/domysocial/index.php', 'type' => 'page'],
        ['title' => 'Accueil', 'icon' => '⭐', 'url' => '/domydesk/index.php', 'type' => 'page'],
        ['title' => 'Profil', 'icon' => '🏃', 'url' => '/domydesk/profile_view.php', 'type' => 'page'],
        ['title' => 'Se connecter', 'icon' => '✅', 'url' => '/domydesk/login.php', 'type' => 'page'],
        ['title' => 'Déconnexion', 'icon' => '❌', 'url' => '/domydesk/logout.php', 'type' => 'page'],
        ['title' => 'Aide', 'icon' => '📜', 'url' => '/domydesk/data/procedures/procedures_list.php', 'type' => 'page'],
        ['title' => 'Administration', 'icon' => '🛠️', 'url' => '/domydesk/adm/site_settings.php', 'type' => 'page'],
    ];
}

function dmd_normalize_horizontal_url(string $url, string $type): string {
    $url = trim($url);
    if ($url === '') return '';
    if (strlen($url) > 255) return '';

    if ($type === 'external') {
        if (!filter_var($url, FILTER_VALIDATE_URL)) return '';
        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true) ? $url : '';
    }

    if (preg_match('~^https?://~i', $url)) return '';
    $url = str_replace('\\', '/', $url);
    if (str_contains($url, '..')) return '';
    if (str_starts_with($url, '//')) return '';
    if (!str_starts_with($url, '/')) {
        $url = '/domydesk/' . ltrim($url, '/');
    }
    return $url;
}

function dmd_normalize_horizontal_menu_from_post(array $post, array $allowedEmojis): array {
    $titles = $post['menu_title'] ?? [];
    $icons  = $post['menu_icon'] ?? [];
    $types  = $post['menu_type'] ?? [];
    $urls   = $post['menu_url'] ?? [];
    $delete = $post['menu_delete'] ?? [];

    if (!is_array($titles) || !is_array($icons) || !is_array($types) || !is_array($urls)) {
        return [];
    }

    $items = [];
    $count = min(count($titles), 30);

    for ($i = 0; $i < $count; $i++) {
        if (isset($delete[$i])) continue;

        $title = trim((string)($titles[$i] ?? ''));
        $icon  = trim((string)($icons[$i] ?? ''));
        $type  = ((string)($types[$i] ?? 'page')) === 'external' ? 'external' : 'page';
        $url   = dmd_normalize_horizontal_url((string)($urls[$i] ?? ''), $type);

        if ($title === '' && $url === '') continue;
        if ($title === '' || $url === '') continue;

        if (function_exists('mb_substr')) {
            $title = mb_substr($title, 0, 80, 'UTF-8');
        } else {
            $title = substr($title, 0, 80);
        }

        if (!in_array($icon, $allowedEmojis, true)) {
            $icon = '⭐';
        }

        $items[] = [
            'title' => $title,
            'icon'  => $icon,
            'url'   => $url,
            'type'  => $type,
        ];
    }

    return $items;
}

function dmd_horizontal_menu_to_html(array $items): string {
    $html = '';
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $title = trim((string)($item['title'] ?? ''));
        $icon  = trim((string)($item['icon'] ?? ''));
        $url   = trim((string)($item['url'] ?? ''));
        $type  = ((string)($item['type'] ?? 'page')) === 'external' ? 'external' : 'page';

        if ($title === '' || $icon === '' || $url === '') continue;

        $target = $type === 'external' ? ' target="_blank" rel="noopener noreferrer"' : '';
        $html .= '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" class="icon-link" title="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"' . $target . '>' . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') . '</a>' . "
";
    }
    return $html;
}

function dmd_theme_github_to_raw(string $url): string {
    $url = trim($url);
    if ($url === '') return '';

    $url = preg_replace('~\?.*$~', '', $url);
    $url = preg_replace('~/refs/heads/([^/]+)/~', '/$1/', $url);

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    if (preg_match('~^https?://github\.com/([^/]+)/([^/]+)/raw/([^/]+)/(.*)$~i', $url, $m)) {
        return "https://raw.githubusercontent.com/{$m[1]}/{$m[2]}/{$m[3]}/{$m[4]}";
    }

    return $url;
}

function dmd_theme_slug(string $value): string {
    $value = basename($value);
    $value = preg_replace('~\.zip$~i', '', $value);
    $value = preg_replace('~[^a-zA-Z0-9._-]+~', '-', $value);
    return trim($value, '-');
}

function dmd_theme_folder_from_url(string $url, string $fallbackName): string {
    $path = parse_url($url, PHP_URL_PATH);
    $folder = $path ? dmd_theme_slug(pathinfo($path, PATHINFO_FILENAME)) : '';
    if ($folder === '') $folder = dmd_theme_slug($fallbackName);
    return $folder;
}

function dmd_theme_http_get(string $url, ?string &$why = null) {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 40,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($body === false || $code < 200 || $code >= 300) {
            $why = $body === false ? ('cURL : ' . $err) : ('HTTP ' . $code);
            return false;
        }

        return $body;
    }

    $ctx = stream_context_create([
        'http' => [
            'header'  => "User-Agent: DoMyDesk-ThemeMarket/1.0\r\n",
            'timeout' => 40,
        ]
    ]);

    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        $why = 'file_get_contents impossible.';
        return false;
    }

    return $body;
}

function dmd_theme_http_download(string $url, string $dest, ?string &$why = null): bool {
    $why = '';
    $url = dmd_theme_github_to_raw($url);

    if (function_exists('curl_init')) {
        $fp = @fopen($dest, 'wb');
        if (!$fp) {
            $why = 'Écriture du ZIP impossible.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_USERAGENT      => 'DoMyDesk-ThemeMarket/1.0',
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 60,
        ]);
        $ok   = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        fclose($fp);

        if (!$ok || $code < 200 || $code >= 300 || !filesize($dest)) {
            @unlink($dest);
            $why = 'HTTP ' . $code . ($err ? ' - ' . $err : '');
            return false;
        }

        @chmod($dest, 0664);
        return true;
    }

    $data = @file_get_contents($url);
    if ($data === false || $data === '') {
        $why = 'Téléchargement impossible ou fichier vide.';
        return false;
    }

    if (@file_put_contents($dest, $data) === false) {
        $why = 'Écriture du ZIP impossible.';
        return false;
    }

    @chmod($dest, 0664);
    return true;
}

function dmd_theme_safe_extract_zip(ZipArchive $zip, string $extractDir, array &$errors): bool {
    @mkdir($extractDir, 0775, true);
    $extractReal = realpath($extractDir);

    if ($extractReal === false) {
        $errors[] = 'Dossier temporaire du thème invalide.';
        return false;
    }

    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if ($name === false || $name === '') continue;

        $name = str_replace('\\', '/', $name);

        if (
            str_starts_with($name, '/') ||
            preg_match('~(^|/)\.\.(/|$)~', $name) ||
            preg_match('~^[a-zA-Z]:/~', $name)
        ) {
            $errors[] = 'ZIP thème refusé : chemin dangereux détecté.';
            return false;
        }
    }

    if (!$zip->extractTo($extractDir)) {
        $errors[] = 'Extraction du thème impossible.';
        return false;
    }

    dmd_set_permissions($extractDir);
    return true;
}

function dmd_theme_normalize_extract(string $extractDir): bool {
    $extractDir = rtrim($extractDir, '/') . '/';
    if (is_file($extractDir . 'style.css')) return true;

    $children = array_values(array_filter(scandir($extractDir) ?: [], fn($x) => $x !== '.' && $x !== '..' && $x !== '__MACOSX'));
    $candidates = [];

    foreach ($children as $child) {
        $childPath = $extractDir . $child;
        if (is_dir($childPath) && is_file($childPath . '/style.css')) {
            $candidates[] = $childPath;
        }
    }

    if (count($candidates) !== 1) return false;

    $source = rtrim($candidates[0], '/') . '/';
    foreach (array_diff(scandir($source), ['.', '..']) as $item) {
        @rename($source . $item, $extractDir . $item);
    }
    @rmdir($source);

    return is_file($extractDir . 'style.css');
}

function dmd_theme_installed_list(string $themesDir): array {
    $items = [];
    foreach (glob(rtrim($themesDir, '/') . '/*', GLOB_ONLYDIR) ?: [] as $folder) {
        if (is_file($folder . '/style.css')) {
            $items[] = basename($folder);
        }
    }
    sort($items, SORT_NATURAL | SORT_FLAG_CASE);
    return $items;
}


function dmd_rights_notification_permission_labels($moduleId, $permissions, $definitions) {
    if (!is_array($permissions)) {
        $permissions = array();
    }

    if (in_array('*', $permissions, true)) {
        return array('Toutes les actions');
    }

    $moduleDefinitions = isset($definitions[$moduleId]) && is_array($definitions[$moduleId])
        ? $definitions[$moduleId]
        : array();
    $labels = array();

    foreach ($permissions as $permissionId) {
        $permissionId = trim((string)$permissionId);
        if ($permissionId === '') {
            continue;
        }
        $labels[] = isset($moduleDefinitions[$permissionId]['label']) && trim((string)$moduleDefinitions[$permissionId]['label']) !== ''
            ? (string)$moduleDefinitions[$permissionId]['label']
            : $permissionId;
    }

    $labels = array_values(array_unique($labels));
    sort($labels, SORT_NATURAL | SORT_FLAG_CASE);
    return $labels;
}

function dmd_user_module_rights_notification_changes($beforeAcl, $afterAcl, $modules, $definitions) {
    $beforeOverrides = isset($beforeAcl['overrides']) && is_array($beforeAcl['overrides']) ? $beforeAcl['overrides'] : array();
    $afterOverrides = isset($afterAcl['overrides']) && is_array($afterAcl['overrides']) ? $afterAcl['overrides'] : array();
    $moduleIds = array_values(array_unique(array_merge(array_keys($beforeOverrides), array_keys($afterOverrides))));
    sort($moduleIds, SORT_NATURAL | SORT_FLAG_CASE);
    $changes = array();

    foreach ($moduleIds as $moduleId) {
        $beforeRule = isset($beforeOverrides[$moduleId]) && is_array($beforeOverrides[$moduleId]) ? $beforeOverrides[$moduleId] : array();
        $afterRule = isset($afterOverrides[$moduleId]) && is_array($afterOverrides[$moduleId]) ? $afterOverrides[$moduleId] : array();
        $beforeState = strtolower(trim((string)($beforeRule['state'] ?? 'inherit')));
        $afterState = strtolower(trim((string)($afterRule['state'] ?? 'inherit')));
        if (!in_array($beforeState, array('inherit', 'allow', 'deny'), true)) $beforeState = 'inherit';
        if (!in_array($afterState, array('inherit', 'allow', 'deny'), true)) $afterState = 'inherit';

        $beforePermissions = $beforeState === 'allow' && isset($beforeRule['permissions']) && is_array($beforeRule['permissions'])
            ? array_values($beforeRule['permissions'])
            : array();
        $afterPermissions = $afterState === 'allow' && isset($afterRule['permissions']) && is_array($afterRule['permissions'])
            ? array_values($afterRule['permissions'])
            : array();
        sort($beforePermissions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($afterPermissions, SORT_NATURAL | SORT_FLAG_CASE);

        if ($beforeState === $afterState && $beforePermissions === $afterPermissions) {
            continue;
        }

        $changes[$moduleId] = array(
            'label' => isset($modules[$moduleId]['name']) ? (string)$modules[$moduleId]['name'] : $moduleId,
            'before' => $beforeState,
            'after' => $afterState,
            'permissions_before' => dmd_rights_notification_permission_labels($moduleId, $beforePermissions, $definitions),
            'permissions_after' => dmd_rights_notification_permission_labels($moduleId, $afterPermissions, $definitions),
        );
    }

    return $changes;
}

function dmd_role_module_rights_notification_changes($beforeRules, $afterRules, $modules, $definitions) {
    $beforeRules = is_array($beforeRules) ? $beforeRules : array();
    $afterRules = is_array($afterRules) ? $afterRules : array();
    $moduleIds = array_values(array_unique(array_merge(array_keys($beforeRules), array_keys($afterRules))));
    sort($moduleIds, SORT_NATURAL | SORT_FLAG_CASE);
    $changes = array();

    foreach ($moduleIds as $moduleId) {
        $beforeRule = isset($beforeRules[$moduleId]) && is_array($beforeRules[$moduleId]) ? $beforeRules[$moduleId] : array();
        $afterRule = isset($afterRules[$moduleId]) && is_array($afterRules[$moduleId]) ? $afterRules[$moduleId] : array();
        $beforeEnabled = !empty($beforeRule['enabled']);
        $afterEnabled = !empty($afterRule['enabled']);
        $beforePermissions = $beforeEnabled && isset($beforeRule['permissions']) && is_array($beforeRule['permissions']) ? array_values($beforeRule['permissions']) : array();
        $afterPermissions = $afterEnabled && isset($afterRule['permissions']) && is_array($afterRule['permissions']) ? array_values($afterRule['permissions']) : array();
        sort($beforePermissions, SORT_NATURAL | SORT_FLAG_CASE);
        sort($afterPermissions, SORT_NATURAL | SORT_FLAG_CASE);

        if ($beforeEnabled === $afterEnabled && $beforePermissions === $afterPermissions) {
            continue;
        }

        $changes[$moduleId] = array(
            'label' => isset($modules[$moduleId]['name']) ? (string)$modules[$moduleId]['name'] : $moduleId,
            'before' => $beforeEnabled ? 'allow' : 'deny',
            'after' => $afterEnabled ? 'allow' : 'deny',
            'permissions_before' => dmd_rights_notification_permission_labels($moduleId, $beforePermissions, $definitions),
            'permissions_after' => dmd_rights_notification_permission_labels($moduleId, $afterPermissions, $definitions),
        );
    }

    return $changes;
}
