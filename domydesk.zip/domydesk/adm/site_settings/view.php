<!DOCTYPE html>
<html lang="<?= htmlspecialchars((string)($settings['language'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administration systeme</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeCssHref) ?>">
<link rel="stylesheet" href="../core/dmd_permissions_admin.css?v=120">
<link rel="stylesheet" href="../core/dmd_permissions_admin_compact.css?v=121">
<?php $dmdSiteSettingsCss = $baseDir . '/adm/site_settings/assets/site_settings.css'; ?>
<link rel="stylesheet" href="site_settings/assets/site_settings.css?v=<?= is_file($dmdSiteSettingsCss) ? (int)filemtime($dmdSiteSettingsCss) : 1 ?>">
</head>
<body>
<?php
require __DIR__ . '/views/dashboard.php';
require __DIR__ . '/views/popups/security.php';
require __DIR__ . '/views/popups/core_interface.php';
require __DIR__ . '/views/popups/site.php';
require __DIR__ . '/views/popups/maintenance.php';
require __DIR__ . '/views/popups/index_settings.php';
require __DIR__ . '/views/popups/system_tools.php';
require __DIR__ . '/views/popups/news.php';
require __DIR__ . '/views/popups/theme_market.php';
require __DIR__ . '/views/popups/unofficial.php';
require __DIR__ . '/views/popups/module_market.php';
require __DIR__ . '/views/popups/module_rights.php';
require __DIR__ . '/views/popups/users.php';
require __DIR__ . '/views/popups/page_rights.php';
require __DIR__ . '/views/popups/metiers.php';
?>
<script>
const ROLE_PAGES = <?= json_encode($pageRightsData['roles'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_PAGE_OVERRIDES = <?= json_encode($userPageOverridesMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const ROLE_MODULES = <?= json_encode($rolesModulesData['roles'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const MODULE_PERMISSION_DEFS = <?= json_encode($modulePermissionDefinitions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_MODULE_OVERRIDES = <?= json_encode($userModuleOverridesMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const USER_RIGHTS_META = <?= json_encode($userRightsMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const REOPEN_POPUP = <?= json_encode($reopenPopup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const MODULE_RIGHTS_STATE_KEY = 'dmd-module-rights-selection';
const PAGE_RIGHTS_STATE_KEY = 'dmd-page-rights-selection';
</script>
<?php $dmdSiteSettingsJs = $baseDir . '/adm/site_settings/assets/site_settings.js'; ?>
<script src="site_settings/assets/site_settings.js?v=<?= is_file($dmdSiteSettingsJs) ? (int)filemtime($dmdSiteSettingsJs) : 1 ?>"></script>
</body>
</html>
