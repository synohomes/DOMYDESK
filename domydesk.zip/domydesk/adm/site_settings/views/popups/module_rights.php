<div id="popup-module-rights" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Droits sur les modules</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-module-rights' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Droits enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-module-rights' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <p>
            </p>

            <div class="dmd-rights-catalog-head">
                <div>
                    <h3>Tous les modules</h3>
                    <p class="pe-note">Cocher « Tout le monde » pour un accès global, ou ouvrir « Paramétrer » pour gérer les groupes et les utilisateurs.</p><br>
                </div>
                <span class="dmd-rights-module-count"><?= count($permissionModules) ?> module<?= count($permissionModules) > 1 ? 's' : '' ?></span>
            </div>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="global-module-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <?php if (!empty($permissionModules)): ?>
                    <div class="dmd-rights-card-grid">
                        <?php foreach ($permissionModules as $moduleId => $moduleInfo):
                            $moduleAccessMode = dmd_module_access_mode($moduleId);
                            $moduleName = (string)($moduleInfo['name'] ?? $moduleId);
                            $moduleDescription = trim((string)($moduleInfo['description'] ?? ''));
                        ?>
                            <article class="dmd-rights-card" data-global-module-card="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                                <div class="dmd-rights-card-main">
                                    <img
                                        class="dmd-rights-card-icon"
                                        src="../modules/<?= rawurlencode($moduleId) ?>/icon.png"
                                        alt=""
                                        onerror="this.hidden=true"
                                    >
                                    <div class="dmd-rights-card-copy">
                                        <strong><?= htmlspecialchars($moduleName, ENT_QUOTES, 'UTF-8') ?></strong>
                                        <?php if ($moduleDescription !== ''): ?>
                                            <small title="<?= htmlspecialchars($moduleDescription, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($moduleDescription, ENT_QUOTES, 'UTF-8') ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="dmd-rights-card-actions">
                                    <label class="dmd-rights-everyone">
                                        <input
                                            type="checkbox"
                                            name="global_modules[]"
                                            value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                            data-global-module="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                            <?= $moduleAccessMode === 'everyone' ? 'checked' : '' ?>
                                        >
                                        <span>Tout le monde</span>
                                    </label>

                                    <button
                                        type="button"
                                        class="dmd-rights-config-button"
                                        data-popup-open="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                        aria-haspopup="dialog"
                                        aria-controls="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    >⚙ Paramétrer</button>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pe-note">Aucun module installé pour le moment.</p>
                <?php endif; ?>
<br>
                <div class="pe-actions dmd-rights-global-save">
                    <button type="submit" name="save_global_module_rights" value="1">Enregistrer « Tout le monde »</button>
                </div>
            </form>

            <!-- Formulaires maîtres invisibles : les contrôles des popups y sont rattachés avec form="...". -->
            <form method="post" accept-charset="UTF-8" id="role-module-rights-form" class="dmd-rights-master-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="rights_role" id="moduleRightsRole" required>
                    <?php foreach ($metiers as $m): ?>
                        <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>" <?= $selectedRightsRole === $m ? 'selected' : '' ?>>
                            <?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>

            <form method="post" accept-charset="UTF-8" id="user-module-exceptions-form" class="dmd-rights-master-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="rights_user" id="moduleRightsUser" required>
                    <option value="">Sélectionner une personne</option>
                    <?php foreach ($users as $u):
                        $uProfile = $userProfiles[$u] ?? [];
                        $uName = trim((string)($uProfile['prenom'] ?? '') . ' ' . (string)($uProfile['nom'] ?? ''));
                        $uRole = (string)($uProfile['role_metier'] ?? '');
                    ?>
                        <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>" <?= $selectedRightsUser === $u ? 'selected' : '' ?>>
                            <?= htmlspecialchars(($uName !== '' ? $uName . ' — ' : '') . $u . ($uRole !== '' ? ' (' . $uRole . ')' : ''), ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="save_user_module_exceptions" value="1" id="saveUserModuleExceptions" hidden disabled>Enregistrer</button>
            </form>
        </div>
    </div>
</div>

<?php foreach ($permissionModules as $moduleId => $moduleInfo):
    $permissionGroups = dmd_module_permission_groups($moduleId);
    $moduleName = (string)($moduleInfo['name'] ?? $moduleId);
?>
<div id="popup-module-config-<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>" class="pe-popup dmd-module-config-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2><?= htmlspecialchars($moduleName, ENT_QUOTES, 'UTF-8') ?> — Paramétrer les droits</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <div class="dmd-rights-config-columns">
                <section class="dmd-rights-config-section">
                    <div class="dmd-rights-config-title">
                        <div>
                            <strong>👥 Groupe / rôle métier</strong>
                            <small>Définis les droits par défaut du groupe.</small>
                        </div>
                    </div>

                    <label class="dmd-rights-field">
                        <span>Groupe / rôle métier</span>
                        <select data-module-role-select="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <?php foreach ($metiers as $m): ?>
                                <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label class="dmd-rights-access-line">
                        <input
                            type="checkbox"
                            name="role_modules[]"
                            value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            data-rights-role-module="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            form="role-module-rights-form"
                        >
                        <span>Autoriser ce groupe à utiliser le module</span>
                    </label>

                    <?php if (!empty($permissionGroups)): ?>
                        <div class="dmd-rights-action-zone" data-role-permission-details="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <label class="dmd-permission-all">
                                <input
                                    type="checkbox"
                                    name="role_all_modules[]"
                                    value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-role-all="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    form="role-module-rights-form"
                                >
                                <span><strong>Tous les droits</strong><small>Contrôle complet de ce module.</small></span>
                            </label>

                            <?php foreach ($permissionGroups as $permissionGroup => $permissionDefinitions): ?>
                                <div class="dmd-permission-group">
                                    <div class="dmd-permission-group-title"><?= htmlspecialchars($permissionGroup, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="dmd-permission-grid">
                                        <?php foreach ($permissionDefinitions as $permissionId => $permissionDefinition): ?>
                                            <label class="dmd-permission-item<?= !empty($permissionDefinition['dangerous']) ? ' is-dangerous' : '' ?>">
                                                <input
                                                    type="checkbox"
                                                    name="role_permission_tokens[]"
                                                    value="<?= htmlspecialchars($moduleId . '|' . $permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-rights-role-permission="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-permission-id="<?= htmlspecialchars($permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    form="role-module-rights-form"
                                                >
                                                <span><strong><?= htmlspecialchars($permissionDefinition['label'] ?? $permissionId, ENT_QUOTES, 'UTF-8') ?></strong></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="dmd-rights-legacy-note">Ce module ne déclare pas encore de droits fins : l’accès au module donne son fonctionnement complet historique.</div>
                    <?php endif; ?>

                    <div class="pe-actions">
                        <button type="submit" name="save_role_module_rights" value="1" form="role-module-rights-form">Enregistrer le groupe</button>
                    </div>
                </section>

                <section class="dmd-rights-config-section">
                    <div class="dmd-rights-config-title">
                        <div>
                            <strong>👤 Utilisateur</strong>
                            <small>Ajoute une exception individuelle au-dessus des droits du groupe.</small>
                        </div>
                    </div>

                    <label class="dmd-rights-field">
                        <span>Utilisateur</span>
                        <select data-module-user-select="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <option value="">Sélectionner une personne</option>
                            <?php foreach ($users as $u):
                                $uProfile = $userProfiles[$u] ?? [];
                                $uName = trim((string)($uProfile['prenom'] ?? '') . ' ' . (string)($uProfile['nom'] ?? ''));
                                $uRole = (string)($uProfile['role_metier'] ?? '');
                            ?>
                                <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars(($uName !== '' ? $uName . ' — ' : '') . $u . ($uRole !== '' ? ' (' . $uRole . ')' : ''), ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <div class="dmd-rights-user-summary" data-rights-effective="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">Sélectionne une personne</div>

                    <label class="dmd-rights-field">
                        <span>Exception</span>
                        <select
                            name="user_override_state[]"
                            data-rights-user-override="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                            form="user-module-exceptions-form"
                            disabled
                        >
                            <option value="<?= htmlspecialchars($moduleId . '|inherit', ENT_QUOTES, 'UTF-8') ?>">Comme son groupe</option>
                            <option value="<?= htmlspecialchars($moduleId . '|allow', ENT_QUOTES, 'UTF-8') ?>">Toujours autoriser</option>
                            <option value="<?= htmlspecialchars($moduleId . '|deny', ENT_QUOTES, 'UTF-8') ?>">Toujours refuser</option>
                        </select>
                    </label>

                    <?php if (!empty($permissionGroups)): ?>
                        <div class="dmd-rights-action-zone" data-user-permission-details="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>">
                            <label class="dmd-permission-all">
                                <input
                                    type="checkbox"
                                    name="user_all_modules[]"
                                    value="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-user-all="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                    form="user-module-exceptions-form"
                                    disabled
                                >
                                <span><strong>Tous les droits</strong><small>Exception personnelle avec contrôle complet.</small></span>
                            </label>

                            <?php foreach ($permissionGroups as $permissionGroup => $permissionDefinitions): ?>
                                <div class="dmd-permission-group">
                                    <div class="dmd-permission-group-title"><?= htmlspecialchars($permissionGroup, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="dmd-permission-grid">
                                        <?php foreach ($permissionDefinitions as $permissionId => $permissionDefinition): ?>
                                            <label class="dmd-permission-item<?= !empty($permissionDefinition['dangerous']) ? ' is-dangerous' : '' ?>">
                                                <input
                                                    type="checkbox"
                                                    name="user_permission_tokens[]"
                                                    value="<?= htmlspecialchars($moduleId . '|' . $permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-rights-user-permission="<?= htmlspecialchars($moduleId, ENT_QUOTES, 'UTF-8') ?>"
                                                    data-permission-id="<?= htmlspecialchars($permissionId, ENT_QUOTES, 'UTF-8') ?>"
                                                    form="user-module-exceptions-form"
                                                    disabled
                                                >
                                                <span><strong><?= htmlspecialchars($permissionDefinition['label'] ?? $permissionId, ENT_QUOTES, 'UTF-8') ?></strong></span>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="dmd-rights-legacy-note">Sans droits fins déclarés, « Toujours autoriser » donne accès au module complet.</div>
                    <?php endif; ?>

                    <div class="pe-actions">
                        <button type="submit" name="save_user_module_exceptions" value="1" form="user-module-exceptions-form" data-user-save disabled>Enregistrer l’utilisateur</button>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

