<div id="popup-metiers" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Rôles métier</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="pe-form-row">
                    <div>
                        <label>Nouveau rôle métier</label>
                        <input type="text" name="new_metier" placeholder="ex: TECH, COMPTA, RH">
                    </div>
                    <div>
                        <label>Supprimer un rôle métier</label>
                        <select name="del_metier">
                            <option value="">Ne rien supprimer</option>
                            <?php foreach ($metiers as $m): ?>
                                <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="pe-actions">
                    <button type="submit" name="add_metier">Ajouter</button>
                    <button type="submit" name="delete_metier" class="btn-del">Supprimer</button>
                </div>
            </form>

            <hr>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div>
                    <label>Rôle attribué automatiquement aux nouvelles inscriptions</label>
                    <select name="default_registration_role" required>
                        <?php foreach ($metiers as $m): ?>
                            <option value="<?= htmlspecialchars($m) ?>" <?= (($rolesModulesData['default_role'] ?? '') === $m) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($m) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <p class="pe-note">L’utilisateur ne peut pas choisir lui-même un rôle plus privilégié lors de son inscription.</p>
                <div class="pe-actions">
                    <button type="submit" name="save_default_role">Enregistrer le rôle par défaut</button>
                </div>
            </form>

            <hr>
            <p class="pe-note">
                Les autorisations héritées des rôles et les exceptions individuelles sont maintenant centralisées dans « Droits sur les modules ».
            </p>
        </div>
    </div>
</div>

