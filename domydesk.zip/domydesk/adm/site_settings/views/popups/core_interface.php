<div id="popup-core-interface" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Outils Core & dashboards</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-core-interface' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Réglages enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-core-interface' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <form method="post" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="save_core_interface" value="1">

                <datalist id="dmd-core-tool-icons">
                    <option value="⚡"></option>
                    <option value="🚨"></option>
                    <option value="🧰"></option>
                    <option value="🚀"></option>
                    <option value="🎯"></option>
                    <option value="🛠️"></option>
                    <option value="🔧"></option>
                    <option value="▶️"></option>
                    <option value="⏱️"></option>
                    <option value="💡"></option>
                </datalist>

                <div class="pe-form-row">
                    <div>
                        <h3><?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?> ActionHub</h3>
                        <label style="display:flex;align-items:center;gap:10px;">
                            <input type="checkbox" name="actionhub_enabled" value="1" <?= !empty($settings['core_tools']['actionhub']['enabled']) ? 'checked' : '' ?>>
                            Activé globalement
                        </label>
                        <label>Emplacement par défaut</label>
                        <select name="actionhub_default_location">
                            <?php $ahDefaultLocation = (string)$settings['core_tools']['actionhub']['default_location']; ?>
                            <option value="header" <?= $ahDefaultLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $ahDefaultLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $ahDefaultLocation === 'hidden' ? 'selected' : '' ?>>Masqué par défaut</option>
                        </select>
                        <label>Icône</label>
                        <input type="text" name="actionhub_icon" list="dmd-core-tool-icons" maxlength="16" value="<?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?>" placeholder="⚡">
                    </div>

                    <div>
                        <h3><?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?> Quick-Session</h3>
                        <label style="display:flex;align-items:center;gap:10px;">
                            <input type="checkbox" name="quick_session_enabled" value="1" <?= !empty($settings['core_tools']['quick_session']['enabled']) ? 'checked' : '' ?>>
                            Activé globalement
                        </label>
                        <label>Emplacement par défaut</label>
                        <?php $qsDefaultLocation = (string)$settings['core_tools']['quick_session']['default_location']; ?>
                        <select name="quick_session_default_location">
                            <option value="header" <?= $qsDefaultLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $qsDefaultLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $qsDefaultLocation === 'hidden' ? 'selected' : '' ?>>Masqué par défaut</option>
                        </select>
                        <label>Icône</label>
                        <input type="text" name="quick_session_icon" list="dmd-core-tool-icons" maxlength="16" value="<?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?>" placeholder="🚨">
                    </div>
                </div>

                <hr>

                <div>
                    <label>Nombre maximum de dashboards par utilisateur</label>
                    <input type="number" min="0" step="1" name="dashboard_limit" value="<?= (int)$settings['dashboard_limit'] ?>">
                    <p class="pe-note"><strong>0 = illimité.</strong> La même règle est utilisée par la création manuelle et par ActionHub.</p>
                </div>

                <p class="pe-note">Si un outil est désactivé ici, aucun utilisateur ne peut le réactiver depuis son profil. Le choix utilisateur ne porte que sur l’emplacement ou le masquage lorsque l’outil est autorisé globalement.</p>

                <div class="pe-actions">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

