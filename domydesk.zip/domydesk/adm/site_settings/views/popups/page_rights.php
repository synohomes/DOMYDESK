<div id="popup-page-rights" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Pages accessibles</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-page-rights' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Droits des pages enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-page-rights' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <p class="pe-note">
                <strong>L’administrateur autorise, l’utilisateur organise.</strong>
                Ici tu définis les pages que chacun peut utiliser. Ensuite chaque personne décide librement de les ajouter ou non à son propre menu vertical.
            </p>

            <h3>🔒 Pages essentielles</h3>
            <p class="pe-note">Ces pages font partie du fonctionnement normal de DoMyDesk. Elles restent disponibles, mais personne n’est obligé de les mettre dans son menu.</p>

            <?php if (!empty($alwaysPages)): ?>
                <div class="mods-grid">
                    <?php foreach ($alwaysPages as $pageId => $pageInfo): ?>
                        <div class="mod-card">
                            <div class="mod-meta">
                                <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="mod-id"><?= htmlspecialchars($pageInfo['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                            </div>
                            <strong>Toujours disponible</strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <hr>

            <h3>🌍 1. Pages pour tout le monde</h3>
            <p class="pe-note">Coche les pages facultatives que tous les utilisateurs peuvent ouvrir, quel que soit leur métier.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="global-page-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <?php if (!empty($permissionPages)): ?>
                    <div class="mods-grid">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <label class="mod-card">
                                <div class="mod-meta">
                                    <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="mod-id"><?= htmlspecialchars($pageInfo['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                                </div>
                                <div>
                                    <input
                                        type="checkbox"
                                        name="global_pages[]"
                                        value="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                        data-global-page="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                        <?= dmd_page_access_mode($pageId) === 'everyone' ? 'checked' : '' ?>
                                    >
                                    <strong>Tout le monde</strong>
                                </div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pe-note">Aucune page facultative déclarée pour le moment.</p>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_global_page_rights" value="1">Enregistrer</button>
                </div>
            </form>

            <hr>

            <h3>👥 2. Pages par rôle métier</h3>
            <p class="pe-note">Choisis un métier, puis coche les pages que les personnes de ce métier peuvent utiliser.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="role-page-rights-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <div>
                    <label for="pageRightsRole">Rôle métier</label>
                    <select name="page_rights_role" id="pageRightsRole" required>
                        <?php foreach ($metiers as $m): ?>
                            <option value="<?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?>" <?= $m === $selectedPageRightsRole ? 'selected' : '' ?>><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (!empty($permissionPages)): ?>
                    <div class="mods-grid">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <label class="mod-card">
                                <div class="mod-meta">
                                    <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                    <div class="mod-id" data-role-page-help="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Autoriser ce rôle</div>
                                </div>
                                <input
                                    type="checkbox"
                                    name="role_pages[]"
                                    value="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                    data-rights-role-page="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                >
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_role_page_rights" value="1">Enregistrer les pages du rôle</button>
                </div>
            </form>

            <hr>

            <h3>👤 3. Exceptions pour une personne</h3>
            <p class="pe-note">Un cas particulier ? Donne une page en plus, retire-la, ou laisse simplement son rôle décider.</p>

            <form method="post" accept-charset="UTF-8" class="pe-form" id="user-page-exceptions-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <div>
                    <label for="pageRightsUser">Utilisateur</label>
                    <select name="page_rights_user" id="pageRightsUser">
                        <option value="">Sélectionner une personne</option>
                        <?php foreach ($users as $u):
                            $profile = $userProfiles[$u] ?? [];
                            $fullName = trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? ''));
                            $roleMetier = (string)($profile['role_metier'] ?? '');
                            $userLabel = ($fullName !== '' ? $fullName . ' — ' : '') . $u . ($roleMetier !== '' ? ' (' . $roleMetier . ')' : '');
                        ?>
                            <option value="<?= htmlspecialchars($u, ENT_QUOTES, 'UTF-8') ?>" <?= $u === $selectedPageRightsUser ? 'selected' : '' ?>><?= htmlspecialchars($userLabel, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (!empty($permissionPages)): ?>
                    <div id="userPageExceptionsGrid" class="pe-form">
                        <?php foreach ($permissionPages as $pageId => $pageInfo): ?>
                            <div class="pe-msg">
                                <div class="pe-form-row">
                                    <div>
                                        <div class="mod-name"><?= htmlspecialchars($pageInfo['label'] ?? $pageId, ENT_QUOTES, 'UTF-8') ?></div>
                                        <div class="mod-id" data-page-rights-effective="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Sélectionne une personne</div>
                                    </div>
                                    <div>
                                        <label for="page-override-<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>">Exception</label>
                                        <select
                                            id="page-override-<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                            name="page_overrides[<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>]"
                                            data-rights-user-page-override="<?= htmlspecialchars($pageId, ENT_QUOTES, 'UTF-8') ?>"
                                            disabled
                                        >
                                            <option value="inherit">Comme son rôle</option>
                                            <option value="allow">Toujours autoriser</option>
                                            <option value="deny">Toujours refuser</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit" name="save_user_page_exceptions" value="1" id="saveUserPageExceptions" disabled>Enregistrer les exceptions</button>
                </div>
            </form>
        </div>
    </div>
</div>

