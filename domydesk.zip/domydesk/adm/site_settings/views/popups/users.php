<div id="popup-user-add" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head"><h2>Ajouter utilisateur</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="pe-form-row"><div><label>Prenom</label><input type="text" name="prenom" required></div><div><label>Nom</label><input type="text" name="nom" required></div></div>
                <div><label>Email</label><input type="email" name="email" required></div>
                <div class="pe-form-row"><div><label>Role interne</label><select name="role_metier" required><option value="" disabled selected>Selectionner</option><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></div><div><label>Role systeme</label><select name="role_system" required><option value="user">Utilisateur</option><option value="admin">Administrateur</option><?php if ($isSuperadmin): ?><option value="superadmin">Superadmin</option><?php endif; ?></select></div></div>
                <div><label>Mot de passe</label><input type="password" name="password" required></div>
                <div class="pe-actions"><button type="submit" name="add_user">Ajouter</button></div>
            </form>
        </div>
    </div>
</div>

<div id="popup-user-roles" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Roles utilisateurs</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <form method="post" accept-charset="UTF-8" class="pe-form">
                <div class="table-wrap"><table class="roles-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Role systeme</th><th>Role metier</th><th>Action</th></tr></thead><tbody>
                    <?php foreach ($users as $mail):
                        $profile = $userProfiles[$mail] ?? [];
                        $prenom = $profile['prenom'] ?? $mail;
                        $nom = $profile['nom'] ?? '';
                        $roleSys = $profile['role_system'] ?? 'user';
                        $roleMetier = $profile['role_metier'] ?? '';
                    ?>
                    <tr>
                        <td><strong><?= htmlspecialchars(trim($prenom . ' ' . $nom)) ?></strong><br><a href="/domydesk/profile_view.php?email=<?= urlencode($mail) ?>">Voir profil</a></td>
                        <td><?= htmlspecialchars($mail) ?><?= $mail === $email ? '<br><strong>Vous</strong>' : '' ?></td>
                        <td>
                            <?php if ($roleSys === 'superadmin' && !$isSuperadmin): ?>
                                <strong>Superadmin</strong>
                                <input type="hidden" name="role_systems[<?= htmlspecialchars($mail) ?>]" value="superadmin">
                            <?php else: ?>
                                <select name="role_systems[<?= htmlspecialchars($mail) ?>]">
                                    <option value="user" <?= $roleSys === 'user' ? 'selected' : '' ?>>Utilisateur</option>
                                    <option value="admin" <?= $roleSys === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                                    <?php if ($isSuperadmin): ?><option value="superadmin" <?= $roleSys === 'superadmin' ? 'selected' : '' ?>>Superadmin</option><?php endif; ?>
                                </select>
                            <?php endif; ?>
                        </td>
                        <td><select name="role_metiers[<?= htmlspecialchars($mail) ?>]" <?= ($roleSys === 'superadmin' && !$isSuperadmin) ? 'disabled' : '' ?>><?php foreach ($metiers as $m): ?><option value="<?= htmlspecialchars($m) ?>" <?= $m === $roleMetier ? 'selected' : '' ?>><?= htmlspecialchars($m) ?></option><?php endforeach; ?></select></td>
                        <td>
                            <?php $canDeleteThis = $mail !== $email && ($roleSys !== 'superadmin' || ($isSuperadmin && $superadminTotal > 1)); ?>
                            <?php if ($canDeleteThis): ?><button type="submit" name="delete_user" value="<?= htmlspecialchars($mail) ?>" class="btn-del" onclick="return confirm('Supprimer définitivement <?= htmlspecialchars($mail) ?> ?')">Supprimer</button><?php else: ?>—<?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody></table></div>
                <div class="pe-actions"><button type="submit" name="save_user_roles">Enregistrer les rôles</button></div>
            </form>
        </div>
    </div>
</div>

