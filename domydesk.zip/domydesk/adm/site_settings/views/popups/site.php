<div id="popup-site-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Paramètres du site</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-site-settings' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Paramètres enregistrés.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-site-settings' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>
            <form method="post" accept-charset="UTF-8" enctype="multipart/form-data" class="pe-form">
                <div><label>Nom du site</label><input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>

                <div>
                    <label for="site_language">Langue de DoMyDesk</label>
                    <select name="site_language" id="site_language" <?= empty($availableLanguages) ? 'disabled' : '' ?>>
                        <?php if (empty($availableLanguages)): ?>
                            <option value="">Aucun dossier de langue installé dans /lang/</option>
                        <?php else: ?>
                            <?php foreach ($availableLanguages as $languageFolder => $languageLabel): ?>
                                <option
                                    value="<?= htmlspecialchars((string)$languageFolder, ENT_QUOTES, 'UTF-8') ?>"
                                    <?= (($settings['language'] ?? '') === $languageFolder) ? 'selected' : '' ?>
                                >
                                    <?= htmlspecialchars((string)$languageLabel, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <p class="pe-note">Seulement les textes du système seront traduis dans la langue choisie.</p>
                </div>
<br>
                <div class="pe-form-row">
                    <div>
                        <label>Avatar / logo actuel du site</label>
                        <?php
                        $siteLogoFile = dmd_site_asset_file($settings, 'logo_path');
                        $siteLogoUrl = $siteLogoFile !== '' ? dmd_media_public_url($siteLogoFile) : '';
                        ?>
                        <?php if ($siteLogoUrl !== ''): ?>
                            <br><img class="logo-preview" src="<?= htmlspecialchars($siteLogoUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Avatar du site">
                        <?php else: ?>
                            <p class="pe-note">Aucun avatar/logo.</p>
                        <?php endif; ?><br>
                        <input type="file" name="logo" accept="image/*,.svg"><br>
                        <?php if ($siteLogoUrl !== ''): ?><br>
                            <label><input type="checkbox" name="remove_site_logo" value="1"> Supprimer l’avatar/logo actuel</label>
                        <?php endif; ?>
                    </div>

                    <div>
                        <label>Bannière actuelle du site</label>
                        <?php
                        $siteBannerFile = dmd_site_asset_file($settings, 'banner_path');
                        $siteBannerUrl = $siteBannerFile !== '' ? dmd_media_public_url($siteBannerFile) : '';
                        ?>
                        <?php if ($siteBannerUrl !== ''): ?>
                            <br><img src="<?= htmlspecialchars($siteBannerUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Bannière du site" style="width:100%;max-width:420px;height:110px;object-fit:cover;border:1px solid var(--border-color);border-radius:var(--radius,14px);">
                        <?php else: ?>
                            <p class="pe-note">Aucune bannière. Les utilisateurs sans bannière personnelle n’en afficheront pas.</p>
                        <?php endif; ?>
                        <input type="file" name="site_banner" accept="image/*,.svg">
                        <?php if ($siteBannerUrl !== ''): ?>
                            <label><input type="checkbox" name="remove_site_banner" value="1"> Supprimer la bannière actuelle</label>
                        <?php endif; ?>
                    </div>
                </div>
<br>
                <div><br>
                    <label>Image en haut du menu vertical</label>
                    <?php $brandModeCurrent = (string)($settings['vertical_menu_brand_mode'] ?? 'none'); ?>
                    <div class="pe-actions" style="justify-content:flex-start;">
                        <label><input type="radio" name="vertical_menu_brand_mode" value="none" <?= $brandModeCurrent === 'none' ? 'checked' : '' ?>> Aucune</label>
                        <label title="<?= $siteLogoUrl === '' ? 'Ajoute d’abord un avatar/logo du site.' : '' ?>">
                            <input type="radio" name="vertical_menu_brand_mode" value="avatar" <?= $brandModeCurrent === 'avatar' ? 'checked' : '' ?> <?= $siteLogoUrl === '' ? 'disabled' : '' ?>> Avatar
                        </label>
                        <label title="<?= $siteBannerUrl === '' ? 'Ajoute d’abord une bannière du site.' : '' ?>">
                            <input type="radio" name="vertical_menu_brand_mode" value="banner" <?= $brandModeCurrent === 'banner' ? 'checked' : '' ?> <?= $siteBannerUrl === '' ? 'disabled' : '' ?>> Bannière
                        </label>
                    </div>
                    <p class="pe-note">Une option sans image n’est pas sélectionnable.</p>
                </div><br>

                <h3>Menu horizontal du header</h3>
                <p class="pe-note">Ajoute une page interne ou un lien externe. L’icône doit venir de la liste.</p>
                <datalist id="dmd-pages-list">
                    <?php foreach ($pagesScan as $pageOption): ?>
                        <option value="/domydesk/<?= htmlspecialchars($pageOption, ENT_QUOTES, 'UTF-8') ?>"></option>
                    <?php endforeach; ?>
                    <option value="/domydesk/dashboard.php"></option>
                    <option value="/domydesk/index.php"></option>
                    <option value="/domydesk/profile_view.php"></option>
                    <option value="/domydesk/login.php"></option>
                    <option value="/domydesk/logout.php"></option>
                    <option value="/domydesk/adm/site_settings.php"></option>
                </datalist>

                <div class="table-wrap">
                    <table class="roles-table">
                        <thead>
                            <tr>
                                <th class="dmd-menu-order-col" title="Glisser pour changer l’ordre">Ordre</th>
                                <th>Titre</th>
                                <th>Emoji</th>
                                <th>Type</th>
                                <th>Page ou lien</th>
                                <th>Supprimer</th>
                            </tr>
                        </thead>
                        <tbody id="dmd-horizontal-menu-body">
                            <?php
                            $menuRows = $settings['menu_horizontal'] ?? dmd_default_horizontal_menu();
                            if (!is_array($menuRows)) $menuRows = dmd_default_horizontal_menu();
                            for ($emptyRow = 0; $emptyRow < 5; $emptyRow++) {
                                $menuRows[] = ['title' => '', 'icon' => '⭐', 'url' => '', 'type' => 'page'];
                            }
                            foreach ($menuRows as $idx => $menuItem):
                                if (!is_array($menuItem)) $menuItem = [];
                                $miTitle = (string)($menuItem['title'] ?? '');
                                $miIcon = (string)($menuItem['icon'] ?? '⭐');
                                $miType = ((string)($menuItem['type'] ?? 'page')) === 'external' ? 'external' : 'page';
                                $miUrl = (string)($menuItem['url'] ?? '');
                            ?>
                                <tr class="dmd-menu-row">
                                    <td class="dmd-menu-order-col">
                                        <button type="button" class="dmd-menu-drag-handle" draggable="true" title="Maintenir et glisser pour déplacer cette ligne" aria-label="Déplacer cette entrée">☰</button>
                                    </td>
                                    <td><input type="text" name="menu_title[<?= (int)$idx ?>]" value="<?= htmlspecialchars($miTitle, ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex : Dashboard"></td>
                                    <td>
                                        <select name="menu_icon[<?= (int)$idx ?>]">
                                            <?php foreach ($dmdHorizontalMenuEmojis as $emoji): ?>
                                                <option value="<?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?>" <?= $emoji === $miIcon ? 'selected' : '' ?>><?= htmlspecialchars($emoji, ENT_QUOTES, 'UTF-8') ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="menu_type[<?= (int)$idx ?>]">
                                            <option value="page" <?= $miType === 'page' ? 'selected' : '' ?>>Page</option>
                                            <option value="external" <?= $miType === 'external' ? 'selected' : '' ?>>Lien externe</option>
                                        </select>
                                    </td>
                                    <td><input type="text" name="menu_url[<?= (int)$idx ?>]" list="dmd-pages-list" value="<?= htmlspecialchars($miUrl, ENT_QUOTES, 'UTF-8') ?>" placeholder="/domydesk/page.php ou https://..."></td>
                                    <td><input type="checkbox" name="menu_delete[<?= (int)$idx ?>]" value="1"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="pe-actions"><button name="save_site">Enregistrer</button></div>
            </form>
        </div>
    </div>
</div>

