<div id="popup-index-settings" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Reglages page d'accueil</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/indexcfg.php" title="Reglages page d'accueil DoMyDesk" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

