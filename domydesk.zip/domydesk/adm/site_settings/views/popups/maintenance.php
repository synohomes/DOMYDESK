<div id="popup-site-maintenance" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Maintenance</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($idDoMyDesk): ?>
                <p class="pe-note">ID DoMyDesk : <strong><?= htmlspecialchars($idDoMyDesk) ?></strong></p>
                <p><a class="btn" href="/domydesk/data/id_domydesk.txt" download>Sauvegarder l’ID</a></p>
            <?php else: ?>
                <p class="pe-note">Aucun ID DoMyDesk trouvé.</p>
            <?php endif; ?>

            <p><a href="../adm/fix_all_rights.php" target="_blank" class="btn">Accorder les permissions</a></p>

            <hr>

            <h3>Synchronisation DomyCo</h3>

            <?php if ($reopenPopup === 'popup-site-maintenance' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Réglage DomyCo enregistré.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-site-maintenance' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">

                <label>
                    <input type="checkbox" name="domyco_heartbeat_enabled" value="1" <?= $heartbeatEnabled ? 'checked' : '' ?>>
                    Activer la synchronisation automatique avec DomyCo
                </label>

                <p class="pe-note">
                    Quand elle est activée, DoMyDesk maintient le heartbeat à <strong>5 minutes</strong> tant qu’une session est ouverte.
                    L’envoi est non bloquant et se relance automatiquement, y compris lorsque vous restez sur le même dashboard.
                </p>

                <div class="pe-actions">
                    <button type="submit" name="save_domyco_heartbeat" value="1">Enregistrer</button>
                </div><br>
            </form>

            <div class="pe-msg">
                <div><strong>État :</strong> <?= $heartbeatEnabled ? 'Activé' : 'Désactivé' ?></div>
                <div><strong>Dernière tentative :</strong> <?= htmlspecialchars($heartbeatLastAttemptText, ENT_QUOTES, 'UTF-8') ?></div>
                <div><strong>Prochaine tentative automatique :</strong> <?= $heartbeatEnabled ? htmlspecialchars($heartbeatNextText, ENT_QUOTES, 'UTF-8') : 'Désactivée' ?></div>
                <?php if ($heartbeatLastAttempt > 0): ?>
                    <div><strong>Dernier résultat :</strong>
                        <?php if (!empty($heartbeatLast['skipped'])): ?>
                            <?= htmlspecialchars((string)($heartbeatLast['reason'] ?? 'Ignoré'), ENT_QUOTES, 'UTF-8') ?>
                        <?php elseif ($heartbeatLastSuccess): ?>
                            OK<?= $heartbeatLastHttp ? ' — HTTP ' . (int)$heartbeatLastHttp : '' ?>
                        <?php else: ?>
                            Échec<?= $heartbeatLastHttp ? ' — HTTP ' . (int)$heartbeatLastHttp : '' ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <form method="post" accept-charset="UTF-8" class="pe-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                <div class="pe-actions">
                    <button type="submit" name="send_domyco_heartbeat_now" value="1">Envoyer maintenant</button>
                </div>
                <p class="pe-note">L’envoi manuel fonctionne même si la synchronisation automatique est désactivée.</p>
            </form>
        </div>
    </div>
</div>

