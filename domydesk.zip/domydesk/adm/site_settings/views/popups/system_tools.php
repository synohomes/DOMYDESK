<?php if ($isSuperadmin): ?>
<div id="popup-system-logs" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Logs système</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="system_logs.php" title="Logs système" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-updates" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Mises à jour système</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="updates.php" title="Mises à jour système" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-module-updates" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2>Mise à jour des modules</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="module_updates.php" title="Mise à jour des modules" style="width:100%;height:78vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>
<?php endif; ?>

