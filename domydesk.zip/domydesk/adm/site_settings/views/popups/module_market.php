<div id="popup-market-inline" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide market-modal">
        <div class="pe-popup-head market-head"><h2>Installer un module</h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/marketmodules.php" title="Market DoMyDesk"></iframe>
        </div>
    </div>
</div>

