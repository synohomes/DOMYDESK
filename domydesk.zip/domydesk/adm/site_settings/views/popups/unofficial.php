<?php if ($isSuperadmin): ?>
<div id="popup-unofficial-themes" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Thèmes non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/unofficial_themes.php" title="Thèmes non officiels" style="width:100%;height:72vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>

<div id="popup-unofficial-modules" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head"><h2><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Modules non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></h2><button type="button" data-popup-close>Fermer</button></div>
        <div class="pe-popup-body market-body">
            <iframe src="../adm/market/unofficial_modules.php" title="Modules non officiels" style="width:100%;height:72vh;border:0;display:block;background:transparent;"></iframe>
        </div>
    </div>
</div>
<?php endif; ?>

