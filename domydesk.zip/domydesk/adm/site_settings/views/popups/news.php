<div id="popup-news" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Actualités</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php include $baseDir . "/data/news/newscfg.php"; ?>
        </div>
    </div>
</div>

