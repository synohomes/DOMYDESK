<div id="popup-theme-market" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Market des themes</h2>
            <div style="display:flex;gap:8px;align-items:center">
                <form method="post" action="?open=popup-theme-market" style="margin:0">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                    <button type="submit" name="refresh_theme_catalog" value="1" title="Rafraîchir immédiatement depuis GitHub">↻ Rafraîchir</button>
                </form>
                <button type="button" data-popup-close>Fermer</button>
            </div>
        </div>

        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-theme-market' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Catalogue rafraîchi.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-theme-market' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>
            <?php if ($themeMarketRaw === false): ?>
                <div class="pe-msg pe-msg-error">Impossible de charger le catalogue des themes : <?= htmlspecialchars($themeMarketWhy) ?></div>

            <?php elseif (!$themeMarketItems): ?>
                <div class="pe-msg pe-msg-error">Catalogue des themes vide ou JSON invalide.</div>

            <?php else: ?>

                <div class="mods-grid theme-market-grid">
                    <?php foreach ($themeMarketItems as $themeItem):
                        if (!is_array($themeItem)) continue;

                        $tmName = trim((string)($themeItem['name'] ?? 'Theme'));
                        $tmDate = trim((string)($themeItem['date'] ?? ''));
                        $tmDesc = trim((string)($themeItem['description'] ?? ''));
                        $tmImage = dmd_theme_github_to_raw((string)($themeItem['image'] ?? ''));
                        $tmDl = dmd_theme_github_to_raw((string)($themeItem['dl'] ?? ''));
                        $tmSize = trim((string)($themeItem['size'] ?? ''));
                        $tmFolder = dmd_theme_folder_from_url($tmDl, $tmName);
                        $tmInstalled = $tmFolder !== '' && in_array($tmFolder, $installedThemes, true);
                    ?>

                        <div class="mod-card theme-market-card">

                            <?php if ($tmImage): ?>
                                <img
                                    src="<?= htmlspecialchars($tmImage, ENT_QUOTES, 'UTF-8') ?>"
                                    alt="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>"
                                    class="mod-thumb theme-market-thumb"
                                    title="Cliquer pour agrandir"
                                    onclick='openThemePreview(
                                        <?= json_encode($tmImage, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>,
                                        <?= json_encode($tmName, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
                                    )'
                                >
                            <?php endif; ?>

                            <div class="mod-meta">
                                <div class="mod-name" title="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>
                                </div>

                                <div class="mod-id">
                                    Dossier : <?= htmlspecialchars($tmFolder ?: '-', ENT_QUOTES, 'UTF-8') ?>
                                    <?php if ($tmDate): ?> · <?= htmlspecialchars($tmDate, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                    <?php if ($tmSize): ?> · <?= htmlspecialchars($tmSize, ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
                                </div>

                                <?php if ($tmDesc): ?>
                                    <p class="pe-note"><?= htmlspecialchars($tmDesc, ENT_QUOTES, 'UTF-8') ?></p>
                                <?php endif; ?>

                                <?php if ($tmInstalled): ?>
                                    <p class="pe-note"><strong>Déjà installé</strong></p>
                                <?php endif; ?>
                            </div>

                            <?php if ($tmDl): ?>
                                <form method="post" accept-charset="UTF-8" class="pe-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_name" value="<?= htmlspecialchars($tmName, ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="hidden" name="theme_dl" value="<?= htmlspecialchars($tmDl, ENT_QUOTES, 'UTF-8') ?>">
                                    <button type="submit" name="install_theme_market" value="1">
                                        <?= $tmInstalled ? 'Réinstaller' : 'Installer' ?>
                                    </button>
                                </form>
                            <?php else: ?>
                                <p class="pe-note">Lien ZIP manquant.</p>
                            <?php endif; ?>

                        </div>

                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-theme-preview" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2 id="theme-preview-title">Aperçu du thème</h2>
            <button type="button" onclick="closeThemePreview()">Fermer</button>
        </div>

        <div class="pe-popup-body theme-preview-body">
            <img id="theme-preview-img" src="" alt="" class="theme-preview-img">
        </div>
    </div>
</div>

