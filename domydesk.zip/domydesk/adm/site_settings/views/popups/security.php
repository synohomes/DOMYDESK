<?php if ($isSuperadmin): ?>
<div id="popup-security-admin" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>🔐 Sécurité & administration</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body">
            <?php if ($reopenPopup === 'popup-security-admin' && ($success || $message)): ?>
                <div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Configuration enregistrée.', ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>
            <?php if ($reopenPopup === 'popup-security-admin' && $errors): ?>
                <div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '<br>'; ?></div>
            <?php endif; ?>

            <?php
                // N'ouvrir que le volet correspondant à l'action réellement effectuée.
                $dmdSecurityRequestedSection = strtolower(trim((string)($_GET['section'] ?? '')));
                $dmdSecurityMfaOpen = (
                    $dmdSecurityRequestedSection === 'mfa'
                    || isset($_POST['save_mfa_policy'])
                    || (string)($_GET['mfa_saved'] ?? '') === '1'
                );
                $dmdSecurityDirectoryOpen = (
                    $dmdSecurityRequestedSection === 'directory'
                    || !empty($dmdDirectoryAction)
                );
                $dmdSecurityDoMySocialOpen = (
                    $dmdSecurityRequestedSection === 'domysocial'
                    || isset($_POST['generate_dms_bridge'])
                    || isset($_POST['revoke_dms_bridge'])
                    || (string)($_GET['dms_bridge_saved'] ?? '') === '1'
                    || (string)($_GET['dms_bridge_revoked'] ?? '') === '1'
                    || $dmdDmsBridgeNewToken !== ''
                );
                $dmdSecurityLicensesOpen = (
                    $dmdSecurityRequestedSection === 'licenses'
                    || isset($_POST['install_dmd_license'])
                    || isset($_POST['remove_dmd_license'])
                    || (string)($_GET['license_saved'] ?? '') === '1'
                    || (string)($_GET['license_removed'] ?? '') === '1'
                );
            ?>
            <div class="dmd-security-accordions" id="dmd-security-accordions">
                <details id="dmd-security-mfa" class="dmd-security-accordion" data-security-section="mfa" <?= $dmdSecurityMfaOpen ? 'open' : '' ?>>
                    <summary>🔐 Identité & MFA</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Politique centrale Microsoft Authenticator. Priorité : <strong>utilisateur → groupe/rôle métier → politique globale</strong>.</p>

                        <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=mfa" class="pe-form" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="save_mfa_policy" value="1">

                            <div class="dmd-security-grid">
                                <div>
                                    <label>Politique globale MFA</label>
                                    <select name="mfa_global_policy">
                                        <option value="optional" <?= ($mfaPolicy['global'] ?? 'optional') === 'optional' ? 'selected' : '' ?>>Facultatif — chaque utilisateur choisit</option>
                                        <option value="required" <?= ($mfaPolicy['global'] ?? '') === 'required' ? 'selected' : '' ?>>Obligatoire — configuration imposée avant accès</option>
                                        <option value="disabled" <?= ($mfaPolicy['global'] ?? '') === 'disabled' ? 'selected' : '' ?>>Désactivé — aucun MFA utilisé à la connexion</option>
                                    </select>
                                </div>
                                <div>
                                    <label>Validations de désactivation</label>
                                    <p class="pe-note"><?= (int)$mfaDisablePendingCount ?> demande(s) en attente.</p>
                                    <a class="btn" href="mfa_requests.php">Gérer les validations MFA</a>
                                </div>
                            </div>

                            <h3>Groupes / rôles métier</h3>
                            <div class="table-wrap">
                                <table class="dmd-security-table">
                                    <thead><tr><th>Groupe / rôle métier</th><th>Politique</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($metiers as $mfaRoleName): ?>
                                        <?php $mfaRoleState = (string)($mfaPolicy['roles'][$mfaRoleName] ?? 'inherit'); ?>
                                        <tr>
                                            <td><?= htmlspecialchars($mfaRoleName, ENT_QUOTES, 'UTF-8') ?></td>
                                            <td>
                                                <select name="mfa_role_policy[<?= htmlspecialchars($mfaRoleName, ENT_QUOTES, 'UTF-8') ?>]">
                                                    <option value="inherit" <?= $mfaRoleState === 'inherit' ? 'selected' : '' ?>>Hériter de la politique globale</option>
                                                    <option value="optional" <?= $mfaRoleState === 'optional' ? 'selected' : '' ?>>Facultatif</option>
                                                    <option value="required" <?= $mfaRoleState === 'required' ? 'selected' : '' ?>>Obligatoire</option>
                                                    <option value="disabled" <?= $mfaRoleState === 'disabled' ? 'selected' : '' ?>>Désactivé</option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <h3>Utilisateurs</h3>
                            <div class="table-wrap">
                                <table class="dmd-security-table">
                                    <thead><tr><th>Utilisateur</th><th>Groupe</th><th>MFA configuré</th><th>Politique effective</th><th>Exception</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($users as $mfaUserMail): ?>
                                        <?php
                                            $mfaUserProfile = $userProfiles[$mfaUserMail] ?? array();
                                            $mfaUserRole = (string)($mfaUserProfile['role_metier'] ?? '');
                                            $mfaUserConfigured = dmd_mfa_enabled($mfaUserMail);
                                            $mfaUserEffective = dmd_mfa_effective_policy($mfaUserMail, $mfaUserProfile);
                                            $mfaUserOverride = (string)($mfaPolicy['users'][$mfaUserMail] ?? 'inherit');
                                            $mfaUserName = trim((string)($mfaUserProfile['prenom'] ?? '') . ' ' . (string)($mfaUserProfile['nom'] ?? ''));
                                        ?>
                                        <tr>
                                            <td><strong><?= htmlspecialchars($mfaUserName !== '' ? $mfaUserName : $mfaUserMail, ENT_QUOTES, 'UTF-8') ?></strong><br><span class="dmd-security-status"><?= htmlspecialchars($mfaUserMail, ENT_QUOTES, 'UTF-8') ?></span></td>
                                            <td><?= htmlspecialchars($mfaUserRole !== '' ? $mfaUserRole : '—', ENT_QUOTES, 'UTF-8') ?></td>
                                            <td><?= $mfaUserConfigured ? '✅ Oui' : '⚪ Non' ?></td>
                                            <td><?= $mfaUserEffective === 'required' ? '🔒 Obligatoire' : ($mfaUserEffective === 'disabled' ? '⛔ Désactivé' : '⚪ Facultatif') ?></td>
                                            <td>
                                                <select name="mfa_user_policy[<?= htmlspecialchars($mfaUserMail, ENT_QUOTES, 'UTF-8') ?>]">
                                                    <option value="inherit" <?= $mfaUserOverride === 'inherit' ? 'selected' : '' ?>>Hériter du groupe/global</option>
                                                    <option value="optional" <?= $mfaUserOverride === 'optional' ? 'selected' : '' ?>>Facultatif</option>
                                                    <option value="required" <?= $mfaUserOverride === 'required' ? 'selected' : '' ?>>Obligatoire</option>
                                                    <option value="disabled" <?= $mfaUserOverride === 'disabled' ? 'selected' : '' ?>>Désactivé</option>
                                                </select>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>

                            <p class="pe-note">Une politique « Désactivé » ne détruit pas le secret Authenticator existant : elle suspend son utilisation. Une politique « Obligatoire » force la configuration du MFA après le mot de passe avant d’ouvrir la session DoMyDesk.</p>

                            <div class="dmd-security-auth">
                                <div>
                                    <label>Mot de passe Superadmin</label>
                                    <input type="password" name="mfa_admin_password" required autocomplete="current-password">
                                </div>
                                <div>
                                    <label>Code MFA Superadmin<?= dmd_mfa_enabled($email) ? '' : ' (non requis : MFA non configuré)' ?></label>
                                    <input type="text" name="mfa_admin_code" <?= dmd_mfa_enabled($email) ? 'required' : '' ?> autocomplete="one-time-code" inputmode="numeric">
                                </div>
                            </div>
                            <div class="pe-actions"><button type="submit" name="save_mfa_policy" value="1">Enregistrer la politique MFA</button></div>
                        </form>
                    </div>
                </details>

                <details id="dmd-security-directory" class="dmd-security-accordion" data-security-section="directory" <?= $dmdSecurityDirectoryOpen ? 'open' : '' ?>>
                    <summary>🏢 Annuaire / Active Directory</summary>
                    <?php require $baseDir . '/adm/directory/directory_config.php'; ?>
                </details>

                <details id="dmd-security-domysocial" class="dmd-security-accordion" data-security-section="domysocial" <?= $dmdSecurityDoMySocialOpen ? 'open' : '' ?>>
                    <summary>🔗 Liaison DoMySocial</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Appaire ce DoMyDesk avec une instance DoMySocial. DoMySocial pourra synchroniser les identités autorisées (profil, avatar, bannière, identité AD et, si activé, MFA), puis conserver sa propre copie locale pour rester autonome.</p>

                        <?php if ($dmdDmsBridgeNewToken !== ''): ?>
                            <div class="pe-msg pe-msg-ok">
                                <strong>🔑 Nouveau code d’appairage</strong><br>
                                Copiez ce code maintenant : il ne sera plus affiché après fermeture ou rechargement.
                            </div>
                            <div class="dmd-dms-bridge-token">
                                <code id="dmdDmsBridgeToken"><?= htmlspecialchars($dmdDmsBridgeNewToken, ENT_QUOTES, 'UTF-8') ?></code>
                                <button type="button" class="btn" onclick="dmdCopyBridgeToken(this)">📋 Copier</button>
                            </div>
                            <p class="pe-note">À coller dans DoMySocial → Administration → Sécurité → Liaison DoMyDesk.</p>
                        <?php endif; ?>

                        <div class="dmd-dms-bridge-grid">
                            <div class="dmd-dms-bridge-box">
                                <h3>Ajouter une instance DoMySocial</h3>
                                <p class="pe-note">Chaque code ajoute une nouvelle instance DoMySocial. Les liaisons déjà actives restent en place. Le code brut n’est pas conservé dans DoMyDesk.</p>
                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=domysocial" class="pe-form" autocomplete="off">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label>Nom de l’instance DoMySocial</label>
                                    <input class="dmd-dms-bridge-label" type="text" name="dms_bridge_label" value="DoMySocial" maxlength="120" placeholder="Ex. Marnaz-City">
                                    <div class="pe-actions"><button type="submit" name="generate_dms_bridge" value="1">🔑 Générer un code d’appairage</button></div>
                                </form>
                            </div>

                            <div class="dmd-dms-bridge-box">
                                <h3>État de la liaison</h3>
                                <div class="dmd-dms-bridge-meta">
                                    <div><span class="pe-note">ID DoMyDesk</span><br><strong><?= htmlspecialchars(dmd_domysocial_bridge_instance_uid() ?: 'Non disponible', ENT_QUOTES, 'UTF-8') ?></strong></div>
                                    <div><span class="pe-note">Instances autorisées</span><br><strong><?= count($dmdDmsBridgeTokens) ?> DoMySocial</strong></div>
                                </div>
                                <?php if ($dmdDmsBridgeTokens): ?>
                                    <div class="dmd-dms-bridge-instance-list">
                                    <?php foreach ($dmdDmsBridgeTokens as $dmdDmsBridgeRow): ?>
                                        <?php
                                          $dmsUid=trim((string)($dmdDmsBridgeRow['dms_instance_uid'] ?? ''));
                                          $dmsName=trim((string)($dmdDmsBridgeRow['dms_instance_name'] ?? ''));
                                          if ($dmsName==='') $dmsName=(string)($dmdDmsBridgeRow['label'] ?? 'DoMySocial');
                                        ?>
                                        <div class="dmd-dms-bridge-instance">
                                          <div class="dmd-dms-bridge-meta">
                                            <div><strong>🌐 <?= htmlspecialchars($dmsName, ENT_QUOTES, 'UTF-8') ?></strong></div>
                                            <div><span class="pe-note">ID unique DoMySocial</span><br><strong><?= htmlspecialchars($dmsUid!==''?$dmsUid:'En attente du premier test depuis DoMySocial', ENT_QUOTES, 'UTF-8') ?></strong></div>
                                            <div class="dmd-security-status">Créé : <?= htmlspecialchars((string)($dmdDmsBridgeRow['created_at'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Appairé : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['paired_at'] ?? '') ?: 'pas encore'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Dernière utilisation : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['last_used_at'] ?? '') ?: 'jamais'), ENT_QUOTES, 'UTF-8') ?></div>
                                            <div class="dmd-security-status">Dernière IP : <?= htmlspecialchars((string)(($dmdDmsBridgeRow['last_ip'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></div>
                                          </div>
                                          <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=domysocial" onsubmit="return confirm('Révoquer uniquement cette liaison DoMySocial ?');">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="dms_bridge_id" value="<?= htmlspecialchars((string)($dmdDmsBridgeRow['id'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                                            <button class="btn dmd-dms-bridge-danger" type="submit" name="revoke_dms_bridge" value="1">🚫 Révoquer cette instance</button>
                                          </form>
                                        </div>
                                    <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="dmd-dms-bridge-empty">Aucune instance DoMySocial n’est actuellement appairée.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="dmd-dms-bridge-box dmd-dms-bridge-spaced">
                            <h3>Ce que permet la liaison</h3>
                            <p class="pe-note">L’API DoMyDesk reste en lecture seule. Selon les options choisies dans DoMySocial, elle peut fournir les utilisateurs, profils, avatars, bannières, informations Active Directory et MFA. Les éléments synchronisés sont ensuite stockés localement dans DoMySocial : une panne de DoMyDesk ne supprime pas les données déjà copiées.</p>
                        </div>
                    </div>
                </details>

                <details id="dmd-security-licenses" class="dmd-security-accordion" data-security-section="licenses" <?= $dmdSecurityLicensesOpen ? 'open' : '' ?>>
                    <summary>🔑 Licences</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">État, droits actifs et installation du fichier <code>.dmdlic</code> signé pour cette instance. Le moteur utilise uniquement <code>var/licenses/current.dmdlic</code>.</p>

                        <div class="dmd-license-summary-grid">
                            <div class="dmd-license-summary-card"><span>État</span><strong class="dmd-license-state"><?= htmlspecialchars(dmd_admin_license_state_label($dmdLicenseStatus['state'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Instance</span><strong><?= htmlspecialchars((string)($dmdLicenseStatus['instance_id'] ?? dmd_license_instance_id() ?: 'Indisponible'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Licence</span><strong><?= htmlspecialchars((string)(($dmdLicenseStatus['license_id'] ?? '') ?: 'Aucune licence signée'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                            <div class="dmd-license-summary-card"><span>Valide jusqu’au</span><strong><?= htmlspecialchars((string)(($dmdLicenseStatus['valid_until'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                        </div>

                        <?php if ((string)($dmdLicenseStatus['source'] ?? '') === 'launch'): ?>
                            <div class="dmd-license-order-note"><strong>🎁 Offre de lancement active jusqu’en janvier 2027.</strong><br><span class="pe-note">Vous pouvez déjà préparer une demande de devis pour les licences et services souhaités.</span></div>
                        <?php elseif ((string)($dmdLicenseStatus['state'] ?? '') === 'license_required'): ?>
                            <div class="dmd-license-order-note"><strong>Licence requise.</strong><br><span class="pe-note">Installez un fichier signé pour réactiver les fonctions commerciales.</span></div>
                        <?php endif; ?>

                        <div class="tablewrap">
                            <table class="dmd-license-products">
                                <thead><tr><th>Produit</th><th>Autorisé</th><th>Quota / droit</th></tr></thead>
                                <tbody>
                                    <tr><td>DMD-Remote</td><td><?= !empty($dmdLicenseAgent['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseAgent['remote_targets_max'] ?? 0, 'PC'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-MyDesk</td><td><?= !empty($dmdLicenseMyDesk['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseMyDesk['modules_max'] ?? 0, 'modules'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-Instances</td><td><?= !empty($dmdLicenseInstances['enabled']) ? 'Oui' : 'Non' ?></td><td><?= htmlspecialchars(dmd_admin_license_quota($dmdLicenseInstances['instances_max'] ?? 0, 'instances'), ENT_QUOTES, 'UTF-8') ?></td></tr>
                                    <tr><td>DMD-Ticketing — Réception Support</td><td><?= !empty($dmdTicketingLicense['enabled']) ? 'Oui' : 'Non' ?></td><td><?= !empty($dmdTicketingLicense['enabled']) ? htmlspecialchars(dmd_admin_license_quota($dmdTicketingLicense['clients_max'] ?? -1, 'clients'), ENT_QUOTES, 'UTF-8') : 'Non activé' ?></td></tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="dmd-license-tools">
                            <div class="dmd-license-box">
                                <h3>Installer / remplacer une licence</h3>
                                <p class="pe-note">La signature Ed25519 et l’ID de cette instance sont contrôlés avant écriture. Une sauvegarde de l’ancienne licence est créée automatiquement.</p>
                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" enctype="multipart/form-data" class="dmd-license-upload">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <input type="file" name="license_file" accept=".dmdlic,application/json" required>
                                    <button type="submit" class="btn" name="install_dmd_license" value="1">📥 Installer</button>
                                </form>
                                <?php if ($dmdLicenseHasSignedFile): ?>
                                    <div class="dmd-license-hash" style="margin-top:9px">SHA-256 : <?= is_file($dmdLicenseEngineFile) ? htmlspecialchars(strtoupper(hash_file('sha256', $dmdLicenseEngineFile)), ENT_QUOTES, 'UTF-8') : '—' ?></div>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" style="margin-top:9px" onsubmit="return confirm('Retirer la licence signée actuelle ? Une sauvegarde sera conservée.');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="btn" name="remove_dmd_license" value="1">🗑️ Retirer la licence</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="dmd-license-box">
                                <h3>Commander des licences</h3>
                                <p class="pe-note">DoMyDesk charge uniquement le barème <code>services.json</code> publié sur GitHub. Le barème est lu directement depuis GitHub.</p>
                                <div class="dmd-license-order-note"><strong>La demande ne constitue pas une vente.</strong><br><span class="pe-note">Un devis sera établi et envoyé par l’association avant toute validation.</span></div>
                                <button class="btn" type="button" data-popup-open="popup-license-order" id="dmdLicenseOrderOpen">🛒 Voir les licences et préparer une demande</button>
                            </div>
                        </div>

                        <?php if ($dmdTicketingAvailable): ?>
                        <div class="dmd-ticketing-license-admin">
                            <div class="dmd-ticketing-license-head">
                                <div>
                                    <h3>🎫 DMD-Ticketing — Récepteur Support</h3>
                                    <p class="pe-note">Cette partie existe sur tous les DoMyDesk mais reste réservée au superadmin. Le DoMyDesk Client n’a besoin d’aucune licence pour envoyer un ticket : il importe uniquement le fichier créé ici par son Support.</p>
                                </div>
                                <span class="dmd-ticketing-license-badge <?= !empty($dmdTicketingLicense['enabled']) ? 'is-ok' : 'is-off' ?>"><?= !empty($dmdTicketingLicense['enabled']) ? ((($dmdTicketingLicense['source'] ?? '') === 'launch') ? 'Lancement gratuit' : 'Licence active') : 'Licence requise' ?></span>
                            </div>

                            <?php if (!empty($dmdTicketingLicense['enabled'])): ?>
                                <div class="dmd-license-order-note">
                                    <strong><?= (($dmdTicketingLicense['source'] ?? '') === 'launch') ? '🎁 Réception gratuite jusqu’au 1er janvier 2027' : '✅ Réception externe autorisée' ?></strong><br>
                                    <span class="pe-note">Entreprises clientes actives : <?= (int)$dmdTicketingActiveClients ?> / <?= $dmdTicketingClientsMax < 0 ? 'Illimité' : (int)$dmdTicketingClientsMax ?>. La période de lancement est limitée à 5 clients.</span>
                                </div>

                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" class="dmd-ticketing-support-form">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                    <label class="dmd-ticketing-switch"><input type="checkbox" name="dmd_ticketing_support_enabled" value="1" <?= !empty($dmdTicketingReceive['enabled']) ? 'checked' : '' ?>> <span>Activer ce DoMyDesk comme récepteur Support</span></label>
                                    <div class="dmd-ticketing-form-grid">
                                        <label><span>Nom de l’entreprise Support</span><input type="text" name="dmd_ticketing_support_name" value="<?= htmlspecialchars((string)($dmdTicketingReceive['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex. SynoHomes" required></label>
                                        <label class="is-wide">
                                            <span>Adresse publique du DoMyDesk Support</span>
                                            <input type="text" name="dmd_ticketing_support_endpoint" value="<?= htmlspecialchars($dmdTicketingSupportBaseUrl, ENT_QUOTES, 'UTF-8') ?>" placeholder="https://support.exemple.fr/domydesk/" required>
                                            <small class="pe-note">Indiquez uniquement l’adresse racine de DoMyDesk, par exemple <code>https://support.exemple.fr/domydesk/</code>. Le chemin DMD-Ticketing est ajouté automatiquement et n’a pas besoin d’être communiqué.</small>
                                        </label>
                                    </div>
                                    <div class="dmd-security-actions"><button type="submit" class="btn" name="dmd_ticketing_support_save" value="1">💾 Enregistrer le récepteur</button></div>
                                </form>

                                <?php if (!empty($dmdTicketingReceive['token'])): ?>
                                <div class="dmd-ticketing-master-key">
                                    <div><strong>Clé maître de liaison</strong><div class="pe-note">Créée une seule fois et conservée chiffrée. Elle est commune aux fichiers clients, mais chaque client possède en plus son propre jeton. Le renouvellement annuel de licence ne change jamais cette clé.</div></div>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Régénérer la clé maître ? Tous les fichiers .dmdticketlink déjà distribués devront être régénérés et réimportés chez les clients.');">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <button type="submit" class="btn" name="dmd_ticketing_support_key_regenerate" value="1">⚠️ Régénérer la clé maître</button>
                                    </form>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($dmdTicketingReceive['enabled'])): ?>
                                <div class="dmd-ticketing-client-create">
                                    <h3>Ajouter une entreprise cliente</h3>
                                    <p class="pe-note">Le Support crée obligatoirement la liaison. Indiquez l’ID unique du DoMyDesk installé chez le client ; le fichier généré sera inutilisable sur une autre instance.</p>
                                    <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" class="dmd-ticketing-form-grid">
                                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                        <label><span>Nom de l’entreprise cliente</span><input type="text" name="dmd_ticketing_client_name" placeholder="Ex. Garage Dupont" required></label>
                                        <label><span>ID unique DoMyDesk client</span><input type="text" name="dmd_ticketing_client_instance" placeholder="DmD-..." required></label>
                                        <div class="is-wide dmd-security-actions"><button type="submit" class="btn" name="dmd_ticketing_client_create" value="1" <?= ($dmdTicketingClientsMax >= 0 && $dmdTicketingActiveClients >= $dmdTicketingClientsMax) ? 'disabled' : '' ?>>➕ Créer le client</button></div>
                                    </form>
                                </div>
                                <?php endif; ?>

                                <div class="dmd-ticketing-clients">
                                    <h3>Entreprises clientes</h3>
                                    <?php if (!$dmdTicketingClients): ?>
                                        <p class="pe-note">Aucune entreprise cliente enregistrée.</p>
                                    <?php else: ?>
                                        <?php foreach ($dmdTicketingClients as $tkClient): $tkStatus=(string)($tkClient['status']??'active'); $tkUid=(string)($tkClient['instance_uid']??''); ?>
                                        <div class="dmd-ticketing-client-row <?= $tkStatus === 'revoked' ? 'is-revoked' : '' ?>">
                                            <div class="dmd-ticketing-client-info">
                                                <strong><?= htmlspecialchars((string)($tkClient['client_name'] ?? $tkUid), ENT_QUOTES, 'UTF-8') ?></strong>
                                                <span><code><?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?></code> · <?= htmlspecialchars((string)($tkClient['client_ref'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
                                                <small><?= $tkStatus === 'revoked' ? 'Révoquée' : 'Active' ?><?= !empty($tkClient['last_seen_at']) ? ' · Dernier contact : '.htmlspecialchars((string)$tkClient['last_seen_at'], ENT_QUOTES, 'UTF-8') : '' ?></small>
                                            </div>
                                            <div class="dmd-security-actions">
                                                <?php if ($tkStatus === 'active'): ?>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_download" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">⬇️ Fichier .dmdticketlink</button>
                                                </form>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Régénérer uniquement le jeton de ce client ? Son ancien fichier cessera de fonctionner.');">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_token_regenerate" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">🔄 Jeton</button>
                                                </form>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses" onsubmit="return confirm('Révoquer cette entreprise cliente ? Ses envois et téléchargements distants seront immédiatement refusés.');">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_revoke" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">🚫 Révoquer</button>
                                                </form>
                                                <?php else: ?>
                                                <form method="post" action="site_settings.php?open=popup-security-admin&amp;section=licenses">
                                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_site_settings'], ENT_QUOTES, 'UTF-8') ?>">
                                                    <button type="submit" class="btn" name="dmd_ticketing_client_reactivate" value="<?= htmlspecialchars($tkUid, ENT_QUOTES, 'UTF-8') ?>">✅ Réactiver</button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="dmd-license-order-note"><strong>Récepteur désactivé.</strong><br><span class="pe-note">L’envoi Client reste gratuit et fonctionnel avec un fichier de liaison valide. Seule la réception Support est soumise à la licence DMD-Ticketing.</span></div>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                            <div class="dmd-license-order-note"><strong>DMD-Ticketing non installé.</strong><br><span class="pe-note">La gestion du récepteur apparaîtra ici lorsque le module DMD-Ticketing sera présent.</span></div>
                        <?php endif; ?>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>🛡️ Droits des modules</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Rôles métier, exceptions utilisateurs et permissions fines des modules.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-module-rights')">Ouvrir les droits des modules</button></div>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>📄 Pages accessibles</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">Accès aux pages par rôle métier et exceptions utilisateurs.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-page-rights')">Ouvrir les pages accessibles</button></div>
                    </div>
                </details>

                <details class="dmd-security-accordion">
                    <summary>🔧 Maintenance</summary>
                    <div class="dmd-security-panel">
                        <p class="pe-note">ID DoMyDesk, permissions et synchronisation DomyCo. La gestion DMD-Agent n’est plus dupliquée ici.</p>
                        <div class="dmd-security-actions"><button type="button" class="btn" onclick="openPopup('popup-site-maintenance')">Ouvrir la maintenance</button></div>
                    </div>
                </details>
            </div>
        </div>
    </div>
</div>

<div id="popup-license-order" class="pe-popup dmd-order-popup" aria-hidden="true" data-catalog-url="https://raw.githubusercontent.com/synohomes/DOMYDESK/refs/heads/main/services.json">
    <div class="pe-popup-window pe-popup-wide dmd-order-window">
        <div class="pe-popup-head">
            <h2>🛒 Licences & services</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>
        <div class="pe-popup-body dmd-order-body">
            <div class="dmd-order-top">
                <div>
                    <strong>Demande de devis</strong>
                    <p class="pe-note">Les tarifs sont lus directement depuis <code>services.json</code> publié sur GitHub. Aucun VPS, aucune redirection et aucun accès à DomyCo ne sont utilisés pour charger cette fenêtre.</p>
                </div>
                <button type="button" class="btn" id="dmdOrderReload">↻ Actualiser les tarifs</button>
            </div>

            <div id="dmdOrderMessage" class="dmd-order-message" hidden></div>
            <div id="dmdOrderLoading" class="dmd-order-loading">Chargement du barème GitHub…</div>

            <div id="dmdOrderContent" hidden>
                <div class="dmd-order-context">
                    <div><span>ID client de la licence</span><strong id="dmdOrderCustomerId"><?= htmlspecialchars((string)(($dmdLicenseStatus['customer_id'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></strong></div>
                    <div><span>Instance DoMyDesk</span><strong id="dmdOrderInstance"><?= htmlspecialchars((string)(($dmdLicenseStatus['instance_id'] ?? '') ?: (dmd_license_instance_id() ?: '—')), ENT_QUOTES, 'UTF-8') ?></strong></div>
                    <div class="dmd-order-profile-field"><span>Profil tarifaire affiché</span><select id="dmdOrderPricingGroup"></select></div>
                </div>

                <div class="dmd-order-layout">
                    <div class="dmd-order-products">
                        <label class="dmd-order-product" data-order-product="instances">
                            <input type="checkbox" class="dmd-order-enable" data-code="instances">
                            <span class="dmd-order-product-text"><strong>DMD-Instances</strong><small>Nombre maximal d’instances DoMyDesk / DoMySocial couvertes.</small><em class="dmd-order-band">—</em></span>
                            <span class="dmd-order-qty"><small>Instances</small><input type="number" min="1" max="100000" value="1" data-order-qty="instances"></span>
                            <span class="dmd-order-price" data-order-price="instances">—</span>
                        </label>
                        <label class="dmd-order-product" data-order-product="remotes">
                            <input type="checkbox" class="dmd-order-enable" data-code="remotes">
                            <span class="dmd-order-product-text"><strong>DMD-Remote</strong><small>Nombre maximal de postes pouvant être pilotés à distance.</small><em class="dmd-order-band">—</em></span>
                            <span class="dmd-order-qty"><small>PC</small><input type="number" min="1" max="100000" value="1" data-order-qty="remotes"></span>
                            <span class="dmd-order-price" data-order-price="remotes">—</span>
                        </label>
                        <label class="dmd-order-product" data-order-product="mydesk">
                            <input type="checkbox" class="dmd-order-enable" data-code="mydesk">
                            <span class="dmd-order-product-text"><strong>DMD-MyDesk</strong><small>Nombre maximal de modules utilisables dans MyDesk.</small><em class="dmd-order-band">—</em></span>
                            <span class="dmd-order-qty"><small>Modules</small><input type="number" min="1" max="100000" value="1" data-order-qty="mydesk"></span>
                            <span class="dmd-order-price" data-order-price="mydesk">—</span>
                        </label>
                        <label class="dmd-order-product" data-order-product="ticketing_external">
                            <input type="checkbox" class="dmd-order-enable" data-code="ticketing_external">
                            <span class="dmd-order-product-text"><strong>DMD-Ticketing — Support externe</strong><small>Quota d’entreprises clientes externes actives autorisées côté Support.</small><em class="dmd-order-band">—</em></span>
                            <span class="dmd-order-qty"><small>Clients</small><input type="number" min="1" max="100000" value="1" data-order-qty="ticketing_external"></span>
                            <span class="dmd-order-price" data-order-price="ticketing_external">—</span>
                        </label>

                        <div class="dmd-order-support">
                            <label><input type="checkbox" id="dmdOrderSupportEnable"> <strong>Ajouter une formule de support</strong></label>
                            <select id="dmdOrderSupport" disabled><option value="none">Aucun support</option></select>
                            <span id="dmdOrderSupportDescription" class="pe-note"></span>
                        </div>

                        <label class="dmd-order-notes"><span>Précision pour le devis <small>(facultatif)</small></span><textarea id="dmdOrderNotes" maxlength="1600" placeholder="Besoin particulier, évolution prévue du nombre de postes, précision sur l’utilisation…"></textarea></label>
                    </div>

                    <aside class="dmd-order-summary">
                        <h3>Récapitulatif</h3>
                        <div id="dmdOrderSummaryLines" class="dmd-order-summary-lines"><div class="pe-note">Aucun service sélectionné.</div></div>
                        <div class="dmd-order-total"><span>Estimation 1re année</span><strong id="dmdOrderFirstTotal">0,00 € HT</strong></div>
                        <div class="dmd-order-renew"><span>Renouvellement estimé</span><strong id="dmdOrderRenewTotal">0,00 € HT/an</strong></div>
                        <div class="dmd-license-order-note"><strong>Un devis sera établi avant validation.</strong><br><span class="pe-note">Les montants affichés proviennent uniquement du barème GitHub et restent une estimation avant devis. Ils ne valent ni facture ni engagement.</span></div>
                        <button type="button" class="btn dmd-order-submit" id="dmdOrderSubmit" disabled>📨 Envoyer ma demande</button>
                        <div class="dmd-order-catalog-meta pe-note" id="dmdOrderCatalogMeta"></div>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

