<?php include $baseDir . '/header.php'; ?>
<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">Administration systeme</h1>
            <p class="pe-subtitle">Gestion du site, des modules, des utilisateurs et des acces.</p>
        </div>
        <div class="dmd-admin-version-stack">
            <div class="pe-user-pill"><?= htmlspecialchars($email ?? 'Utilisateur') ?></div>
            <div class="dmd-version-pill" title="Version lue depuis data/version.txt"><?= htmlspecialchars($dmdVersionLabel) ?></div>
        </div>
    </div>

    <?php if ($success || $message): ?><div class="pe-msg pe-msg-ok"><?= htmlspecialchars($message ?: 'Action effectuée.') ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="pe-msg pe-msg-error"><?php foreach ($errors as $e) echo htmlspecialchars($e) . '<br>'; ?></div><?php endif; ?>

    <h2 class="pe-section-title">Site</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-site-settings">
            <span class="pe-card-main"><span class="pe-card-title">Parametres du site</span><span class="pe-card-desc">Nom, avatar/bannière et menus</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-core-interface">
            <span class="pe-card-main"><span class="pe-card-title">Outils Core & dashboards</span><span class="pe-card-desc">ActionHub, Quick-Session, icônes et limite des bureaux</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='notifications.php'">
            <span class="pe-card-main"><span class="pe-card-title">🔔 Notifications & e-mails</span><span class="pe-card-desc">Activation, SMTP, destinataires et textes des événements</span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-site-maintenance">
            <span class="pe-card-main"><span class="pe-card-title">Maintenance</span><span class="pe-card-desc">ID DoMyDesk et permissions</span></span>
        </button>
        <?php endif; ?>
        <button type="button" class="pe-card" data-popup-open="popup-index-settings">
            <span class="pe-card-main"><span class="pe-card-title">Reglages page d'accueil</span><span class="pe-card-desc">Reglage de l'index du site</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-theme-market">
            <span class="pe-card-main"><span class="pe-card-title">Market des themes</span><span class="pe-card-desc">Aperçus et installation depuis GitHub</span></span>
        </button>
		<button type="button" class="pe-card" data-popup-open="popup-news">
    <span class="pe-card-main">
        <span class="pe-card-title">Actualités</span>
        <span class="pe-card-desc">Configuration des actualités DoMyDesk</span>
    </span>
</button>
        <?php if ($isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-unofficial-themes">
            <span class="pe-card-main"><span class="pe-card-title"><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Thèmes non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></span><span class="pe-card-desc">Installer un thème tiers depuis un ZIP</span></span>
        </button>
        <?php endif; ?>
    </div>

    <h2 class="pe-section-title">Modules</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-market-inline">
            <span class="pe-card-main"><span class="pe-card-title">Installer un module</span><span class="pe-card-desc">Market DoMyDesk</span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-module-rights">
            <span class="pe-card-main"><span class="pe-card-title">Droits sur les modules</span><span class="pe-card-desc">Rôles métier et exceptions utilisateurs</span></span>
        </button>
        <?php endif; ?>
        <?php if ($isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-module-updates">
            <span class="pe-card-main"><span class="pe-card-title">Mise à jour des modules</span><span class="pe-card-desc">Catalogue GitHub ou ZIP manuel</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-unofficial-modules">
            <span class="pe-card-main"><span class="pe-card-title"><span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span> Modules non officiels <span class="dmd-unofficial-emoji" aria-hidden="true">⚠️</span></span><span class="pe-card-desc">Installer un module tiers depuis un ZIP</span></span>
        </button>
        <?php endif; ?>
    </div>

    <h2 class="pe-section-title">Utilisateurs</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-user-add">
            <span class="pe-card-main"><span class="pe-card-title">Ajouter utilisateur</span><span class="pe-card-desc">Creer un compte</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-user-roles">
            <span class="pe-card-main"><span class="pe-card-title">Roles utilisateurs</span><span class="pe-card-desc">Admin/user et metier</span></span>
        </button>
        <?php if (!$isSuperadmin): ?>
        <button type="button" class="pe-card" data-popup-open="popup-page-rights">
            <span class="pe-card-main"><span class="pe-card-title">Pages accessibles</span><span class="pe-card-desc">Rôles métier et exceptions utilisateurs</span></span>
        </button>
        <?php endif; ?>
        <button type="button" class="pe-card" data-popup-open="popup-metiers">
            <span class="pe-card-main"><span class="pe-card-title">Rôles métier</span><span class="pe-card-desc">Création, suppression et rôle par défaut</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='quick_sessions.php'">
            <span class="pe-card-main"><span class="pe-card-title"><?= htmlspecialchars((string)$settings['core_tools']['quick_session']['icon'], ENT_QUOTES, 'UTF-8') ?> Quick-Sessions</span><span class="pe-card-desc">Historique, timeline, mémoire et suppression</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='actionhub.php'">
            <span class="pe-card-main"><span class="pe-card-title"><?= htmlspecialchars((string)$settings['core_tools']['actionhub']['icon'], ENT_QUOTES, 'UTF-8') ?> ActionHub</span><span class="pe-card-desc">Scénarios, création, modification et suppression</span></span>
        </button>
    </div>

    <?php if ($isSuperadmin): ?>
    <h2 class="pe-section-title">Système</h2>
    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-system-logs">
            <span class="pe-card-main"><span class="pe-card-title">📜 Logs système</span><span class="pe-card-desc">Historique des changements du Core, utilisateurs, droits et configuration</span></span>
        </button>
        <button type="button" class="pe-card" onclick="location.href='agent/'">
            <span class="pe-card-main"><span class="pe-card-title">🛡️ DMD-Agent sécurisé</span><span class="pe-card-desc">Identité DoMyDesk, enrôlements, agents et révocations</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-updates">
            <span class="pe-card-main"><span class="pe-card-title">Mises à jour système</span><span class="pe-card-desc">Mises à jour DoMyDesk depuis GitHub ou ZIP manuel</span></span>
        </button>
        <button type="button" class="pe-card" data-popup-open="popup-security-admin">
            <span class="pe-card-main"><span class="pe-card-title">🔐 Sécurité & administration</span><span class="pe-card-desc">MFA, annuaire, licences, liaison DoMySocial, droits et maintenance</span></span>
        </button>
    </div>
    <?php endif; ?>
</div>


