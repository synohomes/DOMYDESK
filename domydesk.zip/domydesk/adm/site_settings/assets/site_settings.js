async function dmdCopyBridgeToken(button) {
    const source = document.getElementById('dmdDmsBridgeToken');
    if (!source) return;
    const value = String(source.textContent || '').trim();
    if (!value) return;

    let copied = false;
    if (navigator.clipboard && window.isSecureContext) {
        try {
            await navigator.clipboard.writeText(value);
            copied = true;
        } catch (e) {}
    }

    if (!copied) {
        const area = document.createElement('textarea');
        area.value = value;
        area.setAttribute('readonly', 'readonly');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        try { copied = document.execCommand('copy'); } catch (e) { copied = false; }
        area.remove();
    }

    if (copied && button) {
        const old = button.textContent;
        button.textContent = '✅ Copié';
        window.setTimeout(() => { button.textContent = old || '📋 Copier'; }, 1400);
    }
}

function dmdRoleModuleRule(role, moduleId) {
    const roleData = ROLE_MODULES[role] || {};
    const modules = roleData.modules || {};
    const rule = modules[moduleId] || {};
    const permissions = Array.isArray(rule.permissions) ? rule.permissions.map(String) : [];
    return {
        enabled: !!rule.enabled,
        permissions: permissions
    };
}

function dmdRoleAllowsModule(role, moduleId) {
    return dmdRoleModuleRule(role, moduleId).enabled;
}

function dmdModuleHasFinePermissions(moduleId) {
    const defs = MODULE_PERMISSION_DEFS[moduleId] || {};
    return Object.keys(defs).length > 0;
}

function dmdRuleHasAllPermissions(rule) {
    return !!(rule && Array.isArray(rule.permissions) && rule.permissions.includes('*'));
}

function dmdUserOverrideRule(user, moduleId) {
    const userRules = USER_MODULE_OVERRIDES[user] || {};
    const rule = userRules[moduleId] || {};
    const state = String(rule.state || 'inherit').toLowerCase();
    return {
        state: ['inherit', 'allow', 'deny'].includes(state) ? state : 'inherit',
        permissions: Array.isArray(rule.permissions) ? rule.permissions.map(String) : []
    };
}

function dmdUserOverrideState(user, moduleId) {
    return dmdUserOverrideRule(user, moduleId).state;
}

function dmdIsGlobalModule(moduleId) {
    const checkbox = document.querySelector(`[data-global-module="${CSS.escape(moduleId)}"]`);
    return !!(checkbox && checkbox.checked);
}

function dmdSetRolePermissionUi(moduleId, rule, enabled, global) {
    const hasFine = dmdModuleHasFinePermissions(moduleId);
    if (!hasFine) return;

    const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
    const permissions = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)];
    const details = document.querySelector(`[data-role-permission-details="${CSS.escape(moduleId)}"]`);
    const allRights = dmdRuleHasAllPermissions(rule);

    if (all) {
        all.checked = enabled && allRights;
        all.disabled = !enabled || global;
    }

    permissions.forEach(input => {
        const permissionId = String(input.dataset.permissionId || '');
        input.checked = enabled && !allRights && rule.permissions.includes(permissionId);
        input.disabled = !enabled || global || allRights;
    });

    if (details) {
        details.disabled = !enabled || global;
        details.classList.toggle('is-disabled', !enabled || global);
    }
}

function dmdLoadRoleModuleRights() {
    const roleSelect = document.getElementById('moduleRightsRole');
    if (!roleSelect) return;
    const selectedRole = roleSelect.value || '';

    document.querySelectorAll('[data-rights-role-module]').forEach(input => {
        const moduleId = input.dataset.rightsRoleModule || '';
        const global = dmdIsGlobalModule(moduleId);
        const rule = dmdRoleModuleRule(selectedRole, moduleId);
        input.checked = rule.enabled;
        input.disabled = global;

        const help = document.querySelector(`[data-role-module-help="${CSS.escape(moduleId)}"]`);
        if (help) {
            help.textContent = global ? 'Déjà autorisé à tout le monde' : 'Autoriser ce rôle à utiliser le module';
        }

        dmdSetRolePermissionUi(moduleId, rule, rule.enabled, global);
    });
}

function dmdReadLiveRoleRule(moduleId) {
    const input = document.querySelector(`[data-rights-role-module="${CSS.escape(moduleId)}"]`);
    if (!input || !input.checked) {
        return { enabled: false, permissions: [] };
    }

    if (!dmdModuleHasFinePermissions(moduleId)) {
        return { enabled: true, permissions: ['*'] };
    }

    const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
    if (all && all.checked) {
        return { enabled: true, permissions: ['*'] };
    }

    const permissions = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)]
        .filter(el => el.checked)
        .map(el => String(el.dataset.permissionId || ''))
        .filter(Boolean);
    return { enabled: true, permissions };
}

function dmdOnRoleAccessChange(input) {
    const moduleId = input.dataset.rightsRoleModule || '';
    const global = dmdIsGlobalModule(moduleId);
    if (input.checked && dmdModuleHasFinePermissions(moduleId)) {
        const all = document.querySelector(`[data-rights-role-all="${CSS.escape(moduleId)}"]`);
        const anyFine = [...document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`)].some(el => el.checked);
        if (all && !all.checked && !anyFine) {
            all.checked = true;
        }
    }
    dmdSetRolePermissionUi(moduleId, dmdReadLiveRoleRule(moduleId), input.checked, global);
    dmdUpdateUserEffectiveRights();
}

function dmdOnRoleAllPermissionsChange(input) {
    const moduleId = input.dataset.rightsRoleAll || '';
    const access = document.querySelector(`[data-rights-role-module="${CSS.escape(moduleId)}"]`);
    if (access && !access.checked) {
        access.checked = true;
    }
    document.querySelectorAll(`[data-rights-role-permission="${CSS.escape(moduleId)}"]`).forEach(el => {
        el.disabled = input.checked || dmdIsGlobalModule(moduleId) || !(access && access.checked);
        if (input.checked) el.checked = false;
    });
    dmdUpdateUserEffectiveRights();
}

function dmdLoadUserModuleOverrides() {
    const userSelect = document.getElementById('moduleRightsUser');
    const saveButton = document.getElementById('saveUserModuleExceptions');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);

    if (saveButton) saveButton.disabled = !selectedUser || isAdminUser;
    document.querySelectorAll('[data-user-save]').forEach(button => {
        button.disabled = !selectedUser || isAdminUser;
    });

    document.querySelectorAll('[data-rights-user-override]').forEach(select => {
        const moduleId = select.dataset.rightsUserOverride || '';
        const rule = selectedUser ? dmdUserOverrideRule(selectedUser, moduleId) : { state: 'inherit', permissions: [] };
        select.value = `${moduleId}|${rule.state}`;
        select.disabled = !selectedUser || isAdminUser;
        dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser);
    });

    dmdUpdateUserEffectiveRights();
}

function dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser) {
    if (!dmdModuleHasFinePermissions(moduleId)) return;
    const allow = !!selectedUser && !isAdminUser && rule.state === 'allow';
    const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
    const permissions = [...document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`)];
    const details = document.querySelector(`[data-user-permission-details="${CSS.escape(moduleId)}"]`);
    const allRights = dmdRuleHasAllPermissions(rule);

    if (all) {
        all.checked = allow && allRights;
        all.disabled = !allow;
    }
    permissions.forEach(input => {
        const permissionId = String(input.dataset.permissionId || '');
        input.checked = allow && !allRights && rule.permissions.includes(permissionId);
        input.disabled = !allow || allRights;
    });
    if (details) details.classList.toggle('is-disabled', !allow);
}

function dmdReadLiveUserRule(moduleId) {
    const select = document.querySelector(`[data-rights-user-override="${CSS.escape(moduleId)}"]`);
    if (!select) return { state: 'inherit', permissions: [] };
    const raw = String(select.value || `${moduleId}|inherit`);
    const splitAt = raw.indexOf('|');
    const state = splitAt >= 0 ? raw.slice(splitAt + 1) : 'inherit';
    if (state !== 'allow') return { state, permissions: [] };

    if (!dmdModuleHasFinePermissions(moduleId)) {
        return { state: 'allow', permissions: ['*'] };
    }

    const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
    if (all && all.checked) return { state: 'allow', permissions: ['*'] };

    const permissions = [...document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`)]
        .filter(el => el.checked)
        .map(el => String(el.dataset.permissionId || ''))
        .filter(Boolean);
    return { state: 'allow', permissions };
}

function dmdOnUserOverrideChange(select) {
    const moduleId = select.dataset.rightsUserOverride || '';
    const userSelect = document.getElementById('moduleRightsUser');
    const selectedUser = userSelect ? userSelect.value : '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const isAdminUser = ['admin', 'superadmin'].includes(String(userMeta.role_system || 'user').toLowerCase());
    let rule = dmdReadLiveUserRule(moduleId);

    if (rule.state === 'allow' && dmdModuleHasFinePermissions(moduleId) && !rule.permissions.length) {
        const all = document.querySelector(`[data-rights-user-all="${CSS.escape(moduleId)}"]`);
        if (all) all.checked = true;
        rule = { state: 'allow', permissions: ['*'] };
    }

    dmdSetUserPermissionUi(moduleId, rule, selectedUser, isAdminUser);
    dmdUpdateUserEffectiveRights();
}

function dmdOnUserAllPermissionsChange(input) {
    const moduleId = input.dataset.rightsUserAll || '';
    document.querySelectorAll(`[data-rights-user-permission="${CSS.escape(moduleId)}"]`).forEach(el => {
        el.disabled = input.checked;
        if (input.checked) el.checked = false;
    });
    dmdUpdateUserEffectiveRights();
}

function dmdPermissionSummary(rule) {
    if (!rule || !rule.enabled) return '';
    if (dmdRuleHasAllPermissions(rule)) return 'tous les droits';
    const count = Array.isArray(rule.permissions) ? rule.permissions.length : 0;
    if (count === 0) return 'accès au module uniquement';
    return count + (count > 1 ? ' actions autorisées' : ' action autorisée');
}

function dmdUpdateUserEffectiveRights() {
    const userSelect = document.getElementById('moduleRightsUser');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const userRole = String(userMeta.role_metier || '');
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);
    const selectedRole = document.getElementById('moduleRightsRole')?.value || '';

    document.querySelectorAll('[data-rights-user-override]').forEach(select => {
        const moduleId = select.dataset.rightsUserOverride || '';
        const effective = document.querySelector(`[data-rights-effective="${CSS.escape(moduleId)}"]`);
        if (!effective) return;

        if (!selectedUser) {
            effective.textContent = 'Sélectionne une personne';
            return;
        }
        if (isAdminUser) {
            effective.textContent = '✓ Administrateur : tous les droits';
            return;
        }

        const liveUserRule = dmdReadLiveUserRule(moduleId);
        if (liveUserRule.state === 'allow') {
            effective.textContent = `✓ Exception personnelle — ${dmdPermissionSummary({ enabled: true, permissions: liveUserRule.permissions })}`;
            return;
        }
        if (liveUserRule.state === 'deny') {
            effective.textContent = '✗ Refusé spécialement pour cette personne';
            return;
        }
        if (dmdIsGlobalModule(moduleId)) {
            effective.textContent = '✓ Autorisé à tout le monde — tous les droits';
            return;
        }

        let roleRule = dmdRoleModuleRule(userRole, moduleId);
        if (userRole && userRole === selectedRole) {
            roleRule = dmdReadLiveRoleRule(moduleId);
        }

        effective.textContent = roleRule.enabled
            ? `✓ Rôle ${userRole} — ${dmdPermissionSummary(roleRule)}`
            : `✗ Non prévu pour le rôle ${userRole || 'de cette personne'}`;
    });
}

function dmdSaveModuleRightsState() {
    const role = document.getElementById('moduleRightsRole')?.value || '';
    const user = document.getElementById('moduleRightsUser')?.value || '';
    try {
        sessionStorage.setItem(MODULE_RIGHTS_STATE_KEY, JSON.stringify({ role, user }));
    } catch (e) {}
}

function dmdRestoreModuleRightsState() {
    let saved = {};
    try {
        saved = JSON.parse(sessionStorage.getItem(MODULE_RIGHTS_STATE_KEY) || '{}') || {};
    } catch (e) {
        saved = {};
    }

    const roleSelect = document.getElementById('moduleRightsRole');
    const userSelect = document.getElementById('moduleRightsUser');

    if (roleSelect && saved.role && [...roleSelect.options].some(option => option.value === saved.role)) {
        roleSelect.value = saved.role;
    }
    if (userSelect && saved.user && [...userSelect.options].some(option => option.value === saved.user)) {
        userSelect.value = saved.user;
    }
}

function dmdRefreshModuleRights() {
    dmdLoadRoleModuleRights();
    dmdLoadUserModuleOverrides();
}

function openPopup(id){ const pop=document.getElementById(id); if(!pop) return; pop.classList.add('is-open'); pop.setAttribute('aria-hidden','false'); document.body.classList.add('noscroll'); }
function closePopup(pop){ if(!pop) return; pop.classList.remove('is-open'); pop.setAttribute('aria-hidden','true'); if(!document.querySelector('.pe-popup.is-open')) document.body.classList.remove('noscroll'); }
function esc(s){ return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#39;'}[m])); }

// Gestion générique des popups de l'administration.
// Toutes les vignettes site_settings utilisent data-popup-open / data-popup-close.
document.querySelectorAll('[data-popup-open]').forEach(btn => {
    btn.addEventListener('click', () => openPopup(btn.dataset.popupOpen));
});

document.querySelectorAll('[data-popup-close]').forEach(btn => {
    btn.addEventListener('click', () => closePopup(btn.closest('.pe-popup')));
});

document.querySelectorAll('.pe-popup').forEach(pop => {
    pop.addEventListener('click', event => {
        if (event.target === pop) closePopup(pop);
    });
});

document.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('.pe-popup.is-open').forEach(pop => closePopup(pop));
});

// Volets de Sécurité & administration : un seul ouvert à la fois.
document.querySelectorAll('#dmd-security-accordions details').forEach(detail => {
    detail.addEventListener('toggle', () => {
        if (!detail.open) return;
        document.querySelectorAll('#dmd-security-accordions details').forEach(other => {
            if (other !== detail) other.open = false;
        });
    });
});

function dmdRoleAllowsPage(role, pageId) {
    const roleData = ROLE_PAGES[role] || {};
    const pages = roleData.pages || {};
    return !!(pages[pageId] && pages[pageId].enabled);
}

function dmdUserPageOverrideState(user, pageId) {
    const userRules = USER_PAGE_OVERRIDES[user] || {};
    const rule = userRules[pageId] || {};
    const state = String(rule.state || 'inherit').toLowerCase();
    return ['inherit', 'allow', 'deny'].includes(state) ? state : 'inherit';
}

function dmdIsGlobalPage(pageId) {
    const checkbox = document.querySelector(`[data-global-page="${CSS.escape(pageId)}"]`);
    return !!(checkbox && checkbox.checked);
}

function dmdLoadRolePageRights() {
    const roleSelect = document.getElementById('pageRightsRole');
    if (!roleSelect) return;
    const selectedRole = roleSelect.value || '';

    document.querySelectorAll('[data-rights-role-page]').forEach(input => {
        const pageId = input.dataset.rightsRolePage || '';
        const global = dmdIsGlobalPage(pageId);
        input.checked = dmdRoleAllowsPage(selectedRole, pageId);
        input.disabled = global;

        const help = document.querySelector(`[data-role-page-help="${CSS.escape(pageId)}"]`);
        if (help) help.textContent = global ? 'Déjà accessible à tout le monde' : 'Autoriser ce rôle';
    });
}

function dmdLoadUserPageOverrides() {
    const userSelect = document.getElementById('pageRightsUser');
    const saveButton = document.getElementById('saveUserPageExceptions');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);

    if (saveButton) saveButton.disabled = !selectedUser || isAdminUser;

    document.querySelectorAll('[data-rights-user-page-override]').forEach(select => {
        const pageId = select.dataset.rightsUserPageOverride || '';
        select.value = selectedUser ? dmdUserPageOverrideState(selectedUser, pageId) : 'inherit';
        select.disabled = !selectedUser || isAdminUser;
    });

    dmdUpdateUserEffectivePageRights();
}

function dmdUpdateUserEffectivePageRights() {
    const userSelect = document.getElementById('pageRightsUser');
    if (!userSelect) return;

    const selectedUser = userSelect.value || '';
    const userMeta = USER_RIGHTS_META[selectedUser] || {};
    const userRole = String(userMeta.role_metier || '');
    const systemRole = String(userMeta.role_system || 'user').toLowerCase();
    const isAdminUser = ['admin', 'superadmin'].includes(systemRole);
    const selectedRole = document.getElementById('pageRightsRole')?.value || '';

    document.querySelectorAll('[data-rights-user-page-override]').forEach(select => {
        const pageId = select.dataset.rightsUserPageOverride || '';
        const effective = document.querySelector(`[data-page-rights-effective="${CSS.escape(pageId)}"]`);
        if (!effective) return;

        if (!selectedUser) {
            effective.textContent = 'Sélectionne une personne';
            return;
        }

        if (isAdminUser) {
            effective.textContent = '✓ Administrateur : toujours autorisé';
            return;
        }

        const state = select.value;
        if (state === 'allow') {
            effective.textContent = '✓ Accessible spécialement pour cette personne';
            return;
        }
        if (state === 'deny') {
            effective.textContent = '✗ Refusée spécialement pour cette personne';
            return;
        }
        if (dmdIsGlobalPage(pageId)) {
            effective.textContent = '✓ Accessible à tout le monde';
            return;
        }

        let roleAllowed = dmdRoleAllowsPage(userRole, pageId);
        if (userRole && userRole === selectedRole) {
            const liveRoleCheckbox = document.querySelector(`[data-rights-role-page="${CSS.escape(pageId)}"]`);
            if (liveRoleCheckbox && !liveRoleCheckbox.disabled) roleAllowed = liveRoleCheckbox.checked;
        }

        effective.textContent = roleAllowed
            ? `✓ Accessible au rôle ${userRole}`
            : `✗ Non prévue pour le rôle ${userRole || 'de cette personne'}`;
    });
}

function dmdSavePageRightsState() {
    const role = document.getElementById('pageRightsRole')?.value || '';
    const user = document.getElementById('pageRightsUser')?.value || '';
    try { sessionStorage.setItem(PAGE_RIGHTS_STATE_KEY, JSON.stringify({ role, user })); } catch (e) {}
}

function dmdRestorePageRightsState() {
    let saved = {};
    try { saved = JSON.parse(sessionStorage.getItem(PAGE_RIGHTS_STATE_KEY) || '{}') || {}; } catch (e) { saved = {}; }

    const roleSelect = document.getElementById('pageRightsRole');
    const userSelect = document.getElementById('pageRightsUser');

    if (roleSelect && saved.role && [...roleSelect.options].some(option => option.value === saved.role)) roleSelect.value = saved.role;
    if (userSelect && saved.user && [...userSelect.options].some(option => option.value === saved.user)) userSelect.value = saved.user;
}

const pageRightsRole = document.getElementById('pageRightsRole');
const pageRightsUser = document.getElementById('pageRightsUser');

dmdRestorePageRightsState();
pageRightsRole?.addEventListener('change', () => {
    dmdSavePageRightsState();
    dmdLoadRolePageRights();
    dmdUpdateUserEffectivePageRights();
});
pageRightsUser?.addEventListener('change', () => {
    dmdSavePageRightsState();
    dmdLoadUserPageOverrides();
});
document.querySelectorAll('[data-global-page]').forEach(el => el.addEventListener('change', () => {
    dmdLoadRolePageRights();
    dmdUpdateUserEffectivePageRights();
}));
document.querySelectorAll('[data-rights-role-page]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectivePageRights));
document.querySelectorAll('[data-rights-user-page-override]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectivePageRights));
['global-page-rights-form', 'role-page-rights-form', 'user-page-exceptions-form'].forEach(formId => {
    document.getElementById(formId)?.addEventListener('submit', dmdSavePageRightsState);
});
dmdLoadRolePageRights();
dmdLoadUserPageOverrides();


function dmdSyncModuleRightsSelectors() {
    const role = document.getElementById('moduleRightsRole')?.value || '';
    const user = document.getElementById('moduleRightsUser')?.value || '';

    document.querySelectorAll('[data-module-role-select]').forEach(select => {
        if ([...select.options].some(option => option.value === role)) select.value = role;
    });
    document.querySelectorAll('[data-module-user-select]').forEach(select => {
        if ([...select.options].some(option => option.value === user)) select.value = user;
        else select.value = '';
    });
}

document.querySelectorAll('[data-module-role-select]').forEach(select => {
    select.addEventListener('change', () => {
        const master = document.getElementById('moduleRightsRole');
        if (!master) return;
        master.value = select.value || '';
        dmdSaveModuleRightsState();
        dmdLoadRoleModuleRights();
        dmdUpdateUserEffectiveRights();
        dmdSyncModuleRightsSelectors();
    });
});

document.querySelectorAll('[data-module-user-select]').forEach(select => {
    select.addEventListener('change', () => {
        const master = document.getElementById('moduleRightsUser');
        if (!master) return;
        master.value = select.value || '';
        dmdSaveModuleRightsState();
        dmdLoadUserModuleOverrides();
        dmdSyncModuleRightsSelectors();
    });
});

const moduleRightsRole = document.getElementById('moduleRightsRole');
const moduleRightsUser = document.getElementById('moduleRightsUser');

dmdRestoreModuleRightsState();

moduleRightsRole?.addEventListener('change', () => {
    dmdSaveModuleRightsState();
    dmdLoadRoleModuleRights();
    dmdUpdateUserEffectiveRights();
});
moduleRightsUser?.addEventListener('change', () => {
    dmdSaveModuleRightsState();
    dmdLoadUserModuleOverrides();
});
document.querySelectorAll('[data-global-module]').forEach(el => el.addEventListener('change', () => {
    dmdLoadRoleModuleRights();
    dmdUpdateUserEffectiveRights();
}));
document.querySelectorAll('[data-rights-role-module]').forEach(el => el.addEventListener('change', () => dmdOnRoleAccessChange(el)));
document.querySelectorAll('[data-rights-role-all]').forEach(el => el.addEventListener('change', () => dmdOnRoleAllPermissionsChange(el)));
document.querySelectorAll('[data-rights-role-permission]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectiveRights));
document.querySelectorAll('[data-rights-user-override]').forEach(el => el.addEventListener('change', () => dmdOnUserOverrideChange(el)));
document.querySelectorAll('[data-rights-user-all]').forEach(el => el.addEventListener('change', () => dmdOnUserAllPermissionsChange(el)));
document.querySelectorAll('[data-rights-user-permission]').forEach(el => el.addEventListener('change', dmdUpdateUserEffectiveRights));

['global-module-rights-form', 'role-module-rights-form', 'user-module-exceptions-form'].forEach(formId => {
    document.getElementById(formId)?.addEventListener('submit', dmdSaveModuleRightsState);
});

dmdRefreshModuleRights();
dmdSyncModuleRightsSelectors();

if (REOPEN_POPUP === 'popup-site-settings') {
    openPopup('popup-site-settings');
}
if (REOPEN_POPUP === 'popup-security-admin') {
    openPopup('popup-security-admin');

    // Si une sous-section de Sécurité est demandée dans l'URL, on l'ouvre
    // explicitement après l'ouverture de la popup. Cela évite de dépendre
    // uniquement du rendu PHP de l'attribut `open`.
    const requestedSecuritySection = new URLSearchParams(window.location.search).get('section') || '';
    if (requestedSecuritySection) {
        window.requestAnimationFrame(() => {
            const wanted = document.querySelector(`#dmd-security-accordions [data-security-section="${CSS.escape(requestedSecuritySection)}"]`);
            if (!wanted) return;
            document.querySelectorAll('#dmd-security-accordions details').forEach(other => {
                if (other !== wanted) other.open = false;
            });
            wanted.open = true;
            window.setTimeout(() => {
                wanted.scrollIntoView({block:'nearest', behavior:'auto'});
            }, 0);
        });
    }
}
if (REOPEN_POPUP === 'popup-module-rights') {
    openPopup('popup-module-rights');
}
if (REOPEN_POPUP === 'popup-page-rights') {
    openPopup('popup-page-rights');
}
if (REOPEN_POPUP === 'popup-site-maintenance') {
    openPopup('popup-site-maintenance');
}
if (REOPEN_POPUP === 'popup-updates') {
    openPopup('popup-updates');
}
if (REOPEN_POPUP === 'popup-system-logs') {
    openPopup('popup-system-logs');
}

function openThemePreview(src, title) {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');
    const headTitle = document.getElementById('theme-preview-title');

    if (!popup || !img || !headTitle) return;

    img.src = src;
    img.alt = title || 'Aperçu du thème';
    headTitle.textContent = title || 'Aperçu du thème';

    popup.classList.add('is-open');
    popup.setAttribute('aria-hidden', 'false');
    document.body.classList.add('noscroll');
}

function closeThemePreview() {
    const popup = document.getElementById('popup-theme-preview');
    const img = document.getElementById('theme-preview-img');

    if (!popup) return;

    popup.classList.remove('is-open');
    popup.setAttribute('aria-hidden', 'true');

    if (img) {
        img.src = '';
        img.alt = '';
    }

    if (!document.querySelector('.pe-popup.is-open')) {
        document.body.classList.remove('noscroll');
    }
}

document.getElementById('popup-theme-preview')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeThemePreview();
    }
});

function dmdRenumberHorizontalMenuRows() {
    const tbody = document.getElementById('dmd-horizontal-menu-body');
    if (!tbody) return;

    [...tbody.querySelectorAll('.dmd-menu-row')].forEach((row, index) => {
        const title = row.querySelector('input[name^="menu_title"]');
        const icon = row.querySelector('select[name^="menu_icon"]');
        const type = row.querySelector('select[name^="menu_type"]');
        const url = row.querySelector('input[name^="menu_url"]');
        const del = row.querySelector('input[name^="menu_delete"]');

        if (title) title.name = `menu_title[${index}]`;
        if (icon) icon.name = `menu_icon[${index}]`;
        if (type) type.name = `menu_type[${index}]`;
        if (url) url.name = `menu_url[${index}]`;
        if (del) del.name = `menu_delete[${index}]`;
    });
}

(function dmdInitHorizontalMenuOrdering() {
    const tbody = document.getElementById('dmd-horizontal-menu-body');
    if (!tbody) return;

    let draggedRow = null;

    const clearDropMarkers = () => {
        tbody.querySelectorAll('.dmd-menu-row').forEach(row => {
            row.classList.remove('dmd-menu-drop-before', 'dmd-menu-drop-after');
        });
    };

    tbody.querySelectorAll('.dmd-menu-drag-handle').forEach(handle => {
        handle.addEventListener('dragstart', event => {
            draggedRow = handle.closest('.dmd-menu-row');
            if (!draggedRow) return;

            draggedRow.classList.add('dmd-menu-dragging');
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', 'dmd-horizontal-menu-row');
        });

        handle.addEventListener('dragend', () => {
            if (draggedRow) draggedRow.classList.remove('dmd-menu-dragging');
            draggedRow = null;
            clearDropMarkers();
            dmdRenumberHorizontalMenuRows();
        });
    });

    tbody.querySelectorAll('.dmd-menu-row').forEach(targetRow => {
        targetRow.addEventListener('dragover', event => {
            if (!draggedRow || targetRow === draggedRow) return;
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';

            clearDropMarkers();
            const rect = targetRow.getBoundingClientRect();
            const before = event.clientY < rect.top + (rect.height / 2);
            targetRow.classList.add(before ? 'dmd-menu-drop-before' : 'dmd-menu-drop-after');
        });

        targetRow.addEventListener('dragleave', () => {
            targetRow.classList.remove('dmd-menu-drop-before', 'dmd-menu-drop-after');
        });

        targetRow.addEventListener('drop', event => {
            if (!draggedRow || targetRow === draggedRow) return;
            event.preventDefault();

            const rect = targetRow.getBoundingClientRect();
            const before = event.clientY < rect.top + (rect.height / 2);

            if (before) {
                tbody.insertBefore(draggedRow, targetRow);
            } else {
                tbody.insertBefore(draggedRow, targetRow.nextSibling);
            }

            clearDropMarkers();
            dmdRenumberHorizontalMenuRows();
        });
    });

    const siteForm = tbody.closest('form');
    siteForm?.addEventListener('submit', dmdRenumberHorizontalMenuRows);
    dmdRenumberHorizontalMenuRows();
})();

(function dmdInitLicenseOrder(){
    const popup=document.getElementById('popup-license-order');
    if(!popup)return;
    const catalogUrl=String(popup.dataset.catalogUrl||'https://raw.githubusercontent.com/synohomes/DOMYDESK/refs/heads/main/services.json');
    const openBtn=document.getElementById('dmdLicenseOrderOpen');
    const reloadBtn=document.getElementById('dmdOrderReload');
    const loading=document.getElementById('dmdOrderLoading');
    const content=document.getElementById('dmdOrderContent');
    const message=document.getElementById('dmdOrderMessage');
    const submit=document.getElementById('dmdOrderSubmit');
    const supportEnable=document.getElementById('dmdOrderSupportEnable');
    const supportSelect=document.getElementById('dmdOrderSupport');
    const supportDescription=document.getElementById('dmdOrderSupportDescription');
    const notes=document.getElementById('dmdOrderNotes');
    const profileSelect=document.getElementById('dmdOrderPricingGroup');
    let state={catalog:null,loaded:false};

    function showMessage(text,type='error'){
        message.hidden=false;
        message.className='dmd-order-message '+(type==='success'?'is-success':'is-error');
        message.textContent=String(text||'');
    }
    function clearMessage(){message.hidden=true;message.textContent='';message.className='dmd-order-message';}
    function money(value,suffix=' HT'){
        if(value===null||value===undefined||value==='')return 'Sur devis';
        const currency=String(state.catalog?.currency||'EUR').toUpperCase();
        const symbol=currency==='EUR'?'€':currency;
        return Number(value).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' '+symbol+suffix;
    }
    function band(rows,quantity){
        const q=Math.max(1,Number(quantity||1));
        return (Array.isArray(rows)?rows:[]).find(row=>q>=Number(row.min||1)&&(row.max===null||row.max===undefined||q<=Number(row.max)))||null;
    }
    function currentProfile(){return String(profileSelect?.value||Object.keys(state.catalog?.profiles||{})[0]||'');}
    function productRows(code){
        if(!state.catalog)return[];
        if(code==='ticketing_external')return state.catalog.ticketing_external?.bands||[];
        const profile=state.catalog.profiles?.[currentProfile()];
        return Array.isArray(profile?.[code])?profile[code]:[];
    }
    function updateSupportDescription(){
        if(!state.catalog||!supportEnable.checked){supportDescription.textContent='';return;}
        const row=(state.catalog.support||[]).find(item=>String(item.id||'')===supportSelect.value);
        supportDescription.textContent=row?String(row.description||''):'';
    }
    function recalc(){
        if(!state.loaded)return;
        let totalFirst=0,totalRenew=0,hasQuoteFirst=false,hasQuoteRenew=false,count=0;
        const lines=[];
        document.querySelectorAll('.dmd-order-enable[data-code]').forEach(box=>{
            const code=String(box.dataset.code||'');
            const card=box.closest('.dmd-order-product');
            const qtyEl=document.querySelector(`[data-order-qty="${CSS.escape(code)}"]`);
            const priceEl=document.querySelector(`[data-order-price="${CSS.escape(code)}"]`);
            const bandEl=card?.querySelector('.dmd-order-band');
            const q=Math.max(1,Math.min(100000,Number(qtyEl?.value||1)));
            if(qtyEl)qtyEl.value=String(q);
            card?.classList.toggle('is-selected',box.checked);
            if(!box.checked){if(priceEl)priceEl.textContent='—';if(bandEl)bandEl.textContent='—';return;}
            count++;
            const row=band(productRows(code),q);
            const productLabel=card?.querySelector('.dmd-order-product-text strong')?.textContent||code;
            if(!row){if(priceEl)priceEl.textContent='Palier introuvable';if(bandEl)bandEl.textContent='—';lines.push({label:productLabel,value:'Palier introuvable'});return;}
            if(bandEl)bandEl.textContent=String(row.label||'');
            const p1=row.first_year_ht===null||row.first_year_ht===''?null:Number(row.first_year_ht||0);
            const pr=row.renewal_ht===null||row.renewal_ht===''?null:Number(row.renewal_ht||0);
            if(p1===null)hasQuoteFirst=true;else totalFirst+=p1;
            if(pr===null)hasQuoteRenew=true;else totalRenew+=pr;
            if(priceEl)priceEl.textContent=p1===null?'Sur devis':money(p1);
            lines.push({label:productLabel+' · '+q,value:p1===null?'Sur devis':money(p1)});
        });
        if(supportEnable.checked){
            const row=(state.catalog.support||[]).find(item=>String(item.id||'')===supportSelect.value);
            if(row){count++;const p=Number(row.price_ht||0);totalFirst+=p;totalRenew+=p;lines.push({label:'Support · '+String(row.label||''),value:money(p)});}
        }
        const summary=document.getElementById('dmdOrderSummaryLines');
        summary.innerHTML='';
        if(!lines.length){const empty=document.createElement('div');empty.className='pe-note';empty.textContent='Aucun service sélectionné.';summary.appendChild(empty);}
        lines.forEach(line=>{const el=document.createElement('div');el.className='dmd-order-summary-line';const a=document.createElement('span');a.textContent=line.label;const b=document.createElement('strong');b.textContent=line.value;el.append(a,b);summary.appendChild(el);});
        document.getElementById('dmdOrderFirstTotal').textContent=hasQuoteFirst?(totalFirst>0?money(totalFirst)+' + sur devis':'Sur devis'):money(totalFirst);
        document.getElementById('dmdOrderRenewTotal').textContent=hasQuoteRenew?(totalRenew>0?money(totalRenew,' HT/an')+' + sur devis':'Sur devis'):money(totalRenew,' HT/an');
        submit.disabled=count===0;
        updateSupportDescription();
    }
    function fillSupport(){
        supportSelect.innerHTML='<option value="none">Aucun support</option>';
        (state.catalog.support||[]).forEach(row=>{const opt=document.createElement('option');opt.value=String(row.id||'');opt.textContent=String(row.label||row.id||'Support')+' — '+money(Number(row.price_ht||0),' HT/an');supportSelect.appendChild(opt);});
        const firstPaid=(state.catalog.support||[]).find(row=>String(row.id||'')!=='autonome')||(state.catalog.support||[])[0];
        if(firstPaid)supportSelect.value=String(firstPaid.id||'none');
    }
    function fillProfiles(){
        profileSelect.innerHTML='';
        Object.entries(state.catalog?.profiles||{}).forEach(([key,row])=>{const opt=document.createElement('option');opt.value=key;opt.textContent=String(row?.label||key);profileSelect.appendChild(opt);});
    }
    function render(){
        fillProfiles();
        document.getElementById('dmdOrderCatalogMeta').textContent='Barème : '+String(state.catalog.source_updated_at||state.catalog.generated_at||'date inconnue')+' · GitHub services.json';
        fillSupport();
        document.querySelectorAll('.dmd-order-enable').forEach(el=>{el.checked=false;});
        document.querySelectorAll('[data-order-qty]').forEach(el=>{el.value='1';});
        supportEnable.checked=false;supportSelect.disabled=true;notes.value='';
        recalc();
    }
    async function load(){
        clearMessage();state.loaded=false;content.hidden=true;loading.hidden=false;loading.textContent='Chargement direct depuis GitHub…';reloadBtn.disabled=true;submit.disabled=true;
        try{
            const response=await fetch(catalogUrl,{method:'GET',headers:{'Accept':'application/json'},cache:'no-store'});
            if(!response.ok)throw new Error('GitHub répond HTTP '+response.status+'.');
            const catalog=await response.json();
            if(!catalog||catalog.schema!=='DMD-SERVICES-CATALOG-V1')throw new Error('services.json est invalide.');
            state.catalog=catalog;state.loaded=true;
            render();content.hidden=false;loading.hidden=true;
        }catch(err){loading.hidden=true;showMessage(err.message||'Impossible de lire services.json sur GitHub.');}
        finally{reloadBtn.disabled=false;}
    }
    function buildText(){
        const rows=[];
        rows.push('Demande de devis DoMyDesk');
        rows.push('Profil : '+(profileSelect.options[profileSelect.selectedIndex]?.text||currentProfile()));
        document.querySelectorAll('.dmd-order-enable[data-code]:checked').forEach(box=>{
            const code=String(box.dataset.code||'');
            const card=box.closest('.dmd-order-product');
            const label=card?.querySelector('.dmd-order-product-text strong')?.textContent||code;
            const qty=document.querySelector(`[data-order-qty="${CSS.escape(code)}"]`)?.value||'1';
            const palier=card?.querySelector('.dmd-order-band')?.textContent||'';
            const prix=document.querySelector(`[data-order-price="${CSS.escape(code)}"]`)?.textContent||'';
            rows.push(label+' : '+qty+' — '+palier+' — '+prix);
        });
        if(supportEnable.checked)rows.push('Support : '+(supportSelect.options[supportSelect.selectedIndex]?.text||''));
        rows.push('Estimation 1re année : '+document.getElementById('dmdOrderFirstTotal').textContent);
        rows.push('Renouvellement estimé : '+document.getElementById('dmdOrderRenewTotal').textContent);
        if(notes.value.trim())rows.push('Précision : '+notes.value.trim());
        return rows.join('\n');
    }
    document.querySelectorAll('.dmd-order-enable').forEach(el=>el.addEventListener('change',recalc));
    document.querySelectorAll('[data-order-qty]').forEach(el=>el.addEventListener('input',recalc));
    supportEnable.addEventListener('change',()=>{supportSelect.disabled=!supportEnable.checked;recalc();});
    supportSelect.addEventListener('change',recalc);
    profileSelect?.addEventListener('change',recalc);
    reloadBtn.addEventListener('click',load);
    openBtn?.addEventListener('click',load);
    submit.addEventListener('click',async()=>{
        if(!state.loaded||submit.disabled)return;
        try{
            await navigator.clipboard.writeText(buildText());
            showMessage('Récapitulatif copié.','success');
        }catch(e){showMessage('Impossible de copier automatiquement le récapitulatif.');}
    });
})();;
