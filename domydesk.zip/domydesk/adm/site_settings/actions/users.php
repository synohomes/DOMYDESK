<?php
    if ($isAdmin && isset($_POST['add_user'])) {
        $prenom = trim($_POST['prenom'] ?? '');
        $nom = trim($_POST['nom'] ?? '');
        $emailNew = trim($_POST['email'] ?? '');
        $roleMetier = trim($_POST['role_metier'] ?? '');
        $roleSystem = trim($_POST['role_system'] ?? 'user');
        $password = $_POST['password'] ?? '';
        if (!$prenom || !$nom || !$emailNew || !$roleMetier || !$password || !$roleSystem) {
            $errors[] = 'Tous les champs utilisateur sont obligatoires.';
        } elseif (!filter_var($emailNew, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email invalide.';
        } elseif (!in_array($roleMetier, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (!in_array($roleSystem, $isSuperadmin ? ['user','admin','superadmin'] : ['user','admin'], true)) {
            $errors[] = 'Rôle système invalide.';
        } elseif (is_dir($profilesDir . $emailNew)) {
            $errors[] = "L'utilisateur existe déjà.";
        } else {
            $folder = $profilesDir . $emailNew . '/';
            @mkdir($folder, 0775, true);
            dmd_write_profile($emailNew, [
                'prenom' => $prenom,
                'nom' => $nom,
                'email' => $emailNew,
                'role_system' => $roleSystem,
                'role_metier' => $roleMetier,
                'motdepasse' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            dmd_write_user_modules_acl($emailNew, dmd_default_user_modules_acl());
            dmd_write_user_pages_acl($emailNew, dmd_default_user_pages_acl());
            dmd_json_write($folder . 'dashboard.json', []);
            dmd_json_write($folder . 'menu.json', []);
            if (is_file($baseDir . '/data/Logo_2025_Mini.png')) {
                $newUserMediaDir = dmd_user_media_dir($emailNew, true);
                if ($newUserMediaDir !== '') {
                    @copy($baseDir . '/data/Logo_2025_Mini.png', $newUserMediaDir . 'avatar.png');
                    @chmod($newUserMediaDir . 'avatar.png', 0664);
                }
            }
            dmd_set_permissions($folder);
            dmd_ensure_private_profile_dir($emailNew);
            @chmod(dmd_profile_path($emailNew, false), 0640);
            @chmod(dmd_modules_acl_path($emailNew, false), 0640);
            @chmod(dmd_pages_acl_path($emailNew, false), 0640);
            $success = true;
            $message = 'Utilisateur ajouté.';
            dmd_notification_index_refresh_user($emailNew);
            dmd_system_log('user_created', $emailNew, 'success', $message, ['prenom' => $prenom, 'nom' => $nom, 'role_system' => $roleSystem, 'role_metier' => $roleMetier]);
            dmd_notify_user($emailNew, 'account_created', 'Votre compte DoMyDesk a été créé', 'Un administrateur a créé votre compte DoMyDesk.', ['level' => 'success', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
        }
    }

    if ($isAdmin && isset($_POST['update_user_roles'])) {
        $userMail = trim($_POST['user_email'] ?? '');
        $roleSys = trim($_POST['new_role_system'] ?? 'user');
        $roleMetier = trim($_POST['new_role_metier'] ?? '');
        $profileFile = dmd_profile_path($userMail, true);
        if (is_file($profileFile)) {
            $data = dmd_json_read($profileFile, []);
            $beforeRoleSystem = (string)($data['role_system'] ?? 'user');
            $beforeRoleMetier = (string)($data['role_metier'] ?? '');
            $currentTargetRole = $beforeRoleSystem;
            $allowedTargetRoles = $isSuperadmin ? ['superadmin','admin','user'] : ['admin','user'];
            $denyRoleChange = false;
            if ($currentTargetRole === 'superadmin' && !$isSuperadmin) {
                $errors[] = 'Un compte Admin ne peut pas modifier un Superadmin.';
                dmd_system_log('superadmin_role_change_denied', $userMail, 'denied', 'Tentative de modification des rôles d’un Superadmin.');
                $denyRoleChange = true;
            }
            if (!$denyRoleChange) {
                if (in_array($roleSys, $allowedTargetRoles, true)) {
                    if ($currentTargetRole === 'superadmin' && $roleSys !== 'superadmin') {
                        $idx = dmd_notification_index();
                        $superadmins = $idx['role_system']['superadmin'] ?? [];
                        if (count($superadmins) <= 1) {
                            $roleSys = 'superadmin';
                            $errors[] = 'Le dernier Superadmin ne peut pas être rétrogradé.';
                        }
                    }
                    $data['role_system'] = $roleSys;
                }
                if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
                dmd_write_profile($userMail, $data);
                dmd_notification_index_refresh_user($userMail);
                $success = true;
                $message = 'Rôles mis à jour.';
                dmd_system_log('user_roles_updated', $userMail, 'success', $message, ['role_system' => $data['role_system'] ?? 'user', 'role_metier' => $data['role_metier'] ?? '']);
                $roleChanges = [];
                if (($data['role_system'] ?? 'user') !== $beforeRoleSystem) {
                    $roleChanges['role_system'] = ['label' => 'Rôle système', 'before' => $beforeRoleSystem, 'after' => (string)($data['role_system'] ?? 'user')];
                }
                if (($data['role_metier'] ?? '') !== $beforeRoleMetier) {
                    $roleChanges['role_metier'] = ['label' => 'Rôle métier', 'before' => $beforeRoleMetier, 'after' => (string)($data['role_metier'] ?? '')];
                }
                dmd_notify_user($userMail, 'profile_changed', 'Vos rôles DoMyDesk ont changé', 'Un administrateur a modifié vos rôles DoMyDesk.', [
                    'level' => 'warning',
                    'action_url' => 'profile_view.php',
                    'action_label' => 'Voir mon profil',
                    'meta' => ['scope' => 'profile', 'target' => $userMail, 'changes' => $roleChanges],
                ]);
            }
        }
    }

    if ($isAdmin && isset($_POST['save_user_roles'])) {
        $roleSystems = $_POST['role_systems'] ?? [];
        $roleMetiers = $_POST['role_metiers'] ?? [];
        if (is_array($roleSystems) && is_array($roleMetiers)) {
            $changedUsers = [];
            foreach ($roleSystems as $userMail => $roleSys) {
                $userMail = trim((string)$userMail);
                $roleSys = trim((string)$roleSys);
                $roleMetier = trim((string)($roleMetiers[$userMail] ?? ''));
                $profileFile = dmd_profile_path($userMail, true);
                if (!is_file($profileFile)) continue;
                $data = dmd_json_read($profileFile, []);
                $beforeSys = $data['role_system'] ?? 'user';
                $beforeMetier = $data['role_metier'] ?? '';
                if ($beforeSys === 'superadmin' && !$isSuperadmin) {
                    continue;
                }
                $allowedTargetRoles = $isSuperadmin ? ['superadmin','admin','user'] : ['admin','user'];
                if (in_array($roleSys, $allowedTargetRoles, true)) {
                    if ($beforeSys === 'superadmin' && $roleSys !== 'superadmin') {
                        $idx = dmd_notification_index();
                        $superadmins = $idx['role_system']['superadmin'] ?? [];
                        if (count($superadmins) <= 1) {
                            $roleSys = 'superadmin';
                        }
                    }
                    $data['role_system'] = $roleSys;
                }
                if (in_array($roleMetier, $metiers, true)) $data['role_metier'] = $roleMetier;
                if (($data['role_system'] ?? 'user') !== $beforeSys || ($data['role_metier'] ?? '') !== $beforeMetier) {
                    dmd_write_profile($userMail, $data);
                    dmd_notification_index_refresh_user($userMail);
                    $changedUsers[] = $userMail;
                    $roleChanges = [];
                    if (($data['role_system'] ?? 'user') !== $beforeSys) {
                        $roleChanges['role_system'] = ['label' => 'Rôle système', 'before' => (string)$beforeSys, 'after' => (string)($data['role_system'] ?? 'user')];
                    }
                    if (($data['role_metier'] ?? '') !== $beforeMetier) {
                        $roleChanges['role_metier'] = ['label' => 'Rôle métier', 'before' => (string)$beforeMetier, 'after' => (string)($data['role_metier'] ?? '')];
                    }
                    dmd_notify_user($userMail, 'profile_changed', 'Vos rôles DoMyDesk ont changé', 'Un administrateur a modifié vos rôles DoMyDesk.', [
                        'level' => 'warning',
                        'action_url' => 'profile_view.php',
                        'action_label' => 'Voir mon profil',
                        'meta' => ['scope' => 'profile', 'target' => $userMail, 'changes' => $roleChanges],
                    ]);
                }
            }
            $success = true;
            $message = 'Rôles utilisateurs enregistrés.';
            dmd_system_log('users_roles_bulk_updated', 'utilisateurs', 'success', $message, ['users' => $changedUsers]);
        }
    }

    if ($isAdmin && isset($_POST['delete_user'])) {
        $userMail = trim($_POST['delete_user'] ?? ($_POST['user_email'] ?? ''));
        $targetProfile = $userMail !== '' ? dmd_read_profile($userMail) : [];
        $targetSystemRole = (string)($targetProfile['role_system'] ?? 'user');
        $idx = dmd_notification_index();
        $superadmins = $idx['role_system']['superadmin'] ?? [];
        if ($targetSystemRole === 'superadmin' && !$isSuperadmin) {
            $errors[] = 'Un compte Admin ne peut pas supprimer un Superadmin.';
            dmd_system_log('superadmin_delete_denied', $userMail, 'denied', 'Tentative de suppression d’un compte Superadmin.');
        } elseif ($targetSystemRole === 'superadmin' && count($superadmins) <= 1) {
            $errors[] = 'Le dernier Superadmin ne peut pas être supprimé.';
        } elseif ($userMail !== '' && $userMail !== $email && is_dir($profilesDir . $userMail)) {
            dmd_remove_dir($profilesDir . $userMail);
            dmd_notification_index_remove_user($userMail);
            $success = true;
            $message = 'Utilisateur supprimé.';
            dmd_system_log('user_deleted', $userMail, 'success', $message, ['prenom' => (string)($targetProfile['prenom'] ?? ''), 'nom' => (string)($targetProfile['nom'] ?? ''), 'role_system' => $targetSystemRole, 'role_metier' => (string)($targetProfile['role_metier'] ?? '')]);
        } else {
            $errors[] = "Impossible de supprimer l'utilisateur courant ou un dossier introuvable.";
        }
    }
