<?php
    if ($isAdmin && isset($_POST['refresh_theme_catalog'])) {
        $reopenPopup = 'popup-theme-market';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Rafraîchissement des thèmes refusé : formulaire expiré ou invalide.';
        } else {
            $refreshError = '';
            $refreshOk = false;
            $themeMarketRawOverride = dmd_source_load_raw($baseDir, 'themes', true, $refreshError, $refreshOk);
            if ($refreshOk) {
                $success = true;
                $message = 'Catalogue des thèmes rafraîchi directement depuis GitHub.';
            } else {
                $errors[] = 'Rafraîchissement GitHub impossible' . ($refreshError !== '' ? ' : ' . $refreshError : '.') . ' Le dernier cache valide est conservé.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_core_interface'])) {
        $reopenPopup = 'popup-core-interface';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des outils Core expiré ou invalide.';
        } else {
            $beforeCoreTools = $settings['core_tools'];
            $beforeDashboardLimit = (int)($settings['dashboard_limit'] ?? 0);

            $settings['core_tools']['actionhub'] = array(
                'enabled' => isset($_POST['actionhub_enabled']),
                'default_location' => dmd_ui_normalize_location($_POST['actionhub_default_location'] ?? 'header', 'header'),
                'icon' => dmd_ui_normalize_icon($_POST['actionhub_icon'] ?? '⚡', '⚡'),
            );
            $settings['core_tools']['quick_session'] = array(
                'enabled' => isset($_POST['quick_session_enabled']),
                'default_location' => dmd_ui_normalize_location($_POST['quick_session_default_location'] ?? 'header', 'header'),
                'icon' => dmd_ui_normalize_icon($_POST['quick_session_icon'] ?? '🚨', '🚨'),
            );
            $settings['dashboard_limit'] = max(0, (int)($_POST['dashboard_limit'] ?? 0));

            if (dmd_json_write($settingsFile, $settings)) {
                $success = true;
                $message = 'Outils Core et limite des dashboards enregistrés.';
                dmd_system_log('core_interface_settings_updated', 'adm/settings.json', 'success', $message, array(
                    'core_tools_before' => $beforeCoreTools,
                    'core_tools_after' => $settings['core_tools'],
                    'dashboard_limit_before' => $beforeDashboardLimit,
                    'dashboard_limit_after' => $settings['dashboard_limit'],
                ));
            } else {
                $errors[] = 'Impossible d’enregistrer les réglages des outils Core.';
            }
        }
    }

    if (isset($_POST['save_site'])) {
        $reopenPopup = 'popup-site-settings';
        $settings['site_name'] = trim((string)($_POST['site_name'] ?? ($settings['site_name'] ?? 'DoMyDesk')));
        if ($settings['site_name'] === '') {
            $settings['site_name'] = 'DoMyDesk';
        }

        $requestedLanguage = trim((string)($_POST['site_language'] ?? ($settings['language'] ?? '')));
        if ($requestedLanguage !== '' && isset($availableLanguages[$requestedLanguage])) {
            $settings['language'] = $requestedLanguage;
        }

        $menuHorizontal = dmd_normalize_horizontal_menu_from_post($_POST, $dmdHorizontalMenuEmojis);
        if ($menuHorizontal) {
            $settings['menu_horizontal'] = $menuHorizontal;
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($menuHorizontal);
        } elseif (!empty($settings['menu_horizontal']) && is_array($settings['menu_horizontal'])) {
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        } else {
            $settings['menu_horizontal'] = dmd_default_horizontal_menu();
            $settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);
        }

        $siteUploadDir = $baseDir . '/adm/uploads/';
        if (!is_dir($siteUploadDir)) @mkdir($siteUploadDir, 0775, true);

        if (!empty($_POST['remove_site_logo'])) {
            dmd_media_remove_named($siteUploadDir, 'logo');
            $settings['logo_path'] = '';
        }

        if (!empty($_POST['remove_site_banner'])) {
            dmd_media_remove_named($siteUploadDir, 'banner');
            $settings['banner_path'] = '';
        }

        if (!empty($_FILES['logo']) && ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $storedLogo = dmd_media_store_upload($_FILES['logo'], $siteUploadDir, 'logo', true);
            if (!empty($storedLogo['success'])) {
                $settings['logo_path'] = 'uploads/' . basename((string)$storedLogo['file']);
            } else {
                $errors[] = (string)($storedLogo['error'] ?? "Impossible d'envoyer l'avatar/logo du site.");
            }
        }

        if (!empty($_FILES['site_banner']) && ($_FILES['site_banner']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $storedBanner = dmd_media_store_upload($_FILES['site_banner'], $siteUploadDir, 'banner', true);
            if (!empty($storedBanner['success'])) {
                $settings['banner_path'] = 'uploads/' . basename((string)$storedBanner['file']);
            } else {
                $errors[] = (string)($storedBanner['error'] ?? "Impossible d'envoyer la bannière du site.");
            }
        }

        $brandMode = trim((string)($_POST['vertical_menu_brand_mode'] ?? 'none'));
        if (!in_array($brandMode, array('none', 'avatar', 'banner'), true)) {
            $brandMode = 'none';
        }
        $hasSiteAvatar = dmd_site_asset_file($settings, 'logo_path') !== '';
        $hasSiteBanner = dmd_site_asset_file($settings, 'banner_path') !== '';
        if (($brandMode === 'avatar' && !$hasSiteAvatar) || ($brandMode === 'banner' && !$hasSiteBanner)) {
            $brandMode = 'none';
        }
        $settings['vertical_menu_brand_mode'] = $brandMode;

        if (!$errors && dmd_json_write($settingsFile, $settings)) {
            $success = true;
            $message = 'Paramètres du site enregistrés.';
            $changes = [];
            if (($settingsBeforePost['site_name'] ?? '') !== ($settings['site_name'] ?? '')) {
                $changes['site_name'] = ['avant' => $settingsBeforePost['site_name'] ?? '', 'apres' => $settings['site_name'] ?? ''];
            }
            if (($settingsBeforePost['language'] ?? '') !== ($settings['language'] ?? '')) {
                $changes['language'] = ['avant' => $settingsBeforePost['language'] ?? '', 'apres' => $settings['language'] ?? ''];
            }
            if (($settingsBeforePost['menu_horizontal'] ?? []) !== ($settings['menu_horizontal'] ?? [])) {
                $changes['menu_horizontal'] = ['avant_count' => count($settingsBeforePost['menu_horizontal'] ?? []), 'apres_count' => count($settings['menu_horizontal'] ?? [])];
            }
            if (($settingsBeforePost['logo_path'] ?? '') !== ($settings['logo_path'] ?? '')) {
                $changes['logo_path'] = ['avant' => $settingsBeforePost['logo_path'] ?? '', 'apres' => $settings['logo_path'] ?? ''];
            }
            if (($settingsBeforePost['banner_path'] ?? '') !== ($settings['banner_path'] ?? '')) {
                $changes['banner_path'] = ['avant' => $settingsBeforePost['banner_path'] ?? '', 'apres' => $settings['banner_path'] ?? ''];
            }
            if (($settingsBeforePost['vertical_menu_brand_mode'] ?? 'none') !== ($settings['vertical_menu_brand_mode'] ?? 'none')) {
                $changes['vertical_menu_brand_mode'] = ['avant' => $settingsBeforePost['vertical_menu_brand_mode'] ?? 'none', 'apres' => $settings['vertical_menu_brand_mode'] ?? 'none'];
            }
            dmd_system_log('site_settings_updated', 'adm/settings.json', 'success', 'Paramètres du site enregistrés.', $changes);
        }
    }

    if ($isAdmin && isset($_POST['save_domyco_heartbeat'])) {
        $reopenPopup = 'popup-site-maintenance';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire DomyCo expiré ou invalide.';
        } else {
            $settings['domyco_heartbeat_enabled'] = isset($_POST['domyco_heartbeat_enabled']);
            $settings['domyco_heartbeat_interval'] = 300;

            if (dmd_json_write($settingsFile, $settings)) {
                $success = true;
                $message = !empty($settings['domyco_heartbeat_enabled'])
                    ? 'Synchronisation DomyCo activée : un heartbeat toutes les 5 minutes.'
                    : 'Synchronisation DomyCo désactivée.';
                dmd_system_log('domyco_heartbeat_setting', 'DomyCo', 'success', $message, ['enabled' => !empty($settings['domyco_heartbeat_enabled'])]);
            } else {
                $errors[] = 'Impossible d’enregistrer le réglage DomyCo.';
            }
        }
    }

    if ($isAdmin && isset($_POST['send_domyco_heartbeat_now'])) {
        $reopenPopup = 'popup-site-maintenance';
        $token = $_POST['csrf_token'] ?? '';

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire DomyCo expiré ou invalide.';
        } elseif (!is_file($heartbeatFile)) {
            $errors[] = 'Fichier data/domyco_heartbeat.php introuvable.';
        } else {
            require_once $heartbeatFile;

            if (!function_exists('dmd_hb_run')) {
                $errors[] = 'Moteur heartbeat DomyCo indisponible.';
            } else {
                $heartbeatManualResult = dmd_hb_run(true, $baseDir);

                if (!empty($heartbeatManualResult['success'])) {
                    $success = true;
                    $message = 'Synchronisation DomyCo envoyée manuellement.';
                    dmd_system_log('domyco_heartbeat_manual', 'DomyCo', 'success', $message);
                } else {
                    $errors[] = 'Échec de la synchronisation DomyCo : '
                        . (($heartbeatManualResult['curl_error'] ?? '') ?: ($heartbeatManualResult['error'] ?? 'erreur inconnue'));
                }
            }
        }
    }

