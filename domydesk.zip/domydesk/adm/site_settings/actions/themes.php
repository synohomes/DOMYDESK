<?php
    if ($isAdmin && isset($_POST['install_theme_market'])) {
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire thème expiré ou invalide.';
        } else {
            $themeName = trim((string)($_POST['theme_name'] ?? ''));
            $themeDl = dmd_theme_github_to_raw(trim((string)($_POST['theme_dl'] ?? '')));
            $themeFolder = dmd_theme_folder_from_url($themeDl, $themeName);

            if ($themeDl === '' || $themeFolder === '') {
                $errors[] = 'Thème invalide.';
            } elseif (!class_exists('ZipArchive')) {
                $errors[] = 'ZipArchive n’est pas disponible sur le serveur.';
            } else {
                $zipTmp = rtrim($themeUploadDir, '/') . '/' . $themeFolder . '.zip';
                $tmpExtract = rtrim($themeUploadDir, '/') . '/extract_' . $themeFolder . '_' . time() . '/';
                $targetThemeDir = rtrim($themesDir, '/') . '/' . $themeFolder . '/';
                $why = '';

                if (!dmd_theme_http_download($themeDl, $zipTmp, $why)) {
                    $errors[] = 'Téléchargement du thème impossible : ' . $why;
                } else {
                    $zip = new ZipArchive();
                    if ($zip->open($zipTmp) === true) {
                        if (dmd_theme_safe_extract_zip($zip, $tmpExtract, $errors) && dmd_theme_normalize_extract($tmpExtract)) {
                            $zip->close();
                            @unlink($zipTmp);

                            if (is_dir($targetThemeDir)) dmd_remove_dir($targetThemeDir);

                            if (@rename($tmpExtract, $targetThemeDir)) {
                                dmd_set_permissions($targetThemeDir);
                                $success = true;
                                $message = 'Thème installé : ' . $themeFolder;
                                dmd_system_log('theme_installed', $themeFolder, 'success', $message);
                            } else {
                                $errors[] = 'Impossible de placer le thème dans le dossier /theme/.';
                                dmd_remove_dir($tmpExtract);
                            }
                        } else {
                            $zip->close();
                            @unlink($zipTmp);
                            dmd_remove_dir($tmpExtract);
                            if (!$errors) $errors[] = 'Le ZIP du thème ne contient pas de style.css utilisable.';
                        }
                    } else {
                        @unlink($zipTmp);
                        $errors[] = 'Impossible d’ouvrir le ZIP du thème.';
                    }
                }
            }
        }
    }

