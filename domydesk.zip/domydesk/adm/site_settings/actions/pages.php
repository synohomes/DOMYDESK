<?php
    if ($isAdmin && isset($_POST['save_global_page_rights'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $globalPages = isset($_POST['global_pages']) && is_array($_POST['global_pages'])
            ? array_values(array_map('strval', $_POST['global_pages']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } else {
            $pageAccessModes = [];
            foreach ($permissionPages as $pageId => $pageInfo) {
                $pageAccessModes[$pageId] = in_array($pageId, $globalPages, true) ? 'everyone' : 'controlled';
            }

            if (dmd_set_page_access_modes($pageAccessModes)) {
                $pageRightsData = dmd_read_pages_access();
                $success = true;
                $message = 'Pages accessibles à tout le monde enregistrées.';
                dmd_system_log('global_page_rights_updated', 'pages', 'success', $message, ['global_pages' => $globalPages]);
                dmd_notify_all('permissions_changed', 'Accès aux pages modifiés', 'Les règles globales d’accès aux pages DoMyDesk ont été mises à jour.', ['level' => 'warning']);
            } else {
                $errors[] = 'Impossible d’enregistrer les droits globaux des pages.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_role_page_rights'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsRole = trim((string)($_POST['page_rights_role'] ?? ''));
        $rolePages = isset($_POST['role_pages']) && is_array($_POST['role_pages'])
            ? array_values(array_map('strval', $_POST['role_pages']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } elseif (!in_array($rightsRole, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (dmd_set_role_pages($rightsRole, $rolePages)) {
            $pageRightsData = dmd_read_pages_access();
            $success = true;
            $message = 'Pages du rôle ' . $rightsRole . ' enregistrées.';
            dmd_system_log('role_page_permissions_updated', $rightsRole, 'success', $message, ['pages' => $rolePages]);
            dmd_notify_metier($rightsRole, 'permissions_changed', 'Vos accès aux pages ont changé', 'Les pages autorisées pour votre rôle métier ont été mises à jour.', ['level' => 'warning']);
        } else {
            $errors[] = 'Impossible d’enregistrer les pages de ce rôle.';
        }
    }

    if ($isAdmin && isset($_POST['save_user_page_exceptions'])) {
        $reopenPopup = 'popup-page-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsUser = trim((string)($_POST['page_rights_user'] ?? ''));
        $userOverrides = isset($_POST['page_overrides']) && is_array($_POST['page_overrides'])
            ? $_POST['page_overrides']
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des pages expiré ou invalide.';
        } elseif ($rightsUser === '' || !is_dir($profilesDir . $rightsUser)) {
            $errors[] = 'Utilisateur invalide.';
        } else {
            $rightsUserProfile = dmd_read_profile($rightsUser);
            if (dmd_is_system_admin_profile($rightsUserProfile)) {
                $success = true;
                $message = 'Un administrateur possède déjà toutes les pages DoMyDesk.';
            } elseif (dmd_replace_user_page_overrides($rightsUser, $userOverrides)) {
                $success = true;
                $message = 'Exceptions de pages de ' . $rightsUser . ' enregistrées.';
                dmd_system_log('user_page_permissions_updated', $rightsUser, 'success', $message, ['overrides' => $userOverrides]);
                dmd_notify_user($rightsUser, 'permissions_changed', 'Vos accès aux pages ont changé', 'Un administrateur a modifié vos exceptions individuelles d’accès aux pages.', ['level' => 'warning']);
            } else {
                $errors[] = 'Impossible d’enregistrer les exceptions de pages de cet utilisateur.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_default_role'])) {
        $defaultRole = trim((string)($_POST['default_registration_role'] ?? ''));

        if (dmd_set_default_registration_role($defaultRole)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle par défaut des nouvelles inscriptions enregistré.';
            dmd_system_log('default_business_role_updated', $defaultRole, 'success', $message);
        } else {
            $errors[] = 'Rôle par défaut invalide.';
        }
    }

