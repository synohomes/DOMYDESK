<?php
    if ($isSuperadmin && $dmdTicketingAvailable && (
        isset($_POST['dmd_ticketing_support_save']) || isset($_POST['dmd_ticketing_support_key_regenerate']) ||
        isset($_POST['dmd_ticketing_client_create']) || isset($_POST['dmd_ticketing_client_revoke']) ||
        isset($_POST['dmd_ticketing_client_reactivate']) || isset($_POST['dmd_ticketing_client_token_regenerate']) ||
        isset($_POST['dmd_ticketing_client_download'])
    )) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'DMD-Ticketing : formulaire expiré ou invalide.';
        } else {
            try {
                $tkLicense = dmdtk_external_license_status();
                if (empty($tkLicense['enabled'])) throw new RuntimeException('Licence DMD-Ticketing Support requise pour administrer le récepteur.');
                $tkCfg = dmdtk_config();
                $tkReceive = isset($tkCfg['external_receive']) && is_array($tkCfg['external_receive']) ? $tkCfg['external_receive'] : array();

                if (isset($_POST['dmd_ticketing_support_save'])) {
                    $supportName = trim((string)($_POST['dmd_ticketing_support_name'] ?? ''));
                    $supportBaseUrl = trim((string)($_POST['dmd_ticketing_support_endpoint'] ?? ''));
                    $enabledRequested = !empty($_POST['dmd_ticketing_support_enabled']);
                    if ($supportName === '') throw new RuntimeException('Indiquez le nom de l’entreprise Support.');
                    if ($supportBaseUrl === '') throw new RuntimeException('Indiquez l’adresse publique de DoMyDesk.');
                    $endpoint = dmd_admin_ticketing_endpoint_from_base($supportBaseUrl);
                    if ($endpoint === '') throw new RuntimeException('Adresse publique DoMyDesk invalide.');
                    $globalKey = trim((string)($tkReceive['token'] ?? ''));
                    if ($globalKey === '') $globalKey = bin2hex(random_bytes(32));
                    $nextReceive = array('enabled'=>$enabledRequested,'name'=>$supportName,'endpoint'=>$endpoint,'token'=>$globalKey,'owner'=>$email);
                    $saved = dmdtk_save_config($tkCfg['categories'] ?? array(), $tkCfg['priorities'] ?? array(), $email, array('external_support'=>$tkCfg['external_support'] ?? array(),'external_receive'=>$nextReceive));
                    if ($saved === false) throw new RuntimeException('Impossible d’enregistrer la configuration du récepteur.');
                    dmdtk_log($email, 'receiver_configure', 'config', 'success', array('endpoint'=>$endpoint,'enabled'=>$enabledRequested));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_saved=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_support_key_regenerate'])) {
                    $tkReceive['token'] = bin2hex(random_bytes(32));
                    if (trim((string)($tkReceive['owner'] ?? '')) === '') $tkReceive['owner'] = $email;
                    $saved = dmdtk_save_config($tkCfg['categories'] ?? array(), $tkCfg['priorities'] ?? array(), $email, array('external_support'=>$tkCfg['external_support'] ?? array(),'external_receive'=>$tkReceive));
                    if ($saved === false) throw new RuntimeException('Impossible de régénérer la clé Support.');
                    dmdtk_log($email, 'receiver_key_regenerate', 'config', 'warning', array());
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_client_create'])) {
                    $clientName = trim((string)($_POST['dmd_ticketing_client_name'] ?? ''));
                    $clientInstance = trim((string)($_POST['dmd_ticketing_client_instance'] ?? ''));
                    $created = dmdtk_external_client_create($clientName, $clientInstance, $email);
                    if (empty($created['ok'])) {
                        $err = (string)($created['error'] ?? 'CLIENT_CREATE_FAILED');
                        if ($err === 'CLIENT_LIMIT_REACHED') throw new RuntimeException('Limite de la licence atteinte : ' . (int)($created['clients_max'] ?? 0) . ' entreprises clientes actives maximum.');
                        if ($err === 'CLIENT_ALREADY_EXISTS') throw new RuntimeException('Cette instance DoMyDesk est déjà enregistrée comme cliente.');
                        throw new RuntimeException('Création du client impossible : ' . $err);
                    }
                    dmdtk_log($email, 'external_client_create', $clientInstance, 'success', array('client_name'=>$clientName));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_client_created=1'); exit;
                }

                foreach (array('dmd_ticketing_client_revoke'=>'revoked','dmd_ticketing_client_reactivate'=>'active') as $field=>$status) {
                    if (isset($_POST[$field])) {
                        $clientInstance = trim((string)$_POST[$field]);
                        $result = dmdtk_external_client_set_status($clientInstance, $status, $email);
                        if (empty($result['ok'])) {
                            if (($result['error'] ?? '') === 'CLIENT_LIMIT_REACHED') throw new RuntimeException('Impossible de réactiver : quota de clients atteint.');
                            throw new RuntimeException('Impossible de modifier cette entreprise cliente.');
                        }
                        dmdtk_log($email, $status==='revoked'?'external_client_revoke':'external_client_reactivate', $clientInstance, 'success', array());
                        header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                    }
                }

                if (isset($_POST['dmd_ticketing_client_token_regenerate'])) {
                    $clientInstance = trim((string)$_POST['dmd_ticketing_client_token_regenerate']);
                    $result = dmdtk_external_client_regenerate_token($clientInstance, $email);
                    if (empty($result['ok'])) throw new RuntimeException('Impossible de régénérer le jeton de cette entreprise.');
                    dmdtk_log($email, 'external_client_token_regenerate', $clientInstance, 'warning', array());
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&ticketing_action_done=1'); exit;
                }

                if (isset($_POST['dmd_ticketing_client_download'])) {
                    $clientInstance = trim((string)$_POST['dmd_ticketing_client_download']);
                    $link = dmdtk_link_export_raw($clientInstance);
                    if (empty($link['ok'])) throw new RuntimeException('Impossible de générer le fichier de liaison : ' . (string)($link['error'] ?? 'erreur inconnue'));
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . str_replace('"','',(string)$link['filename']) . '"');
                    header('Cache-Control: no-store');
                    echo (string)$link['raw']; exit;
                }
            } catch (Throwable $e) {
                $errors[] = 'DMD-Ticketing : ' . $e->getMessage();
            }
        }
    }

    if ($isSuperadmin && (isset($_POST['install_dmd_license']) || isset($_POST['remove_dmd_license']))) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Licence refusée : formulaire expiré ou invalide.';
        } else {
            try {
                $licenseInstanceId = dmd_license_instance_id();
                if ($licenseInstanceId === '') throw new RuntimeException('ID DoMyDesk introuvable.');
                if (!dmd_license_init_storage()) throw new RuntimeException('Impossible d’initialiser var/licenses/.');
                $licenseEngineFile = dmd_license_file();

                if (isset($_POST['install_dmd_license'])) {
                    if (!isset($_FILES['license_file']) || !is_array($_FILES['license_file'])) throw new RuntimeException('Aucun fichier de licence reçu.');
                    $upload = $_FILES['license_file'];
                    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Erreur d’envoi du fichier .dmdlic (code ' . (int)($upload['error'] ?? -1) . ').');
                    if (($upload['size'] ?? 0) <= 0 || ($upload['size'] ?? 0) > 1024 * 1024) throw new RuntimeException('Taille du fichier de licence invalide.');
                    $uploadName = (string)($upload['name'] ?? '');
                    if (strtolower(pathinfo($uploadName, PATHINFO_EXTENSION)) !== 'dmdlic') throw new RuntimeException('Le fichier doit être un .dmdlic.');
                    $raw = @file_get_contents((string)$upload['tmp_name']);
                    if ($raw === false || trim($raw) === '') throw new RuntimeException('Impossible de lire le fichier envoyé.');

                    $incoming = dmd_license_verify_raw($raw, $licenseInstanceId);
                    if (empty($incoming['ok']) || empty($incoming['verified'])) {
                        throw new RuntimeException('Licence refusée : ' . (string)($incoming['error'] ?? 'signature ou instance invalide'));
                    }

                    if (is_file($licenseEngineFile)) {
                        $backup = dirname($licenseEngineFile) . '/previous-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.dmdlic';
                        if (!@copy($licenseEngineFile, $backup)) throw new RuntimeException('Impossible de sauvegarder la licence actuelle avant remplacement.');
                        @chmod($backup, 0640);
                    }

                    $install = dmd_license_install_raw($raw);
                    if (empty($install['ok'])) throw new RuntimeException('Installation impossible : ' . (string)($install['error'] ?? 'erreur inconnue'));
                    if (!is_file($licenseEngineFile)) throw new RuntimeException('Le moteur n’a pas créé var/licenses/current.dmdlic.');

                    $writtenRaw = (string)@file_get_contents($licenseEngineFile);
                    $written = dmd_license_verify_raw($writtenRaw, $licenseInstanceId);
                    if (empty($written['ok']) || empty($written['verified'])) throw new RuntimeException('La licence écrite dans var/licenses est invalide.');
                    if ((string)($written['license_id'] ?? '') !== (string)($incoming['license_id'] ?? '')) throw new RuntimeException('Contrôle après écriture : license_id différent.');

                    $legacyFile = $baseDir . '/data/.dmd-license/current.dmdlic';
                    if (is_file($legacyFile)) {
                        $legacyArchive = dirname($legacyFile) . '/OBSOLETE-current-' . gmdate('Ymd-His') . '.dmdlic';
                        @rename($legacyFile, $legacyArchive);
                        @chmod($legacyArchive, 0640);
                    }

                    dmd_system_log('license_installed', (string)($written['license_id'] ?? 'licence'), 'success', 'Licence signée installée depuis Sécurité & administration.', array(
                        'updated_by' => $email,
                        'instance_id' => $licenseInstanceId,
                        'revision' => (int)($written['revision'] ?? 0),
                    ));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&license_saved=1');
                    exit;
                }

                if (isset($_POST['remove_dmd_license'])) {
                    if (is_file($licenseEngineFile)) {
                        $backup = dirname($licenseEngineFile) . '/removed-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.dmdlic';
                        if (!@copy($licenseEngineFile, $backup)) throw new RuntimeException('Impossible de sauvegarder la licence avant retrait.');
                        @chmod($backup, 0640);
                        if (!@unlink($licenseEngineFile)) throw new RuntimeException('Impossible de retirer var/licenses/current.dmdlic.');
                    }
                    dmd_system_log('license_removed', $licenseInstanceId, 'warning', 'Licence signée retirée depuis Sécurité & administration.', array('updated_by' => $email));
                    header('Location: site_settings.php?open=popup-security-admin&section=licenses&license_removed=1');
                    exit;
                }
            } catch (Throwable $e) {
                $errors[] = $e->getMessage();
            }
        }
    }
    if ($isSuperadmin && (isset($_POST['generate_dms_bridge']) || isset($_POST['revoke_dms_bridge']))) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Liaison DoMySocial refusée : formulaire expiré ou invalide.';
        } elseif (isset($_POST['generate_dms_bridge'])) {
            $label = trim((string)($_POST['dms_bridge_label'] ?? 'DoMySocial'));
            if ($label === '') $label = 'DoMySocial';
            if (function_exists('mb_substr')) $label = mb_substr($label, 0, 120, 'UTF-8');
            else $label = substr($label, 0, 120);
            $generated = dmd_domysocial_bridge_generate_token($label);
            if ($generated === false) {
                $errors[] = 'Impossible de générer le code d’appairage DoMySocial.';
            } else {
                $_SESSION['dmd_dms_bridge_new_token'] = (string)($generated['token'] ?? '');
                dmd_system_log('domysocial_bridge_created', 'DoMySocial', 'warning', 'Nouvel appairage DoMySocial créé.', array(
                    'updated_by' => $email,
                    'label' => $label,
                    'bridge_id' => (string)($generated['id'] ?? ''),
                ));
                header('Location: site_settings.php?open=popup-security-admin&section=domysocial&dms_bridge_saved=1');
                exit;
            }
        } elseif (isset($_POST['revoke_dms_bridge'])) {
            $bridgeId=trim((string)($_POST['dms_bridge_id'] ?? ''));
            $revokedRow=null;
            foreach ($dmdDmsBridgeTokens as $row) {
                if (is_array($row) && hash_equals((string)($row['id'] ?? ''),$bridgeId)) { $revokedRow=$row; break; }
            }
            if ($bridgeId!=='' && dmd_domysocial_bridge_revoke_token($bridgeId)) {
                dmd_system_log('domysocial_bridge_revoked', 'DoMySocial', 'warning', 'Liaison DoMySocial révoquée.', array(
                    'updated_by' => $email,
                    'bridge_id' => $bridgeId,
                    'domysocial_uid' => (string)($revokedRow['dms_instance_uid'] ?? ''),
                    'label' => (string)($revokedRow['label'] ?? 'DoMySocial'),
                ));
                header('Location: site_settings.php?open=popup-security-admin&section=domysocial&dms_bridge_revoked=1');
                exit;
            }
            $errors[] = 'Impossible de révoquer cette liaison DoMySocial.';
        }
        $dmdDmsBridgeCfg = dmd_domysocial_bridge_read();
        $dmdDmsBridgeTokens = isset($dmdDmsBridgeCfg['tokens']) && is_array($dmdDmsBridgeCfg['tokens']) ? $dmdDmsBridgeCfg['tokens'] : array();
    }

    if ($isSuperadmin && isset($_POST['save_mfa_policy'])) {
        $reopenPopup = 'popup-security-admin';
        $token = $_POST['csrf_token'] ?? '';
        $password = (string)($_POST['mfa_admin_password'] ?? '');
        $adminCode = trim((string)($_POST['mfa_admin_code'] ?? ''));
        $hash = (string)($profileData['motdepasse'] ?? ($profileData['password'] ?? ''));

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Politique MFA refusée : formulaire expiré ou invalide.';
        } elseif ($hash === '' || !password_verify($password, $hash)) {
            $errors[] = 'Politique MFA refusée : mot de passe Superadmin incorrect.';
        } else {
            $adminMfaOk = true;
            if (dmd_mfa_enabled($email)) {
                $usedRecovery = false;
                $adminMfaOk = dmd_mfa_verify_user_code($email, $adminCode, $usedRecovery);
                if (!$adminMfaOk) $errors[] = 'Politique MFA refusée : code MFA Superadmin incorrect.';
            }

            if ($adminMfaOk) {
                $newPolicy = array(
                    'global' => dmd_mfa_policy_normalize_state($_POST['mfa_global_policy'] ?? 'optional', false),
                    'roles' => array(),
                    'users' => array(),
                );

                $rolePolicies = isset($_POST['mfa_role_policy']) && is_array($_POST['mfa_role_policy']) ? $_POST['mfa_role_policy'] : array();
                foreach ($metiers as $roleName) {
                    $state = dmd_mfa_policy_normalize_state($rolePolicies[$roleName] ?? 'inherit', true);
                    if ($state !== 'inherit') $newPolicy['roles'][$roleName] = $state;
                }

                $userPolicies = isset($_POST['mfa_user_policy']) && is_array($_POST['mfa_user_policy']) ? $_POST['mfa_user_policy'] : array();
                foreach ($userPolicies as $userMailRaw => $stateRaw) {
                    $userMail = dmd_safe_user_key((string)$userMailRaw);
                    if ($userMail === '' || !is_file(dmd_profile_path($userMail, false))) continue;
                    $state = dmd_mfa_policy_normalize_state($stateRaw, true);
                    if ($state !== 'inherit') $newPolicy['users'][$userMail] = $state;
                }

                $beforePolicy = dmd_mfa_policy_read();
                if (dmd_mfa_policy_write($newPolicy, $email)) {
                    $mfaPolicy = dmd_mfa_policy_read();

                    $expectedRoles = $newPolicy['roles'];
                    $expectedUsers = $newPolicy['users'];
                    $savedRoles = isset($mfaPolicy['roles']) && is_array($mfaPolicy['roles']) ? $mfaPolicy['roles'] : array();
                    $savedUsers = isset($mfaPolicy['users']) && is_array($mfaPolicy['users']) ? $mfaPolicy['users'] : array();
                    ksort($expectedRoles, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($expectedUsers, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($savedRoles, SORT_NATURAL | SORT_FLAG_CASE);
                    ksort($savedUsers, SORT_NATURAL | SORT_FLAG_CASE);

                    $savedExactly = (($mfaPolicy['global'] ?? 'optional') === $newPolicy['global'])
                        && ($savedRoles === $expectedRoles)
                        && ($savedUsers === $expectedUsers);

                    if (!$savedExactly) {
                        $errors[] = 'Échec de sécurité : la politique MFA écrite ne correspond pas à la politique relue.';
                    } else {
                        $success = true;
                        $message = 'Politique MFA centrale enregistrée.';
                        dmd_system_log('mfa_policy_updated', 'MFA', 'warning', $message, array(
                            'updated_by' => $email,
                            'before' => $beforePolicy,
                            'after' => $mfaPolicy,
                            'storage' => dmd_mfa_policy_path(),
                        ));

                        if (dmd_mfa_enabled($email)) {
                            $_SESSION['dmd_mfa_authenticated_at'] = time();
                        }

                        $effectiveForAdmin = dmd_mfa_effective_policy($email, $profileData);
                        if ($effectiveForAdmin === 'required' && !dmd_mfa_enabled($email)) {
                            header('Location: ../mfa_setup.php?required=1&policy_saved=1');
                            exit;
                        }

                        header('Location: site_settings.php?open=popup-security-admin&mfa_saved=1');
                        exit;
                    }
                } else {
                    $errors[] = 'Impossible d’enregistrer la politique MFA centrale. Vérifiez les droits d’écriture de var/security ou data/secure/mfa.';
                }
            }
        }
    }
