<?php
    if ($isAdmin && isset($_POST['delete_module'])) {
        $mod = basename((string)$_POST['delete_module']);
        $notificationIndexBeforeDelete = dmd_notification_index();
        $affectedModuleUsers = isset($notificationIndexBeforeDelete['modules'][$mod]) && is_array($notificationIndexBeforeDelete['modules'][$mod])
            ? $notificationIndexBeforeDelete['modules'][$mod]
            : [];
        if (!$isSuperadmin) {
            $errors[] = 'La suppression d’un module est réservée au Superadmin.';
            dmd_system_log('module_delete_denied', $mod, 'denied', 'Tentative de suppression de module avec un compte Admin.');
        } elseif ($mod !== '' && dmd_remove_dir($baseDir . '/modules/' . $mod)) {
            $success = true;
            $message = 'Module supprimé.';
            dmd_system_log('module_deleted', $mod, 'success', $message);
            dmd_notify_many($affectedModuleUsers, 'module_removed', 'Un module que vous utilisiez a été supprimé', 'Le module ' . $mod . ' a été supprimé de cette instance DoMyDesk par un Superadmin.', ['level' => 'warning']);
            dmd_notification_build_index();
        } else {
            $errors[] = 'Impossible de supprimer ce module.';
            dmd_system_log('module_delete_failed', $mod, 'error', 'Impossible de supprimer le module.');
        }
    }

    if ($isAdmin && isset($_POST['add_metier'])) {
        $new = trim($_POST['new_metier'] ?? '');
        if ($new !== '' && !in_array($new, $metiers, true)) {
            $metiers[] = $new;
            sort($metiers, SORT_NATURAL | SORT_FLAG_CASE);
            dmd_json_write($rolesFile, array_values($metiers));
            $metiers = dmd_roles_catalog();
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle ajouté.';
            dmd_system_log('business_role_added', $new, 'success', $message);
        }
    }

    if ($isAdmin && isset($_POST['delete_metier'])) {
        $del = trim($_POST['del_metier'] ?? '');
        if ($del !== '') {
            $metiers = array_values(array_filter($metiers, fn($m) => $m !== $del));
            dmd_json_write($rolesFile, $metiers);
            $metiers = dmd_roles_catalog();
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Rôle supprimé.';
            dmd_system_log('business_role_deleted', $del, 'success', $message);
        }
    }

    if ($isAdmin && isset($_POST['save_module_access_modes'])) {
        $moduleAccessModes = isset($_POST['module_access_mode']) && is_array($_POST['module_access_mode'])
            ? $_POST['module_access_mode']
            : [];

        if (dmd_set_module_access_modes($moduleAccessModes)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Modes d’accès des modules enregistrés.';
            dmd_system_log('module_access_modes_updated', 'modules', 'success', $message);
        } else {
            $errors[] = 'Impossible d’enregistrer les modes d’accès des modules.';
        }
    }

    if ($isAdmin && isset($_POST['save_role_modules'])) {
        $roleAccess = trim((string)($_POST['access_role'] ?? ''));
        $roleModules = isset($_POST['role_modules']) && is_array($_POST['role_modules'])
            ? $_POST['role_modules']
            : [];

        if (!in_array($roleAccess, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } elseif (dmd_set_role_modules($roleAccess, $roleModules)) {
            $rolesModulesData = dmd_read_roles_modules();
            $success = true;
            $message = 'Modules du rôle enregistrés.';
            dmd_system_log('role_modules_updated', $roleAccess, 'success', $message, ['modules' => array_values($roleModules)]);
            dmd_notify_metier($roleAccess, 'permissions_changed', 'Vos accès modules ont changé', 'Les modules autorisés pour votre rôle métier ont été modifiés.', ['level' => 'warning', 'action_url' => 'profile_edit.php', 'action_label' => 'Voir mon profil']);
        } else {
            $errors[] = 'Impossible d’enregistrer les modules du rôle.';
        }
    }

    if ($isAdmin && isset($_POST['save_global_module_rights'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $globalModules = isset($_POST['global_modules']) && is_array($_POST['global_modules'])
            ? array_values(array_map('strval', $_POST['global_modules']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } else {
            $moduleAccessModes = [];
            foreach ($permissionModules as $moduleId => $moduleInfo) {
                $moduleAccessModes[$moduleId] = in_array($moduleId, $globalModules, true) ? 'everyone' : 'controlled';
            }

            if (dmd_set_module_access_modes($moduleAccessModes)) {
                $rolesModulesData = dmd_read_roles_modules();
                $success = true;
                $message = 'Modules accessibles à tout le monde enregistrés.';
                dmd_system_log('global_module_rights_updated', 'modules', 'success', $message, ['global_modules' => $globalModules]);
                dmd_notify_all('permissions_changed', 'Accès aux modules modifiés', 'Les règles globales d’accès aux modules DoMyDesk ont été mises à jour.', ['level' => 'warning', 'action_url' => 'profile_edit.php', 'action_label' => 'Voir mes modules']);
            } else {
                $errors[] = 'Impossible d’enregistrer les droits globaux.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_role_module_rights'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsRole = trim((string)($_POST['rights_role'] ?? ''));
        $roleModules = isset($_POST['role_modules']) && is_array($_POST['role_modules'])
            ? array_values(array_map('strval', $_POST['role_modules']))
            : [];
        $roleAllModules = isset($_POST['role_all_modules']) && is_array($_POST['role_all_modules'])
            ? array_values(array_map('strval', $_POST['role_all_modules']))
            : [];
        $rolePermissionTokens = isset($_POST['role_permission_tokens']) && is_array($_POST['role_permission_tokens'])
            ? array_values(array_map('strval', $_POST['role_permission_tokens']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } elseif (!in_array($rightsRole, $metiers, true)) {
            $errors[] = 'Rôle métier invalide.';
        } else {
            $permissionMap = [];
            foreach ($rolePermissionTokens as $tokenValue) {
                $parts = explode('|', $tokenValue, 2);
                if (count($parts) !== 2) {
                    continue;
                }
                $moduleId = trim((string)$parts[0]);
                $permissionId = trim((string)$parts[1]);
                if ($moduleId === '' || $permissionId === '') {
                    continue;
                }
                if (!isset($permissionMap[$moduleId])) {
                    $permissionMap[$moduleId] = [];
                }
                $permissionMap[$moduleId][] = $permissionId;
            }

            $rules = [];
            foreach ($roleModules as $moduleId) {
                $moduleId = trim((string)$moduleId);
                if ($moduleId === '' || !isset($permissionModules[$moduleId])) {
                    continue;
                }

                $definitions = $modulePermissionDefinitions[$moduleId] ?? [];
                if (empty($definitions) || in_array($moduleId, $roleAllModules, true)) {
                    $permissions = ['*'];
                } else {
                    $permissions = $permissionMap[$moduleId] ?? [];
                }

                $rules[$moduleId] = [
                    'enabled' => true,
                    'permissions' => $permissions,
                ];
            }

            $roleRulesBefore = isset($rolesModulesData['roles'][$rightsRole]['modules']) && is_array($rolesModulesData['roles'][$rightsRole]['modules'])
                ? $rolesModulesData['roles'][$rightsRole]['modules']
                : array();

            if (dmd_set_role_module_rules($rightsRole, $rules)) {
                $rolesModulesData = dmd_read_roles_modules();
                $roleRulesAfter = isset($rolesModulesData['roles'][$rightsRole]['modules']) && is_array($rolesModulesData['roles'][$rightsRole]['modules'])
                    ? $rolesModulesData['roles'][$rightsRole]['modules']
                    : array();
                $roleRightsChanges = dmd_role_module_rights_notification_changes($roleRulesBefore, $roleRulesAfter, $permissionModules, $modulePermissionDefinitions);
                $success = true;
                $message = 'Droits fins du rôle ' . $rightsRole . ' enregistrés.';
                dmd_system_log('role_module_permissions_updated', $rightsRole, 'success', $message, ['rules' => $rules, 'changes' => $roleRightsChanges]);
                if ($roleRightsChanges) {
                    dmd_notify_metier(
                        $rightsRole,
                        'permissions_changed',
                        'Vos droits sur les modules ont changé',
                        count($roleRightsChanges) . ' module(s) ont été modifié(s) pour votre rôle métier.',
                        [
                            'level' => 'warning',
                            'action_url' => 'profile_edit.php',
                            'action_label' => 'Voir mes accès',
                            'meta' => [
                                'scope' => 'modules',
                                'role_metier' => $rightsRole,
                                'changes' => $roleRightsChanges,
                            ],
                        ]
                    );
                }
            } else {
                $errors[] = 'Impossible d’enregistrer les droits de ce rôle.';
            }
        }
    }

    if ($isAdmin && isset($_POST['save_user_module_exceptions'])) {
        $reopenPopup = 'popup-module-rights';
        $token = $_POST['csrf_token'] ?? '';
        $rightsUser = trim((string)($_POST['rights_user'] ?? ''));
        $overrideStateTokens = isset($_POST['user_override_state']) && is_array($_POST['user_override_state'])
            ? array_values(array_map('strval', $_POST['user_override_state']))
            : [];
        $userAllModules = isset($_POST['user_all_modules']) && is_array($_POST['user_all_modules'])
            ? array_values(array_map('strval', $_POST['user_all_modules']))
            : [];
        $userPermissionTokens = isset($_POST['user_permission_tokens']) && is_array($_POST['user_permission_tokens'])
            ? array_values(array_map('strval', $_POST['user_permission_tokens']))
            : [];

        if (!is_string($token) || !hash_equals($_SESSION['csrf_site_settings'] ?? '', $token)) {
            $errors[] = 'Formulaire des droits expiré ou invalide.';
        } elseif ($rightsUser === '' || !is_dir($profilesDir . $rightsUser)) {
            $errors[] = 'Utilisateur invalide.';
        } else {
            $rightsUserProfile = dmd_read_profile($rightsUser);
            if (dmd_is_system_admin_profile($rightsUserProfile)) {
                $success = true;
                $message = 'Un administrateur possède déjà tous les droits sur les modules.';
            } else {
                $stateMap = [];
                foreach ($overrideStateTokens as $stateToken) {
                    $parts = explode('|', $stateToken, 2);
                    if (count($parts) !== 2) {
                        continue;
                    }
                    $moduleId = trim((string)$parts[0]);
                    $state = strtolower(trim((string)$parts[1]));
                    if ($moduleId !== '' && in_array($state, ['inherit', 'allow', 'deny'], true)) {
                        $stateMap[$moduleId] = $state;
                    }
                }

                $permissionMap = [];
                foreach ($userPermissionTokens as $tokenValue) {
                    $parts = explode('|', $tokenValue, 2);
                    if (count($parts) !== 2) {
                        continue;
                    }
                    $moduleId = trim((string)$parts[0]);
                    $permissionId = trim((string)$parts[1]);
                    if ($moduleId === '' || $permissionId === '') {
                        continue;
                    }
                    if (!isset($permissionMap[$moduleId])) {
                        $permissionMap[$moduleId] = [];
                    }
                    $permissionMap[$moduleId][] = $permissionId;
                }

                $rules = [];
                foreach ($permissionModules as $moduleId => $moduleInfo) {
                    $state = $stateMap[$moduleId] ?? 'inherit';
                    if ($state === 'inherit') {
                        continue;
                    }

                    $permissions = [];
                    if ($state === 'allow') {
                        $definitions = $modulePermissionDefinitions[$moduleId] ?? [];
                        if (empty($definitions) || in_array($moduleId, $userAllModules, true)) {
                            $permissions = ['*'];
                        } else {
                            $permissions = $permissionMap[$moduleId] ?? [];
                        }
                    }

                    $rules[$moduleId] = [
                        'state' => $state,
                        'permissions' => $permissions,
                    ];
                }

                $userAclBefore = dmd_read_user_modules_acl($rightsUser);

                if (dmd_replace_user_module_overrides_detailed($rightsUser, $rules)) {
                    $userAclAfter = dmd_read_user_modules_acl($rightsUser);
                    $userRightsChanges = dmd_user_module_rights_notification_changes($userAclBefore, $userAclAfter, $permissionModules, $modulePermissionDefinitions);
                    $success = true;
                    $message = 'Exceptions fines de ' . $rightsUser . ' enregistrées.';
                    dmd_notification_index_refresh_user($rightsUser);
                    dmd_system_log('user_module_permissions_updated', $rightsUser, 'success', $message, ['rules' => $rules, 'changes' => $userRightsChanges]);
                    if ($userRightsChanges) {
                        dmd_notify_user(
                            $rightsUser,
                            'permissions_changed',
                            'Vos droits sur les modules ont changé',
                            count($userRightsChanges) . ' module(s) ont été modifié(s) par un administrateur.',
                            [
                                'level' => 'warning',
                                'action_url' => 'profile_edit.php',
                                'action_label' => 'Voir mes accès',
                                'meta' => [
                                    'scope' => 'modules',
                                    'target' => $rightsUser,
                                    'changes' => $userRightsChanges,
                                ],
                            ]
                        );
                    }
                } else {
                    $errors[] = 'Impossible d’enregistrer les exceptions de cet utilisateur.';
                }
            }
        }
    }

