<?php
$settings = dmd_ui_settings_with_defaults(dmd_json_read($settingsFile, []));

$availableLanguages = [];
if (is_dir($languagesDir)) {
    foreach (scandir($languagesDir) ?: [] as $languageFolder) {
        if ($languageFolder === '.' || $languageFolder === '..' || str_starts_with($languageFolder, '.')) {
            continue;
        }

        $languagePath = rtrim($languagesDir, "/\\") . '/' . $languageFolder;
        if (!is_dir($languagePath)) {
            continue;
        }

        // Le nom affiché et la valeur enregistrée correspondent directement
        // au nom réel du dossier présent dans /lang/.
        $availableLanguages[$languageFolder] = $languageFolder;
    }
}
uksort($availableLanguages, 'strnatcasecmp');

$currentLanguage = (string)($settings['language'] ?? '');
if ($currentLanguage === '' || !isset($availableLanguages[$currentLanguage])) {
    $currentLanguage = $availableLanguages ? (string)array_key_first($availableLanguages) : '';
}
$settings['language'] = $currentLanguage;
if (!array_key_exists('banner_path', $settings)) {
    $settings['banner_path'] = '';
}
if (!array_key_exists('vertical_menu_brand_mode', $settings)) {
    $settings['vertical_menu_brand_mode'] = 'none';
}
if (!array_key_exists('domyco_heartbeat_enabled', $settings)) {
    $settings['domyco_heartbeat_enabled'] = true;
}
$settings['domyco_heartbeat_interval'] = 300;
$metiers = dmd_roles_catalog();
require_once $baseDir . '/adm/directory/directory_actions.php';
$mfaPolicy = dmd_mfa_policy_read();
$rolesModulesData = dmd_read_roles_modules();
$permissionModules = dmd_installed_modules();
$modulePermissionDefinitions = [];
foreach ($permissionModules as $modulePermissionId => $modulePermissionInfo) {
    $modulePermissionDefinitions[$modulePermissionId] = dmd_module_permission_definitions($modulePermissionId);
}
$pageCatalog = dmd_page_catalog();
$pageRightsData = dmd_read_pages_access();
$alwaysPages = array_filter($pageCatalog, fn($pageInfo) => (($pageInfo['access'] ?? 'controlled') === 'always'));
$permissionPages = array_filter($pageCatalog, fn($pageInfo) => (($pageInfo['access'] ?? 'controlled') === 'controlled'));
$pagesScan = array_values(array_map(fn($pageInfo) => (string)($pageInfo['path'] ?? ''), $pageCatalog));
$pagesScan[] = 'adm/site_settings.php';
$pagesScan = array_values(array_unique(array_filter($pagesScan)));
sort($pagesScan, SORT_NATURAL | SORT_FLAG_CASE);

$dmdHorizontalMenuEmojis = dmd_horizontal_menu_emojis();
if (empty($settings['menu_horizontal']) || !is_array($settings['menu_horizontal'])) {
    $settings['menu_horizontal'] = dmd_default_horizontal_menu();
}
$settings['menu_vertical'] = dmd_horizontal_menu_to_html($settings['menu_horizontal']);

$settingsBeforePost = $settings;
$themeMarketRawOverride = null;

$dmdDmsBridgeNewToken = '';
if ($isSuperadmin && isset($_SESSION['dmd_dms_bridge_new_token'])) {
    $dmdDmsBridgeNewToken = (string)$_SESSION['dmd_dms_bridge_new_token'];
    unset($_SESSION['dmd_dms_bridge_new_token']);
}
$dmdDmsBridgeCfg = $isSuperadmin ? dmd_domysocial_bridge_read() : array('tokens' => array());
$dmdDmsBridgeTokens = isset($dmdDmsBridgeCfg['tokens']) && is_array($dmdDmsBridgeCfg['tokens']) ? $dmdDmsBridgeCfg['tokens'] : array();

