<?php
$heartbeatEnabled = !empty($settings['domyco_heartbeat_enabled']);
$heartbeatInterval = 300;
$heartbeatLast = dmd_json_read($heartbeatLastFile, []);
$heartbeatLastAttempt = is_file($heartbeatLockFile) ? (int)trim((string)@file_get_contents($heartbeatLockFile)) : 0;
$heartbeatLastAttemptText = $heartbeatLastAttempt > 0 ? date('d/m/Y H:i:s', $heartbeatLastAttempt) : 'Jamais';
$heartbeatNextText = $heartbeatLastAttempt > 0 ? date('d/m/Y H:i:s', $heartbeatLastAttempt + $heartbeatInterval) : 'Au prochain chargement après activation';
$heartbeatLastSuccess = !empty($heartbeatLast['success']) && empty($heartbeatLast['skipped']);
$heartbeatLastHttp = $heartbeatLast['http_code'] ?? ($heartbeatLast['sync_result']['http_code'] ?? null);

$users = [];
$userRoles = [];
$userProfiles = [];
foreach (glob($profilesDir . '*', GLOB_ONLYDIR) ?: [] as $folder) {
    $mail = basename($folder);

    // Synology peut créer automatiquement un dossier @eaDir dans /users/profiles/.
    // Ce dossier système ne doit jamais être considéré comme un utilisateur DoMyDesk.
    if ($mail === '@eaDir') {
        continue;
    }

    $profile = dmd_read_profile($mail);
    $users[] = $mail;
    $userProfiles[$mail] = $profile;
    $userRoles[$mail] = $profile['role_system'] ?? 'user';
}
sort($users, SORT_NATURAL | SORT_FLAG_CASE);
$superadminTotal = 0;
foreach ($userProfiles as $pUser) { if (($pUser['role_system'] ?? 'user') === 'superadmin') $superadminTotal++; }

// Données légères nécessaires à la matrice des droits modules.
// On ne précharge pas les droits effectifs complets : le navigateur les calcule
// à partir du rôle métier, du mode d'accès et des seules exceptions utilisateur.
$userModuleOverridesMap = [];
$userRightsMeta = [];
foreach ($users as $u) {
    $acl = dmd_read_user_modules_acl($u);
    $profile = $userProfiles[$u] ?? [];
    $userModuleOverridesMap[$u] = is_array($acl['overrides'] ?? null) ? $acl['overrides'] : [];
    $userRightsMeta[$u] = [
        'role_system' => (string)($profile['role_system'] ?? 'user'),
        'role_metier' => (string)($profile['role_metier'] ?? ''),
        'name' => trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? '')),
    ];
}

$selectedRightsRole = trim((string)($_POST['rights_role'] ?? ($metiers[0] ?? '')));
if (!in_array($selectedRightsRole, $metiers, true)) {
    $selectedRightsRole = (string)($metiers[0] ?? '');
}
$selectedRightsUser = trim((string)($_POST['rights_user'] ?? ''));
if ($selectedRightsUser !== '' && !in_array($selectedRightsUser, $users, true)) {
    $selectedRightsUser = '';
}


$userPageOverridesMap = [];
foreach ($users as $u) {
    $pageAcl = dmd_read_user_pages_acl($u);
    $userPageOverridesMap[$u] = is_array($pageAcl['overrides'] ?? null) ? $pageAcl['overrides'] : [];
}

$selectedPageRightsRole = trim((string)($_POST['page_rights_role'] ?? ($metiers[0] ?? '')));
if (!in_array($selectedPageRightsRole, $metiers, true)) {
    $selectedPageRightsRole = (string)($metiers[0] ?? '');
}
$selectedPageRightsUser = trim((string)($_POST['page_rights_user'] ?? ''));
if ($selectedPageRightsUser !== '' && !in_array($selectedPageRightsUser, $users, true)) {
    $selectedPageRightsUser = '';
}

$modDir = $baseDir . '/modules';
$allModules = array_values(array_filter(glob($modDir . '/*') ?: [], 'is_dir'));
$totalModules = count($allModules);
$perPage = 40;
$page = max(1, (int)($_GET['mpage'] ?? 1));
$pagesCount = max(1, (int)ceil($totalModules / $perPage));
$page = min($page, $pagesCount);
$modulesPage = array_slice($allModules, ($page - 1) * $perPage, $perPage);

$themeMarketWhy = $themeMarketSourceError;
$themeMarketRefreshed = false;
$themeMarketRaw = $themeMarketRawOverride;
if ($themeMarketRaw === null) {
    $themeMarketRaw = dmd_source_load_raw($baseDir, 'themes', false, $themeMarketWhy, $themeMarketRefreshed);
}
$themeMarketItems = [];
if ($themeMarketRaw !== false) {
    $decodedThemeMarket = json_decode($themeMarketRaw, true);
    if (is_array($decodedThemeMarket)) $themeMarketItems = $decodedThemeMarket;
}
$installedThemes = dmd_theme_installed_list($themesDir);

/* État de licence relu après toute action d’administration. */
$dmdLicenseStatus = $isSuperadmin ? dmd_license_status(true) : array();
$dmdLicenseEntitlements = isset($dmdLicenseStatus['entitlements']) && is_array($dmdLicenseStatus['entitlements']) ? $dmdLicenseStatus['entitlements'] : array();
$dmdLicenseAgent = isset($dmdLicenseEntitlements['dmd_agent']) && is_array($dmdLicenseEntitlements['dmd_agent']) ? $dmdLicenseEntitlements['dmd_agent'] : array();
$dmdLicenseMyDesk = isset($dmdLicenseEntitlements['dmd_mydesk']) && is_array($dmdLicenseEntitlements['dmd_mydesk']) ? $dmdLicenseEntitlements['dmd_mydesk'] : array();
$dmdLicenseInstances = isset($dmdLicenseEntitlements['dmd_instances']) && is_array($dmdLicenseEntitlements['dmd_instances']) ? $dmdLicenseEntitlements['dmd_instances'] : array();
$dmdLicenseTicketing = isset($dmdLicenseEntitlements['dmd_ticketing_external']) && is_array($dmdLicenseEntitlements['dmd_ticketing_external']) ? $dmdLicenseEntitlements['dmd_ticketing_external'] : array();
$dmdLicenseHasSignedFile = !empty($dmdLicenseStatus['verified']) && (string)($dmdLicenseStatus['source'] ?? '') === 'file';
$dmdLicenseEngineFile = dmd_license_file();
$dmdTicketingLicense = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_license_status() : array('enabled'=>false,'clients_max'=>0);
$dmdTicketingConfig = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_config() : array();
$dmdTicketingReceive = isset($dmdTicketingConfig['external_receive']) && is_array($dmdTicketingConfig['external_receive']) ? $dmdTicketingConfig['external_receive'] : array();
$dmdTicketingSupportBaseUrl = dmd_admin_ticketing_base_url((string)($dmdTicketingReceive['endpoint'] ?? ''));
$dmdTicketingClients = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_client_list() : array();
$dmdTicketingActiveClients = ($isSuperadmin && $dmdTicketingAvailable) ? dmdtk_external_active_client_count() : 0;
$dmdTicketingClientsMax = (int)($dmdTicketingLicense['clients_max'] ?? 0);
