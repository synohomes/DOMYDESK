<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    header('Location: ../login.php');
    exit;
}

$baseDir = dirname(__DIR__, 2); 
require_once $baseDir . '/core/dmd_permissions.php';
require_once $baseDir . '/core/dmd_system_services.php';
require_once $baseDir . '/core/dmd_media.php';
require_once $baseDir . '/core/dmd_ui_features.php';
require_once $baseDir . '/core/dmd_version.php';
require_once $baseDir . '/core/dmd_sources.php';
require_once $baseDir . '/core/dmd_mfa.php';
require_once $baseDir . '/core/dmd_domysocial_bridge.php';
require_once $baseDir . '/core/dmd_license.php';
$dmdTicketingLibFile = $baseDir . '/modules/dmd-ticketing/dmd-ticketing_lib.php';
$dmdTicketingAvailable = is_file($dmdTicketingLibFile);
if ($dmdTicketingAvailable) require_once $dmdTicketingLibFile;
$profilesDir = $baseDir . '/users/profiles/';
$profileFile = dmd_profile_path($email, true);

if (!is_file($profileFile)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$profileData = json_decode((string)file_get_contents($profileFile), true);
if (!is_array($profileData)) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$roleSystemReal = $profileData['role_system'] ?? 'user';

if (!in_array($roleSystemReal, ['admin', 'superadmin'], true)) {
    header('Location: ../profile_view.php');
    exit;
}

$isAdmin = true;
$isSuperadmin = ($roleSystemReal === 'superadmin');
$mfaDisablePendingCount = $isSuperadmin ? count(dmd_mfa_pending_disable_requests()) : 0;
$dmdVersion = dmd_version_read($baseDir);
$dmdVersionLabel = $dmdVersion === 'Inconnue' ? 'Version inconnue' : ('V.' . $dmdVersion);
$migrationReport = dmd_migrate_all_user_security_files();

if (empty($_SESSION['csrf_site_settings'])) {
    $_SESSION['csrf_site_settings'] = bin2hex(random_bytes(32));
}

$settingsFile = $baseDir . '/adm/settings.json';
$languagesDir = $baseDir . '/lang/';
$rolesFile = $baseDir . '/data/roles_metier.json';
$rolesModulesFile = $baseDir . '/data/secure/roles_modules.json';
$idFile = $baseDir . '/data/id_domydesk.txt';
$heartbeatFile = $baseDir . '/data/domyco_heartbeat.php';
$heartbeatLockFile = $baseDir . '/data/domyco_heartbeat.lock';
$heartbeatLastFile = $baseDir . '/data/domyco_heartbeat_last.json';
$themeMarketSourceError = '';
$themeMarketUrl = dmd_source_url($baseDir, 'themes', $themeMarketSourceError);
$themesDir = $baseDir . '/theme/';
$themeUploadDir = $baseDir . '/uploads/themes/';
@mkdir($themesDir, 0775, true);
@mkdir($themeUploadDir, 0775, true);

$success = false;
$errors = [];
$message = '';
$reopenPopup = '';
$requestedPopup = trim((string)($_GET['open'] ?? ''));
$allowedRequestedPopups = ['popup-site-settings','popup-core-interface','popup-site-maintenance','popup-security-admin','popup-index-settings','popup-theme-market','popup-unofficial-themes','popup-news','popup-market-inline','popup-unofficial-modules','popup-module-rights','popup-user-add','popup-user-roles','popup-page-rights','popup-metiers','popup-updates','popup-system-logs','popup-module-updates'];
if ($requestedPopup !== '' && in_array($requestedPopup, $allowedRequestedPopups, true)) {
    if (!in_array($requestedPopup, ['popup-updates','popup-system-logs','popup-module-updates','popup-security-admin'], true) || $isSuperadmin) {
        $reopenPopup = $requestedPopup;
    }
}
if ($isSuperadmin && (string)($_GET['mfa_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Politique MFA centrale enregistrée et relue avec succès.';
}
if ($isSuperadmin && (string)($_GET['dms_bridge_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Code d’appairage DoMySocial créé. Copiez-le maintenant : il ne sera affiché qu’une seule fois.';
}
if ($isSuperadmin && (string)($_GET['dms_bridge_revoked'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Liaison DoMySocial révoquée.';
}
if ($isSuperadmin && (string)($_GET['license_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Licence signée installée et vérifiée pour cette instance.';
}
if ($isSuperadmin && (string)($_GET['license_removed'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin';
    $success = true;
    $message = 'Licence signée retirée. Le mode de lancement s’applique à nouveau tant qu’il est disponible.';
}
if ($isSuperadmin && (string)($_GET['ticketing_saved'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Configuration du récepteur DMD-Ticketing enregistrée.';
}
if ($isSuperadmin && (string)($_GET['ticketing_client_created'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Entreprise cliente créée. Le fichier de liaison peut maintenant être téléchargé.';
}
if ($isSuperadmin && (string)($_GET['ticketing_action_done'] ?? '') === '1') {
    $reopenPopup = 'popup-security-admin'; $success = true; $message = 'Action DMD-Ticketing effectuée.';
}
$idDoMyDesk = is_file($idFile) ? trim((string)file_get_contents($idFile)) : '';

