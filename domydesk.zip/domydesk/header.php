<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_system_services.php';
require_once __DIR__ . '/core/dmd_media.php';
require_once __DIR__ . '/core/dmd_ui_features.php';

/* =========================================================
   BASE URL DOMYDESK
   ========================================================= */
function dmd_base_path(): string {
    return '/domydesk/';
}

$basePath = dmd_base_path();

/* =========================================================
   CACHE UTILISATEUR
   ========================================================= */
if (!defined('DMD_CACHE_READY')) {
    define('DMD_CACHE_READY', true);
    define('CACHE_ROOT', __DIR__ . '/data/cache/');

    if (!is_dir(CACHE_ROOT)) {
        @mkdir(CACHE_ROOT, 0775, true);
    }

    $userId = !empty($_SESSION['user']['email'])
        ? $_SESSION['user']['email']
        : (!empty($_SESSION['user']['id']) ? (string)$_SESSION['user']['id'] : '_public');

    $safeUserId = preg_replace('/[^a-zA-Z0-9_\-@.]/', '_', $userId);
    define('USER_CACHE_DIR', CACHE_ROOT . $safeUserId . '/');

    if (!is_dir(USER_CACHE_DIR)) {
        @mkdir(USER_CACHE_DIR, 0775, true);
    }

    function dmd_cache_user_path(string $key): string {
        $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        return USER_CACHE_DIR . $safe . '.json';
    }

    function dmd_cache_get(string $key, int $ttl): mixed {
        $f = dmd_cache_user_path($key);
        if (!is_file($f)) return null;
        if ((time() - filemtime($f)) > $ttl) return null;

        $j = @file_get_contents($f);
        if ($j === false) return null;

        $d = json_decode($j, true);
        return (json_last_error() === JSON_ERROR_NONE) ? $d : null;
    }

    function dmd_cache_set(string $key, mixed $data): bool {
        $f = dmd_cache_user_path($key);
        $j = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return ($j !== false) ? (@file_put_contents($f, $j) !== false) : false;
    }

    function dmd_cache_del(string $key): void {
        $f = dmd_cache_user_path($key);
        if (is_file($f)) {
            @unlink($f);
        }
    }

    function dmd_cache_clear_user(): bool {
        if (!is_dir(USER_CACHE_DIR)) return true;

        $ok = true;

        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(USER_CACHE_DIR, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($it as $path) {
            $ok = $ok && (@($path->isDir() ? rmdir($path->getPathname()) : unlink($path->getPathname())));
        }

        $ok = $ok && @rmdir(USER_CACHE_DIR);
        @mkdir(USER_CACHE_DIR, 0775, true);

        return $ok;
    }

    if (empty($_SESSION['csrf_cache'])) {
        $_SESSION['csrf_cache'] = bin2hex(random_bytes(16));
    }

    if (
        isset($_GET['clear_cache'], $_GET['token'])
        && hash_equals($_SESSION['csrf_cache'], (string)$_GET['token'])
    ) {
        $done = dmd_cache_clear_user();
        $_SESSION['flash_cache'] = $done ? 'Cache utilisateur vidé.' : 'Échec du vidage du cache.';

        $target = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');

        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Location: ' . $target, true, 303);
        } else {
            echo '<script>location.replace(' . json_encode($target) . ');</script>';
            echo '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($target, ENT_QUOTES) . '"></noscript>';
        }

        exit;
    }
}

/* =========================================================
   UTILISATEUR / THEME / MENU
   ========================================================= */
$userEmail     = $_SESSION['user']['email']  ?? null;
$userFirstName = $_SESSION['user']['prenom'] ?? 'Invité';
$userRole      = $_SESSION['user']['role_system'] ?? ($_SESSION['role_system'] ?? null);
$menu          = [];
$theme         = 'default';

if ($userEmail) {
    $safeEmail = basename($userEmail);

    $themePath = __DIR__ . "/users/profiles/$safeEmail/theme.json";
    if (file_exists($themePath)) {
        $themeData = json_decode((string)file_get_contents($themePath), true);

        if (
            !empty($themeData['theme'])
            && file_exists(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")
        ) {
            $theme = basename($themeData['theme']);
        }
    }

    $menuFilePath = __DIR__ . "/users/profiles/$safeEmail/menu.json";
    if (file_exists($menuFilePath)) {
        $menu = json_decode((string)file_get_contents($menuFilePath), true);
        if (!is_array($menu)) {
            $menu = [];
        }
    }
}

/* =========================================================
   SETTINGS
   ========================================================= */
$settingsFile = __DIR__ . '/adm/settings.json';

$settings = [
    'site_name'                   => 'Mon super site',
    'logo_path'                   => 'uploads/logo.png',
    'banner_path'                 => '',
    'vertical_menu_brand_mode'    => 'none',
    'menu_horizontal'             => [],
    'menu_vertical'               => '',
    'domyco_heartbeat_enabled'    => true,
    'domyco_heartbeat_interval'   => 300,
];

if (file_exists($settingsFile)) {
    $json = file_get_contents($settingsFile);
    $loadedSettings = json_decode((string)$json, true);

    if (is_array($loadedSettings)) {
        $settings = array_merge($settings, $loadedSettings);
    }
}

$dmdVerticalBrandMode = (string)($settings['vertical_menu_brand_mode'] ?? 'none');
$dmdVerticalBrandFile = '';
if ($dmdVerticalBrandMode === 'avatar') {
    $dmdVerticalBrandFile = dmd_site_asset_file($settings, 'logo_path');
} elseif ($dmdVerticalBrandMode === 'banner') {
    $dmdVerticalBrandFile = dmd_site_asset_file($settings, 'banner_path');
} else {
    $dmdVerticalBrandMode = 'none';
}
if ($dmdVerticalBrandFile === '') {
    $dmdVerticalBrandMode = 'none';
}
$dmdVerticalBrandUrl = $dmdVerticalBrandFile !== '' ? dmd_media_public_url($dmdVerticalBrandFile) : '';

$domycoHeartbeatEnabled = !empty($settings['domyco_heartbeat_enabled']);
$domycoHeartbeatInterval = 300;

$dmdActionHubTool = $userEmail ? dmd_ui_effective_tool($userEmail, 'actionhub', $settings) : null;
$dmdQuickSessionTool = $userEmail ? dmd_ui_effective_tool($userEmail, 'quick_session', $settings) : null;
$dmdVerticalCoreTools = array();

if ($userEmail && is_array($dmdActionHubTool) && ($dmdActionHubTool['location'] ?? '') === 'vertical') {
    $dmdVerticalCoreTools[] = $dmdActionHubTool;
}
if ($userEmail && is_array($dmdQuickSessionTool) && ($dmdQuickSessionTool['location'] ?? '') === 'vertical') {
    $dmdVerticalCoreTools[] = $dmdQuickSessionTool;
}

$dmdCoreToolDashboardName = isset($currentDashboard) ? trim((string)$currentDashboard) : '';
$dmdCoreToolBaseQuery = $dmdCoreToolDashboardName !== ''
    ? ('dashboard=' . rawurlencode($dmdCoreToolDashboardName) . '&')
    : '';

/* =========================================================
   URLS PROPRES
   ========================================================= */
function dmd_url(string $link): string {
    global $basePath;

    $link = trim($link);

    if ($link === '') {
        return '#';
    }

    if (preg_match('#^https?://#i', $link)) {
        return $link;
    }

    if (strpos($link, '/domydesk/') === 0) {
        return $link;
    }

    if ($basePath !== '/' && strpos($link, $basePath) === 0) {
        return $link;
    }

    if (strpos($link, '/') === 0) {
        return rtrim($basePath, '/') . '/' . ltrim($link, '/');
    }

    return rtrim($basePath, '/') . '/' . ltrim($link, '/');
}

/* =========================================================
   MENU HORIZONTAL DU HEADER
   - Source unique : /adm/settings.json -> menu_horizontal
   - Ne reconstruit plus un menu codé en dur par-dessus.
   ========================================================= */
function dmd_header_horizontal_menu_html(array $items): string {
    $html = '';

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $title = trim((string)($item['title'] ?? ''));
        $icon  = trim((string)($item['icon'] ?? ''));
        $url   = trim((string)($item['url'] ?? ''));
        $type  = ((string)($item['type'] ?? 'page')) === 'external' ? 'external' : 'page';

        if ($title === '' || $icon === '' || $url === '') {
            continue;
        }

        // Les chemins absolus (/domydesk/..., /domysocial/...) sont déjà complets.
        // Les chemins relatifs restent compatibles avec l'ancien fonctionnement.
        $href = str_starts_with($url, '/') || preg_match('#^https?://#i', $url)
            ? $url
            : dmd_url($url);

        $target = $type === 'external'
            ? ' target="_blank" rel="noopener noreferrer"'
            : '';

        $html .= '<a href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8')
            . '" class="icon-link" title="' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '"'
            . $target . '>'
            . htmlspecialchars($icon, ENT_QUOTES, 'UTF-8')
            . '</a>' . "\n";
    }

    return $html;
}

$configuredHorizontalMenu = $settings['menu_horizontal'] ?? [];

if (is_array($configuredHorizontalMenu) && $configuredHorizontalMenu) {
    $settings['menu_vertical'] = dmd_header_horizontal_menu_html($configuredHorizontalMenu);
} elseif (!empty($settings['menu_vertical']) && is_string($settings['menu_vertical'])) {
    // Compatibilité avec les anciennes installations qui n'avaient que le HTML stocké.
    $settings['menu_vertical'] = (string)$settings['menu_vertical'];
} else {
    // Secours minimal uniquement si settings.json ne contient encore aucun menu.
    $settings['menu_vertical'] = dmd_header_horizontal_menu_html([
        ['title' => 'Dashboard', 'icon' => '🖥️', 'url' => '/domydesk/dashboard.php', 'type' => 'page'],
        ['title' => 'Accueil', 'icon' => '⭐', 'url' => '/domydesk/index.php', 'type' => 'page'],
        ['title' => 'Profil', 'icon' => '🏃', 'url' => '/domydesk/profile_view.php', 'type' => 'page'],
        ['title' => 'Déconnexion', 'icon' => '❌', 'url' => '/domydesk/logout.php', 'type' => 'page'],
    ]);
}

/* =========================================================
   MENU PERSONNALISÉ
   ========================================================= */
function dmd_header_filter_menu_items(array $items, string $email): array {
    $clean = [];

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $label = trim((string)($item['label'] ?? ''));
        if ($label === '') {
            continue;
        }

        $type = strtolower(trim((string)($item['type'] ?? 'none')));
        $link = trim((string)($item['link'] ?? ''));
        $submenu = !empty($item['submenu']) && is_array($item['submenu'])
            ? dmd_header_filter_menu_items($item['submenu'], $email)
            : [];

        if ($type === 'page') {
            $pageId = dmd_page_id_from_link($link);

            if ($pageId === '' || $email === '' || !dmd_user_can_access_page($email, $pageId)) {
                if (!$submenu) {
                    continue;
                }
                $type = 'none';
                $link = '#';
            } else {
                $catalog = dmd_page_catalog();
                $link = (string)($catalog[$pageId]['path'] ?? '');
            }
        } elseif ($type === 'link') {
            if (!filter_var($link, FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($link, PHP_URL_SCHEME)), ['http', 'https'], true)) {
                if (!$submenu) {
                    continue;
                }
                $type = 'none';
                $link = '#';
            }
        } else {
            $type = 'none';
            $link = '#';
        }

        $clean[] = [
            'label' => $label,
            'type' => $type,
            'link' => $link,
            'submenu' => $submenu,
        ];
    }

    return $clean;
}

function renderMenuItems(array $items, string $email = ''): void {
    $items = dmd_header_filter_menu_items($items, $email);
    echo '<ul>';

    foreach ($items as $item) {
        $label   = $item['label'] ?? '';
        $link    = $item['link'] ?? '#';
        $type    = $item['type'] ?? 'none';
        $submenu = $item['submenu'] ?? [];

        if (!$label) {
            continue;
        }

        $safeLink = $type === 'none' ? '#' : dmd_url((string)$link);

        if (!empty($submenu) && is_array($submenu)) {
            echo '<li class="has-submenu">';
            echo '<a href="' . htmlspecialchars($safeLink, ENT_QUOTES) . '">' . htmlspecialchars((string)$label, ENT_QUOTES) . '</a>';
            renderMenuItems($submenu, $email);
            echo '</li>';
        } else {
            echo '<li><a href="' . htmlspecialchars($safeLink, ENT_QUOTES) . '">' . htmlspecialchars((string)$label, ENT_QUOTES) . '</a></li>';
        }
    }

    echo '</ul>';
}

/* =========================================================
   ID DOMYDESK
   ========================================================= */
function dmd_read_unique_id(): string {
    $candidates = [
        __DIR__ . '/data/id_domydesk.txt',
        __DIR__ . '/id_domydesk.txt',
        __DIR__ . '/adm/data/id_domydesk.txt',
    ];

    foreach ($candidates as $p) {
        if (is_file($p)) {
            $id = trim((string)@file_get_contents($p));

            if ($id !== '') {
                return $id;
            }
        }
    }

    return 'ID non défini';
}

$domydeskId = dmd_read_unique_id();

/* =========================================================
   NOTIFICATIONS CORE
   ========================================================= */
if (empty($_SESSION['csrf_notifications'])) {
    $_SESSION['csrf_notifications'] = bin2hex(random_bytes(24));
}
$dmdNotificationState = $userEmail ? dmd_notification_state($userEmail) : ['unread' => 0, 'unread_ids' => []];
$dmdNotificationUnread = (int)($dmdNotificationState['unread'] ?? 0);
$dmdNotificationRole = $userEmail ? dmd_sys_current_role() : 'user';

/* =========================================================
   STATS VISITEURS
   Désactivées dans DoMyDesk 1.2.0 privé.
   Le suivi visiteurs reste réservé à l'instance publique V1.
   ========================================================= */
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($settings['site_name'], ENT_QUOTES) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath, ENT_QUOTES) ?>theme/<?= htmlspecialchars($theme, ENT_QUOTES) ?>/style.css">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath, ENT_QUOTES) ?>core/dmd_header_layout.css?v=<?= is_file(__DIR__ . '/core/dmd_header_layout.css') ? (int)filemtime(__DIR__ . '/core/dmd_header_layout.css') : 120 ?>">
    <link rel="stylesheet" href="<?= htmlspecialchars($basePath, ENT_QUOTES) ?>core/dmd_notifications.css?v=121">
    <?php
    require_once __DIR__ . '/core/dmd_theme_assets.php';
    echo dmd_theme_extra_links(__DIR__, $basePath . 'theme', $theme);
    ?>
</head>
<body>
<header>
    <div id="top-bar">
        <div class="left">
            <span id="user-name"><?= htmlspecialchars($userFirstName, ENT_QUOTES) ?></span>
            <span id="date">--.--.----</span>
            <span id="time">--:--:--</span>

            <?php if ($userEmail): ?>
                <button type="button" id="dmd-notify-trigger" class="dmd-notify-trigger<?= $dmdNotificationUnread > 0 ? ' has-unread' : '' ?>" title="Notifications" aria-label="Ouvrir les notifications" aria-haspopup="dialog" aria-controls="dmd-notify-overlay">
                    <span aria-hidden="true">🔔</span>
                    <span id="dmd-notify-count" class="dmd-notify-count<?= $dmdNotificationUnread > 0 ? '' : ' is-zero' ?>"><?= $dmdNotificationUnread > 99 ? '99+' : $dmdNotificationUnread ?></span>
                </button>
            <?php endif; ?>
        </div>

        <?php if (!empty($dmdHeaderDashboardControls)): ?>
            <div class="center">
                <?= $dmdHeaderDashboardControls ?>
            </div>
        <?php endif; ?>

        <div class="right">
            <?= $settings['menu_vertical'] ?>
        </div>
    </div>

    <div class="menu-toggle" onclick="toggleMenu()">☰</div>

    <div class="right-menu-wrapper" id="right-menu-wrapper" aria-hidden="true">
        <nav class="right-menu">
            <?php if ($dmdVerticalBrandMode !== 'none' && $dmdVerticalBrandUrl !== ''): ?>
                <div class="dmd-right-menu-brand dmd-right-menu-brand-<?= htmlspecialchars($dmdVerticalBrandMode, ENT_QUOTES, 'UTF-8') ?>">
                    <img src="<?= htmlspecialchars($dmdVerticalBrandUrl, ENT_QUOTES, 'UTF-8') ?>" alt="<?= $dmdVerticalBrandMode === 'banner' ? 'Bannière DoMyDesk' : 'Avatar DoMyDesk' ?>">
                </div>
            <?php endif; ?>
            <ul>
                <?php if ($dmdVerticalCoreTools): ?>
                    <?php foreach ($dmdVerticalCoreTools as $dmdCoreTool): ?>
                        <?php
                        $dmdToolId = (string)($dmdCoreTool['id'] ?? '');
                        $dmdToolQueryId = $dmdToolId === 'quick_session' ? 'quick_session' : 'actionhub';
                        $dmdToolHref = dmd_url('dashboard.php?' . $dmdCoreToolBaseQuery . 'core_tool=' . rawurlencode($dmdToolQueryId));
                        ?>
                        <li class="dmd-core-tool-menu-item">
                            <a href="<?= htmlspecialchars($dmdToolHref, ENT_QUOTES, 'UTF-8') ?>">
                                <?= htmlspecialchars((string)($dmdCoreTool['icon'] ?? '⭐'), ENT_QUOTES, 'UTF-8') ?>
                                <?= htmlspecialchars((string)($dmdCoreTool['label'] ?? $dmdToolId), ENT_QUOTES, 'UTF-8') ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <hr>
                <?php endif; ?>

                <li><a href="<?= htmlspecialchars(dmd_url('modules/modules.php'), ENT_QUOTES) ?>">🎫 Modules</a></li>

                <li>
                    <a href="?clear_cache=1&token=<?= htmlspecialchars($_SESSION['csrf_cache'], ENT_QUOTES) ?>"
                       class="menu-action"
                       title="Vider mon cache">♻️ Vider mon cache</a>
                </li>

                <li><a href="<?= htmlspecialchars(dmd_url('members.php'), ENT_QUOTES) ?>">👨‍👨‍👦‍👦 Membres</a></li>
                <li><a href="<?= htmlspecialchars(dmd_url('profile_edit.php'), ENT_QUOTES) ?>">🧰 Modifier le profil</a></li>

                <?php if (!empty($_SESSION['flash_cache'])): ?>
                    <li id="flash-cache" class="flash notice" role="status" aria-live="polite">
                        <?= htmlspecialchars($_SESSION['flash_cache'], ENT_QUOTES); ?>
                    </li>
                    <?php unset($_SESSION['flash_cache']); ?>
                <?php endif; ?>

                <hr>

                <?php
                if (!empty($menu['items']['items']) && is_array($menu['items']['items'])) {
                    renderMenuItems($menu['items']['items'], (string)$userEmail);
                } else {
                    echo '<li style="padding:10px; color:orange;">Aucun menu personnalisé trouvé.</li>';
                }
                ?>

                <hr>
            </ul>
        </nav>
    </div>
</header>

<?php if ($userEmail): ?>
<div id="dmd-notify-overlay" class="dmd-notify-overlay" aria-hidden="true">
    <section class="dmd-notify-window" role="dialog" aria-modal="true" aria-labelledby="dmd-notify-title">
        <div class="dmd-notify-head">
            <strong id="dmd-notify-title">🔔 Notifications</strong>
            <div class="dmd-notify-head-actions">
                <button type="button" id="dmd-notify-read-all">Tout marquer lu</button>
                <button type="button" id="dmd-notify-clear">Vider</button>
                <button type="button" id="dmd-notify-close">Fermer</button>
            </div>
        </div>
        <div id="dmd-notify-list" class="dmd-notify-list"><div class="dmd-notify-empty">Chargement…</div></div>
    </section>
</div>

<div id="dmd-notify-detail-overlay" class="dmd-notify-detail-overlay" aria-hidden="true">
    <section class="dmd-notify-detail-window" role="dialog" aria-modal="true" aria-labelledby="dmd-notify-detail-title">
        <div class="dmd-notify-head">
            <strong id="dmd-notify-detail-title">Détail de la notification</strong>
            <button type="button" id="dmd-notify-detail-close">Fermer</button>
        </div>
        <div id="dmd-notify-detail-body" class="dmd-notify-detail-body"></div>
    </section>
</div>
<?php endif; ?>

<?php if ($userEmail && $domycoHeartbeatEnabled): ?>
<script>
(() => {
    const endpoint = <?= json_encode($basePath . 'data/domyco_heartbeat.php', JSON_UNESCAPED_SLASHES) ?>;
    const intervalMs = 300000;

    const sendDomyCoHeartbeat = () => {
        fetch(endpoint, {
            method: 'GET',
            cache: 'no-store',
            credentials: 'same-origin'
        }).catch(() => {});
    };

    const startDomyCoHeartbeat = () => {
        window.setTimeout(sendDomyCoHeartbeat, 800);
        window.setInterval(sendDomyCoHeartbeat, intervalMs);

        // Si l'onglet a été mis en veille par le navigateur, on retente dès
        // que l'utilisateur revient sur DoMyDesk. Le moteur PHP garde lui-même
        // la limite d'un envoi réel toutes les 5 minutes pour toute l'instance.
        window.addEventListener('focus', sendDomyCoHeartbeat);
        window.addEventListener('pageshow', sendDomyCoHeartbeat);
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                sendDomyCoHeartbeat();
            }
        });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startDomyCoHeartbeat, { once: true });
    } else {
        startDomyCoHeartbeat();
    }
})();
</script>
<?php endif; ?>

<script>
function updateDateTime() {
    const d = document.getElementById('date');
    const t = document.getElementById('time');

    if (!d || !t) return;

    const now = new Date();

    d.textContent =
        String(now.getDate()).padStart(2, '0') + '.' +
        String(now.getMonth() + 1).padStart(2, '0') + '.' +
        now.getFullYear();

    t.textContent =
        String(now.getHours()).padStart(2, '0') + ':' +
        String(now.getMinutes()).padStart(2, '0') + ':' +
        String(now.getSeconds()).padStart(2, '0');
}

function toggleMenu() {
    const menu = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');

    if (!menu || !toggleBtn) return;

    const isOpen = menu.classList.contains('is-open');

    if (isOpen) {
        menu.classList.remove('is-open');
        menu.style.transform = 'translateX(100%)';
        menu.setAttribute('aria-hidden', 'true');
        toggleBtn.setAttribute('aria-expanded', 'false');
    } else {
        menu.classList.add('is-open');
        menu.style.transform = 'translateX(0)';
        menu.setAttribute('aria-hidden', 'false');
        toggleBtn.setAttribute('aria-expanded', 'true');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateDateTime();
    setInterval(updateDateTime, 1000);


    const dmdNotifyTrigger = document.getElementById('dmd-notify-trigger');
    const dmdNotifyOverlay = document.getElementById('dmd-notify-overlay');
    const dmdNotifyList = document.getElementById('dmd-notify-list');
    const dmdNotifyCount = document.getElementById('dmd-notify-count');
    const dmdNotifyClose = document.getElementById('dmd-notify-close');
    const dmdNotifyReadAll = document.getElementById('dmd-notify-read-all');
    const dmdNotifyClear = document.getElementById('dmd-notify-clear');
    const dmdNotifyDetailOverlay = document.getElementById('dmd-notify-detail-overlay');
    const dmdNotifyDetailBody = document.getElementById('dmd-notify-detail-body');
    const dmdNotifyDetailTitle = document.getElementById('dmd-notify-detail-title');
    const dmdNotifyDetailClose = document.getElementById('dmd-notify-detail-close');
    const dmdNotifyEndpoint = <?= json_encode($basePath . 'users/notifications.php', JSON_UNESCAPED_SLASHES) ?>;
    const dmdNotifyCsrf = <?= json_encode($_SESSION['csrf_notifications'] ?? '', JSON_UNESCAPED_SLASHES) ?>;
    const dmdCurrentRole = <?= json_encode($dmdNotificationRole, JSON_UNESCAPED_SLASHES) ?>;

    function dmdSetNotificationCount(value) {
        if (!dmdNotifyCount || !dmdNotifyTrigger) return;
        const n = Math.max(0, Number(value) || 0);
        dmdNotifyCount.textContent = n > 99 ? '99+' : String(n);
        dmdNotifyCount.classList.toggle('is-zero', n === 0);
        dmdNotifyTrigger.classList.toggle('has-unread', n > 0);
    }

    function dmdNotificationIcon(level) {
        if (level === 'danger') return '🔴';
        if (level === 'warning') return '🟠';
        if (level === 'success') return '🟢';
        return '🔵';
    }

    function dmdNotificationActionUrl(url) {
        url = String(url || '').trim();
        if (!url) return '';
        if (/^https?:\/\//i.test(url)) return url;
        if (url.startsWith('/')) return url;
        return <?= json_encode(rtrim($basePath, '/') . '/', JSON_UNESCAPED_SLASHES) ?> + url.replace(/^\/+/, '');
    }

    function dmdNotificationDate(item) {
        if (!item || !item.timestamp) return '';
        try { return new Date(Number(item.timestamp) * 1000).toLocaleString('fr-FR'); } catch(e) { return ''; }
    }

    function dmdFormatDetailValue(value, kind = '') {
        if (value === null || typeof value === 'undefined') return 'Détail non exposé';
        if (Array.isArray(value)) return value.length ? value.join(', ') : 'Aucun';
        const raw = String(value);
        if (kind === 'module_state') {
            if (raw === 'allow') return 'Autorisé';
            if (raw === 'deny') return 'Refusé';
            if (raw === 'inherit') return 'Hérité du rôle';
        }
        return raw === '' ? 'Aucun' : raw;
    }

    async function dmdMarkNotificationRead(id) {
        if (!id) return;
        const body = new URLSearchParams({action:'read', id:String(id), csrf_token:dmdNotifyCsrf});
        try {
            const r = await fetch(dmdNotifyEndpoint, {method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body});
            const data = await r.json();
            if (data && data.success) dmdSetNotificationCount(data.unread || 0);
        } catch(e) {}
    }

    function dmdCreateNotificationAction(item) {
        const actionUrl = dmdNotificationActionUrl(item && item.action_url);
        if (item && item.requires_superadmin && dmdCurrentRole !== 'superadmin') {
            const switchLink = document.createElement('a');
            const next = actionUrl || <?= json_encode($basePath . 'adm/site_settings.php', JSON_UNESCAPED_SLASHES) ?>;
            switchLink.href = <?= json_encode($basePath . 'logout.php?next=', JSON_UNESCAPED_SLASHES) ?> + encodeURIComponent(next);
            switchLink.textContent = '🔐 Se connecter en Superadmin';
            switchLink.addEventListener('click', () => dmdMarkNotificationRead(item.id));
            return switchLink;
        }
        if (actionUrl) {
            const link = document.createElement('a');
            link.href = actionUrl;
            link.textContent = item.action_label || 'Ouvrir';
            link.addEventListener('click', () => dmdMarkNotificationRead(item.id));
            return link;
        }
        return null;
    }

    function dmdAppendDetailLine(parent, label, value) {
        const row = document.createElement('div');
        row.className = 'dmd-notify-detail-line';
        const k = document.createElement('span'); k.textContent = label;
        const v = document.createElement('strong'); v.textContent = value;
        row.append(k, v);
        parent.appendChild(row);
    }

    function dmdRenderNotificationChanges(parent, changes, scope) {
        if (!changes || typeof changes !== 'object' || Array.isArray(changes)) return false;
        const entries = Object.entries(changes);
        if (!entries.length) return false;

        const section = document.createElement('section');
        section.className = 'dmd-notify-detail-section';
        const heading = document.createElement('h4');
        heading.textContent = scope === 'modules' ? 'Modifications des modules' : 'Modifications effectuées';
        section.appendChild(heading);

        entries.forEach(([key, change]) => {
            if (!change || typeof change !== 'object') return;
            const card = document.createElement('div');
            card.className = 'dmd-notify-change';
            const title = document.createElement('strong');
            title.className = 'dmd-notify-change-title';
            title.textContent = change.label || change.name || key;
            card.appendChild(title);

            const values = document.createElement('div');
            values.className = 'dmd-notify-change-values';
            const isModule = scope === 'modules' || Object.prototype.hasOwnProperty.call(change, 'permissions_before') || Object.prototype.hasOwnProperty.call(change, 'permissions_after');

            const before = document.createElement('div');
            const beforeLabel = document.createElement('span'); beforeLabel.textContent = 'Avant';
            const beforeValue = document.createElement('strong'); beforeValue.textContent = dmdFormatDetailValue(change.before, isModule ? 'module_state' : '');
            before.append(beforeLabel, beforeValue);

            const arrow = document.createElement('div'); arrow.className = 'dmd-notify-change-arrow'; arrow.textContent = '→';

            const after = document.createElement('div');
            const afterLabel = document.createElement('span'); afterLabel.textContent = 'Après';
            const afterValue = document.createElement('strong'); afterValue.textContent = dmdFormatDetailValue(change.after, isModule ? 'module_state' : '');
            after.append(afterLabel, afterValue);

            values.append(before, arrow, after);
            card.appendChild(values);

            if (isModule && (Array.isArray(change.permissions_before) || Array.isArray(change.permissions_after))) {
                const perms = document.createElement('div');
                perms.className = 'dmd-notify-change-permissions';
                const pBefore = dmdFormatDetailValue(change.permissions_before || []);
                const pAfter = dmdFormatDetailValue(change.permissions_after || []);
                perms.textContent = 'Actions fines : ' + pBefore + ' → ' + pAfter;
                card.appendChild(perms);
            }
            section.appendChild(card);
        });

        if (section.children.length <= 1) return false;
        parent.appendChild(section);
        return true;
    }

    async function dmdOpenNotificationDetail(item, listBox = null) {
        if (!dmdNotifyDetailOverlay || !dmdNotifyDetailBody || !item) return;
        dmdNotifyDetailBody.textContent = '';
        dmdNotifyDetailTitle.textContent = dmdNotificationIcon(item.level) + ' ' + (item.title || 'Notification');

        const summary = document.createElement('section');
        summary.className = 'dmd-notify-detail-section';
        if (item.message) {
            const message = document.createElement('p');
            message.className = 'dmd-notify-detail-message';
            message.textContent = item.message;
            summary.appendChild(message);
        }
        dmdAppendDetailLine(summary, 'Date', dmdNotificationDate(item) || 'Non renseignée');
        dmdAppendDetailLine(summary, 'Déclenchée par', item.actor || 'DoMyDesk');
        dmdAppendDetailLine(summary, 'Type', item.type || 'information');
        dmdNotifyDetailBody.appendChild(summary);

        const meta = item.meta && typeof item.meta === 'object' ? item.meta : {};
        const hasChangeDetails = dmdRenderNotificationChanges(dmdNotifyDetailBody, meta.changes, meta.scope || '');
        if (!hasChangeDetails && (!meta.changes || !Object.keys(meta.changes || {}).length)) {
            const legacy = document.createElement('div');
            legacy.className = 'dmd-notify-detail-legacy';
            legacy.textContent = 'Aucun détail avant/après n’a été enregistré pour cette notification. Les nouvelles notifications créées après ce correctif conserveront le détail des changements.';
            dmdNotifyDetailBody.appendChild(legacy);
        }

        const extraKeys = Object.keys(meta).filter(k => !['changes','scope','target'].includes(k));
        if (extraKeys.length) {
            const extra = document.createElement('section');
            extra.className = 'dmd-notify-detail-section';
            const h = document.createElement('h4'); h.textContent = 'Informations complémentaires'; extra.appendChild(h);
            extraKeys.forEach(k => {
                const value = meta[k];
                if (value === null || typeof value === 'object') return;
                dmdAppendDetailLine(extra, k.replaceAll('_',' '), dmdFormatDetailValue(value));
            });
            if (extra.children.length > 1) dmdNotifyDetailBody.appendChild(extra);
        }

        const action = dmdCreateNotificationAction(item);
        if (action) {
            const actions = document.createElement('div');
            actions.className = 'dmd-notify-detail-actions';
            actions.appendChild(action);
            dmdNotifyDetailBody.appendChild(actions);
        }

        dmdNotifyDetailOverlay.classList.add('is-open');
        dmdNotifyDetailOverlay.setAttribute('aria-hidden','false');

        if (!item.read) {
            await dmdMarkNotificationRead(item.id);
            item.read = true;
            if (listBox) listBox.classList.remove('is-unread');
            if (listBox) {
                const readButton = listBox.querySelector('[data-notify-read]');
                if (readButton) readButton.remove();
            }
        }
    }

    function dmdCloseNotificationDetail() {
        if (!dmdNotifyDetailOverlay) return;
        dmdNotifyDetailOverlay.classList.remove('is-open');
        dmdNotifyDetailOverlay.setAttribute('aria-hidden','true');
    }

    function dmdRenderNotifications(data) {
        if (!dmdNotifyList) return;
        dmdNotifyList.textContent = '';
        const items = data && Array.isArray(data.items) ? data.items : [];
        dmdSetNotificationCount(data && data.unread != null ? data.unread : 0);
        if (!items.length) {
            const empty = document.createElement('div');
            empty.className = 'dmd-notify-empty';
            empty.textContent = 'Aucune notification.';
            dmdNotifyList.appendChild(empty);
            return;
        }
        items.forEach(item => {
            const box = document.createElement('article');
            box.className = 'dmd-notify-item' + (item.read ? '' : ' is-unread');
            box.dataset.level = item.level || 'info';

            const title = document.createElement('button');
            title.type = 'button';
            title.className = 'dmd-notify-item-title dmd-notify-item-title-button';
            title.title = 'Voir tous les détails';
            const icon = document.createElement('span'); icon.textContent = dmdNotificationIcon(item.level);
            const txt = document.createElement('span'); txt.textContent = item.title || 'Notification';
            title.append(icon, txt);
            title.addEventListener('click', () => dmdOpenNotificationDetail(item, box));
            box.appendChild(title);

            if (item.message) {
                const msg = document.createElement('div'); msg.className = 'dmd-notify-item-message'; msg.textContent = item.message; box.appendChild(msg);
            }
            const meta = document.createElement('div'); meta.className = 'dmd-notify-item-meta';
            meta.textContent = dmdNotificationDate(item) + (item.actor ? ' • par ' + item.actor : '');
            box.appendChild(meta);

            const actions = document.createElement('div'); actions.className = 'dmd-notify-item-actions';
            if (!item.read) {
                const readBtn = document.createElement('button'); readBtn.type = 'button'; readBtn.dataset.notifyRead = '1'; readBtn.textContent = 'Marquer lu';
                readBtn.addEventListener('click', async () => { await dmdMarkNotificationRead(item.id); item.read = true; box.classList.remove('is-unread'); readBtn.remove(); });
                actions.appendChild(readBtn);
            }
            const detailBtn = document.createElement('button');
            detailBtn.type = 'button';
            detailBtn.textContent = 'Détails';
            detailBtn.addEventListener('click', () => dmdOpenNotificationDetail(item, box));
            actions.appendChild(detailBtn);

            const action = dmdCreateNotificationAction(item);
            if (action) actions.appendChild(action);
            box.appendChild(actions);
            dmdNotifyList.appendChild(box);
        });
    }

    async function dmdLoadNotifications() {
        if (!dmdNotifyList) return;
        try {
            const r = await fetch(dmdNotifyEndpoint + '?action=list&_=' + Date.now(), {credentials:'same-origin', cache:'no-store'});
            const data = await r.json();
            if (data && data.success) dmdRenderNotifications(data);
        } catch(e) {
            dmdNotifyList.innerHTML = '<div class="dmd-notify-empty">Impossible de charger les notifications.</div>';
        }
    }

    async function dmdRefreshNotificationCount() {
        if (document.visibilityState !== 'visible' || !dmdNotifyCount) return;
        try {
            const r = await fetch(dmdNotifyEndpoint + '?action=count&_=' + Date.now(), {credentials:'same-origin', cache:'no-store'});
            const data = await r.json();
            if (data && data.success) dmdSetNotificationCount(data.unread || 0);
        } catch(e) {}
    }

    function dmdCloseNotifications() {
        if (!dmdNotifyOverlay) return;
        dmdCloseNotificationDetail();
        dmdNotifyOverlay.classList.remove('is-open');
        dmdNotifyOverlay.setAttribute('aria-hidden','true');
    }

    if (dmdNotifyTrigger && dmdNotifyOverlay) {
        dmdNotifyTrigger.addEventListener('click', () => {
            dmdNotifyOverlay.classList.add('is-open');
            dmdNotifyOverlay.setAttribute('aria-hidden','false');
            dmdLoadNotifications();
        });
        dmdNotifyClose?.addEventListener('click', dmdCloseNotifications);
        dmdNotifyDetailClose?.addEventListener('click', dmdCloseNotificationDetail);
        dmdNotifyOverlay.addEventListener('click', e => { if (e.target === dmdNotifyOverlay) dmdCloseNotifications(); });
        dmdNotifyDetailOverlay?.addEventListener('click', e => { if (e.target === dmdNotifyDetailOverlay) dmdCloseNotificationDetail(); });
        document.addEventListener('keydown', e => {
            if (e.key !== 'Escape') return;
            if (dmdNotifyDetailOverlay?.classList.contains('is-open')) dmdCloseNotificationDetail();
            else dmdCloseNotifications();
        });
        dmdNotifyReadAll?.addEventListener('click', async () => {
            const body = new URLSearchParams({action:'read_all', csrf_token:dmdNotifyCsrf});
            try {
                const r = await fetch(dmdNotifyEndpoint, {method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body});
                const data = await r.json();
                if (data && data.success) dmdLoadNotifications();
            } catch(e) {}
        });
        dmdNotifyClear?.addEventListener('click', async () => {
            if (!window.confirm('Supprimer toutes vos notifications ? Cette action est définitive.')) return;
            const body = new URLSearchParams({action:'clear', csrf_token:dmdNotifyCsrf});
            try {
                const r = await fetch(dmdNotifyEndpoint, {method:'POST', credentials:'same-origin', cache:'no-store', headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}, body});
                const data = await r.json();
                if (data && data.success) {
                    dmdCloseNotificationDetail();
                    dmdSetNotificationCount(0);
                    dmdRenderNotifications({items:[], unread:0});
                }
            } catch(e) {}
        });
        window.setInterval(dmdRefreshNotificationCount, 30000);
        document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') dmdRefreshNotificationCount(); });
    }

    const menuWrapper = document.getElementById('right-menu-wrapper');
    const toggleBtn = document.querySelector('.menu-toggle');

    if (menuWrapper && toggleBtn) {
        menuWrapper.addEventListener('mouseover', () => {
            menuWrapper.classList.add('is-open');
            menuWrapper.style.transform = 'translateX(0)';
            menuWrapper.setAttribute('aria-hidden', 'false');
            toggleBtn.setAttribute('aria-expanded', 'true');
        });

        menuWrapper.addEventListener('mouseout', () => {
            menuWrapper.classList.remove('is-open');
            menuWrapper.style.transform = 'translateX(100%)';
            menuWrapper.setAttribute('aria-hidden', 'true');
            toggleBtn.setAttribute('aria-expanded', 'false');
        });
    }

    const flash = document.getElementById('flash-cache');
    if (flash) {
        setTimeout(() => {
            flash.style.transition = 'opacity .3s';
            flash.style.opacity = '0';
            setTimeout(() => flash.remove(), 320);
        }, 1800);
    }

    const tb = document.getElementById('top-bar');
    if (tb) {
        /*
         * La barre est fixe dans le viewport : elle ne doit jamais suivre
         * le scroll horizontal du workspace. Soustraire window.scrollX
         * décale la barre vers la gauche et laisse un trou à droite.
         */
        tb.style.position = 'fixed';
        tb.style.left = '0';
        tb.style.right = '0';
        tb.style.width = '100vw';
        tb.style.willChange = 'auto';
        tb.style.transform = 'translateZ(0)';
    }
});
</script>