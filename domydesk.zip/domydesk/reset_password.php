<?php
session_start();
require_once __DIR__ . '/core/dmd_password_reset.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');

$token = trim((string)($_GET['token'] ?? ($_POST['token'] ?? '')));
$recordData = null;
$recordIndex = null;
$record = dmd_password_reset_find_record($token, $recordData, $recordIndex);
$theme = 'default';
$error = '';
$success = '';
$csrf = dmd_csrf_token('password_reset');
$email = $record ? dmd_safe_user_key((string)($record['email'] ?? '')) : '';

if ($email !== '') {
    $themePath = dmd_user_dir($email) . 'theme.json';
    if (is_file($themePath)) {
        $themeData = json_decode((string)@file_get_contents($themePath), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidate = basename((string)$themeData['theme']);
            if (is_file(__DIR__ . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
        }
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'password_reset')) {
        $error = 'Formulaire expiré. Rechargez la page depuis le lien reçu par e-mail.';
    } elseif (!$record) {
        $error = 'Ce lien de réinitialisation est invalide ou a expiré.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'verify_mfa') {
            $mfaResult = dmd_password_reset_verify_mfa($token, (string)($_POST['mfa_code'] ?? ''));
            if (empty($mfaResult['ok'])) {
                $error = (string)($mfaResult['error'] ?? 'Code MFA incorrect.');
                if (!empty($mfaResult['locked'])) $record = array();
            }
        } elseif ($action === 'reset_password') {
            $resetResult = dmd_password_reset_apply($token, (string)($_POST['new_password'] ?? ''), (string)($_POST['new_password_confirm'] ?? ''));
            if (!empty($resetResult['ok'])) {
                $success = 'Votre mot de passe a été réinitialisé avec succès (' . (string)($resetResult['target_label'] ?? 'DoMyDesk') . ').';
                $record = array();
            } else {
                $error = (string)($resetResult['error'] ?? 'La réinitialisation a échoué.');
            }
        }
    }
}

$mfaRequired = $record && $email !== '' && dmd_mfa_enabled($email);
$mfaVerified = $record && (!$mfaRequired || dmd_password_reset_mfa_is_verified($record, $token));
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Réinitialisation du mot de passe - DoMyDesk</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <?php
    require_once __DIR__ . '/core/dmd_theme_assets.php';
    echo dmd_theme_extra_links(__DIR__, 'theme', $theme, 'login');
    ?>
</head>
<body>
<main class="login-wrapper">
    <section class="login-card" aria-labelledby="reset-title">
        <div class="brand">
            <img src="adm/uploads/logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 id="reset-title">Réinitialiser le mot de passe</h1>
        </div>

        <?php if ($success !== ''): ?>
            <div class="message success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></div>
            <p class="subtitle">Vous pouvez maintenant vous connecter avec votre nouveau mot de passe.</p>
            <a class="register-link" href="login.php">Se connecter</a>
        <?php elseif (!$record): ?>
            <div class="error-message"><?= htmlspecialchars($error !== '' ? $error : 'Ce lien de réinitialisation est invalide, expiré ou a déjà été utilisé.', ENT_QUOTES, 'UTF-8') ?></div>
            <a class="register-link" href="forgot_password.php">Demander un nouveau lien</a>
            <a class="register-link" href="login.php">Retour à la connexion</a>
        <?php else: ?>
            <p class="subtitle">Compte : <strong><?= htmlspecialchars(dmd_password_reset_mask_email($email), ENT_QUOTES, 'UTF-8') ?></strong></p>

            <?php if ($error !== ''): ?>
                <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <?php if ($mfaRequired && !$mfaVerified): ?>
                <p class="subtitle">Ce compte est protégé par MFA. Confirmez la demande avec le code à 6 chiffres de Microsoft Authenticator.</p>
                <form method="post" autocomplete="off">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="verify_mfa">
                    <label for="mfa_code">Code MFA</label>
                    <input id="mfa_code" name="mfa_code" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" placeholder="000000" required autofocus>
                    <button type="submit" class="btn">Confirmer avec le MFA</button>
                </form>
            <?php else: ?>
                <?php $profile = dmd_read_profile($email); $targets = dmd_password_reset_account_targets($profile); ?>
                <p class="subtitle">
                    Le nouveau mot de passe sera appliqué à
                    <strong><?php
                        if (!empty($targets['local']) && !empty($targets['ad'])) echo 'DoMyDesk et Active Directory';
                        elseif (!empty($targets['ad'])) echo 'Active Directory';
                        else echo 'DoMyDesk';
                    ?></strong>.
                </p>
                <form method="post" autocomplete="off">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="action" value="reset_password">
                    <label for="new_password">Nouveau mot de passe</label>
                    <input type="password" id="new_password" name="new_password" minlength="8" maxlength="256" autocomplete="new-password" required autofocus>
                    <label for="new_password_confirm">Confirmer le nouveau mot de passe</label>
                    <input type="password" id="new_password_confirm" name="new_password_confirm" minlength="8" maxlength="256" autocomplete="new-password" required>
                    <button type="submit" class="btn">Réinitialiser le mot de passe</button>
                </form>
            <?php endif; ?>

            <a class="register-link" href="login.php">Annuler</a>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
