<?php
require_once __DIR__ . '/../core/dmd_domysocial_bridge.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function dmd_dms_bridge_json($data,$status=200) {
    http_response_code((int)$status);
    echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function dmd_dms_bridge_header($name) {
    $key='HTTP_'.strtoupper(str_replace('-','_',$name));
    return trim((string)($_SERVER[$key]??''));
}

$id=dmd_dms_bridge_header('X-DMS-Bridge-Id');
$timestamp=dmd_dms_bridge_header('X-DMS-Bridge-Time');
$nonce=dmd_dms_bridge_header('X-DMS-Bridge-Nonce');
$signature=dmd_dms_bridge_header('X-DMS-Bridge-Signature');
$dmsInstanceUid=dmd_dms_bridge_header('X-DMS-Instance-Uid');
$dmsInstanceName=rawurldecode(dmd_dms_bridge_header('X-DMS-Instance-Name'));
$bridgeVersion=(int)(dmd_dms_bridge_header('X-DMS-Bridge-Version') ?: 1);
$target=(string)($_SERVER['REQUEST_URI']??'');
$verified=dmd_domysocial_bridge_verify_request($id,$timestamp,$nonce,$signature,(string)($_SERVER['REQUEST_METHOD']??'GET'),$target,$dmsInstanceUid,$dmsInstanceName,$bridgeVersion);
if ($verified===false) dmd_dms_bridge_json(array('ok'=>false,'error'=>'Appairage DoMySocial refusé.'),401);
$key=$verified['key'];

$action=strtolower(trim((string)($_GET['action']??'ping')));
if ($action==='ping') {
    dmd_dms_bridge_json(array(
        'ok'=>true,
        'product'=>'DoMyDesk',
        'bridge_version'=>1,
        'instance_uid'=>dmd_domysocial_bridge_instance_uid(),
        'paired_domysocial_uid'=>(string)($verified['row']['dms_instance_uid'] ?? ''),
        'paired_domysocial_name'=>(string)($verified['row']['dms_instance_name'] ?? ''),
        'time'=>date('c'),
    ));
}
if ($action!=='export') dmd_dms_bridge_json(array('ok'=>false,'error'=>'Action inconnue.'),400);

$payload=dmd_domysocial_bridge_export(!empty($_GET['users']),!empty($_GET['media']),!empty($_GET['mfa']),!empty($_GET['directory']));
$enc=dmd_domysocial_bridge_encrypt_payload($payload,$key);
if (!is_string($enc) || $enc==='') dmd_dms_bridge_json(array('ok'=>false,'error'=>'Chiffrement du bridge indisponible.'),500);
dmd_dms_bridge_json(array('ok'=>true,'enc'=>'gcm','data'=>$enc));
