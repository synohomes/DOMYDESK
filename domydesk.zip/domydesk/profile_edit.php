<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_system_services.php';
require_once __DIR__ . '/core/dmd_media.php';
require_once __DIR__ . '/core/dmd_ui_features.php';
require_once __DIR__ . '/core/dmd_mfa.php';
require_once __DIR__ . '/core/directory/dmd_ad_sync.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (empty($_SESSION['csrf_profile_ui'])) {
    $_SESSION['csrf_profile_ui'] = bin2hex(random_bytes(32));
}

if (empty($_SESSION['csrf_profile_mfa'])) {
    $_SESSION['csrf_profile_mfa'] = bin2hex(random_bytes(32));
}

/* ==========================================================
   Fonctions
   ========================================================== */

function getUserFolder($email) {
    $safe = dmd_safe_user_key($email);
    return $safe === '' ? '' : __DIR__ . '/users/profiles/' . $safe . '/';
}

function dmd_profile_menu_base_url() {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/profile_edit.php'));
    $base = rtrim(str_replace('\\', '/', dirname($script)), '/');
    return $base === '.' ? '' : $base;
}

function dmd_profile_menu_page_link($path, $baseUrl) {
    $path = ltrim(str_replace('\\', '/', (string)$path), '/');
    return rtrim((string)$baseUrl, '/') . '/' . $path;
}

function dmd_profile_menu_available_pages($email, $baseUrl) {
    $pages = array();

    foreach (dmd_user_available_pages($email) as $page) {
        $pages[] = array(
            'id' => (string)($page['id'] ?? ''),
            'label' => (string)($page['label'] ?? ($page['id'] ?? 'Page')),
            'description' => (string)($page['description'] ?? ''),
            'link' => dmd_profile_menu_page_link((string)($page['path'] ?? ''), $baseUrl),
        );
    }

    usort($pages, function ($a, $b) {
        return strnatcasecmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
    });

    return $pages;
}

function dmd_profile_menu_sanitize_items($items, $email, $baseUrl) {
    if (!is_array($items)) {
        return array();
    }

    $clean = array();
    $catalog = dmd_page_catalog();

    foreach ($items as $item) {
        if (!is_array($item)) {
            continue;
        }

        $label = trim((string)($item['label'] ?? ''));
        if ($label === '') {
            continue;
        }

        $type = strtolower(trim((string)($item['type'] ?? 'none')));
        $link = trim((string)($item['link'] ?? ''));
        $submenu = dmd_profile_menu_sanitize_items($item['submenu'] ?? array(), $email, $baseUrl);

        if ($type === 'page') {
            $pageId = dmd_page_id_from_link($link);

            if ($pageId !== '' && isset($catalog[$pageId]) && dmd_user_can_access_page($email, $pageId)) {
                $link = dmd_profile_menu_page_link($catalog[$pageId]['path'], $baseUrl);
            } else {
                $type = 'none';
                $link = '';
            }
        } elseif ($type === 'link') {
            if (!filter_var($link, FILTER_VALIDATE_URL)) {
                $type = 'none';
                $link = '';
            } else {
                $scheme = strtolower((string)parse_url($link, PHP_URL_SCHEME));
                if (!in_array($scheme, array('http', 'https'), true)) {
                    $type = 'none';
                    $link = '';
                }
            }
        } else {
            $type = 'none';
            $link = '';
        }

        $clean[] = array(
            'label' => $label,
            'type' => $type,
            'link' => $link,
            'submenu' => $submenu,
        );
    }

    return $clean;
}

/* ==========================================================
   Session / chemins
   ========================================================== */

$userEmail = $_SESSION['user']['email'] ?? '';
$currentProfile = dmd_read_profile($userEmail);
$isAdmin = dmd_is_system_admin_profile($currentProfile);
$currentRoleSystem = (string)($currentProfile['role_system'] ?? 'user');
$isSuperadminCurrent = ($currentRoleSystem === 'superadmin');
$requestedEmail = (isset($_GET['email']) && $isAdmin) ? (string)$_GET['email'] : $userEmail;
$email = dmd_safe_user_key($requestedEmail);
if ($email === '') {
    http_response_code(400);
    exit('Utilisateur invalide.');
}

$userFolder = getUserFolder($email);

$profilePath = dmd_profile_path($email, true);
$menuPath    = $userFolder . 'menu.json';
$modulesPath = dmd_modules_acl_path($email, true);
$mediaDir    = dmd_user_media_dir($email, true);
$avatarPath  = dmd_user_avatar_file($email);
$bannerPath  = dmd_user_banner_file($email);
$avatarUrl   = $avatarPath !== '' ? dmd_media_public_url($avatarPath) : '';
$bannerUrl   = $bannerPath !== '' ? dmd_media_public_url($bannerPath) : '';
$siteMediaSettings = dmd_site_settings_read();
$siteBannerPath = dmd_site_asset_file($siteMediaSettings, 'banner_path');
$siteBannerUrl = $siteBannerPath !== '' ? dmd_media_public_url($siteBannerPath) : '';
$themePath   = $userFolder . 'theme.json';

$uiSiteSettings = dmd_ui_site_settings();
$actionHubGlobal = dmd_ui_global_tool('actionhub', $uiSiteSettings);
$quickSessionGlobal = dmd_ui_global_tool('quick_session', $uiSiteSettings);
$actionHubUserLocation = dmd_ui_user_location($email, 'actionhub', $uiSiteSettings);
$quickSessionUserLocation = dmd_ui_user_location($email, 'quick_session', $uiSiteSettings);

$installedThemes = array_map('basename', glob(__DIR__ . "/theme/*", GLOB_ONLYDIR) ?: []);

$theme = 'default';
$themeData = [];
$uiScale = 100;
$moduleListIcons = true;

if (file_exists($themePath)) {
    $themeData = json_decode(file_get_contents($themePath), true);
    if (!is_array($themeData)) $themeData = [];

    if (!empty($themeData['theme']) && file_exists(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")) {
        $theme = basename($themeData['theme']);
    }
    if (isset($themeData['ui_scale']) && is_numeric($themeData['ui_scale'])) {
        $uiScale = max(60, min(150, (int)$themeData['ui_scale']));
    }
    if (array_key_exists('module_list_icons', $themeData)) {
        $moduleListIcons = (bool)$themeData['module_list_icons'];
    }
}

$baseUrl = dmd_profile_menu_base_url();
$availablePages = dmd_profile_menu_available_pages($email, $baseUrl);

$userData    = file_exists($profilePath) ? json_decode(file_get_contents($profilePath), true) : [];
$menuDataRaw = file_exists($menuPath) ? json_decode(file_get_contents($menuPath), true) : [];
$menuData    = dmd_profile_menu_sanitize_items($menuDataRaw['items']['items'] ?? [], $email, $baseUrl);

$rolesFile    = 'data/roles_metier.json';
$rolesMetiers = file_exists($rolesFile) ? json_decode(file_get_contents($rolesFile), true) : [];
$roleSystemOptions = $isSuperadminCurrent ? ['user', 'admin', 'superadmin'] : ['user', 'admin'];

$hasProfileExport = dmd_user_can_use_module($email, 'savev.1')
    && dmd_user_module_is_enabled($email, 'savev.1');

$isSelf = ($email === $userEmail);
$existingHash = $userData['motdepasse'] ?? ($userData['password'] ?? null);
$isActiveDirectoryAccount = strtolower((string)($userData['auth_source'] ?? 'local')) === 'active_directory';
$targetRoleSystem = (string)($userData['role_system'] ?? 'user');
$adminCannotManageTarget = ($isAdmin && !$isSuperadminCurrent && !$isSelf && $targetRoleSystem === 'superadmin');
$mfaEnabledForTarget = dmd_mfa_enabled($email);
$mfaPolicyForTarget = dmd_mfa_effective_policy($email, $userData);
$mfaDisableRequestForTarget = $mfaEnabledForTarget ? dmd_mfa_disable_request($email) : array();

/* ==========================================================
   POST
   ========================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($adminCannotManageTarget) {
        $message = '❌ Un compte Admin ne peut pas modifier un compte Superadmin.';
        dmd_system_log('superadmin_profile_change_denied', $email, 'denied', 'Un administrateur a tenté de modifier un compte Superadmin.');
    }

    elseif (isset($_POST['update_mfa_preference'])) {
        if (!$isSelf) {
            $message = '❌ La préférence MFA ne peut être modifiée que par le propriétaire du compte.';
        } else {
            $token = (string)($_POST['csrf_profile_mfa'] ?? '');
            if ($token === '' || !hash_equals((string)($_SESSION['csrf_profile_mfa'] ?? ''), $token)) {
                $message = '❌ Formulaire MFA expiré ou invalide.';
            } else {
                $wantMfa = !empty($_POST['mfa_enabled_toggle']);
                $mfaEnabledNow = dmd_mfa_enabled($email);
                $mfaPolicyNow = dmd_mfa_effective_policy($email, $userData);
                $pendingRequest = dmd_mfa_disable_request($email);

                if ($wantMfa) {
                    if ($mfaPolicyNow === 'disabled') {
                        $message = '❌ Le MFA est désactivé pour ce compte par la politique DoMyDesk.';
                    } elseif (!empty($pendingRequest)) {
                        if (dmd_mfa_clear_disable_request($email, (string)($pendingRequest['request_id'] ?? ''))) {
                            $message = '✅ Demande de désactivation annulée. Le MFA reste actif.';
                            dmd_system_log('mfa_disable_request_cancelled', $email, 'success', 'Demande de désactivation MFA annulée depuis le profil utilisateur.');
                        } else {
                            $message = '❌ Impossible d’annuler la demande de désactivation MFA.';
                        }
                    } elseif (!$mfaEnabledNow) {
                        header('Location: mfa_setup.php');
                        exit;
                    } else {
                        $message = '✅ Le MFA est déjà activé sur votre compte.';
                    }
                } else {
                    if (!$mfaEnabledNow) {
                        $message = '✅ Le MFA est déjà désactivé sur votre compte.';
                    } elseif (!empty($pendingRequest)) {
                        $message = '⏳ Une demande de désactivation MFA est déjà en attente de validation Superadmin.';
                    } else {
                        $password = (string)($_POST['mfa_disable_password'] ?? '');
                        $code = (string)($_POST['mfa_disable_code'] ?? '');
                        $hash = (string)($userData['motdepasse'] ?? ($userData['password'] ?? ''));
                        $usedRecovery = false;
                        $passwordOk = false;
                        if ($isActiveDirectoryAccount) {
                            $adPasswordCheck = dmd_directory_authenticate_ad_profile($userData, $password);
                            $passwordOk = !empty($adPasswordCheck['ok']);
                        } else {
                            $passwordOk = ($hash !== '' && password_verify($password, $hash));
                        }

                        if (!$passwordOk) {
                            $message = '❌ Mot de passe actuel incorrect.';
                        } elseif (!dmd_mfa_verify_user_code($email, $code, $usedRecovery)) {
                            $message = '❌ Code Authenticator ou code de secours incorrect.';
                        } else {
                            $request = dmd_mfa_request_disable($email, $email);
                            if ($request === false) {
                                $message = '❌ Impossible d’enregistrer la demande de désactivation MFA.';
                            } else {
                                $message = '⏳ Demande de désactivation envoyée au Superadmin. Le MFA reste actif jusqu’à sa validation.';
                                dmd_system_log('mfa_disable_requested', $email, 'warning', 'Désactivation MFA demandée depuis le profil utilisateur ; validation Superadmin requise.', array('request_id' => (string)($request['request_id'] ?? '')));
                                if (function_exists('dmd_notify_system_role')) {
                                    dmd_notify_system_role('superadmin', 'mfa_disable_requested', 'Validation MFA requise', 'Un utilisateur demande la désactivation de son MFA.', array(
                                        'level' => 'warning',
                                        'action_url' => 'adm/mfa_requests.php',
                                        'action_label' => 'Examiner',
                                        'requires_superadmin' => true,
                                        'meta' => array('target_user' => $email, 'request_id' => (string)($request['request_id'] ?? '')),
                                    ));
                                }
                                if (function_exists('dmd_notify_user')) {
                                    dmd_notify_user($email, 'security', 'Demande de désactivation MFA envoyée', 'Votre MFA reste actif jusqu’à validation par un Superadmin.', array('level' => 'warning'));
                                }
                            }
                        }
                    }
                }
            }
        }

        $mfaEnabledForTarget = dmd_mfa_enabled($email);
        $mfaPolicyForTarget = dmd_mfa_effective_policy($email, $userData);
        $mfaDisableRequestForTarget = $mfaEnabledForTarget ? dmd_mfa_disable_request($email) : array();
    }

    elseif (isset($_POST['update_profile'])) {
        $userData['prenom'] = trim((string)($_POST['first_name'] ?? ''));
        $userData['nom']    = trim((string)($_POST['last_name'] ?? ''));

        if ($isAdmin) {
            $requestedRoleMetier = trim((string)($_POST['job_role'] ?? ''));

            if ($requestedRoleMetier === '' || in_array($requestedRoleMetier, $rolesMetiers, true)) {
                $userData['role_metier'] = $requestedRoleMetier;
            }

            if (isset($_POST['role_system']) && in_array($_POST['role_system'], $roleSystemOptions, true)) {
                $requestedSystemRole = (string)$_POST['role_system'];
                if ($isSuperadminCurrent && $targetRoleSystem === 'superadmin' && $requestedSystemRole !== 'superadmin') {
                    $idx = dmd_notification_index();
                    $superadmins = isset($idx['role_system']['superadmin']) && is_array($idx['role_system']['superadmin']) ? $idx['role_system']['superadmin'] : [];
                    if (count($superadmins) <= 1) {
                        $requestedSystemRole = 'superadmin';
                        $message = '❌ Le dernier Superadmin ne peut pas être rétrogradé.';
                    }
                }
                $userData['role_system'] = $requestedSystemRole;
            }
        }

        $profileExtraFields = [
            'pseudo', 'adresse', 'code_postal', 'ville', 'pays',
            'telephone', 'whatsapp', 'facebook', 'groupe_facebook', 'linkedin',
            'instagram', 'site_web', 'entreprise', 'poste', 'service',
            'bio', 'autres_infos'
        ];

        if ($isAdmin) {
            $profileExtraFields[] = 'notes_admin';
        }

        foreach ($profileExtraFields as $fieldName) {
            $userData[$fieldName] = trim((string)($_POST[$fieldName] ?? ''));
        }

        if (!is_dir($userFolder)) {
            mkdir($userFolder, 0755, true);
        }

        if (dmd_write_profile($email, $userData)) {
            $message = "Profil mis à jour avec succès.";
            dmd_notification_index_refresh_user($email);
            if ($isAdmin && !$isSelf) {
                dmd_system_log('user_profile_updated', $email, 'success', 'Profil utilisateur modifié depuis l’administration.');
                dmd_notify_user($email, 'profile_changed', 'Votre profil a été modifié', 'Un administrateur a mis à jour votre profil DoMyDesk.', ['level' => 'warning', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
            }
        } else {
            $message = "❌ Impossible d’enregistrer le profil.";
        }
    }

    elseif (isset($_POST['remove_avatar'])) {
        dmd_media_remove_named($mediaDir, 'avatar');
        dmd_media_remove_named($userFolder, 'avatar');
        $avatarPath = '';
        $avatarUrl = '';
        $message = "Avatar supprimé.";
        if ($isAdmin && !$isSelf) {
            dmd_system_log('user_avatar_removed', $email, 'success', 'Avatar utilisateur supprimé depuis l’administration.');
            dmd_notify_user($email, 'profile_changed', 'Votre avatar a été supprimé', 'Un administrateur a supprimé votre avatar DoMyDesk.', ['level' => 'info']);
        }
    }

    elseif (isset($_POST['remove_banner'])) {
        dmd_media_remove_named($mediaDir, 'baniere');
        $bannerPath = '';
        $bannerUrl = '';
        $message = "Bannière personnelle supprimée. La bannière du site sera utilisée si elle existe.";
        if ($isAdmin && !$isSelf) {
            dmd_system_log('user_banner_removed', $email, 'success', 'Bannière utilisateur supprimée depuis l’administration.');
            dmd_notify_user($email, 'profile_changed', 'Votre bannière a été supprimée', 'Un administrateur a supprimé votre bannière personnelle. La bannière du site sera utilisée si elle existe.', ['level' => 'info']);
        }
    }

    elseif (isset($_POST['upload_avatar'])) {
        $stored = dmd_media_store_upload($_FILES['avatar'] ?? array(), $mediaDir, 'avatar', true);
        if (!empty($stored['success'])) {
            $avatarPath = (string)$stored['file'];
            $avatarUrl = dmd_media_public_url($avatarPath);
            $message = "Avatar mis à jour avec succès.";
            if ($isAdmin && !$isSelf) {
                dmd_system_log('user_avatar_updated', $email, 'success', 'Avatar utilisateur modifié depuis l’administration.');
                dmd_notify_user($email, 'profile_changed', 'Votre avatar a été modifié', 'Un administrateur a mis à jour votre avatar DoMyDesk.', ['level' => 'info', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
            }
        } else {
            $message = "❌ " . (string)($stored['error'] ?? 'Erreur upload avatar.');
        }
    }

    elseif (isset($_POST['upload_banner'])) {
        $stored = dmd_media_store_upload($_FILES['banner'] ?? array(), $mediaDir, 'baniere', true);
        if (!empty($stored['success'])) {
            $bannerPath = (string)$stored['file'];
            $bannerUrl = dmd_media_public_url($bannerPath);
            $message = "Bannière mise à jour avec succès.";
            if ($isAdmin && !$isSelf) {
                dmd_system_log('user_banner_updated', $email, 'success', 'Bannière utilisateur modifiée depuis l’administration.');
                dmd_notify_user($email, 'profile_changed', 'Votre bannière a été modifiée', 'Un administrateur a mis à jour la bannière de votre profil DoMyDesk.', ['level' => 'info', 'action_url' => 'profile_view.php', 'action_label' => 'Voir mon profil']);
            }
        } else {
            $message = "❌ " . (string)($stored['error'] ?? 'Erreur upload bannière.');
        }
    }

    elseif (isset($_POST['update_core_tools_ui'])) {
        $token = $_POST['csrf_profile_ui'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf_profile_ui'] ?? '', $token)) {
            $message = '❌ Formulaire des outils Core expiré ou invalide.';
        } else {
            $locations = array();

            if (!empty($actionHubGlobal['enabled'])) {
                $locations['actionhub'] = dmd_ui_normalize_location(
                    $_POST['actionhub_location'] ?? $actionHubUserLocation,
                    $actionHubGlobal['default_location'] ?? 'header'
                );
            }

            if (!empty($quickSessionGlobal['enabled'])) {
                $locations['quick_session'] = dmd_ui_normalize_location(
                    $_POST['quick_session_location'] ?? $quickSessionUserLocation,
                    $quickSessionGlobal['default_location'] ?? 'header'
                );
            }

            if (dmd_ui_save_user_locations($email, $locations)) {
                $message = '✅ Emplacement des outils Core enregistré.';
                dmd_system_log('user_core_tools_ui_updated', $email, 'success', 'Préférences ActionHub / Quick-Session mises à jour.', array('locations' => $locations));
                if ($isAdmin && !$isSelf) {
                    dmd_notify_user($email, 'profile_changed', 'Vos outils DoMyDesk ont été modifiés', 'Un administrateur a modifié l’emplacement de vos outils ActionHub / Quick-Session.', array('level' => 'info'));
                }
            } else {
                $message = '❌ Impossible d’enregistrer les préférences des outils Core.';
            }
        }

        if (isset($locations['actionhub'])) {
            $actionHubUserLocation = $locations['actionhub'];
        }
        if (isset($locations['quick_session'])) {
            $quickSessionUserLocation = $locations['quick_session'];
        }
    }

    elseif (isset($_POST['update_theme'])) {
        $themeChoice = basename($_POST['theme'] ?? 'default');
        $uiScaleChoice = max(60, min(150, (int)($_POST['ui_scale'] ?? 100)));
        $moduleListIconsChoice = !empty($_POST['module_list_icons']);

        file_put_contents($themePath, json_encode([
            'theme' => $themeChoice,
            'ui_scale' => $uiScaleChoice,
            'module_list_icons' => $moduleListIconsChoice,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        if ($isAdmin && !$isSelf) {
            dmd_system_log('user_theme_updated', $email, 'success', 'Thème utilisateur modifié.', ['theme' => $themeChoice]);
            dmd_notify_user($email, 'profile_changed', 'Votre thème a été modifié', 'Un administrateur a modifié le thème de votre compte.', ['level' => 'info']);
        }

        $redir = 'profile_edit.php';

        if ($isAdmin && isset($_GET['email'])) {
            $redir .= '?email=' . urlencode($_GET['email']);
        }

        header("Location: $redir");
        exit;
    }

    elseif (isset($_POST['import_theme'])) {
        if (!class_exists('ZipArchive')) {
            $message = "❌ ZipArchive non disponible sur le serveur.";
        } elseif (isset($_FILES['theme_zip']) && is_uploaded_file($_FILES['theme_zip']['tmp_name'])) {
            $zipPath = $_FILES['theme_zip']['tmp_name'];
            $zip = new ZipArchive;

            if ($zip->open($zipPath) === true) {
                $folderName = basename($_FILES['theme_zip']['name'], '.zip');
                $extractPath = __DIR__ . "/theme/" . $folderName;

                if (!is_dir("theme")) {
                    mkdir("theme", 0755, true);
                }

                if (!is_dir($extractPath)) {
                    mkdir($extractPath, 0755, true);
                }

                $zip->extractTo($extractPath);
                $zip->close();

                $message = "Thème importé avec succès.";
            } else {
                $message = "❌ Impossible d’ouvrir le fichier ZIP.";
            }
        } else {
            $message = "❌ Erreur lors de l’import du fichier ZIP.";
        }
    }

    elseif (isset($_POST['update_menu'])) {
        $menuJson = $_POST['menu_json'] ?? '';
        $decodedMenu = json_decode($menuJson, true);

        if (is_array($decodedMenu)) {
            $decodedMenu = dmd_profile_menu_sanitize_items($decodedMenu, $email, $baseUrl);
            $fullMenu = ['items' => ['items' => $decodedMenu]];

            if (!is_dir($userFolder)) {
                mkdir($userFolder, 0755, true);
            }

            file_put_contents($menuPath, json_encode($fullMenu, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

            $menuData = $decodedMenu;
            $message = "✅ Menu latéral mis à jour.";
            if ($isAdmin && !$isSelf) {
                dmd_system_log('user_menu_updated', $email, 'success', 'Menu utilisateur modifié depuis l’administration.');
                dmd_notify_user($email, 'profile_changed', 'Votre menu a été modifié', 'Un administrateur a mis à jour votre menu DoMyDesk.', ['level' => 'info']);
            }
        } else {
            $message = "❌ Format JSON du menu invalide.";
        }
    }

    elseif (isset($_POST['change_password'])) {
        if ($isActiveDirectoryAccount) {
            $message = "❌ Le mot de passe de ce compte est géré par Active Directory et ne peut pas être modifié localement dans DoMyDesk.";
            goto end_change_pwd;
        }

        $new1 = $_POST['new_password'] ?? '';
        $new2 = $_POST['new_password_confirm'] ?? '';
        $old  = $_POST['current_password'] ?? '';
        $forceReset = !empty($_POST['reset_without_old']);

        if (strlen($new1) < 8) {
            $message = "❌ Nouveau mot de passe trop court, minimum 8 caractères.";
        } elseif ($new1 !== $new2) {
            $message = "❌ La confirmation ne correspond pas.";
        } else {
            $changingOwn = ($email === $userEmail) || !$isAdmin;

            if ($changingOwn && !empty($existingHash) && !$forceReset) {
                if ($old === '' || !password_verify($old, $existingHash)) {
                    $message = "❌ Ancien mot de passe incorrect. Cochez la réinitialisation si vous l’avez oublié.";
                    goto end_change_pwd;
                }
            }

            $newHash = password_hash($new1, PASSWORD_DEFAULT);

            $userData['motdepasse'] = $newHash;
            $userData['password'] = $newHash;

            if (isset($userData['password_hash'])) {
                unset($userData['password_hash']);
            }

            if (!is_dir($userFolder)) {
                mkdir($userFolder, 0755, true);
            }

            file_put_contents($profilePath, json_encode($userData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            $message = $changingOwn ? "✅ Mot de passe mis à jour." : "✅ Mot de passe réinitialisé pour l’utilisateur.";
            if (!$changingOwn && $isAdmin) {
                dmd_system_log('user_password_reset', $email, 'success', 'Mot de passe utilisateur réinitialisé par un administrateur.');
                dmd_notify_user($email, 'security', 'Votre mot de passe a été réinitialisé', 'Un administrateur a réinitialisé le mot de passe de votre compte DoMyDesk.', ['level' => 'warning']);
            }
        }

        end_change_pwd: ;
    }
}

/* ==========================================================
   Modules configurables
   ========================================================== */

$moduleCards = [];

/*
 * 1.2.0 : profile/modules.json n'est plus l'ancien tableau des modules.
 * C'est maintenant une ACL (enabled/overrides). On passe donc par le Core
 * pour récupérer uniquement les modules installés + autorisés + activés.
 */
$activeModules = dmd_effective_modules($email, true);

foreach ($activeModules as $moduleId => $mod) {
    $mid = basename((string)($mod['id'] ?? $moduleId));

    if ($mid === '') {
        continue;
    }

    $moduleDir = __DIR__ . '/modules/' . $mid;

    /* Convention actuelle + compatibilité anciens modules. */
    $cfgCandidates = [
        $moduleDir . '/' . $mid . 'cfg.php',
        $moduleDir . '/' . $mid . '_cfg.php',
    ];

    $cfgFile = '';

    foreach ($cfgCandidates as $candidate) {
        if (is_file($candidate)) {
            $cfgFile = $candidate;
            break;
        }
    }

    if ($cfgFile === '') {
        continue;
    }

    /*
     * Chemin disque absolu avec __DIR__, URL web absolue depuis la racine
     * courante de DoMyDesk. Ainsi l'iframe ne dépend plus du dossier courant.
     */
    $cfgBasename = basename($cfgFile);
    $cfgUrl = $baseUrl
        . '/modules/' . rawurlencode($mid)
        . '/' . rawurlencode($cfgBasename);

    $moduleCards[] = [
        'id' => $mid,
        'name' => $mod['name'] ?? strtoupper($mid),
        'description' => $mod['description'] ?? 'Module configurable',
        'cfg_url' => $cfgUrl,
    ];
}

$themeFile = __DIR__ . "/theme/$theme/style.css";
$themeHref = $baseUrl . "/theme/" . rawurlencode($theme) . "/style.css";

if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>DoMyDesk - Profil</title>
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($baseUrl) ?>/core/dmd_profile_media.css?v=<?= is_file(__DIR__ . '/core/dmd_profile_media.css') ? (int)filemtime(__DIR__ . '/core/dmd_profile_media.css') : 120 ?>">
</head>

<body>
<?php include 'header.php'; ?>

<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">Configuration du profil</h1>
            <p class="pe-subtitle">Configuration de votre compte, vos menus, vos modules.</p>
        </div>

        <div class="pe-head-right">
            <?php if ($avatarUrl !== ''): ?>
                <img class="pe-head-avatar" src="<?= htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Photo de profil">
            <?php else: ?>
                <div class="pe-head-avatar-empty">
                    <?= htmlspecialchars(strtoupper(substr(trim(($userData['prenom'] ?? 'U')), 0, 1))) ?>
                </div>
            <?php endif; ?>

            <div class="pe-card-main">
                <div class="pe-user-pill"><?= htmlspecialchars($email) ?></div>
                <div class="field-inline">
                    <span class="mod-id">
                        ID instance :
                        <strong id="dmd-instance-id"><?= htmlspecialchars($domydeskId ?? 'ID non défini', ENT_QUOTES, 'UTF-8') ?></strong>
                    </span>
                    <button
                        type="button"
                        class="icon-link"
                        id="copy-instance-id"
                        title="Copier l’ID de l’instance"
                        aria-label="Copier l’ID de l’instance"
                    >📋</button>
                </div>
            </div>
        </div>
    </div>

    <h2 class="pe-section-title">Vos paramètres</h2>

    <div class="pe-grid">
        <button type="button" class="pe-card" data-popup-open="popup-profile">
            <span class="pe-card-main">
                <span class="pe-card-title">Votre profil</span>
                <span class="pe-card-desc">Nom, prénom, contact, réseaux et informations</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-security">
            <span class="pe-card-main">
                <span class="pe-card-title">Sécurité</span>
                <span class="pe-card-desc">Modifier ou réinitialiser le mot de passe / Configurer MFA</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-avatar">
            <span class="pe-card-main">
                <span class="pe-card-title">Avatar & bannière</span>
                <span class="pe-card-desc">Images du profil utilisateur</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-theme">
            <span class="pe-card-main">
                <span class="pe-card-title">Thème</span>
                <span class="pe-card-desc">Choix, aperçu</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-core-tools-ui">
            <span class="pe-card-main">
                <span class="pe-card-title">Outils rapides</span>
                <span class="pe-card-desc">ActionHub et Quick-Session : header, menu vertical ou masqué</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>

        <button type="button" class="pe-card" data-popup-open="popup-menu">
            <span class="pe-card-main">
                <span class="pe-card-title">Menu vertical</span>
                <span class="pe-card-desc">Organisation du menu utilisateur</span>
            </span>
            <span class="pe-card-icon">›</span>
        </button>
    </div>

    <h2 class="pe-section-title">Vos modules</h2>

    <?php if (empty($moduleCards)): ?>
        <div class="message">Aucun module configurable.</div>
    <?php else: ?>
        <div class="pe-module-search">
            <input type="text" id="moduleSearch" placeholder="Recherche...">
        </div>

        <div class="pe-module-grid" id="moduleGrid">
            <?php foreach ($moduleCards as $c): ?>
                <button
                    type="button"
                    class="pe-card"
                    data-module-card
                    data-name="<?= htmlspecialchars(strtolower(($c['name'] ?? '') . ' ' . ($c['id'] ?? '') . ' ' . ($c['description'] ?? ''))) ?>"
                    data-mod="<?= htmlspecialchars($c['id']) ?>"
                    data-label="<?= htmlspecialchars($c['name']) ?>"
                    data-cfg-url="<?= htmlspecialchars($c['cfg_url'], ENT_QUOTES, 'UTF-8') ?>"
                >
                    <img class="dmd-user-module-icon" src="<?= htmlspecialchars($baseUrl . '/modules/' . rawurlencode($c['id']) . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt="" onerror="this.style.display='none'">
                    <span class="pe-card-main">
                        <span class="pe-card-title"><?= htmlspecialchars($c['name']) ?></span>
                    </span>
                    <span class="pe-card-icon">›</span>
                </button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div id="popup-profile" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Votre profil</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" autocomplete="off" class="pe-form">
                <input type="hidden" name="update_profile" value="1">

                <div class="pe-form-row">
                    <div>
                        <label>Prénom</label>
                        <input type="text" name="first_name" value="<?= htmlspecialchars($userData['prenom'] ?? '') ?>" required>
                    </div>

                    <div>
                        <label>Nom</label>
                        <input type="text" name="last_name" value="<?= htmlspecialchars($userData['nom'] ?? '') ?>" required>
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Pseudo</label>
                        <input type="text" name="pseudo" value="<?= htmlspecialchars($userData['pseudo'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Rôle métier</label>
                        <?php if ($isAdmin): ?>
                            <select name="job_role">
                                <option value="">-- Aucun rôle métier --</option>
                                <?php foreach ($rolesMetiers as $role): ?>
                                    <?php
                                        $val = is_array($role) ? ($role['label'] ?? $role['value'] ?? '') : $role;
                                        $selected = ($userData['role_metier'] ?? '') === $val ? 'selected' : '';
                                    ?>
                                    <option value="<?= htmlspecialchars($val) ?>" <?= $selected ?>>
                                        <?= htmlspecialchars($val) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input type="text" value="<?= htmlspecialchars($userData['role_metier'] ?? 'Aucun rôle métier') ?>" readonly>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($isAdmin): ?>
                    <div class="pe-form-row">
                        <div>
                            <label>Rôle système</label>
                            <select name="role_system">
                                <?php foreach ($roleSystemOptions as $roleSystemOption): ?>
                                    <option value="<?= htmlspecialchars($roleSystemOption) ?>" <?= (($userData['role_system'] ?? 'user') === $roleSystemOption) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($roleSystemOption) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label>E-mail / dossier utilisateur</label>
                            <input type="text" value="<?= htmlspecialchars($email) ?>" readonly>
                        </div>
                    </div>
                <?php endif; ?>

                <h3>Adresse</h3>
                <div class="pe-form-row">
                    <div>
                        <label>Adresse</label>
                        <input type="text" name="adresse" value="<?= htmlspecialchars($userData['adresse'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Code postal</label>
                        <input type="text" name="code_postal" value="<?= htmlspecialchars($userData['code_postal'] ?? '') ?>">
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Ville</label>
                        <input type="text" name="ville" value="<?= htmlspecialchars($userData['ville'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Pays</label>
                        <input type="text" name="pays" value="<?= htmlspecialchars($userData['pays'] ?? '') ?>">
                    </div>
                </div>

                <h3>Contact</h3>
                <div class="pe-form-row">
                    <div>
                        <label>Téléphone</label>
                        <input type="text" name="telephone" value="<?= htmlspecialchars($userData['telephone'] ?? '') ?>">
                    </div>

                    <div>
                        <label>WhatsApp</label>
                        <input type="text" name="whatsapp" value="<?= htmlspecialchars($userData['whatsapp'] ?? '') ?>">
                    </div>
                </div>

                <h3>Réseaux</h3>
                <div class="pe-form-row">
                    <div>
                        <label>Facebook</label>
                        <input type="text" name="facebook" value="<?= htmlspecialchars($userData['facebook'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Groupe Facebook</label>
                        <input type="text" name="groupe_facebook" value="<?= htmlspecialchars($userData['groupe_facebook'] ?? '') ?>">
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>LinkedIn</label>
                        <input type="text" name="linkedin" value="<?= htmlspecialchars($userData['linkedin'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Instagram</label>
                        <input type="text" name="instagram" value="<?= htmlspecialchars($userData['instagram'] ?? '') ?>">
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Site web</label>
                        <input type="text" name="site_web" value="<?= htmlspecialchars($userData['site_web'] ?? '') ?>">
                    </div>
                </div>

                <h3>Informations</h3>
                <div class="pe-form-row">
                    <div>
                        <label>Entreprise</label>
                        <input type="text" name="entreprise" value="<?= htmlspecialchars($userData['entreprise'] ?? '') ?>">
                    </div>

                    <div>
                        <label>Poste</label>
                        <input type="text" name="poste" value="<?= htmlspecialchars($userData['poste'] ?? '') ?>">
                    </div>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Service</label>
                        <input type="text" name="service" value="<?= htmlspecialchars($userData['service'] ?? '') ?>">
                    </div>
                </div>

                <div>
                    <label>Bio</label>
                    <textarea name="bio" rows="3"><?= htmlspecialchars($userData['bio'] ?? '') ?></textarea>
                </div>

                <div>
                    <label>Autres informations</label>
                    <textarea name="autres_infos" rows="3"><?= htmlspecialchars($userData['autres_infos'] ?? '') ?></textarea>
                </div>

                <?php if ($isAdmin): ?>
                    <div>
                        <label>Notes admin</label>
                        <textarea name="notes_admin" rows="3"><?= htmlspecialchars($userData['notes_admin'] ?? '') ?></textarea>
                    </div>
                <?php endif; ?>

                <div class="pe-actions">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-security" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Sécurité</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if ($isActiveDirectoryAccount): ?>
                <div class="pe-form">
                    <p class="pe-note"><strong>Compte Active Directory.</strong> Le mot de passe est géré par l’annuaire et n’est pas stocké dans DoMyDesk. Sa modification locale est désactivée.</p>
                </div>
            <?php else: ?>
            <form method="POST" autocomplete="off" class="pe-form">
                <input type="hidden" name="change_password" value="1">

                <?php if ($isSelf || !$isAdmin || $email === $userEmail): ?>
                    <?php if (!empty($existingHash)): ?>
                        <div>
                            <label>Ancien mot de passe</label>
                            <input type="password" name="current_password" placeholder="Facultatif si vous cochez la réinitialisation">
                        </div>

                        <label class="pe-check-line">
                            <input type="checkbox" name="reset_without_old" value="1">
                            Je ne connais plus l’ancien mot de passe, réinitialiser quand même
                        </label>
                    <?php else: ?>
                        <p class="pe-note">Aucun mot de passe défini encore pour ce compte.</p>
                        <input type="hidden" name="reset_without_old" value="1">
                    <?php endif; ?>
                <?php else: ?>
                    <p class="pe-note">
                        Administrateur : réinitialisation sans ancien mot de passe pour
                        <strong><?= htmlspecialchars($email) ?></strong>.
                    </p>
                    <input type="hidden" name="reset_without_old" value="1">
                <?php endif; ?>

                <div class="pe-form-row">
                    <div>
                        <label>Nouveau mot de passe</label>
                        <input type="password" name="new_password" placeholder="Min 8 caractères" minlength="8" required>
                    </div>

                    <div>
                        <label>Confirmation</label>
                        <input type="password" name="new_password_confirm" placeholder="Répétez le mot de passe" minlength="8" required>
                    </div>
                </div>

                <div class="pe-actions">
                    <button type="submit">Mettre à jour</button>
                </div>
            </form>
            <?php endif; ?>

            <hr>

            <div class="pe-form">
                <div>
                    <label>Authentification multifacteur (MFA)</label>
                    <p class="pe-note">
                        État : <strong><?= $mfaEnabledForTarget ? '✅ Configuré — Microsoft Authenticator' : '⚪ Non configuré' ?></strong><br>
                        Politique : <strong><?= $mfaPolicyForTarget === 'required' ? '🔒 Obligatoire' : ($mfaPolicyForTarget === 'disabled' ? '⛔ Désactivé par le Superadmin' : '⚪ Facultatif') ?></strong>
                    </p>
                    <?php if ($mfaPolicyForTarget === 'disabled' && $mfaEnabledForTarget): ?>
                        <p class="pe-note">La configuration MFA est conservée, mais elle n’est pas utilisée à la connexion tant que la politique centrale la désactive.</p>
                    <?php endif; ?>
                    <?php if (!empty($mfaDisableRequestForTarget)): ?>
                        <p class="pe-note"><strong>⏳ Une demande de désactivation est en attente de validation Superadmin.</strong> Le MFA reste actif.</p>
                    <?php endif; ?>
                </div>

                <?php if ($isSelf): ?>
                    <?php if ($mfaPolicyForTarget === 'disabled'): ?>
                        <div class="pe-actions">
                            <span class="pe-note">Le MFA est désactivé pour votre compte par la politique centrale DoMyDesk.</span>
                            <a href="mfa_setup.php" class="btn">Voir la politique MFA</a>
                        </div>
                    <?php else: ?>
                        <form method="POST" autocomplete="off" class="pe-form" id="mfa-preference-form">
                            <input type="hidden" name="update_mfa_preference" value="1">
                            <input type="hidden" name="csrf_profile_mfa" value="<?= htmlspecialchars($_SESSION['csrf_profile_mfa'], ENT_QUOTES, 'UTF-8') ?>">

                            <label class="pe-check-line" style="font-weight:700;">
                                <input type="checkbox" id="mfa-enabled-toggle" name="mfa_enabled_toggle" value="1" <?= ($mfaEnabledForTarget && empty($mfaDisableRequestForTarget)) ? 'checked' : '' ?>>
                                Activer le MFA sur mon compte
                            </label>

                            <?php if (!empty($mfaDisableRequestForTarget)): ?>
                                <p class="pe-note"><strong>⏳ Désactivation demandée.</strong> Le MFA reste actif jusqu’à la décision du Superadmin. Recochez la case puis enregistrez pour annuler votre demande.</p>
                            <?php elseif ($mfaEnabledForTarget): ?>
                                <p class="pe-note">Décochez la case pour demander la désactivation. Votre MFA restera actif jusqu’à validation par un Superadmin.</p>
                                <div id="mfa-disable-confirmation" hidden>
                                    <div class="pe-form-row">
                                        <div><label>Mot de passe actuel</label><input type="password" id="mfa-disable-password" name="mfa_disable_password" autocomplete="current-password"></div>
                                        <div><label>Code Authenticator ou code de secours</label><input type="text" id="mfa-disable-code" name="mfa_disable_code" autocomplete="one-time-code" inputmode="numeric"></div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <p class="pe-note">Cochez la case puis enregistrez pour lancer la configuration Microsoft Authenticator.</p>
                            <?php endif; ?>

                            <div class="pe-actions">
                                <button type="submit">Enregistrer MFA</button>
                                <?php if ($mfaEnabledForTarget): ?><a href="mfa_setup.php" class="btn">Gérer Microsoft Authenticator</a><?php endif; ?>
                            </div>
                        </form>
                    <?php endif; ?>
                <?php elseif ($isSuperadminCurrent && !empty($mfaDisableRequestForTarget)): ?>
                    <div class="pe-actions"><a href="adm/mfa_requests.php" class="btn">Examiner la demande MFA</a></div>
                <?php else: ?>
                    <div class="pe-actions"><span class="pe-note">La configuration MFA appartient à l’utilisateur.</span></div>
                <?php endif; ?>
            </div>

            <?php if ($hasProfileExport): ?>
                <hr>

                <div class="pe-form">
                    <div>
                        <label>Export du profil</label>
                        <p class="pe-note">
                            Télécharge une sauvegarde complète de votre dossier utilisateur DoMyDesk.
                        </p>
                    </div>

                    <div class="pe-actions">
                        <a href="modules/savev.1/download.php" class="btn">
                            Exporter son profil complet
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div id="popup-avatar" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Avatar & bannière</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <?php if (!empty($message) && (isset($_POST['upload_avatar']) || isset($_POST['upload_banner']) || isset($_POST['remove_avatar']) || isset($_POST['remove_banner']))): ?>
                <div class="message"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <div class="pe-media-preview-grid">
                <div class="pe-avatar-line">
                    <?php if ($avatarUrl !== ''): ?>
                        <img class="pe-avatar" src="<?= htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Avatar">
                    <?php else: ?>
                        <div class="pe-avatar-empty">?</div>
                    <?php endif; ?>
                </div>
                <div>
                    <h3>Avatar</h3>
                    <p class="pe-note">Tout format image reconnu est accepté (PNG, JPG, GIF, WEBP, BMP, AVIF, etc. ; SVG sécurisé). Le fichier est conservé dans <strong>avatarban/avatar.format</strong>.</p>
                    <form method="POST" enctype="multipart/form-data" class="pe-form">
                        <input type="hidden" name="upload_avatar" value="1">
                        <input type="file" name="avatar" accept="image/*,.svg" required>
                        <div class="pe-media-actions">
                            <button type="submit">Mettre à jour</button>
                            <?php if ($avatarUrl !== ''): ?>
                                <button type="submit" name="remove_avatar" value="1" formnovalidate onclick="return confirm('Supprimer cet avatar ?');">Supprimer</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <hr>

            <div class="pe-media-preview-grid">
                <div>
                    <?php if ($bannerUrl !== ''): ?>
                        <img class="pe-banner-preview" src="<?= htmlspecialchars($bannerUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Bannière">
                    <?php elseif ($siteBannerUrl !== ''): ?>
                        <img class="pe-banner-preview" src="<?= htmlspecialchars($siteBannerUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Bannière du site">
                    <?php else: ?>
                        <div class="pe-banner-preview" style="display:grid;place-items:center;">Aucune bannière</div>
                    <?php endif; ?>
                </div>
                <div>
                    <h3>Bannière</h3>
                    <p class="pe-note">
                        Tout format image reconnu est accepté (PNG, JPG, GIF, WEBP, BMP, AVIF, etc. ; SVG sécurisé). Le fichier est conservé dans <strong>avatarban/baniere.format</strong>.
                        <?php if ($bannerUrl === '' && $siteBannerUrl !== ''): ?>La bannière du site est actuellement utilisée par défaut.<?php endif; ?>
                    </p>
                    <form method="POST" enctype="multipart/form-data" class="pe-form">
                        <input type="hidden" name="upload_banner" value="1">
                        <input type="file" name="banner" accept="image/*,.svg" required>
                        <div class="pe-media-actions">
                            <button type="submit">Mettre à jour</button>
                            <?php if ($bannerUrl !== ''): ?>
                                <button type="submit" name="remove_banner" value="1" formnovalidate onclick="return confirm('Supprimer la bannière personnelle et revenir à celle du site ?');">Utiliser celle du site</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="popup-theme" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Thème</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" class="pe-form">
                <input type="hidden" name="update_theme" value="1">

                <div>
                    <label>Choisir un thème</label>
                    <select name="theme">
                        <?php foreach (glob("theme/*", GLOB_ONLYDIR) as $dir): ?>
                            <?php
                                $dirName = basename($dir);
                                $selected = $theme === $dirName ? 'selected' : '';
                            ?>
                            <option value="<?= htmlspecialchars($dirName) ?>" <?= $selected ?>>
                                <?= htmlspecialchars(ucfirst($dirName)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="pe-form-row">
                    <div>
                        <label>Zoom de l’interface</label>
                        <select name="ui_scale">
                            <?php for ($scaleOption = 60; $scaleOption <= 150; $scaleOption += 5): ?>
                                <option value="<?= $scaleOption ?>" <?= $uiScale === $scaleOption ? 'selected' : '' ?>><?= $scaleOption ?> %</option>
                            <?php endfor; ?>
                        </select>
						                        <label style="display:flex;align-items:center;gap:24px;min-height:36px;">
                            <input type="checkbox" name="module_list_icons" value="1" <?= $moduleListIcons ? 'checked' : '' ?>>
                            Afficher les icônes dans la liste de mes modules
                        </label>
                    </div>

                </div>

                <div class="pe-actions">
                    <button type="submit">Changer le thème</button>
                </div>
            </form>

            <hr>
        </div>
    </div>
</div>

<div id="popup-core-tools-ui" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window">
        <div class="pe-popup-head">
            <h2>Outils rapides</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <form method="POST" class="pe-form">
                <input type="hidden" name="update_core_tools_ui" value="1">
                <input type="hidden" name="csrf_profile_ui" value="<?= htmlspecialchars($_SESSION['csrf_profile_ui'], ENT_QUOTES, 'UTF-8') ?>">

                <div>
                    <label><?= htmlspecialchars((string)($actionHubGlobal['icon'] ?? '⚡'), ENT_QUOTES, 'UTF-8') ?> ActionHub</label>
                    <?php if (!empty($actionHubGlobal['enabled'])): ?>
                        <select name="actionhub_location">
                            <option value="header" <?= $actionHubUserLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $actionHubUserLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $actionHubUserLocation === 'hidden' ? 'selected' : '' ?>>Masqué / désactivé pour mon compte</option>
                        </select>
                        <p class="pe-note">Réglage administrateur par défaut : <?= htmlspecialchars((string)($actionHubGlobal['default_location'] ?? 'header'), ENT_QUOTES, 'UTF-8') ?>.</p>
                    <?php else: ?>
                        <p class="pe-note"><strong>Désactivé par l’administrateur.</strong> Ce compte ne peut pas le réactiver.</p>
                    <?php endif; ?>
                </div>

                <div>
                    <label><?= htmlspecialchars((string)($quickSessionGlobal['icon'] ?? '🚨'), ENT_QUOTES, 'UTF-8') ?> Quick-Session</label>
                    <?php if (!empty($quickSessionGlobal['enabled'])): ?>
                        <select name="quick_session_location">
                            <option value="header" <?= $quickSessionUserLocation === 'header' ? 'selected' : '' ?>>Header — au milieu</option>
                            <option value="vertical" <?= $quickSessionUserLocation === 'vertical' ? 'selected' : '' ?>>Menu vertical — en haut</option>
                            <option value="hidden" <?= $quickSessionUserLocation === 'hidden' ? 'selected' : '' ?>>Masqué / désactivé pour mon compte</option>
                        </select>
                        <p class="pe-note">Réglage administrateur par défaut : <?= htmlspecialchars((string)($quickSessionGlobal['default_location'] ?? 'header'), ENT_QUOTES, 'UTF-8') ?>.</p>
                    <?php else: ?>
                        <p class="pe-note"><strong>Désactivé par l’administrateur.</strong> Ce compte ne peut pas le réactiver.</p>
                    <?php endif; ?>
                </div>

                <p class="pe-note">Le menu vertical place ces outils dans la zone système, tout en haut, avant la partie personnalisable.</p>

                <div class="pe-actions">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="popup-menu" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Menu vertical</h2>
            <button type="button" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <p class="pe-note">Tu ne vois ici que les pages DoMyDesk auxquelles tu as accès. Les ajouter au menu reste entièrement ton choix.</p>
            <form method="POST" onsubmit="prepareMenuJson();" class="pe-form">
                <input type="hidden" name="update_menu" value="1">
                <input type="hidden" id="menu_json" name="menu_json">

                <ul class="pe-menu-list" id="menuList"></ul>

                <div class="pe-actions">
                    <button type="button" class="btn-add" onclick="addMenuItem()">Ajouter un élément</button>
                    <button type="submit">Enregistrer le menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($isAdmin): ?>
    <div id="popup-news" class="pe-popup" aria-hidden="true">
        <div class="pe-popup-window pe-popup-wide">
            <div class="pe-popup-head">
                <h2>Actualités</h2>
                <button type="button" data-popup-close>Fermer</button>
            </div>

            <div class="pe-popup-body">
                <?php include __DIR__ . "/data/news/newscfg.php"; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div id="popup-module" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2 id="mod-host-title">Configuration</h2>
            <button type="button" id="mod-close" data-popup-close>Fermer</button>
        </div>

        <div class="pe-popup-body">
            <iframe id="mod-iframe" title="Configuration du module" loading="lazy"></iframe>
        </div>
    </div>
</div>

<div id="themesPopup" class="pe-popup" aria-hidden="true">
    <div class="pe-popup-window pe-popup-wide">
        <div class="pe-popup-head">
            <h2>Galerie des thèmes</h2>
            <button type="button" id="closeThemesPopup">Fermer</button>
        </div>

        <div class="pe-popup-body">
            <p class="pe-note">Survolez la loupe pour voir la miniature. ✅ = installé, ⬇️ = disponible.</p>

            <div class="table-wrap">
                <table class="th-table" id="themesTable">
                    <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Description</th>
                        <th>Aperçu</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div id="previewFloat" class="pe-preview-float">
                <img id="previewImg" src="" alt="preview">
            </div>
        </div>
    </div>
</div>

<script>
const availablePages = <?= json_encode($availablePages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const menuData = <?= json_encode($menuData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const themeHref = <?= json_encode($themeHref, JSON_UNESCAPED_SLASHES) ?>;

const normLink = (s) => (s || '').replace(/^\/+/, '').replace(/^domydesk\//, '');

function escapeHtml(str) {
    return String(str ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function escapeAttr(str) {
    return escapeHtml(str);
}

function createOptionList(currentLink) {
    return [
        `<option value="">-- choisir une page --</option>`,
        ...availablePages.map(p => `<option value="${escapeAttr(p.link)}" ${normLink(p.link) === normLink(currentLink) ? 'selected' : ''}>${escapeHtml(p.label)}</option>`)
    ].join('');
}

function setVisibility(el, visible) {
    if (!el) {
        return;
    }

    el.hidden = !visible;
}

function createMenuItem(item = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Libellé';
    input.value = item.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `<option value="none">Pas de lien</option><option value="page">Page</option><option value="link">Lien externe</option>`;
    selectType.value = item.type || 'none';

    const selectPage = document.createElement('select');
    selectPage.innerHTML = createOptionList(item.link);

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = item.type === 'link' ? (item.link || '') : '';

    function updateLinkFields() {
        setVisibility(selectPage, selectType.value === 'page');
        setVisibility(inputLink, selectType.value === 'link');
    }

    selectType.onchange = updateLinkFields;
    updateLinkFields();

    const addSubBtn = document.createElement('button');
    addSubBtn.type = 'button';
    addSubBtn.textContent = '+';
    addSubBtn.className = 'btn-sm btn-add';

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    const subList = document.createElement('ul');
    subList.className = 'pe-submenu-list';

    (item.submenu || []).forEach(sub => subList.appendChild(createSubItem(sub)));

    addSubBtn.onclick = () => subList.appendChild(createSubItem());

    li.append(input, selectType, selectPage, inputLink, addSubBtn, delBtn, subList);

    return li;
}

function createSubItem(sub = {}) {
    const li = document.createElement('li');

    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Sous-libellé';
    input.value = sub.label || '';

    const selectType = document.createElement('select');
    selectType.innerHTML = `<option value="none">Pas de lien</option><option value="page">Page</option><option value="link">Lien externe</option>`;
    selectType.value = sub.type || 'none';

    const selectPage = document.createElement('select');
    selectPage.innerHTML = createOptionList(sub.link);

    const inputLink = document.createElement('input');
    inputLink.type = 'text';
    inputLink.placeholder = 'https://...';
    inputLink.value = sub.type === 'link' ? (sub.link || '') : '';

    function updateLinkFields() {
        setVisibility(selectPage, selectType.value === 'page');
        setVisibility(inputLink, selectType.value === 'link');
    }

    selectType.onchange = updateLinkFields;
    updateLinkFields();

    const delBtn = document.createElement('button');
    delBtn.type = 'button';
    delBtn.textContent = '×';
    delBtn.className = 'btn-sm btn-del';
    delBtn.onclick = () => li.remove();

    li.append(input, selectType, selectPage, inputLink, delBtn);

    return li;
}

function addMenuItem() {
    document.getElementById('menuList')?.appendChild(createMenuItem());
}

function prepareMenuJson() {
    const items = [];

    document.querySelectorAll('#menuList > li').forEach(li => {
        const label = li.querySelector('input[type=text]')?.value.trim();
        const selects = li.querySelectorAll('select');
        const type = selects[0]?.value;

        const link = (type === 'page')
            ? selects[1]?.value
            : (type === 'link')
                ? li.querySelector('input[placeholder="https://..."]')?.value.trim()
                : '';

        const submenu = [];

        li.querySelectorAll('.pe-submenu-list > li').forEach(sub => {
            const subLabel = sub.querySelector('input[type=text]')?.value.trim();
            const subSelects = sub.querySelectorAll('select');
            const subType = subSelects[0]?.value;

            const subLink = (subType === 'page')
                ? subSelects[1]?.value
                : (subType === 'link')
                    ? sub.querySelector('input[placeholder="https://..."]')?.value.trim()
                    : '';

            if (subLabel) {
                submenu.push({
                    label: subLabel,
                    type: subType,
                    link: subLink,
                    submenu: []
                });
            }
        });

        if (label) {
            items.push({
                label,
                type,
                link,
                submenu
            });
        }
    });

    document.getElementById('menu_json').value = JSON.stringify(items, null, 2);
}

function openPopup(id) {
    const pop = document.getElementById(id);

    if (!pop) {
        return;
    }

    pop.classList.add('is-open');
    pop.setAttribute('aria-hidden', 'false');
    document.body.classList.add('noscroll');
}

function closePopup(pop) {
    if (!pop) {
        return;
    }

    pop.classList.remove('is-open');
    pop.setAttribute('aria-hidden', 'true');

    if (!document.querySelector('.pe-popup.is-open')) {
        document.body.classList.remove('noscroll');
    }
}

window.addEventListener('DOMContentLoaded', () => {
    const menuList = document.getElementById('menuList');

    if (menuList) {
        (menuData || []).forEach(item => menuList.appendChild(createMenuItem(item)));
    }

    const select = document.querySelector('select[name="theme"]');
    const previewImg = document.getElementById('theme-preview-img');

    function updatePreview() {
        if (select && previewImg) {
            previewImg.src = `theme/${select.value}/theme.png`;
        }
    }

    select?.addEventListener('change', updatePreview);
    updatePreview();

    document.querySelectorAll('[data-popup-open]').forEach(btn => {
        btn.addEventListener('click', () => openPopup(btn.dataset.popupOpen));
    });

    document.querySelectorAll('.pe-popup').forEach(pop => {
        pop.addEventListener('click', e => {
            if (e.target === pop) {
                closePopup(pop);
            }
        });
    });

    document.querySelectorAll('[data-popup-close]').forEach(btn => {
        btn.addEventListener('click', () => closePopup(btn.closest('.pe-popup')));
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.pe-popup.is-open').forEach(closePopup);
        }
    });

    const mfaToggle = document.getElementById('mfa-enabled-toggle');
    const mfaDisableConfirmation = document.getElementById('mfa-disable-confirmation');
    const mfaDisablePassword = document.getElementById('mfa-disable-password');
    const mfaDisableCode = document.getElementById('mfa-disable-code');

    function syncMfaDisableConfirmation() {
        if (!mfaToggle || !mfaDisableConfirmation) return;
        const mustConfirmDisable = !mfaToggle.checked;
        mfaDisableConfirmation.hidden = !mustConfirmDisable;
        if (mfaDisablePassword) mfaDisablePassword.required = mustConfirmDisable;
        if (mfaDisableCode) mfaDisableCode.required = mustConfirmDisable;
    }

    mfaToggle?.addEventListener('change', syncMfaDisableConfirmation);
    syncMfaDisableConfirmation();

    const copyInstanceIdBtn = document.getElementById('copy-instance-id');
    const instanceIdValue = document.getElementById('dmd-instance-id');

    copyInstanceIdBtn?.addEventListener('click', async () => {
        const value = instanceIdValue?.textContent?.trim() || '';

        if (!value) {
            return;
        }

        const original = copyInstanceIdBtn.textContent;

        try {
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(value);
            } else {
                const area = document.createElement('textarea');
                area.value = value;
                area.setAttribute('readonly', '');
                area.style.position = 'fixed';
                area.style.opacity = '0';
                document.body.appendChild(area);
                area.select();
                document.execCommand('copy');
                area.remove();
            }

            copyInstanceIdBtn.textContent = '✅';
        } catch (e) {
            copyInstanceIdBtn.textContent = '⚠️';
        }

        setTimeout(() => {
            copyInstanceIdBtn.textContent = original;
        }, 1200);
    });
});
</script>

<script>
(() => {
    const frame = document.getElementById('mod-iframe');
    const title = document.getElementById('mod-host-title');
    const search = document.getElementById('moduleSearch');

    function openModule(id, label, cfgUrl) {
        if (!cfgUrl) {
            return;
        }

        const sep = cfgUrl.includes('?') ? '&' : '?';
        const url = `${cfgUrl}${sep}embed=1`;

        title.textContent = label || id.toUpperCase();
        frame.src = url;

        openPopup('popup-module');
    }

    window.addEventListener('message', (ev) => {
        if (!frame || !ev || !ev.data || ev.source !== frame.contentWindow || ev.data.type !== 'iframe-size') {
            return;
        }

        const h = Math.max(520, Math.min(ev.data.height | 0, 50000));
        frame.height = h;
    });

    frame?.addEventListener('load', () => {
        try {
            const doc = frame.contentDocument || frame.contentWindow.document;
            const hasTheme = [...doc.querySelectorAll('link[rel="stylesheet"]')].some(l => l.href && l.href.includes('/theme/'));

            if (!hasTheme && themeHref) {
                const link = doc.createElement('link');
                link.rel = 'stylesheet';
                link.href = themeHref;
                doc.head.appendChild(link);
            }

            const s = doc.createElement('script');
            s.text = `(function(){
                function send(){
                    try {
                        var h = Math.max(
                            document.documentElement.scrollHeight || 0,
                            document.body ? document.body.scrollHeight : 0
                        );
                        parent.postMessage({type:'iframe-size',height:h},'*');
                    } catch(e) {}
                }

                var ro = window.ResizeObserver ? new ResizeObserver(send) : null;

                if (ro && document.body) {
                    ro.observe(document.body);
                }

                var mo = new MutationObserver(function(){
                    setTimeout(send,0);
                });

                mo.observe(document.documentElement,{
                    subtree:true,
                    childList:true,
                    attributes:true,
                    characterData:true
                });

                window.addEventListener('load',function(){
                    setTimeout(send,10);
                    setTimeout(send,300);
                    setTimeout(send,1200);
                });

                setTimeout(send,10);
            })();`;

            doc.body.appendChild(s);
        } catch(e) {
            console.error(e);
        }
    });

    document.getElementById('moduleGrid')?.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-mod]');

        if (!btn) {
            return;
        }

        openModule(
            btn.getAttribute('data-mod'),
            btn.getAttribute('data-label'),
            btn.getAttribute('data-cfg-url')
        );
    });

    document.getElementById('mod-close')?.addEventListener('click', () => {
        frame.src = 'about:blank';
        frame.removeAttribute('height');
    });

search?.addEventListener('input', () => {
    const q = search.value.trim().toLowerCase();

    document.querySelectorAll('[data-module-card]').forEach(card => {
        const text = (card.getAttribute('data-name') || '').toLowerCase();
        const visible = text.includes(q);

        card.style.display = visible ? '' : 'none';
    });
});
})();
</script>

<script>
(() => {
    const THEMES_JSON_URL = <?= json_encode($themesCatalogUrl, JSON_UNESCAPED_SLASHES) ?>;
    const INSTALLED = <?= json_encode($installedThemes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

    const btnOpen = document.getElementById('openThemesGallery');
    const popup = document.getElementById('themesPopup');
    const btnClose = document.getElementById('closeThemesPopup');
    const tbody = document.querySelector('#themesTable tbody');
    const floatBox = document.getElementById('previewFloat');
    const floatImg = document.getElementById('previewImg');

    const isImg = (u = '') => /\.(png|jpe?g|webp|gif|avif|svg)(\?|#|$)/i.test(u);
    const isPdf = (u = '') => /\.pdf(\?|#|$)/i.test(u);

    function slugify(s = '') {
        return String(s)
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }

    function installUrl(id, dl) {
        const base = new URL(location.href);
        const p = new URLSearchParams(base.search);

        p.set('download_theme', id);
        p.set('theme_url', dl);

        return `${base.pathname}?${p.toString()}#themes`;
    }

    function movePreview(e) {
        floatBox.style.left = (e.clientX + 16) + 'px';
        floatBox.style.top = (e.clientY + 16) + 'px';
    }

    function renderRow(item) {
        const name = item.name || 'Sans nom';
        const id = item.id ? String(item.id) : slugify(name);
        const desc = item.description || '';
        const date = item.date ? ` (${item.date})` : '';
        const img = item.image || '';
        const dl = item.dl || '';
        const size = item.size ? ` · ${item.size}` : '';
        const installed = INSTALLED.includes(id);

        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td><strong>${escapeHtml(name)}</strong>${escapeHtml(date)}</td>
            <td>${escapeHtml(desc + size)}</td>
            <td></td>
            <td>${installed ? '✅ Installé' : '⬇️ Disponible'}</td>
            <td></td>
        `;

        const tdPreview = tr.children[2];
        const tdAction = tr.children[4];

        if (img && isImg(img)) {
            const span = document.createElement('span');

            span.className = 'th-loupe';
            span.textContent = '🔍 Voir';
            span.dataset.preview = img;

            span.addEventListener('mouseenter', e => {
                floatImg.src = span.dataset.preview || '';
                floatBox.classList.add('is-visible');
                movePreview(e);
            });

            span.addEventListener('mousemove', movePreview);

            span.addEventListener('mouseleave', () => {
                floatBox.classList.remove('is-visible');
                floatImg.src = '';
            });

            tdPreview.appendChild(span);
        } else if (img) {
            const a = document.createElement('a');

            a.className = 'btn-sm';
            a.href = img;
            a.target = '_blank';
            a.rel = 'noopener';
            a.textContent = isPdf(img) ? 'Aperçu PDF' : 'Aperçu';

            tdPreview.appendChild(a);
        } else {
            tdPreview.textContent = '—';
        }

        if (dl && installed) {
            const btn = document.createElement('button');

            btn.type = 'button';
            btn.textContent = 'Appliquer';

            btn.addEventListener('click', () => {
                const sel = document.querySelector('select[name="theme"]');

                if (sel) {
                    sel.value = id;
                    sel.closest('form')?.submit();
                }
            });

            tdAction.appendChild(btn);
        } else if (dl) {
            const a = document.createElement('a');

            a.className = 'btn-sm';
            a.href = installUrl(id, dl);
            a.textContent = 'Télécharger';

            tdAction.appendChild(a);
        } else {
            tdAction.textContent = 'Pas de ZIP';
        }

        return tr;
    }

    async function loadThemes() {
        if (!tbody) {
            return;
        }

        tbody.innerHTML = `<tr><td colspan="5">Chargement…</td></tr>`;

        try {
            const res = await fetch(THEMES_JSON_URL, {
                cache: 'no-store'
            });

            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }

            const data = await res.json();
            const items = Array.isArray(data) ? data : (Array.isArray(data.items) ? data.items : []);

            if (!items.length) {
                tbody.innerHTML = `<tr><td colspan="5">Aucun thème dans le catalogue.</td></tr>`;
                return;
            }

            tbody.innerHTML = '';

            items.forEach(item => tbody.appendChild(renderRow(item)));
        } catch (err) {
            console.error(err);
            tbody.innerHTML = `<tr><td colspan="5">Erreur de chargement du catalogue.</td></tr>`;
        }
    }

    btnOpen?.addEventListener('click', () => {
        openPopup('themesPopup');
        loadThemes();
    });

    btnClose?.addEventListener('click', () => closePopup(popup));
})();
</script>


</body>
</html>