<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

require_once __DIR__ . '/core/dmd_security.php';
dmd_security_session_start();
require_once __DIR__ . '/core/dmd_system_services.php';
require_once __DIR__ . '/core/dmd_ui_features.php';
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_module_contract.php';
require_once __DIR__ . '/core/dmd_activity.php';
require_once __DIR__ . '/core/dmd_module_logs.php';
require_once __DIR__ . '/core/dmd_module_events.php';
require_once __DIR__ . '/Quick-Session/dmd_quick_session.php';
require_once __DIR__ . '/ActionHub/dmd_action_hub.php';
