<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';

if (empty($_SESSION['user']['email'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
$currentProfile = dmd_read_profile($user['email']);

if (!dmd_is_system_admin_profile($currentProfile)) {
    header("Location: dashboard.php");
    exit();
}

$users = array();

foreach (glob(__DIR__ . '/users/profiles/*', GLOB_ONLYDIR) ?: array() as $profileDir) {
    $userEmail = basename($profileDir);
    $profile = dmd_read_profile($userEmail);

    if (!empty($profile)) {
        $users[] = $profile;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Utilisateurs</title>
</head>
<body>
    <header>
        <p>Bienvenue, <?php echo $user['first_name']; ?> !</p>
        <a href="logout.php">Se déconnecter</a>
    </header>
    <section>
        <h2>Utilisateurs</h2>
        <ul>
            <?php foreach ($users as $userData) { ?>
                <li><?php echo $userData['first_name'] . ' ' . $userData['last_name']; ?> - <?php echo $userData['email']; ?></li>
            <?php } ?>
        </ul>
    </section>
</body>
</html>
