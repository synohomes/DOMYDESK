<?php
require_once __DIR__ . '/core/dmd_permissions.php';

function getUserProfile($email) {
    $profile = dmd_read_profile($email);
    return !empty($profile) ? $profile : null;
}

function isLoggedIn() {
    return isset($_SESSION['user']) && isset($_SESSION['user']['email']);
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}
?>
