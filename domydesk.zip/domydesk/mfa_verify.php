<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_security.php';
require_once __DIR__ . '/core/dmd_mfa.php';
require_once __DIR__ . '/core/dmd_system_services.php';

$pending = isset($_SESSION['dmd_mfa_pending']) && is_array($_SESSION['dmd_mfa_pending']) ? $_SESSION['dmd_mfa_pending'] : array();
$stepUp = !empty($pending['step_up']);

/* Une session déjà ouverte est autorisée ici uniquement pour un step-up MFA central. */
if (isset($_SESSION['user']) && !$stepUp) {
    header('Location: dashboard.php');
    exit;
}
$email = dmd_safe_user_key((string)($pending['email'] ?? ''));
$issuedAt = (int)($pending['issued_at'] ?? 0);

if ($email === '' || $issuedAt <= 0 || time() - $issuedAt > 600 || !dmd_mfa_enabled($email)) {
    unset($_SESSION['dmd_mfa_pending']);
    if ($stepUp) {
        session_unset();
        session_destroy();
    }
    header('Location: login.php?mfa=expired');
    exit;
}

$theme = 'default';
$themePath = dmd_user_dir($email) . 'theme.json';
if (is_file($themePath)) {
    $themeData = json_decode((string)file_get_contents($themePath), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file(__DIR__ . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    }
}

$error = '';
$csrf = dmd_csrf_token('mfa_login');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'mfa_login')) {
        $error = 'Formulaire expiré. Rechargez la page.';
    } else {
        $attempts = (int)($pending['attempts'] ?? 0);
        if ($attempts >= 5) {
            unset($_SESSION['dmd_mfa_pending']);
            header('Location: login.php?mfa=locked');
            exit;
        }

        $code = trim((string)($_POST['mfa_code'] ?? ''));
        $usedRecovery = false;
        if (dmd_mfa_verify_user_code($email, $code, $usedRecovery)) {
            $user = isset($pending['user']) && is_array($pending['user']) ? $pending['user'] : array();
            $role = (string)($pending['role_system'] ?? ($user['role_system'] ?? 'user'));
            $redirect = (string)($pending['redirect'] ?? 'dashboard.php');
            if ($redirect === '' || preg_match('#^https?://#i', $redirect) || strpos($redirect, "\r") !== false || strpos($redirect, "\n") !== false || strpos($redirect, '..') !== false) {
                $redirect = 'dashboard.php';
            }

            unset($_SESSION['dmd_mfa_pending']);
            session_regenerate_id(true);
            $_SESSION['user'] = $user;
            $_SESSION['role_system'] = $role;
            $_SESSION['dmd_mfa_authenticated_at'] = time();

            if (function_exists('dmd_system_log')) {
                dmd_system_log($usedRecovery ? 'mfa_login_recovery' : 'mfa_login', $email, 'success', $usedRecovery ? 'Connexion MFA avec code de récupération.' : 'Connexion MFA validée.');
            }

            header('Location: ' . ($redirect !== '' ? $redirect : 'dashboard.php'));
            exit;
        }

        $pending['attempts'] = $attempts + 1;
        $_SESSION['dmd_mfa_pending'] = $pending;
        if (function_exists('dmd_system_log')) {
            dmd_system_log('mfa_login_failed', $email, 'denied', 'Code MFA incorrect.');
        }
        $remaining = max(0, 5 - (int)$pending['attempts']);
        $error = 'Code incorrect. Tentatives restantes : ' . $remaining . '.';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vérification - DoMyDesk</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <?php
    require_once __DIR__ . '/core/dmd_theme_assets.php';
    echo dmd_theme_extra_links(__DIR__, 'theme', $theme, 'login');
    ?>
</head>
<body>
<main class="login-wrapper">
    <section class="login-card" aria-labelledby="mfa-title">
        <div class="brand">
            <img src="adm/uploads/logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 id="mfa-title">Vérification</h1>
        </div>
        <p class="subtitle">Entrez le code Microsoft Authenticator pour <strong><?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?></strong>.</p>

        <?php if ($error !== ''): ?>
            <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <label for="mfa_code">Code Authenticator ou code de secours</label>
            <input id="mfa_code" name="mfa_code" autocomplete="one-time-code" autofocus required>
            <button type="submit" class="btn">Valider</button>
            <a class="register-link" href="logout.php">Annuler la connexion</a>
        </form>
    </section>
</main>
</body>
</html>
