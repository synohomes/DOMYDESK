<?php
/**
 * DoMyDesk - Quick-Session PDF helper
 * PHP 7.3 compatible, no external dependency.
 */

if (!class_exists('DmdQuickSessionPdf')) {
    class DmdQuickSessionPdf
    {
        const PAGE_W = 595.28;
        const PAGE_H = 841.89;
        const MARGIN_X = 46.0;
        const MARGIN_TOP = 44.0;
        const MARGIN_BOTTOM = 46.0;

        private $pages = array();
        private $current = '';
        private $y = self::MARGIN_TOP;

        public function __construct()
        {
            $this->addPage();
        }

        private function addPage()
        {
            if ($this->current !== '') {
                $this->pages[] = $this->current;
            }
            $this->current = '';
            $this->y = self::MARGIN_TOP;
        }

        private function ensureSpace($height)
        {
            if (($this->y + $height) > (self::PAGE_H - self::MARGIN_BOTTOM)) {
                $this->addPage();
                return true;
            }
            return false;
        }

        private function pdfY($topY)
        {
            return self::PAGE_H - $topY;
        }

        private function enc($text)
        {
            $text = html_entity_decode(strip_tags((string)$text), ENT_QUOTES, 'UTF-8');
            $text = str_replace(array("\r\n", "\r"), "\n", $text);
            if (function_exists('iconv')) {
                $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
                if ($converted !== false) {
                    $text = $converted;
                }
            }
            $text = str_replace('\\', '\\\\', $text);
            $text = str_replace('(', '\\(', $text);
            $text = str_replace(')', '\\)', $text);
            $text = str_replace("\n", ' ', $text);
            return $text;
        }

        private function writeText($x, $topY, $text, $size, $bold, $gray)
        {
            $font = $bold ? '/F2' : '/F1';
            $g = max(0, min(1, (float)$gray));
            $this->current .= sprintf(
                "%.3f g BT %s %.2f Tf 1 0 0 1 %.2f %.2f Tm (%s) Tj ET\n",
                $g,
                $font,
                (float)$size,
                (float)$x,
                $this->pdfY((float)$topY),
                $this->enc($text)
            );
        }

        private function fillRect($x, $topY, $w, $h, $gray)
        {
            $g = max(0, min(1, (float)$gray));
            $bottomY = self::PAGE_H - $topY - $h;
            $this->current .= sprintf("%.3f g %.2f %.2f %.2f %.2f re f\n", $g, $x, $bottomY, $w, $h);
        }

        private function strokeLine($x1, $topY1, $x2, $topY2, $gray, $width)
        {
            $g = max(0, min(1, (float)$gray));
            $this->current .= sprintf(
                "%.3f G %.2f w %.2f %.2f m %.2f %.2f l S\n",
                $g,
                (float)$width,
                (float)$x1,
                $this->pdfY((float)$topY1),
                (float)$x2,
                $this->pdfY((float)$topY2)
            );
        }

        private function wrap($text, $width, $fontSize)
        {
            $text = trim(preg_replace('/\s+/u', ' ', (string)$text));
            if ($text === '') {
                return array('');
            }

            $avgChar = max(4.2, ((float)$fontSize) * 0.52);
            $maxChars = max(12, (int)floor($width / $avgChar));
            $words = preg_split('/\s+/u', $text);
            $lines = array();
            $line = '';

            foreach ($words as $word) {
                $candidate = $line === '' ? $word : ($line . ' ' . $word);
                if (function_exists('mb_strlen')) {
                    $candidateLen = mb_strlen($candidate, 'UTF-8');
                } else {
                    $candidateLen = strlen($candidate);
                }

                if ($candidateLen <= $maxChars) {
                    $line = $candidate;
                    continue;
                }

                if ($line !== '') {
                    $lines[] = $line;
                }
                $line = $word;
            }

            if ($line !== '') {
                $lines[] = $line;
            }

            return $lines ?: array('');
        }

        public function header($title, $subtitle)
        {
            $this->ensureSpace(72);
            $x = self::MARGIN_X;
            $w = self::PAGE_W - (2 * self::MARGIN_X);
            $this->fillRect($x, $this->y, $w, 58, 0.16);
            $this->writeText($x + 16, $this->y + 23, 'DoMyDesk - Procedure', 11.5, true, 1.0);
            $this->writeText($x + 16, $this->y + 43, $title, 17, true, 1.0);
            $this->y += 70;

            if (trim((string)$subtitle) !== '') {
                $this->paragraph($subtitle, 9.5, 13.5, false, 0.35);
                $this->y += 2;
            }
        }

        public function section($title)
        {
            $this->ensureSpace(34);
            $x = self::MARGIN_X;
            $w = self::PAGE_W - (2 * self::MARGIN_X);
            $this->fillRect($x, $this->y, $w, 24, 0.93);
            $this->writeText($x + 9, $this->y + 16.5, $title, 10.5, true, 0.15);
            $this->y += 32;
        }

        public function keyValue($key, $value)
        {
            $this->ensureSpace(18);
            $x = self::MARGIN_X;
            $this->writeText($x, $this->y + 10, $key, 8.8, true, 0.28);
            $this->writeText($x + 116, $this->y + 10, $value !== '' ? $value : '-', 8.8, false, 0.18);
            $this->y += 17;
        }

        public function paragraph($text, $size = 9.5, $lineHeight = 14.0, $bold = false, $gray = 0.16)
        {
            $width = self::PAGE_W - (2 * self::MARGIN_X);
            $lines = $this->wrap($text, $width, $size);
            foreach ($lines as $line) {
                $this->ensureSpace($lineHeight + 3);
                $this->writeText(self::MARGIN_X, $this->y + $size, $line, $size, $bold, $gray);
                $this->y += $lineHeight;
            }
            $this->y += 3;
        }

        public function bullet($text, $size = 9.2)
        {
            $width = self::PAGE_W - (2 * self::MARGIN_X) - 18;
            $lines = $this->wrap($text, $width, $size);
            $first = true;
            foreach ($lines as $line) {
                $this->ensureSpace(14);
                if ($first) {
                    $this->writeText(self::MARGIN_X, $this->y + $size, '-', $size, true, 0.22);
                    $first = false;
                }
                $this->writeText(self::MARGIN_X + 16, $this->y + $size, $line, $size, false, 0.18);
                $this->y += 13.2;
            }
            $this->y += 2;
        }

        public function timelineItem($date, $module, $label, $target, $status, $details)
        {
            $title = trim($date . '  |  ' . strtoupper($module) . ($status !== '' ? '  |  ' . strtoupper($status) : ''));
            $body = trim($label . ($target !== '' ? ' - ' . $target : ''));
            $detail = trim($details);

            $bodyLines = $this->wrap($body, self::PAGE_W - (2 * self::MARGIN_X) - 18, 9.1);
            $detailLines = $detail !== '' ? $this->wrap($detail, self::PAGE_W - (2 * self::MARGIN_X) - 18, 8.5) : array();
            $height = 20 + (count($bodyLines) * 12) + (count($detailLines) * 11) + 7;
            $this->ensureSpace($height);

            $x = self::MARGIN_X;
            $this->fillRect($x, $this->y, 4, max(34, $height - 4), 0.55);
            $this->writeText($x + 14, $this->y + 10, $title, 7.8, true, 0.38);
            $this->y += 15;

            foreach ($bodyLines as $line) {
                $this->writeText($x + 14, $this->y + 9, $line, 9.1, true, 0.14);
                $this->y += 12;
            }
            foreach ($detailLines as $line) {
                $this->writeText($x + 14, $this->y + 8, $line, 8.5, false, 0.32);
                $this->y += 11;
            }
            $this->y += 8;
        }

        public function footerNote($text)
        {
            $this->ensureSpace(30);
            $this->y += 4;
            $this->strokeLine(self::MARGIN_X, $this->y, self::PAGE_W - self::MARGIN_X, $this->y, 0.78, 0.5);
            $this->writeText(self::MARGIN_X, $this->y + 15, $text, 7.4, false, 0.48);
            $this->y += 22;
        }

        public function save($file)
        {
            if ($this->current !== '') {
                $this->pages[] = $this->current;
                $this->current = '';
            }

            $objects = array();
            $fontRegularId = 3;
            $fontBoldId = 4;
            $pageIds = array();
            $contentIds = array();
            $nextId = 5;

            foreach ($this->pages as $idx => $content) {
                $pageIds[$idx] = $nextId++;
                $contentIds[$idx] = $nextId++;
            }

            $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
            $kids = array();
            foreach ($pageIds as $id) {
                $kids[] = $id . ' 0 R';
            }
            $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($pageIds) . ' >>';
            $objects[$fontRegularId] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
            $objects[$fontBoldId] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';

            foreach ($this->pages as $idx => $content) {
                $pageId = $pageIds[$idx];
                $contentId = $contentIds[$idx];
                $objects[$pageId] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::PAGE_W . ' ' . self::PAGE_H . '] '
                    . '/Resources << /Font << /F1 ' . $fontRegularId . ' 0 R /F2 ' . $fontBoldId . ' 0 R >> >> '
                    . '/Contents ' . $contentId . ' 0 R >>';
                $objects[$contentId] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream";
            }

            ksort($objects);
            $maxId = max(array_keys($objects));
            $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
            $offsets = array(0 => 0);

            for ($i = 1; $i <= $maxId; $i++) {
                if (!isset($objects[$i])) {
                    continue;
                }
                $offsets[$i] = strlen($pdf);
                $pdf .= $i . " 0 obj\n" . $objects[$i] . "\nendobj\n";
            }

            $xref = strlen($pdf);
            $pdf .= "xref\n0 " . ($maxId + 1) . "\n";
            $pdf .= "0000000000 65535 f \n";
            for ($i = 1; $i <= $maxId; $i++) {
                $off = isset($offsets[$i]) ? $offsets[$i] : 0;
                $pdf .= sprintf("%010d 00000 n \n", $off);
            }
            $pdf .= "trailer\n<< /Size " . ($maxId + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";

            return @file_put_contents($file, $pdf, LOCK_EX) !== false;
        }
    }
}

if (!function_exists('dmd_qsp_safe_base_name')) {
    function dmd_qsp_safe_base_name($name)
    {
        $name = trim(strip_tags((string)$name));
        if ($name === '') {
            $name = 'Procedure-Quick-Session';
        }
        if (function_exists('iconv')) {
            $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $name);
            if ($tmp !== false && $tmp !== '') {
                $name = $tmp;
            }
        }
        $name = preg_replace('/[^a-zA-Z0-9._-]+/', '-', $name);
        $name = trim((string)$name, '-_.');
        if ($name === '') {
            $name = 'Procedure-Quick-Session';
        }
        return substr($name, 0, 90);
    }
}

if (!function_exists('dmd_qsp_unique_pdf_path')) {
    function dmd_qsp_unique_pdf_path($directory, $baseName)
    {
        if (!is_dir($directory)) {
            @mkdir($directory, 0775, true);
        }
        $baseName = dmd_qsp_safe_base_name($baseName);
        $filename = $baseName . '.pdf';
        $path = rtrim($directory, '/\\') . DIRECTORY_SEPARATOR . $filename;
        if (!is_file($path)) {
            return array($path, $filename);
        }

        $suffix = date('Ymd-His');
        $filename = $baseName . '-' . $suffix . '.pdf';
        $path = rtrim($directory, '/\\') . DIRECTORY_SEPARATOR . $filename;
        $i = 2;
        while (is_file($path)) {
            $filename = $baseName . '-' . $suffix . '-' . $i . '.pdf';
            $path = rtrim($directory, '/\\') . DIRECTORY_SEPARATOR . $filename;
            $i++;
        }
        return array($path, $filename);
    }
}

if (!function_exists('dmd_qsp_duration')) {
    function dmd_qsp_duration($seconds)
    {
        $seconds = max(0, (int)$seconds);
        return sprintf('%02d:%02d:%02d', floor($seconds / 3600), floor(($seconds % 3600) / 60), $seconds % 60);
    }
}

if (!function_exists('dmd_qsp_date')) {
    function dmd_qsp_date($timestamp)
    {
        $timestamp = (int)$timestamp;
        return $timestamp > 0 ? date('d/m/Y H:i:s', $timestamp) : '-';
    }
}

if (!function_exists('dmd_qsp_iso_date')) {
    function dmd_qsp_iso_date($iso, $fallbackTimestamp = 0)
    {
        $iso = trim((string)$iso);
        if ($iso !== '') {
            try {
                $dt = new DateTime($iso);
                return $dt->format('d/m/Y H:i:s');
            } catch (Exception $e) {
                // Fallback sur le timestamp ci-dessous.
            }
        }
        return dmd_qsp_date($fallbackTimestamp);
    }
}

if (!function_exists('dmd_qsp_procedure_index_file')) {
    function dmd_qsp_procedure_index_file()
    {
        return dirname(__DIR__) . '/data/secure/quick_session_procedures.json';
    }
}

if (!function_exists('dmd_qsp_register_procedure')) {
    function dmd_qsp_register_procedure($filename, array $session, $sourceUser, $relativePath = '')
    {
        $file = dmd_qsp_procedure_index_file();
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        $index = array('version' => 1, 'updated_at' => time(), 'procedures' => array());
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $decoded = $raw !== false ? json_decode($raw, true) : null;
            if (is_array($decoded)) {
                $index = $decoded;
                if (!isset($index['procedures']) || !is_array($index['procedures'])) {
                    $index['procedures'] = array();
                }
            }
        }

        $entry = array(
            'filename' => basename((string)$filename),
            'relative_path' => str_replace('\\', '/', trim((string)$relativePath)),
            'title' => isset($session['title']) ? (string)$session['title'] : '',
            'summary' => isset($session['summary']) ? (string)$session['summary'] : '',
            'tags' => function_exists('dmd_qs_normalize_string_list') ? dmd_qs_normalize_string_list(isset($session['tags']) ? $session['tags'] : array(), 40, 80) : array(),
            'module_ids' => function_exists('dmd_qs_module_ids') ? dmd_qs_module_ids(isset($session['modules']) ? $session['modules'] : array()) : array(),
            'resource_types' => function_exists('dmd_qs_resource_types') ? dmd_qs_resource_types(isset($session['resources']) ? $session['resources'] : array()) : array(),
            'resolution' => isset($session['resolution']['note']) ? (string)$session['resolution']['note'] : '',
            'source_session_id' => isset($session['id']) ? (string)$session['id'] : '',
            'source_user' => (string)$sourceUser,
            'created_at' => time(),
            'created_at_iso' => date('c')
        );

        $kept = array();
        foreach ($index['procedures'] as $existing) {
            if (!is_array($existing)) continue;
            $existingRel = str_replace('\\', '/', trim((string)(isset($existing['relative_path']) ? $existing['relative_path'] : '')));
            $sameRel = $relativePath !== '' && $existingRel !== '' && $existingRel === str_replace('\\', '/', trim((string)$relativePath));
            $sameLegacy = $existingRel === '' && basename(isset($existing['filename']) ? $existing['filename'] : '') === basename($filename);
            if ($sameRel || $sameLegacy) continue;
            $kept[] = $existing;
        }
        $kept[] = $entry;
        usort($kept, function ($a, $b) {
            return ((int)(isset($b['created_at']) ? $b['created_at'] : 0)) <=> ((int)(isset($a['created_at']) ? $a['created_at'] : 0));
        });

        $index['version'] = 1;
        $index['updated_at'] = time();
        $index['updated_at_iso'] = date('c', $index['updated_at']);
        $index['procedures'] = $kept;

        $json = json_encode($index, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }
        return @file_put_contents($file, $json, LOCK_EX) !== false;
    }
}

if (!function_exists('dmd_qsp_create_procedure_pdf')) {
    function dmd_qsp_create_procedure_pdf(array $session, $sourceUser, $proceduresDir, $preferredName = '')
    {
        $title = trim(isset($session['title']) ? (string)$session['title'] : '');
        if ($title === '') {
            $title = 'Procedure issue de ' . (isset($session['id']) ? $session['id'] : 'Quick-Session');
        }
        $baseName = trim((string)$preferredName) !== '' ? $preferredName : $title;
        list($targetPath, $filename) = dmd_qsp_unique_pdf_path($proceduresDir, $baseName);

        $pdf = new DmdQuickSessionPdf();
        $pdf->header($title, isset($session['summary']) ? $session['summary'] : '');

        $pdf->section('Référence');
        $pdf->keyValue('Source', isset($session['id']) ? (string)$session['id'] : 'Quick-Session');
        $pdf->keyValue('Date de résolution', dmd_qsp_iso_date(isset($session['closed_at_iso']) ? $session['closed_at_iso'] : '', isset($session['closed_at']) ? $session['closed_at'] : 0));
        $pdf->keyValue('Durée observée', dmd_qsp_duration(isset($session['duration_seconds']) ? $session['duration_seconds'] : 0));

        $tags = isset($session['tags']) && is_array($session['tags']) ? $session['tags'] : array();
        if ($tags) {
            $pdf->keyValue('Mots-clés', implode(', ', $tags));
        }

        $pdf->section('Contexte / Résumé');
        $summary = trim(isset($session['summary']) ? (string)$session['summary'] : '');
        $pdf->paragraph($summary !== '' ? $summary : 'Aucun résumé renseigné.');

        $resources = isset($session['resources']) && is_array($session['resources']) ? $session['resources'] : array();
        if ($resources) {
            $pdf->section('Ressources concernées');
            foreach ($resources as $resource) {
                if (!is_array($resource)) {
                    continue;
                }
                $label = isset($resource['label']) && trim((string)$resource['label']) !== '' ? $resource['label'] : (isset($resource['id']) ? $resource['id'] : 'Ressource');
                $type = isset($resource['type']) ? $resource['type'] : '';
                $source = isset($resource['source']) ? $resource['source'] : '';
                $line = $label;
                if ($type !== '') {
                    $line .= ' (' . $type . ')';
                }
                if ($source !== '') {
                    $line .= ' - ' . $source;
                }
                $pdf->bullet($line);
            }
        }

        $modules = isset($session['modules']) && is_array($session['modules']) ? $session['modules'] : array();
        if ($modules) {
            $pdf->section('Outils / Modules utilisés');
            foreach ($modules as $module) {
                if (!is_array($module)) {
                    continue;
                }
                $name = isset($module['title']) && trim((string)$module['title']) !== '' ? $module['title'] : (isset($module['id']) ? $module['id'] : 'Module');
                $pdf->bullet($name);
            }
        }

        $pdf->section('Résolution / Méthode validée');
        $resolution = isset($session['resolution']['note']) ? trim((string)$session['resolution']['note']) : '';
        $pdf->paragraph($resolution !== '' ? $resolution : 'Aucune résolution détaillée n\'a été renseignée.');

        $timeline = isset($session['timeline']) && is_array($session['timeline']) ? $session['timeline'] : array();
        if ($timeline) {
            $pdf->section('Chronologie de référence');
            foreach ($timeline as $event) {
                if (!is_array($event)) {
                    continue;
                }
                $pdf->timelineItem(
                    dmd_qsp_iso_date(isset($event['date_iso']) ? $event['date_iso'] : '', isset($event['timestamp']) ? $event['timestamp'] : 0),
                    isset($event['module']) ? $event['module'] : 'core',
                    isset($event['label']) && trim((string)$event['label']) !== '' ? $event['label'] : (isset($event['action']) ? $event['action'] : ''),
                    isset($event['target']) ? $event['target'] : '',
                    isset($event['status']) ? $event['status'] : '',
                    isset($event['details']) ? $event['details'] : ''
                );
            }
        }

        $pdf->footerNote('Procédure générée depuis une Quick-Session DoMyDesk. À valider et adapter avant réutilisation si nécessaire.');

        if (!$pdf->save($targetPath)) {
            return array('ok' => false, 'error' => 'write_failed');
        }
        @chmod($targetPath, 0664);
        $documentsRoot = dirname(__DIR__) . '/data/procedures/documents/';
        $targetNorm = str_replace('\\', '/', $targetPath);
        $rootNorm = rtrim(str_replace('\\', '/', $documentsRoot), '/') . '/';
        $relativePath = strpos($targetNorm, $rootNorm) === 0 ? substr($targetNorm, strlen($rootNorm)) : basename($targetNorm);

        if (!dmd_qsp_register_procedure($filename, $session, $sourceUser, $relativePath)) {
            @unlink($targetPath);
            return array('ok' => false, 'error' => 'index_failed');
        }

        return array('ok' => true, 'filename' => $filename, 'relative_path' => $relativePath, 'path' => $targetPath);
    }
}
