(function () {
    'use strict';

    const cfg = window.DMDQuickSessionConfig || {};
    if (!cfg.active || !cfg.view) {
        return;
    }

    const state = {
        suggestions: [],
        rejected: new Set(),
        searchWindow: null,
        previewWindow: null,
        resolutionChoiceWindow: null,
        sheetWindow: null,
        previewItem: null,
        searchBusy: false,
        acceptBusy: false,
        sheetBusy: false,
        closeBusy: false
    };

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function toast(message) {
        if (window.DMDWorkspace && typeof window.DMDWorkspace.toast === 'function') {
            window.DMDWorkspace.toast(message);
            return;
        }
        console.log('[Quick-Session]', message);
    }

    function encodeDocumentPath(path) {
        return String(path || '')
            .split('/')
            .filter(Boolean)
            .map(part => encodeURIComponent(part))
            .join('/');
    }

    function suggestionKey(item) {
        if (!item) return '';
        if (item.type === 'procedure') {
            return 'procedure:' + String(item.procedure_path || item.procedure || '').toLowerCase();
        }
        return 'session:' + String(item.source_session_id || item.source_filename || '').toLowerCase();
    }

    function moduleLabel(id) {
        const names = cfg.moduleNames || {};
        const value = names[id];
        return typeof value === 'string' && value.trim() !== '' ? value.trim() : id;
    }

    async function api(action, method, payload) {
        const options = {
            method: method || 'GET',
            cache: 'no-store',
            headers: {}
        };

        if ((method || 'GET').toUpperCase() !== 'GET' && cfg.csrfToken) {
            options.headers['X-DMD-CSRF'] = cfg.csrfToken;
        }

        if (payload !== undefined) {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(payload);
        }

        let url = cfg.apiUrl + '?action=' + encodeURIComponent(action);
        if ((method || 'GET').toUpperCase() === 'GET' && payload && typeof payload === 'object') {
            const query = new URLSearchParams();
            Object.keys(payload).forEach(key => {
                if (payload[key] !== undefined && payload[key] !== null && String(payload[key]) !== '') {
                    query.set(key, String(payload[key]));
                }
            });
            const suffix = query.toString();
            if (suffix) url += '&' + suffix;
            delete options.body;
            delete options.headers['Content-Type'];
        }

        const response = await fetch(url, options);
        let data = {};
        try {
            data = await response.json();
        } catch (e) {
            data = {};
        }

        if (!response.ok || !data.ok) {
            const err = new Error(data.error || action + '_failed');
            err.data = data;
            throw err;
        }
        return data;
    }

    function dashboardRoot() {
        return document.getElementById('dashboard') || document.body;
    }

    function collectWorkspaceModules() {
        const allowed = Array.isArray(cfg.allowedModules) ? cfg.allowedModules : [];
        return Array.from(document.querySelectorAll('#dashboard > .module'))
            .filter(el => el && el.dataset && el.dataset.id && allowed.includes(String(el.dataset.id)))
            .map(el => {
                const id = String(el.dataset.id || '').trim();
                const shape = el.classList.contains('rounded') ? 'rounded' : (el.classList.contains('circle') ? 'circle' : 'square');
                const titleEl = el.querySelector('.module-title');
                return {
                    id: id,
                    title: titleEl ? String(titleEl.textContent || id).trim() : id,
                    shape: shape,
                    x: Math.max(0, Math.round(parseFloat(el.style.left) || 0)),
                    y: Math.max(0, Math.round(parseFloat(el.style.top) || 0)),
                    width: Math.max(120, Math.round(parseFloat(el.style.width) || el.offsetWidth || 280)),
                    height: Math.max(90, Math.round(parseFloat(el.style.height) || el.offsetHeight || 280))
                };
            });
    }

    async function syncWorkspaceModules() {
        if (cfg.phase !== 'accepted') return [];
        const modules = collectWorkspaceModules();
        const result = await api('save_modules', 'POST', { modules: modules });
        return Array.isArray(result.modules) ? result.modules : modules;
    }

    function expandDashboardCanvas() {
        if (typeof window.DMDExpandDashboardCanvas === 'function') {
            window.DMDExpandDashboardCanvas();
            return;
        }
        if (typeof window.expandCanvasLT === 'function') {
            window.expandCanvasLT();
        }
    }

    function pageScrollPosition() {
        const scroller = document.scrollingElement || document.documentElement;
        return {
            left: scroller ? (scroller.scrollLeft || 0) : (window.scrollX || 0),
            top: scroller ? (scroller.scrollTop || 0) : (window.scrollY || 0)
        };
    }

    function scrollPageBy(dx, dy) {
        const scroller = document.scrollingElement || document.documentElement;
        if (!scroller) return;
        if (dx) scroller.scrollLeft = Math.max(0, (scroller.scrollLeft || 0) + dx);
        if (dy) scroller.scrollTop = Math.max(0, (scroller.scrollTop || 0) + dy);
    }

    function isWorkspaceWindow(win) {
        const overlay = win ? win.closest('.dmd-qs-overlay') : null;
        return !!(overlay && overlay.dataset.dmdQsHost === 'workspace');
    }

    function isMobileView() {
        return !!(window.DMDWorkspace && typeof window.DMDWorkspace.isMobileView === 'function' && window.DMDWorkspace.isMobileView());
    }

    function bringToFront(win) {
        if (!win) return;

        if (typeof window.DMDBringWorkspaceItemToFront === 'function') {
            window.DMDBringWorkspaceItemToFront(win);
            return;
        }

        let maxZ = 20;
        document.querySelectorAll('.module, .dmd-qs-window').forEach(el => {
            const z = parseInt(el.style.zIndex || '0', 10);
            if (Number.isFinite(z)) maxZ = Math.max(maxZ, z);
        });
        win.style.zIndex = String(maxZ + 1);
    }

    function placeWindow(win) {
        if (!win || isMobileView()) {
            bringToFront(win);
            return;
        }

        const workspace = isWorkspaceWindow(win);
        const dash = dashboardRoot();
        if (win.dataset.dmdQsPlaced !== '1') {
            win.dataset.dmdQsPlaced = '1';
            const width = win.offsetWidth || 620;
            const pageScroll = pageScrollPosition();
            const visibleWidth = window.innerWidth || dash.clientWidth || 1024;
            const left = workspace
                ? pageScroll.left + Math.max(12, Math.round((visibleWidth - width) / 2))
                : Math.max(12, Math.round((visibleWidth - width) / 2));
            const top = workspace ? pageScroll.top + 18 : 58;
            win.style.left = Math.max(0, left) + 'px';
            win.style.top = Math.max(0, top) + 'px';
        }
        if (workspace) expandDashboardCanvas();
        bringToFront(win);
    }

    function bindWorkspaceWindow(win) {
        if (!win || win.dataset.dmdQsBound === '1') return;
        win.dataset.dmdQsBound = '1';

        const head = win.querySelector('.dmd-qs-window-head');
        const resizeHandle = win.querySelector('.dmd-qs-resize-handle');

        win.addEventListener('pointerdown', function () {
            bringToFront(win);
        }, true);

        if (head) {
            let drag = null;

            function stopDrag(event) {
                if (!drag) return;
                if (event && event.pointerId != null && event.pointerId !== drag.pointerId) return;

                const pointerId = drag.pointerId;
                const wasWorkspace = drag.workspace;
                drag = null;
                document.documentElement.classList.remove('dmd-qs-pointer-active');
                if (wasWorkspace) expandDashboardCanvas();

                if (head.releasePointerCapture) {
                    try { head.releasePointerCapture(pointerId); } catch (e) {}
                }
            }

            head.addEventListener('pointerdown', function (event) {
                if (isMobileView()) return;
                if (event.button !== undefined && event.button !== 0) return;
                if (event.target.closest('button,input,select,textarea,a')) return;

                bringToFront(win);
                const workspace = isWorkspaceWindow(win);
                const pageScroll = workspace ? pageScrollPosition() : { left: 0, top: 0 };
                drag = {
                    pointerId: event.pointerId,
                    startX: event.clientX,
                    startY: event.clientY,
                    left: parseFloat(win.style.left) || 0,
                    top: parseFloat(win.style.top) || 0,
                    workspace: workspace,
                    scrollLeft: pageScroll.left,
                    scrollTop: pageScroll.top
                };

                document.documentElement.classList.add('dmd-qs-pointer-active');
                if (head.setPointerCapture) {
                    try { head.setPointerCapture(event.pointerId); } catch (e) {}
                }
                event.preventDefault();
            });

            head.addEventListener('pointermove', function (event) {
                if (!drag || event.pointerId !== drag.pointerId) return;

                let scrollDx = 0;
                let scrollDy = 0;

                if (drag.workspace) {
                    // Le dashboard Bureau utilise le scroll du document, pas scrollLeft/scrollTop
                    // de #dashboard. On agrandit d'abord le canvas, puis on fait défiler la vraie
                    // page lorsque la souris approche d'un bord de l'écran.
                    expandDashboardCanvas();

                    const edge = 46;
                    const step = 28;
                    const rightLimit = (window.innerWidth || document.documentElement.clientWidth) - edge;
                    const bottomLimit = (window.innerHeight || document.documentElement.clientHeight) - edge;
                    let dx = 0;
                    let dy = 0;

                    if (event.clientX > rightLimit) dx = step;
                    else if (event.clientX < edge) dx = -step;

                    if (event.clientY > bottomLimit) dy = step;
                    else if (event.clientY < edge) dy = -step;

                    if (dx || dy) {
                        scrollPageBy(dx, dy);
                    }

                    const pageScroll = pageScrollPosition();
                    scrollDx = pageScroll.left - drag.scrollLeft;
                    scrollDy = pageScroll.top - drag.scrollTop;
                }

                win.style.left = Math.max(0, drag.left + event.clientX - drag.startX + scrollDx) + 'px';
                win.style.top = Math.max(0, drag.top + event.clientY - drag.startY + scrollDy) + 'px';
                if (drag.workspace) expandDashboardCanvas();
                event.preventDefault();
            });

            head.addEventListener('pointerup', stopDrag);
            head.addEventListener('pointercancel', stopDrag);
            head.addEventListener('lostpointercapture', stopDrag);
            window.addEventListener('blur', () => stopDrag(null));
        }

        if (resizeHandle) {
            let resize = null;

            function stopResize(event) {
                if (!resize) return;
                if (event && event.pointerId != null && event.pointerId !== resize.pointerId) return;

                const pointerId = resize.pointerId;
                const wasWorkspace = isWorkspaceWindow(win);
                resize = null;
                document.documentElement.classList.remove('dmd-qs-pointer-active');
                if (wasWorkspace) expandDashboardCanvas();

                if (resizeHandle.releasePointerCapture) {
                    try { resizeHandle.releasePointerCapture(pointerId); } catch (e) {}
                }
            }

            resizeHandle.addEventListener('pointerdown', function (event) {
                if (isMobileView()) return;
                if (event.button !== undefined && event.button !== 0) return;

                bringToFront(win);
                const rect = win.getBoundingClientRect();
                resize = {
                    pointerId: event.pointerId,
                    startX: event.clientX,
                    startY: event.clientY,
                    width: rect.width,
                    height: rect.height
                };

                document.documentElement.classList.add('dmd-qs-pointer-active');
                if (resizeHandle.setPointerCapture) {
                    try { resizeHandle.setPointerCapture(event.pointerId); } catch (e) {}
                }
                event.preventDefault();
                event.stopPropagation();
            });

            resizeHandle.addEventListener('pointermove', function (event) {
                if (!resize || event.pointerId !== resize.pointerId) return;
                win.style.width = Math.max(320, resize.width + event.clientX - resize.startX) + 'px';
                win.style.height = Math.max(220, resize.height + event.clientY - resize.startY) + 'px';
                if (isWorkspaceWindow(win)) expandDashboardCanvas();
                event.preventDefault();
            });

            resizeHandle.addEventListener('pointerup', stopResize);
            resizeHandle.addEventListener('pointercancel', stopResize);
            resizeHandle.addEventListener('lostpointercapture', stopResize);
            window.addEventListener('blur', () => stopResize(null));
        }
    }

    function popupShell(className, title, bodyHtml, options) {
        options = options || {};
        const overlay = document.createElement('div');
        overlay.className = 'dmd-qs-overlay ' + className + '-overlay';
        overlay.innerHTML = `
            <section class="dmd-qs-window ${className}" role="dialog" aria-modal="false" data-dmd-window-ignore="1">
                <header class="dmd-qs-window-head">
                    <strong>${esc(title)}</strong>
                    <button type="button" class="dmd-qs-window-close" aria-label="Fermer">×</button>
                </header>
                ${bodyHtml}
                <div class="dmd-qs-resize-handle" aria-hidden="true"></div>
            </section>`;
        const workspaceHost = options.workspace === true || (className === 'dmd-qs-preview-window' && cfg.phase === 'accepted');
        overlay.dataset.dmdQsHost = workspaceHost ? 'workspace' : 'floating';
        (workspaceHost ? dashboardRoot() : document.body).appendChild(overlay);

        const win = overlay.querySelector('.dmd-qs-window');
        const close = overlay.querySelector('.dmd-qs-window-close');
        if (close) {
            close.addEventListener('click', () => overlay.classList.remove('is-open'));
        }

        bindWorkspaceWindow(win);
        return { overlay, win };
    }

    function showWindow(shell) {
        if (!shell) return;
        shell.overlay.classList.add('is-open');
        window.requestAnimationFrame(() => placeWindow(shell.win));
    }

    function ensureSearchWindow() {
        if (state.searchWindow) return state.searchWindow;

        const shell = popupShell(
            'dmd-qs-search-window',
            'Quick-Session · Recherche',
            `<div class="dmd-qs-window-body">
                <div class="dmd-qs-search-row">
                    <label for="dmdQsKeywords">Mots-clés</label>
                    <div class="dmd-qs-search-controls">
                        <input id="dmdQsKeywords" type="text" autocomplete="off" placeholder="Proxmox, CPU, ServAD">
                        <button type="button" id="dmdQsSearchBtn">Rechercher</button>
                    </div>
                    <small>Recherche dans le titre, le nom du PDF, les mots-clés, le résumé, la résolution et les modules liés.</small>
                </div>
                <div id="dmdQsSearchStatus" class="dmd-qs-search-status" aria-live="polite"></div>
                <div id="dmdQsSuggestions" class="dmd-qs-suggestions"></div>
            </div>`
        );

        state.searchWindow = shell;
        const input = shell.overlay.querySelector('#dmdQsKeywords');
        const button = shell.overlay.querySelector('#dmdQsSearchBtn');

        input.value = Array.isArray(cfg.tags) ? cfg.tags.join(', ') : '';
        button.addEventListener('click', runSearch);
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter') {
                e.preventDefault();
                runSearch();
            }
        });
        let searchTimer = null;
        input.addEventListener('input', () => {
            window.clearTimeout(searchTimer);
            const value = String(input.value || '').trim();
            if (value.length < 2) return;
            searchTimer = window.setTimeout(runSearch, 280);
        });

        return shell;
    }

    function openSearchWindow() {
        const shell = ensureSearchWindow();
        showWindow(shell);
        const input = shell.overlay.querySelector('#dmdQsKeywords');
        window.setTimeout(() => input && input.focus(), 50);
    }

    function renderSuggestions() {
        const shell = ensureSearchWindow();
        const container = shell.overlay.querySelector('#dmdQsSuggestions');
        const status = shell.overlay.querySelector('#dmdQsSearchStatus');
        if (!container || !status) return;

        const items = state.suggestions.filter(item => item && item.type === 'procedure' && item.procedure_path && !state.rejected.has(suggestionKey(item)));
        container.innerHTML = '';

        if (!items.length) {
            status.textContent = state.suggestions.some(item => item && item.type === 'procedure' && item.procedure_path)
                ? 'Toutes les procédures affichées ont été refusées. Modifie les mots-clés pour relancer la recherche.'
                : 'Aucune procédure PDF correspondante trouvée.';
            return;
        }

        status.textContent = items.length + ' proposition' + (items.length > 1 ? 's' : '') + ' trouvée' + (items.length > 1 ? 's' : '') + '.';

        items.forEach(item => {
            const score = Math.max(0, Math.min(100, Number(item.score) || 0));
            const title = item.type === 'procedure'
                ? String(item.label || item.procedure || 'Procédure')
                : String(item.source_title || item.label || 'Quick-Session précédente');
            const moduleIds = item.type === 'procedure'
                ? (Array.isArray(item.module_ids) ? item.module_ids : [])
                : (Array.isArray(item.source_modules) ? item.source_modules : []);
            const moduleText = moduleIds.length ? moduleIds.map(moduleLabel).join(', ') : 'Aucun module mémorisé';
            const tags = Array.isArray(item.tags) && item.tags.length ? item.tags.join(', ') : '';
            const summary = String(item.summary || item.resolution || '').trim();

            const card = document.createElement('article');
            card.className = 'dmd-qs-suggestion';
            card.innerHTML = `
                <div class="dmd-qs-suggestion-main">
                    <div class="dmd-qs-suggestion-title">
                        <strong>${item.type === 'procedure' ? '📄' : '🕘'} ${esc(title)}</strong>
                        <span>${score} %</span>
                    </div>
                    <div class="dmd-qs-suggestion-meta">${esc(moduleText)}</div>
                    ${summary ? `<div class="dmd-qs-suggestion-meta">${esc(summary)}</div>` : ''}
                    ${tags ? `<div class="dmd-qs-suggestion-tags">${esc(tags)}</div>` : ''}
                </div>
                <button type="button" class="dmd-qs-suggestion-open">Voir</button>`;
            card.querySelector('.dmd-qs-suggestion-open').addEventListener('click', () => previewSuggestion(item));
            container.appendChild(card);
        });
    }

    async function runSearch() {
        if (state.searchBusy) return;
        const shell = ensureSearchWindow();
        const input = shell.overlay.querySelector('#dmdQsKeywords');
        const button = shell.overlay.querySelector('#dmdQsSearchBtn');
        const status = shell.overlay.querySelector('#dmdQsSearchStatus');
        const keywords = String(input ? input.value : '').trim();

        if (!keywords) {
            status.textContent = 'Saisis au moins un mot-clé.';
            input && input.focus();
            return;
        }

        state.searchBusy = true;
        state.rejected.clear();
        if (button) button.disabled = true;
        status.textContent = 'Recherche des procédures…';

        try {
            const result = await api('suggestions', 'GET', { q: keywords, limit: 15 });
            state.suggestions = Array.isArray(result.suggestions)
                ? result.suggestions.filter(item => item && item.type === 'procedure' && item.procedure_path)
                : [];
            renderSuggestions();
        } catch (e) {
            console.error('Quick-Session search:', e);
            status.textContent = 'Impossible de rechercher les procédures.';
        } finally {
            state.searchBusy = false;
            if (button) button.disabled = false;
        }
    }

    function sessionPreviewHtml(item) {
        const title = String(item.source_title || item.label || 'Quick-Session précédente');
        const modules = Array.isArray(item.source_modules) && item.source_modules.length
            ? item.source_modules.map(moduleLabel).join(', ')
            : 'Aucun module mémorisé';
        const summary = String(item.source_summary || '').trim() || 'Non renseigné';
        const resolution = String(item.source_resolution || '').trim() || 'Non renseignée';

        return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>
            <main style="font-family:Arial,sans-serif;padding:18px;line-height:1.5">
                <h1>${esc(title)}</h1>
                <p><strong>Modules :</strong> ${esc(modules)}</p>
                <p><strong>Résumé :</strong><br>${esc(summary)}</p>
                <p><strong>Résolution :</strong><br>${esc(resolution)}</p>
            </main>
        </body></html>`;
    }

    function ensurePreviewWindow() {
        if (state.previewWindow) return state.previewWindow;

        const shell = popupShell(
            'dmd-qs-preview-window',
            'Quick-Session · Procédure',
            `<div class="dmd-qs-preview-body"><iframe title="Procédure Quick-Session"></iframe></div>
             <div class="dmd-qs-module-picker">
                <strong>Modules à ouvrir</strong>
                <small>Sélectionne les modules utiles. Quick-Session mémorisera ce choix pour cette procédure.</small>
                <div class="dmd-qs-module-picker-list"></div>
             </div>
             <footer class="dmd-qs-preview-actions">
                <button type="button" class="dmd-qs-refuse">Refuser</button>
                <button type="button" class="dmd-qs-accept">Accepter et ouvrir</button>
             </footer>`
        );

        const refuse = shell.overlay.querySelector('.dmd-qs-refuse');
        const accept = shell.overlay.querySelector('.dmd-qs-accept');

        refuse.addEventListener('click', () => {
            if (!state.previewItem) return;
            state.rejected.add(suggestionKey(state.previewItem));
            shell.overlay.classList.remove('is-open');
            state.previewItem = null;
            renderSuggestions();
            openSearchWindow();
        });

        accept.addEventListener('click', acceptPreview);
        state.previewWindow = shell;
        return shell;
    }

    function renderModulePicker(shell, item) {
        const list = shell && shell.overlay ? shell.overlay.querySelector('.dmd-qs-module-picker-list') : null;
        if (!list) return;
        const allowed = Array.isArray(cfg.allowedModules) ? cfg.allowedModules : [];
        const selected = new Set(Array.isArray(item && item.module_ids) ? item.module_ids.map(String) : []);
        list.innerHTML = '';
        if (!allowed.length) {
            list.innerHTML = '<span class="dmd-qs-module-picker-empty">Aucun module accessible pour ce profil.</span>';
            return;
        }
        allowed.forEach(id => {
            const label = document.createElement('label');
            label.className = 'dmd-qs-module-choice';
            const checked = selected.has(String(id)) ? ' checked' : '';
            label.innerHTML = `<input type="checkbox" value="${esc(id)}"${checked}><span>${esc(moduleLabel(id))}</span>`;
            list.appendChild(label);
        });
    }

    function selectedPreviewModules(shell) {
        if (!shell || !shell.overlay) return [];
        return Array.from(shell.overlay.querySelectorAll('.dmd-qs-module-picker-list input[type="checkbox"]:checked'))
            .map(input => String(input.value || '').trim())
            .filter(Boolean);
    }

    function previewSuggestion(item) {
        if (!item) return;
        state.previewItem = item;
        const shell = ensurePreviewWindow();
        const title = item.type === 'procedure'
            ? String(item.label || item.procedure || 'Procédure')
            : String(item.source_title || item.label || 'Quick-Session précédente');
        const headTitle = shell.overlay.querySelector('.dmd-qs-window-head strong');
        const iframe = shell.overlay.querySelector('iframe');
        if (headTitle) headTitle.textContent = title;
        renderModulePicker(shell, item);

        if (item.type === 'procedure' && item.procedure_path) {
            iframe.removeAttribute('srcdoc');
            iframe.src = cfg.procedureBaseUrl + encodeDocumentPath(item.procedure_path);
        } else {
            iframe.removeAttribute('src');
            iframe.srcdoc = sessionPreviewHtml(item);
        }

        if (state.searchWindow) state.searchWindow.overlay.classList.remove('is-open');
        showWindow(shell);
    }

    async function acceptPreview() {
        if (!state.previewItem || state.acceptBusy) return;
        const shell = ensurePreviewWindow();
        const accept = shell.overlay.querySelector('.dmd-qs-accept');
        const refuse = shell.overlay.querySelector('.dmd-qs-refuse');
        state.acceptBusy = true;
        if (accept) accept.disabled = true;
        if (refuse) refuse.disabled = true;

        try {
            const item = state.previewItem;
            if (!item || item.type !== 'procedure' || !item.procedure_path) {
                throw new Error('invalid_procedure_selection');
            }

            const selection = {
                type: 'procedure',
                procedure_path: item.procedure_path || '',
                source_session_id: item.source_session_id || '',
                module_ids: selectedPreviewModules(shell)
            };

            const result = await api('accept', 'POST', { selection });
            const allowed = Array.isArray(cfg.allowedModules) ? cfg.allowedModules : [];
            const opened = Array.isArray(result.modules)
                ? result.modules.filter(m => m && allowed.includes(m.id)).length
                : 0;
            if (!opened) {
                toast('Procédure acceptée. Aucun module n’a été sélectionné ou n’est accessible.');
            } else {
                toast(opened + ' module' + (opened > 1 ? 's' : '') + ' préparé' + (opened > 1 ? 's' : '') + ' pour la Quick-Session.');
            }
            location.href = '?quick_session=1&from=' + encodeURIComponent(result.origin_dashboard || cfg.originDashboard || 'dashboard');
        } catch (e) {
            console.error('Quick-Session accept:', e);
            toast('Impossible d’accepter cette proposition.');
            state.acceptBusy = false;
            if (accept) accept.disabled = false;
            if (refuse) refuse.disabled = false;
        }
    }

    function openAcceptedReference() {
        const accepted = cfg.accepted || null;
        if (!accepted || accepted.type !== 'procedure' || !accepted.procedure_path) {
            return;
        }

        const shell = ensurePreviewWindow();
        const iframe = shell.overlay.querySelector('iframe');
        const headTitle = shell.overlay.querySelector('.dmd-qs-window-head strong');
        const actions = shell.overlay.querySelector('.dmd-qs-preview-actions');
        if (headTitle) headTitle.textContent = String(accepted.title || 'Procédure Quick-Session');
        if (actions) actions.hidden = true;
        iframe.removeAttribute('srcdoc');
        iframe.src = cfg.procedureBaseUrl + encodeDocumentPath(accepted.procedure_path);
        showWindow(shell);
    }


    function setSheetBusy(shell, busy) {
        state.sheetBusy = !!busy;
        if (!shell) return;
        shell.overlay.querySelectorAll('button, input, textarea').forEach(el => {
            if (el.classList.contains('dmd-qs-window-close')) return;
            el.disabled = !!busy;
        });
    }

    function ensureResolutionChoiceWindow() {
        if (state.resolutionChoiceWindow) return state.resolutionChoiceWindow;

        const shell = popupShell(
            'dmd-qs-resolution-choice-window',
            'Quick-Session · Résolu',
            `<div class="dmd-qs-window-body dmd-qs-resolution-choice-body">
                <p>L’intervention est terminée. Que veux-tu faire ?</p>
                <div class="dmd-qs-resolution-choice-actions">
                    <button type="button" class="dmd-qs-fill-sheet">☑ Remplir la fiche</button>
                    <button type="button" class="dmd-qs-close-session">☑ Fermer la session</button>
                </div>
            </div>`
        );

        shell.overlay.querySelector('.dmd-qs-fill-sheet').addEventListener('click', async () => {
            shell.overlay.classList.remove('is-open');
            await openSheetWindow();
        });

        shell.overlay.querySelector('.dmd-qs-close-session').addEventListener('click', async () => {
            await closeQuickSession(shell);
        });

        state.resolutionChoiceWindow = shell;
        return shell;
    }

    function openResolutionChoice() {
        if (state.closeBusy) return;
        const shell = ensureResolutionChoiceWindow();
        showWindow(shell);
    }

    function ensureSheetWindow() {
        if (state.sheetWindow) return state.sheetWindow;

        const shell = popupShell(
            'dmd-qs-sheet-window',
            'Quick-Session · Fiche d’intervention',
            `<form class="dmd-qs-sheet-form">
                <div class="dmd-qs-window-body dmd-qs-sheet-body">
                    <div class="dmd-qs-sheet-context" aria-live="polite"></div>
                    <label>
                        <span>Titre</span>
                        <input type="text" name="title" maxlength="180" placeholder="Ex. VM à 90 % CPU">
                    </label>
                    <label>
                        <span>Résumé</span>
                        <textarea name="summary" rows="4" placeholder="Résumé rapide de la situation et du travail effectué."></textarea>
                    </label>
                    <label>
                        <span>Mots-clés</span>
                        <input type="text" name="tags" maxlength="500" placeholder="cpu, proxmox, servad">
                    </label>
                    <label>
                        <span>Résolution</span>
                        <textarea name="resolution_note" rows="5" placeholder="Décris ce qui a été fait pour résoudre le problème."></textarea>
                    </label>
                    <div class="dmd-qs-sheet-links"></div>
                    <div class="dmd-qs-sheet-status" aria-live="polite"></div>
                </div>
                <footer class="dmd-qs-sheet-actions">
                    <button type="button" class="dmd-qs-sheet-cancel">Fermer la fiche</button>
                    <button type="button" class="dmd-qs-sheet-save">Enregistrer</button>
                    <button type="submit" class="dmd-qs-sheet-save-close">✅ Enregistrer et fermer la session</button>
                </footer>
            </form>`,
            { workspace: cfg.phase === 'accepted' }
        );

        const form = shell.overlay.querySelector('.dmd-qs-sheet-form');
        shell.overlay.querySelector('.dmd-qs-sheet-cancel').addEventListener('click', () => {
            if (!state.sheetBusy) shell.overlay.classList.remove('is-open');
        });
        shell.overlay.querySelector('.dmd-qs-sheet-save').addEventListener('click', () => saveSheet(false));
        form.addEventListener('submit', event => {
            event.preventDefault();
            saveSheet(true);
        });

        state.sheetWindow = shell;
        return shell;
    }

    function renderSheetData(shell, data) {
        const form = shell.overlay.querySelector('.dmd-qs-sheet-form');
        if (!form) return;

        form.elements.title.value = String(data.title || '');
        form.elements.summary.value = String(data.summary || '');
        form.elements.tags.value = Array.isArray(data.tags) ? data.tags.join(', ') : String(data.tags || '');
        form.elements.resolution_note.value = String(data.resolution_note || '');

        const modules = Array.isArray(data.modules) ? data.modules : [];
        const moduleText = modules.length
            ? modules.map(m => moduleLabel(String((m && m.id) || m || ''))).filter(Boolean).join(', ')
            : 'Aucun module enregistré';
        const context = shell.overlay.querySelector('.dmd-qs-sheet-context');
        if (context) {
            context.innerHTML = `<strong>${esc(data.session_id || 'Quick-Session')}</strong><span>Modules : ${esc(moduleText)}</span>`;
        }

        const procedures = Array.isArray(data.linked_procedures) ? data.linked_procedures : [];
        const links = shell.overlay.querySelector('.dmd-qs-sheet-links');
        if (links) {
            links.innerHTML = procedures.length
                ? `<strong>Procédure${procedures.length > 1 ? 's' : ''} liée${procedures.length > 1 ? 's' : ''}</strong><div>${procedures.map(p => `<span>${esc(String(p).split('/').pop())}</span>`).join('')}</div>`
                : '<strong>Procédure liée</strong><div><span>Aucune</span></div>';
        }
    }

    async function openSheetWindow() {
        const shell = ensureSheetWindow();
        const status = shell.overlay.querySelector('.dmd-qs-sheet-status');
        showWindow(shell);
        setSheetBusy(shell, true);
        if (status) status.textContent = 'Chargement de la fiche…';

        try {
            if (cfg.phase === 'accepted') {
                await syncWorkspaceModules();
            }
            const data = await api('sheet', 'GET');
            renderSheetData(shell, data);
            if (status) status.textContent = '';
            window.setTimeout(() => {
                const field = shell.overlay.querySelector('input[name="title"]');
                if (field) field.focus();
            }, 40);
        } catch (e) {
            console.error('Quick-Session sheet:', e);
            if (status) status.textContent = 'Impossible de charger la fiche Quick-Session.';
        } finally {
            setSheetBusy(shell, false);
        }
    }

    async function saveSheet(closeAfterSave) {
        if (state.sheetBusy || state.closeBusy) return;
        const shell = ensureSheetWindow();
        const form = shell.overlay.querySelector('.dmd-qs-sheet-form');
        const status = shell.overlay.querySelector('.dmd-qs-sheet-status');
        if (!form) return;

        const payload = {
            title: String(form.elements.title.value || '').trim(),
            summary: String(form.elements.summary.value || '').trim(),
            tags: String(form.elements.tags.value || '').trim(),
            resolution_note: String(form.elements.resolution_note.value || '').trim(),
            modules: collectWorkspaceModules()
        };

        setSheetBusy(shell, true);
        if (status) status.textContent = 'Enregistrement…';

        try {
            const data = await api('sheet_save', 'POST', payload);
            renderSheetData(shell, data);
            if (status) status.textContent = 'Fiche enregistrée.';
            toast('Fiche Quick-Session enregistrée.');

            if (closeAfterSave) {
                await closeQuickSession(shell);
            }
        } catch (e) {
            console.error('Quick-Session sheet save:', e);
            if (status) status.textContent = 'Impossible d’enregistrer la fiche.';
            setSheetBusy(shell, false);
        }
    }

    async function closeQuickSession(sourceShell) {
        if (state.closeBusy) return;
        state.closeBusy = true;

        const resolveButton = document.getElementById('quickSessionResolveBtn');
        if (resolveButton) resolveButton.disabled = true;
        if (sourceShell) {
            sourceShell.overlay.querySelectorAll('button').forEach(button => { button.disabled = true; });
        }

        try {
            if (cfg.phase === 'accepted') {
                await syncWorkspaceModules();
            }
            const result = await api('resolve', 'POST', {});
            if (result.pdf && result.pdf.filename) {
                toast('Fiche enregistrée et PDF créé : ' + result.pdf.filename);
            }
            location.href = '?dashboard=' + encodeURIComponent(result.origin_dashboard || cfg.originDashboard || 'dashboard');
        } catch (e) {
            console.error('Quick-Session close:', e);
            toast('Impossible de clôturer la Quick-Session.');
            state.closeBusy = false;
            if (resolveButton) resolveButton.disabled = false;
            if (sourceShell) {
                sourceShell.overlay.querySelectorAll('button').forEach(button => { button.disabled = false; });
            }
            if (state.sheetWindow) setSheetBusy(state.sheetWindow, false);
        }
    }

    function renderQuickActions() {
        const root = document.getElementById('dmdQuickSessionRoot');
        if (!root) return;

        if (cfg.phase === 'accepted') {
            const accepted = cfg.accepted || {};
            const title = String(accepted.title || 'Référence acceptée');
            root.innerHTML = `<div class="dmd-qs-inline-actions"><span>📌 ${esc(title)}</span>${accepted.type === 'procedure' ? '<button type="button" id="dmdQsOpenAccepted">📄 Ouvrir la procédure</button>' : ''}</div>`;
            const btn = root.querySelector('#dmdQsOpenAccepted');
            if (btn) btn.addEventListener('click', openAcceptedReference);
            return;
        }

        root.innerHTML = '<div class="dmd-qs-inline-actions"><span>Choisis la procédure avant de préparer l’espace temporaire.</span><button type="button" id="dmdQsOpenSearch">🔎 Rechercher</button></div>';
        const btn = root.querySelector('#dmdQsOpenSearch');
        if (btn) btn.addEventListener('click', openSearchWindow);
    }

    window.DMDQuickSession = Object.assign(window.DMDQuickSession || {}, {
        openResolutionChoice: openResolutionChoice,
        openSheet: openSheetWindow,
        closeSession: closeQuickSession
    });

    document.addEventListener('DOMContentLoaded', function () {
        renderQuickActions();

        if (cfg.phase === 'accepted') {
            window.setTimeout(openAcceptedReference, 180);
            return;
        }

        openSearchWindow();
        if (Array.isArray(cfg.tags) && cfg.tags.length) {
            window.setTimeout(runSearch, 120);
        }
    });
})();
