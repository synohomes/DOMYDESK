<?php
$baseDir = dirname(__DIR__);
require_once $baseDir . '/dmd_runtime.php';
require_once $baseDir . '/Quick-Session/dmd_quick_session_pdf.php';
dmd_security_session_start();
header('Content-Type: text/html; charset=UTF-8');

$email = isset($_SESSION['user']['email']) ? (string)$_SESSION['user']['email'] : '';
if ($email === '') {
    header('Location: ../login.php');
    exit;
}

$profileFile = dmd_profile_path($email, true);
$profile = is_file($profileFile) ? json_decode((string)file_get_contents($profileFile), true) : array();
if (!is_array($profile) || !in_array(isset($profile['role_system']) ? $profile['role_system'] : 'user', array('admin', 'superadmin'), true)) {
    http_response_code(403);
    die('Accès refusé');
}

$csrf = dmd_csrf_token('quick-session-admin');

$profilesDir = $baseDir . '/users/profiles/';
$proceduresDir = $baseDir . '/data/procedures/documents/';
$quickProceduresDir = $proceduresDir . 'quick-session/';
if (!is_dir($quickProceduresDir)) @mkdir($quickProceduresDir, 0750, true);
$message = '';
$error = '';

function dmd_qsa_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_qsa_duration($seconds) {
    $seconds = max(0, (int)$seconds);
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;
    return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
}

function dmd_qsa_date($timestamp) {
    $timestamp = (int)$timestamp;
    return $timestamp > 0 ? date('d/m/Y H:i:s', $timestamp) : '—';
}

function dmd_qsa_users($profilesDir) {
    $users = array();
    if (!is_dir($profilesDir)) {
        return $users;
    }

    foreach (scandir($profilesDir) ?: array() as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $path = $profilesDir . $entry;
        if (is_dir($path) && is_file($path . '/profile/profile.json')) {
            $users[] = $entry;
        }
    }
    sort($users, SORT_NATURAL | SORT_FLAG_CASE);
    return $users;
}

function dmd_qsa_pdf_list($proceduresDir) {
    $pdfs = array();
    if (!is_dir($proceduresDir)) return $pdfs;

    $root = rtrim(str_replace('\\', '/', $proceduresDir), '/') . '/';
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($proceduresDir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if (!$file->isFile() || strtolower($file->getExtension()) !== 'pdf') continue;
        $full = str_replace('\\', '/', $file->getPathname());
        $rel = strpos($full, $root) === 0 ? substr($full, strlen($root)) : $file->getFilename();
        $pdfs[] = $rel;
    }
    sort($pdfs, SORT_NATURAL | SORT_FLAG_CASE);
    return $pdfs;
}

function dmd_qsa_resolve_linked($linked, $procedurePdfs) {
    $linked = is_array($linked) ? $linked : array();
    $available = array_fill_keys($procedurePdfs, true);
    $byBase = array();
    foreach ($procedurePdfs as $pdf) $byBase[basename($pdf)][] = $pdf;
    $out = array();
    foreach ($linked as $value) {
        $value = str_replace('\\', '/', trim((string)$value));
        if ($value === '') continue;
        if (isset($available[$value])) $resolved = $value;
        elseif (!empty($byBase[basename($value)])) $resolved = $byBase[basename($value)][0];
        else continue;
        if (!in_array($resolved, $out, true)) $out[] = $resolved;
    }
    return $out;
}

function dmd_qsa_posted_memory($procedurePdfs) {
    $linked = isset($_POST['linked_procedures']) && is_array($_POST['linked_procedures'])
        ? $_POST['linked_procedures']
        : array();
    $linked = dmd_qsa_resolve_linked($linked, $procedurePdfs);

    return array(
        'title' => isset($_POST['title']) ? $_POST['title'] : '',
        'summary' => isset($_POST['summary']) ? $_POST['summary'] : '',
        'tags' => isset($_POST['tags']) ? $_POST['tags'] : '',
        'resolution_note' => isset($_POST['resolution_note']) ? $_POST['resolution_note'] : '',
        'linked_procedures' => $linked
    );
}

$users = dmd_qsa_users($profilesDir);
$procedurePdfs = dmd_qsa_pdf_list($proceduresDir);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!dmd_csrf_validate(dmd_csrf_request_token($_POST), 'quick-session-admin')) {
        dmd_system_log('quick_session_admin_csrf_denied', 'Quick-Session', 'denied', 'Action d’administration Quick-Session refusée : jeton CSRF invalide.');
        $error = 'Jeton de sécurité invalide. Recharge la page.';
    } else {
        $targetUser = isset($_POST['target_user']) ? dmd_sys_safe_email($_POST['target_user']) : '';
        $filename = isset($_POST['filename']) ? dmd_qs_safe_session_filename($_POST['filename']) : '';

        if ($targetUser === '' || !in_array($targetUser, $users, true) || $filename === '') {
            $error = 'Quick-Session introuvable.';
        } else {
            $adminSessionLock = dmd_qs_acquire_lock($targetUser);
            if (!$adminSessionLock) {
                $error = 'Quick-Session occupée. Réessaie dans un instant.';
            }
        }
        if ($error === '' && isset($_POST['delete_session'])) {
            if (dmd_qs_delete_session($targetUser, $filename)) {
                $message = 'Quick-Session supprimée définitivement.';
                dmd_system_log('quick_session_deleted', $targetUser . '/' . $filename, 'success', $message, array('target_user' => $targetUser, 'filename' => $filename));
                unset($_GET['user'], $_GET['file']);
            } else {
                $error = 'Impossible de supprimer cette Quick-Session.';
            }
        } elseif ($error === '' && isset($_POST['save_as_procedure'])) {
            $metadata = dmd_qsa_posted_memory($procedurePdfs);

            if (!dmd_qs_update_archive_metadata($targetUser, $filename, $metadata)) {
                $error = 'Impossible d’enregistrer la mémoire avant de créer la procédure.';
            } else {
                $sessionFile = dmd_qs_user_dir($targetUser, false) . '/' . $filename;
                $sessionForProcedure = dmd_qs_read_session_file($sessionFile);

                if (!$sessionForProcedure || $sessionForProcedure['status'] !== 'resolved') {
                    $error = 'La Quick-Session doit être résolue avant de devenir une procédure.';
                } else {
                    $procedureName = isset($_POST['procedure_name']) ? trim((string)$_POST['procedure_name']) : '';
                    $created = dmd_qsp_create_procedure_pdf($sessionForProcedure, $targetUser, $quickProceduresDir, $procedureName);

                    if (empty($created['ok']) || empty($created['filename'])) {
                        $error = 'Impossible de générer le PDF de procédure.';
                    } else {
                        $linked = isset($metadata['linked_procedures']) && is_array($metadata['linked_procedures'])
                            ? $metadata['linked_procedures']
                            : array();
                        $createdRef = !empty($created['relative_path']) ? $created['relative_path'] : ('quick-session/' . $created['filename']);
                        if (!in_array($createdRef, $linked, true)) {
                            $linked[] = $createdRef;
                        }
                        $metadata['linked_procedures'] = $linked;
                        if (!dmd_qs_update_archive_metadata($targetUser, $filename, $metadata)) {
                            $error = 'Le PDF a été créé, mais il n’a pas pu être lié à la Quick-Session.';
                        } else {
                            $procedurePdfs = dmd_qsa_pdf_list($proceduresDir);
                            $message = 'Procédure PDF créée et liée à la Quick-Session : ' . $created['filename'];
                            dmd_system_log('quick_session_procedure_created', $targetUser . '/' . $filename, 'success', $message, array('procedure' => $created['filename']));
                            $_GET['user'] = $targetUser;
                            $_GET['file'] = $filename;
                        }
                    }
                }
            }
        } elseif ($error === '' && isset($_POST['save_session_memory'])) {
            $metadata = dmd_qsa_posted_memory($procedurePdfs);

            if (dmd_qs_update_archive_metadata($targetUser, $filename, $metadata)) {
                $message = 'Mémoire de la Quick-Session enregistrée.';
                dmd_system_log('quick_session_memory_updated', $targetUser . '/' . $filename, 'success', $message);
                $_GET['user'] = $targetUser;
                $_GET['file'] = $filename;
            } else {
                $error = 'Impossible d’enregistrer la mémoire de cette Quick-Session.';
            }
        }
        if (isset($adminSessionLock) && is_resource($adminSessionLock)) dmd_qs_release_lock($adminSessionLock);
    }
}

$sessions = array();
foreach ($users as $userEmail) {
    foreach (dmd_qs_session_files($userEmail) as $file) {
        $session = dmd_qs_read_session_file($file);
        if (!$session) {
            continue;
        }

        $session['_user'] = $userEmail;
        $session['_filename'] = basename($file);
        $sessions[] = $session;
    }
}

usort($sessions, function ($a, $b) {
    return ((int)$b['started_at']) <=> ((int)$a['started_at']);
});

$selected = null;
$viewUser = isset($_GET['user']) ? basename((string)$_GET['user']) : '';
$viewFile = isset($_GET['file']) ? dmd_qs_safe_session_filename($_GET['file']) : '';

if ($viewUser !== '' && $viewFile !== '' && in_array($viewUser, $users, true)) {
    $candidate = dmd_qs_user_dir($viewUser, false) . '/' . $viewFile;
    if (is_file($candidate)) {
        $selected = dmd_qs_read_session_file($candidate);
        if ($selected) {
            $selected['_user'] = $viewUser;
            $selected['_filename'] = $viewFile;
        }
    }
}

$theme = 'default';
$themeJson = $profilesDir . dmd_qs_safe_email($email) . '/theme.json';
if (is_file($themeJson)) {
    $themeData = json_decode((string)file_get_contents($themeJson), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidateTheme = basename((string)$themeData['theme']);
        if (is_file($baseDir . '/theme/' . $candidateTheme . '/style.css')) {
            $theme = $candidateTheme;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quick-Sessions</title>
    <link rel="stylesheet" href="../theme/<?= dmd_qsa_h($theme) ?>/style.css">
    <link rel="stylesheet" href="../Quick-Session/quick-session-admin.css">
</head>
<body>
<?php include $baseDir . '/header.php'; ?>

<div class="pe-page">
    <div class="pe-head">
        <div>
            <h1 class="pe-title">🚨 Quick-Sessions</h1>
            <p class="pe-subtitle">Historique des sessions, timeline, mémoire opérationnelle et procédures associées.</p>
        </div>
        <div class="pe-actions">
		<button type="button" onclick="location.href='../adm/site_settings.php'">← Administration</button>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="pe-msg pe-msg-ok"><?= dmd_qsa_h($message) ?></div>
    <?php endif; ?>
    <?php if ($error !== ''): ?>
        <div class="pe-msg pe-msg-error"><?= dmd_qsa_h($error) ?></div>
    <?php endif; ?>

    <?php if ($selected): ?>
        <?php
            $selectedDuration = $selected['status'] === 'active'
                ? time() - (int)$selected['started_at']
                : (int)$selected['duration_seconds'];
            $selectedTags = implode(', ', isset($selected['tags']) ? $selected['tags'] : array());
            $linkedProcedures = dmd_qsa_resolve_linked(
                isset($selected['linked_procedures']) && is_array($selected['linked_procedures']) ? $selected['linked_procedures'] : array(),
                $procedurePdfs
            );
        ?>
        <h2 class="pe-section-title">Détail de la Quick-Session</h2>
        <div class="pe-grid">
            <div class="pe-card">
                <span class="pe-card-main">
                    <span class="pe-card-title"><?= dmd_qsa_h($selected['title'] !== '' ? $selected['title'] : $selected['id']) ?></span>
                    <span class="pe-card-desc"><?= dmd_qsa_h($selected['_user']) ?> · <?= $selected['status'] === 'active' ? 'Active' : 'Résolue' ?> · <?= dmd_qsa_h(dmd_qsa_duration($selectedDuration)) ?></span>
                </span>
            </div>
            <div class="pe-card">
                <span class="pe-card-main">
                    <span class="pe-card-title">Modules</span>
                    <span class="pe-card-desc"><?= count($selected['modules']) ?> module(s) · <?= count($selected['timeline']) ?> événement(s)</span>
                </span>
            </div>
            <div class="pe-card">
                <span class="pe-card-main">
                    <span class="pe-card-title">Procédures</span>
                    <span class="pe-card-desc"><?= count($linkedProcedures) ?> procédure(s) liée(s)</span>
                </span>
            </div>
        </div>

        <h2 class="pe-section-title">Mémoire opérationnelle</h2>
        <form method="post" class="pe-form">
            <input type="hidden" name="csrf_token" value="<?= dmd_qsa_h($csrf) ?>">
            <input type="hidden" name="target_user" value="<?= dmd_qsa_h($selected['_user']) ?>">
            <input type="hidden" name="filename" value="<?= dmd_qsa_h($selected['_filename']) ?>">

            <div>
                <label>Titre</label>
                <input type="text" name="title" value="<?= dmd_qsa_h($selected['title']) ?>" placeholder="Ex. CPU élevé sur Home Assistant">
            </div>

            <div>
                <label>Résumé</label>
                <textarea name="summary" rows="3" placeholder="Résumé rapide de la situation et du travail effectué."><?= dmd_qsa_h($selected['summary']) ?></textarea>
            </div>

            <div>
                <label>Tags de rapprochement</label>
                <input type="text" name="tags" value="<?= dmd_qsa_h($selectedTags) ?>" placeholder="cpu, proxmox, home-assistant, réseau">
                <p class="pe-note">Ces tags permettront au Core de mieux rapprocher les futures Quick-Sessions quand les modules commenceront à fournir leur contexte.</p>
            </div>

            <div>
                <label>Résolution / ce qui a fonctionné</label>
                <textarea name="resolution_note" rows="3" placeholder="Ex. Redémarrage de la VM puis contrôle Zabbix OK."><?= dmd_qsa_h($selected['resolution']['note']) ?></textarea>
            </div>

            <div>
                <label>Procédures PDF liées</label>
                <?php if ($procedurePdfs): ?>
                    <div class="mods-grid">
                        <?php foreach ($procedurePdfs as $pdf): ?>
                            <label class="mod-card">
                                <div class="mod-meta">
                                    <div class="mod-name">📄 <?= dmd_qsa_h(basename($pdf)) ?></div>
                                    <div class="mod-id">Réutilisable sur un cas similaire</div>
                                </div>
                                <input type="checkbox" name="linked_procedures[]" value="<?= dmd_qsa_h($pdf) ?>" <?= in_array($pdf, $linkedProcedures, true) ? 'checked' : '' ?>>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pe-note">Aucun PDF disponible dans data/procedures/documents/ et ses catégories.</p>
                <?php endif; ?>
            </div>

            <?php if ($selected['status'] === 'resolved'): ?>
                <div class="qs-procedure-create">
                    <h3>📚 Créer une procédure depuis cette Quick-Session</h3>
                    <p>Le titre, le résumé, les tags, la résolution, les modules et la timeline seront mis en page dans un PDF enregistré directement dans les procédures DoMyDesk. Le PDF sera ensuite lié à cette session et réutilisable par les futures Quick-Sessions similaires.</p>
                    <div class="qs-procedure-create-row">
                        <div>
                            <label>Nom du PDF de procédure</label>
                            <input type="text" name="procedure_name" value="<?= dmd_qsa_h($selected['title'] !== '' ? $selected['title'] : 'Procedure-' . $selected['id']) ?>" placeholder="Ex. Diagnostic CPU Proxmox">
                        </div>
                        <button type="submit" name="save_as_procedure" value="1">📚 Enregistrer comme procédure PDF</button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="pe-actions qs-inline-actions">
                <button type="submit" name="save_session_memory" value="1">Enregistrer la mémoire</button>
                <button type="button" onclick="openQsPrintModal()">🖨️ Imprimer / PDF</button>
                <button type="button" onclick="location.href='admin.php'">Retour à la liste</button>
            </div>
        </form>

        <h2 class="pe-section-title">Timeline</h2>
        <div class="table-wrap">
            <table class="roles-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Action</th>
                        <th>Cible</th>
                        <th>État</th>
                        <th>Détails</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($selected['timeline'] as $event): ?>
                        <tr>
                            <td><?= dmd_qsa_h(dmd_qsa_date(isset($event['timestamp']) ? $event['timestamp'] : 0)) ?></td>
                            <td><?= dmd_qsa_h(isset($event['module']) ? $event['module'] : 'core') ?></td>
                            <td><?= dmd_qsa_h(isset($event['label']) && $event['label'] !== '' ? $event['label'] : (isset($event['action']) ? $event['action'] : '')) ?></td>
                            <td><?= dmd_qsa_h(isset($event['target']) && $event['target'] !== '' ? $event['target'] : '—') ?></td>
                            <td><?= dmd_qsa_h(isset($event['status']) && $event['status'] !== '' ? $event['status'] : '—') ?></td>
                            <td><?= dmd_qsa_h(isset($event['details']) && $event['details'] !== '' ? $event['details'] : '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <h2 class="pe-section-title">Modules présents dans la session</h2>
        <div class="table-wrap">
            <table class="roles-table">
                <thead><tr><th>Module</th><th>Titre</th><th>Position</th><th>Taille</th></tr></thead>
                <tbody>
                    <?php if (!$selected['modules']): ?>
                        <tr><td colspan="4">Aucun module enregistré.</td></tr>
                    <?php else: ?>
                        <?php foreach ($selected['modules'] as $module): ?>
                            <tr>
                                <td><?= dmd_qsa_h(isset($module['id']) ? $module['id'] : '') ?></td>
                                <td><?= dmd_qsa_h(isset($module['title']) ? $module['title'] : '') ?></td>
                                <td><?= (int)(isset($module['x']) ? $module['x'] : 0) ?> × <?= (int)(isset($module['y']) ? $module['y'] : 0) ?></td>
                                <td><?= (int)(isset($module['width']) ? $module['width'] : 0) ?> × <?= (int)(isset($module['height']) ? $module['height'] : 0) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <form method="post" class="pe-form" onsubmit="return confirm('Supprimer définitivement cette Quick-Session et toute sa timeline ?');">
            <input type="hidden" name="csrf_token" value="<?= dmd_qsa_h($csrf) ?>">
            <input type="hidden" name="target_user" value="<?= dmd_qsa_h($selected['_user']) ?>">
            <input type="hidden" name="filename" value="<?= dmd_qsa_h($selected['_filename']) ?>">
            <div class="pe-actions">
                <button type="submit" name="delete_session" value="1" class="btn-del">Supprimer définitivement</button>
            </div>
        </form>
    <?php endif; ?>

    <h2 class="pe-section-title">Historique</h2>
    <div class="table-wrap">
        <table class="roles-table">
            <thead>
                <tr>
                    <th>Utilisateur</th>
                    <th>Début</th>
                    <th>Fin</th>
                    <th>Durée</th>
                    <th>État</th>
                    <th>Modules</th>
                    <th>Timeline</th>
                    <th>Procédures</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$sessions): ?>
                    <tr><td colspan="9">Aucune Quick-Session enregistrée.</td></tr>
                <?php else: ?>
                    <?php foreach ($sessions as $session): ?>
                        <?php
                            $duration = $session['status'] === 'active'
                                ? time() - (int)$session['started_at']
                                : (int)$session['duration_seconds'];
                        ?>
                        <tr>
                            <td><?= dmd_qsa_h($session['_user']) ?></td>
                            <td><?= dmd_qsa_h(dmd_qsa_date($session['started_at'])) ?></td>
                            <td><?= dmd_qsa_h(dmd_qsa_date($session['closed_at'])) ?></td>
                            <td><?= dmd_qsa_h(dmd_qsa_duration($duration)) ?></td>
                            <td><strong><?= $session['status'] === 'active' ? 'Active' : 'Résolue' ?></strong></td>
                            <td><?= count($session['modules']) ?></td>
                            <td><?= count($session['timeline']) ?></td>
                            <td><?= count($session['linked_procedures']) ?></td>
                            <td>
                                <div class="pe-actions">
                                    <button type="button" onclick="location.href='admin.php?user=<?= rawurlencode($session['_user']) ?>&file=<?= rawurlencode($session['_filename']) ?>'">Voir</button>
                                    <button type="button" onclick="location.href='admin.php?user=<?= rawurlencode($session['_user']) ?>&file=<?= rawurlencode($session['_filename']) ?>&print=1'">🖨️ Imprimer</button>
                                    <form method="post" onsubmit="return confirm('Supprimer définitivement cette Quick-Session ?');">
                                        <input type="hidden" name="csrf_token" value="<?= dmd_qsa_h($csrf) ?>">
                                        <input type="hidden" name="target_user" value="<?= dmd_qsa_h($session['_user']) ?>">
                                        <input type="hidden" name="filename" value="<?= dmd_qsa_h($session['_filename']) ?>">
                                        <button type="submit" name="delete_session" value="1" class="btn-del">Supprimer</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($selected): ?>
<div class="qs-modal-overlay" id="qsPrintModal" aria-hidden="true">
    <div class="qs-modal" role="dialog" aria-modal="true" aria-labelledby="qsPrintModalTitle">
        <div class="qs-modal-head">
            <div class="qs-modal-title">
                <strong id="qsPrintModalTitle">🖨️ Aperçu avant impression</strong>
                <span>Imprime la session complète ou choisis « Enregistrer au format PDF » dans la boîte de dialogue d’impression.</span>
            </div>
            <div class="qs-modal-actions">
                <button type="button" onclick="printQuickSession()">🖨️ Imprimer / Enregistrer en PDF</button>
                <button type="button" onclick="closeQsPrintModal()">Fermer</button>
            </div>
        </div>
        <div class="qs-modal-body">
            <article class="qs-print-sheet">
                <header class="qs-print-header">
                    <div>
                        <div class="qs-print-kicker">DoMyDesk · Rapport Quick-Session</div>
                        <h2><?= dmd_qsa_h($selected['title'] !== '' ? $selected['title'] : $selected['id']) ?></h2>
                    </div>
                    <div class="qs-print-meta">
                        Session : <?= dmd_qsa_h($selected['id']) ?><br>
                        Utilisateur : <?= dmd_qsa_h($selected['_user']) ?><br>
                        Impression : <?= dmd_qsa_h(date('d/m/Y H:i:s')) ?>
                    </div>
                </header>

                <div class="qs-print-stats">
                    <div class="qs-print-stat"><span>État</span><strong><?= $selected['status'] === 'active' ? 'Active' : 'Résolue' ?></strong></div>
                    <div class="qs-print-stat"><span>Durée</span><strong><?= dmd_qsa_h(dmd_qsa_duration($selectedDuration)) ?></strong></div>
                    <div class="qs-print-stat"><span>Début</span><strong><?= dmd_qsa_h(dmd_qsa_date($selected['started_at'])) ?></strong></div>
                    <div class="qs-print-stat"><span>Fin</span><strong><?= dmd_qsa_h(dmd_qsa_date($selected['closed_at'])) ?></strong></div>
                </div>

                <section class="qs-print-section">
                    <h3>Résumé</h3>
                    <?php if (trim((string)$selected['summary']) !== ''): ?>
                        <p><?= dmd_qsa_h($selected['summary']) ?></p>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucun résumé renseigné.</p>
                    <?php endif; ?>
                </section>

                <section class="qs-print-section">
                    <h3>Résolution / ce qui a fonctionné</h3>
                    <?php if (trim((string)$selected['resolution']['note']) !== ''): ?>
                        <p><?= dmd_qsa_h($selected['resolution']['note']) ?></p>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucune résolution renseignée.</p>
                    <?php endif; ?>
                </section>

                <section class="qs-print-section">
                    <h3>Tags de rapprochement</h3>
                    <?php if (!empty($selected['tags'])): ?>
                        <div class="qs-print-tags">
                            <?php foreach ($selected['tags'] as $tag): ?><span><?= dmd_qsa_h($tag) ?></span><?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucun tag.</p>
                    <?php endif; ?>
                </section>

                <section class="qs-print-section">
                    <h3>Ressources</h3>
                    <?php if (!empty($selected['resources'])): ?>
                        <ul class="qs-print-list">
                            <?php foreach ($selected['resources'] as $resource): ?>
                                <?php if (is_array($resource)): ?>
                                    <li>
                                        <?= dmd_qsa_h(isset($resource['label']) && $resource['label'] !== '' ? $resource['label'] : (isset($resource['id']) ? $resource['id'] : 'Ressource')) ?>
                                        <?php if (!empty($resource['type'])): ?> · <?= dmd_qsa_h($resource['type']) ?><?php endif; ?>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucune ressource enregistrée.</p>
                    <?php endif; ?>
                </section>

                <section class="qs-print-section">
                    <h3>Modules utilisés</h3>
                    <?php if (!empty($selected['modules'])): ?>
                        <div class="qs-print-table-wrap">
                            <table class="qs-print-table">
                                <thead><tr><th>Module</th><th>Titre</th><th>Forme</th><th>Position</th><th>Taille</th></tr></thead>
                                <tbody>
                                    <?php foreach ($selected['modules'] as $module): ?>
                                        <tr>
                                            <td><?= dmd_qsa_h(isset($module['id']) ? $module['id'] : '') ?></td>
                                            <td><?= dmd_qsa_h(isset($module['title']) ? $module['title'] : '') ?></td>
                                            <td><?= dmd_qsa_h(isset($module['shape']) ? $module['shape'] : '—') ?></td>
                                            <td><?= (int)(isset($module['x']) ? $module['x'] : 0) ?> × <?= (int)(isset($module['y']) ? $module['y'] : 0) ?></td>
                                            <td><?= (int)(isset($module['width']) ? $module['width'] : 0) ?> × <?= (int)(isset($module['height']) ? $module['height'] : 0) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucun module enregistré.</p>
                    <?php endif; ?>
                </section>

                <section class="qs-print-section">
                    <h3>Timeline complète</h3>
                    <div class="qs-print-table-wrap">
                        <table class="qs-print-table">
                            <thead><tr><th>Date</th><th>Module</th><th>Action</th><th>Cible</th><th>État</th><th>Détails</th></tr></thead>
                            <tbody>
                                <?php foreach ($selected['timeline'] as $event): ?>
                                    <tr>
                                        <td><?= dmd_qsa_h(dmd_qsa_date(isset($event['timestamp']) ? $event['timestamp'] : 0)) ?></td>
                                        <td><?= dmd_qsa_h(isset($event['module']) ? $event['module'] : 'core') ?></td>
                                        <td><?= dmd_qsa_h(isset($event['label']) && $event['label'] !== '' ? $event['label'] : (isset($event['action']) ? $event['action'] : '')) ?></td>
                                        <td><?= dmd_qsa_h(isset($event['target']) && $event['target'] !== '' ? $event['target'] : '—') ?></td>
                                        <td><?= dmd_qsa_h(isset($event['status']) && $event['status'] !== '' ? $event['status'] : '—') ?></td>
                                        <td><?= dmd_qsa_h(isset($event['details']) && $event['details'] !== '' ? $event['details'] : '—') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

                <section class="qs-print-section">
                    <h3>Procédures liées</h3>
                    <?php if (!empty($linkedProcedures)): ?>
                        <ul class="qs-print-list">
                            <?php foreach ($linkedProcedures as $pdf): ?><li>📄 <?= dmd_qsa_h($pdf) ?></li><?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="qs-print-empty">Aucune procédure liée à cette session.</p>
                    <?php endif; ?>
                </section>

                <footer class="qs-print-footer">
                    Rapport généré depuis l’historique Quick-Session DoMyDesk. Les données imprimées correspondent à l’archive enregistrée au moment de l’ouverture de cette page.
                </footer>
            </article>
        </div>
    </div>
</div>
<script>
function openQsPrintModal() {
    var modal = document.getElementById('qsPrintModal');
    if (!modal) return;
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
}

function closeQsPrintModal() {
    var modal = document.getElementById('qsPrintModal');
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
}

function printQuickSession() {
    document.body.classList.add('qs-printing');
    window.print();
    setTimeout(function () {
        document.body.classList.remove('qs-printing');
    }, 500);
}

document.getElementById('qsPrintModal').addEventListener('click', function (event) {
    if (event.target === this) {
        closeQsPrintModal();
    }
});

document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        closeQsPrintModal();
    }
});

<?php if (!empty($_GET['print'])): ?>
document.addEventListener('DOMContentLoaded', function () {
    openQsPrintModal();
});
<?php endif; ?>
</script>
<?php endif; ?>

</body>
</html>
