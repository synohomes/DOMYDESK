<?php
require_once dirname(__DIR__) . '/dmd_runtime.php';

$email = dmd_api_require_user();
if (!dmd_ui_tool_api_allowed('quick_session', $email)) {
    dmd_json_response(array(
        'ok' => false,
        'error' => 'service_disabled',
        'message' => 'Quick-Session est désactivé par l’administrateur.',
    ), 403);
}
$action = strtolower(trim((string)(isset($_GET['action']) ? $_GET['action'] : 'status')));

if ($action === 'status') {
    dmd_api_require_method('GET');
    $active = dmd_qs_get_active($email);
    dmd_json_response(array(
        'ok' => true,
        'active' => (bool)$active,
        'session_id' => $active ? (string)$active['id'] : null,
        'started_at' => $active ? (int)$active['started_at'] : null,
        'phase' => $active ? (string)(isset($active['workflow']['phase']) ? $active['workflow']['phase'] : 'selection') : null,
        'origin_dashboard' => $active ? (string)(isset($active['workflow']['origin_dashboard']) ? $active['workflow']['origin_dashboard'] : 'dashboard') : null,
        'tags' => $active && !empty($active['tags']) ? array_values($active['tags']) : array(),
        'accepted' => $active ? (isset($active['workflow']['accepted']) ? $active['workflow']['accepted'] : null) : null,
    ));
}

if ($action === 'suggestions') {
    dmd_api_require_method('GET');
    $active = dmd_qs_get_active($email);
    $query = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;
    $limit = max(1, min(25, $limit));
    dmd_json_response(array(
        'ok' => true,
        'active' => (bool)$active,
        'query' => $query,
        'suggestions' => $active ? dmd_qs_suggest_procedures($email, $active, $limit, $query) : array(),
    ));
}

if ($action === 'sheet') {
    dmd_api_require_method('GET');
    $active = dmd_qs_get_active($email);
    if (!$active) dmd_json_response(array('ok' => false, 'error' => 'no_active_session'), 409);
    dmd_json_response(array(
        'ok' => true,
        'session_id' => (string)(isset($active['id']) ? $active['id'] : ''),
        'title' => (string)(isset($active['title']) ? $active['title'] : ''),
        'summary' => (string)(isset($active['summary']) ? $active['summary'] : ''),
        'tags' => !empty($active['tags']) && is_array($active['tags']) ? array_values($active['tags']) : array(),
        'resolution_note' => (string)(isset($active['resolution']['note']) ? $active['resolution']['note'] : ''),
        'linked_procedures' => !empty($active['linked_procedures']) && is_array($active['linked_procedures']) ? array_values($active['linked_procedures']) : array(),
        'modules' => !empty($active['modules']) && is_array($active['modules']) ? array_values($active['modules']) : array(),
        'resources' => !empty($active['resources']) && is_array($active['resources']) ? array_values($active['resources']) : array(),
        'started_at' => (int)(isset($active['started_at']) ? $active['started_at'] : 0),
    ));
}

dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('quick-session', $payload);
$quickSessionLock = dmd_qs_acquire_lock($email);
if (!$quickSessionLock) dmd_json_response(array('ok' => false, 'error' => 'session_locked'), 503);
register_shutdown_function(function () use ($quickSessionLock) {
    dmd_qs_release_lock($quickSessionLock);
});

if ($action === 'start') {
    $originDashboard = isset($payload['origin_dashboard']) ? (string)$payload['origin_dashboard'] : 'dashboard';
    $active = dmd_qs_start($email, array('origin_dashboard' => $originDashboard));
    if (!$active) dmd_json_response(array('ok' => false, 'error' => 'start_failed'), 500);
    dmd_json_response(array(
        'ok' => true,
        'active' => true,
        'session_id' => (string)$active['id'],
        'started_at' => (int)$active['started_at'],
        'phase' => (string)(isset($active['workflow']['phase']) ? $active['workflow']['phase'] : 'selection'),
        'origin_dashboard' => (string)(isset($active['workflow']['origin_dashboard']) ? $active['workflow']['origin_dashboard'] : 'dashboard'),
    ));
}

if ($action === 'context') {
    $result = dmd_qs_update_context(
        $email,
        isset($payload['tags']) ? $payload['tags'] : array(),
        isset($payload['title']) ? $payload['title'] : ''
    );
    if (empty($result['ok'])) dmd_json_response($result, (isset($result['error']) && $result['error'] === 'no_active_session') ? 409 : 500);
    dmd_json_response($result);
}

if ($action === 'accept') {
    $selection = isset($payload['selection']) && is_array($payload['selection']) ? $payload['selection'] : array();
    $result = dmd_qs_accept_suggestion($email, $selection);
    if (empty($result['ok'])) {
        $error = isset($result['error']) ? (string)$result['error'] : 'accept_failed';
        dmd_json_response($result, $error === 'no_active_session' ? 409 : 400);
    }
    dmd_json_response($result);
}

if ($action === 'add_resource' || $action === 'start_with_resource') {
    $resource = isset($payload['resource']) ? $payload['resource'] : null;
    if ($action === 'start_with_resource') {
        $result = dmd_qs_start_with_resource($email, $resource, array(
            'origin_dashboard' => isset($payload['origin_dashboard']) ? $payload['origin_dashboard'] : 'dashboard',
        ));
    } else {
        $result = dmd_qs_add_resource($email, $resource);
    }
    if (empty($result['ok'])) {
        $error = isset($result['error']) ? (string)$result['error'] : 'resource_failed';
        dmd_json_response($result, $error === 'no_active_session' ? 409 : 400);
    }
    dmd_json_response($result);
}

if ($action === 'sheet_save') {
    if (isset($payload['modules']) && is_array($payload['modules'])) {
        if (!dmd_qs_save_modules($email, $payload['modules'])) {
            dmd_json_response(array('ok' => false, 'error' => 'module_save_failed'), 409);
        }
    }
    $result = dmd_qs_update_active_metadata($email, array(
        'title' => isset($payload['title']) ? $payload['title'] : '',
        'summary' => isset($payload['summary']) ? $payload['summary'] : '',
        'tags' => isset($payload['tags']) ? $payload['tags'] : '',
        'resolution_note' => isset($payload['resolution_note']) ? $payload['resolution_note'] : '',
    ));
    if (empty($result['ok']) || empty($result['session'])) {
        $error = isset($result['error']) ? (string)$result['error'] : 'sheet_save_failed';
        dmd_json_response(array('ok' => false, 'error' => $error), $error === 'no_active_session' ? 409 : 500);
    }
    $session = $result['session'];
    dmd_json_response(array(
        'ok' => true,
        'session_id' => (string)(isset($session['id']) ? $session['id'] : ''),
        'title' => (string)(isset($session['title']) ? $session['title'] : ''),
        'summary' => (string)(isset($session['summary']) ? $session['summary'] : ''),
        'tags' => !empty($session['tags']) && is_array($session['tags']) ? array_values($session['tags']) : array(),
        'resolution_note' => (string)(isset($session['resolution']['note']) ? $session['resolution']['note'] : ''),
        'linked_procedures' => !empty($session['linked_procedures']) && is_array($session['linked_procedures']) ? array_values($session['linked_procedures']) : array(),
        'modules' => !empty($session['modules']) && is_array($session['modules']) ? array_values($session['modules']) : array(),
        'resources' => !empty($session['resources']) && is_array($session['resources']) ? array_values($session['resources']) : array(),
        'started_at' => (int)(isset($session['started_at']) ? $session['started_at'] : 0),
    ));
}

if ($action === 'save_modules') {
    $modules = isset($payload['modules']) && is_array($payload['modules']) ? $payload['modules'] : $payload;
    unset($modules['csrf_token']);
    if (!dmd_qs_save_modules($email, $modules)) {
        dmd_json_response(array('ok' => false, 'error' => 'no_active_quick_session'), 409);
    }
    $active = dmd_qs_get_active($email);
    dmd_json_response(array(
        'ok' => true,
        'quick_session' => true,
        'modules' => $active && !empty($active['modules']) && is_array($active['modules']) ? array_values($active['modules']) : array(),
    ));
}

if ($action === 'resolve') {
    $active = dmd_qs_get_active($email);
    $filename = $active && !empty($active['_filename']) ? (string)$active['_filename'] : null;
    $sessionId = $active && !empty($active['id']) ? (string)$active['id'] : null;
    $originDashboard = $active ? (string)(isset($active['workflow']['origin_dashboard']) ? $active['workflow']['origin_dashboard'] : 'dashboard') : 'dashboard';

    if (!dmd_qs_resolve($email)) {
        dmd_json_response(array('ok' => false, 'error' => 'resolve_failed'), 500);
    }

    $pdfResult = null;
    if ($filename) {
        $archiveFile = dmd_qs_user_dir($email, false) . '/' . basename($filename);
        $resolvedSession = dmd_qs_read_session_file($archiveFile);
        if ($resolvedSession) {
            require_once __DIR__ . '/dmd_quick_session_pdf.php';
            $proceduresDir = dirname(__DIR__) . '/data/procedures/documents/quick-session';
            if (!is_dir($proceduresDir)) {
                @mkdir($proceduresDir, 0775, true);
            }
            $preferredName = trim((string)(isset($resolvedSession['title']) ? $resolvedSession['title'] : ''));
            $pdfResult = dmd_qsp_create_procedure_pdf($resolvedSession, $email, $proceduresDir, $preferredName);

            if (!empty($pdfResult['ok']) && !empty($pdfResult['relative_path'])) {
                $links = !empty($resolvedSession['linked_procedures']) && is_array($resolvedSession['linked_procedures'])
                    ? array_values($resolvedSession['linked_procedures'])
                    : array();
                if (!in_array($pdfResult['relative_path'], $links, true)) {
                    $links[] = $pdfResult['relative_path'];
                    dmd_qs_update_archive_metadata($email, basename($filename), array('linked_procedures' => $links));
                }
            }
        }
    }

    dmd_json_response(array(
        'ok' => true,
        'active' => false,
        'archived' => true,
        'session_id' => $sessionId,
        'filename' => $filename,
        'origin_dashboard' => $originDashboard,
        'pdf' => $pdfResult,
    ));
}

dmd_json_response(array('ok' => false, 'error' => 'unknown_action'), 400);
