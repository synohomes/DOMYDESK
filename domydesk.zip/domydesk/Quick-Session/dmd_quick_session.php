<?php
/**
 * DoMyDesk 1.2.0 - Quick-Session V3
 *
 * Principes :
 * - aucun timer PHP / aucun polling permanent ;
 * - un petit JSON par Quick-Session dans le profil utilisateur ;
 * - une Quick-Session résolue est ARCHIVÉE, jamais supprimée automatiquement ;
 * - timeline Core prête à recevoir les événements des futurs modules ;
 * - mémoire opérationnelle légère pour suggérer des procédures déjà associées
 *   à des Quick-Sessions similaires, sans scanner les PDF en permanence ;
 * - index sécurisé des procédures créées depuis une session, afin qu'elles
 *   restent réutilisables même si l'archive source est supprimée.
 *
 * Compatible PHP 7.3+
 */

if (!function_exists('dmd_qs_safe_email')) {
    function dmd_qs_safe_email($email) {
        $email = trim((string)$email);
        if (function_exists('dmd_sys_safe_email')) return dmd_sys_safe_email($email);
        if ($email === '' || basename($email) !== $email || strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) return '';
        return preg_match('/^[a-zA-Z0-9_@.\-+]+$/', $email) ? $email : '';
    }
}

if (!function_exists('dmd_qs_user_dir')) {
    function dmd_qs_user_dir($email, $create = true) {
        $safeEmail = dmd_qs_safe_email($email);
        if ($safeEmail === '') return '';
        $dir = dirname(__DIR__) . '/users/profiles/' . $safeEmail . '/quick-session';

        if ($create && !is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }

        if ($create && is_dir($dir)) {
            $htaccess = $dir . '/.htaccess';
            $rules = "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
            if (!is_file($htaccess) || (string)@file_get_contents($htaccess) !== $rules) {
                @file_put_contents($htaccess, $rules, LOCK_EX);
                @chmod($htaccess, 0640);
            }
        }

        return $dir;
    }
}

if (!function_exists('dmd_qs_memory_file')) {
    function dmd_qs_memory_file($email) {
        return dmd_qs_user_dir($email, true) . '/.memory.json';
    }
}

if (!function_exists('dmd_qs_active_pointer_file')) {
    function dmd_qs_active_pointer_file($email) {
        return dmd_qs_user_dir($email, true) . '/.active.json';
    }
}

if (!function_exists('dmd_qs_acquire_lock')) {
    function dmd_qs_acquire_lock($email) {
        $dir = dmd_qs_user_dir($email, true);
        if ($dir === '') return false;
        $handle = @fopen($dir . '/.session.lock', 'c+');
        if (!$handle) return false;
        @chmod($dir . '/.session.lock', 0640);
        if (!@flock($handle, LOCK_EX)) {
            @fclose($handle);
            return false;
        }
        return $handle;
    }
}

if (!function_exists('dmd_qs_release_lock')) {
    function dmd_qs_release_lock($handle) {
        if (!is_resource($handle)) return;
        @flock($handle, LOCK_UN);
        @fclose($handle);
    }
}

if (!function_exists('dmd_qs_read_file')) {
    function dmd_qs_read_file($file) {
        if (!is_file($file)) {
            return null;
        }

        $raw = @file_get_contents($file);
        if ($raw === false || $raw === '') {
            return null;
        }

        $data = json_decode($raw, true);
        return (json_last_error() === JSON_ERROR_NONE && is_array($data)) ? $data : null;
    }
}

if (!function_exists('dmd_qs_write_file')) {
    function dmd_qs_write_file($file, array $data) {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;

        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_qs_session_id')) {
    function dmd_qs_session_id($timestamp) {
        try {
            $suffix = strtoupper(bin2hex(random_bytes(2)));
        } catch (Exception $e) {
            $suffix = strtoupper(substr(md5(uniqid('', true)), 0, 4));
        }

        return 'QS-' . date('Ymd-His', (int)$timestamp) . '-' . $suffix;
    }
}

if (!function_exists('dmd_qs_timeline_entry')) {
    function dmd_qs_timeline_entry($module, $action, $label, $target = '', $status = '', $details = '', $timestamp = null) {
        $timestamp = $timestamp === null ? time() : (int)$timestamp;

        return array(
            'timestamp' => $timestamp,
            'date_iso' => date('c', $timestamp),
            'module' => trim((string)$module) !== '' ? trim((string)$module) : 'core',
            'action' => trim((string)$action),
            'label' => trim((string)$label),
            'target' => trim((string)$target),
            'status' => trim((string)$status),
            'details' => trim((string)$details)
        );
    }
}

if (!function_exists('dmd_qs_normalize_string_list')) {
    function dmd_qs_normalize_string_list($items, $maxItems = 50, $maxLen = 120) {
        if (!is_array($items)) {
            return array();
        }

        $clean = array();
        foreach ($items as $item) {
            $value = trim(strip_tags((string)$item));
            if ($value === '') {
                continue;
            }

            if (function_exists('mb_substr')) {
                $value = mb_substr($value, 0, $maxLen, 'UTF-8');
            } else {
                $value = substr($value, 0, $maxLen);
            }

            if (!in_array($value, $clean, true)) {
                $clean[] = $value;
            }

            if (count($clean) >= $maxItems) {
                break;
            }
        }

        return $clean;
    }
}

if (!function_exists('dmd_qs_sanitize_resource')) {
    function dmd_qs_sanitize_resource($resource) {
        if (!is_array($resource)) {
            return null;
        }

        $cleanField = function ($value, $maxLen = 180) {
            $value = trim(strip_tags((string)$value));
            if (function_exists('mb_substr')) {
                return mb_substr($value, 0, $maxLen, 'UTF-8');
            }
            return substr($value, 0, $maxLen);
        };

        $type = preg_replace('/[^a-zA-Z0-9._\-]/', '', strtolower($cleanField($resource['type'] ?? 'object', 80)));
        $id = $cleanField($resource['id'] ?? '', 180);
        if ($id === '') {
            return null;
        }
        if ($type === '') {
            $type = 'object';
        }

        $source = preg_replace('/[^a-zA-Z0-9._\-]/', '', strtolower($cleanField($resource['source'] ?? '', 80)));
        $label = $cleanField($resource['label'] ?? $id, 180);
        $tags = dmd_qs_normalize_string_list($resource['tags'] ?? array(), 20, 80);

        return array(
            'type' => $type,
            'id' => $id,
            'label' => $label !== '' ? $label : $id,
            'source' => $source,
            'tags' => $tags
        );
    }
}

if (!function_exists('dmd_qs_sanitize_resources')) {
    function dmd_qs_sanitize_resources($resources) {
        if (!is_array($resources)) {
            return array();
        }

        $clean = array();
        $seen = array();
        foreach ($resources as $resource) {
            $item = dmd_qs_sanitize_resource($resource);
            if (!$item) {
                continue;
            }

            $key = strtolower($item['type'] . '|' . $item['source'] . '|' . $item['id']);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $clean[] = $item;
            if (count($clean) >= 100) {
                break;
            }
        }
        return $clean;
    }
}

if (!function_exists('dmd_qs_normalize_session')) {
    function dmd_qs_normalize_session(array $data, $file = null) {
        $startedAt = isset($data['started_at']) ? (int)$data['started_at'] : 0;
        if ($startedAt <= 0 && $file && is_file($file)) {
            $startedAt = (int)@filemtime($file);
        }
        if ($startedAt <= 0) {
            $startedAt = time();
        }

        $data['version'] = max(2, isset($data['version']) ? (int)$data['version'] : 1);
        $data['id'] = isset($data['id']) && trim((string)$data['id']) !== ''
            ? trim((string)$data['id'])
            : dmd_qs_session_id($startedAt);
        $data['status'] = isset($data['status']) && $data['status'] === 'resolved' ? 'resolved' : 'active';
        $data['started_at'] = $startedAt;
        $data['started_at_iso'] = isset($data['started_at_iso']) && $data['started_at_iso'] !== ''
            ? (string)$data['started_at_iso']
            : date('c', $startedAt);

        if (!array_key_exists('closed_at', $data)) {
            $data['closed_at'] = null;
        }
        if (!array_key_exists('closed_at_iso', $data)) {
            $data['closed_at_iso'] = null;
        }
        if (!array_key_exists('duration_seconds', $data)) {
            $data['duration_seconds'] = null;
        }

        $data['title'] = isset($data['title']) ? trim(strip_tags((string)$data['title'])) : '';
        $data['summary'] = isset($data['summary']) ? trim(strip_tags((string)$data['summary'])) : '';
        $data['tags'] = dmd_qs_normalize_string_list(isset($data['tags']) ? $data['tags'] : array(), 40, 80);
        $data['resources'] = dmd_qs_sanitize_resources(isset($data['resources']) ? $data['resources'] : array());
        $data['modules'] = isset($data['modules']) && is_array($data['modules']) ? array_values($data['modules']) : array();
        $data['timeline'] = isset($data['timeline']) && is_array($data['timeline']) ? array_values($data['timeline']) : array();

        if (empty($data['timeline'])) {
            $data['timeline'][] = dmd_qs_timeline_entry(
                'core',
                'quick_session_started',
                'Quick-Session démarrée',
                '',
                'success',
                '',
                $startedAt
            );
        }

        if (!isset($data['resolution']) || !is_array($data['resolution'])) {
            $data['resolution'] = array();
        }
        $data['resolution']['status'] = isset($data['resolution']['status']) ? (string)$data['resolution']['status'] : ($data['status'] === 'resolved' ? 'resolved' : '');
        $data['resolution']['note'] = isset($data['resolution']['note']) ? trim(strip_tags((string)$data['resolution']['note'])) : '';

        if (!array_key_exists('linked_ticket', $data)) {
            $data['linked_ticket'] = null;
        }
        $data['linked_procedures'] = dmd_qs_normalize_string_list(
            isset($data['linked_procedures']) ? $data['linked_procedures'] : array(),
            30,
            180
        );

        if (!isset($data['workflow']) || !is_array($data['workflow'])) {
            $data['workflow'] = array();
        }

        $phase = isset($data['workflow']['phase']) ? strtolower(trim((string)$data['workflow']['phase'])) : '';
        if (!in_array($phase, array('selection', 'accepted'), true)) {
            // Migration transparente des Quick-Sessions actives créées avant ce flux :
            // si elles ont déjà des modules, on les considère comme une intervention acceptée.
            $phase = !empty($data['modules']) ? 'accepted' : 'selection';
        }
        $data['workflow']['phase'] = $phase;

        $originDashboard = isset($data['workflow']['origin_dashboard'])
            ? preg_replace('/[^a-zA-Z0-9_-]/', '_', (string)$data['workflow']['origin_dashboard'])
            : 'dashboard';
        $data['workflow']['origin_dashboard'] = $originDashboard !== '' ? $originDashboard : 'dashboard';

        if (!isset($data['workflow']['accepted']) || !is_array($data['workflow']['accepted'])) {
            $data['workflow']['accepted'] = null;
        }

        return $data;
    }
}

if (!function_exists('dmd_qs_read_session_file')) {
    function dmd_qs_read_session_file($file) {
        $data = dmd_qs_read_file($file);
        if (!$data) {
            return null;
        }
        return dmd_qs_normalize_session($data, $file);
    }
}

if (!function_exists('dmd_qs_session_files')) {
    function dmd_qs_session_files($email) {
        $dir = dmd_qs_user_dir($email, false);
        if (!is_dir($dir)) {
            return array();
        }

        $files = glob($dir . '/*.json');
        if (!$files) {
            return array();
        }

        $out = array();
        foreach ($files as $file) {
            $base = basename($file);
            if ($base === '.memory.json' || substr($base, 0, 1) === '.') {
                continue;
            }
            $out[] = $file;
        }
        return $out;
    }
}

if (!function_exists('dmd_qs_get_active')) {
    function dmd_qs_get_active($email) {
        // Chemin rapide : un seul petit pointeur est lu, quel que soit le nombre
        // de Quick-Sessions archivées dans le profil.
        $pointerFile = dmd_qs_active_pointer_file($email);
        $pointer = dmd_qs_read_file($pointerFile);

        if ($pointer && !empty($pointer['filename'])) {
            $filename = dmd_qs_safe_session_filename($pointer['filename']);
            if ($filename !== '') {
                $file = dmd_qs_user_dir($email, false) . '/' . $filename;
                $data = dmd_qs_read_session_file($file);
                if ($data && ($data['status'] ?? '') === 'active') {
                    $data['_file'] = $file;
                    $data['_filename'] = $filename;
                    return $data;
                }
            }
        }

        // Fallback de réparation uniquement si le pointeur est absent/cassé
        // (ancienne V1, restauration de sauvegarde, manipulation manuelle...).
        $files = dmd_qs_session_files($email);
        if (!$files) {
            @unlink($pointerFile);
            return null;
        }

        $active = null;
        $activeFile = null;
        $bestStartedAt = 0;

        foreach ($files as $file) {
            $data = dmd_qs_read_session_file($file);
            if (!$data || ($data['status'] ?? '') !== 'active') {
                continue;
            }

            $startedAt = isset($data['started_at']) ? (int)$data['started_at'] : (int)@filemtime($file);
            if ($active === null || $startedAt >= $bestStartedAt) {
                $active = $data;
                $activeFile = $file;
                $bestStartedAt = $startedAt;
            }
        }

        if ($active === null) {
            @unlink($pointerFile);
            return null;
        }

        dmd_qs_write_file($pointerFile, array(
            'filename' => basename($activeFile),
            'session_id' => (string)$active['id'],
            'started_at' => (int)$active['started_at']
        ));

        $active['_file'] = $activeFile;
        $active['_filename'] = basename($activeFile);
        return $active;
    }
}

if (!function_exists('dmd_qs_start')) {
    function dmd_qs_start($email, array $options = array()) {
        $existing = dmd_qs_get_active($email);
        if ($existing) {
            return $existing;
        }

        $dir = dmd_qs_user_dir($email, true);
        if (!is_dir($dir) || !is_writable($dir)) {
            return null;
        }

        $now = time();
        $baseName = date('d-m-Y_H-i-s', $now);
        $file = $dir . '/' . $baseName . '.json';

        $suffix = 1;
        while (is_file($file)) {
            $file = $dir . '/' . $baseName . '_' . $suffix . '.json';
            $suffix++;
        }

        $data = array(
            'version' => 2,
            'id' => dmd_qs_session_id($now),
            'status' => 'active',
            'started_at' => $now,
            'started_at_iso' => date('c', $now),
            'closed_at' => null,
            'closed_at_iso' => null,
            'duration_seconds' => null,
            'title' => '',
            'summary' => '',
            'tags' => array(),
            'resources' => array(),
            'modules' => array(),
            'timeline' => array(
                dmd_qs_timeline_entry('core', 'quick_session_started', 'Quick-Session démarrée', '', 'success', '', $now)
            ),
            'resolution' => array(
                'status' => '',
                'note' => ''
            ),
            'linked_ticket' => null,
            'linked_procedures' => array(),
            'workflow' => array(
                'phase' => 'selection',
                'origin_dashboard' => isset($options['origin_dashboard'])
                    ? (preg_replace('/[^a-zA-Z0-9_-]/', '_', (string)$options['origin_dashboard']) ?: 'dashboard')
                    : 'dashboard',
                'accepted' => null
            )
        );

        if (!dmd_qs_write_file($file, $data)) {
            return null;
        }

        if (!dmd_qs_write_file(dmd_qs_active_pointer_file($email), array(
            'filename' => basename($file),
            'session_id' => (string)$data['id'],
            'started_at' => (int)$data['started_at']
        ))) {
            @unlink($file);
            return null;
        }

        $data['_file'] = $file;
        $data['_filename'] = basename($file);
        return $data;
    }
}

if (!function_exists('dmd_qs_resolve_module_id')) {
    /**
     * Résout un ancien identifiant de module vers l'identifiant actuellement installé.
     * Les procédures peuvent conserver un legacy_ids (ex. todolist) alors que le
     * dossier courant est DMD-Todolist. Aucun changement n'est fait si aucun alias
     * installé ne correspond.
     */
    function dmd_qs_resolve_module_id($moduleId) {
        $moduleId = preg_replace('/[^a-zA-Z0-9._\-]/', '', trim((string)$moduleId));
        if ($moduleId === '') return '';

        static $map = null;
        if ($map === null) {
            $map = array();
            $modulesRoot = dirname(__DIR__) . '/modules';
            $dirs = is_dir($modulesRoot) ? (glob($modulesRoot . '/*', GLOB_ONLYDIR) ?: array()) : array();
            foreach ($dirs as $dir) {
                $folderId = basename($dir);
                if ($folderId === '') continue;
                $canonical = $folderId;
                $manifestFile = $dir . '/dmd_module.json';
                $manifest = is_file($manifestFile) ? json_decode((string)@file_get_contents($manifestFile), true) : null;
                if (is_array($manifest)) {
                    $manifestId = preg_replace('/[^a-zA-Z0-9._\-]/', '', trim((string)($manifest['id'] ?? '')));
                    if ($manifestId !== '') $canonical = $manifestId;
                    $aliases = array_merge(array($folderId, $canonical), (array)($manifest['legacy_ids'] ?? array()));
                } else {
                    $aliases = array($folderId);
                }
                foreach ($aliases as $alias) {
                    $alias = preg_replace('/[^a-zA-Z0-9._\-]/', '', trim((string)$alias));
                    if ($alias !== '') $map[strtolower($alias)] = $canonical;
                }
            }
        }

        $key = strtolower($moduleId);
        return isset($map[$key]) ? (string)$map[$key] : $moduleId;
    }
}

if (!function_exists('dmd_qs_sanitize_modules')) {
    function dmd_qs_sanitize_modules($modules) {
        if (!is_array($modules)) {
            return array();
        }

        $clean = array();

        foreach ($modules as $module) {
            if (!is_array($module)) {
                continue;
            }

            $id = isset($module['id']) ? trim((string)$module['id']) : '';
            $id = preg_replace('/[^a-zA-Z0-9._\-]/', '', $id);
            $id = dmd_qs_resolve_module_id($id);
            if ($id === '') {
                continue;
            }

            $shape = isset($module['shape']) ? (string)$module['shape'] : 'square';
            if (!in_array($shape, array('square', 'rounded', 'circle'), true)) {
                $shape = 'square';
            }

            $title = isset($module['title']) ? strip_tags((string)$module['title']) : $id;
            if (function_exists('mb_substr')) {
                $title = mb_substr($title, 0, 180, 'UTF-8');
            } else {
                $title = substr($title, 0, 180);
            }

            $clean[] = array(
                'id' => $id,
                'title' => $title,
                'shape' => $shape,
                'x' => isset($module['x']) ? (int)$module['x'] : 0,
                'y' => isset($module['y']) ? (int)$module['y'] : 0,
                'width' => max(120, isset($module['width']) ? (int)$module['width'] : 280),
                'height' => max(90, isset($module['height']) ? (int)$module['height'] : 280)
            );
        }

        return $clean;
    }
}

if (!function_exists('dmd_qs_module_ids')) {
    function dmd_qs_module_ids($modules) {
        $ids = array();
        if (!is_array($modules)) {
            return $ids;
        }

        foreach ($modules as $module) {
            if (!is_array($module) || empty($module['id'])) {
                continue;
            }
            $id = trim((string)$module['id']);
            if ($id !== '' && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        sort($ids, SORT_STRING);
        return $ids;
    }
}

if (!function_exists('dmd_qs_append_timeline')) {
    function dmd_qs_append_timeline(array &$session, array $entry) {
        if (!isset($session['timeline']) || !is_array($session['timeline'])) {
            $session['timeline'] = array();
        }
        $session['timeline'][] = $entry;

        // Garde-fou : une session ne doit jamais devenir un énorme fichier par accident.
        // 5 000 événements restent largement suffisants pour un historique opérationnel.
        if (count($session['timeline']) > 5000) {
            $session['timeline'] = array_slice($session['timeline'], -5000);
        }
    }
}

if (!function_exists('dmd_qs_save_modules')) {
    function dmd_qs_save_modules($email, $modules) {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return false;
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        $oldIds = dmd_qs_module_ids($active['modules']);
        $cleanModules = dmd_qs_sanitize_modules($modules);
        $newIds = dmd_qs_module_ids($cleanModules);

        $added = array_values(array_diff($newIds, $oldIds));
        $removed = array_values(array_diff($oldIds, $newIds));

        foreach ($added as $moduleId) {
            dmd_qs_append_timeline(
                $active,
                dmd_qs_timeline_entry('core', 'module_opened', 'Module ouvert dans la Quick-Session', $moduleId, 'success')
            );
        }

        foreach ($removed as $moduleId) {
            dmd_qs_append_timeline(
                $active,
                dmd_qs_timeline_entry('core', 'module_closed', 'Module retiré de la Quick-Session', $moduleId, 'success')
            );
        }

        $active['modules'] = $cleanModules;
        $active['updated_at'] = time();
        $active['updated_at_iso'] = date('c', $active['updated_at']);

        return dmd_qs_write_file($file, $active);
    }
}

if (!function_exists('dmd_qs_parse_tags')) {
    function dmd_qs_parse_tags($tags) {
        if (is_string($tags)) {
            $raw = trim($tags);
            if ($raw === '') {
                return array();
            }

            if (preg_match('/[,;\r\n]/', $raw)) {
                $tags = preg_split('/[,;\r\n]+/', $raw);
            } else {
                $tags = preg_split('/\s+/', $raw);
            }
        }

        return dmd_qs_normalize_string_list(is_array($tags) ? $tags : array(), 40, 80);
    }
}

if (!function_exists('dmd_qs_update_context')) {
    function dmd_qs_update_context($email, $tags, $title = '') {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return array('ok' => false, 'error' => 'no_active_session');
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        $active['tags'] = dmd_qs_parse_tags($tags);
        if (trim((string)$title) !== '') {
            $cleanTitle = trim(strip_tags((string)$title));
            $active['title'] = function_exists('mb_substr')
                ? mb_substr($cleanTitle, 0, 180, 'UTF-8')
                : substr($cleanTitle, 0, 180);
        }

        // Changer les mots-clés repasse volontairement par la sélection tant qu'aucune
        // procédure n'a été acceptée pour cette intervention.
        if (empty($active['workflow']['accepted'])) {
            $active['workflow']['phase'] = 'selection';
        }

        $active['updated_at'] = time();
        $active['updated_at_iso'] = date('c', $active['updated_at']);

        if (!dmd_qs_write_file($file, $active)) {
            return array('ok' => false, 'error' => 'write_failed');
        }

        return array('ok' => true, 'tags' => $active['tags'], 'title' => $active['title']);
    }
}

if (!function_exists('dmd_qs_find_session_by_id')) {
    function dmd_qs_find_session_by_id($email, $sessionId) {
        $sessionId = trim((string)$sessionId);
        if ($sessionId === '') {
            return null;
        }

        foreach (dmd_qs_session_files($email) as $file) {
            $session = dmd_qs_read_session_file($file);
            if ($session && (string)($session['id'] ?? '') === $sessionId) {
                $session['_file'] = $file;
                $session['_filename'] = basename($file);
                return $session;
            }
        }
        return null;
    }
}

if (!function_exists('dmd_qs_modules_from_ids')) {
    function dmd_qs_modules_from_ids($ids) {
        $ids = dmd_qs_normalize_string_list(is_array($ids) ? $ids : array(), 50, 120);
        $modules = array();
        foreach ($ids as $index => $id) {
            $id = preg_replace('/[^a-zA-Z0-9._\-]/', '', (string)$id);
            $id = dmd_qs_resolve_module_id($id);
            if ($id === '') continue;

            $col = $index % 3;
            $row = (int)floor($index / 3);
            $modules[] = array(
                'id' => $id,
                'title' => $id,
                'shape' => 'square',
                'x' => 20 + ($col * 430),
                'y' => 20 + ($row * 390),
                'width' => 410,
                'height' => 360
            );
        }
        return $modules;
    }
}

if (!function_exists('dmd_qs_safe_procedure_path')) {
    function dmd_qs_safe_procedure_path($path) {
        $raw = str_replace('\\', '/', trim((string)$path));
        if ($raw === '' || strtolower(pathinfo($raw, PATHINFO_EXTENSION)) !== 'pdf') {
            return '';
        }

        $parts = array();
        foreach (explode('/', $raw) as $part) {
            $part = trim($part);
            if ($part === '' || $part === '.' || $part === '..') continue;
            $parts[] = basename($part);
        }
        if (!$parts) return '';

        $relative = implode('/', $parts);
        $base = dirname(__DIR__) . '/data/procedures/documents/';
        if (is_file($base . $relative)) return $relative;

        if (count($parts) === 1) {
            foreach (array('quick-session/', 'interne/', 'partagees/') as $prefix) {
                if (is_file($base . $prefix . $relative)) return $prefix . $relative;
            }
        }
        return '';
    }
}

if (!function_exists('dmd_qs_accept_suggestion')) {
    function dmd_qs_accept_suggestion($email, array $selection) {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return array('ok' => false, 'error' => 'no_active_session');
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        $type = strtolower(trim((string)($selection['type'] ?? 'procedure')));
        $accepted = array();
        $modules = array();

        if ($type === 'procedure') {
            $relativePath = dmd_qs_safe_procedure_path($selection['procedure_path'] ?? '');
            if ($relativePath === '') {
                return array('ok' => false, 'error' => 'procedure_not_found');
            }

            $procedureIndex = dmd_qs_read_file(dirname(__DIR__) . '/data/secure/quick_session_procedures.json');
            $entry = null;
            if ($procedureIndex && !empty($procedureIndex['procedures']) && is_array($procedureIndex['procedures'])) {
                foreach ($procedureIndex['procedures'] as $candidate) {
                    if (!is_array($candidate)) continue;
                    $candidatePath = !empty($candidate['relative_path']) ? (string)$candidate['relative_path'] : (string)($candidate['filename'] ?? '');
                    $candidatePath = dmd_qs_safe_procedure_path($candidatePath);
                    if ($candidatePath !== '' && strcasecmp($candidatePath, $relativePath) === 0) {
                        $entry = $candidate;
                        break;
                    }
                }
            }

            $sourceSessionId = $entry ? (string)($entry['source_session_id'] ?? '') : (string)($selection['source_session_id'] ?? '');
            $sourceUser = $entry ? (string)($entry['source_user'] ?? '') : '';

            // Le choix fait dans l'interface est prioritaire : il permet de corriger
            // une ancienne association ou d'en créer une lors de la première utilisation.
            $selectedModuleIds = isset($selection['module_ids']) && is_array($selection['module_ids'])
                ? $selection['module_ids'] : array();
            if ($selectedModuleIds) {
                $modules = dmd_qs_modules_from_ids($selectedModuleIds);
            }

            if (!$modules && $sourceSessionId !== '' && ($sourceUser === '' || strcasecmp(dmd_qs_safe_email($sourceUser), dmd_qs_safe_email($email)) === 0)) {
                $sourceSession = dmd_qs_find_session_by_id($email, $sourceSessionId);
                if ($sourceSession && !empty($sourceSession['modules'])) {
                    $modules = dmd_qs_sanitize_modules($sourceSession['modules']);
                }
            }

            if (!$modules) {
                $moduleIds = $entry && !empty($entry['module_ids']) && is_array($entry['module_ids'])
                    ? $entry['module_ids'] : array();
                $modules = dmd_qs_modules_from_ids($moduleIds);
            }

            dmd_qs_remember_procedure_modules($email, $relativePath, dmd_qs_module_ids($modules));

            if (!in_array($relativePath, $active['linked_procedures'], true)) {
                $active['linked_procedures'][] = $relativePath;
            }

            $accepted = array(
                'type' => 'procedure',
                'procedure_path' => $relativePath,
                'title' => $entry && !empty($entry['title']) ? (string)$entry['title'] : basename($relativePath),
                'source_session_id' => $sourceSessionId,
                'module_ids' => dmd_qs_module_ids($modules),
                'accepted_at' => time(),
                'accepted_at_iso' => date('c')
            );
        } elseif ($type === 'session') {
            $sourceSession = null;
            $sourceFilename = dmd_qs_safe_session_filename($selection['source_filename'] ?? '');
            if ($sourceFilename !== '') {
                $sourceFile = dmd_qs_user_dir($email, false) . '/' . $sourceFilename;
                $sourceSession = dmd_qs_read_session_file($sourceFile);
            }
            if (!$sourceSession && !empty($selection['source_session_id'])) {
                $sourceSession = dmd_qs_find_session_by_id($email, $selection['source_session_id']);
            }
            if (!$sourceSession) {
                return array('ok' => false, 'error' => 'source_session_not_found');
            }

            $modules = dmd_qs_sanitize_modules($sourceSession['modules'] ?? array());
            $accepted = array(
                'type' => 'session',
                'title' => trim((string)($sourceSession['title'] ?? '')) ?: ('Quick-Session ' . (string)($sourceSession['id'] ?? '')),
                'source_session_id' => (string)($sourceSession['id'] ?? ''),
                'source_filename' => (string)($sourceFilename ?: ($sourceSession['_filename'] ?? '')),
                'module_ids' => dmd_qs_module_ids($modules),
                'accepted_at' => time(),
                'accepted_at_iso' => date('c')
            );
        } else {
            return array('ok' => false, 'error' => 'invalid_selection_type');
        }

        $active['modules'] = $modules;
        $active['workflow']['phase'] = 'accepted';
        $active['workflow']['accepted'] = $accepted;
        $active['updated_at'] = time();
        $active['updated_at_iso'] = date('c', $active['updated_at']);

        dmd_qs_append_timeline(
            $active,
            dmd_qs_timeline_entry(
                'core',
                'quick_session_reference_accepted',
                'Référence Quick-Session acceptée',
                (string)($accepted['title'] ?? ''),
                'success',
                $type
            )
        );

        foreach (dmd_qs_module_ids($modules) as $moduleId) {
            dmd_qs_append_timeline(
                $active,
                dmd_qs_timeline_entry('core', 'module_opened', 'Module ouvert automatiquement par la Quick-Session', $moduleId, 'success')
            );
        }

        if (!dmd_qs_write_file($file, $active)) {
            return array('ok' => false, 'error' => 'write_failed');
        }

        return array(
            'ok' => true,
            'phase' => 'accepted',
            'accepted' => $accepted,
            'modules' => $modules,
            'origin_dashboard' => (string)$active['workflow']['origin_dashboard']
        );
    }
}

if (!function_exists('dmd_qs_add_timeline_event')) {
    /**
     * API interne Quick-Session. Les modules 1.2.0 publient désormais leurs
     * actions avec dmd_module_event() ; le bus d'activité alimente la timeline.
     */
    function dmd_qs_add_timeline_event($email, $module, $action, $target = '', $status = '', $details = '', $label = '') {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return false;
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        if ($label === '') {
            $label = trim((string)$action);
        }

        dmd_qs_append_timeline(
            $active,
            dmd_qs_timeline_entry($module, $action, $label, $target, $status, $details)
        );

        $active['updated_at'] = time();
        $active['updated_at_iso'] = date('c', $active['updated_at']);

        return dmd_qs_write_file($file, $active);
    }
}

if (!function_exists('dmd_qs_add_resource')) {
    function dmd_qs_add_resource($email, $resource) {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return array('ok' => false, 'added' => false, 'error' => 'no_active_session');
        }

        $clean = dmd_qs_sanitize_resource($resource);
        if (!$clean) {
            return array('ok' => false, 'added' => false, 'error' => 'invalid_resource');
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        $key = strtolower($clean['type'] . '|' . $clean['source'] . '|' . $clean['id']);
        foreach ($active['resources'] as $existing) {
            $existingKey = strtolower(
                (string)($existing['type'] ?? '') . '|' .
                (string)($existing['source'] ?? '') . '|' .
                (string)($existing['id'] ?? '')
            );
            if ($existingKey === $key) {
                return array('ok' => true, 'added' => false, 'resource' => $clean);
            }
        }

        $active['resources'][] = $clean;
        dmd_qs_append_timeline(
            $active,
            dmd_qs_timeline_entry(
                $clean['source'] !== '' ? $clean['source'] : 'core',
                'resource_added',
                'Ressource ajoutée à la Quick-Session',
                $clean['label'],
                'success',
                $clean['type']
            )
        );

        $active['updated_at'] = time();
        $active['updated_at_iso'] = date('c', $active['updated_at']);

        if (!dmd_qs_write_file($file, $active)) {
            return array('ok' => false, 'added' => false, 'error' => 'write_failed');
        }

        return array('ok' => true, 'added' => true, 'resource' => $clean);
    }
}

if (!function_exists('dmd_qs_start_with_resource')) {
    function dmd_qs_start_with_resource($email, $resource, $options = array()) {
        $active = dmd_qs_start($email, is_array($options) ? $options : array());
        if (!$active) {
            return array('ok' => false, 'error' => 'start_failed');
        }

        $result = dmd_qs_add_resource($email, $resource);
        if (empty($result['ok'])) {
            return $result;
        }

        $active = dmd_qs_get_active($email);
        return array(
            'ok' => true,
            'added' => !empty($result['added']),
            'session_id' => $active ? (string)$active['id'] : null,
            'started_at' => $active ? (int)$active['started_at'] : null,
            'resource' => $result['resource'] ?? null
        );
    }
}

if (!function_exists('dmd_qs_resolve')) {
    function dmd_qs_resolve($email) {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return true;
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        $now = time();
        $active['status'] = 'resolved';
        $active['closed_at'] = $now;
        $active['closed_at_iso'] = date('c', $now);
        $active['duration_seconds'] = max(0, $now - (int)$active['started_at']);
        $active['resolution']['status'] = 'resolved';
        $active['updated_at'] = $now;
        $active['updated_at_iso'] = date('c', $now);

        dmd_qs_append_timeline(
            $active,
            dmd_qs_timeline_entry('core', 'quick_session_resolved', 'Quick-Session marquée comme résolue', '', 'success', '', $now)
        );

        // IMPORTANT : on archive. Aucun unlink() du JSON de session.
        $ok = dmd_qs_write_file($file, $active);
        if ($ok) {
            @unlink(dmd_qs_active_pointer_file($email));

            // Chaque Quick-Session résolue nourrit immédiatement la mémoire.
            // Aucun scan permanent : l'index n'est reconstruit qu'à la clôture
            // ou lors d'une migration d'un ancien format de mémoire.
            dmd_qs_rebuild_memory_index($email);
        }
        return $ok;
    }
}

if (!function_exists('dmd_qs_safe_session_filename')) {
    function dmd_qs_safe_session_filename($filename) {
        $filename = basename((string)$filename);
        if (!preg_match('/^[a-zA-Z0-9._\-]+\.json$/', $filename)) {
            return '';
        }
        if ($filename === '.memory.json' || substr($filename, 0, 1) === '.') {
            return '';
        }
        return $filename;
    }
}

if (!function_exists('dmd_qs_delete_session')) {
    function dmd_qs_delete_session($email, $filename) {
        $filename = dmd_qs_safe_session_filename($filename);
        if ($filename === '') {
            return false;
        }

        $dir = dmd_qs_user_dir($email, false);
        if (!is_dir($dir)) {
            return false;
        }

        $file = $dir . '/' . $filename;
        if (!is_file($file)) {
            return false;
        }

        $ok = @unlink($file);
        if ($ok) {
            $pointer = dmd_qs_read_file(dmd_qs_active_pointer_file($email));
            if ($pointer && isset($pointer['filename']) && basename((string)$pointer['filename']) === $filename) {
                @unlink(dmd_qs_active_pointer_file($email));
            }
            dmd_qs_rebuild_memory_index($email);
        }
        return $ok;
    }
}


if (!function_exists('dmd_qs_update_active_metadata')) {
    function dmd_qs_update_active_metadata($email, array $metadata) {
        $active = dmd_qs_get_active($email);
        if (!$active || empty($active['_file'])) {
            return array('ok' => false, 'error' => 'no_active_session');
        }

        $file = $active['_file'];
        unset($active['_file'], $active['_filename']);
        $active = dmd_qs_normalize_session($active, $file);

        if (array_key_exists('title', $metadata)) {
            $active['title'] = trim(strip_tags((string)$metadata['title']));
        }
        if (array_key_exists('summary', $metadata)) {
            $active['summary'] = trim(strip_tags((string)$metadata['summary']));
        }
        if (array_key_exists('resolution_note', $metadata)) {
            $active['resolution']['note'] = trim(strip_tags((string)$metadata['resolution_note']));
        }
        if (array_key_exists('tags', $metadata)) {
            $tags = $metadata['tags'];
            if (is_string($tags)) {
                $tags = preg_split('/[,;]+/', $tags);
            }
            $active['tags'] = dmd_qs_normalize_string_list(is_array($tags) ? $tags : array(), 40, 80);
        }

        $now = time();
        $active['updated_at'] = $now;
        $active['updated_at_iso'] = date('c', $now);
        dmd_qs_append_timeline(
            $active,
            dmd_qs_timeline_entry('core', 'quick_session_sheet_saved', 'Fiche Quick-Session enregistrée', '', 'success', '', $now)
        );

        if (!dmd_qs_write_file($file, $active)) {
            return array('ok' => false, 'error' => 'write_failed');
        }

        return array('ok' => true, 'session' => $active);
    }
}

if (!function_exists('dmd_qs_update_archive_metadata')) {
    function dmd_qs_update_archive_metadata($email, $filename, array $metadata) {
        $filename = dmd_qs_safe_session_filename($filename);
        if ($filename === '') {
            return false;
        }

        $file = dmd_qs_user_dir($email, false) . '/' . $filename;
        $session = dmd_qs_read_session_file($file);
        if (!$session) {
            return false;
        }

        $session['title'] = isset($metadata['title']) ? trim(strip_tags((string)$metadata['title'])) : $session['title'];
        $session['summary'] = isset($metadata['summary']) ? trim(strip_tags((string)$metadata['summary'])) : $session['summary'];
        $session['resolution']['note'] = isset($metadata['resolution_note'])
            ? trim(strip_tags((string)$metadata['resolution_note']))
            : $session['resolution']['note'];

        $tags = isset($metadata['tags']) ? $metadata['tags'] : $session['tags'];
        if (is_string($tags)) {
            $tags = preg_split('/[,;]+/', $tags);
        }
        $session['tags'] = dmd_qs_normalize_string_list(is_array($tags) ? $tags : array(), 40, 80);

        $procedures = isset($metadata['linked_procedures']) ? $metadata['linked_procedures'] : $session['linked_procedures'];
        $session['linked_procedures'] = dmd_qs_normalize_string_list(
            is_array($procedures) ? $procedures : array(),
            30,
            180
        );

        $session['updated_at'] = time();
        $session['updated_at_iso'] = date('c', $session['updated_at']);

        if (!dmd_qs_write_file($file, $session)) {
            return false;
        }

        dmd_qs_rebuild_memory_index($email);
        return true;
    }
}

if (!function_exists('dmd_qs_resource_types')) {
    function dmd_qs_resource_types($resources) {
        $types = array();
        if (!is_array($resources)) {
            return $types;
        }

        foreach ($resources as $resource) {
            if (!is_array($resource)) {
                continue;
            }
            $type = isset($resource['type']) ? trim((string)$resource['type']) : '';
            if ($type !== '' && !in_array($type, $types, true)) {
                $types[] = $type;
            }
        }
        sort($types, SORT_STRING);
        return $types;
    }
}

if (!function_exists('dmd_qs_rebuild_memory_index')) {
    function dmd_qs_rebuild_memory_index($email) {
        $entries = array();

        foreach (dmd_qs_session_files($email) as $file) {
            $session = dmd_qs_read_session_file($file);
            if (!$session || $session['status'] !== 'resolved') {
                continue;
            }

            $entries[] = array(
                'session_id' => $session['id'],
                'filename' => basename($file),
                'closed_at' => (int)($session['closed_at'] ?: $session['started_at']),
                'title' => (string)$session['title'],
                'summary' => (string)$session['summary'],
                'module_ids' => dmd_qs_module_ids($session['modules']),
                'resource_types' => dmd_qs_resource_types($session['resources']),
                'tags' => dmd_qs_normalize_string_list($session['tags'], 40, 80),
                'resolution_note' => isset($session['resolution']['note']) ? (string)$session['resolution']['note'] : '',
                'procedures' => dmd_qs_normalize_string_list($session['linked_procedures'], 30, 180)
            );
        }

        usort($entries, function ($a, $b) {
            return ((int)$b['closed_at']) <=> ((int)$a['closed_at']);
        });

        return dmd_qs_write_file(
            dmd_qs_memory_file($email),
            array(
                'version' => 2,
                'updated_at' => time(),
                'entries' => $entries
            )
        );
    }
}

if (!function_exists('dmd_qs_memory_index')) {
    function dmd_qs_memory_index($email) {
        $file = dmd_qs_memory_file($email);
        $memory = dmd_qs_read_file($file);

        // Migration automatique de l'ancien index V1 : celui-ci ne gardait
        // que les sessions possédant déjà un PDF lié, ce qui empêchait une
        // Quick-Session simplement résolue d'être reconnue comme expérience passée.
        if (!$memory || (int)($memory['version'] ?? 0) < 2 || !isset($memory['entries']) || !is_array($memory['entries'])) {
            dmd_qs_rebuild_memory_index($email);
            $memory = dmd_qs_read_file($file);
        }

        if (!$memory || !isset($memory['entries']) || !is_array($memory['entries'])) {
            return array(
                'version' => 2,
                'updated_at' => 0,
                'entries' => array()
            );
        }

        return $memory;
    }
}

if (!function_exists('dmd_qs_search_fold')) {
    function dmd_qs_search_fold($value) {
        $value = html_entity_decode(strip_tags((string)$value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = trim($value);

        if (function_exists('transliterator_transliterate')) {
            $tmp = @transliterator_transliterate('NFD; [:Nonspacing Mark:] Remove; NFC', $value);
            if (is_string($tmp) && $tmp !== '') {
                $value = $tmp;
            }
        } elseif (function_exists('iconv')) {
            $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if (is_string($tmp) && $tmp !== '') {
                $value = $tmp;
            }
        }

        $value = function_exists('mb_strtolower')
            ? mb_strtolower($value, 'UTF-8')
            : strtolower($value);

        // Tout séparateur devient un espace : "AD, CPU", "AD-CPU" et "AD CPU"
        // produisent les mêmes termes de recherche.
        $value = preg_replace('/[^a-z0-9]+/i', ' ', $value);
        return trim(preg_replace('/\\s+/', ' ', (string)$value));
    }
}

if (!function_exists('dmd_qs_search_tokens')) {
    function dmd_qs_search_tokens($values) {
        if (!is_array($values)) {
            $values = array($values);
        }

        $tokens = array();
        foreach ($values as $value) {
            if (is_array($value)) {
                foreach (dmd_qs_search_tokens($value) as $nestedToken) {
                    $tokens[$nestedToken] = true;
                }
                continue;
            }

            $folded = dmd_qs_search_fold($value);
            if ($folded === '') continue;

            foreach (preg_split('/\\s+/', $folded) as $token) {
                $token = trim((string)$token);
                if ($token === '' || $token === 'pdf') continue;
                $tokens[$token] = true;
            }
        }

        return array_keys($tokens);
    }
}

if (!function_exists('dmd_qs_search_token_matches')) {
    function dmd_qs_search_token_matches($needle, array $haystack) {
        $needle = (string)$needle;
        if ($needle === '') return false;

        foreach ($haystack as $candidate) {
            $candidate = (string)$candidate;
            if ($candidate === '') continue;

            if ($needle === $candidate) {
                return true;
            }

            // Une saisie partielle reste utile ("proxm" -> "proxmox"),
            // mais uniquement à partir de 4 caractères pour éviter les faux positifs.
            if (strlen($needle) >= 4 && strlen($candidate) >= 4) {
                if (strpos($candidate, $needle) === 0 || strpos($needle, $candidate) === 0) {
                    return true;
                }
            }
        }

        return false;
    }
}

if (!function_exists('dmd_qs_similarity_score')) {
    function dmd_qs_similarity_score(array $current, array $past) {
        $moduleIds = dmd_qs_module_ids(isset($current['modules']) ? $current['modules'] : array());
        $pastModules = isset($past['module_ids']) && is_array($past['module_ids']) ? $past['module_ids'] : array();

        $resourceTypes = dmd_qs_resource_types(isset($current['resources']) ? $current['resources'] : array());
        $pastResourceTypes = isset($past['resource_types']) && is_array($past['resource_types']) ? $past['resource_types'] : array();

        // La zone "Mots-clés" est une vraie recherche, pas une comparaison stricte
        // de chaînes. On cherche chaque terme dans les tags ET dans le contexte
        // descriptif de la procédure/session.
        $queryTokens = dmd_qs_search_tokens(isset($current['tags']) ? $current['tags'] : array());

        $pastSearchValues = array();
        foreach (array('tags', 'title', 'summary', 'resolution', 'resolution_note', 'filename', 'procedure', 'procedures', 'module_ids') as $field) {
            if (array_key_exists($field, $past)) {
                $pastSearchValues[] = $past[$field];
            }
        }
        $pastTokens = dmd_qs_search_tokens($pastSearchValues);

        $availableSignals = 0;
        $score = 0.0;

        if (!empty($moduleIds)) {
            $availableSignals += 50;
            $foldModules = array_map('strtolower', $moduleIds);
            $foldPastModules = array_map('strtolower', $pastModules);
            $intersection = count(array_intersect($foldModules, $foldPastModules));
            $union = count(array_unique(array_merge($foldModules, $foldPastModules)));
            if ($union > 0) {
                $score += 50 * ($intersection / $union);
            }
        }

        if (!empty($resourceTypes)) {
            $availableSignals += 20;
            $intersection = count(array_intersect($resourceTypes, $pastResourceTypes));
            $union = count(array_unique(array_merge($resourceTypes, $pastResourceTypes)));
            if ($union > 0) {
                $score += 20 * ($intersection / $union);
            }
        }

        if (!empty($queryTokens)) {
            $availableSignals += 30;

            $matched = 0;
            foreach ($queryTokens as $queryToken) {
                if (dmd_qs_search_token_matches($queryToken, $pastTokens)) {
                    $matched++;
                }
            }

            // On mesure la couverture de la requête : "AD CPU" trouve donc
            // ["AD", "CPU"], ["AD, CPU"], "CPU-a-90-sur-l-ad.pdf", etc.
            $coverage = $matched / max(1, count($queryTokens));
            $score += 30 * $coverage;
        }

        if ($availableSignals === 0) {
            return 0.0;
        }

        return min(100.0, ($score / $availableSignals) * 100.0);
    }
}


if (!function_exists('dmd_qs_search_token_quality')) {
    function dmd_qs_search_token_quality($needle, $candidate) {
        $needle = (string)$needle;
        $candidate = (string)$candidate;
        if ($needle === '' || $candidate === '') return 0.0;
        if ($needle === $candidate) return 1.0;
        if (strlen($needle) >= 3 && strpos($candidate, $needle) === 0) return 0.92;
        if (strlen($candidate) >= 3 && strpos($needle, $candidate) === 0) return 0.86;
        if (strlen($needle) >= 3 && strpos($candidate, $needle) !== false) return 0.78;
        if (strlen($needle) >= 5 && strlen($candidate) >= 5 && function_exists('levenshtein')) {
            $distance = levenshtein($needle, $candidate);
            if ($distance === 1) return 0.72;
            if ($distance === 2 && max(strlen($needle), strlen($candidate)) >= 8) return 0.58;
        }
        return 0.0;
    }
}


if (!function_exists('dmd_qs_catalog_filesystem_procedures')) {
    /**
     * Retourne tous les PDF réellement présents dans data/procedures/documents.
     * Cela évite qu'une procédure existante soit invisible simplement parce
     * qu'elle n'a pas encore été enrichie par un index Quick-Session.
     */
    function dmd_qs_catalog_filesystem_procedures() {
        $base = dirname(__DIR__) . '/data/procedures/documents/';
        if (!is_dir($base)) return array();

        $items = array();
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($it as $fileInfo) {
                if (!$fileInfo->isFile()) continue;
                $name = $fileInfo->getFilename();
                if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'pdf') continue;
                $full = str_replace('\\', '/', $fileInfo->getPathname());
                $baseNorm = rtrim(str_replace('\\', '/', $base), '/') . '/';
                if (strpos($full, $baseNorm) !== 0) continue;
                $relative = substr($full, strlen($baseNorm));
                $relative = dmd_qs_safe_procedure_path($relative);
                if ($relative === '') continue;
                $items[] = array(
                    'relative_path' => $relative,
                    'filename' => basename($relative),
                    'title' => pathinfo(basename($relative), PATHINFO_FILENAME),
                    'categories' => array(dirname($relative) !== '.' ? dirname($relative) : ''),
                    'created_at' => (int)$fileInfo->getMTime(),
                );
            }
        } catch (Exception $e) {
            return array();
        }
        return $items;
    }
}

if (!function_exists('dmd_qs_remember_procedure_modules')) {
    /** Mémorise les modules choisis pour une procédure afin des les rouvrir automatiquement ensuite. */
    function dmd_qs_remember_procedure_modules($email, $relativePath, $moduleIds) {
        $relativePath = dmd_qs_safe_procedure_path($relativePath);
        $moduleIds = dmd_qs_normalize_string_list($moduleIds, 50, 120);
        if ($relativePath === '') return false;

        $indexFile = dirname(__DIR__) . '/data/secure/quick_session_procedures.json';
        $index = dmd_qs_read_file($indexFile);
        if (!is_array($index)) $index = array('version' => 1, 'procedures' => array());
        if (empty($index['procedures']) || !is_array($index['procedures'])) $index['procedures'] = array();

        $found = false;
        foreach ($index['procedures'] as &$entry) {
            if (!is_array($entry)) continue;
            $candidate = !empty($entry['relative_path']) ? (string)$entry['relative_path'] : (string)($entry['filename'] ?? '');
            $candidate = dmd_qs_safe_procedure_path($candidate);
            if ($candidate !== '' && strcasecmp($candidate, $relativePath) === 0) {
                $entry['relative_path'] = $relativePath;
                $entry['filename'] = basename($relativePath);
                $entry['module_ids'] = array_values($moduleIds);
                $entry['updated_at'] = time();
                $entry['updated_at_iso'] = date('c');
                $found = true;
                break;
            }
        }
        unset($entry);

        if (!$found) {
            $index['procedures'][] = array(
                'filename' => basename($relativePath),
                'relative_path' => $relativePath,
                'title' => pathinfo(basename($relativePath), PATHINFO_FILENAME),
                'summary' => '',
                'tags' => array(),
                'module_ids' => array_values($moduleIds),
                'resource_types' => array(),
                'resolution' => '',
                'source_session_id' => '',
                'source_user' => dmd_qs_safe_email($email),
                'created_at' => time(),
                'created_at_iso' => date('c')
            );
        }

        $index['updated_at'] = time();
        $index['updated_at_iso'] = date('c');
        return dmd_qs_write_file($indexFile, $index);
    }
}

if (!function_exists('dmd_qs_search_procedures')) {
    /**
     * Vraie recherche de procédures : la saisie utilisateur est prioritaire.
     * Le contexte de la Quick-Session ne sert que de petit bonus de classement.
     * La recherche ne modifie jamais les tags/titre de la session active.
     */
    function dmd_qs_search_procedures($email, array $currentSession, $query, $limit = 12) {
        $query = trim((string)$query);
        $queryFold = dmd_qs_search_fold($query);
        $queryTokens = dmd_qs_search_tokens(array($query));
        if ($queryFold === '' || !$queryTokens) return array();

        $catalog = array();
        $add = function ($entry) use (&$catalog) {
            if (!is_array($entry)) return;
            $path = isset($entry['relative_path']) ? (string)$entry['relative_path'] : (string)($entry['procedure_path'] ?? ($entry['filename'] ?? ''));
            $path = dmd_qs_safe_procedure_path($path);
            if ($path === '') return;
            $key = strtolower($path);
            if (!isset($catalog[$key])) {
                $catalog[$key] = array(
                    'relative_path' => $path,
                    'filename' => basename($path),
                    'original_name' => '',
                    'title' => '',
                    'summary' => '',
                    'resolution' => '',
                    'tags' => array(),
                    'module_ids' => array(),
                    'resource_types' => array(),
                    'categories' => array(),
                    'source_session_id' => '',
                    'created_at' => 0,
                );
            }
            foreach (array('original_name','title','summary','resolution','source_session_id') as $field) {
                if (!empty($entry[$field])) $catalog[$key][$field] = (string)$entry[$field];
            }
            foreach (array('tags','module_ids','resource_types','categories') as $field) {
                if (!empty($entry[$field]) && is_array($entry[$field])) {
                    $catalog[$key][$field] = array_values(array_unique(array_merge($catalog[$key][$field], $entry[$field])));
                }
            }
            $ts = isset($entry['created_at']) ? (int)$entry['created_at'] : (isset($entry['closed_at']) ? (int)$entry['closed_at'] : 0);
            if ($ts > $catalog[$key]['created_at']) $catalog[$key]['created_at'] = $ts;
        };

        $qsIndex = dmd_qs_read_file(dirname(__DIR__) . '/data/secure/quick_session_procedures.json');
        if ($qsIndex && !empty($qsIndex['procedures']) && is_array($qsIndex['procedures'])) {
            foreach ($qsIndex['procedures'] as $entry) $add($entry);
        }

        $localIndex = dmd_qs_read_file(dirname(__DIR__) . '/data/secure/procedures_local_index.json');
        if ($localIndex && !empty($localIndex['procedures']) && is_array($localIndex['procedures'])) {
            foreach ($localIndex['procedures'] as $entry) $add($entry);
        }

        $memory = dmd_qs_memory_index($email);
        if (!empty($memory['entries']) && is_array($memory['entries'])) {
            foreach ($memory['entries'] as $entry) {
                if (!is_array($entry) || empty($entry['procedures']) || !is_array($entry['procedures'])) continue;
                foreach ($entry['procedures'] as $procedure) {
                    $add(array(
                        'relative_path' => $procedure,
                        'title' => $entry['title'] ?? '',
                        'summary' => $entry['summary'] ?? '',
                        'resolution' => $entry['resolution_note'] ?? '',
                        'tags' => $entry['tags'] ?? array(),
                        'module_ids' => $entry['module_ids'] ?? array(),
                        'resource_types' => $entry['resource_types'] ?? array(),
                        'source_session_id' => $entry['session_id'] ?? '',
                        'created_at' => $entry['closed_at'] ?? 0,
                    ));
                }
            }
        }

        foreach (dmd_qs_catalog_filesystem_procedures() as $entry) $add($entry);

        $currentModules = array_map('strtolower', dmd_qs_module_ids($currentSession['modules'] ?? array()));
        $currentTypes = array_map('strtolower', dmd_qs_resource_types($currentSession['resources'] ?? array()));
        $results = array();

        foreach ($catalog as $entry) {
            $fieldValues = array(
                'title' => array($entry['title']),
                'tags' => $entry['tags'],
                'filename' => array($entry['filename'], $entry['original_name']),
                'summary' => array($entry['summary']),
                'resolution' => array($entry['resolution']),
                'modules' => $entry['module_ids'],
                'categories' => $entry['categories'],
            );
            $fieldWeights = array(
                'title' => 1.00,
                'tags' => 0.96,
                'filename' => 0.92,
                'summary' => 0.78,
                'resolution' => 0.78,
                'modules' => 0.66,
                'categories' => 0.58,
            );

            $fieldTokens = array();
            foreach ($fieldValues as $field => $values) $fieldTokens[$field] = dmd_qs_search_tokens($values);

            $coverage = 0.0;
            $matched = 0;
            foreach ($queryTokens as $needleToken) {
                $best = 0.0;
                foreach ($fieldTokens as $field => $tokens) {
                    foreach ($tokens as $candidateToken) {
                        $quality = dmd_qs_search_token_quality($needleToken, $candidateToken) * $fieldWeights[$field];
                        if ($quality > $best) $best = $quality;
                    }
                }
                if ($best >= 0.45) $matched++;
                $coverage += $best;
            }
            if ($matched === 0) continue;

            $score = 72.0 * ($coverage / max(1, count($queryTokens)));
            $foldTitle = dmd_qs_search_fold($entry['title']);
            $foldFilename = dmd_qs_search_fold($entry['filename'] . ' ' . $entry['original_name']);
            $foldTags = dmd_qs_search_fold(implode(' ', $entry['tags']));
            $foldSummary = dmd_qs_search_fold($entry['summary'] . ' ' . $entry['resolution']);
            if ($foldTitle !== '' && $queryFold === $foldTitle) $score += 24;
            elseif ($foldTitle !== '' && strpos($foldTitle, $queryFold) !== false) $score += 19;
            elseif ($foldTags !== '' && strpos($foldTags, $queryFold) !== false) $score += 16;
            elseif ($foldFilename !== '' && strpos($foldFilename, $queryFold) !== false) $score += 14;
            elseif ($foldSummary !== '' && strpos($foldSummary, $queryFold) !== false) $score += 10;

            $candidateModules = array_map('strtolower', (array)$entry['module_ids']);
            if ($currentModules && $candidateModules) {
                $intersection = count(array_intersect($currentModules, $candidateModules));
                $union = count(array_unique(array_merge($currentModules, $candidateModules)));
                if ($union > 0) $score += 6 * ($intersection / $union);
            }
            $candidateTypes = array_map('strtolower', (array)$entry['resource_types']);
            if ($currentTypes && $candidateTypes) {
                $intersection = count(array_intersect($currentTypes, $candidateTypes));
                $union = count(array_unique(array_merge($currentTypes, $candidateTypes)));
                if ($union > 0) $score += 4 * ($intersection / $union);
            }

            $label = trim((string)$entry['title']);
            if ($label === '') $label = trim((string)$entry['original_name']);
            if ($label === '') $label = (string)$entry['filename'];

            $results[] = array(
                'type' => 'procedure',
                'procedure' => $entry['filename'],
                'procedure_path' => $entry['relative_path'],
                'label' => $label,
                'score' => (int)round(min(100, $score)),
                'source_session_id' => (string)$entry['source_session_id'],
                'module_ids' => array_values($entry['module_ids']),
                'summary' => (string)$entry['summary'],
                'resolution' => (string)$entry['resolution'],
                'tags' => array_values($entry['tags']),
                'categories' => array_values($entry['categories']),
                'created_at' => (int)$entry['created_at'],
            );
        }

        usort($results, function ($a, $b) {
            if ((int)$a['score'] !== (int)$b['score']) return (int)$b['score'] <=> (int)$a['score'];
            if ((int)$a['created_at'] !== (int)$b['created_at']) return (int)$b['created_at'] <=> (int)$a['created_at'];
            return strnatcasecmp((string)$a['label'], (string)$b['label']);
        });

        return array_slice($results, 0, max(1, min(25, (int)$limit)));
    }
}

if (!function_exists('dmd_qs_suggest_procedures')) {
    /**
     * Retourne la mémoire utile à la Quick-Session courante.
     *
     * Types possibles :
     * - procedure : PDF lié/créé depuis une ancienne Quick-Session ;
     * - session   : ancienne Quick-Session similaire, même sans PDF.
     *
     * Le nom historique de la fonction est conservé pour compatibilité.
     */
    function dmd_qs_suggest_procedures($email, array $currentSession, $limit = 3, $query = '') {
        if (trim((string)$query) !== '') {
            return dmd_qs_search_procedures($email, $currentSession, $query, $limit);
        }
        $proceduresDir = dirname(__DIR__) . '/data/procedures/documents/';
        $suggestions = array();
        $currentSessionId = isset($currentSession['id']) ? (string)$currentSession['id'] : '';

        $resolveProcedure = function ($procedure) use ($proceduresDir) {
            $raw = str_replace('\\', '/', trim((string)$procedure));
            if ($raw === '' || strtolower(pathinfo($raw, PATHINFO_EXTENSION)) !== 'pdf') return '';

            $safeParts = array();
            foreach (explode('/', $raw) as $part) {
                $part = trim($part);
                if ($part === '' || $part === '.' || $part === '..') continue;
                $safeParts[] = basename($part);
            }
            if (!$safeParts) return '';
            $safe = implode('/', $safeParts);

            $candidates = array();
            if (strpos($safe, '/') !== false) {
                $candidates[] = $safe;
            } else {
                // Compatibilité avec les anciennes Quick-Sessions qui ne stockaient que le nom du PDF.
                $candidates[] = $safe;
                $candidates[] = 'quick-session/' . $safe;
                $candidates[] = 'interne/' . $safe;
                $candidates[] = 'partagees/' . $safe;
            }

            foreach ($candidates as $relative) {
                if (is_file($proceduresDir . $relative)) return $relative;
            }
            return '';
        };

        $addProcedureSuggestion = function ($procedure, $score, $sourceSessionId, $sourceTitle, array $metadata = array()) use (&$suggestions, $resolveProcedure) {
            $relativePath = $resolveProcedure($procedure);
            if ($relativePath === '') return;

            $displayName = basename($relativePath);
            $score = round((float)$score);
            $key = 'procedure:' . strtolower($relativePath);

            $candidate = array(
                'type' => 'procedure',
                'procedure' => $displayName,
                'procedure_path' => $relativePath,
                'label' => !empty($metadata['title']) ? (string)$metadata['title'] : ($sourceTitle !== '' ? (string)$sourceTitle : $displayName),
                'score' => $score,
                'source_session_id' => (string)$sourceSessionId,
                'source_title' => (string)$sourceTitle,
                'module_ids' => !empty($metadata['module_ids']) && is_array($metadata['module_ids']) ? array_values($metadata['module_ids']) : array(),
                'summary' => isset($metadata['summary']) ? (string)$metadata['summary'] : '',
                'resolution' => isset($metadata['resolution']) ? (string)$metadata['resolution'] : '',
                'tags' => isset($metadata['tags']) && is_array($metadata['tags']) ? array_values($metadata['tags']) : array()
            );

            if (!isset($suggestions[$key]) || $score > $suggestions[$key]['score']) {
                $suggestions[$key] = $candidate;
            } else {
                // Un passage par l'index global peut enrichir une suggestion déjà trouvée
                // dans la mémoire utilisateur avec les modules/résumé de la procédure.
                foreach (array('module_ids', 'summary', 'resolution', 'tags') as $field) {
                    if (!empty($candidate[$field])) {
                        $suggestions[$key][$field] = $candidate[$field];
                    }
                }
                if (!empty($metadata['title'])) {
                    $suggestions[$key]['label'] = (string)$metadata['title'];
                }
            }
        };

        $addSessionSuggestion = function (array $entry, $score) use (&$suggestions, $currentSessionId) {
            $sourceSessionId = isset($entry['session_id']) ? (string)$entry['session_id'] : '';
            if ($sourceSessionId === '' || $sourceSessionId === $currentSessionId) return;

            $filename = isset($entry['filename']) ? dmd_qs_safe_session_filename($entry['filename']) : '';
            if ($filename === '') return;

            $score = round((float)$score);
            $closedAt = isset($entry['closed_at']) ? (int)$entry['closed_at'] : 0;
            $title = trim((string)($entry['title'] ?? ''));
            $label = $title !== '' ? $title : 'Quick-Session précédente';

            $key = 'session:' . strtolower($sourceSessionId);
            if (!isset($suggestions[$key]) || $score > $suggestions[$key]['score']) {
                $suggestions[$key] = array(
                    'type' => 'session',
                    'label' => $label,
                    'score' => $score,
                    'source_session_id' => $sourceSessionId,
                    'source_title' => $title,
                    'source_filename' => $filename,
                    'source_closed_at' => $closedAt,
                    'source_modules' => isset($entry['module_ids']) && is_array($entry['module_ids'])
                        ? array_values($entry['module_ids'])
                        : array(),
                    'source_summary' => isset($entry['summary']) ? (string)$entry['summary'] : '',
                    'source_resolution' => isset($entry['resolution_note']) ? (string)$entry['resolution_note'] : ''
                );
            }
        };

        // 1) Mémoire historique propre à l'utilisateur.
        // La V2 de l'index contient TOUTES les Quick-Sessions résolues,
        // pas uniquement celles qui avaient déjà un PDF lié.
        $memory = dmd_qs_memory_index($email);
        if (!empty($memory['entries']) && is_array($memory['entries'])) {
            foreach ($memory['entries'] as $entry) {
                if (!is_array($entry)) continue;

                $score = dmd_qs_similarity_score($currentSession, $entry);
                if ($score < 45) continue;

                $hasValidProcedure = false;
                if (!empty($entry['procedures']) && is_array($entry['procedures'])) {
                    foreach ($entry['procedures'] as $procedure) {
                        $before = count($suggestions);
                        $addProcedureSuggestion(
                            $procedure,
                            $score,
                            isset($entry['session_id']) ? $entry['session_id'] : '',
                            isset($entry['title']) ? $entry['title'] : ''
                        );
                        if (count($suggestions) > $before) {
                            $hasValidProcedure = true;
                        }
                    }
                }

                // Le flux interactif Quick-Session ne propose que des documents exploitables.
                // Une ancienne session sans PDF reste disponible dans l'historique/admin,
                // mais n'est pas proposée ici : l'accepter créerait un workspace vide.
                if (!$hasValidProcedure) {
                    continue;
                }
            }
        }

        // 2) Index global des procédures créées depuis une Quick-Session.
        $procedureIndexFile = dirname(__DIR__) . '/data/secure/quick_session_procedures.json';
        $procedureIndex = dmd_qs_read_file($procedureIndexFile);
        if ($procedureIndex && !empty($procedureIndex['procedures']) && is_array($procedureIndex['procedures'])) {
            foreach ($procedureIndex['procedures'] as $procedureEntry) {
                if (!is_array($procedureEntry) || empty($procedureEntry['filename'])) continue;

                $past = array(
                    'module_ids' => isset($procedureEntry['module_ids']) && is_array($procedureEntry['module_ids']) ? $procedureEntry['module_ids'] : array(),
                    'resource_types' => isset($procedureEntry['resource_types']) && is_array($procedureEntry['resource_types']) ? $procedureEntry['resource_types'] : array(),
                    'tags' => isset($procedureEntry['tags']) && is_array($procedureEntry['tags']) ? $procedureEntry['tags'] : array(),
                    'title' => isset($procedureEntry['title']) ? (string)$procedureEntry['title'] : '',
                    'summary' => isset($procedureEntry['summary']) ? (string)$procedureEntry['summary'] : '',
                    'resolution' => isset($procedureEntry['resolution']) ? (string)$procedureEntry['resolution'] : '',
                    'filename' => isset($procedureEntry['filename']) ? (string)$procedureEntry['filename'] : '',
                    'procedure' => !empty($procedureEntry['relative_path']) ? (string)$procedureEntry['relative_path'] : (string)($procedureEntry['filename'] ?? '')
                );

                $score = dmd_qs_similarity_score($currentSession, $past);
                if ($score < 45) continue;

                $procedureRef = !empty($procedureEntry['relative_path']) ? $procedureEntry['relative_path'] : $procedureEntry['filename'];
                $addProcedureSuggestion(
                    $procedureRef,
                    $score,
                    isset($procedureEntry['source_session_id']) ? $procedureEntry['source_session_id'] : '',
                    isset($procedureEntry['title']) ? $procedureEntry['title'] : '',
                    $procedureEntry
                );
            }
        }

        uasort($suggestions, function ($a, $b) {
            if ((int)$a['score'] === (int)$b['score']) {
                // À score égal, une procédure directement exploitable passe avant une simple archive.
                if (($a['type'] ?? '') !== ($b['type'] ?? '')) {
                    return ($a['type'] ?? '') === 'procedure' ? -1 : 1;
                }
                return strcmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
            }
            return (int)$b['score'] <=> (int)$a['score'];
        });

        return array_slice(array_values($suggestions), 0, max(1, (int)$limit));
    }
}


/* =========================================================
   Pont event-driven DoMyDesk 1.2.0
   Les modules publient une activité via core/dmd_activity.php ; Quick-Session
   capture l'événement dans la requête courante sans scanner les logs.
   ========================================================= */
if (!function_exists('dmd_qs_apply_activity_event')) {
    function dmd_qs_apply_activity_event($email, $event) {
        $dir = dmd_qs_user_dir($email, true);
        if ($dir === '' || !is_dir($dir)) return false;
        $lock = dmd_qs_acquire_lock($email);
        if (!$lock) return false;
        $ok = false;
        {
            $active = dmd_qs_get_active($email);
            if ($active && !empty($active['_file'])) {
                $file = $active['_file'];
                unset($active['_file'], $active['_filename']);
                $active = dmd_qs_normalize_session($active, $file);

                $resource = isset($event['resource']) && is_array($event['resource'])
                    ? dmd_qs_sanitize_resource(array(
                        'type' => isset($event['resource']['type']) ? $event['resource']['type'] : 'object',
                        'id' => isset($event['resource']['id']) ? $event['resource']['id'] : '',
                        'label' => isset($event['resource']['label']) ? $event['resource']['label'] : (isset($event['resource']['name']) ? $event['resource']['name'] : ''),
                        'source' => isset($event['resource']['source']) && $event['resource']['source'] !== '' ? $event['resource']['source'] : (isset($event['module']) ? $event['module'] : ''),
                        'tags' => isset($event['resource']['tags']) ? $event['resource']['tags'] : array(),
                    ))
                    : null;

                if ($resource) {
                    $key = strtolower($resource['type'] . '|' . $resource['source'] . '|' . $resource['id']);
                    $exists = false;
                    foreach ($active['resources'] as $existing) {
                        $existingKey = strtolower((string)($existing['type'] ?? '') . '|' . (string)($existing['source'] ?? '') . '|' . (string)($existing['id'] ?? ''));
                        if ($existingKey === $key) { $exists = true; break; }
                    }
                    if (!$exists) {
                        $active['resources'][] = $resource;
                        dmd_qs_append_timeline($active, dmd_qs_timeline_entry(
                            $resource['source'] !== '' ? $resource['source'] : 'core',
                            'resource_added',
                            'Ressource ajoutée à la Quick-Session',
                            $resource['label'],
                            'success',
                            $resource['type']
                        ));
                    }
                }

                dmd_qs_append_timeline($active, dmd_qs_timeline_entry(
                    (string)($event['module'] ?? 'core'),
                    (string)($event['action'] ?? 'activity'),
                    (string)($event['label'] ?? ($event['action'] ?? 'Activité')),
                    (string)($event['target'] ?? ''),
                    (string)($event['status'] ?? ''),
                    (string)($event['details'] ?? ''),
                    isset($event['timestamp']) ? (int)$event['timestamp'] : null
                ));
                $active['updated_at'] = time();
                $active['updated_at_iso'] = date('c', $active['updated_at']);
                $ok = dmd_qs_write_file($file, $active);
            }
        }
        dmd_qs_release_lock($lock);
        return $ok;
    }
}

if (!function_exists('dmd_qs_record_activity_event')) {
    function dmd_qs_record_activity_event($event) {
        if (!is_array($event) || empty($event['user']) || empty($event['module']) || empty($event['action'])) return false;
        return dmd_qs_apply_activity_event((string)$event['user'], $event);
    }
}

if (function_exists('dmd_event_on') && empty($GLOBALS['DMD_QS_ACTIVITY_LISTENER_REGISTERED'])) {
    $GLOBALS['DMD_QS_ACTIVITY_LISTENER_REGISTERED'] = true;
    dmd_event_on('dmd.activity', 'dmd_qs_record_activity_event');
}
