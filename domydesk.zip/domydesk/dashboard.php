<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
require_once __DIR__ . '/core/dmd_security.php';
dmd_security_session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_ui_features.php';
require_once __DIR__ . '/Quick-Session/dmd_quick_session.php';

if (empty($_SESSION['user']['email'])) {
    header('Location: login.php');
    exit;
}

$email   = $_SESSION['user']['email'];
$userDir = __DIR__ . "/users/profiles/$email";
$quickSessionCsrf = dmd_csrf_token('quick-session');
$actionHubCsrf = dmd_csrf_token('actionhub');
$dmdUiSettings = dmd_ui_site_settings();
$dmdQuickSessionTool = dmd_ui_effective_tool($email, 'quick_session', $dmdUiSettings);
$dmdActionHubTool = dmd_ui_effective_tool($email, 'actionhub', $dmdUiSettings);
$dmdQuickSessionUserEnabled = is_array($dmdQuickSessionTool) && !empty($dmdQuickSessionTool['visible']);
$dmdActionHubUserEnabled = is_array($dmdActionHubTool) && !empty($dmdActionHubTool['visible']);
$dmdQuickSessionInHeader = $dmdQuickSessionUserEnabled && (($dmdQuickSessionTool['location'] ?? '') === 'header');
$dmdActionHubInHeader = $dmdActionHubUserEnabled && (($dmdActionHubTool['location'] ?? '') === 'header');
$dmdShowHeaderCoreTools = $dmdQuickSessionInHeader || $dmdActionHubInHeader;

if (!is_dir($userDir)) {
    @mkdir($userDir, 0775, true);
}

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE) ? $data : $fallback;
}

function json_write(string $file, $data): void {
    file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
    );
}

function sanitize_name(string $s): string {
    $s = preg_replace('/[^a-zA-Z0-9_-]/', '_', $s);
    return $s === '' ? 'dashboard' : $s;
}

function dmd_urlencode_path(string $path): string {
    $parts = array_filter(explode('/', str_replace('\\', '/', $path)), 'strlen');
    return implode('/', array_map('rawurlencode', $parts));
}
$theme = 'default';

$themeJson = $userDir . "/theme.json";

if (is_file($themeJson)) {
    $themeData = json_read($themeJson, []);

    if (
        !empty($themeData['theme']) &&
        is_file(__DIR__ . "/theme/" . basename($themeData['theme']) . "/style.css")
    ) {
        $theme = basename($themeData['theme']);
    }
} else {
    $profileFile = dmd_profile_path($email, true);

    if (is_file($profileFile)) {
        $profileData = json_read($profileFile, []);

        if (
            !empty($profileData['theme']) &&
            is_file(__DIR__ . "/theme/" . basename($profileData['theme']) . "/style.css")
        ) {
            $theme = basename($profileData['theme']);
        }
    }
}


$listFile = "$userDir/dashboards.json";

if (!file_exists($listFile)) {
    json_write($listFile, ['dashboard']);
}

$dashboards = json_read($listFile, ['dashboard']);
$dashboards = array_values(array_unique(array_map('sanitize_name', (array)$dashboards)));

if (!$dashboards) {
    $dashboards = ['dashboard'];
    json_write($listFile, $dashboards);
}

$quickSessionRequested = $dmdQuickSessionUserEnabled && !empty($_GET['quick_session']);

if ($quickSessionRequested && isset($_GET['from'])) {
    $requested = sanitize_name($_GET['from']);
} else {
    $requested = isset($_GET['dashboard']) ? sanitize_name($_GET['dashboard']) : $dashboards[0];
}

$currentDashboard = in_array($requested, $dashboards, true) ? $requested : $dashboards[0];

$dashboardFile = "$userDir/$currentDashboard.json";

if (!file_exists($dashboardFile)) {
    json_write($dashboardFile, []);
}

/* ==========================================================
   Quick-Session Core
   ========================================================== */
$quickSessionActiveData = dmd_qs_get_active($email);
$quickSessionActive = is_array($quickSessionActiveData);
$isQuickSessionView = $quickSessionRequested && $quickSessionActive;
$quickSessionStartedAt = $quickSessionActive ? (int)($quickSessionActiveData['started_at'] ?? 0) : 0;
$quickSessionModules = $quickSessionActive && !empty($quickSessionActiveData['modules']) && is_array($quickSessionActiveData['modules'])
    ? $quickSessionActiveData['modules']
    : [];
$quickSessionWorkflow = $quickSessionActive && !empty($quickSessionActiveData['workflow']) && is_array($quickSessionActiveData['workflow'])
    ? $quickSessionActiveData['workflow']
    : [];
$quickSessionPhase = $quickSessionActive ? (string)($quickSessionWorkflow['phase'] ?? 'selection') : 'inactive';
$quickSessionAccepted = $quickSessionActive && isset($quickSessionWorkflow['accepted']) && is_array($quickSessionWorkflow['accepted'])
    ? $quickSessionWorkflow['accepted']
    : null;
$quickSessionTags = $quickSessionActive && !empty($quickSessionActiveData['tags']) && is_array($quickSessionActiveData['tags'])
    ? array_values($quickSessionActiveData['tags'])
    : [];
$quickSessionOriginDashboard = $quickSessionActive
    ? sanitize_name((string)($quickSessionWorkflow['origin_dashboard'] ?? $currentDashboard))
    : $currentDashboard;

if (!in_array($quickSessionOriginDashboard, $dashboards, true)) {
    $quickSessionOriginDashboard = $currentDashboard;
}

if ($quickSessionRequested && !$quickSessionActive) {
    header('Location: dashboard.php?dashboard=' . rawurlencode($currentDashboard));
    exit;
}

// Une reprise de Quick-Session revient toujours sur le dashboard depuis lequel elle a été lancée.
if ($isQuickSessionView && $currentDashboard !== $quickSessionOriginDashboard) {
    $currentDashboard = $quickSessionOriginDashboard;
    $dashboardFile = "$userDir/$currentDashboard.json";
    if (!file_exists($dashboardFile)) {
        json_write($dashboardFile, []);
    }
}

$quickSessionWorkspaceActive = $isQuickSessionView && $quickSessionPhase === 'accepted';

// Ne jamais injecter dans le workspace Quick-Session un module que le profil ne peut pas utiliser.
if ($quickSessionModules) {
    $qsAllowedMap = dmd_effective_modules($email, true);
    $quickSessionModules = array_values(array_filter($quickSessionModules, function ($module) use ($qsAllowedMap) {
        return is_array($module) && !empty($module['id']) && isset($qsAllowedMap[(string)$module['id']]);
    }));
}

/* ==========================================================
   Modules disponibles sur le dashboard
   ========================================================== */

$availableModules = array();

$hiddenDashboardModules = array(
    'savev.1'
);

$effectiveModules = dmd_effective_modules($email, true);

foreach ($effectiveModules as $mid => $m) {
    $mid = trim((string)$mid);

    if ($mid === '' || empty($m['name'])) {
        continue;
    }

    if (in_array($mid, $hiddenDashboardModules, true)) {
        continue;
    }

    $dashboardValue = isset($m['dashboard']) ? $m['dashboard'] : true;

    if (
        $dashboardValue === false ||
        $dashboardValue === 0 ||
        $dashboardValue === '0' ||
        strtolower((string)$dashboardValue) === 'false' ||
        strtolower((string)$dashboardValue) === 'no'
    ) {
        continue;
    }

    $availableModules[$mid] = $m['name'];
}

/* ==========================================================
   Barre Dashboard intégrée au Header
   ========================================================== */
ob_start();
?>
<div class="dmd-dashboard-controls" aria-label="Commandes du dashboard">
    <!-- 1. Liste des dashboards -->
    <span class="dmd-header-group dmd-header-group-dashboard-list">
        <select
            id="dashSelect"
            class="dmd-header-select dmd-header-dashboard-select"
            title="Changer de dashboard"
            aria-label="Changer de dashboard"
            onchange="location.href='?dashboard=' + encodeURIComponent(this.value)"
        >
            <?php foreach ($dashboards as $d): ?>
                <option value="<?= htmlspecialchars($d, ENT_QUOTES, 'UTF-8') ?>" <?= $d === $currentDashboard ? 'selected' : '' ?>>
                    <?= htmlspecialchars($d, ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>
    </span>

    <span class="dmd-header-separator" aria-hidden="true"></span>

    <span class="dmd-header-group dmd-header-group-dashboard-actions">
        <button class="dmd-header-action add" type="button" onclick="createDash()" title="Nouveau dashboard" aria-label="Nouveau dashboard">＋</button>
        <button class="dmd-header-action rename" type="button" onclick="renameDash()" title="Renommer le dashboard" aria-label="Renommer le dashboard">✏️</button>
        <button class="dmd-header-action delete" type="button" onclick="deleteDash()" title="Supprimer le dashboard" aria-label="Supprimer le dashboard">🗑️</button>
    </span>

    <?php if ($dmdShowHeaderCoreTools): ?>
        <span class="dmd-header-separator" aria-hidden="true"></span>

        <!-- 3. Outils rapides DoMyDesk -->
        <span class="dmd-header-group dmd-header-group-core-tools">
            <?php if ($dmdQuickSessionInHeader): ?>
                <button
                    id="quickSessionBtn"
                    class="dmd-header-action dmd-header-quick-session<?= $quickSessionActive ? ' is-active' : '' ?>"
                    type="button"
                    title="<?= $quickSessionActive ? 'Ouvrir la Quick-Session active' : 'Démarrer une Quick-Session' ?>"
                    aria-label="<?= $quickSessionActive ? 'Ouvrir la Quick-Session active' : 'Démarrer une Quick-Session' ?>"
                >
                    <span aria-hidden="true"><?= htmlspecialchars((string)($dmdQuickSessionTool['icon'] ?? '🚨'), ENT_QUOTES, 'UTF-8') ?></span>
                    <span id="quickSessionTimer" class="dmd-quick-session-timer<?= $quickSessionActive ? '' : ' is-hidden' ?>">00:00:00</span>
                </button>
            <?php endif; ?>

            <?php if ($dmdActionHubInHeader): ?>
                <button
                    id="actionHubBtn"
                    class="dmd-header-action dmd-header-actionhub"
                    type="button"
                    title="Ouvrir ActionHub"
                    aria-label="Ouvrir ActionHub"
                    data-dmd-action-hub-global="1"
                ><?= htmlspecialchars((string)($dmdActionHubTool['icon'] ?? '⚡'), ENT_QUOTES, 'UTF-8') ?></button>
            <?php endif; ?>

            <button
                id="dmdCoreHelpBtn"
                class="dmd-header-action dmd-header-help"
                type="button"
                title="Aide des outils rapides"
                aria-label="Aide des outils rapides"
            >?</button>
        </span>
    <?php endif; ?>

    <span class="dmd-header-separator" aria-hidden="true"></span>

    <span class="dmd-header-group dmd-header-group-module-tools">
        <select
            id="addModuleSelect"
            class="dmd-header-select dmd-header-module-select"
            title="Ajouter un module à ce dashboard"
            aria-label="Ajouter un module à ce dashboard"
        >
            <option value="">＋ Module</option>
            <?php foreach ($availableModules as $id => $name): ?>
                <option value="<?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button
            id="resetBtn"
            class="dmd-header-action"
            type="button"
            title="Réinitialiser le dashboard"
            aria-label="Réinitialiser le dashboard"
        >↺</button>
    </span>

    <span class="dmd-header-separator dmd-header-view-separator" aria-hidden="true"></span>

    <span class="dmd-header-group dmd-header-group-view">
        <button
            id="dmdViewModeBtn"
            class="dmd-header-action dmd-header-view-mode"
            type="button"
            title="Choisir la vue Mobile / Bureau"
            aria-label="Choisir la vue Mobile / Bureau"
        >🖥️</button>
    </span>
</div>
<?php
$dmdHeaderDashboardControls = ob_get_clean();
?>
<!DOCTYPE html>
<html lang="fr" class="dmd-dashboard-page<?= $isQuickSessionView ? ' dmd-quick-session-view' : '' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.8">

    <title>Bureau Numérique</title>

    <script>
    (function () {
        try {
            const saved = localStorage.getItem('dmd:view-mode');
            const mode = saved === 'mobile' ? 'mobile' : 'desktop';
            document.documentElement.classList.add(mode === 'mobile' ? 'dmd-view-mobile' : 'dmd-view-desktop');
            document.documentElement.dataset.dmdViewMode = mode;
        } catch (e) {
            document.documentElement.classList.add('dmd-view-desktop');
            document.documentElement.dataset.dmdViewMode = 'desktop';
        }
    })();
    </script>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <link rel="stylesheet" href="core/dmd_workspace.css?v=<?= (int)@filemtime(__DIR__ . '/core/dmd_workspace.css') ?>">
    <?php if ($dmdActionHubUserEnabled): ?>
        <link rel="stylesheet" href="ActionHub/action-hub.css?v=<?= (int)@filemtime(__DIR__ . '/ActionHub/action-hub.css') ?>">
    <?php endif; ?>
    <?php if ($dmdQuickSessionUserEnabled): ?>
        <link rel="stylesheet" href="Quick-Session/quick-session.css?v=<?= (int)@filemtime(__DIR__ . '/Quick-Session/quick-session.css') ?>">
    <?php endif; ?>

    <script src="data/interact.js?v=<?= (int)@filemtime(__DIR__ . '/data/interact.js') ?>"></script>
    <script src="core/dmd_workspace.js?v=<?= (int)@filemtime(__DIR__ . '/core/dmd_workspace.js') ?>" defer></script>
    <?php if ($dmdActionHubUserEnabled): ?>
        <script src="ActionHub/action-hub.js?v=<?= (int)@filemtime(__DIR__ . '/ActionHub/action-hub.js') ?>" defer></script>
    <?php endif; ?>
    <?php if ($dmdQuickSessionUserEnabled): ?>
        <script src="Quick-Session/quick-session.js?v=<?= (int)@filemtime(__DIR__ . '/Quick-Session/quick-session.js') ?>" defer></script>
    <?php endif; ?>
</head>

<body>
<div class="wrapper">

    <?php include 'header.php'; ?>

    <main>
        <div class="popup" id="confirmPopup">
            <p>Confirmer la réinitialisation ?</p>
            <button type="button" onclick="confirmReset()">Oui</button>
            <button type="button" onclick="hidePopup()">Non</button>
        </div>

        <div class="popup" id="dmdCoreHelpPopup" hidden aria-labelledby="dmdCoreHelpTitle">
            <p id="dmdCoreHelpTitle"><strong>Aide DoMyDesk</strong></p>

            <?php if ($dmdQuickSessionUserEnabled): ?>
            <p>
                <strong><?= htmlspecialchars((string)($dmdQuickSessionTool['icon'] ?? '🚨'), ENT_QUOTES, 'UTF-8') ?> Quick-Session</strong><br>
                Démarre une intervention rapide, conserve le temps écoulé et permet de travailler
                temporairement avec les modules et procédures utiles sans modifier le dashboard normal.
            </p>
            <?php endif; ?>

            <?php if ($dmdActionHubUserEnabled): ?>
            <p>
                <strong><?= htmlspecialchars((string)($dmdActionHubTool['icon'] ?? '⚡'), ENT_QUOTES, 'UTF-8') ?> ActionHub</strong><br>
                Centralise les actions proposées par les modules et leurs ressources, selon les droits
                de l'utilisateur et le contexte courant.
            </p>
            <?php endif; ?>

            <button type="button" id="dmdCoreHelpClose">Fermer</button>
        </div>

        <?php if ($isQuickSessionView): ?>
            <div class="dmd-quick-session-tools">
                <div class="dmd-quick-session-state" aria-live="polite">
                    <strong>🚨 Quick-Session</strong>
                    <span><?= $quickSessionWorkspaceActive ? 'Intervention temporaire' : 'Sélection de la procédure' ?></span>
                </div>
                <div class="dmd-quick-session-resolve">
                    <button id="quickSessionResolveBtn" type="button" title="Archiver cette Quick-Session comme résolue">✅ Résolu</button>
                </div>
            </div>
            <div id="dmdQuickSessionRoot" aria-live="polite"></div>
        <?php endif; ?>

        <div id="dashboard"></div>
    </main>
</div>

<script>
const currentDashboard = <?= json_encode($currentDashboard, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const currentUserEmail = <?= json_encode($email, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const dashboardAllowedModules = <?= json_encode(array_keys($availableModules), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const dashboardModuleNames = <?= json_encode($availableModules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

function dashboardModuleDisplayName(id, fallback = '') {
    const name = dashboardModuleNames[id];
    if (typeof name === 'string' && name.trim() !== '') {
        return name.trim();
    }

    if (typeof fallback === 'string' && fallback.trim() !== '') {
        return fallback.trim();
    }

    return id;
}

function dashboardEscapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, ch => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#039;',
        '"': '&quot;'
    }[ch]));
}


const quickSessionActive = <?= $quickSessionActive ? 'true' : 'false' ?>;
const quickSessionView = <?= $isQuickSessionView ? 'true' : 'false' ?>;
const quickSessionWorkspaceActive = <?= $quickSessionWorkspaceActive ? 'true' : 'false' ?>;
const quickSessionStartedAt = <?= (int)$quickSessionStartedAt ?>;
const quickSessionInitialModules = <?= json_encode($quickSessionModules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const quickSessionOriginDashboard = <?= json_encode($quickSessionOriginDashboard, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const workspaceGeometryScope = quickSessionWorkspaceActive ? 'quick-session' : currentDashboard;

window.DMDQuickSessionConfig = {
    active: quickSessionActive,
    view: quickSessionView,
    workspaceActive: quickSessionWorkspaceActive,
    phase: <?= json_encode($quickSessionPhase, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
    startedAt: quickSessionStartedAt,
    originDashboard: quickSessionOriginDashboard,
    tags: <?= json_encode($quickSessionTags, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
    accepted: <?= json_encode($quickSessionAccepted, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
    apiUrl: 'Quick-Session/api.php',
    csrfToken: <?= json_encode($quickSessionCsrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
    procedureBaseUrl: 'data/procedures/documents/',
    allowedModules: dashboardAllowedModules,
    moduleNames: dashboardModuleNames
};
let highestModuleZIndex = 10;
let highestWorkspaceZIndex = 10;

function bringWorkspaceItemToFront(itemEl) {
    if (!itemEl) {
        return;
    }

    document.querySelectorAll('#dashboard > .module, #dashboard .dmd-qs-window').forEach(el => {
        const z = parseInt(el.style.zIndex || '0', 10);
        if (Number.isFinite(z)) {
            highestWorkspaceZIndex = Math.max(highestWorkspaceZIndex, z);
        }
    });

    highestWorkspaceZIndex++;
    highestModuleZIndex = Math.max(highestModuleZIndex, highestWorkspaceZIndex);
    itemEl.style.zIndex = highestWorkspaceZIndex;
}

window.DMDBringWorkspaceItemToFront = bringWorkspaceItemToFront;

function dashboardModules() {
    const dash = document.getElementById('dashboard');
    if (!dash) return [];
    return Array.from(dash.children).filter(el => el.classList && el.classList.contains('module'));
}

function dashboardModuleFromNode(node) {
    if (!node || !node.closest) return null;
    const moduleEl = node.closest('.module');
    if (!moduleEl) return null;
    const dash = document.getElementById('dashboard');
    return dash && moduleEl.parentElement === dash ? moduleEl : null;
}

/* ==========================================================
   Sécurité d'ouverture des modules
   - Une seule instance d'un même module
   - Aucun chevauchement automatique à l'ouverture
   ========================================================== */

function dashboardFindOpenModule(moduleId) {
    const id = String(moduleId || '');

    return dashboardModules().find(moduleEl => {
        return moduleEl.dataset && String(moduleEl.dataset.id || '') === id;
    }) || null;
}

function dashboardModuleRect(moduleEl) {
    const left = Math.max(0, parseFloat(moduleEl.style.left) || 0);
    const top = Math.max(0, parseFloat(moduleEl.style.top) || 0);
    const width = Math.max(
        120,
        parseFloat(moduleEl.style.width) || moduleEl.offsetWidth || 280
    );
    const height = Math.max(
        90,
        parseFloat(moduleEl.style.height) || moduleEl.offsetHeight || 280
    );

    return {
        left,
        top,
        right: left + width,
        bottom: top + height,
        width,
        height
    };
}

function dashboardRectsOverlap(a, b, gap = 12) {
    return !(
        a.right + gap <= b.left ||
        a.left >= b.right + gap ||
        a.bottom + gap <= b.top ||
        a.top >= b.bottom + gap
    );
}

function dashboardFindFreeModulePosition(moduleEl, preferredX, preferredY) {
    const dash = document.getElementById('dashboard');

    if (!dash || !moduleEl) {
        return {
            x: Math.max(0, Number(preferredX) || 0),
            y: Math.max(0, Number(preferredY) || 0)
        };
    }

    // En vue mobile, l'ordre est géré par le workspace et non par les coordonnées.
    if (window.DMDWorkspace && window.DMDWorkspace.isMobileView()) {
        return {
            x: Math.max(0, Number(preferredX) || 0),
            y: Math.max(0, Number(preferredY) || 0)
        };
    }

    const gap = 12;
    const ownRect = dashboardModuleRect(moduleEl);
    const width = ownRect.width;
    const height = ownRect.height;
    const occupied = dashboardModules()
        .filter(el => el !== moduleEl)
        .map(dashboardModuleRect);

    const makeRect = (x, y) => ({
        left: Math.max(0, x),
        top: Math.max(0, y),
        right: Math.max(0, x) + width,
        bottom: Math.max(0, y) + height,
        width,
        height
    });

    const isFree = (x, y) => {
        const candidate = makeRect(x, y);
        return occupied.every(rect => !dashboardRectsOverlap(candidate, rect, gap));
    };

    const startX = Math.max(0, Number(preferredX) || 0);
    const startY = Math.max(0, Number(preferredY) || 0);

    // 1. Position souhaitée/restaurée.
    if (isFree(startX, startY)) {
        return { x: startX, y: startY };
    }

    // 2. Cherche d'abord autour des modules déjà présents.
    const candidates = [];

    occupied.forEach(rect => {
        candidates.push(
            { x: rect.right + gap, y: rect.top },
            { x: rect.left, y: rect.bottom + gap }
        );
    });

    candidates.sort((a, b) => {
        const da = Math.abs(a.x - startX) + Math.abs(a.y - startY);
        const db = Math.abs(b.x - startX) + Math.abs(b.y - startY);
        return da - db;
    });

    for (const candidate of candidates) {
        if (isFree(candidate.x, candidate.y)) {
            return candidate;
        }
    }

    // 3. Solution garantie : sous le module le plus bas.
    const maxBottom = occupied.reduce((max, rect) => Math.max(max, rect.bottom), 0);

    return {
        x: startX,
        y: Math.max(startY, maxBottom + gap)
    };
}

function dashboardPlaceModuleWithoutOverlap(moduleEl, preferredX, preferredY) {
    if (!moduleEl) {
        return;
    }

    const position = dashboardFindFreeModulePosition(
        moduleEl,
        preferredX,
        preferredY
    );

    moduleEl.style.left = Math.max(0, Math.round(position.x)) + 'px';
    moduleEl.style.top = Math.max(0, Math.round(position.y)) + 'px';
}

function dashboardFocusExistingModule(moduleEl) {
    if (!moduleEl) {
        return;
    }

    bringModuleToFront(moduleEl);

    moduleEl.classList.add('dmd-module-already-open');
    window.setTimeout(() => {
        moduleEl.classList.remove('dmd-module-already-open');
    }, 900);

    try {
        moduleEl.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'nearest'
        });
    } catch (e) {}
}

function bringModuleToFront(moduleEl) {
    bringWorkspaceItemToFront(moduleEl);
}

document.addEventListener('pointerdown', function (e) {
    const moduleEl = dashboardModuleFromNode(e.target);

    if (moduleEl) {
        bringModuleToFront(moduleEl);
    }
}, true);

function expandCanvasLT() {
    const ws = document.getElementById('dashboard');
    if (!ws) {
        return;
    }

    const mods = dashboardModules();
    const quickSessionWindows = Array.from(ws.querySelectorAll(
        '.dmd-qs-overlay[data-dmd-qs-host="workspace"].is-open .dmd-qs-window'
    ));
    const managedWindows = Array.from(ws.querySelectorAll('.dmd-managed-window')).filter(el => {
        if (el.hidden) return false;
        const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
        return !style || (style.display !== 'none' && style.visibility !== 'hidden');
    });
    const workspaceItems = Array.from(new Set([...mods, ...quickSessionWindows, ...managedWindows]));
    if (window.DMDWorkspace && window.DMDWorkspace.isMobileView()) {
        ws.classList.toggle('empty', workspaceItems.length === 0);
        return;
    }
    ws.classList.toggle('empty', workspaceItems.length === 0);

    if (workspaceItems.length === 0) {
        ws.scrollTo(0, 0);
    }
}
window.DMDExpandDashboardCanvas = expandCanvasLT;

window.addEventListener('resize', () => {
    window.requestAnimationFrame(expandCanvasLT);
});

function changeShape(sel) {
    const m = sel.closest('.module');

    if (!m) {
        return;
    }

    m.classList.remove('square', 'rounded', 'circle');
    m.classList.add(sel.value);

    saveDashboard();
}

document.addEventListener('pointerdown', function (e) {
    const handle = e.target.closest('.dmd-module-drag-handle');
    if (handle) {
        handle.style.cursor = 'grabbing';
    }
}, true);

function dmdResetModuleDragCursor() {
    document.querySelectorAll('.dmd-module-drag-handle').forEach(handle => {
        handle.style.cursor = 'grab';
    });
}

document.addEventListener('pointerup', dmdResetModuleDragCursor, true);
document.addEventListener('pointercancel', dmdResetModuleDragCursor, true);

function moduleMinimumSize(el) {
    const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
    const cssMinWidth = style ? parseFloat(style.minWidth) : NaN;
    const cssMinHeight = style ? parseFloat(style.minHeight) : NaN;
    const dataMinWidth = parseFloat(el.dataset.dmdMinWidth || '');
    const dataMinHeight = parseFloat(el.dataset.dmdMinHeight || '');

    return {
        width: Math.max(120, Number.isFinite(dataMinWidth) ? dataMinWidth : 0, Number.isFinite(cssMinWidth) ? cssMinWidth : 0),
        height: Math.max(90, Number.isFinite(dataMinHeight) ? dataMinHeight : 0, Number.isFinite(cssMinHeight) ? cssMinHeight : 0)
    };
}

function enableInteract(el) {
    if (typeof interact !== 'function') {
        return;
    }

    try {
        interact(el).unset();
    } catch (e) {}

    if (window.DMDWorkspace && window.DMDWorkspace.isMobileView()) {
        return;
    }

    interact(el)
        .draggable({
            allowFrom: '.dmd-module-drag-handle',
            ignoreFrom: 'button, select, input, textarea, a, .module-content, .resize-handle',
            listeners: {
                start(e) {
                    e.target.classList.add('dmd-dragging');
                    bringModuleToFront(e.target);
                },
                move(e) {
                    const t = e.target;

                    const x = Math.max(0, (parseFloat(t.style.left) || 0) + e.dx);
                    const y = Math.max(0, (parseFloat(t.style.top) || 0) + e.dy);

                    t.style.left = x + 'px';
                    t.style.top  = y + 'px';

                    expandCanvasLT();
                },
                end(e) {
                    e.target.classList.remove('dmd-dragging');
                    if (window.DMDWorkspace) {
                        window.DMDWorkspace.rememberModuleGeometry(e.target, workspaceGeometryScope);
                    }
                    saveDashboard();
                }
            }
        })
        .resizable({
            edges: {
                left: false,
                top: false,
                right: '.resize-handle',
                bottom: '.resize-handle'
            },
            listeners: {
                start(e) {
                    e.target.classList.add('dmd-resizing');
                    bringModuleToFront(e.target);
                },
                move(e) {
                    const t = e.target;
                    const min = moduleMinimumSize(t);
                    const x = Math.max(0, parseFloat(t.style.left) || 0);
                    const y = Math.max(0, parseFloat(t.style.top) || 0);

                    t.style.width  = Math.max(min.width, e.rect.width) + 'px';
                    t.style.height = Math.max(min.height, e.rect.height) + 'px';
                    t.style.left   = Math.max(0, x + e.deltaRect.left) + 'px';
                    t.style.top    = Math.max(0, y + e.deltaRect.top) + 'px';

                    expandCanvasLT();
                },
                end(e) {
                    e.target.classList.remove('dmd-resizing');
                    if (window.DMDWorkspace) {
                        window.DMDWorkspace.rememberModuleGeometry(e.target, workspaceGeometryScope);
                    }
                    saveDashboard();
                }
            }
        });
}

function loadModuleContent(modEl, id) {
    fetch(`modules/${encodeURIComponent(id)}/${encodeURIComponent(id)}.php`, {
        cache: 'no-store'
    })
        .then(r => r.text())
        .then(html => {
            const container = modEl.querySelector('.module-content');

            if (!container) {
                return;
            }

            container.innerHTML = html;

            container.querySelectorAll('script').forEach(oldScript => {
                const s = document.createElement('script');

                if (oldScript.src) {
                    s.src = oldScript.src;
                } else {
                    s.textContent = oldScript.textContent;
                }

                container.appendChild(s);
            });

            if (window.DMDActionHub) {
                window.DMDActionHub.decorate(container);
            }
        })
        .catch(err => console.error(`[${id}]`, err));
}

let dashboardSaveChain = Promise.resolve();

function saveDashboard() {
    const mods = dashboardModules().filter(m => m.dataset && m.dataset.id).map(m => {
        const shape = m.classList.contains('rounded')
            ? 'rounded'
            : (m.classList.contains('circle') ? 'circle' : 'square');

        const savedModule = {
            id: m.dataset.id,
            title: m.querySelector('.module-title')?.textContent || m.dataset.id,
            shape: shape,
            x: Math.max(0, Math.round(parseFloat(m.style.left) || 0)),
            y: Math.max(0, Math.round(parseFloat(m.style.top) || 0)),
            width: Math.max(120, Math.round(parseFloat(m.style.width) || m.offsetWidth || 200)),
            height: Math.max(90, Math.round(parseFloat(m.style.height) || m.offsetHeight || 200))
        };
        if (!quickSessionWorkspaceActive) {
            savedModule.content = m.querySelector('.module-content')?.textContent || '';
        }

        return savedModule;
    });

    const saveUrl = quickSessionWorkspaceActive
        ? 'users/save_dashboard.php?quick_session=1'
        : 'users/save_dashboard.php?dashboard=' + encodeURIComponent(currentDashboard);

    const requestHeaders = { 'Content-Type': 'application/json' };
    if (quickSessionWorkspaceActive) {
        requestHeaders['X-DMD-CSRF'] = <?= json_encode($quickSessionCsrf, JSON_UNESCAPED_SLASHES) ?>;
    }

    const request = dashboardSaveChain
        .catch(() => {})
        .then(() => fetch(saveUrl, {
            method: 'POST',
            headers: requestHeaders,
            cache: 'no-store',
            credentials: 'same-origin',
            body: JSON.stringify(mods)
        }))
        .then(r => {
            if (!r.ok) {
                throw new Error('save_failed');
            }
            return r;
        })
        .catch(err => {
            console.error('Erreur sauvegarde dashboard :', err);
            throw err;
        });
    dashboardSaveChain = request.catch(() => {});

    expandCanvasLT();
    return request;
}

function closeModule(btn) {
    const m = btn && btn.classList && btn.classList.contains('module') && btn.parentElement === document.getElementById('dashboard')
        ? btn
        : dashboardModuleFromNode(btn);

    if (!m) {
        return;
    }

    if (window.DMDWorkspace) {
        window.DMDWorkspace.rememberModuleGeometry(m, workspaceGeometryScope);
    }

    m.remove();

    expandCanvasLT();
    saveDashboard();
}

document.addEventListener('click', e => {
    if (e.target.classList.contains('module-close')) {
        closeModule(e.target);
    }
});

document.addEventListener('dmd:module-close', e => {
    const moduleEl = dashboardModuleFromNode(e.target);
    if (moduleEl) {
        closeModule(moduleEl);
    }
});

document.addEventListener('dmd:module-refresh', e => {
    const moduleEl = dashboardModuleFromNode(e.target);
    if (moduleEl && moduleEl.dataset.id) {
        loadModuleContent(moduleEl, moduleEl.dataset.id);
    }
});

document.addEventListener('dmd:module-move-request', e => {
    const moduleEl = dashboardModuleFromNode(e.target);
    if (!moduleEl) {
        return;
    }

    bringModuleToFront(moduleEl);
    moduleEl.classList.add('dmd-move-ready');
    window.setTimeout(() => moduleEl.classList.remove('dmd-move-ready'), 1800);
});

document.getElementById('addModuleSelect').addEventListener('change', async function () {
    const id = this.value;

    if (!id) {
        return;
    }

    // Sécurité : un même module ne peut exister qu'une seule fois.
    const existingModule = dashboardFindOpenModule(id);

    if (existingModule) {
        dashboardFocusExistingModule(existingModule);
        this.value = '';
        return;
    }

    const dash = document.getElementById('dashboard');
    const mod = document.createElement('div');

    mod.className = 'module square';
    mod.dataset.id = id;

    Object.assign(mod.style, {
        left: '250px',
        top: '280px',
        width: '280px',
        height: '280px'
    });

    const displayName = dashboardModuleDisplayName(id, id);

    mod.innerHTML = `
        <div class="module-header">
            <div class="dmd-module-head-title" style="display:flex;align-items:center;gap:8px;min-width:0;">
                <img
                    class="dmd-module-drag-handle"
                    src="modules/${id}/icon.png"
                    alt=""
                    draggable="false"
                    title="Déplacer le module"
                    style="width:28px;height:28px;object-fit:contain;flex:0 0 28px;display:block;cursor:grab;user-select:none;-webkit-user-drag:none;touch-action:none;"
                    onerror="this.style.visibility='hidden'"
                >
                <span class="module-title">${dashboardEscapeHtml(displayName)}</span>
            </div>

            <div class="dmd-module-head-actions">
                <select class="shape-select" onchange="changeShape(this)" aria-label="Forme du module">
                    <option value="square">Carré</option>
                    <option value="rounded">Arrondi</option>
                </select>

                <button class="dmd-module-menu-trigger" type="button" title="Actions du module" aria-label="Actions du module">⋯</button>
            </div>
        </div>

        <div class="module-content">Contenu du module ${id}</div>
        <div class="resize-handle"></div>
    `;

    dash.appendChild(mod);
    bringModuleToFront(mod);

    if (window.DMDWorkspace) {
        await window.DMDWorkspace.restoreModuleGeometry(mod, workspaceGeometryScope, {
            x: 250,
            y: 280,
            width: 280,
            height: 280
        });
    }

    // La géométrie mémorisée peut désormais être occupée par un autre module.
    // On conserve la taille restaurée mais on déplace uniquement le nouveau
    // module vers la zone libre la plus proche.
    dashboardPlaceModuleWithoutOverlap(
        mod,
        parseFloat(mod.style.left) || 250,
        parseFloat(mod.style.top) || 280
    );

    expandCanvasLT();
    enableInteract(mod);
    loadModuleContent(mod, id);
    saveDashboard();

    this.value = '';
});

document.getElementById('resetBtn').addEventListener('click', e => {
    const p = document.getElementById('confirmPopup');
    const r = e.target.getBoundingClientRect();

    p.style.display = 'block';
    p.style.top = (r.bottom + window.scrollY) + 'px';
    p.style.left = (r.left + window.scrollX) + 'px';
});

function confirmReset() {
    if (quickSessionWorkspaceActive) {
        hidePopup();

        const dash = document.getElementById('dashboard');
        dash.innerHTML = '';
        expandCanvasLT();
        saveDashboard();
        return;
    }

    const url = 'users/reset_dashboard.php?dashboard=' + encodeURIComponent(currentDashboard);

    fetch(url, {
        method: 'POST',
        cache: 'no-store'
    })
        .then(() => {
            hidePopup();

            const dash = document.getElementById('dashboard');
            dash.innerHTML = '';

            expandCanvasLT();

            location.replace('?dashboard=' + encodeURIComponent(currentDashboard) + '&r=' + Date.now());
        })
        .catch(() => {
            hidePopup();

            const dash = document.getElementById('dashboard');
            dash.innerHTML = '';

            expandCanvasLT();

            location.replace('?dashboard=' + encodeURIComponent(currentDashboard) + '&r=' + Date.now());
        });
}

function hidePopup() {
    document.getElementById('confirmPopup').style.display = 'none';
}

function openCoreHelp(anchor) {
    const popup = document.getElementById('dmdCoreHelpPopup');
    if (!popup) {
        return;
    }

    popup.hidden = false;
    popup.style.display = 'block';

    if (anchor) {
        const r = anchor.getBoundingClientRect();
        popup.style.top = (r.bottom + window.scrollY) + 'px';
        popup.style.left = (r.left + window.scrollX) + 'px';
    }
}

function closeCoreHelp() {
    const popup = document.getElementById('dmdCoreHelpPopup');
    if (!popup) {
        return;
    }

    popup.style.display = 'none';
    popup.hidden = true;
}

function openGlobalActionHub(anchor) {
    const detail = {
        anchor: anchor || null,
        currentDashboard: currentDashboard,
        quickSessionActive: quickSessionActive,
        quickSessionView: quickSessionView
    };

    // Point d'entrée global : le Core ActionHub peut écouter cet événement.
    document.dispatchEvent(new CustomEvent('dmd:actionhub-open', { detail }));

    if (!window.DMDActionHub) {
        console.warn('ActionHub : le Core DMDActionHub n’est pas chargé.');
        return;
    }

    if (typeof window.DMDActionHub.openGlobal === 'function') {
        window.DMDActionHub.openGlobal(detail);
        return;
    }

    if (typeof window.DMDActionHub.toggleGlobal === 'function') {
        window.DMDActionHub.toggleGlobal(detail);
        return;
    }

    if (typeof window.DMDActionHub.openHub === 'function') {
        window.DMDActionHub.openHub(detail);
    }
}

function renderDashboardModules(mods) {
    const dash = document.getElementById('dashboard');
    dash.innerHTML = '';

    let renderList = Array.isArray(mods) ? [...mods] : [];

    if (window.DMDWorkspace && window.DMDWorkspace.isMobileView()) {
        renderList.sort((a, b) => {
            const ay = Number(a && a.y) || 0;
            const by = Number(b && b.y) || 0;
            if (ay !== by) return ay - by;
            return (Number(a && a.x) || 0) - (Number(b && b.x) || 0);
        });
    }

    const renderedModuleIds = new Set();

    renderList.forEach(d => {
        if (!d || !dashboardAllowedModules.includes(d.id)) {
            return;
        }

        // Sécurité au chargement : si un ancien JSON contient encore deux fois
        // le même module, seule la première instance est affichée.
        if (renderedModuleIds.has(d.id)) {
            return;
        }
        renderedModuleIds.add(d.id);

        const m = document.createElement('div');

        m.className = `module ${d.shape || 'square'}`;
        m.dataset.id = d.id;

        Object.assign(m.style, {
            left: Math.max(0, Number(d.x) || 0) + 'px',
            top: Math.max(0, Number(d.y) || 0) + 'px',
            width: Math.max(120, Number(d.width) || 280) + 'px',
            height: Math.max(90, Number(d.height) || 280) + 'px'
        });

        const displayName = dashboardModuleDisplayName(d.id, d.title || d.id);

        m.innerHTML = `
            <div class="module-header">
                <div class="dmd-module-head-title" style="display:flex;align-items:center;gap:8px;min-width:0;">
                    <img
                        class="dmd-module-drag-handle"
                        src="modules/${d.id}/icon.png"
                        alt=""
                        draggable="false"
                        title="Déplacer le module"
                        style="width:28px;height:28px;object-fit:contain;flex:0 0 28px;display:block;cursor:grab;user-select:none;-webkit-user-drag:none;touch-action:none;"
                        onerror="this.style.visibility='hidden'"
                    >
                    <span class="module-title">${dashboardEscapeHtml(displayName)}</span>
                </div>

                <div class="dmd-module-head-actions">
                    <select class="shape-select" onchange="changeShape(this)" aria-label="Forme du module">
                        <option value="square"${d.shape === 'square' ? ' selected' : ''}>Carré</option>
                        <option value="rounded"${d.shape === 'rounded' ? ' selected' : ''}>Arrondi</option>
                        <option value="circle"${d.shape === 'circle' ? ' selected' : ''}>Rond</option>
                    </select>

                    <button class="dmd-module-menu-trigger" type="button" title="Actions du module" aria-label="Actions du module">⋯</button>
                </div>
            </div>

            <div class="module-content">${quickSessionWorkspaceActive ? '' : (d.content || '')}</div>
            <div class="resize-handle"></div>
        `;

        dash.appendChild(m);

        enableInteract(m);
        loadModuleContent(m, d.id);
    });

    if (window.DMDWorkspace) {
        window.DMDWorkspace.applyMobileOrder(dash);
    }

    expandCanvasLT();
}

function loadDash(name) {
    if (quickSessionWorkspaceActive) {
        renderDashboardModules(quickSessionInitialModules);
        return Promise.resolve();
    }

    return fetch(
        'users/profiles/' + encodeURIComponent(currentUserEmail) + '/' + encodeURIComponent(name) + '.json',
        {
            cache: 'no-store'
        }
    )
        .then(r => r.json())
        .then(mods => {
            renderDashboardModules(mods);
        })
        .catch(err => {
            console.error('Erreur chargement dashboard :', err);
            expandCanvasLT();
        });
}

function createDash() {
    const n = prompt('Nom du nouveau tableau :');

    if (!n) {
        return;
    }

    fetch('users/create_dashboard.php', {
        method: 'POST',
        cache: 'no-store',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: n })
    })
        .then(async response => {
            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.ok) {
                if (data.error === 'dashboard_limit') {
                    const limitText = Number(data.limit || 0) > 0 ? ` (${data.limit} maximum)` : '';
                    throw new Error('Limite de dashboards atteinte' + limitText + '.');
                }
                throw new Error('Impossible de créer le dashboard.');
            }
            location.href = '?dashboard=' + encodeURIComponent(data.name || n);
        })
        .catch(error => {
            alert(error && error.message ? error.message : 'Impossible de créer le dashboard.');
        });
}

function renameDash() {
    const n = prompt('Nouveau nom :', currentDashboard);

    if (!n) {
        return;
    }

    fetch('users/rename_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            old: currentDashboard,
            name: n
        })
    }).then(() => {
        location.href = '?dashboard=' + encodeURIComponent(n);
    });
}

function deleteDash() {
    if (!confirm('Supprimer ce tableau ?')) {
        return;
    }

    fetch('users/delete_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: currentDashboard
        })
    }).then(() => {
        location.href = '?dashboard=<?= urlencode($dashboards[0]) ?>';
    });
}

function formatQuickSessionDuration(totalSeconds) {
    totalSeconds = Math.max(0, Math.floor(totalSeconds));

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    return String(hours).padStart(2, '0') + ':' +
        String(minutes).padStart(2, '0') + ':' +
        String(seconds).padStart(2, '0');
}

function updateQuickSessionTimer() {
    if (!quickSessionActive || !quickSessionStartedAt) {
        return;
    }

    const timer = document.getElementById('quickSessionTimer');
    if (!timer) {
        return;
    }

    const elapsed = Math.floor(Date.now() / 1000) - quickSessionStartedAt;
    timer.textContent = formatQuickSessionDuration(elapsed);
}

function openQuickSession() {
    const origin = quickSessionActive ? quickSessionOriginDashboard : currentDashboard;
    location.href = '?quick_session=1&from=' + encodeURIComponent(origin);
}

function startQuickSession(btn) {
    if (btn) {
        btn.disabled = true;
    }
    Promise.resolve(saveDashboard())
        .then(() => fetch('Quick-Session/api.php?action=start', {
            method: 'POST',
            cache: 'no-store',
            headers: {
                'Content-Type': 'application/json',
                'X-DMD-CSRF': <?= json_encode($quickSessionCsrf, JSON_UNESCAPED_SLASHES) ?>
            },
            body: JSON.stringify({ origin_dashboard: currentDashboard })
        }))
        .then(r => r.json().then(data => ({ ok: r.ok, data })))
        .then(result => {
            if (!result.ok || !result.data.ok) {
                throw new Error(result.data.error || 'start_failed');
            }
            location.href = '?quick_session=1&from=' + encodeURIComponent(result.data.origin_dashboard || currentDashboard);
        })
        .catch(err => {
            console.error('Quick-Session :', err);
            alert('Impossible de démarrer la Quick-Session.');
            if (btn) {
                btn.disabled = false;
            }
        });
}

function resolveQuickSession() {
    if (window.DMDQuickSession && typeof window.DMDQuickSession.openResolutionChoice === 'function') {
        window.DMDQuickSession.openResolutionChoice();
        return;
    }

    alert('La fenêtre de clôture Quick-Session n’est pas disponible. Recharge la page puis réessaie.');
}

window.addEventListener('DOMContentLoaded', () => {
    if (window.DMDWorkspace) {
        window.DMDWorkspace.configure({
            dashboardName: workspaceGeometryScope,
            quickSessionView: quickSessionWorkspaceActive,
            windowStateUrl: 'users/workspace_state.php',
            onModeChanged: () => location.reload(),
            onMobileOrderChanged: () => {}
        });
    }

    if (window.DMDActionHub) {
        window.DMDActionHub.configure({
            endpoint: 'ActionHub/api.php',
            quickSessionApiUrl: 'Quick-Session/api.php',
            csrfToken: <?= json_encode($actionHubCsrf, JSON_UNESCAPED_SLASHES) ?>,
            quickSessionCsrfToken: <?= json_encode($quickSessionCsrf, JSON_UNESCAPED_SLASHES) ?>,
            currentDashboard: currentDashboard,
            quickSessionActive: quickSessionActive,
            quickSessionView: quickSessionView
        });
        window.DMDActionHub.decorate(document);
    }

    const quickBtn = document.getElementById('quickSessionBtn');
    const actionHubBtn = document.getElementById('actionHubBtn');
    const coreHelpBtn = document.getElementById('dmdCoreHelpBtn');
    const coreHelpClose = document.getElementById('dmdCoreHelpClose');
    const resolveBtn = document.getElementById('quickSessionResolveBtn');

    if (quickBtn) {
        quickBtn.addEventListener('click', () => {
            if (quickSessionActive) {
                if (!quickSessionView) {
                    openQuickSession();
                }
                return;
            }

            startQuickSession(quickBtn);
        });
    }

    if (actionHubBtn) {
        actionHubBtn.addEventListener('click', () => openGlobalActionHub(actionHubBtn));
    }

    if (coreHelpBtn) {
        coreHelpBtn.addEventListener('click', () => openCoreHelp(coreHelpBtn));
    }

    if (coreHelpClose) {
        coreHelpClose.addEventListener('click', closeCoreHelp);
    }

    if (resolveBtn) {
        resolveBtn.addEventListener('click', resolveQuickSession);
    }

    updateQuickSessionTimer();
    if (quickSessionActive) {
        window.setInterval(updateQuickSessionTimer, 1000);
    }

    const requestedCoreTool = new URLSearchParams(window.location.search).get('core_tool');

    loadDash(currentDashboard).then(() => {
        if (!requestedCoreTool) return;

        const cleanUrl = new URL(window.location.href);
        cleanUrl.searchParams.delete('core_tool');
        window.history.replaceState({}, '', cleanUrl.pathname + cleanUrl.search + cleanUrl.hash);

        if (requestedCoreTool === 'actionhub' && <?= $dmdActionHubUserEnabled ? 'true' : 'false' ?>) {
            window.setTimeout(() => openGlobalActionHub(null), 80);
            return;
        }

        if (requestedCoreTool === 'quick_session' && <?= $dmdQuickSessionUserEnabled ? 'true' : 'false' ?>) {
            window.setTimeout(() => {
                if (quickSessionActive) {
                    if (!quickSessionView) openQuickSession();
                    return;
                }
                startQuickSession(null);
            }, 80);
        }
    });

});
</script>

<script>
(function () {
    const dash = document.getElementById('dashboard');

    if (!dash) {
        return;
    }

    const root = document.documentElement;

    function alignTopbar() {
        const r = dash.getBoundingClientRect();

        root.style.setProperty('--topbar-left', r.left + 'px');
        root.style.setProperty('--topbar-width', r.width + 'px');
    }

    alignTopbar();

    window.addEventListener('resize', alignTopbar);
    window.addEventListener('scroll', alignTopbar, { passive: true });

    new ResizeObserver(alignTopbar).observe(dash);
})();
</script>

</body>
</html>