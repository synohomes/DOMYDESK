<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
session_start();
require_once __DIR__ . '/core/dmd_password_reset.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');

$theme = 'default';
$error = '';
$message = '';
$identity = '';
$csrf = dmd_csrf_token('password_forgot');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $identity = trim((string)($_POST['identity'] ?? ''));
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'password_forgot')) {
        $error = 'Formulaire expiré. Rechargez la page.';
    } elseif ($identity === '') {
        $error = 'Saisissez votre adresse e-mail ou votre identifiant Active Directory.';
    } else {
        $result = dmd_password_reset_create_request($identity);
        $message = (string)($result['public_message'] ?? 'Si ce compte existe, un e-mail de réinitialisation vient d’être envoyé.');
        $identity = '';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Mot de passe oublié - DoMyDesk</title>
    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
    <?php
    require_once __DIR__ . '/core/dmd_theme_assets.php';
    echo dmd_theme_extra_links(__DIR__, 'theme', $theme, 'login');
    ?>
</head>
<body>
<main class="login-wrapper">
    <section class="login-card" aria-labelledby="forgot-title">
        <div class="brand">
            <img src="adm/uploads/logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 id="forgot-title">Mot de passe oublié</h1>
        </div>

        <p class="subtitle">Saisissez l’adresse e-mail de votre compte DoMyDesk ou votre identifiant Active Directory.</p>

        <?php if ($error !== ''): ?>
            <div class="error-message"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <?php if ($message !== ''): ?>
            <div class="message success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <?php if ($message === ''): ?>
        <form method="post" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <label for="identity">Adresse e-mail / identifiant AD</label>
            <input type="text" id="identity" name="identity" value="<?= htmlspecialchars($identity, ENT_QUOTES, 'UTF-8') ?>" placeholder="vous@exemple.com ou jdupont" required autofocus>
            <button type="submit" class="btn">Envoyer le lien de réinitialisation</button>
        </form>
        <?php endif; ?>

        <a class="register-link" href="login.php">Retour à la connexion</a>
    </section>
</main>
</body>
</html>
