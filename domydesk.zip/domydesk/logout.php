<?php
session_start();

function dmd_logout_safe_next($value) {
    $value = trim((string)$value);
    if ($value === '') return '';
    if (preg_match('#^https?://#i', $value)) return '';
    if (strpos($value, "\r") !== false || strpos($value, "\n") !== false || strpos($value, '..') !== false) return '';
    if ($value[0] === '/') {
        return strpos($value, '/domydesk/') === 0 ? $value : '';
    }
    return ltrim($value, '/');
}

$next = dmd_logout_safe_next(isset($_GET['next']) ? $_GET['next'] : '');
session_unset();
session_destroy();

$target = 'login.php';
if ($next !== '') {
    $target .= '?next=' . rawurlencode($next);
}
header('Location: ' . $target);
exit;
