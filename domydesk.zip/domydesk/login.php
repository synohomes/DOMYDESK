<?php
session_start();
require_once __DIR__ . '/core/dmd_permissions.php';
require_once __DIR__ . '/core/dmd_mfa.php';
require_once __DIR__ . '/core/dmd_account_approval.php';
require_once __DIR__ . '/core/directory/dmd_ad_sync.php';

function dmd_login_safe_next($value) {
    $value = trim((string)$value);
    if ($value === '') return '';
    if (preg_match('#^https?://#i', $value)) return '';
    if (strpos($value, "\r") !== false || strpos($value, "\n") !== false || strpos($value, '..') !== false) return '';
    if ($value[0] === '/') return strpos($value, '/domydesk/') === 0 ? $value : '';
    return ltrim($value, '/');
}

$loginNext = dmd_login_safe_next($_GET['next'] ?? '');

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

function json_read(string $file, $fallback) {
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    $data = json_decode($raw, true);

    return (json_last_error() === JSON_ERROR_NONE) ? $data : $fallback;
}

$error = '';
$email = '';
$theme = 'default';

if (($_GET['mfa'] ?? '') === 'expired') {
    $error = "La vérification MFA a expiré. Reconnectez-vous.";
} elseif (($_GET['mfa'] ?? '') === 'locked') {
    $error = "Trop de codes MFA incorrects. Recommencez la connexion.";
}
$info = '';
if (($_GET['registration'] ?? '') === 'pending') {
    $info = "Votre inscription a bien été enregistrée. Un administrateur doit la valider avant votre première connexion.";
} elseif (($_GET['registration'] ?? '') === 'active') {
    $info = "Votre compte a été créé et activé. Vous pouvez vous connecter.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identityInput = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $email = $identityInput;

    if ($identityInput === '') {
        $error = "Adresse e-mail ou identifiant AD obligatoire.";
    } else {
        $resolvedEmail = dmd_directory_find_profile_email_by_login($identityInput);
        if ($resolvedEmail === '' && filter_var($identityInput, FILTER_VALIDATE_EMAIL)) {
            $resolvedEmail = strtolower($identityInput);
        }

        $userDir = $resolvedEmail !== '' ? (__DIR__ . '/users/profiles/' . $resolvedEmail . '/') : '';
        $profilePath = $resolvedEmail !== '' ? dmd_profile_path($resolvedEmail, true) : '';
        $themePath = $userDir !== '' ? ($userDir . 'theme.json') : '';

        if ($themePath !== '' && is_file($themePath)) {
            $themeData = json_read($themePath, []);
            if (!empty($themeData['theme']) && is_file(__DIR__ . '/theme/' . basename($themeData['theme']) . '/style.css')) {
                $theme = basename($themeData['theme']);
            }
        }

        if ($profilePath !== '' && is_file($profilePath)) {
            $profile = json_read($profilePath, []);
            $accountStatus = dmd_account_status($profile);
            if ($accountStatus !== 'active') {
                if ($accountStatus === 'pending') {
                    $error = "Ce compte est en attente de validation par un administrateur.";
                } elseif ($accountStatus === 'refused') {
                    $error = "Cette demande d’inscription a été refusée.";
                } elseif ($accountStatus === 'suspended') {
                    $error = "Ce compte est suspendu.";
                } else {
                    $error = "Ce compte n’est pas autorisé à se connecter.";
                }
                $authOk = false;
            } else {
            $authOk = false;
            $authSource = strtolower((string)($profile['auth_source'] ?? 'local'));

            if ($authSource === 'active_directory') {
                $ad = is_array($profile['ad'] ?? null) ? $profile['ad'] : [];
                $hash = (string)($profile['motdepasse'] ?? $profile['password'] ?? '');
                $isMergedLocalAccount = !empty($ad['merge_existing_account'])
                    || strtolower((string)($ad['previous_auth_source'] ?? '')) === 'local';

                // Un compte local fusionné avec AD garde volontairement son identité locale.
                // Avec l'adresse e-mail DoMyDesk, son ancien mot de passe local reste donc
                // un moyen de secours valide. Cela évite qu'une désactivation temporaire de
                // l'authentification AD verrouille le propriétaire de l'instance.
                $loginLooksLikeEmail = filter_var($identityInput, FILTER_VALIDATE_EMAIL) !== false;
                $localAuthOk = false;
                if ($isMergedLocalAccount && $loginLooksLikeEmail && $hash !== '') {
                    $localAuthOk = password_verify($password, $hash);
                }

                if ($localAuthOk) {
                    $authOk = true;
                } else {
                    $adAuth = dmd_directory_authenticate_ad_profile($profile, $password);
                    $authOk = !empty($adAuth['ok']);
                    if (!$authOk) {
                        $adError = (string)($adAuth['error'] ?? 'Authentification Active Directory refusée.');
                        if ($isMergedLocalAccount && $loginLooksLikeEmail && $hash !== '' && stripos($adError, 'désactiv') !== false) {
                            $error = 'Authentification Active Directory désactivée. Le mot de passe local de ce compte fusionné a également été refusé.';
                        } else {
                            $error = $adError;
                        }
                    }
                }
            } else {
                $hash = (string)($profile['motdepasse'] ?? $profile['password'] ?? '');
                $authOk = $hash !== '' && password_verify($password, $hash);
                if (!$authOk) $error = "Mot de passe incorrect.";
            }

            if ($authOk) {
                $resolvedEmail = (string)($profile['email'] ?? $resolvedEmail);
                $sessionUser = [
                    'email'        => $resolvedEmail,
                    'prenom'       => $profile['prenom'] ?? '',
                    'nom'          => $profile['nom'] ?? '',
                    'role_system'  => $profile['role_system'] ?? '',
                    'role_metier'  => $profile['role_metier'] ?? ''
                ];

                $roleSystem = $profile['role_system'] ?? 'user';
                $redirectAfterLogin = $loginNext !== '' ? $loginNext : 'dashboard.php';
                $mfaPolicy = dmd_mfa_effective_policy($sessionUser['email'], $profile);

                if ($mfaPolicy === 'required' && !dmd_mfa_enabled($sessionUser['email'])) {
                    session_regenerate_id(true);
                    $_SESSION['dmd_mfa_enroll_pending'] = [
                        'email' => $sessionUser['email'],
                        'user' => $sessionUser,
                        'role_system' => $roleSystem,
                        'redirect' => $redirectAfterLogin,
                        'issued_at' => time(),
                    ];
                    header('Location: mfa_setup.php?required=1');
                    exit;
                }

                if (dmd_mfa_policy_login_uses_mfa($sessionUser['email'], $profile)) {
                    session_regenerate_id(true);
                    $_SESSION['dmd_mfa_pending'] = [
                        'email' => $sessionUser['email'],
                        'user' => $sessionUser,
                        'role_system' => $roleSystem,
                        'redirect' => $redirectAfterLogin,
                        'issued_at' => time(),
                        'attempts' => 0,
                    ];
                    header('Location: mfa_verify.php');
                    exit;
                }

                session_regenerate_id(true);
                $_SESSION['user'] = $sessionUser;
                $_SESSION['role_system'] = $roleSystem;
                header('Location: ' . $redirectAfterLogin);
                exit;
            }
            }
        } else {
            $error = "Utilisateur non trouvé.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Se connecter</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<?php
require_once __DIR__ . '/core/dmd_theme_assets.php';
echo dmd_theme_extra_links(__DIR__, 'theme', $theme, 'login');
?>
</head>

<body>

<main class="login-wrapper">
    <section class="login-card" aria-labelledby="login-title">

        <div class="brand">
            <img src="adm/uploads/logo.png" alt="Logo DoMyDesk" onerror="this.style.display='none'">
            <h1 id="login-title">Se connecter</h1>
        </div>

        <p class="subtitle">
            Votre espace de travail modulaire, privé et élégant.
        </p>

        <?php if (!empty($info)): ?>
            <p class="subtitle"><?= htmlspecialchars($info, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error-message">
                <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="post" action="" autocomplete="on" novalidate>
            <label for="email">Adresse e-mail / identifiant AD</label>
            <input
                type="text"
                id="email"
                name="email"
                placeholder="vous@exemple.com ou jdupont"
                value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                required
            >

            <label for="password">Mot de passe</label>
            <input
                type="password"
                id="password"
                name="password"
                placeholder="••••••••"
                required
            >

            <button type="submit" class="btn">
                Se connecter
            </button>

            <a class="register-link" href="forgot_password.php">
                Mot de passe oublié ?
            </a>

            <a class="register-link" href="register.php">
                Créer un compte
            </a>

            <p class="footnote">
                Accès réservé • <strong>DoMyDesk</strong> — Modular Private Workspace
            </p>
        </form>

    </section>
</main>

</body>
</html>