<?php
declare(strict_types=1);

session_start();

$rootDir = __DIR__;
$installedFlag = $rootDir . '/data/id_domydesk.txt';

if (is_file($installedFlag)) {
    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>DoMyDesk déjà installé</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            :root {
                --dmd-bg: #090b14;
                --dmd-panel: rgba(17, 23, 43, .82);
                --dmd-border: rgba(255, 255, 255, .14);
                --dmd-text: #f7f8ff;
                --dmd-muted: rgba(247, 248, 255, .68);
                --dmd-accent: #ff3b30;
                --dmd-blue: #7aa2ff;
                --dmd-green: #37d67a;
            }

            * {
                box-sizing: border-box;
            }

            body {
                min-height: 100vh;
                margin: 0;
                display: grid;
                place-items: center;
                padding: 24px;
                color: var(--dmd-text);
                font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
                background:
                    radial-gradient(circle at 22% 18%, rgba(122, 162, 255, .24), transparent 32%),
                    radial-gradient(circle at 82% 25%, rgba(255, 59, 48, .18), transparent 34%),
                    radial-gradient(circle at 54% 100%, rgba(55, 214, 122, .14), transparent 30%),
                    var(--dmd-bg);
                overflow: hidden;
            }

            body::before,
            body::after {
                content: "";
                position: fixed;
                width: 520px;
                height: 520px;
                border-radius: 999px;
                pointer-events: none;
                filter: blur(12px);
                opacity: .36;
                animation: dmd-orb 15s ease-in-out infinite alternate;
            }

            body::before {
                top: -180px;
                left: -160px;
                background: radial-gradient(circle, rgba(122, 162, 255, .35), transparent 68%);
            }

            body::after {
                right: -190px;
                bottom: -220px;
                background: radial-gradient(circle, rgba(255, 59, 48, .28), transparent 70%);
                animation-delay: -5s;
            }

            @keyframes dmd-orb {
                from { transform: translate3d(0, 0, 0) scale(1); }
                to { transform: translate3d(42px, 34px, 0) scale(1.08); }
            }

            .dmd-installed-bg {
                position: fixed;
                inset: 0;
                opacity: .16;
                pointer-events: none;
                overflow: hidden;
                mask-image: linear-gradient(90deg, transparent, #000 22%, #000 78%, transparent);
            }

            .dmd-installed-track {
                position: absolute;
                left: 0;
                display: flex;
                gap: 14px;
                width: max-content;
                white-space: nowrap;
                animation: dmd-marquee 38s linear infinite;
            }

            .dmd-installed-track:nth-child(1) {
                top: 14%;
            }

            .dmd-installed-track:nth-child(2) {
                bottom: 14%;
                animation-direction: reverse;
                animation-duration: 46s;
            }

            .dmd-chip {
                display: inline-flex;
                align-items: center;
                min-height: 40px;
                padding: 0 16px;
                border: 1px solid rgba(255, 255, 255, .12);
                border-radius: 999px;
                background: rgba(255, 255, 255, .065);
                color: rgba(255, 255, 255, .72);
                backdrop-filter: blur(10px);
                font-size: 14px;
            }

            @keyframes dmd-marquee {
                from { transform: translateX(0); }
                to { transform: translateX(-50%); }
            }

            .dmd-installed-card {
                position: relative;
                z-index: 2;
                width: min(620px, 100%);
                padding: clamp(26px, 4vw, 42px);
                border: 1px solid var(--dmd-border);
                border-radius: 30px;
                background:
                    linear-gradient(180deg, rgba(255, 255, 255, .11), rgba(255, 255, 255, .055)),
                    var(--dmd-panel);
                box-shadow: 0 28px 90px rgba(0, 0, 0, .48);
                backdrop-filter: blur(28px);
                text-align: center;
                overflow: hidden;
            }

            .dmd-installed-card::before {
                content: "";
                position: absolute;
                inset: 0;
                background: linear-gradient(120deg, transparent 0%, rgba(255,255,255,.13) 42%, transparent 58%);
                transform: translateX(-105%);
                animation: dmd-shine 5.8s ease-in-out infinite;
                pointer-events: none;
            }

            @keyframes dmd-shine {
                0%, 62% { transform: translateX(-105%); }
                100% { transform: translateX(105%); }
            }

            .dmd-status {
                position: relative;
                display: inline-flex;
                align-items: center;
                gap: 9px;
                margin-bottom: 18px;
                padding: 8px 13px;
                border: 1px solid rgba(55, 214, 122, .24);
                border-radius: 999px;
                background: rgba(55, 214, 122, .10);
                color: #c9ffd9;
                font-size: 13px;
                font-weight: 800;
            }

            .dmd-status::before {
                content: "";
                width: 9px;
                height: 9px;
                border-radius: 999px;
                background: var(--dmd-green);
                box-shadow: 0 0 0 7px rgba(55, 214, 122, .12);
            }

            h1 {
                position: relative;
                margin: 0;
                font-size: clamp(34px, 6vw, 58px);
                line-height: 1;
                letter-spacing: -0.055em;
            }

            h1 span {
                display: block;
                color: transparent;
                background: linear-gradient(90deg, #ffffff, #b9c7ff, #ffb7b2);
                -webkit-background-clip: text;
                background-clip: text;
            }

            p {
                position: relative;
                max-width: 500px;
                margin: 18px auto 0;
                color: var(--dmd-muted);
                font-size: 16px;
                line-height: 1.65;
            }

            .dmd-actions {
                position: relative;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 12px;
                margin-top: 28px;
            }

            .dmd-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 46px;
                padding: 0 18px;
                border-radius: 16px;
                text-decoration: none;
                color: white;
                font-weight: 900;
                border: 1px solid rgba(255,255,255,.14);
                transition: transform .16s ease, filter .16s ease, background .16s ease;
            }

            .dmd-btn-primary {
                background: linear-gradient(135deg, var(--dmd-accent), #ff6a5f 48%, var(--dmd-blue));
                box-shadow: 0 18px 42px rgba(255, 59, 48, .22);
            }

            .dmd-btn-ghost {
                background: rgba(255,255,255,.07);
            }

            .dmd-btn:hover {
                transform: translateY(-1px);
                filter: brightness(1.06);
            }

            .dmd-note {
                position: relative;
                margin-top: 22px;
                padding: 13px 14px;
                border: 1px solid rgba(255,255,255,.10);
                border-radius: 18px;
                background: rgba(255,255,255,.055);
                color: rgba(255,255,255,.58);
                font-size: 13px;
                line-height: 1.5;
            }

            @media (max-width: 560px) {
                .dmd-actions {
                    display: grid;
                }

                .dmd-btn {
                    width: 100%;
                }
            }

            @media (prefers-reduced-motion: reduce) {
                *,
                *::before,
                *::after {
                    animation-duration: .001ms !important;
                    animation-iteration-count: 1 !important;
                }
            }
        </style>
    </head>
    <body>
        <div class="dmd-installed-bg" aria-hidden="true">
            <div class="dmd-installed-track">
                <span class="dmd-chip">📌 TodoList</span>
                <span class="dmd-chip">📄 PDF View</span>
                <span class="dmd-chip">🖥️ Proxmox</span>
                <span class="dmd-chip">🏠 Home Assistant</span>
                <span class="dmd-chip">📰 Actualités</span>
                <span class="dmd-chip">🚀 Updates</span>
                <span class="dmd-chip">📌 TodoList</span>
                <span class="dmd-chip">📄 PDF View</span>
                <span class="dmd-chip">🖥️ Proxmox</span>
                <span class="dmd-chip">🏠 Home Assistant</span>
                <span class="dmd-chip">📰 Actualités</span>
                <span class="dmd-chip">🚀 Updates</span>
            </div>
            <div class="dmd-installed-track">
                <span class="dmd-chip">Bureau web privé</span>
                <span class="dmd-chip">Modules installables</span>
                <span class="dmd-chip">Données locales</span>
                <span class="dmd-chip">Dashboard personnalisable</span>
                <span class="dmd-chip">Support optionnel</span>
                <span class="dmd-chip">Bureau web privé</span>
                <span class="dmd-chip">Modules installables</span>
                <span class="dmd-chip">Données locales</span>
                <span class="dmd-chip">Dashboard personnalisable</span>
                <span class="dmd-chip">Support optionnel</span>
            </div>
        </div>

        <main class="dmd-installed-card">
            <div class="dmd-status">Installation détectée</div>
            <h1>DoMyDesk est <span>déjà installé</span></h1>
            <p>
                Le fichier d’installation est encore présent, mais DoMyDesk possède déjà
                un identifiant d’installation. Par sécurité, l’assistant d’installation est bloqué.
            </p>

            <div class="dmd-actions">
                <a class="dmd-btn dmd-btn-primary" href="/domydesk/login.php">Aller à la connexion</a>
                <a class="dmd-btn dmd-btn-ghost" href="/domydesk/">Retour à DoMyDesk</a>
            </div>

            <div class="dmd-note">
                Conseil : supprimez <strong>install.php</strong> du serveur après installation.
                Si vous voulez réinstaller volontairement, sauvegardez d’abord vos données puis retirez le verrou d’installation avec prudence.
            </div>
        </main>
    </body>
    </html>
    <?php
    exit;
}

if (!empty($_GET['dev'])) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
    error_reporting(E_ALL);
}

function dmd_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function dmd_redirect(string $path = '/domydesk/login.php'): void
{
    if (!headers_sent()) {
        header('Location: ' . $path, true, 302);
        exit;
    }

    echo '<script>location.replace(' . json_encode($path) . ');</script>';
    echo '<noscript><meta http-equiv="refresh" content="0;url=' . dmd_h($path) . '"></noscript>';
    exit;
}

function dmd_safe_profile_dir_name(string $email): string
{
    return str_replace(['/', '\\', "\0"], '', $email);
}

function dmd_detect_system_type(): string
{
    $osInfo = php_uname();
    $etcIssue = @file_get_contents('/etc/issue') ?: '';

    if (stripos($osInfo, 'synology') !== false || is_dir('/volume1/')) return 'synology';
    if (is_dir('/share/') && is_file('/etc/config/uLinux.conf')) return 'qnap';
    if (stripos($etcIssue, 'ubuntu') !== false || stripos($osInfo, 'ubuntu') !== false) return 'ubuntu';

    return 'unknown';
}

function dmd_chmod_tree(string $path, int $dirPerm = 0775, int $filePerm = 0664): void
{
    if (!file_exists($path)) return;

    if (is_dir($path)) {
        @chmod($path, $dirPerm);
        $items = @scandir($path);
        if (!is_array($items)) return;

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            dmd_chmod_tree($path . DIRECTORY_SEPARATOR . $item, $dirPerm, $filePerm);
        }
        return;
    }

    @chmod($path, $filePerm);
}

function dmd_apply_initial_permissions(string $rootDir): void
{
    $system = dmd_detect_system_type();

    // Permissions appliquées uniquement après installation, pas à chaque affichage de la page.
    $writableDirs = [
        $rootDir . '/data',
        $rootDir . '/users',
        $rootDir . '/users/profiles',
        $rootDir . '/modules',
        $rootDir . '/theme',
    ];

    foreach ($writableDirs as $dir) {
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        dmd_chmod_tree($dir, 0775, 0664);
    }

    $marker = '.permissions_checked';
    if ($system === 'synology') {
        $marker = '.htpermissions';
    } elseif ($system === 'qnap') {
        $marker = '.qnap_permissions';
    } elseif ($system === 'ubuntu') {
        $marker = '.ubuntu_permissions';
    }

    @file_put_contents($rootDir . '/' . $marker, strtoupper($system) . ' : permissions initiales vérifiées le ' . date('Y-m-d H:i:s'));
}

function dmd_disable_installer_after_response(): void
{
    register_shutdown_function(static function (): void {
        $installFile = __FILE__;

        if (!is_file($installFile)) return;

        if (is_writable($installFile)) {
            @unlink($installFile);
            return;
        }

        @rename($installFile, __DIR__ . '/install.disabled.php');
    });
}

function dmd_generate_domydesk_uid(string $nom, string $prenom): string
{
    $aa = date('y');
    $mm = date('m');
    $initNom = strtolower(substr($nom, 0, 1)) ?: 'x';
    $initPrenom = strtolower(substr($prenom, 0, 1)) ?: 'x';
    $rand10 = str_pad((string) random_int(0, 9999999999), 10, '0', STR_PAD_LEFT);

    return "DmD-$aa-$mm-$initNom$initPrenom-$rand10";
}

function dmd_generate_client_id(string $prenom): string
{
    $initiale = strtolower(substr($prenom !== '' ? $prenom : 'x', 0, 1));
    $annee = date('y');
    $alea = strtoupper(substr(str_shuffle('ABCDEFGHJKLMNPQRSTUVWXYZ'), 0, 4));
    $num = str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT);

    return "DM1-$initiale-$annee-$alea-$num";
}


/**
 * Nettoie uniquement les donnees d'execution DMD-Agent qui ne doivent jamais
 * etre reutilisees sur une nouvelle instance DoMyDesk.
 *
 * Le code Agent et l'installateur Windows restent intacts. Les .htaccess sont
 * conserves. Cette fonction n'est appelee que pendant une premiere installation,
 * lorsque data/id_domydesk.txt n'existe pas encore.
 */
function dmd_install_clear_agent_runtime_dir(string $dir): array
{
    $errors = [];
    if (!is_dir($dir)) return $errors;

    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $item) {
            /** @var SplFileInfo $item */
            $path = $item->getPathname();

            // Les protections HTTP restent en place.
            if ($item->isFile() && $item->getFilename() === '.htaccess') {
                continue;
            }

            if ($item->isDir()) {
                // Un dossier contenant uniquement un .htaccess doit rester.
                $entries = @scandir($path);
                if (is_array($entries)) {
                    $remaining = array_values(array_diff($entries, ['.', '..']));
                    if ($remaining === ['.htaccess']) continue;
                    if ($remaining !== []) continue;
                }

                if (!@rmdir($path) && is_dir($path)) {
                    $errors[] = 'rmdir:' . $path;
                }
                continue;
            }

            if (!@unlink($path) && is_file($path)) {
                $errors[] = 'unlink:' . $path;
            }
        }
    } catch (Throwable $e) {
        $errors[] = 'exception:' . $e->getMessage();
    }

    return $errors;
}

function dmd_install_reset_agent_runtime(string $rootDir): array
{
    $agentVar = $rootDir . '/var/agent';
    $errors = [];

    // Identite cryptographique : elle DOIT etre unique a cette installation.
    $identityFiles = [
        $agentVar . '/instance/instance.php',
        $agentVar . '/instance/instance_signature.php',
        $agentVar . '/instance/public_key.php',
        $agentVar . '/instance/private/private_key.php',
        $agentVar . '/instance/private/enrollment_pepper.php',
    ];

    foreach ($identityFiles as $file) {
        if (is_file($file) && !@unlink($file)) {
            $errors[] = 'unlink:' . $file;
        }
    }

    // Aucune donnee de parc, de droits, de commande ou de journal d'une autre
    // installation ne doit voyager vers la nouvelle instance.
    foreach (['enrollments', 'devices', 'packages', 'commands', 'updates', 'logs', 'security', 'audits'] as $runtimeDir) {
        $errors = array_merge($errors, dmd_install_clear_agent_runtime_dir($agentVar . '/' . $runtimeDir));
    }

    foreach (['pc_groups.php', 'user_groups.php', 'policies.php'] as $accessFile) {
        $file = $agentVar . '/access/' . $accessFile;
        if (is_file($file) && !@unlink($file)) {
            $errors[] = 'unlink:' . $file;
        }
    }

    return [
        'ok' => $errors === [],
        'errors' => $errors,
    ];
}

function dmd_install_create_agent_seal(string $rootDir, string $instanceId): array
{
    $core = $rootDir . '/adm/agent/includes/agent_core.php';
    if (!is_file($core)) {
        return ['ok' => false, 'state' => 'agent_core_missing', 'message' => 'Le coeur DMD-Agent est absent.'];
    }

    require_once $core;

    if (!function_exists('dmd_agent_ensure_instance_identity')) {
        return ['ok' => false, 'state' => 'agent_core_invalid', 'message' => 'Le coeur DMD-Agent ne fournit pas la fonction de scellement.'];
    }

    $identity = dmd_agent_ensure_instance_identity();
    if (empty($identity['ok'])) {
        // Le runtime a ete nettoye juste avant : tout fichier d'identite present ici
        // appartient a cette tentative d'installation et peut etre retire pour autoriser un nouvel essai.
        if (function_exists('dmd_agent_instance_paths')) {
            foreach (dmd_agent_instance_paths() as $file) {
                if (is_file($file)) @unlink($file);
            }
        }

        return [
            'ok' => false,
            'state' => (string)($identity['state'] ?? 'identity_error'),
            'message' => (string)($identity['message'] ?? 'Impossible de creer l’identite cryptographique DMD-Agent.'),
        ];
    }

    $sealedId = (string)($identity['manifest']['instance_id'] ?? '');
    if ($sealedId === '' || !hash_equals($instanceId, $sealedId)) {
        return ['ok' => false, 'state' => 'sealed_id_mismatch', 'message' => 'L’identifiant scelle DMD-Agent ne correspond pas a cette instance DoMyDesk.'];
    }

    return [
        'ok' => true,
        'state' => 'valid',
        'fingerprint' => (string)($identity['manifest']['public_key_fingerprint'] ?? ''),
    ];
}


function dmd_read_domydesk_version(string $rootDir): string
{
    $versionFile = $rootDir . '/data/version.txt';
    if (!is_file($versionFile) || !is_readable($versionFile)) {
        return 'unknown';
    }

    $version = trim((string) @file_get_contents($versionFile));
    if ($version === '' || !preg_match('/^[0-9A-Za-z][0-9A-Za-z._+-]*$/', $version)) {
        return 'unknown';
    }

    return $version;
}

function dmd_collect_modules(string $rootDir): array
{
    $modules = [];
    $modulesFile = $rootDir . '/modules/list.json';

    if (!is_file($modulesFile)) return $modules;

    $modulesJson = json_decode((string) file_get_contents($modulesFile), true);
    if (!is_array($modulesJson)) return $modules;

    foreach ($modulesJson as $module) {
        if (!is_array($module)) continue;

        $modules[] = [
            'id'      => (string)($module['id'] ?? ''),
            'name'    => (string)($module['name'] ?? ($module['id'] ?? '')),
            'enabled' => !empty($module['enabled']),
        ];
    }

    return $modules;
}

function dmd_register_installation(string $rootDir, array $payload): void
{
    try {
        $ch = curl_init('https://register.synohomes.com/register.php');
        if (!$ch) throw new RuntimeException('Impossible d’initialiser cURL.');

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);

        $resp = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        @mkdir($rootDir . '/data', 0775, true);

        @file_put_contents(
            $rootDir . '/data/register.log',
            date('c') . ' - DomyCo Register HTTP ' . $httpCode . ' - error: ' . $curlError . ' - response: ' . $resp . PHP_EOL,
            FILE_APPEND
        );

        @file_put_contents(
            $rootDir . '/data/domyco_register.json',
            json_encode([
                'sent'      => true,
                'sent_at'   => date('c'),
                'http_code' => $httpCode,
                'error'     => $curlError,
                'response'  => $resp,
                'payload'   => $payload,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    } catch (Throwable $e) {
        @mkdir($rootDir . '/data', 0775, true);
        @file_put_contents($rootDir . '/data/register.log', date('c') . ' - DomyCo Register error: ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
    }
}

$errors = [];

if (empty($_SESSION['install_csrf'])) {
    $_SESSION['install_csrf'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_POST['csrf'] ?? '');

    if (!hash_equals($_SESSION['install_csrf'], $csrf)) {
        $errors[] = 'Session expirée ou formulaire invalide. Rechargez la page.';
    }

    $email = trim((string)($_POST['email'] ?? ''));
    $prenom = trim((string)($_POST['prenom'] ?? ''));
    $nom = trim((string)($_POST['nom'] ?? ''));
    $motdepasse = (string)($_POST['motdepasse'] ?? '');
    $shareInstall = isset($_POST['share_install']) && $_POST['share_install'] === '1';

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Merci d’indiquer un email administrateur valide.';
    }

    if ($motdepasse === '') {
        $errors[] = 'Merci de définir un mot de passe administrateur.';
    }

    if (!$errors) {
        @mkdir($rootDir . '/data', 0775, true);
        @mkdir($rootDir . '/users/profiles', 0775, true);

        // Une nouvelle installation ne doit jamais heriter de l'identite, des
        // agents, des droits ou des journaux DMD-Agent de l'instance qui a servi
        // a fabriquer l'archive.
        $agentReset = dmd_install_reset_agent_runtime($rootDir);
        if (empty($agentReset['ok'])) {
            $errors[] = 'Impossible de nettoyer les donnees DMD-Agent de l’archive avant le scellement. Verifiez les droits d’écriture sur var/agent/.';
        }
    }

    if (!$errors) {
        $safeEmailDir = dmd_safe_profile_dir_name($email);
        $userDir = $rootDir . '/users/profiles/' . $safeEmailDir;
        $profileDir = $userDir . '/profile';

        if (!is_dir($userDir)) @mkdir($userDir, 0775, true);
        if (!is_dir($profileDir)) @mkdir($profileDir, 0750, true);

        $idFile = $rootDir . '/data/id_domydesk.txt';
        $idDmd = dmd_generate_domydesk_uid($nom, $prenom);

        if (file_put_contents($idFile, $idDmd, LOCK_EX) === false) {
            $errors[] = 'Impossible de créer data/id_domydesk.txt.';
        } else {
            @chmod($idFile, 0664);
        }
    }

    if (!$errors) {
        // Cree la paire Ed25519, le fingerprint, la signature de l'identite et
        // le pepper d'enrolement, puis lie le tout a data/id_domydesk.txt.
        $agentSeal = dmd_install_create_agent_seal($rootDir, $idDmd);
        if (empty($agentSeal['ok'])) {
            @unlink($idFile); // permet de relancer install.php apres correction
            $state = (string)($agentSeal['state'] ?? 'unknown');
            $message = (string)($agentSeal['message'] ?? 'Erreur inconnue.');
            $errors[] = 'Scellement DMD-Agent impossible [' . $state . '] : ' . $message;
        }
    }

    if (!$errors) {
        $profil = [
            'email'         => $email,
            'prenom'        => $prenom,
            'nom'           => $nom,
            'pseudo'        => $prenom ?: $email,
            'role_system'   => 'superadmin',
            'motdepasse'    => password_hash($motdepasse, PASSWORD_DEFAULT),
            'created_at'    => date('Y-m-d H:i:s'),
            'id_client'     => dmd_generate_client_id($prenom),
            'share_install' => $shareInstall,
            'consent_at'    => $shareInstall ? date('c') : null,
        ];

        file_put_contents($profileDir . '/profile.json', json_encode($profil, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        @chmod($profileDir . '/profile.json', 0640);

        $profileHtaccess = $profileDir . '/.htaccess';
        if (!is_file($profileHtaccess)) {
            @file_put_contents($profileHtaccess, "Require all denied\nDeny from all\n", LOCK_EX);
            @chmod($profileHtaccess, 0640);
        }

        dmd_apply_initial_permissions($rootDir);

        if ($shareInstall) {
            $host = $_SERVER['HTTP_HOST'] ?? '';
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            $scheme = $https ? 'https' : 'http';
            $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/domydesk'));
            $scriptDir = rtrim($scriptDir, '/');

            dmd_register_installation($rootDir, [
                'product_type'  => 'domydesk',
                'instance_uid'  => $idDmd,
                'instance_name' => 'DoMyDesk',
                'admin_email'   => $email,
                'admin_prenom'  => $prenom,
                'admin_nom'     => $nom,
                'domain'        => $host,
                'install_url'   => $scheme . '://' . $host . $scriptDir,
                'version'       => dmd_read_domydesk_version($rootDir),
                'modules'       => dmd_collect_modules($rootDir),
                'services'      => [],
                'created_at'    => date('c'),
            ]);
        }

        $_SESSION['user'] = [
            'email'       => $email,
            'prenom'      => $prenom,
            'nom'         => $nom,
            'role_system' => 'superadmin',
        ];

        dmd_disable_installer_after_response();
        dmd_redirect('/domydesk/login.php');
    }
}

$csrfToken = $_SESSION['install_csrf'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Installation DoMyDesk</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root{--bg:#090b14;--panel:rgba(12,16,31,.72);--panel2:rgba(17,23,43,.92);--border:rgba(255,255,255,.12);--border2:rgba(255,255,255,.22);--text:#f7f8ff;--muted:rgba(247,248,255,.68);--accent:#ff3b30;--blue:#7aa2ff;--green:#37d67a;--shadow:0 24px 80px rgba(0,0,0,.46);--radius:28px}*{box-sizing:border-box}body{min-height:100vh;margin:0;color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;background:radial-gradient(circle at 20% 10%,rgba(122,162,255,.22),transparent 30%),radial-gradient(circle at 80% 20%,rgba(255,59,48,.18),transparent 32%),radial-gradient(circle at 55% 95%,rgba(55,214,122,.14),transparent 28%),var(--bg);overflow-x:hidden}body:before,body:after{content:"";position:fixed;width:520px;height:520px;border-radius:999px;filter:blur(12px);opacity:.36;pointer-events:none;z-index:0;animation:orb 16s ease-in-out infinite alternate}body:before{top:-170px;left:-130px;background:radial-gradient(circle,rgba(122,162,255,.35),transparent 68%)}body:after{right:-180px;bottom:-210px;background:radial-gradient(circle,rgba(255,59,48,.28),transparent 70%);animation-delay:-6s}@keyframes orb{from{transform:translate3d(0,0,0) scale(1)}to{transform:translate3d(44px,34px,0) scale(1.08)}}.bg{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none;opacity:.42;mask-image:linear-gradient(90deg,transparent,#000 18%,#000 82%,transparent)}.track{position:absolute;display:flex;gap:14px;width:max-content;animation:marquee 34s linear infinite;white-space:nowrap}.track:nth-child(1){top:9%;left:0}.track:nth-child(2){top:43%;right:0;animation-name:marqueeReverse;animation-duration:42s}.track:nth-child(3){bottom:9%;left:0;animation-duration:38s}.chip{display:inline-flex;align-items:center;min-height:40px;padding:0 16px;border:1px solid rgba(255,255,255,.11);border-radius:999px;background:rgba(255,255,255,.055);color:rgba(255,255,255,.66);backdrop-filter:blur(10px);box-shadow:0 12px 28px rgba(0,0,0,.16);font-size:14px}@keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}@keyframes marqueeReverse{from{transform:translateX(0)}to{transform:translateX(50%)}}.shell{position:relative;z-index:2;min-height:100vh;display:grid;grid-template-columns:minmax(280px,.95fr) minmax(320px,560px);gap:clamp(24px,4vw,64px);align-items:center;width:min(1180px,calc(100% - 36px));margin:0 auto;padding:42px 0}.hero{padding:clamp(10px,2vw,22px)}.kicker{display:inline-flex;align-items:center;gap:9px;padding:8px 12px;border:1px solid var(--border);border-radius:999px;background:rgba(255,255,255,.06);color:var(--muted);backdrop-filter:blur(18px);font-size:14px}.kicker:before{content:"";width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 0 6px rgba(55,214,122,.12)}.hero h1{margin:22px 0 14px;font-size:clamp(40px,7vw,82px);line-height:.95;letter-spacing:-.06em}.hero h1 span{display:block;color:transparent;background:linear-gradient(90deg,#fff,#b9c7ff,#ffb7b2);-webkit-background-clip:text;background-clip:text}.hero p{max-width:620px;margin:0;color:var(--muted);font-size:clamp(16px,1.7vw,20px);line-height:1.65}.features{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:28px;max-width:620px}.feature{border:1px solid var(--border);background:rgba(255,255,255,.055);border-radius:20px;padding:16px;backdrop-filter:blur(16px)}.feature strong{display:block;margin-bottom:5px;font-size:15px}.feature span{display:block;color:var(--muted);font-size:13px;line-height:1.45}.card{position:relative;border:1px solid var(--border2);border-radius:var(--radius);background:linear-gradient(180deg,rgba(255,255,255,.105),rgba(255,255,255,.055)),var(--panel);box-shadow:var(--shadow);backdrop-filter:blur(28px);overflow:hidden}.card:before{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 0%,rgba(255,255,255,.14) 42%,transparent 58%);transform:translateX(-100%);animation:shine 5.8s ease-in-out infinite;pointer-events:none}@keyframes shine{0%,62%{transform:translateX(-105%)}100%{transform:translateX(105%)}}.cardHead{position:relative;padding:26px 26px 18px;border-bottom:1px solid var(--border)}.cardHead small{display:inline-flex;margin-bottom:10px;color:var(--muted);letter-spacing:.12em;text-transform:uppercase;font-size:11px;font-weight:800}.cardHead h2{margin:0;font-size:clamp(24px,3.2vw,34px);letter-spacing:-.03em}.cardHead p{margin:10px 0 0;color:var(--muted);line-height:1.55;font-size:14px}.form{position:relative;padding:24px 26px 26px}.alert{margin:0 0 16px;padding:12px 14px;border-radius:16px;border:1px solid rgba(255,80,80,.38);background:rgba(255,80,80,.12);color:#ffd7d7;line-height:1.45;font-size:14px}.field{display:grid;gap:8px;margin-bottom:15px}.field label{color:rgba(255,255,255,.88);font-size:13px;font-weight:750}.field input{width:100%;height:48px;padding:0 15px;border-radius:16px;border:1px solid var(--border);background:rgba(255,255,255,.075);color:var(--text);outline:none;transition:border-color .18s,box-shadow .18s,background .18s;font:inherit}.field input::placeholder{color:rgba(255,255,255,.38)}.field input:focus{border-color:rgba(122,162,255,.72);box-shadow:0 0 0 4px rgba(122,162,255,.16);background:rgba(255,255,255,.1)}.role{display:inline-flex;align-items:center;min-height:42px;padding:0 14px;border:1px solid rgba(55,214,122,.3);border-radius:999px;background:rgba(55,214,122,.11);color:#c9ffd9;font-size:13px;font-weight:800}.declareWrap{position:relative;margin:16px 0 18px}.declare{display:flex;align-items:center;gap:13px;padding:15px;border:1px solid var(--border);border-radius:19px;background:rgba(255,255,255,.06);cursor:pointer;transition:border-color .18s,background .18s,transform .18s}.declare:hover,.declare:focus-within{border-color:rgba(122,162,255,.56);background:rgba(122,162,255,.10);transform:translateY(-1px)}.declare input{width:20px;height:20px;accent-color:var(--accent);flex:0 0 auto}.declare strong{display:block;font-size:14px}.declare span span{display:block;margin-top:3px;color:var(--muted);font-size:12px;line-height:1.4}.bubble{position:absolute;left:50%;bottom:calc(100% + 12px);width:min(430px,92vw);transform:translateX(-50%) translateY(8px);padding:15px 16px;border:1px solid rgba(122,162,255,.32);border-radius:18px;background:rgba(10,15,31,.96);box-shadow:0 22px 60px rgba(0,0,0,.44);color:var(--text);opacity:0;pointer-events:none;transition:opacity .18s,transform .18s;z-index:10}.bubble:after{content:"";position:absolute;left:50%;top:100%;transform:translateX(-50%);border-width:9px 9px 0 9px;border-style:solid;border-color:rgba(10,15,31,.96) transparent transparent transparent}.declareWrap:hover .bubble,.declareWrap:focus-within .bubble,.declareWrap.is-visible .bubble{opacity:1;transform:translateX(-50%) translateY(0)}.bubble h3{margin:0 0 7px;font-size:15px}.bubble p{margin:0;color:var(--muted);font-size:13px;line-height:1.5}.submit{width:100%;min-height:52px;border:0;border-radius:18px;color:#fff;cursor:pointer;font:inherit;font-weight:900;background:linear-gradient(135deg,var(--accent),#ff6a5f 48%,#7aa2ff);box-shadow:0 18px 42px rgba(255,59,48,.22);transition:transform .16s,filter .16s,box-shadow .16s}.submit:hover{filter:brightness(1.06);transform:translateY(-1px);box-shadow:0 22px 54px rgba(255,59,48,.28)}.submit:active{transform:translateY(0)}.footnote{margin:14px 0 0;color:rgba(255,255,255,.48);font-size:12px;line-height:1.45;text-align:center}@media(max-width:940px){.shell{grid-template-columns:1fr;align-items:start;padding:28px 0}.hero{text-align:center}.hero p,.features{margin-left:auto;margin-right:auto}}@media(max-width:620px){.features{grid-template-columns:1fr}.cardHead,.form{padding-left:18px;padding-right:18px}.bubble{left:0;transform:translateY(8px)}.declareWrap:hover .bubble,.declareWrap:focus-within .bubble,.declareWrap.is-visible .bubble{transform:translateY(0)}.bubble:after{left:24px;transform:none}}@media(prefers-reduced-motion:reduce){*,*:before,*:after{animation-duration:.001ms!important;animation-iteration-count:1!important;scroll-behavior:auto!important}}
    </style>
</head>
<body>
    <div class="bg" aria-hidden="true">
        <div class="track"><span class="chip">📌 TodoList partagé</span><span class="chip">📄 PDF View</span><span class="chip">🖥️ Proxmox</span><span class="chip">🏠 Home Assistant</span><span class="chip">📰 Actualités</span><span class="chip">🔐 Coffre personnel</span><span class="chip">🌐 Accès NAS</span><span class="chip">📊 Infra</span><span class="chip">📌 TodoList partagé</span><span class="chip">📄 PDF View</span><span class="chip">🖥️ Proxmox</span><span class="chip">🏠 Home Assistant</span><span class="chip">📰 Actualités</span><span class="chip">🔐 Coffre personnel</span><span class="chip">🌐 Accès NAS</span><span class="chip">📊 Infra</span></div>
        <div class="track"><span class="chip">Un bureau web privé</span><span class="chip">Modules installables</span><span class="chip">Données chez vous</span><span class="chip">Dashboard personnalisable</span><span class="chip">Market de mises à jour</span><span class="chip">Support optionnel</span><span class="chip">Un bureau web privé</span><span class="chip">Modules installables</span><span class="chip">Données chez vous</span><span class="chip">Dashboard personnalisable</span><span class="chip">Market de mises à jour</span><span class="chip">Support optionnel</span></div>
        <div class="track"><span class="chip">⚙️ Paramètres centralisés</span><span class="chip">🧩 Modules métier</span><span class="chip">👥 Utilisateurs</span><span class="chip">🎨 Thèmes</span><span class="chip">🚀 Updates</span><span class="chip">🛡️ Auto-hébergement</span><span class="chip">⚙️ Paramètres centralisés</span><span class="chip">🧩 Modules métier</span><span class="chip">👥 Utilisateurs</span><span class="chip">🎨 Thèmes</span><span class="chip">🚀 Updates</span><span class="chip">🛡️ Auto-hébergement</span></div>
    </div>

    <main class="shell">
        <section class="hero">
            <div class="kicker">Installation sécurisée</div>
            <h1>Bienvenue dans <span>DoMyDesk</span></h1>
            <p>Créez le premier Superadmin de votre bureau web privé. Il faudra utiliser ce compte Superadmin uniquement pour la gestion d'administration, pour un utilisateur Admin de production il faudra créer un autre utilisateur. N'oubliez pas d'activer le MFA pour tous les comptes admins & utilisateurs (SuperAdmin en priorité). DoMyDesk centralise vos modules, vos liens, vos outils, vos documents et vos services maison dans une interface personnalisable.</p>

            <div class="features">
                <div class="feature"><strong>Modules</strong><span>Ajoutez des outils comme TodoList, PDF View, Proxmox, HA ou Infra.</span></div>
                <div class="feature"><strong>Données locales</strong><span>Vos profils et réglages restent dans votre installation.</span></div>
                <div class="feature"><strong>Market</strong><span>Préparez l’installation de modules et de mises à jour propres.</span></div>
				<div class="feature"><strong>MFA</strong><span>Activez la double authentification pour tous les comptes si cela est possible, pour le configurer allez dans administration, sécurité & administration, Identité et MFA .</span></div>
				<div class="feature"><strong>LDAPS</strong><span>Synchronisez votre AD à DoMyDesk pour facilité vos moyens de vous authentifier à votre compte DoMyDesk.</span></div>
                <div class="feature"><strong>Support</strong><span>Déclarez l’installation seulement si vous voulez le suivi centralisé.</span></div>
            </div>
        </section>

        <section class="card" aria-label="Formulaire d'installation DoMyDesk">
            <div class="cardHead">
                <small>Premier démarrage</small>
                <h2>Créer l’administrateur</h2>
                <p>Cet utilisateur sera le propriétaire initial de l’instance et disposera du rôle Superadmin pour les opérations système sensibles.</p>
            </div>

            <form class="form" method="POST" action="" autocomplete="on">
                <input type="hidden" name="csrf" value="<?= dmd_h($csrfToken) ?>">

                <?php if ($errors): ?>
                    <div class="alert">
                        <?php foreach ($errors as $error): ?>
                            <div><?= dmd_h($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="field"><label for="email">Email administrateur</label><input id="email" type="email" name="email" placeholder="admin@exemple.com" required value="<?= dmd_h($_POST['email'] ?? '') ?>"></div>
                <div class="field"><label for="prenom">Prénom</label><input id="prenom" type="text" name="prenom" placeholder="Sébastien" value="<?= dmd_h($_POST['prenom'] ?? '') ?>"></div>
                <div class="field"><label for="nom">Nom</label><input id="nom" type="text" name="nom" placeholder="Dupont" value="<?= dmd_h($_POST['nom'] ?? '') ?>"></div>
                <div class="field"><label>Rôle système</label><div class="role">Superadministrateur</div></div>
                <div class="field"><label for="motdepasse">Mot de passe</label><input id="motdepasse" type="password" name="motdepasse" placeholder="Définir un mot de passe" required></div>

                <div class="declareWrap" id="declareWrap">
                    <div class="bubble" id="declareBubble" role="status" aria-live="polite">
                        <h3>Déclarer l’installation de DoMyDesk</h3>
                        <p>Option facultative : si vous cochez cette case, l’email administrateur, l’ID unique de l’installation et la liste des modules activés seront transmis à synohomes.com pour faciliter le support, le suivi des versions et les mises à jour. Sans cette option, aucune donnée n’est envoyée automatiquement.</p>
                    </div>

                    <label class="declare" for="share_install">
                        <input type="checkbox" id="share_install" name="share_install" value="1" <?= !empty($_POST['share_install']) ? 'checked' : '' ?>>
                        <span><strong>Déclarer l’installation de DoMyDesk</strong><span>Facultatif : utile pour le support centralisé, le suivi des versions et les mises à jour.</span></span>
                    </label>
                </div>

                <button class="submit" type="submit">Créer le Superadmin et terminer l’installation</button>
                <p class="footnote">Après installation réussie, ce fichier tente de se supprimer automatiquement. Si la suppression échoue, le verrou d’installation bloque quand même son réemploi.</p>
            </form>
        </section>
    </main>

    <script>
        (function(){
            const wrap = document.getElementById('declareWrap');
            const checkbox = document.getElementById('share_install');
            if (!wrap || !checkbox) return;
            let timer = null;
            function showInfo(){
                wrap.classList.add('is-visible');
                clearTimeout(timer);
                timer = setTimeout(function(){ wrap.classList.remove('is-visible'); }, 4500);
            }
            wrap.addEventListener('mouseenter', showInfo);
            checkbox.addEventListener('focus', showInfo);
            checkbox.addEventListener('click', showInfo);
        })();
    </script>
</body>
</html>
