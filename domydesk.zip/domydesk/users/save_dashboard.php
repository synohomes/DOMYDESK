<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (empty($_SESSION['user']['email'])) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'unauthorized'));
    exit;
}

$email = basename((string)$_SESSION['user']['email']);
$userDir = __DIR__ . '/profiles/' . $email;

if (!is_dir($userDir)) {
    @mkdir($userDir, 0775, true);
}

$data = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_json'));
    exit;
}

/* ==========================================================
   Quick-Session
   Même moteur de dashboard, destination différente.
   Le JSON Quick-Session conserve uniquement les infos utiles
   au placement des modules, sans recopier leur contenu.
   ========================================================== */
if (!empty($_GET['quick_session'])) {
    require_once dirname(__DIR__) . '/core/dmd_security.php';
    require_once dirname(__DIR__) . '/Quick-Session/dmd_quick_session.php';

    if (!dmd_csrf_validate(dmd_csrf_request_token($data), 'quick-session')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'csrf_invalid'));
        exit;
    }

    if (!dmd_qs_save_modules($email, $data)) {
        http_response_code(409);
        echo json_encode(array('ok' => false, 'error' => 'no_active_quick_session'));
        exit;
    }

    echo json_encode(array('ok' => true, 'quick_session' => true));
    exit;
}

/* ==========================================================
   Dashboard normal
   ========================================================== */
$dashboardName = isset($_GET['dashboard']) ? (string)$_GET['dashboard'] : 'dashboard';
$dashboardName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $dashboardName);
if ($dashboardName === '') {
    $dashboardName = 'dashboard';
}

$dashboardFile = $userDir . '/' . $dashboardName . '.json';
$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

if ($json === false || @file_put_contents($dashboardFile, $json, LOCK_EX) === false) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'save_failed'));
    exit;
}

echo json_encode(array('ok' => true, 'quick_session' => false));
