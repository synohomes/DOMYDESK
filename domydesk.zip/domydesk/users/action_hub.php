<?php
// Compatibilité des anciens appels : le service officiel vit désormais dans /ActionHub/.
require dirname(__DIR__) . '/ActionHub/api.php';
