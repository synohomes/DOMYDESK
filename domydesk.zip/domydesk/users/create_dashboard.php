<?php
session_start();
require_once dirname(__DIR__) . '/core/dmd_ui_features.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (empty($_SESSION['user']['email'])) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'unauthorized'));
    exit;
}

$payload = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_json'));
    exit;
}

$rawName = trim((string)($payload['name'] ?? ''));
$name = preg_replace('/[^a-zA-Z0-9_-]/', '_', $rawName);
$name = trim((string)$name, '_-');
if ($name === '') {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_name'));
    exit;
}
$name = substr($name, 0, 64);

$email = basename((string)$_SESSION['user']['email']);
$dir = __DIR__ . '/profiles/' . $email;
if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'profile_dir_missing'));
    exit;
}

$listFile = $dir . '/dashboards.json';
$dashboards = array('dashboard');
if (is_file($listFile)) {
    $decoded = json_decode((string)@file_get_contents($listFile), true);
    if (is_array($decoded) && $decoded) {
        $dashboards = array_values(array_unique(array_filter(array_map(function ($item) {
            $item = preg_replace('/[^a-zA-Z0-9_-]/', '_', (string)$item);
            return $item !== '' ? $item : null;
        }, $decoded))));
    }
}
if (!$dashboards) $dashboards = array('dashboard');

$exists = in_array($name, $dashboards, true);
$dashboardLimit = dmd_ui_dashboard_limit();
if (!$exists) {
    if (dmd_ui_dashboard_limit_reached(count($dashboards))) {
        http_response_code(409);
        echo json_encode(array(
            'ok' => false,
            'error' => 'dashboard_limit',
            'limit' => $dashboardLimit,
            'current' => count($dashboards),
        ));
        exit;
    }
    $dashboards[] = $name;
}

$dashboardFile = $dir . '/' . $name . '.json';
$current = array();
if (is_file($dashboardFile)) {
    $decoded = json_decode((string)@file_get_contents($dashboardFile), true);
    if (is_array($decoded)) $current = $decoded;
}

$known = array();
foreach ($current as $item) {
    if (is_array($item) && !empty($item['id'])) {
        $known[(string)$item['id']] = true;
    }
}

$modulesAdded = array();
$requestedModules = isset($payload['modules']) && is_array($payload['modules']) ? $payload['modules'] : array();
foreach ($requestedModules as $moduleId) {
    $moduleId = preg_replace('/[^a-zA-Z0-9._-]/', '', trim((string)$moduleId));
    if ($moduleId === '' || isset($known[$moduleId])) continue;

    $index = count($current);
    $col = $index % 3;
    $row = (int)floor($index / 3);

    $current[] = array(
        'id' => $moduleId,
        'title' => $moduleId,
        'shape' => 'square',
        'x' => 20 + ($col * 430),
        'y' => 20 + ($row * 390),
        'width' => 410,
        'height' => 360,
    );
    $known[$moduleId] = true;
    $modulesAdded[] = $moduleId;
}

$listJson = json_encode($dashboards, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$dashJson = json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

if (
    $listJson === false ||
    $dashJson === false ||
    @file_put_contents($listFile, $listJson, LOCK_EX) === false ||
    @file_put_contents($dashboardFile, $dashJson, LOCK_EX) === false
) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'write_failed'));
    exit;
}

echo json_encode(array(
    'ok' => true,
    'name' => $name,
    'created' => !$exists,
    'existing' => $exists,
    'modules_added' => $modulesAdded,
    'dashboard_limit' => $dashboardLimit,
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
