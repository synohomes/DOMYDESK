<?php
// Compatibilité des anciens appels : le service officiel vit désormais dans /Quick-Session/.
require dirname(__DIR__) . '/Quick-Session/api.php';
