<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once dirname(__DIR__) . '/core/dmd_permissions.php';
require_once dirname(__DIR__) . '/core/dmd_system_services.php';

$email = isset($_SESSION['user']['email']) ? dmd_sys_safe_email($_SESSION['user']['email']) : '';
if ($email === '' || !is_dir(dirname(__DIR__) . '/users/profiles/' . $email)) {
    http_response_code(401);
    echo json_encode(array('success' => false, 'error' => 'not_authenticated'));
    exit;
}

$action = isset($_GET['action']) ? (string)$_GET['action'] : (isset($_POST['action']) ? (string)$_POST['action'] : 'count');

if ($action === 'count') {
    $state = dmd_notification_state($email);
    echo json_encode(array('success' => true, 'unread' => (int)$state['unread']), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($action === 'list') {
    echo json_encode(array(
        'success' => true,
        'unread' => (int)dmd_notification_state($email)['unread'],
        'role_system' => dmd_sys_current_role(),
        'items' => dmd_notification_list($email, 100),
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('success' => false, 'error' => 'method_not_allowed'));
    exit;
}

$token = isset($_POST['csrf_token']) ? (string)$_POST['csrf_token'] : '';
if (empty($_SESSION['csrf_notifications']) || !hash_equals((string)$_SESSION['csrf_notifications'], $token)) {
    http_response_code(403);
    echo json_encode(array('success' => false, 'error' => 'invalid_token'));
    exit;
}

if ($action === 'read') {
    $id = isset($_POST['id']) ? (string)$_POST['id'] : '';
    $ok = dmd_notification_mark_read($email, $id);
    echo json_encode(array('success' => $ok, 'unread' => (int)dmd_notification_state($email)['unread']));
    exit;
}

if ($action === 'read_all') {
    $ok = dmd_notification_mark_all_read($email);
    echo json_encode(array('success' => $ok, 'unread' => (int)dmd_notification_state($email)['unread']));
    exit;
}

if ($action === 'clear') {
    $ok = dmd_notification_clear($email);
    echo json_encode(array('success' => $ok, 'unread' => 0));
    exit;
}

http_response_code(400);
echo json_encode(array('success' => false, 'error' => 'unknown_action'));
