<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (empty($_SESSION['user']['email'])) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'unauthorized'));
    exit;
}

$email = basename((string)$_SESSION['user']['email']);
$userDir = __DIR__ . '/profiles/' . $email;
$stateFile = $userDir . '/workspace_state.json';

if (!is_dir($userDir) && !@mkdir($userDir, 0775, true) && !is_dir($userDir)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'profile_dir_failed'));
    exit;
}

function dmd_ws_empty_state() {
    return array(
        'schema' => 1,
        'modules' => array(),
        'module_defaults' => array(),
        'popups' => array(),
        'remotes' => array()
    );
}

function dmd_ws_safe_key($value, $fallback) {
    $value = trim((string)$value);
    $value = preg_replace('/[^a-zA-Z0-9._:@-]+/', '_', $value);
    $value = trim((string)$value, '_');
    if ($value === '') {
        return $fallback;
    }
    return substr($value, 0, 180);
}

function dmd_ws_num($value, $min, $max, $fallback) {
    if (!is_numeric($value)) {
        return $fallback;
    }
    $number = (float)$value;
    if ($number < $min) $number = $min;
    if ($number > $max) $number = $max;
    return round($number, 2);
}

function dmd_ws_geometry($raw) {
    if (!is_array($raw)) {
        return null;
    }

    $width = dmd_ws_num(isset($raw['width']) ? $raw['width'] : null, 120, 12000, null);
    $height = dmd_ws_num(isset($raw['height']) ? $raw['height'] : null, 90, 12000, null);

    if ($width === null || $height === null) {
        return null;
    }

    return array(
        'x' => dmd_ws_num(isset($raw['x']) ? $raw['x'] : 0, -12000, 120000, 0),
        'y' => dmd_ws_num(isset($raw['y']) ? $raw['y'] : 0, -12000, 120000, 0),
        'width' => $width,
        'height' => $height,
        'updated_at' => time()
    );
}

function dmd_ws_read_state($file) {
    $empty = dmd_ws_empty_state();
    if (!is_file($file)) {
        return $empty;
    }

    $raw = @file_get_contents($file);
    $data = $raw !== false ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return $empty;
    }

    foreach (array('modules', 'module_defaults', 'popups', 'remotes') as $key) {
        if (!isset($data[$key]) || !is_array($data[$key])) {
            $data[$key] = array();
        }
    }
    $data['schema'] = 1;
    return $data;
}

function dmd_ws_write_state($file, $state) {
    $json = json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }

    $tmp = $file . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        return false;
    }
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode(array('ok' => true, 'state' => dmd_ws_read_state($stateFile)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('ok' => false, 'error' => 'method_not_allowed'));
    exit;
}

$payload = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_json'));
    exit;
}

$type = isset($payload['type']) ? (string)$payload['type'] : '';
$geometry = dmd_ws_geometry(isset($payload['geometry']) ? $payload['geometry'] : null);
if (!in_array($type, array('module', 'popup', 'remote'), true)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_payload'));
    exit;
}
if ($type !== 'remote' && $geometry === null) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_payload'));
    exit;
}

$lockFile = $stateFile . '.lock';
$lock = @fopen($lockFile, 'c+');
if (!$lock || !@flock($lock, LOCK_EX)) {
    if ($lock) @fclose($lock);
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'lock_failed'));
    exit;
}

$state = dmd_ws_read_state($stateFile);

if ($type === 'module') {
    $module = dmd_ws_safe_key(isset($payload['module']) ? $payload['module'] : '', 'module');
    $dashboard = dmd_ws_safe_key(isset($payload['dashboard']) ? $payload['dashboard'] : '', 'dashboard');

    if (!isset($state['modules'][$dashboard]) || !is_array($state['modules'][$dashboard])) {
        $state['modules'][$dashboard] = array();
    }
    $state['modules'][$dashboard][$module] = $geometry;

    // Le dernier format du module sert de repli sur un autre dashboard.
    $state['module_defaults'][$module] = array(
        'width' => $geometry['width'],
        'height' => $geometry['height'],
        'updated_at' => $geometry['updated_at']
    );
} elseif ($type === 'popup') {
    $popup = dmd_ws_safe_key(isset($payload['popup']) ? $payload['popup'] : '', 'popup');
    $state['popups'][$popup] = $geometry;
} else {
    $agent = dmd_ws_safe_key(isset($payload['agent_id']) ? $payload['agent_id'] : '', '');
    if ($agent === '') {
        @flock($lock, LOCK_UN);
        @fclose($lock);
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'invalid_agent'));
        exit;
    }

    $open = !array_key_exists('open', $payload) || !empty($payload['open']);
    if (!$open) {
        unset($state['remotes'][$agent]);
    } else {
        $existing = isset($state['remotes'][$agent]) && is_array($state['remotes'][$agent])
            ? $state['remotes'][$agent]
            : array();

        $entry = array(
            'agent_id' => $agent,
            'control' => !empty($payload['control']),
            'updated_at' => time()
        );

        if ($geometry !== null) {
            $entry['geometry'] = $geometry;
        } elseif (isset($existing['geometry']) && is_array($existing['geometry'])) {
            $entry['geometry'] = $existing['geometry'];
        }

        $state['remotes'][$agent] = $entry;
    }
}

$ok = dmd_ws_write_state($stateFile, $state);
@flock($lock, LOCK_UN);
@fclose($lock);

if (!$ok) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'save_failed'));
    exit;
}

echo json_encode(array('ok' => true), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
