<?php
session_start();

/* ==========================================================
   Thème utilisateur
   - utilisateur connecté : users/profiles/[email]/theme.json
   - visiteur/non connecté : thème default
   ========================================================== */
$theme = 'default';

if (!empty($_SESSION['user']['email'])) {
    $email = (string) $_SESSION['user']['email'];
    $themeFile = __DIR__ . '/users/profiles/' . $email . '/theme.json';

    if (is_file($themeFile)) {
        $themeData = json_decode((string) file_get_contents($themeFile), true);
        $requestedTheme = basename((string) ($themeData['theme'] ?? ''));

        if (
            $requestedTheme !== '' &&
            is_file(__DIR__ . '/theme/' . $requestedTheme . '/style.css')
        ) {
            $theme = $requestedTheme;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>DoMyDesk - Portail</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">

  
</head>

<body>
<?php include 'header.php'; ?>

<main class="dmd-home">

  <section class="hero" aria-labelledby="home-title">
    <div>
      <p class="eyebrow">Portail public DomyCo</p>

      <h1 id="home-title">
        <span>DoMyBox, DoMyDesk, DoMySocial, DoMyCore.</span>
      </h1>

      <p class="hero-lead">
        DoMyDesk est le bureau virtuel hébergé sur un serveur WEB.
        Il permet de découvrir, tester et utiliser des modules depuis un simple navigateur :
        outils personnels, services privés, supervision, accès distant, sauvegarde, réseau social privé,
        administration, procédures, PRA et futurs modules communautaires.
        Ce portail est ouvert aux visiteurs pour comprendre le projet, essayer l’interface
        et rejoindre l’écosystème comme utilisateur, testeur, développeur ou membre de la communauté.
      </p>

      <div class="hero-actions">
        <a class="home-btn primary" href="login.php">VOUS CONNECTER</a>
        <a class="home-btn" href="register.php">VOUS ENREGISTRER</a>
        <a class="home-btn" href="https://www.youtube.com/watch?v=E3nn6WN2faM&list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM">VISIONNER NOS VIDÉOS</a>
        <a class="home-btn" href="https://synohomes.com">VISITER SYNOHOMES / DOMYDESK</a>
		<a class="home-btn" href="https://github.com/synohomes/newsdomydesk/raw/refs/heads/main/domydesk.zip">TELECHARGER DOMYDESK</a>

      </div>
    </div>

    <div class="hero-visual portal-visual" aria-label="Témoignages DomyCore">
      <div class="mobile-demo">
        <div class="mobile-top">
          <span class="mobile-title">Ils utilisent DomyCo</span>
          <span class="mobile-status"><span></span><span></span><span></span></span>
        </div>

        <div class="mobile-screen">
          <span class="mobile-chip">DoMyDesk</span>
          <span class="mobile-chip">DoMySocial</span>
          <span class="mobile-chip">DoMyBox</span>
          <span class="mobile-chip">PRA</span>

          <div class="bubble-track">
            <article class="talk-bubble">
              <strong>Télétravail</strong>
              <p>“Passer du travail au privé en deux clics, c’est génial. Je garde mes outils pro dans DoMyDesk et mon espace perso dans DoMySocial.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Voyage & souvenirs</strong>
              <p>“J’ai passé des vacances incroyables aux USA. Toutes mes photos et vidéos sont restées sur mon réseau social privé, sans dépendre d’une plateforme publique.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Entreprise</strong>
              <p>“J’ai acheté la DomyBox complète pour mon entreprise. Mon IT était heureux de gérer l’infra, les comptes, les accès et les modules au même endroit.”</p>
            </article>

            <article class="talk-bubble">
              <strong>PRA informatique</strong>
              <p>“Le mode PRA complet est un gros plus. En cas de panne, on sait quoi contrôler, quoi relancer et comment garder les services importants disponibles.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Support IT</strong>
              <p>“Wake-on-LAN, SSH, supervision, NAS, procédures et accès distant : tout est regroupé dans un bureau web simple à prendre en main.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Association</strong>
              <p>“On centralise les membres, les documents, les outils et les procédures. Même les personnes moins techniques comprennent rapidement où aller.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Famille</strong>
              <p>“Avec DoMySocial, on garde nos albums, nos souvenirs et nos échanges dans un espace privé. C’est notre petit réseau social à nous.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Développeur</strong>
              <p>“Le système de modules donne envie de contribuer : je peux créer un outil, le proposer au market et le partager avec la communauté.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Administration</strong>
              <p>“Comptes, thèmes, modules, actualités et mises à jour : DoMyDesk rend la DomyBox plus simple à administrer au quotidien.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Utilisateur DomyBox</strong>
              <p>“J’active seulement ce dont j’ai besoin : fichiers, sauvegarde, monitoring, accès distant, minuteur, outils métiers… mon bureau reste propre.”</p>
            </article>

            <article class="talk-bubble">
              <strong>Utilisateur DomyBox</strong>
              <p>“J’ai remplacé ma box par cette DomyBox. Routeur, firewall, NAS, DHCP, DNS, PXE : tout devient accessible depuis le dashboard.”</p>
            </article>
          </div>

          <div class="mobile-bottom">
            <span class="mobile-nav-item active">Desk</span>
            <span class="mobile-nav-item">Social</span>
            <span class="mobile-nav-item">Box</span>
			<span class="mobile-nav-item">CMS</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="stats" aria-label="Découverte de DoMyDesk">
    <article class="stat">
      <strong>Portail</strong>
      <span>Une entrée publique pour présenter DoMyDesk et guider les visiteurs.</span>
    </article>

    <article class="stat">
      <strong>DoMyBox</strong>
      <span>Un hébergement local ou privé pour centraliser ses services numériques.</span>
    </article>

    <article class="stat">
      <strong>Modules</strong>
      <span>Des outils activables selon les besoins : perso, pro, IT ou communauté.</span>
    </article>

    <article class="stat">
      <strong>Communauté</strong>
      <span>Un projet pensé pour accueillir testeurs, utilisateurs et développeurs.</span>
    </article>
  </section>

  <div class="home-grid">
    <section class="panel" aria-labelledby="features-title">
      <div class="panel-head">
        <p class="panel-kicker">Premiers pas</p>
        <h2 class="panel-title" id="features-title">Comment utiliser ce portail ?</h2>
        <p class="panel-desc">
          Cette page sert de point d’entrée pour découvrir DoMyDesk, comprendre la logique des modules
          et accéder rapidement à son bureau, à son compte et aux outils installés sur la DomyBox.
        </p>
      </div>

      <div class="feature-list">
        <article class="feature">
          <div class="ico">①</div>
          <div>
            <h3>Entrer dans le bureau</h3>
            <p>
              Clique sur “Vous connecter” pour ouvrir le tableau de bord.
              C’est l’espace principal où apparaissent les modules activés sous forme de fenêtres ou de vignettes.
            </p>
          </div>
        </article>

        <article class="feature">
          <div class="ico">②</div>
          <div>
            <h3>Découvrir les modules</h3>
            <p>
              La page des modules permet de voir les outils disponibles sur la DomyBox :
              modules personnels, modules IT, modules communautaires, outils métiers ou services privés.
            </p>
          </div>
        </article>

        <article class="feature">
          <div class="ico">③</div>
          <div>
            <h3>Activer un module installé</h3>
            <p>
              Un module téléchargé ou présent sur la DomyBox doit être activé pour ton compte.
              Une fois activé, il devient disponible dans ton bureau DoMyDesk.
            </p>
          </div>
        </article>

        <article class="feature">
          <div class="ico">④</div>
          <div>
            <h3>Personnaliser son compte</h3>
            <p>
              Depuis “Gérer mon compte”, tu peux modifier ton profil, ton mot de passe,
              ton avatar, ton thème et certains réglages selon les droits de ton utilisateur.
            </p>
          </div>
        </article>

        <article class="feature">
          <div class="ico">⑤</div>
          <div>
            <h3>Comprendre DomyCore</h3>
            <p>
              DoMyDesk est le centre de contrôle. DoMySocial apporte la couche sociale privée.
              DomyBox héberge les services. DomyCore relie l’ensemble dans une logique simple et évolutive.
            </p>
          </div>
        </article>

        <article class="feature">
          <div class="ico">⑥</div>
          <div>
            <h3>Participer au projet</h3>
            <p>
              Les visiteurs peuvent devenir utilisateurs, testeurs, développeurs ou membres de la communauté.
              L’objectif est de faire évoluer les modules et les usages autour d’une base commune.
            </p>
          </div>
        </article>
      </div>
    </section>

    <section class="panel" aria-labelledby="actu-title">
      <div class="panel-head">
        <p class="panel-kicker">Actualités</p>
        <h2 class="panel-title" id="actu-title">Suivre l’évolution de DoMyDesk</h2>
        <p class="panel-desc">
          Retrouve ici les annonces, nouveautés, corrections, modules ajoutés et informations importantes
          autour de DoMyDesk, DomyBox, DoMySocial et DomyCore.
        </p>
      </div>

      <div class="news-toolbar">
        <span class="news-count" id="news-count">Chargement…</span>
      </div>

      <div id="news-container">
        <div class="loading-state">Chargement des actualités…</div>
      </div>

      <div class="pagination">
        <span class="page-indicator" id="page-indicator">Page 1</span>
        <div class="pagination-actions">
          <button id="prev-btn" disabled>Précédent</button>
          <button id="next-btn" disabled>Suivant</button>
        </div>
      </div>
    </section>
  </div>

  <div class="mini-footer">
    DoMyCo @ SynoHomes.
  </div>

</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const url = 'data/news/news.php';
  const container = document.getElementById('news-container');
  const count = document.getElementById('news-count');
  const indicator = document.getElementById('page-indicator');
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  const PAR_PAGE = 4;
  let data = [];
  let page = 1;

  function escapeHTML(s){
    return String(s ?? '')
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }

  function render(){
    container.innerHTML = '';

    if (!data.length){
      container.innerHTML = '<div class="empty-state">Aucune actualité pour le moment.</div>';
      count.textContent = '0 actualité';
      indicator.textContent = 'Page 1';
      prevBtn.disabled = true;
      nextBtn.disabled = true;
      return;
    }

    const totalPages = Math.max(1, Math.ceil(data.length / PAR_PAGE));
    const slice = data.slice((page - 1) * PAR_PAGE, page * PAR_PAGE);

    slice.forEach(n => {
      const auteur = n.auteur ? `<span class="news-pill">${escapeHTML(n.auteur)}</span>` : '';

      container.insertAdjacentHTML('beforeend', `
        <article class="news-card">
          <h3 class="news-title">${escapeHTML(n.titre || 'Actualité')}</h3>
          <div class="news-subtitle">${escapeHTML(n.soustitre || '')}</div>
          <div class="news-meta">
            <span class="news-pill">${escapeHTML(n.date || '')}</span>
            ${auteur}
          </div>
          <p class="news-description">${escapeHTML(n.description || '')}</p>
        </article>
      `);
    });

    count.textContent = data.length + (data.length > 1 ? ' actualités' : ' actualité');
    indicator.textContent = `Page ${page} / ${totalPages}`;
    prevBtn.disabled = page <= 1;
    nextBtn.disabled = page >= totalPages;
  }

  prevBtn.addEventListener('click', () => {
    if(page > 1){
      page--;
      render();
    }
  });

  nextBtn.addEventListener('click', () => {
    if(page * PAR_PAGE < data.length){
      page++;
      render();
    }
  });

  fetch(url)
    .then(r => {
      if(!r.ok) throw new Error('load');
      return r.json();
    })
    .then(json => {
      data = Array.isArray(json) ? json : [];
      render();
    })
    .catch(() => {
      container.innerHTML = '<div class="error-state">Impossible de charger les actualités.</div>';
      count.textContent = 'Erreur de chargement';
      prevBtn.disabled = true;
      nextBtn.disabled = true;
    });
});
</script>

</body>
</html>