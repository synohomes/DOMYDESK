<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once dirname(__DIR__, 2) . '/core/dmd_permissions.php';
require_once dirname(__DIR__, 2) . '/core/dmd_system_services.php';
require_once dirname(__DIR__, 2) . '/core/dmd_sources.php';
$email = $_SESSION['user']['email'] ?? '';
$prenom = $_SESSION['user']['prenom'] ?? 'Admin';
$currentProfile = $email !== '' ? dmd_read_profile($email) : [];

if (!dmd_is_system_admin_profile($currentProfile)) {
    echo "<div style='padding:20px;color:red'>⛔ Accès réservé aux administrateurs.</div>";
    return;
}

// Chemins
$baseDir = __DIR__;
$cfgFile = "$baseDir/newsconfig.json";
$storageBase = "$baseDir/add/";
@mkdir($storageBase, 0775, true);

// Chargement du thème
$theme = 'default';
$themePath = __DIR__ . "/../../users/profiles/$email/theme.json";
if (file_exists($themePath)) {
    $t = json_decode(file_get_contents($themePath), true);
    if (!empty($t['theme'])) $theme = basename($t['theme']);
}
echo "<link rel='stylesheet' href='theme/$theme/style.css'>";

// Traitement du mode
if (isset($_POST['news_mode'])) {
    file_put_contents($cfgFile, json_encode(['mode' => $_POST['news_mode']]));
    dmd_system_log('news_mode_updated', 'newsconfig.json', 'success', 'Mode des actualités modifié.', ['mode' => $_POST['news_mode']]);
    echo "<div style='color:green;padding:10px'>✔️ Mode enregistré.</div>";
}
$currentMode = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true)['mode'] ?? 'github' : 'github';

if (empty($_SESSION['csrf_news_sources'])) {
    $_SESSION['csrf_news_sources'] = bin2hex(random_bytes(32));
}
$newsRefreshMessage = '';
$newsRefreshError = '';
if (isset($_POST['refresh_official_news'])) {
    $token = (string)($_POST['csrf_news_sources'] ?? '');
    if (!hash_equals((string)($_SESSION['csrf_news_sources'] ?? ''), $token)) {
        $newsRefreshError = 'Rafraîchissement refusé : formulaire expiré ou invalide.';
    } else {
        $refreshOk = false;
        $refreshRaw = dmd_source_load_raw(dirname(__DIR__, 2), 'actus', true, $newsRefreshError, $refreshOk);
        if ($refreshOk && $refreshRaw !== false) {
            $newsRefreshMessage = 'Actualités officielles rafraîchies directement depuis GitHub.';
            $newsRefreshError = '';
        } elseif ($newsRefreshError === '') {
            $newsRefreshError = 'Rafraîchissement GitHub impossible. Le dernier cache valide est conservé.';
        }
    }
}

// Chargement d'une news pour modification
$editData = null;
$editFile = $_GET['edit'] ?? null;
if ($editFile && file_exists($editFile)) {
    $editData = json_decode(file_get_contents($editFile), true);
    $editData['_file'] = $editFile;
}

// Enregistrement d'une nouvelle news
if (isset($_POST['add_news']) && !empty($_POST['title']) && !empty($_POST['content'])) {
    $title = strip_tags($_POST['title']);
    $subtitle = strip_tags($_POST['subtitle'] ?? '');
    $author = strip_tags($prenom);
    $date = date('Y-m-d');
    $content = $_POST['content'];

    $year = date('Y');
    $month = date('m');
    $dir = "$storageBase/$year/$month";
    @mkdir($dir, 0775, true);

    $i = 1;
    while (file_exists("$dir/news$i.json")) $i++;
    $filePath = "$dir/news$i.json";

    $entry = [
        'title' => $title,
        'subtitle' => $subtitle,
        'date' => $date,
        'author' => $author,
        'content' => $content
    ];

    file_put_contents($filePath, json_encode($entry, JSON_PRETTY_PRINT));
    dmd_system_log('news_created', basename($filePath), 'success', 'Actualité locale ajoutée.', ['title' => $title]);
    echo "<div style='color:green;padding:10px'>✔️ News ajoutée avec succès.</div>";
}

// Enregistrement d'une modification
if (isset($_POST['update_news']) && !empty($_POST['file']) && file_exists($_POST['file'])) {
    $file = $_POST['file'];
    $updated = [
        'title' => strip_tags($_POST['title']),
        'subtitle' => strip_tags($_POST['subtitle'] ?? ''),
        'date' => $_POST['date'] ?? date('Y-m-d'),
        'author' => strip_tags($prenom),
        'content' => $_POST['content']
    ];
    file_put_contents($file, json_encode($updated, JSON_PRETTY_PRINT));
    dmd_system_log('news_updated', basename($file), 'success', 'Actualité locale modifiée.', ['title' => $updated['title']]);
    echo "<div style='color:green;padding:10px'>✏️ News modifiée.</div>";
    echo "<script>location.href='newscfg.php';</script>";
}
?>

<div class="section" style="margin:16px 0">
  <h2>📰 Configuration des actualités</h2>

  <!-- Mode -->
  <div class="section" style="margin-top:12px">
    <h3>Mode d'affichage</h3>
    <form method="post">
      <label>Afficher :</label>
      <select name="news_mode">
        <option value="github" <?= $currentMode === 'github' ? 'selected' : '' ?>>Actualités officielles (GitHub)</option>
        <option value="local"  <?= $currentMode === 'local'  ? 'selected' : '' ?>>Actualités locales internes</option>
      </select>
      <button type="submit">💾 Enregistrer</button>
    </form>
    <form method="post" action="?open=popup-news" style="margin-top:10px">
      <input type="hidden" name="csrf_news_sources" value="<?= htmlspecialchars($_SESSION['csrf_news_sources'], ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit" name="refresh_official_news" value="1">↻ Rafraîchir les actualités GitHub</button>
    </form>
    <?php if ($newsRefreshMessage !== ''): ?><div style="color:green;padding:10px">✔️ <?= htmlspecialchars($newsRefreshMessage, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($newsRefreshError !== ''): ?><div style="color:red;padding:10px">❌ <?= htmlspecialchars($newsRefreshError, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  </div>

  <!-- Formulaire -->
  <div class="section" style="margin-top:12px">
    <h3><?= $editData ? "✏️ Modifier la news" : "➕ Ajouter une news" ?></h3>
    <form method="post">
      <?php if (!empty($editData)): ?>
        <input type="hidden" name="update_news" value="1">
        <input type="hidden" name="file" value="<?= htmlspecialchars($editData['_file']) ?>">
      <?php else: ?>
        <input type="hidden" name="add_news" value="1">
      <?php endif; ?>

      <label>Titre :</label><br>
      <input type="text" name="title" style="width:100%" required value="<?= $editData['title'] ?? '' ?>"><br>

      <label>Sous-titre :</label><br>
      <input type="text" name="subtitle" style="width:100%" value="<?= $editData['subtitle'] ?? '' ?>"><br>

      <label>Date :</label><br>
      <input type="date" name="date" style="width:50%" value="<?= $editData['date'] ?? date('Y-m-d') ?>"><br>

      <label>Contenu :</label><br>
      <div contenteditable="true" id="editor" style="border:1px solid #ccc;padding:10px;background:#111;color:#eee;min-height:100px;">
        <?= $editData['content'] ?? '' ?>
      </div>
      <textarea name="content" id="content" style="display:none"></textarea>
      <br>

      <button onclick="saveEditorContent()" type="submit">
        <?= $editData ? "💾 Enregistrer les modifications" : "📝 Ajouter la news" ?>
      </button>
      <?php if (!empty($editData)): ?>
        <a href="newscfg.php" style="margin-left:10px">🆕 Ajouter une nouvelle news</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- Liste -->
  <div class="section" style="margin-top:12px">
    <h3>📜 Liste des news locales</h3>
    <?php
    $allFiles = [];
    foreach (glob("$storageBase/*/*/news*.json") as $file) {
        $data = json_decode(file_get_contents($file), true);
        if ($data) { $data['_file'] = $file; $allFiles[] = $data; }
    }
    usort($allFiles, fn($a,$b) => strtotime($b['date'] ?? '1970-01-01') - strtotime($a['date'] ?? '1970-01-01'));

    $page = $_GET['page'] ?? 1; $page = max(1, intval($page));
    $perPage = 5; $total = count($allFiles); $pages = ceil(max(0,$total)/$perPage);
    $start = ($page-1)*$perPage; $paginated = array_slice($allFiles, $start, $perPage);

    if (isset($_GET['delete']) && file_exists($_GET['delete'])) {
        unlink($_GET['delete']);
        echo "<div style='color:red;padding:10px'>❌ News supprimée.</div>";
        echo "<script>location.href='?page=$page';</script>";
    }

    foreach ($paginated as $entry) {
        echo "<div style='border:1px solid #444;padding:10px;margin:10px 0'>";
        echo "<b>".htmlspecialchars($entry['title']??'')."</b><br><small>".htmlspecialchars($entry['date']??'')." – ".htmlspecialchars($entry['author']??'')."</small><br>";
        echo "<a href='?delete=" . urlencode($entry['_file']) . "' onclick='return confirm(\"Supprimer cette news ?\")'>🗑️ Supprimer</a>";
        echo " | <a href='?edit=" . urlencode($entry['_file']) . "'>✏️ Modifier</a>";
        echo "</div>";
    }
    if ($pages > 1) {
        echo "<div style='text-align:center;margin:10px'>";
        for ($i=1; $i<=$pages; $i++) {
            $b = $i==$page ? "font-weight:bold;" : "";
            echo "<a href='?page=$i' style='margin:0 5px;$b'>[$i]</a>";
        }
        echo "</div>";
    }
    ?>
  </div>
</div>

<script>
function saveEditorContent(){
  document.getElementById('content').value =
    document.getElementById('editor').innerHTML;
}
</script>
