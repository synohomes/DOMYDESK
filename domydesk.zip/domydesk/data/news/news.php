<?php
header('Content-Type: application/json; charset=UTF-8');

$rootDir = dirname(__DIR__, 2);
require_once $rootDir . '/core/dmd_sources.php';

// Chemin config
$cfgPath = __DIR__ . '/newsconfig.json';
$mode = 'github';

if (file_exists($cfgPath)) {
    $cfg = json_decode((string)file_get_contents($cfgPath), true);
    if (!empty($cfg['mode'])) $mode = $cfg['mode'];
}

$newsList = [];

// ------------------------------
// MODE GITHUB VIA CACHE /sources/
// ------------------------------
if ($mode === 'github') {
    $why = '';
    $refreshed = false;
    $json = dmd_source_load_raw($rootDir, 'actus', false, $why, $refreshed);

    if ($json === false) {
        echo json_encode(['error' => 'Chargement des actualités impossible : ' . $why], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $data = json_decode((string)$json, true);
    if (!is_array($data)) {
        echo json_encode(['error' => 'Erreur de décodage du cache /sources/actus.json'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    foreach ($data as $item) {
        if (!is_array($item)) continue;
        $item['auteur'] = (isset($item['titre']) && stripos((string)$item['titre'], 'DoMyDesk') !== false) ? 'DoMyDesk' : ($item['auteur'] ?? '');
        $newsList[] = $item;
    }

    echo json_encode($newsList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ------------------------------
// MODE LOCAL
// ------------------------------
$files = glob(__DIR__ . '/add/*/*/news*.json');
foreach ($files as $file) {
    $data = json_decode((string)file_get_contents($file), true);
    if (is_array($data) && isset($data['title'])) {
        $newsList[] = [
            'titre' => $data['title'],
            'soustitre' => $data['subtitle'] ?? '',
            'date' => $data['date'] ?? '',
            'auteur' => $data['author'] ?? '',
            'description' => strip_tags($data['content'] ?? '')
        ];
    }
}

usort($newsList, fn($a, $b) => strtotime($b['date'] ?? '') - strtotime($a['date'] ?? ''));
echo json_encode($newsList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
