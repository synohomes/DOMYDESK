<?php
declare(strict_types=1);

$baseDir = realpath(__DIR__ . '/..') ?: dirname(__DIR__);
$baseDir = rtrim($baseDir, '/\\');

function dmd_hb_read_json_file(string $file): array
{
    if (!is_file($file)) {
        return [];
    }

    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function dmd_hb_settings(string $rootDir): array
{
    $settings = dmd_hb_read_json_file($rootDir . '/adm/settings.json');

    $enabled = array_key_exists('domyco_heartbeat_enabled', $settings)
        ? (bool)$settings['domyco_heartbeat_enabled']
        : true;

    // DomyCo doit recevoir un signe de vie suffisamment fréquent pour que
    // l'instance reste indiquée en ligne. Le heartbeat est donc fixé à
    // 5 minutes (300 secondes). On ne reprend volontairement pas une ancienne
    // valeur domyco_heartbeat_interval à 3600 s qui rendrait l'instance
    // inactive entre deux synchronisations.
    $interval = 300;

    return [
        'enabled' => $enabled,
        'interval' => $interval,
    ];
}

function dmd_hb_write_json(string $file, array $data): void
{
    @file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );
}

function dmd_hb_run(bool $force = false, ?string $rootDir = null): array
{
    $rootDir = $rootDir ?: (realpath(__DIR__ . '/..') ?: dirname(__DIR__));
    $rootDir = rtrim($rootDir, '/\\');

    $dataDir  = $rootDir . '/data';
    $syncFile = $dataDir . '/domyco_sync.php';
    $lockFile = $dataDir . '/domyco_heartbeat.lock';
    $logFile  = $dataDir . '/domyco_heartbeat.log';
    $lastFile = $dataDir . '/domyco_heartbeat_last.json';

    @mkdir($dataDir, 0775, true);

    $cfg = dmd_hb_settings($rootDir);
    $interval = (int)$cfg['interval'];

    if (!$force && empty($cfg['enabled'])) {
        $result = [
            'success' => true,
            'skipped' => true,
            'reason' => 'DISABLED',
            'enabled' => false,
            'interval' => $interval,
            'checked_at' => date('c'),
        ];

        dmd_hb_write_json($lastFile, $result);
        return $result;
    }

    /*
     * Le lock mémorise désormais la DERNIÈRE TENTATIVE, réussie ou non.
     * Cela garantit au maximum un appel Internet toutes les 5 minutes pour toute
     * l'instance, même si DomyCo est momentanément indisponible.
     * flock évite que deux utilisateurs déclenchent la synchro en parallèle.
     */
    $lockHandle = @fopen($lockFile, 'c+');
    if ($lockHandle) {
        @flock($lockHandle, LOCK_EX);
        rewind($lockHandle);
        $lastAttempt = (int)trim((string)stream_get_contents($lockHandle));
        $elapsed = $lastAttempt > 0 ? (time() - $lastAttempt) : PHP_INT_MAX;

        if (!$force && $lastAttempt > 0 && $elapsed < $interval) {
            @flock($lockHandle, LOCK_UN);
            fclose($lockHandle);

            return [
                'success' => true,
                'skipped' => true,
                'reason' => 'THROTTLED',
                'enabled' => true,
                'interval' => $interval,
                'seconds_since_last_attempt' => $elapsed,
                'next_allowed_in' => max(0, $interval - $elapsed),
            ];
        }

        // Réservation du créneau AVANT l'appel réseau.
        ftruncate($lockHandle, 0);
        rewind($lockHandle);
        fwrite($lockHandle, (string)time());
        fflush($lockHandle);
        @flock($lockHandle, LOCK_UN);
        fclose($lockHandle);
    }

    if (!is_file($syncFile)) {
        $result = [
            'success' => false,
            'error' => 'SYNC_FILE_MISSING',
            'sync_file' => $syncFile,
            'attempted_at' => date('c'),
        ];

        dmd_hb_write_json($lastFile, $result);
        @file_put_contents($logFile, date('c') . " - ERROR sync file missing\n", FILE_APPEND);
        return $result;
    }

    $beforeLevel = ob_get_level();

    try {
        ob_start();
        require_once $syncFile;

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        if (!function_exists('domyco_sync_register')) {
            $result = [
                'success' => false,
                'error' => 'SYNC_FUNCTION_MISSING',
                'attempted_at' => date('c'),
            ];

            dmd_hb_write_json($lastFile, $result);
            @file_put_contents($logFile, date('c') . " - ERROR function missing\n", FILE_APPEND);
            return $result;
        }

        ob_start();
        $syncResult = domyco_sync_register($rootDir);

        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        $success = !empty($syncResult['success']);

        $result = [
            'success' => $success,
            'skipped' => false,
            'forced' => $force,
            'enabled' => (bool)$cfg['enabled'],
            'interval' => $interval,
            'attempted_at' => date('c'),
            'sent_at' => $syncResult['sent_at'] ?? date('c'),
            'base_dir' => $rootDir,
            'http_code' => $syncResult['http_code'] ?? null,
            'curl_error' => $syncResult['curl_error'] ?? null,
            'sync_result' => $syncResult,
        ];

        dmd_hb_write_json($lastFile, $result);
        @file_put_contents(
            $logFile,
            date('c') . ' - success=' . ($success ? '1' : '0') . ' - http=' . ($result['http_code'] ?? '-') . ($force ? ' - force=1' : '') . PHP_EOL,
            FILE_APPEND
        );

        return $result;

    } catch (Throwable $e) {
        while (ob_get_level() > $beforeLevel) {
            ob_end_clean();
        }

        $result = [
            'success' => false,
            'error' => 'HEARTBEAT_EXCEPTION',
            'message' => $e->getMessage(),
            'attempted_at' => date('c'),
        ];

        dmd_hb_write_json($lastFile, $result);
        @file_put_contents($logFile, date('c') . ' - EXCEPTION ' . $e->getMessage() . PHP_EOL, FILE_APPEND);
        return $result;
    }
}

function dmd_hb_direct_response(array $result, int $code = 200): void
{
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        http_response_code($code);
    }

    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$isDirect = isset($_SERVER['SCRIPT_FILENAME'])
    && realpath((string)$_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__);

if ($isDirect) {
    // Depuis le navigateur, le heartbeat n'est déclenché que par une session
    // DoMyDesk authentifiée. Le mode --force reste réservé au CLI.
    if (PHP_SAPI !== 'cli') {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (empty($_SESSION['user']['email'])) {
            dmd_hb_direct_response([
                'success' => false,
                'error' => 'AUTH_REQUIRED',
            ], 401);
        }

        $result = dmd_hb_run(false, $baseDir);
        dmd_hb_direct_response($result, !empty($result['success']) ? 200 : 500);
    }

    $force = in_array('--force', $argv ?? [], true);
    $result = dmd_hb_run($force, $baseDir);
    dmd_hb_direct_response($result, !empty($result['success']) ? 200 : 500);
}
