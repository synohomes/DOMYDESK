<?php
header('Content-Type: application/json');
error_reporting(0);
$idFile = __DIR__ . '/id_domydesk.txt';
$id = file_exists($idFile) ? trim(file_get_contents($idFile)) : null;
if (!$id) {
    echo json_encode(['error' => 'ID introuvable']); exit;
}
$modulesList = __DIR__ . '/../modules/list.json';
$list = file_exists($modulesList) ? json_decode(file_get_contents($modulesList), true) : [];
$modules = [];

if (is_array($list)) {
    foreach ($list as $mod) {
        if (!is_array($mod) || empty($mod['id'])) {
            continue;
        }

        $modules[$mod['id']] = [
            'id' => $mod['id'],
            'name' => $mod['name'] ?? $mod['id']
        ];
    }
}
echo json_encode([
    'id' => $id,
    'modules' => array_values($modules)
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
