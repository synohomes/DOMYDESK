<?php
session_start();
$dmdRoot = dirname(__DIR__);
require_once $dmdRoot . '/core/dmd_permissions.php';
require_once $dmdRoot . '/core/dmd_system_services.php';

$userEmail = $_SESSION['user']['email'] ?? '';
if ($userEmail === '') { http_response_code(403); exit('Accès refusé'); }
dmd_require_page_access('procedures');

$currentProfile = dmd_read_profile($userEmail);
$isAdmin = dmd_is_system_admin_profile($currentProfile);
$userDir = $dmdRoot . '/users/profiles/' . basename($userEmail);
$theme = 'default';
$themePath = $userDir . '/theme.json';
if (is_file($themePath)) {
    $td = json_decode((string)file_get_contents($themePath), true);
    if (is_array($td) && !empty($td['theme'])) {
        $candidate = basename((string)$td['theme']);
        if (is_file($dmdRoot . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    }
}

$procedureRoot = __DIR__ . '/procedures/documents';
$internalDir = $procedureRoot . '/interne';
$quickDir = $procedureRoot . '/quick-session';
$sharedDir = $procedureRoot . '/partagees';
$quickIndexFile = __DIR__ . '/secure/quick_session_procedures.json';
$localIndexFile = __DIR__ . '/secure/procedures_local_index.json';
$remoteJson = 'https://raw.githubusercontent.com/synohomes/DOMYDESK/refs/heads/main/Process_domydesk.json';
$remoteCacheFile = __DIR__ . '/cache/procedures_github_catalog.json';
$modulesRoot = $dmdRoot . '/modules';

if (empty($_SESSION['csrf_procedures'])) $_SESSION['csrf_procedures'] = bin2hex(random_bytes(32));
$csrfProcedures = (string)$_SESSION['csrf_procedures'];
foreach (array($procedureRoot, $internalDir, $quickDir, $sharedDir, dirname($remoteCacheFile), dirname($localIndexFile)) as $dir) {
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
}

$message = '';
$messageType = 'info';

function dmd_proc_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmd_proc_size($bytes) {
    $bytes = (int)$bytes;
    if ($bytes >= 1073741824) return round($bytes/1073741824,2).' Go';
    if ($bytes >= 1048576) return round($bytes/1048576,2).' Mo';
    if ($bytes >= 1024) return round($bytes/1024,1).' Ko';
    return $bytes.' o';
}
function dmd_proc_lower($value) {
    $value = (string)$value;
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}
function dmd_proc_safe_pdf_name($name) {
    $name = basename((string)$name);
    $name = preg_replace('/[^a-zA-Z0-9À-ÿ._\- ]/u', '-', $name);
    $name = preg_replace('/\s+/', ' ', trim((string)$name));
    return $name !== '' ? $name : 'procedure.pdf';
}
function dmd_proc_safe_relative_path($path) {
    $path = str_replace('\\', '/', trim((string)$path));
    $parts = array();
    foreach (explode('/', $path) as $part) {
        $part = trim($part);
        if ($part === '' || $part === '.' || $part === '..') continue;
        $parts[] = dmd_proc_safe_pdf_name($part);
    }
    return implode('/', $parts);
}
function dmd_proc_encode_path($path) {
    $parts = array_filter(explode('/', str_replace('\\','/',(string)$path)), 'strlen');
    return implode('/', array_map('rawurlencode', $parts));
}
function dmd_proc_unique_target($dir, $name) {
    $safe = dmd_proc_safe_pdf_name($name);
    if (strtolower(pathinfo($safe, PATHINFO_EXTENSION)) !== 'pdf') $safe .= '.pdf';
    $target = rtrim($dir, '/\\') . '/' . $safe;
    if (!is_file($target)) return $target;
    $stem = pathinfo($safe, PATHINFO_FILENAME);
    $i = 1;
    do {
        $target = rtrim($dir, '/\\') . '/' . $stem . '-' . $i . '.pdf';
        $i++;
    } while (is_file($target));
    return $target;
}
function dmd_proc_has_pdf_header($file) {
    $fh = @fopen($file, 'rb');
    if (!$fh) return false;
    $head = fread($fh, 5);
    fclose($fh);
    return $head === '%PDF-';
}
function dmd_proc_read_json($file, $fallback) {
    if (!is_file($file)) return $fallback;
    $d = json_decode((string)@file_get_contents($file), true);
    return is_array($d) ? $d : $fallback;
}
function dmd_proc_write_json($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    return $json !== false && @file_put_contents($file, $json, LOCK_EX) !== false;
}
function dmd_proc_qs_index($file) {
    $d = dmd_proc_read_json($file, array('version'=>2,'procedures'=>array()));
    if (!isset($d['procedures']) || !is_array($d['procedures'])) $d['procedures'] = array();
    return $d;
}
function dmd_proc_local_index($file) {
    $d = dmd_proc_read_json($file, array('version'=>1,'procedures'=>array()));
    if (!isset($d['procedures']) || !is_array($d['procedures'])) $d['procedures'] = array();
    return $d;
}
function dmd_proc_is_list($array) {
    if (!is_array($array)) return false;
    $i = 0;
    foreach ($array as $k => $v) { if ($k !== $i++) return false; }
    return true;
}
function dmd_proc_safe_remote_url($value) {
    $value = trim((string)$value);
    if ($value === '' || filter_var($value, FILTER_VALIDATE_URL) === false) return '';
    $scheme = strtolower((string)parse_url($value, PHP_URL_SCHEME));
    return in_array($scheme, array('http','https'), true) ? $value : '';
}
function dmd_proc_http_get($url, &$error) {
    $error = '';
    if (!preg_match('#^https?://#i', (string)$url)) { $error = 'URL distante invalide.'; return false; }
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_USERAGENT => 'DoMyDesk-Procedures/1.2.0',
        ));
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            $error = $body === false ? $err : ('HTTP ' . $code);
            return false;
        }
        return $body;
    }
    $ctx = stream_context_create(array(
        'http' => array('timeout'=>8, 'user_agent'=>'DoMyDesk-Procedures/1.2.0'),
        'https' => array('timeout'=>8, 'user_agent'=>'DoMyDesk-Procedures/1.2.0'),
    ));
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) { $error = 'Téléchargement impossible.'; return false; }
    return $body;
}
function dmd_proc_remote_catalog($url, $cacheFile, &$error) {
    $error = '';
    $cacheMaxAge = 3600;
    $cached = null;
    if (is_file($cacheFile)) {
        $tmp = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($tmp)) $cached = $tmp;
        if ($cached !== null && (time() - (int)@filemtime($cacheFile)) < $cacheMaxAge) return $cached;
    }
    $raw = dmd_proc_http_get($url, $fetchError);
    if ($raw === false) {
        if ($cached !== null) { $error = 'Catalogue GitHub indisponible, cache local utilisé.'; return $cached; }
        $error = $fetchError !== '' ? $fetchError : 'Impossible de charger le catalogue GitHub.';
        return array();
    }
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        if ($cached !== null) { $error = 'Catalogue GitHub invalide, cache local utilisé.'; return $cached; }
        $error = 'JSON GitHub invalide.';
        return array();
    }
    if (isset($data['procedures']) && is_array($data['procedures'])) $data = $data['procedures'];
    if (!dmd_proc_is_list($data)) $data = array($data);
    $out = array();
    foreach ($data as $item) {
        if (!is_array($item)) continue;
        $urlItem = dmd_proc_safe_remote_url($item['url'] ?? ($item['pdf'] ?? ($item['file'] ?? ($item['download_url'] ?? ''))));
        if ($urlItem === '') continue;
        $out[] = array(
            'titre' => trim((string)($item['titre'] ?? ($item['name'] ?? 'Procédure'))),
            'soustitre' => trim((string)($item['soustitre'] ?? '')),
            'date' => trim((string)($item['date'] ?? '')),
            'description' => trim((string)($item['description'] ?? '')),
            'url' => $urlItem,
        );
    }
    @file_put_contents($cacheFile, json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), LOCK_EX);
    return $out;
}
function dmd_proc_uploaded_files($field) {
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return array();
    $f = $_FILES[$field];
    if (!is_array($f['name'] ?? null)) return array($f);
    $out = array();
    $count = count($f['name']);
    for ($i=0; $i<$count; $i++) {
        $out[] = array(
            'name' => $f['name'][$i] ?? '', 'type' => $f['type'][$i] ?? '',
            'tmp_name' => $f['tmp_name'][$i] ?? '', 'error' => $f['error'][$i] ?? UPLOAD_ERR_NO_FILE,
            'size' => $f['size'][$i] ?? 0,
        );
    }
    return $out;
}
function dmd_proc_target_dir_for_categories($internal, $quick, $internalDir, $quickDir, $sharedDir) {
    if ($internal && $quick) return $sharedDir;
    return $quick ? $quickDir : $internalDir;
}
function dmd_proc_rel_from_abs($root, $path) {
    $rootReal = rtrim(str_replace('\\','/', (string)$root), '/') . '/';
    $pathNorm = str_replace('\\','/', (string)$path);
    if (strpos($pathNorm, $rootReal) === 0) return substr($pathNorm, strlen($rootReal));
    return basename($pathNorm);
}
function dmd_proc_register_local(&$index, $relativePath, $internal, $quick, $originalName) {
    $relativePath = str_replace('\\','/',(string)$relativePath);
    $kept = array();
    foreach ($index['procedures'] as $entry) {
        if (!is_array($entry) || (($entry['relative_path'] ?? '') === $relativePath)) continue;
        $kept[] = $entry;
    }
    $kept[] = array(
        'relative_path'=>$relativePath,
        'filename'=>basename($relativePath),
        'original_name'=>(string)$originalName,
        'categories'=>array_values(array_filter(array($internal?'interne':'', $quick?'quick-session':''))),
        'created_at'=>time(), 'created_at_iso'=>date('c')
    );
    $index['version'] = 1;
    $index['updated_at'] = time();
    $index['updated_at_iso'] = date('c');
    $index['procedures'] = $kept;
}
function dmd_proc_store_uploaded_pdf($file, $targetDir, $procedureRoot, &$error) {
    $error = '';
    if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) { $error = 'Upload invalide.'; return ''; }
    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) { $error = 'Fichier temporaire invalide.'; return ''; }
    if (strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION)) !== 'pdf' || !dmd_proc_has_pdf_header($tmp)) {
        $error = 'Le fichier n’est pas un PDF valide.'; return '';
    }
    if (!is_dir($targetDir)) @mkdir($targetDir, 0775, true);
    $target = dmd_proc_unique_target($targetDir, (string)$file['name']);
    if (!@move_uploaded_file($tmp, $target)) { $error = 'Impossible d’enregistrer le PDF.'; return ''; }
    @chmod($target, 0664);
    return dmd_proc_rel_from_abs($procedureRoot, $target);
}
function dmd_proc_copy_pdf_stream($stream, $targetDir, $name, $procedureRoot, &$error) {
    $error = '';
    if (!is_resource($stream)) { $error = 'Flux PDF invalide.'; return ''; }
    $head = fread($stream, 5);
    if ($head !== '%PDF-') { $error = 'Le fichier n’est pas un PDF valide.'; return ''; }
    if (!is_dir($targetDir)) @mkdir($targetDir, 0775, true);
    $target = dmd_proc_unique_target($targetDir, basename((string)$name));
    $out = @fopen($target, 'wb');
    if (!$out) { $error = 'Impossible d’écrire le PDF.'; return ''; }
    fwrite($out, $head);
    stream_copy_to_stream($stream, $out);
    fclose($out);
    @chmod($target, 0664);
    return dmd_proc_rel_from_abs($procedureRoot, $target);
}
function dmd_proc_import_zip_ziparchive($zipPath, $targetDir, $procedureRoot, &$errors, &$saved) {
    if (!class_exists('ZipArchive')) return false;
    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) { $errors[]='Impossible d’ouvrir le ZIP avec ZipArchive.'; return true; }
    $totalBytes = 0; $maxTotal = 1024*1024*1024;
    for ($i=0; $i<$zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        if (!is_array($stat)) continue;
        $entry = (string)($stat['name'] ?? '');
        if ($entry === '' || substr($entry,-1)==='/' || strtolower(pathinfo($entry,PATHINFO_EXTENSION))!=='pdf') continue;
        $size=(int)($stat['size']??0); if($size<=0||$size>150*1024*1024){$errors[]=basename($entry).' ignoré (taille invalide).';continue;}
        $totalBytes += $size; if($totalBytes>$maxTotal){$errors[]='Import arrêté : ZIP > 1 Go décompressé.';break;}
        $stream=$zip->getStream($entry); if(!$stream){$errors[]=basename($entry).' illisible.';continue;}
        $err=''; $rel=dmd_proc_copy_pdf_stream($stream,$targetDir,basename($entry),$procedureRoot,$err); fclose($stream);
        if($rel!=='') $saved[]=array('relative_path'=>$rel,'original_name'=>basename($entry)); else $errors[]=basename($entry).' : '.$err;
    }
    $zip->close();
    return true;
}
function dmd_proc_import_zip_phar($zipPath, $targetDir, $procedureRoot, &$errors, &$saved) {
    if (!class_exists('PharData')) return false;
    try {
        $phar = new PharData($zipPath);
        $it = new RecursiveIteratorIterator($phar, RecursiveIteratorIterator::LEAVES_ONLY);
        $totalBytes=0; $maxTotal=1024*1024*1024;
        foreach ($it as $file) {
            if (!($file instanceof SplFileInfo) || $file->isDir()) continue;
            $name=$file->getFilename(); if(strtolower(pathinfo($name,PATHINFO_EXTENSION))!=='pdf') continue;
            $size=(int)$file->getSize(); if($size<=0||$size>150*1024*1024){$errors[]=$name.' ignoré (taille invalide).';continue;}
            $totalBytes+=$size; if($totalBytes>$maxTotal){$errors[]='Import arrêté : ZIP > 1 Go décompressé.';break;}
            $stream=@fopen($file->getPathName(),'rb'); if(!$stream){$errors[]=$name.' illisible.';continue;}
            $err=''; $rel=dmd_proc_copy_pdf_stream($stream,$targetDir,$name,$procedureRoot,$err); fclose($stream);
            if($rel!=='') $saved[]=array('relative_path'=>$rel,'original_name'=>$name); else $errors[]=$name.' : '.$err;
        }
    } catch (Throwable $e) { $errors[]='PharData : '.$e->getMessage(); }
    return true;
}
function dmd_proc_import_zip($zipFile, $targetDir, $procedureRoot, &$errors, &$saved, &$engine) {
    $errors=array(); $saved=array(); $engine='';
    if (!is_array($zipFile) || ($zipFile['error'] ?? UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || empty($zipFile['tmp_name'])) { $errors[]='Archive ZIP invalide.'; return 0; }
    $tmp=(string)$zipFile['tmp_name'];
    if (dmd_proc_import_zip_ziparchive($tmp,$targetDir,$procedureRoot,$errors,$saved)) $engine='ZipArchive';
    elseif (dmd_proc_import_zip_phar($tmp,$targetDir,$procedureRoot,$errors,$saved)) $engine='PharData';
    else { $errors[]='Aucun moteur ZIP disponible (ZipArchive ou PharData).'; return 0; }
    return count($saved);
}
function dmd_proc_recursive_pdfs($root) {
    $out=array();
    if(!is_dir($root)) return $out;
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
    foreach($it as $file){
        if(!$file->isFile()||strtolower($file->getExtension())!=='pdf') continue;
        $rel=dmd_proc_rel_from_abs($root,$file->getPathname());
        $out[$rel]=$file->getPathname();
    }
    return $out;
}

function dmd_proc_module_pdfs($modulesRoot) {
    $out = array();
    if (!is_dir($modulesRoot)) return $out;

    $rootReal = realpath($modulesRoot);
    if ($rootReal === false) return $out;
    $rootPrefix = rtrim(str_replace('\\','/', $rootReal), '/') . '/';

    foreach (scandir($modulesRoot) ?: array() as $moduleFolder) {
        if ($moduleFolder === '.' || $moduleFolder === '..' || substr($moduleFolder, 0, 1) === '.') continue;

        $moduleDir = $modulesRoot . '/' . $moduleFolder;
        if (!is_dir($moduleDir)) continue;

        $moduleReal = realpath($moduleDir);
        if ($moduleReal === false) continue;
        $moduleNorm = rtrim(str_replace('\\','/', $moduleReal), '/') . '/';
        if (strpos($moduleNorm, $rootPrefix) !== 0) continue;

        $moduleName = $moduleFolder;
        $moduleVersion = '';
        foreach (array('dmd_module.json', 'app.json', 'module.json') as $manifestName) {
            $manifestPath = $moduleDir . '/' . $manifestName;
            if (!is_file($manifestPath)) continue;
            $manifest = json_decode((string)@file_get_contents($manifestPath), true);
            if (!is_array($manifest)) continue;
            $candidateName = trim((string)($manifest['name'] ?? ($manifest['label'] ?? ($manifest['id'] ?? ''))));
            if ($candidateName !== '') $moduleName = $candidateName;
            $moduleVersion = trim((string)($manifest['version'] ?? ''));
            break;
        }

        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($moduleDir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
        } catch (Throwable $e) {
            continue;
        }

        foreach ($it as $file) {
            if (!($file instanceof SplFileInfo) || !$file->isFile() || strtolower($file->getExtension()) !== 'pdf') continue;

            $full = $file->getPathname();
            $fullReal = realpath($full);
            if ($fullReal === false) continue;
            $fullNorm = str_replace('\\','/', $fullReal);
            if (strpos($fullNorm, $moduleNorm) !== 0) continue;
            if (!dmd_proc_has_pdf_header($fullReal)) continue;

            $relativeToModules = dmd_proc_rel_from_abs($modulesRoot, $fullReal);
            $relativeInsideModule = dmd_proc_rel_from_abs($moduleDir, $fullReal);
            $out[] = array(
                'module_name' => $moduleName,
                'module_folder' => $moduleFolder,
                'module_version' => $moduleVersion,
                'name' => basename($fullReal),
                'relative_path' => $relativeToModules,
                'module_relative_path' => $relativeInsideModule,
                'encoded_path' => dmd_proc_encode_path($relativeToModules),
                'url' => '../modules/' . dmd_proc_encode_path($relativeToModules),
                'size' => dmd_proc_size((int)filesize($fullReal)),
                'mtime' => filemtime($fullReal) ?: 0,
            );
        }
    }

    usort($out, function($a, $b) {
        $cmp = strcasecmp((string)$a['module_name'], (string)$b['module_name']);
        if ($cmp !== 0) return $cmp;
        return strcasecmp((string)$a['name'], (string)$b['name']);
    });
    return $out;
}
function dmd_proc_categories_for($relativePath, $localIndexByPath, $qsByPath, $qsByFilename) {
    if (isset($localIndexByPath[$relativePath])) {
        $cats=$localIndexByPath[$relativePath]['categories'] ?? array();
        return is_array($cats)?$cats:array();
    }
    $norm=str_replace('\\','/',(string)$relativePath);
    if(strpos($norm,'interne/')===0) return array('interne');
    if(strpos($norm,'quick-session/')===0) return array('quick-session');
    if(strpos($norm,'partagees/')===0) return array('interne','quick-session');
    if(isset($qsByPath[$norm])||isset($qsByFilename[basename($norm)])) return array('quick-session');
    return array('interne');
}

$qsIndex = dmd_proc_qs_index($quickIndexFile);
$localIndex = dmd_proc_local_index($localIndexFile);
$qsByFilename=array(); $qsByPath=array();
foreach($qsIndex['procedures'] as $item){
    if(!is_array($item)||empty($item['filename'])) continue;
    $qsByFilename[basename((string)$item['filename'])]=$item;
    if(!empty($item['relative_path'])) $qsByPath[str_replace('\\','/',(string)$item['relative_path'])]=$item;
}
$localIndexByPath=array();
foreach($localIndex['procedures'] as $entry){if(is_array($entry)&&!empty($entry['relative_path']))$localIndexByPath[str_replace('\\','/',(string)$entry['relative_path'])]=$entry;}

// Migration douce des anciens PDF posés directement dans documents/.
// Les procédures Quick-Session sont déplacées vers quick-session/, les autres vers interne/.
$migrated=false;
foreach(scandir($procedureRoot) ?: array() as $legacyFile){
    if($legacyFile==='.'||$legacyFile==='..') continue;
    $legacyPath=$procedureRoot.'/'.$legacyFile;
    if(!is_file($legacyPath)||strtolower(pathinfo($legacyFile,PATHINFO_EXTENSION))!=='pdf') continue;
    $isQuick=isset($qsByFilename[$legacyFile]);
    $destDir=$isQuick?$quickDir:$internalDir;
    $target=dmd_proc_unique_target($destDir,$legacyFile);
    if(@rename($legacyPath,$target)){
        @chmod($target,0664);
        $rel=dmd_proc_rel_from_abs($procedureRoot,$target);
        dmd_proc_register_local($localIndex,$rel,!$isQuick,$isQuick,$legacyFile);
        $localIndexByPath[$rel]=end($localIndex['procedures']);
        if($isQuick){
            foreach($qsIndex['procedures'] as &$qse){
                if(is_array($qse)&&basename((string)($qse['filename']??''))===$legacyFile){$qse['relative_path']=$rel;}
            }
            unset($qse);
        }
        $migrated=true;
    }
}
if($migrated){
    $qsIndex['version']=2; $qsIndex['updated_at']=time(); $qsIndex['updated_at_iso']=date('c');
    dmd_proc_write_json($quickIndexFile,$qsIndex);
    dmd_proc_write_json($localIndexFile,$localIndex);
    $qsByFilename=array();$qsByPath=array();$localIndexByPath=array();
    foreach($qsIndex['procedures'] as $item){if(!is_array($item)||empty($item['filename']))continue;$qsByFilename[basename((string)$item['filename'])]=$item;if(!empty($item['relative_path']))$qsByPath[str_replace('\\','/',(string)$item['relative_path'])]=$item;}
    foreach($localIndex['procedures'] as $entry){if(is_array($entry)&&!empty($entry['relative_path']))$localIndexByPath[str_replace('\\','/',(string)$entry['relative_path'])]=$entry;}
}

$postCsrfOk = $_SERVER['REQUEST_METHOD'] !== 'POST' || (isset($_POST['csrf_token']) && is_string($_POST['csrf_token']) && hash_equals($csrfProcedures, $_POST['csrf_token']));

if ($isAdmin && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_local_pdf'])) {
    if(!$postCsrfOk){$message='Session expirée. Recharge la page.';$messageType='error';}
    else{
        $rel=dmd_proc_safe_relative_path((string)$_POST['delete_local_pdf']);
        $full=$procedureRoot.'/'.$rel;
        $rootReal=realpath($procedureRoot); $fullReal=is_file($full)?realpath($full):false;
        if($rel!==''&&$rootReal&&$fullReal&&strpos($fullReal,$rootReal.DIRECTORY_SEPARATOR)===0&&strtolower(pathinfo($fullReal,PATHINFO_EXTENSION))==='pdf'&&@unlink($fullReal)){
            $base=basename($rel);
            $localIndex['procedures']=array_values(array_filter($localIndex['procedures'],function($e)use($rel){return !is_array($e)||str_replace('\\','/',(string)($e['relative_path']??''))!==$rel;}));
            $qsIndex['procedures']=array_values(array_filter($qsIndex['procedures'],function($e)use($rel,$base){if(!is_array($e))return true;$rp=str_replace('\\','/',(string)($e['relative_path']??''));return $rp!==$rel&&basename((string)($e['filename']??''))!==$base;}));
            dmd_proc_write_json($localIndexFile,$localIndex); dmd_proc_write_json($quickIndexFile,$qsIndex);
            $message='Procédure supprimée : '.$base; $messageType='success';
            dmd_system_log('procedure_deleted',$rel,'success','Procédure PDF supprimée du centre de procédures.');
        }else{$message='Impossible de supprimer cette procédure.';$messageType='error';}
    }
}

if ($isAdmin && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['import_procedures'])) {
    if(!$postCsrfOk){$message='Session expirée. Recharge la page.';$messageType='error';}
    else{
        $catInternal=!empty($_POST['category_internal']); $catQuick=!empty($_POST['category_quick']);
        if(!$catInternal&&!$catQuick){$message='Choisis au moins une catégorie : Interne et/ou Quick-Session.';$messageType='error';}
        else{
            $targetDir=dmd_proc_target_dir_for_categories($catInternal,$catQuick,$internalDir,$quickDir,$sharedDir);
            $files=dmd_proc_uploaded_files('procedure_files'); $added=0; $errors=array(); $zipEngines=array();
            foreach($files as $file){
                if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) continue;
                if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK){$errors[]=(string)($file['name']??'Fichier').' : erreur upload '.(int)$file['error'];continue;}
                $ext=strtolower(pathinfo((string)($file['name']??''),PATHINFO_EXTENSION));
                if($ext==='pdf'){
                    $err='';$rel=dmd_proc_store_uploaded_pdf($file,$targetDir,$procedureRoot,$err);
                    if($rel!==''){dmd_proc_register_local($localIndex,$rel,$catInternal,$catQuick,(string)$file['name']);$added++;}else$errors[]=(string)$file['name'].' : '.$err;
                }elseif($ext==='zip'){
                    $zipErrors=array();$saved=array();$engine='';$n=dmd_proc_import_zip($file,$targetDir,$procedureRoot,$zipErrors,$saved,$engine);
                    if($engine!=='')$zipEngines[$engine]=true;
                    foreach($saved as $s){dmd_proc_register_local($localIndex,$s['relative_path'],$catInternal,$catQuick,$s['original_name']);}
                    $added+=$n; foreach($zipErrors as $ze)$errors[]=$ze;
                }else{$errors[]=(string)$file['name'].' : seuls PDF et ZIP sont acceptés.';}
            }
            if($added>0){
                dmd_proc_write_json($localIndexFile,$localIndex);
                $message=$added.' procédure(s) importée(s) dans '.($catInternal&&$catQuick?'Interne + Quick-Session':($catQuick?'Quick-Session':'Interne')).'.';
                if($zipEngines)$message.=' ZIP traité avec '.implode(' / ',array_keys($zipEngines)).'.';
                if($errors)$message.=' '.count($errors).' entrée(s) ignorée(s).';
                $messageType='success';
                dmd_system_log('procedures_imported','procedures','success',$added.' procédure(s) importée(s).',array('internal'=>$catInternal,'quick'=>$catQuick,'errors'=>count($errors)));
            }else{$message=$errors?implode(' | ',array_slice($errors,0,5)):'Aucun fichier reçu.';$messageType='error';}
        }
    }
}

// Recharge les index après actions.
$qsIndex=dmd_proc_qs_index($quickIndexFile);$localIndex=dmd_proc_local_index($localIndexFile);
$qsByFilename=array();$qsByPath=array();$localIndexByPath=array();
foreach($qsIndex['procedures'] as $item){if(!is_array($item)||empty($item['filename']))continue;$qsByFilename[basename((string)$item['filename'])]=$item;if(!empty($item['relative_path']))$qsByPath[str_replace('\\','/',(string)$item['relative_path'])]=$item;}
foreach($localIndex['procedures'] as $entry){if(is_array($entry)&&!empty($entry['relative_path']))$localIndexByPath[str_replace('\\','/',(string)$entry['relative_path'])]=$entry;}

$internalPdfs=array();$quickPdfs=array();
foreach(dmd_proc_recursive_pdfs($procedureRoot) as $rel=>$full){
    $cats=dmd_proc_categories_for($rel,$localIndexByPath,$qsByPath,$qsByFilename);
    $meta=$qsByPath[$rel]??($qsByFilename[basename($rel)]??array());
    $entry=array(
        'name'=>basename($rel),'relative_path'=>$rel,'encoded_path'=>dmd_proc_encode_path($rel),
        'size'=>dmd_proc_size((int)filesize($full)),'mtime'=>filemtime($full)?:0,'meta'=>$meta
    );
    if(in_array('interne',$cats,true))$internalPdfs[]=$entry;
    if(in_array('quick-session',$cats,true))$quickPdfs[]=$entry;
}
$sortNewest=function($a,$b){return (int)$b['mtime']<=>(int)$a['mtime'];};usort($internalPdfs,$sortNewest);usort($quickPdfs,$sortNewest);
$githubError='';$githubPdfs=dmd_proc_remote_catalog($remoteJson,$remoteCacheFile,$githubError);
$modulePdfs=dmd_proc_module_pdfs($modulesRoot);
$zipEngine = class_exists('ZipArchive') ? 'ZipArchive' : (class_exists('PharData') ? 'PharData' : 'indisponible');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Procédures disponibles</title>
<link rel="stylesheet" href="/domydesk/theme/<?= dmd_proc_h($theme) ?>/style.css">
<style>
/* Mise en page compacte uniquement : les couleurs restent gérées par le thème DoMyDesk. */
.proc-page{padding:10px!important}.proc-shell{padding:14px!important;max-width:none!important}.proc-head{margin-bottom:10px!important}.proc-head h1{margin:0 0 4px!important;font-size:1.7rem!important}.proc-sub{margin:0!important;font-size:.86rem!important}.proc-categories{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:8px!important;margin:10px 0!important}.proc-cat{min-height:52px!important;padding:8px 10px!important}.proc-cat-main{gap:7px!important}.proc-cat-icon{font-size:1rem!important}.proc-cat-title{font-size:.9rem!important}.proc-cat-count{min-width:28px!important;height:28px!important;line-height:28px!important;font-size:.85rem!important}.proc-toolbar{gap:8px!important;margin:8px 0!important}.proc-search{min-height:40px!important;padding:0 10px!important}.proc-toolbar button{min-height:40px!important;padding:7px 11px!important}.proc-import{padding:10px 12px!important;margin:8px 0 10px!important}.proc-import-head{margin-bottom:3px!important}.proc-import-grid{gap:8px!important;margin-top:7px!important;align-items:center!important}.proc-note{font-size:.76rem!important;line-height:1.25!important}.proc-grid{display:grid!important;grid-template-columns:repeat(auto-fill,minmax(270px,1fr))!important;gap:8px!important}.proc-card{padding:10px 12px!important;min-height:0!important}.proc-card h3{margin:0 0 3px!important;font-size:.94rem!important}.proc-meta{font-size:.76rem!important}.proc-desc{font-size:.8rem!important;line-height:1.3!important;margin:5px 0!important}.proc-actions{gap:6px!important;margin-top:7px!important;align-items:center!important}.proc-actions button,.proc-actions a{padding:6px 10px!important;min-height:32px!important}.proc-alert,.proc-empty{padding:8px 10px!important;margin:8px 0!important}.proc-module-file{opacity:.82}@media(max-width:900px){.proc-categories{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:560px){.proc-page{padding:6px!important}.proc-shell{padding:10px!important}.proc-categories{grid-template-columns:1fr!important}.proc-grid{grid-template-columns:1fr!important}.proc-import-grid{grid-template-columns:1fr!important}}
</style>

</head>
<body>
<?php include $dmdRoot . '/header.php'; ?>
<main class="proc-page"><section class="proc-shell">
<div class="proc-head"><div><h1>Procédures disponibles</h1><p class="proc-sub">Choisis une catégorie puis consulte, recherche ou ouvre les procédures correspondantes.</p></div></div>

<div class="proc-categories" id="procedureCategories">
<button type="button" class="proc-cat active" data-category="github"><span class="proc-cat-main"><span class="proc-cat-icon">🌐</span><span class="proc-cat-title">Procédures GitHub</span></span><span class="proc-cat-count"><?= count($githubPdfs) ?></span></button>
<button type="button" class="proc-cat" data-category="modules"><span class="proc-cat-main"><span class="proc-cat-icon">🧩</span><span class="proc-cat-title">Procédures Modules</span></span><span class="proc-cat-count"><?= count($modulePdfs) ?></span></button>
<button type="button" class="proc-cat" data-category="internal"><span class="proc-cat-main"><span class="proc-cat-icon">📁</span><span class="proc-cat-title">Procédures internes</span></span><span class="proc-cat-count"><?= count($internalPdfs) ?></span></button>
<button type="button" class="proc-cat" data-category="quick"><span class="proc-cat-main"><span class="proc-cat-icon">🚨</span><span class="proc-cat-title">Procédures Quick-Session</span></span><span class="proc-cat-count"><?= count($quickPdfs) ?></span></button>
</div>

<div class="proc-toolbar"><label class="proc-search"><span>🔎</span><input id="procedureSearch" type="search" placeholder="Rechercher dans la catégorie affichée..."></label><button type="button" id="openYoutubeBtn">▶️ YouTube DoMyDesk</button></div>
<?php if($message):?><div class="proc-alert <?= dmd_proc_h($messageType) ?>"><?= dmd_proc_h($message) ?></div><?php endif;?>

<?php if($isAdmin):?>
<form class="proc-import" method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?= dmd_proc_h($csrfProcedures) ?>"><input type="hidden" name="import_procedures" value="1">
<div class="proc-import-head"><strong>Ajouter / importer des procédures</strong><span class="proc-note">Moteur ZIP : <?= dmd_proc_h($zipEngine) ?></span></div>
<div class="proc-note">Un seul formulaire : sélectionne des PDF et/ou un ZIP, puis choisis Interne, Quick-Session ou les deux. Un fichier classé dans les deux catégories n’est stocké qu’une seule fois.</div>
<div class="proc-import-grid"><div><input type="file" name="procedure_files[]" accept="application/pdf,.pdf,application/zip,.zip" multiple required></div><div class="proc-catchecks"><label><input type="checkbox" name="category_internal" value="1" checked> 📁 Interne</label><label><input type="checkbox" name="category_quick" value="1"> 🚨 Quick-Session</label></div><button type="submit">Importer</button></div>
<div class="proc-note">Pour tes gros lots, mets les PDF dans un ZIP : DoMyDesk les extrait directement dans la catégorie choisie. Les sous-dossiers du ZIP sont acceptés, les noms sont sécurisés et seuls les vrais PDF sont conservés.</div>
</form>
<?php endif;?>

<section class="proc-panel active" data-panel="github">
<?php if($githubError!==''):?><div class="proc-alert <?= $githubPdfs?'info':'error' ?>"><?= dmd_proc_h($githubError) ?></div><?php endif;?>
<?php if($githubPdfs):?><div class="proc-grid"><?php foreach($githubPdfs as $pdf):$searchText=dmd_proc_lower($pdf['titre'].' '.$pdf['soustitre'].' '.$pdf['description']);?><article class="proc-card" data-procedure-card data-name="<?= dmd_proc_h($searchText) ?>"><h3><?= dmd_proc_h($pdf['titre']) ?></h3><div class="proc-meta"><?= dmd_proc_h($pdf['soustitre']) ?><?= $pdf['soustitre']!==''&&$pdf['date']!==''?' · ':'' ?><?= dmd_proc_h($pdf['date']) ?></div><?php if($pdf['description']!==''):?><p class="proc-desc"><?= dmd_proc_h($pdf['description']) ?></p><?php endif;?><div class="proc-actions"><button type="button" onclick='openPdf(<?= json_encode($pdf['url'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>,<?= json_encode($pdf['titre'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>)'>Lire</button><a href="<?= dmd_proc_h($pdf['url']) ?>" download>Télécharger</a></div></article><?php endforeach;?></div><?php else:?><div class="proc-empty">Aucune procédure GitHub disponible.</div><?php endif;?>
</section>

<section class="proc-panel" data-panel="modules">
<?php if($modulePdfs):?><div class="proc-grid"><?php foreach($modulePdfs as $pdf):$moduleSearch=dmd_proc_lower($pdf['module_name'].' '.$pdf['module_folder'].' '.$pdf['name'].' '.$pdf['module_version']);?><article class="proc-card" data-procedure-card data-name="<?= dmd_proc_h($moduleSearch) ?>"><h3>🧩 <?= dmd_proc_h($pdf['module_name']) ?></h3><div class="proc-meta"><?php if($pdf['module_version']!==''):?>v<?= dmd_proc_h($pdf['module_version']) ?> · <?php endif;?><?= dmd_proc_h($pdf['size']) ?> · Mis à jour le <?= date('d/m/Y',(int)$pdf['mtime']) ?></div><div class="proc-meta proc-module-file">📄 <?= dmd_proc_h($pdf['name']) ?></div><div class="proc-actions"><button type="button" onclick='openPdf(<?= json_encode($pdf['url'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>,<?= json_encode($pdf['module_name'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>)'>Lire</button><a href="<?= dmd_proc_h($pdf['url']) ?>" download>Télécharger</a></div></article><?php endforeach;?></div><?php else:?><div class="proc-empty">Aucune procédure de module détectée. Ajoute un PDF dans le dossier d’un module installé : il apparaîtra automatiquement ici.</div><?php endif;?>
</section>

<section class="proc-panel" data-panel="internal">
<?php if($internalPdfs):?><div class="proc-grid"><?php foreach($internalPdfs as $pdf):?><article class="proc-card" data-procedure-card data-name="<?= dmd_proc_h(dmd_proc_lower($pdf['name'])) ?>"><h3><?= dmd_proc_h($pdf['name']) ?></h3><div class="proc-meta"><?= dmd_proc_h($pdf['size']) ?> · Mis à jour le <?= date('d/m/Y',(int)$pdf['mtime']) ?></div><div class="proc-actions"><button type="button" onclick="openLocalPdf('<?= dmd_proc_h($pdf['encoded_path']) ?>','<?= dmd_proc_h($pdf['name']) ?>')">Lire</button><a href="procedures/documents/<?= dmd_proc_h($pdf['encoded_path']) ?>" download>Télécharger</a><?php if($isAdmin):?><form method="post" onsubmit="return confirm('Supprimer définitivement cette procédure ?');"><input type="hidden" name="csrf_token" value="<?= dmd_proc_h($csrfProcedures) ?>"><input type="hidden" name="delete_local_pdf" value="<?= dmd_proc_h($pdf['relative_path']) ?>"><button type="submit">Supprimer</button></form><?php endif;?></div></article><?php endforeach;?></div><?php else:?><div class="proc-empty">Aucune procédure interne.</div><?php endif;?>
</section>

<section class="proc-panel" data-panel="quick">
<?php if($quickPdfs):?><div class="proc-grid"><?php foreach($quickPdfs as $pdf):$meta=$pdf['meta'];?><article class="proc-card" data-procedure-card data-name="<?= dmd_proc_h(dmd_proc_lower(($meta['title']??$pdf['name']).' '.implode(' ',is_array($meta['tags']??null)?$meta['tags']:array()))) ?>"><h3><?= dmd_proc_h($meta['title']??$pdf['name']) ?></h3><div class="proc-meta"><?= dmd_proc_h($pdf['name']) ?> · <?= dmd_proc_h($pdf['size']) ?></div><?php if(!empty($meta['summary'])):?><p class="proc-desc"><?= dmd_proc_h($meta['summary']) ?></p><?php endif;?><?php if(!empty($meta['resolution'])):?><p class="proc-desc"><strong>Résolution :</strong> <?= dmd_proc_h($meta['resolution']) ?></p><?php endif;?><div class="proc-actions"><button type="button" onclick="openLocalPdf('<?= dmd_proc_h($pdf['encoded_path']) ?>','<?= dmd_proc_h($meta['title']??$pdf['name']) ?>')">Lire</button><a href="procedures/documents/<?= dmd_proc_h($pdf['encoded_path']) ?>" download>Télécharger</a><?php if($isAdmin):?><form method="post" onsubmit="return confirm('Supprimer définitivement cette procédure ?');"><input type="hidden" name="csrf_token" value="<?= dmd_proc_h($csrfProcedures) ?>"><input type="hidden" name="delete_local_pdf" value="<?= dmd_proc_h($pdf['relative_path']) ?>"><button type="submit">Supprimer</button></form><?php endif;?></div></article><?php endforeach;?></div><?php else:?><div class="proc-empty">Aucune procédure Quick-Session.</div><?php endif;?>
</section>
<div class="proc-empty proc-hidden" id="noSearchResult">Aucune procédure ne correspond à la recherche.</div>
</section></main>

<div class="proc-overlay" id="viewerOverlay" aria-hidden="true"><div class="proc-modal"><div class="proc-modal-head"><strong id="viewerTitle">📄 Procédure</strong><div><a id="downloadBtn" href="#" download>Télécharger</a> <button type="button" id="closeViewerBtn">Fermer</button></div></div><div class="proc-zoom"><button type="button" id="zoomOutBtn">−</button><span id="zoomIndicator">100%</span><button type="button" id="zoomInBtn">+</button><button type="button" id="zoomResetBtn">Reset</button></div><div class="proc-frame-wrap"><iframe id="pdfFrame" class="proc-frame" src="" title="Lecteur PDF"></iframe></div></div></div>
<div class="proc-overlay" id="ytOverlay" aria-hidden="true"><div class="proc-modal"><div class="proc-modal-head"><strong>🎬 YouTube DoMyDesk</strong><button type="button" id="closeYtBtn">Fermer</button></div><div class="proc-frame-wrap"><iframe id="ytFrame" class="proc-frame" src="" title="YouTube DoMyDesk" allowfullscreen></iframe></div></div></div>
<script>
const viewerOverlay=document.getElementById('viewerOverlay'),pdfFrame=document.getElementById('pdfFrame'),downloadBtn=document.getElementById('downloadBtn'),viewerTitle=document.getElementById('viewerTitle'),zoomIndicator=document.getElementById('zoomIndicator');let zoom=1;
function openOverlay(o){o.style.display='flex';o.setAttribute('aria-hidden','false')}function closeOverlay(o){o.style.display='none';o.setAttribute('aria-hidden','true')}
function updateZoom(){pdfFrame.style.transform=`scale(${zoom})`;pdfFrame.style.width=`${100/zoom}%`;pdfFrame.style.height=`${100/zoom}%`;zoomIndicator.textContent=`${Math.round(zoom*100)}%`}
function openPdf(url,name){if(!url)return;zoom=1;updateZoom();pdfFrame.src=url+(url.includes('#')?'':'#toolbar=0&navpanes=0&view=FitH');downloadBtn.href=url.split('#')[0];viewerTitle.textContent='📄 '+name;openOverlay(viewerOverlay)}
function openLocalPdf(encodedPath,name){openPdf('procedures/documents/'+encodedPath,name)}
document.getElementById('zoomInBtn').onclick=()=>{zoom=Math.min(2.2,zoom+.1);updateZoom()};document.getElementById('zoomOutBtn').onclick=()=>{zoom=Math.max(.6,zoom-.1);updateZoom()};document.getElementById('zoomResetBtn').onclick=()=>{zoom=1;updateZoom()};document.getElementById('closeViewerBtn').onclick=()=>{closeOverlay(viewerOverlay);pdfFrame.src=''};viewerOverlay.onclick=e=>{if(e.target===viewerOverlay){closeOverlay(viewerOverlay);pdfFrame.src=''}};
const categoryButtons=[...document.querySelectorAll('.proc-cat')],panels=[...document.querySelectorAll('.proc-panel')],search=document.getElementById('procedureSearch'),noResult=document.getElementById('noSearchResult');
function setCategory(cat){categoryButtons.forEach(b=>b.classList.toggle('active',b.dataset.category===cat));panels.forEach(p=>p.classList.toggle('active',p.dataset.panel===cat));try{localStorage.setItem('dmd-procedure-category',cat)}catch(e){}search.value='';applySearch()}
categoryButtons.forEach(b=>b.addEventListener('click',()=>setCategory(b.dataset.category)));
function applySearch(){const q=(search.value||'').trim().toLowerCase(),active=document.querySelector('.proc-panel.active');let visible=0;if(active)active.querySelectorAll('[data-procedure-card]').forEach(c=>{const ok=!q||(c.dataset.name||'').includes(q);c.classList.toggle('proc-hidden',!ok);if(ok)visible++});noResult.classList.toggle('proc-hidden',!active||visible!==0)}search.addEventListener('input',applySearch);
try{const saved=localStorage.getItem('dmd-procedure-category');if(saved&&document.querySelector('.proc-cat[data-category="'+saved+'"]'))setCategory(saved)}catch(e){}
const ytOverlay=document.getElementById('ytOverlay'),ytFrame=document.getElementById('ytFrame');document.getElementById('openYoutubeBtn').onclick=()=>{ytFrame.src='https://www.youtube.com/embed/videoseries?list=PLqtzZSNg-E8BiDME_SGllHBiOmtL7KIDM&autoplay=1&modestbranding=1&rel=0';openOverlay(ytOverlay)};document.getElementById('closeYtBtn').onclick=()=>{closeOverlay(ytOverlay);ytFrame.src=''};ytOverlay.onclick=e=>{if(e.target===ytOverlay){closeOverlay(ytOverlay);ytFrame.src=''}};document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeOverlay(viewerOverlay);closeOverlay(ytOverlay);pdfFrame.src='';ytFrame.src=''}});
</script>
</body></html>
