<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

$baseDir = dirname(__DIR__, 2);
require_once $baseDir . '/core/dmd_permissions.php';
$email = $_SESSION['user']['email'] ?? null;

if (!$email) {
    http_response_code(403);
    echo 'Accès refusé.';
    exit;
}

$profileFile = dmd_profile_path($email, true);
$profile = dmd_read_profile($email);

if (!is_array($profile) || !in_array(($profile['role_system'] ?? 'user'), ['admin', 'superadmin'], true)) {
    http_response_code(403);
    echo 'Accès refusé.';
    exit;
}

$themeName = 'default';
$themeFile = $baseDir . '/users/profiles/' . $email . '/theme.json';

if (is_file($themeFile)) {
    $themeData = json_decode((string)file_get_contents($themeFile), true);
    if (is_array($themeData)) {
        $themeName = (string)($themeData['theme'] ?? $themeData['name'] ?? $themeData['selected'] ?? $themeName);
    }
}

if (!preg_match('/^[a-zA-Z0-9_-]+$/', $themeName)) {
    $themeName = 'default';
}

$themeCssHref = '../../theme/' . rawurlencode($themeName) . '/style.css';

$agentsFile = __DIR__ . '/agents.json';
$heartbeatLog = __DIR__ . '/logs/heartbeats.json';
$commandsDir = __DIR__ . '/commands/';

function dmd_read_json(string $file, array $default = []): array {
    if (!is_file($file)) return $default;
    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function dmd_write_json(string $file, array $data): bool {
    $ok = file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    ) !== false;

    if ($ok) @chmod($file, 0664);
    return $ok;
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_inventory(array $agent): array {
    return isset($agent['inventory']) && is_array($agent['inventory']) ? $agent['inventory'] : [];
}

function dmd_agent_status(array $agent): string {
    $last = strtotime((string)($agent['last_seen'] ?? ''));
    if (!$last) return 'offline';

    $diff = time() - $last;

    if ($diff <= 45) return 'online';
    if ($diff <= 180) return 'warning';
    return 'offline';
}

function dmd_agent_hostname(array $agent): string {
    $inv = dmd_inventory($agent);
    return (string)($inv['hostname'] ?? $agent['hostname'] ?? 'Périphérique inconnu');
}

function dmd_agent_os_name(array $agent): string {
    $inv = dmd_inventory($agent);
    if (!empty($inv['os']['name'])) return (string)$inv['os']['name'];
    if (!empty($agent['os'])) return (string)$agent['os'];
    return '-';
}

function dmd_agent_os_version(array $agent): string {
    $inv = dmd_inventory($agent);
    return (string)($inv['os']['version'] ?? '');
}

function dmd_agent_arch(array $agent): string {
    $inv = dmd_inventory($agent);
    return (string)($inv['arch'] ?? $agent['arch'] ?? '-');
}

function dmd_agent_version(array $agent): string {
    return (string)($agent['agent_version'] ?? '-');
}

function dmd_agent_cpu(array $agent): string {
    $inv = dmd_inventory($agent);
    $cpu = $inv['cpu'] ?? [];

    if (!is_array($cpu)) return '-';

    $model = trim((string)($cpu['model'] ?? ''));
    $cores = (int)($cpu['cores'] ?? 0);

    if ($model && $cores > 0) return $model . ' · ' . $cores . ' cœurs';
    if ($model) return $model;
    if ($cores > 0) return $cores . ' cœurs';

    return '-';
}

function dmd_agent_ram(array $agent): string {
    $inv = dmd_inventory($agent);
    $ram = $inv['ram'] ?? [];

    if (!is_array($ram)) return '-';

    $total = (float)($ram['total_gb'] ?? 0);
    $used = (float)($ram['used_gb'] ?? 0);

    if ($total <= 0) return '-';

    return number_format($used, 2, ',', ' ') . ' / ' . number_format($total, 2, ',', ' ') . ' Go';
}

function dmd_agent_ram_percent(array $agent): int {
    $inv = dmd_inventory($agent);
    $ram = $inv['ram'] ?? [];

    if (!is_array($ram)) return 0;

    $total = (float)($ram['total_gb'] ?? 0);
    $used = (float)($ram['used_gb'] ?? 0);

    if ($total <= 0) return 0;

    return max(0, min(100, (int)round(($used / $total) * 100)));
}

function dmd_agent_uptime(array $agent): string {
    $inv = dmd_inventory($agent);
    return (string)($inv['uptime']['human'] ?? '-');
}

function dmd_clean_ip(string $ip): string {
    $ip = trim($ip);
    if ($ip === '') return '';
    if (str_contains($ip, '/')) $ip = explode('/', $ip)[0];
    return $ip;
}

function dmd_agent_local_ips(array $agent): array {
    $inv = dmd_inventory($agent);
    $network = $inv['network'] ?? [];
    $ips = [];

    if (!is_array($network)) return [];

    foreach ($network as $iface) {
        if (!is_array($iface)) continue;

        foreach (($iface['ips'] ?? []) as $ip) {
            $ip = dmd_clean_ip((string)$ip);

            if (
                $ip !== '' &&
                !str_starts_with($ip, '127.') &&
                !str_starts_with($ip, '::1') &&
                !str_starts_with(strtolower($ip), 'fe80:')
            ) {
                $ips[] = $ip;
            }
        }
    }

    return array_values(array_unique($ips));
}

function dmd_first_local_ip(array $agent): string {
    $ips = dmd_agent_local_ips($agent);
    return $ips[0] ?? '-';
}

function dmd_os_icon(string $os): string {
    $os = strtolower($os);

    if (str_contains($os, 'windows')) return '🪟';
    if (str_contains($os, 'linux')) return '🐧';
    if (str_contains($os, 'darwin') || str_contains($os, 'mac')) return '🍎';
    if (str_contains($os, 'android')) return '🤖';
    if (str_contains($os, 'ios')) return '📱';

    return '💻';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_agent'])) {
    $deleteId = trim((string)($_POST['machine_id'] ?? ''));

    if ($deleteId !== '') {
        $agents = dmd_read_json($agentsFile, []);

        if (isset($agents[$deleteId])) {
            unset($agents[$deleteId]);
            dmd_write_json($agentsFile, $agents);
        }

        $commandFile = $commandsDir . basename($deleteId) . '.json';
        if (is_file($commandFile)) {
            @unlink($commandFile);
        }

        header('Location: agents_view.php');
        exit;
    }
}

$agents = dmd_read_json($agentsFile, []);
$logs = array_reverse(dmd_read_json($heartbeatLog, []));

$total = count($agents);
$online = 0;
$warning = 0;
$offline = 0;

foreach ($agents as $agent) {
    $status = dmd_agent_status($agent);
    if ($status === 'online') $online++;
    elseif ($status === 'warning') $warning++;
    else $offline++;
}

$agentsForJs = [];
foreach ($agents as $id => $agent) {
    if (is_array($agent)) {
        $agent['_status'] = dmd_agent_status($agent);
        $agent['_hostname'] = dmd_agent_hostname($agent);
        $agent['_os_name'] = dmd_agent_os_name($agent);
        $agent['_os_version'] = dmd_agent_os_version($agent);
        $agent['_arch'] = dmd_agent_arch($agent);
        $agent['_cpu'] = dmd_agent_cpu($agent);
        $agent['_ram'] = dmd_agent_ram($agent);
        $agent['_ram_percent'] = dmd_agent_ram_percent($agent);
        $agent['_local_ips'] = dmd_agent_local_ips($agent);
        $agent['_uptime'] = dmd_agent_uptime($agent);
        $agentsForJs[$id] = $agent;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Agents DOMYDESK</title>
<link rel="stylesheet" href="<?= h($themeCssHref) ?>">
<style>
* {
    box-sizing: border-box;
}

html,
body {
    min-height: 100%;
}

body {
    margin: 0;
    padding: 18px;
    font-family: inherit;
    color: inherit;
}

/*
    agents_view.php
    - aucune couleur écran en dur
    - pas de Canvas / CanvasText
    - pas de blanc forcé
    - pas de noir/or forcé
    - pas de flou transparent
    - les surfaces reprennent les couleurs CALCULÉES du thème via JS
*/

:root {
    --agent-radius: 16px;
    --agent-border: currentColor;
    --agent-bg-solid: inherit;
    --agent-panel-solid: inherit;
    --agent-text-solid: inherit;
}

h2,
h3,
h4 {
    margin: 0;
    color: inherit;
}

button {
    font-family: inherit;
}

/* En-tête */
.page-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 14px;
    margin-bottom: 16px;
    padding: 16px;
    border: 1px solid var(--agent-border);
    border-radius: var(--agent-radius);
    background-color: var(--agent-panel-solid);
    color: var(--agent-text-solid);
    background-image: none;
}

.page-title {
    display: grid;
    gap: 6px;
}

.page-title p {
    margin: 0;
    font-size: 13px;
    opacity: .78;
}

.page-actions,
.popup-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.page-actions {
    margin-top: 8px;
}

/* Boutons */
.export-btn,
.popup-btn,
.agent-delete-btn,
.raw-toggle {
    cursor: pointer;
    border: 1px solid var(--agent-border);
    color: inherit;
    background-color: var(--agent-panel-solid);
    background-image: none;
    border-radius: 12px;
    padding: 9px 14px;
    font-weight: 900;
}

.export-btn:hover,
.popup-btn:hover,
.agent-delete-btn:hover,
.raw-toggle:hover {
    opacity: .82;
}

/* Résumé */
.agent-summary {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

.agent-pill {
    padding: 8px 12px;
    border-radius: 999px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
    font-weight: 800;
    font-size: 13px;
}

/* Blocs */
.block {
    margin-bottom: 22px;
    padding: 16px;
    border: 1px solid var(--agent-border);
    border-radius: var(--agent-radius);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

/* Cartes agents */
.agents-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(285px, 1fr));
    gap: 14px;
}

.agent-card {
    position: relative;
    overflow: hidden;
    border: 1px solid var(--agent-border);
    border-radius: var(--agent-radius);
    padding: 14px;
    cursor: pointer;
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
    transition: transform .15s ease, opacity .15s ease;
}

.agent-card:hover {
    transform: translateY(-2px);
    opacity: .92;
}

.agent-top {
    display: grid;
    grid-template-columns: 46px minmax(0, 1fr);
    gap: 11px;
    align-items: center;
    margin-bottom: 12px;
}

.agent-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    font-size: 24px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    background-image: none;
}

.agent-name {
    font-weight: 900;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.agent-sub {
    margin-top: 4px;
    font-size: 12px;
    opacity: .72;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.agent-metrics {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 9px;
    margin: 12px 0;
}

.metric {
    border: 1px solid var(--agent-border);
    border-radius: 12px;
    padding: 9px;
    min-width: 0;
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

.metric-label {
    display: block;
    font-size: 11px;
    margin-bottom: 5px;
    opacity: .72;
}

.metric-value {
    display: block;
    font-weight: 800;
    font-size: 13px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.agent-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: 10px;
}

.badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    border-radius: 999px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
    font-size: 12px;
    font-weight: 900;
}

.badge::before {
    content: "●";
}

.muted {
    opacity: .72;
}

/* Tableau */
.table-wrap {
    overflow: auto;
    max-height: 240px;
    border-radius: 14px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 760px;
}

th,
td {
    padding: 10px;
    border-bottom: 1px solid var(--agent-border);
    text-align: left;
    white-space: nowrap;
    color: inherit;
    font-size: 13px;
    background-color: var(--agent-panel-solid);
    background-image: none;
}

th {
    font-weight: 900;
    position: sticky;
    top: 0;
    z-index: 2;
}

/* Popup : opaque, sans blur */
.agent-popup {
    position: fixed;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    backdrop-filter: none !important;
    z-index: 9999;
    padding: 18px;
    background: transparent;
}

.agent-popup.is-open {
    display: flex;
}

.agent-popup-window {
    width: min(1180px, 97vw);
    max-height: 90vh;
    overflow: hidden;
    border-radius: 20px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-bg-solid);
    color: inherit;
    background-image: none;
    display: flex;
    flex-direction: column;
    box-shadow: none;
}

.agent-popup-head {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 12px;
    padding: 16px 18px;
    border-bottom: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

.popup-title {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
}

.popup-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    font-size: 24px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    background-image: none;
}

.popup-title strong {
    display: block;
    font-size: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.popup-title span {
    display: block;
    font-size: 13px;
    margin-top: 3px;
    opacity: .72;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.agent-popup-body {
    padding: 18px;
    overflow: auto;
    background-color: var(--agent-bg-solid);
    color: inherit;
    background-image: none;
}

/* Détails */
.detail-hero {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
    margin-bottom: 14px;
}

.hero-tile {
    border: 1px solid var(--agent-border);
    border-radius: 14px;
    padding: 12px;
    min-width: 0;
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

.hero-tile span {
    display: block;
    font-size: 12px;
    margin-bottom: 7px;
    opacity: .72;
}

.hero-tile strong {
    display: block;
    font-size: 15px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.detail-layout {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}

.detail-section {
    border: 1px solid var(--agent-border);
    border-radius: 14px;
    overflow: hidden;
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

.detail-section h4 {
    padding: 12px 14px;
    border-bottom: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    background-image: none;
}

.detail-lines {
    padding: 10px 14px;
    display: grid;
    gap: 2px;
}

.detail-line {
    display: grid;
    grid-template-columns: 150px minmax(0, 1fr);
    gap: 12px;
    padding: 8px 0;
    border-bottom: 1px solid var(--agent-border);
}

.detail-line:last-child {
    border-bottom: 0;
}

.detail-label {
    font-size: 13px;
    opacity: .72;
}

.detail-value {
    font-weight: 700;
    word-break: break-word;
    min-width: 0;
}

/* Réseau */
.network-list {
    display: grid;
    gap: 10px;
    padding: 12px 14px;
}

.net-card {
    border: 1px solid var(--agent-border);
    border-radius: 12px;
    padding: 10px;
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
}

.net-name {
    font-weight: 900;
    margin-bottom: 8px;
}

.net-ip {
    display: inline-flex;
    margin: 3px 5px 3px 0;
    padding: 4px 8px;
    border-radius: 999px;
    border: 1px solid var(--agent-border);
    background-color: var(--agent-panel-solid);
    color: inherit;
    background-image: none;
    font-size: 12px;
    font-weight: 800;
}

/* JSON */
.raw-json {
    display: none;
    margin-top: 14px;
}

.raw-json.is-open {
    display: block;
}

pre {
    white-space: pre-wrap;
    word-break: break-word;
    color: inherit;
    background-color: var(--agent-panel-solid);
    background-image: none;
    border: 1px solid var(--agent-border);
    border-radius: 12px;
    padding: 12px;
}

#print-sheet {
    display: none;
}

/* Responsive */
@media (max-width: 850px) {
    .page-head,
    .detail-layout,
    .detail-hero {
        grid-template-columns: 1fr;
        display: grid;
    }

    .agent-summary {
        justify-content: flex-start;
    }

    .detail-line {
        grid-template-columns: 1fr;
        gap: 4px;
    }

    .popup-actions {
        flex-wrap: wrap;
    }
}

/* PDF : noir/blanc volontairement, indépendant du thème */
@media print {
    @page {
        size: A4;
        margin: 8mm;
    }

    body {
        background: #fff !important;
        color: #000 !important;
        padding: 0 !important;
        font-family: Arial, sans-serif !important;
        font-size: 10px !important;
    }

    body.print-detail > *:not(#print-sheet) {
        display: none !important;
    }

    body.print-list #agent-popup,
    body.print-list .table-wrap,
    body.print-list .page-actions,
    body.print-list .agent-delete-btn {
        display: none !important;
    }

    body.print-list::before {
        content: "DOMYDESK - Liste des agents";
        display: block;
        font-size: 18px;
        font-weight: 900;
        color: #000;
        margin-bottom: 8px;
        border-bottom: 2px solid #000;
        padding-bottom: 6px;
    }

    body.print-list .page-head {
        display: block !important;
        margin-bottom: 8px !important;
    }

    body.print-list .agent-summary {
        justify-content: flex-start !important;
        margin-top: 8px !important;
    }

    body.print-list .agents-grid {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 7px !important;
    }

    body.print-list .block {
        padding: 0 !important;
        border: 0 !important;
    }

    body.print-list .agent-card {
        break-inside: avoid;
        page-break-inside: avoid;
        padding: 8px !important;
        border-radius: 8px !important;
    }

    body.print-list .agent-card,
    body.print-list .metric,
    body.print-list .agent-pill {
        background: #fff !important;
        color: #000 !important;
        border: 1px solid #aaa !important;
        box-shadow: none !important;
    }

    body.print-list h2,
    body.print-list h3,
    body.print-list h4,
    body.print-list .agent-name,
    body.print-list .metric-value {
        color: #000 !important;
    }

    body.print-list .agent-sub,
    body.print-list .metric-label,
    body.print-list .page-title p {
        color: #555 !important;
    }

    body.print-list .badge {
        color: #000 !important;
        background: #eee !important;
        border: 1px solid #999 !important;
    }

    body.print-list .block:last-of-type {
        display: none !important;
    }

    body.print-detail #print-sheet {
        display: block !important;
        color: #000 !important;
        background: #fff !important;
    }

    .pdf-sheet {
        width: 100%;
        color: #000;
        background: #fff;
        font-size: 10px;
        line-height: 1.25;
    }

    .pdf-head {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        border-bottom: 2px solid #000;
        padding-bottom: 6px;
        margin-bottom: 8px;
    }

    .pdf-title strong {
        display: block;
        font-size: 18px;
        color: #000;
    }

    .pdf-title span {
        display: block;
        font-size: 10px;
        color: #444;
        margin-top: 2px;
    }

    .pdf-meta {
        text-align: right;
        font-size: 10px;
        color: #333;
    }

    .pdf-grid-4 {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 5px;
        margin-bottom: 6px;
    }

    .pdf-grid-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 6px;
    }

    .pdf-tile,
    .pdf-box {
        border: 1px solid #aaa;
        border-radius: 5px;
        padding: 5px;
        break-inside: avoid;
        page-break-inside: avoid;
    }

    .pdf-tile span {
        display: block;
        font-size: 8px;
        color: #555;
        margin-bottom: 2px;
        text-transform: uppercase;
    }

    .pdf-tile strong {
        display: block;
        font-size: 10px;
        color: #000;
        word-break: break-word;
    }

    .pdf-box h4 {
        color: #000;
        font-size: 11px;
        margin: 0 0 4px;
        padding-bottom: 3px;
        border-bottom: 1px solid #bbb;
    }

    .pdf-line {
        display: grid;
        grid-template-columns: 82px minmax(0, 1fr);
        gap: 5px;
        padding: 2px 0;
        border-bottom: 1px solid #eee;
    }

    .pdf-line:last-child {
        border-bottom: 0;
    }

    .pdf-label {
        color: #555;
        font-weight: 700;
    }

    .pdf-value {
        color: #000;
        font-weight: 600;
        word-break: break-word;
    }

    .pdf-network {
        display: grid;
        gap: 4px;
    }

    .pdf-net {
        border: 1px solid #ddd;
        border-radius: 4px;
        padding: 4px;
        break-inside: avoid;
        page-break-inside: avoid;
    }

    .pdf-net strong {
        display: block;
        font-size: 9px;
        margin-bottom: 2px;
    }

    .pdf-ip {
        display: inline-block;
        border: 1px solid #bbb;
        border-radius: 999px;
        padding: 1px 5px;
        margin: 1px 2px 1px 0;
        font-size: 8px;
    }
}
</style>
<?php require_once dirname(dirname(__DIR__)) . '/core/dmd_theme_assets.php'; echo dmd_theme_extra_links(dirname(dirname(__DIR__)), '../../theme', $themeName, 'agents'); ?>
</head>
<body>

<div class="page-head">
    <div class="page-title">
        <h2>Agents DOMYDESK</h2>
        <p>Inventaire des périphériques connectés à DoMyDesk.</p>

        <div class="page-actions">
            <button type="button" class="export-btn" onclick="printAgentsList()">
                Exporter la liste PDF
            </button>
        </div>
    </div>

    <div class="agent-summary">
        <div class="agent-pill">Total : <?= (int)$total ?></div>
        <div class="agent-pill">Online : <?= (int)$online ?></div>
        <div class="agent-pill">Attention : <?= (int)$warning ?></div>
        <div class="agent-pill">Offline : <?= (int)$offline ?></div>
    </div>
</div>

<div class="block">
    <?php if (!$agents): ?>
        <p class="muted">Aucun agent détecté pour le moment.</p>
    <?php else: ?>
        <div class="agents-grid">
            <?php foreach ($agents as $machineId => $agent):
                if (!is_array($agent)) continue;

                $status = dmd_agent_status($agent);
                $hostname = dmd_agent_hostname($agent);
                $osName = dmd_agent_os_name($agent);
                $arch = dmd_agent_arch($agent);
                $version = dmd_agent_version($agent);
                $cpu = dmd_agent_cpu($agent);
                $ram = dmd_agent_ram($agent);
                $uptime = dmd_agent_uptime($agent);
                $localIp = dmd_first_local_ip($agent);
                $icon = dmd_os_icon($osName);
            ?>
                <div class="agent-card" onclick="openAgentDetail('<?= h($machineId) ?>')">
                    <div class="agent-top">
                        <div class="agent-icon"><?= h($icon) ?></div>
                        <div style="min-width:0;">
                            <div class="agent-name"><?= h($hostname) ?></div>
                            <div class="agent-sub"><?= h(trim($osName . ' · ' . $arch)) ?></div>
                        </div>
                    </div>

                    <div class="agent-metrics">
                        <div class="metric">
                            <span class="metric-label">IP locale</span>
                            <span class="metric-value"><?= h($localIp) ?></span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Agent</span>
                            <span class="metric-value"><?= h($version) ?></span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">RAM</span>
                            <span class="metric-value"><?= h($ram) ?></span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Uptime</span>
                            <span class="metric-value"><?= h($uptime) ?></span>
                        </div>
                    </div>

                    <div class="metric" style="margin-bottom:10px;">
                        <span class="metric-label">CPU</span>
                        <span class="metric-value"><?= h($cpu) ?></span>
                    </div>

                    <div class="agent-footer">
                        <span class="badge <?= h($status) ?>"><?= h($status) ?></span>

                        <form method="post" onsubmit="event.stopPropagation(); return confirm('Supprimer cet agent de DoMyDesk ?');">
                            <input type="hidden" name="machine_id" value="<?= h($machineId) ?>">
                            <button type="submit" name="delete_agent" value="1" class="agent-delete-btn" onclick="event.stopPropagation();">
                                Supprimer
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<div class="block">
    <h3 style="margin-bottom:12px;">Derniers heartbeats</h3>

    <?php if (!$logs): ?>
        <p class="muted">Aucun heartbeat reçu.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Machine ID</th>
                        <th>Hostname</th>
                        <th>IP</th>
                        <th>Version</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach (array_slice($logs, 0, 40) as $log): ?>
                        <tr>
                            <td><?= h($log['date'] ?? '') ?></td>
                            <td><?= h($log['machine_id'] ?? '') ?></td>
                            <td><?= h($log['hostname'] ?? '') ?></td>
                            <td><?= h($log['ip'] ?? '') ?></td>
                            <td><?= h($log['agent_version'] ?? $log['version'] ?? '') ?></td>
                            <td><?= h($log['status'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<div id="agent-popup" class="agent-popup" onclick="if(event.target === this) closeAgentDetail();">
    <div class="agent-popup-window">
        <div class="agent-popup-head">
            <div class="popup-title">
                <div id="popup-icon" class="popup-icon">💻</div>
                <div style="min-width:0;">
                    <strong id="popup-hostname">Détail agent</strong>
                    <span id="popup-subtitle"></span>
                </div>
            </div>

            <div class="popup-actions">
                <button type="button" class="popup-btn" onclick="printAgentDetail()">Exporter PDF</button>
                <button type="button" class="popup-btn" onclick="closeAgentDetail()">Fermer</button>
            </div>
        </div>

        <div class="agent-popup-body" id="agent-popup-body"></div>
    </div>
</div>

<div id="print-sheet"></div>

<script>
function dmdApplyAgentThemeSurfaces() {
    const root = document.documentElement;
    const bodyStyle = getComputedStyle(document.body);
    const htmlStyle = getComputedStyle(document.documentElement);

    function usableColor(value) {
        if (!value) return '';
        value = String(value).trim();
        if (
            value === 'transparent' ||
            value === 'rgba(0, 0, 0, 0)' ||
            value === 'rgba(0,0,0,0)'
        ) {
            return '';
        }
        return value;
    }

    function pickBackground() {
        return usableColor(bodyStyle.backgroundColor)
            || usableColor(htmlStyle.backgroundColor)
            || '';
    }

    const bg = pickBackground();
    const text = usableColor(bodyStyle.color) || usableColor(htmlStyle.color) || '';

    if (bg) {
        root.style.setProperty('--agent-bg-solid', bg);
        root.style.setProperty('--agent-panel-solid', bg);
    }

    if (text) {
        root.style.setProperty('--agent-text-solid', text);
    }
}

dmdApplyAgentThemeSurfaces();

const AGENTS = <?= json_encode($agentsForJs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;
let CURRENT_AGENT_ID = null;

function esc(value) {
    return String(value ?? '').replace(/[&<>"']/g, function(m) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#039;'}[m];
    });
}

function cleanIp(ip) {
    ip = String(ip ?? '').trim();
    if (!ip) return '';
    if (ip.includes('/')) ip = ip.split('/')[0];
    return ip;
}

function osIcon(os) {
    os = String(os ?? '').toLowerCase();
    if (os.includes('windows')) return '🪟';
    if (os.includes('linux')) return '🐧';
    if (os.includes('darwin') || os.includes('mac')) return '🍎';
    if (os.includes('android')) return '🤖';
    if (os.includes('ios')) return '📱';
    return '💻';
}

function line(label, value) {
    return `
        <div class="detail-line">
            <div class="detail-label">${esc(label)}</div>
            <div class="detail-value">${esc(value || '-')}</div>
        </div>
    `;
}

function section(title, lines) {
    return `
        <div class="detail-section">
            <h4>${esc(title)}</h4>
            <div class="detail-lines">${lines}</div>
        </div>
    `;
}

function hero(label, value) {
    return `
        <div class="hero-tile">
            <span>${esc(label)}</span>
            <strong>${esc(value || '-')}</strong>
        </div>
    `;
}

function pdfLine(label, value) {
    return `
        <div class="pdf-line">
            <div class="pdf-label">${esc(label)}</div>
            <div class="pdf-value">${esc(value || '-')}</div>
        </div>
    `;
}

function pdfBox(title, lines) {
    return `
        <div class="pdf-box">
            <h4>${esc(title)}</h4>
            ${lines}
        </div>
    `;
}

function pdfTile(label, value) {
    return `
        <div class="pdf-tile">
            <span>${esc(label)}</span>
            <strong>${esc(value || '-')}</strong>
        </div>
    `;
}

function formatNetwork(network) {
    if (!Array.isArray(network) || !network.length) {
        return `<div class="network-list"><p class="muted">Aucune interface réseau disponible.</p></div>`;
    }

    let html = `<div class="network-list">`;

    network.forEach(iface => {
        const name = iface?.name || 'Interface';
        const mac = iface?.mac || '';
        const ips = Array.isArray(iface?.ips) ? iface.ips : [];

        html += `<div class="net-card">`;
        html += `<div class="net-name">${esc(name)}</div>`;

        if (mac) {
            html += `<div class="detail-line" style="grid-template-columns:90px minmax(0,1fr);">
                <div class="detail-label">MAC</div>
                <div class="detail-value">${esc(mac)}</div>
            </div>`;
        }

        const filtered = ips
            .map(cleanIp)
            .filter(ip => ip && !ip.startsWith('127.') && !ip.startsWith('::1'));

        if (filtered.length) {
            filtered.forEach(ip => {
                html += `<span class="net-ip">${esc(ip)}</span>`;
            });
        } else {
            html += `<span class="muted">Aucune IP utile</span>`;
        }

        html += `</div>`;
    });

    html += `</div>`;
    return html;
}

function formatNetworkPdf(network) {
    if (!Array.isArray(network) || !network.length) {
        return `<div class="pdf-net">Aucune interface réseau disponible.</div>`;
    }

    let html = `<div class="pdf-network">`;

    network.forEach(iface => {
        const name = iface?.name || 'Interface';
        const mac = iface?.mac || '';
        const ips = Array.isArray(iface?.ips) ? iface.ips : [];

        const filtered = ips
            .map(cleanIp)
            .filter(ip => ip && !ip.startsWith('127.') && !ip.startsWith('::1'));

        html += `<div class="pdf-net">`;
        html += `<strong>${esc(name)}</strong>`;

        if (mac) {
            html += `<div>${esc(mac)}</div>`;
        }

        if (filtered.length) {
            filtered.forEach(ip => {
                html += `<span class="pdf-ip">${esc(ip)}</span>`;
            });
        } else {
            html += `<div>Aucune IP utile</div>`;
        }

        html += `</div>`;
    });

    html += `</div>`;
    return html;
}

function localIps(agent) {
    const network = agent?.inventory?.network || [];
    let ips = [];

    network.forEach(iface => {
        (iface.ips || []).forEach(ip => {
            ip = cleanIp(ip);

            if (
                ip &&
                !ip.startsWith('127.') &&
                !ip.startsWith('::1') &&
                !ip.toLowerCase().startsWith('fe80:')
            ) {
                ips.push(ip);
            }
        });
    });

    return [...new Set(ips)];
}

function openAgentDetail(machineId) {
    const agent = AGENTS[machineId];
    if (!agent) return;

    CURRENT_AGENT_ID = machineId;

    const inv = agent.inventory || {};
    const os = inv.os || {};
    const cpu = inv.cpu || {};
    const ram = inv.ram || {};
    const uptime = inv.uptime || {};
    const network = inv.network || [];

    const hostname = agent._hostname || inv.hostname || agent.hostname || 'Périphérique';
    const osName = agent._os_name || os.name || agent.os || '-';
    const osVersion = agent._os_version || os.version || '-';
    const arch = agent._arch || inv.arch || agent.arch || '-';
    const cpuText = agent._cpu || '-';
    const ramText = agent._ram || '-';
    const ips = localIps(agent);
    const capabilities = Array.isArray(agent.capabilities) ? agent.capabilities : [];

    document.getElementById('popup-icon').textContent = osIcon(osName);
    document.getElementById('popup-hostname').textContent = hostname;
    document.getElementById('popup-subtitle').textContent = `${osName} · ${arch} · Agent ${agent.agent_version || '-'}`;

    let html = '';

    html += `<div class="detail-hero">`;
    html += hero('Statut', agent._status || '-');
    html += hero('IP locale', ips[0] || '-');
    html += hero('RAM', ramText);
    html += hero('Uptime', uptime.human || '-');
    html += `</div>`;

    html += `<div class="detail-layout">`;

    html += section('Résumé', [
        line('Machine ID', agent.machine_id),
        line('Hostname', hostname),
        line('IP vue DoMyDesk', agent.ip),
        line('Dernier contact', agent.last_seen),
        line('Version agent', agent.agent_version)
    ].join(''));

    html += section('Système', [
        line('OS', osName),
        line('Version OS', osVersion),
        line('Architecture', arch),
        line('Utilisateur', inv.user),
        line('Démarré depuis', uptime.human)
    ].join(''));

    html += section('Hardware', [
        line('CPU', cpuText),
        line('Modèle CPU', cpu.model),
        line('Cœurs', cpu.cores),
        line('RAM totale', ram.total_gb ? ram.total_gb + ' Go' : '-'),
        line('RAM utilisée', ram.used_gb ? ram.used_gb + ' Go' : '-'),
        line('RAM libre', ram.free_gb ? ram.free_gb + ' Go' : '-')
    ].join(''));

    html += `
        <div class="detail-section">
            <h4>Réseau</h4>
            ${formatNetwork(network)}
        </div>
    `;

    html += section('Agent', [
        line('Capabilities', capabilities.join(', ') || '-'),
        line('Payload time', agent.last_payload_time),
        line('Résultats commandes', Array.isArray(agent.last_results) && agent.last_results.length ? agent.last_results.length + ' résultat(s)' : '-')
    ].join(''));

    html += `</div>`;

    html += `<button type="button" class="raw-toggle" onclick="toggleRawJson()">Afficher / masquer JSON brut</button>`;
    html += `<div id="raw-json" class="raw-json"><pre>${esc(JSON.stringify(agent, null, 2))}</pre></div>`;

    document.getElementById('agent-popup-body').innerHTML = html;
    document.getElementById('agent-popup').classList.add('is-open');
}

function buildCompactPrintSheet(agent) {
    const inv = agent.inventory || {};
    const os = inv.os || {};
    const cpu = inv.cpu || {};
    const ram = inv.ram || {};
    const uptime = inv.uptime || {};
    const network = inv.network || [];

    const hostname = agent._hostname || inv.hostname || agent.hostname || 'Périphérique';
    const osName = agent._os_name || os.name || agent.os || '-';
    const osVersion = agent._os_version || os.version || '-';
    const arch = agent._arch || inv.arch || agent.arch || '-';
    const cpuText = agent._cpu || '-';
    const ramText = agent._ram || '-';
    const ips = localIps(agent);
    const capabilities = Array.isArray(agent.capabilities) ? agent.capabilities : [];

    let html = `<div class="pdf-sheet">`;

    html += `
        <div class="pdf-head">
            <div class="pdf-title">
                <strong>DOMYDESK - Fiche périphérique</strong>
                <span>${esc(hostname)} · ${esc(osName)} · Agent ${esc(agent.agent_version || '-')}</span>
            </div>
            <div class="pdf-meta">
                Export : ${esc(new Date().toLocaleString('fr-FR'))}<br>
                Dernier contact : ${esc(agent.last_seen || '-')}
            </div>
        </div>
    `;

    html += `<div class="pdf-grid-4">`;
    html += pdfTile('Statut', agent._status || '-');
    html += pdfTile('IP locale', ips[0] || '-');
    html += pdfTile('RAM', ramText);
    html += pdfTile('Uptime', uptime.human || '-');
    html += `</div>`;

    html += `<div class="pdf-grid-2">`;

    html += pdfBox('Résumé', [
        pdfLine('Machine ID', agent.machine_id),
        pdfLine('Hostname', hostname),
        pdfLine('IP DoMyDesk', agent.ip),
        pdfLine('Agent', agent.agent_version)
    ].join(''));

    html += pdfBox('Système', [
        pdfLine('OS', osName),
        pdfLine('Version', osVersion),
        pdfLine('Arch', arch),
        pdfLine('Utilisateur', inv.user)
    ].join(''));

    html += pdfBox('Hardware', [
        pdfLine('CPU', cpuText),
        pdfLine('Cœurs', cpu.cores),
        pdfLine('RAM totale', ram.total_gb ? ram.total_gb + ' Go' : '-'),
        pdfLine('RAM utilisée', ram.used_gb ? ram.used_gb + ' Go' : '-'),
        pdfLine('RAM libre', ram.free_gb ? ram.free_gb + ' Go' : '-')
    ].join(''));

    html += pdfBox('Agent', [
        pdfLine('Capabilities', capabilities.join(', ') || '-'),
        pdfLine('Payload', agent.last_payload_time),
        pdfLine('Résultats', Array.isArray(agent.last_results) && agent.last_results.length ? agent.last_results.length + ' résultat(s)' : '-')
    ].join(''));

    html += `
        <div class="pdf-box">
            <h4>Réseau</h4>
            ${formatNetworkPdf(network)}
        </div>
    `;

    html += `</div>`;
    html += `</div>`;

    return html;
}

function closeAgentDetail() {
    document.getElementById('agent-popup').classList.remove('is-open');
}

function toggleRawJson() {
    document.getElementById('raw-json')?.classList.toggle('is-open');
}

function printAgentsList() {
    document.body.classList.remove('print-detail');
    document.body.classList.add('print-list');
    document.getElementById('print-sheet').innerHTML = '';

    window.print();

    setTimeout(function() {
        document.body.classList.remove('print-list');
    }, 500);
}

function printAgentDetail() {
    if (!CURRENT_AGENT_ID || !AGENTS[CURRENT_AGENT_ID]) {
        alert('Ouvre d’abord un périphérique.');
        return;
    }

    document.getElementById('print-sheet').innerHTML = buildCompactPrintSheet(AGENTS[CURRENT_AGENT_ID]);

    document.body.classList.remove('print-list');
    document.body.classList.add('print-detail');

    window.print();

    setTimeout(function() {
        document.body.classList.remove('print-detail');
        document.getElementById('print-sheet').innerHTML = '';
    }, 500);
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeAgentDetail();
});
</script>

</body>
</html>