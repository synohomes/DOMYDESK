<?php
header('Content-Type: application/json; charset=UTF-8');

$baseDir = dirname(__DIR__); // /data/agents
$agentsFile = $baseDir . '/agents.json';
$logsDir = $baseDir . '/logs/';
$commandsDir = $baseDir . '/commands/';

$heartbeatLog = $logsDir . 'heartbeats.json';

@mkdir($baseDir, 0775, true);
@mkdir($logsDir, 0775, true);
@mkdir($commandsDir, 0775, true);

function dmd_json_read(string $file, array $default = []): array {
    if (!is_file($file)) {
        return $default;
    }

    $data = json_decode((string)file_get_contents($file), true);
    return is_array($data) ? $data : $default;
}

function dmd_json_write(string $file, array $data): bool {
    $dir = dirname($file);

    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }

    $ok = file_put_contents(
        $file,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        LOCK_EX
    ) !== false;

    if ($ok) {
        @chmod($file, 0664);
    }

    return $ok;
}

function dmd_client_ip(): string {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $value = trim((string)$_SERVER[$key]);
            if (str_contains($value, ',')) {
                $value = trim(explode(',', $value)[0]);
            }
            return $value;
        }
    }

    return '';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'POST uniquement'
    ]);
    exit;
}

$raw = file_get_contents('php://input');
$payload = json_decode((string)$raw, true);

if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'JSON invalide'
    ]);
    exit;
}

$machineId = trim((string)($payload['machine_id'] ?? ''));

if ($machineId === '') {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'machine_id manquant'
    ]);
    exit;
}

$now = date('Y-m-d H:i:s');
$ip = dmd_client_ip();

$agents = dmd_json_read($agentsFile, []);

$inventory = is_array($payload['inventory'] ?? null) ? $payload['inventory'] : [];

$agents[$machineId] = [
    'machine_id' => $machineId,
    'agent_version' => (string)($payload['agent_version'] ?? ''),
    'capabilities' => is_array($payload['capabilities'] ?? null) ? $payload['capabilities'] : [],
    'inventory' => $inventory,
    'ip' => $ip,
    'last_seen' => $now,
    'last_payload_time' => (string)($payload['time'] ?? ''),
    'last_results' => is_array($payload['results'] ?? null) ? $payload['results'] : [],
];

dmd_json_write($agentsFile, $agents);

$logs = dmd_json_read($heartbeatLog, []);
$logs[] = [
    'date' => $now,
    'machine_id' => $machineId,
    'hostname' => (string)($inventory['hostname'] ?? ''),
    'ip' => $ip,
    'agent_version' => (string)($payload['agent_version'] ?? ''),
    'results' => is_array($payload['results'] ?? null) ? $payload['results'] : [],
    'status' => 'ok',
];

if (count($logs) > 500) {
    $logs = array_slice($logs, -500);
}

dmd_json_write($heartbeatLog, $logs);

$commandsFile = $commandsDir . $machineId . '.json';
$commands = dmd_json_read($commandsFile, []);

if (!isset($commands['commands']) || !is_array($commands['commands'])) {
    $commands = ['commands' => []];
}

$responseCommands = $commands['commands'];

/*
    Important :
    Pour éviter que l'agent répète la même commande update en boucle,
    on vide le fichier dès qu'on lui a envoyé les commandes.
*/
if (!empty($responseCommands)) {
    dmd_json_write($commandsFile, [
        'commands' => [],
        'last_sent_at' => $now,
        'last_sent_count' => count($responseCommands)
    ]);
}

echo json_encode([
    'status' => 'ok',
    'message' => 'heartbeat reçu',
    'commands' => $responseCommands
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);