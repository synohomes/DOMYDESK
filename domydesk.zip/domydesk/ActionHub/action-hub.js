(function () {
    'use strict';

    let config = {
        endpoint: 'ActionHub/api.php',
        quickSessionApiUrl: 'Quick-Session/api.php',
        csrfToken: '',
        quickSessionCsrfToken: '',
        currentDashboard: 'dashboard',
        quickSessionActive: false,
        quickSessionView: false
    };
    const providers = [];
    let overlay = null;
    let currentContext = null;
    let currentMode = 'context';
    let globalResources = [];
    let scenarioList = [];
    let scenarioCatalog = [];
    let scenarioUsers = [];
    let scenarioDraft = null;
    let scenarioSearchTimer = null;
    let scenarioBusy = false;

    function safeText(value, fallback) {
        const v = String(value == null ? '' : value).trim();
        return v || String(fallback == null ? '' : fallback);
    }

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }

    function toast(message) {
        if (window.DMDWorkspace && typeof window.DMDWorkspace.toast === 'function') {
            window.DMDWorkspace.toast(message);
        } else {
            console.log('[ActionHub]', message);
        }
    }

    function normalizeContext(raw) {
        if (!raw || typeof raw !== 'object') return null;
        const id = safeText(raw.id, '');
        if (!id) return null;
        const tags = Array.isArray(raw.tags) ? raw.tags : String(raw.tags || '').split(',');
        return {
            type: safeText(raw.type, 'object').toLowerCase(),
            id,
            label: safeText(raw.label || raw.name, id),
            name: safeText(raw.name || raw.label, id),
            source: safeText(raw.source || raw.module, ''),
            tags: tags.map(v => safeText(v, '')).filter(Boolean).slice(0, 20)
        };
    }

    function contextFromElement(el) {
        if (!el || !el.closest) return null;
        const host = el.closest('[data-dmd-context], [data-dmd-context-type][data-dmd-context-id], [data-dmd-action-hub="1"]');
        if (!host) return null;
        return normalizeContext({
            type: host.dataset.dmdContextType || host.dataset.dmdActionHubType || 'object',
            id: host.dataset.dmdContextId || host.dataset.dmdActionHubId || '',
            label: host.dataset.dmdContextLabel || host.dataset.dmdContextName || host.dataset.dmdActionHubName || host.dataset.dmdContextId || '',
            source: host.dataset.dmdContextSource || host.dataset.dmdModuleId || host.dataset.dmdActionHubModule || '',
            tags: host.dataset.dmdContextTags || ''
        });
    }

    function ensureOverlay() {
        if (overlay) return overlay;
        overlay = document.createElement('div');
        overlay.className = 'dmd-action-hub-overlay dmd-popup-overlay';
        overlay.setAttribute('role', 'dialog');
        overlay.setAttribute('aria-modal', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        overlay.innerHTML = `
            <div class="dmd-action-hub-panel">
                <div class="dmd-action-hub-head" data-dmd-window-handle>
                    <strong>⚡ ActionHub</strong>
                    <button class="dmd-action-hub-close" type="button" aria-label="Fermer">×</button>
                </div>
                <div class="dmd-action-hub-body">
                    <p class="dmd-action-hub-meta"></p>
                    <div class="dmd-action-hub-content"></div>
                </div>
            </div>`;
        document.body.appendChild(overlay);

        const panel = overlay.querySelector('.dmd-action-hub-panel');
        if (window.DMDWorkspace && typeof window.DMDWorkspace.registerPopup === 'function') {
            window.DMDWorkspace.registerPopup(panel, { key: 'actionhub:main', handle: '.dmd-action-hub-head' });
        }

        overlay.addEventListener('click', event => {
            if (event.target === overlay || event.target.closest('.dmd-action-hub-close')) {
                close();
                return;
            }
            const scenarioRun = event.target.closest('[data-dmd-ah-scenario-run]');
            if (scenarioRun) {
                executeScenario(String(scenarioRun.dataset.dmdAhScenarioRun || ''));
                return;
            }
            const scenarioEdit = event.target.closest('[data-dmd-ah-scenario-edit]');
            if (scenarioEdit) {
                const id = String(scenarioEdit.dataset.dmdAhScenarioEdit || '');
                const scenario = scenarioList.find(item => String(item.id || '') === id);
                if (scenario) openScenarioEditor(scenario);
                return;
            }
            const scenarioDelete = event.target.closest('[data-dmd-ah-scenario-delete]');
            if (scenarioDelete) {
                deleteScenario(String(scenarioDelete.dataset.dmdAhScenarioDelete || ''));
                return;
            }
            if (event.target.closest('[data-dmd-ah-scenario-new]')) {
                openScenarioEditor(null);
                return;
            }
            if (event.target.closest('[data-dmd-ah-scenario-back]')) {
                renderGlobal(globalResources, scenarioList);
                return;
            }
            if (event.target.closest('[data-dmd-ah-scenario-save]')) {
                saveScenarioDraft();
                return;
            }
            if (event.target.closest('[data-dmd-ah-step-add]')) {
                addScenarioStep();
                return;
            }
            const stepRemove = event.target.closest('[data-dmd-ah-step-remove]');
            if (stepRemove) {
                removeScenarioStep(Number(stepRemove.dataset.dmdAhStepRemove));
                return;
            }

            const resourceForget = event.target.closest('[data-dmd-ah-resource-forget]');
            if (resourceForget && Array.isArray(overlay._resources)) {
                forgetGlobalResource(Number(resourceForget.dataset.dmdAhResourceForget));
                return;
            }
            const resourceSelectAll = event.target.closest('[data-dmd-ah-resource-select-all]');
            if (resourceSelectAll) {
                const checked = !!resourceSelectAll.checked;
                overlay.querySelectorAll('[data-dmd-ah-resource-select]').forEach(box => {
                    if (!box.closest('.dmd-action-hub-resource-row').hidden) box.checked = checked;
                });
                updateBulkResourceButton();
                return;
            }
            const resourceSelect = event.target.closest('[data-dmd-ah-resource-select]');
            if (resourceSelect) { updateBulkResourceButton(); return; }
            if (event.target.closest('[data-dmd-ah-resource-forget-selected]')) {
                forgetSelectedGlobalResources();
                return;
            }
            const resourceBtn = event.target.closest('[data-dmd-ah-resource-index]');
            if (resourceBtn && Array.isArray(overlay._resources)) {
                const entry = overlay._resources[Number(resourceBtn.dataset.dmdAhResourceIndex)];
                if (entry) open(entry.resource || entry);
                return;
            }
            const actionBtn = event.target.closest('[data-dmd-ah-action-index]');
            if (actionBtn && Array.isArray(overlay._actions) && currentContext) {
                const action = overlay._actions[Number(actionBtn.dataset.dmdAhActionIndex)];
                if (action && typeof action.handler === 'function') action.handler(currentContext, action);
            }
        });

        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && overlay && overlay.classList.contains('is-open')) close();
        });
        return overlay;
    }

    function show() {
        const el = ensureOverlay();
        el.classList.add('is-open');
        el.setAttribute('aria-hidden', 'false');
    }

    function close() {
        if (!overlay) return;
        overlay.classList.remove('is-open');
        overlay.setAttribute('aria-hidden', 'true');
        currentContext = null;
    }

    async function post(action, payload) {
        const response = await fetch(config.endpoint + '?action=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                'Content-Type': 'application/json',
                'X-DMD-CSRF': config.csrfToken || ''
            },
            body: JSON.stringify(payload || {})
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) {
            const error = new Error(data.message || data.error || action + '_failed');
            error.code = data.error || '';
            error.data = data;
            error.httpStatus = response.status;
            throw error;
        }
        return data;
    }

    async function executeScenarioRequest(id) {
        const response = await fetch(config.endpoint + '?action=scenario_execute', {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                'Content-Type': 'application/json',
                'X-DMD-CSRF': config.csrfToken || ''
            },
            body: JSON.stringify({ id: id })
        });

        const data = await response.json().catch(() => null);
        if (!data || typeof data !== 'object') {
            throw new Error('Réponse ActionHub invalide.');
        }

        /*
         * Une étape en erreur est un résultat fonctionnel du scénario,
         * pas une panne de transport. On renvoie donc le résultat même
         * quand l'API utilise HTTP 400 afin de pouvoir afficher l'étape
         * et son vrai message à l'utilisateur.
         */
        if (!response.ok && !Array.isArray(data.results) && !data.message) {
            const error = new Error(data.error || 'scenario_execute_failed');
            error.code = data.error || '';
            error.data = data;
            error.httpStatus = response.status;
            throw error;
        }

        return data;
    }

    async function get(action, params) {
        const query = new URLSearchParams(params || {});
        query.set('action', action);
        query.set('_', String(Date.now()));
        const response = await fetch(config.endpoint + '?' + query.toString(), {
            method: 'GET',
            credentials: 'same-origin',
            cache: 'no-store'
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) throw new Error(data.error || action + '_failed');
        return data;
    }

    async function quickSessionPost(action, payload) {
        const response = await fetch(config.quickSessionApiUrl + '?action=' + encodeURIComponent(action), {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                'Content-Type': 'application/json',
                'X-DMD-CSRF': config.quickSessionCsrfToken || ''
            },
            body: JSON.stringify(payload || {})
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) throw new Error(data.error || action + '_failed');
        return data;
    }

    async function filterAuthorized(actions) {
        const list = Array.isArray(actions) ? actions.filter(Boolean) : [];
        const checks = [];
        const positions = [];
        list.forEach((action, index) => {
            const moduleId = safeText(action.moduleId || action.module, '');
            if (!moduleId) return;
            checks.push({ module: moduleId, permission: safeText(action.permission, 'use') });
            positions.push(index);
        });
        if (!checks.length) return list;
        try {
            const data = await post('authorize', { checks });
            const decision = new Map();
            positions.forEach((position, i) => decision.set(position, !!data.allowed[i]));
            return list.filter((action, index) => !decision.has(index) || decision.get(index));
        } catch (error) {
            console.error('[ActionHub authorize]', error);
            return list.filter((action, index) => !positions.includes(index));
        }
    }

    async function serverDeclaredActions(context) {
        try {
            const data = await post('resource_actions', { context });
            const declared = Array.isArray(data.actions) ? data.actions : [];
            return declared.map(action => {
                if (!action || typeof action !== 'object') return null;
                const moduleId = safeText(action.module, context.source || '');
                const actionId = safeText(action.id, '');
                if (!moduleId || !actionId) return null;
                return {
                    id: actionId,
                    moduleId,
                    permission: safeText(action.permission, 'module.view'),
                    icon: safeText(action.icon, '⚡'),
                    label: safeText(action.label, actionId),
                    description: safeText(action.description, ''),
                    dangerous: !!action.dangerous,
                    confirm: safeText(action.confirm, ''),
                    handler: async ctx => {
                        const confirmation = safeText(action.confirm, '') || (action.dangerous ? 'Confirmer l’action « ' + safeText(action.label, actionId) + ' » ?' : '');
                        if (confirmation && !window.confirm(confirmation)) return;
                        try {
                            const result = await post('execute', {
                                module: moduleId,
                                action_id: actionId,
                                resource: ctx,
                                payload: {}
                            });
                            toast(result.message || 'Action exécutée.');
                            document.dispatchEvent(new CustomEvent('dmd:actionhub-action-complete', {
                                detail: { action, result, context: ctx }
                            }));
                            close();
                        } catch (error) {
                            console.error('[ActionHub execute]', error);
                            toast('Action ActionHub impossible.');
                        }
                    }
                };
            }).filter(Boolean);
        } catch (error) {
            console.error('[ActionHub actions]', error);
            return [];
        }
    }

    function dedupeActions(actions) {
        const seen = new Set();
        return (Array.isArray(actions) ? actions : []).filter(action => {
            if (!action) return false;
            const key = [
                safeText(action.moduleId || action.module, ''),
                safeText(action.id, ''),
                safeText(action.label, '')
            ].join('|').toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    async function builtinActions(context) {
        const actions = [];

        // Les actions réelles du module passent toujours en premier.
        const declaredActions = await serverDeclaredActions(context);
        declaredActions.forEach(action => actions.push(action));

        for (const provider of providers) {
            try {
                const supports = typeof provider.supports === 'function' ? await provider.supports(context) : true;
                if (!supports) continue;
                const extra = typeof provider.getActions === 'function' ? await provider.getActions(context) : [];
                if (!Array.isArray(extra)) continue;
                extra.forEach(action => {
                    if (!action || typeof action !== 'object') return;
                    const normalized = Object.assign({}, action);
                    if (!normalized.moduleId && !normalized.module && provider.moduleId) normalized.moduleId = provider.moduleId;
                    actions.push(normalized);
                });
            } catch (error) {
                console.error('[ActionHub provider]', provider.name || provider.moduleId || 'provider', error);
            }
        }

        // Quick-Session reste un complément de contexte, jamais l'action principale d'ActionHub.
        if (config.quickSessionActive) {
            actions.push({
                id: 'quick-session.add-resource',
                group: 'quick-session',
                icon: '🚨', label: 'Ajouter à la Quick-Session',
                description: 'Associer cette ressource à la session active.',
                handler: async ctx => {
                    try {
                        const data = await quickSessionPost('add_resource', { resource: ctx });
                        toast(data.added ? 'Ressource ajoutée à la Quick-Session.' : 'Ressource déjà présente dans la Quick-Session.');
                        document.dispatchEvent(new CustomEvent('dmd:quick-session-context-changed', { detail: { source: 'actionhub', added: !!data.added } }));
                        close();
                    } catch (error) { toast('Impossible d’ajouter cette ressource à la Quick-Session.'); }
                }
            });
        } else {
            actions.push({
                id: 'quick-session.start-resource',
                group: 'quick-session',
                icon: '🚨', label: 'Démarrer une Quick-Session',
                description: 'Utiliser cette ressource comme premier contexte.',
                handler: async ctx => {
                    try {
                        const data = await quickSessionPost('start_with_resource', { resource: ctx, origin_dashboard: config.currentDashboard || 'dashboard' });
                        const origin = data.origin_dashboard || config.currentDashboard || 'dashboard';
                        location.href = '?quick_session=1&from=' + encodeURIComponent(origin);
                    } catch (error) { toast('Impossible de démarrer la Quick-Session.'); }
                }
            });
        }

        return filterAuthorized(dedupeActions(actions));
    }

    async function procedures(context) {
        try {
            const data = await post('procedures', { context });
            return Array.isArray(data.procedures) ? data.procedures : [];
        } catch (error) {
            return [];
        }
    }

    function renderContext(context, actions, procedureList) {
        const el = ensureOverlay();
        overlay._actions = Array.isArray(actions) ? actions : [];
        overlay._resources = [];
        el.querySelector('.dmd-action-hub-head strong').innerHTML = `⚡ ${esc(context.label)} <span class="dmd-action-hub-context-type">${esc(context.type)}</span>`;
        el.querySelector('.dmd-action-hub-meta').textContent = context.source ? 'Source : ' + context.source : 'Ressource DoMyDesk';
        let html = '<div class="dmd-action-hub-actions">';
        const primary = [];
        const contextActions = [];
        overlay._actions.forEach((action, index) => {
            (action.group === 'quick-session' ? contextActions : primary).push({ action, index });
        });
        if (primary.length) html += '<div class="dmd-action-hub-section-title">Actions du module</div>';
        primary.forEach(entry => {
            const action = entry.action;
            html += `<button class="dmd-action-hub-action" type="button" data-dmd-ah-action-index="${entry.index}">
                <span class="dmd-action-hub-action-icon">${esc(action.icon || '⚡')}</span>
                <span class="dmd-action-hub-action-text"><strong>${esc(action.label || 'Action')}</strong>${action.description ? `<small>${esc(action.description)}</small>` : ''}</span>
            </button>`;
        });
        if (contextActions.length) html += '<div class="dmd-action-hub-section-title">Quick-Session</div>';
        contextActions.forEach(entry => {
            const action = entry.action;
            html += `<button class="dmd-action-hub-action" type="button" data-dmd-ah-action-index="${entry.index}">
                <span class="dmd-action-hub-action-icon">${esc(action.icon || '🚨')}</span>
                <span class="dmd-action-hub-action-text"><strong>${esc(action.label || 'Action')}</strong>${action.description ? `<small>${esc(action.description)}</small>` : ''}</span>
            </button>`;
        });
        if (Array.isArray(procedureList) && procedureList.length) {
            html += '<div class="dmd-action-hub-section-title">Procédures suggérées</div>';
            procedureList.forEach(proc => {
                html += `<a class="dmd-action-hub-procedure dmd-document-link" href="${esc(proc.url)}" data-dmd-document-title="${esc(proc.procedure)}">
                    <span class="dmd-action-hub-action-icon">📚</span><span class="dmd-action-hub-action-text"><strong>${esc(proc.procedure)}</strong><small>Correspondance ${Number(proc.score) || 0} %</small></span></a>`;
            });
        }
        if (!overlay._actions.length && (!procedureList || !procedureList.length)) {
            html += '<p class="dmd-action-hub-empty">Aucune action compatible n’est déclarée pour cette ressource.</p>';
        }
        html += '</div>';
        el.querySelector('.dmd-action-hub-content').innerHTML = html;
    }

    async function open(rawContext) {
        const context = normalizeContext(rawContext);
        if (!context) return;
        currentMode = 'context';
        currentContext = context;
        const el = ensureOverlay();
        el.dataset.dmdAhMode = 'context';
        el.querySelector('.dmd-action-hub-head strong').textContent = '⚡ ' + context.label;
        el.querySelector('.dmd-action-hub-meta').textContent = 'Recherche des actions disponibles…';
        el.querySelector('.dmd-action-hub-content').innerHTML = '<p class="dmd-action-hub-empty">Chargement…</p>';
        show();
        document.dispatchEvent(new CustomEvent('dmd:action-hub-open', { detail: { context } }));
        const result = await Promise.all([builtinActions(context), procedures(context)]);
        if (!currentContext || currentContext.id !== context.id) return;
        renderContext(context, result[0], result[1]);
    }

    function domResources() {
        const seen = new Set();
        const resources = [];
        document.querySelectorAll('[data-dmd-context], [data-dmd-context-type][data-dmd-context-id], [data-dmd-action-hub="1"]').forEach(host => {
            const ctx = contextFromElement(host);
            if (!ctx) return;
            const key = [ctx.type, ctx.source, ctx.id].join('|').toLowerCase();
            if (seen.has(key)) return;
            seen.add(key);
            resources.push({ resource: ctx, last_seen: 0, location: 'dashboard' });
        });
        return { seen, resources };
    }

    async function providerResources(seen, resources) {
        for (const provider of providers) {
            try {
                const fn = typeof provider.getResources === 'function' ? provider.getResources : (typeof provider.listResources === 'function' ? provider.listResources : null);
                if (!fn) continue;
                const list = await fn.call(provider);
                if (!Array.isArray(list)) continue;
                list.forEach(raw => {
                    const ctx = normalizeContext(raw.resource || raw);
                    if (!ctx) return;
                    const key = [ctx.type, ctx.source, ctx.id].join('|').toLowerCase();
                    if (seen.has(key)) return;
                    seen.add(key);
                    resources.push({ resource: ctx, last_seen: Number(raw.last_seen) || 0, location: 'provider' });
                });
            } catch (error) {
                console.error('[ActionHub resources provider]', error);
            }
        }
    }

    async function serverResources(seen, resources) {
        try {
            const response = await fetch(config.endpoint + '?action=resources&limit=100&_=' + Date.now(), { credentials: 'same-origin', cache: 'no-store' });
            const data = await response.json();
            if (!response.ok || !data.ok || !Array.isArray(data.resources)) return;
            data.resources.forEach(raw => {
                const ctx = normalizeContext(raw.resource || raw);
                if (!ctx) return;
                const key = [ctx.type, ctx.source, ctx.id].join('|').toLowerCase();
                if (seen.has(key)) return;
                seen.add(key);
                resources.push({ resource: ctx, last_seen: Number(raw.last_seen) || 0, location: 'activity' });
            });
        } catch (error) {}
    }

    async function forgetGlobalResource(index) {
        if (!Array.isArray(globalResources) || !Number.isInteger(index) || index < 0 || index >= globalResources.length) return;
        const entry = globalResources[index];
        const resource = normalizeContext(entry && (entry.resource || entry));
        if (!resource) return;

        const label = safeText(resource.label || resource.name, resource.id || 'cette ressource');
        const ok = window.confirm(
            'Retirer « ' + label + ' » de tes ressources récentes ?\n\n' +
            'Elle disparaîtra de ta vue mais son historique restera dans ta corbeille ActionHub jusqu’à ce qu’un Superadmin la vide.\n' +
            'L’objet réel dans son module ne sera pas supprimé.'
        );
        if (!ok) return;

        try {
            const result = await post('resource_forget', { resource: resource });
            if (!result || !result.ok) throw new Error('resource_forget_failed');
            globalResources.splice(index, 1);
            renderGlobal(globalResources, scenarioList);
            toast('Ressource retirée de ta vue ActionHub et placée dans ta corbeille.');
        } catch (error) {
            console.error('[ActionHub resource forget]', error);
            toast(error && error.message ? error.message : 'Impossible de retirer cette ressource.');
        }
    }


    function selectedGlobalResourceIndexes() {
        if (!overlay) return [];
        return Array.from(overlay.querySelectorAll('[data-dmd-ah-resource-select]:checked'))
            .filter(box => !box.closest('.dmd-action-hub-resource-row').hidden)
            .map(box => Number(box.dataset.dmdAhResourceSelect))
            .filter(Number.isInteger);
    }

    function updateBulkResourceButton() {
        if (!overlay) return;
        const selected = selectedGlobalResourceIndexes();
        const button = overlay.querySelector('[data-dmd-ah-resource-forget-selected]');
        if (button) { button.disabled = !selected.length; button.textContent = selected.length ? '🗑 Retirer (' + selected.length + ')' : '🗑 Retirer la sélection'; }
        const visible = Array.from(overlay.querySelectorAll('[data-dmd-ah-resource-select]')).filter(box => !box.closest('.dmd-action-hub-resource-row').hidden);
        const all = overlay.querySelector('[data-dmd-ah-resource-select-all]');
        if (all) { all.checked = visible.length > 0 && visible.every(box => box.checked); all.indeterminate = visible.some(box => box.checked) && !all.checked; }
    }

    async function forgetSelectedGlobalResources() {
        const indexes = selectedGlobalResourceIndexes();
        if (!indexes.length) return;
        const resources = indexes.map(i => normalizeContext(globalResources[i] && (globalResources[i].resource || globalResources[i]))).filter(Boolean);
        if (!resources.length) return;
        if (!window.confirm('Retirer les ' + resources.length + ' ressource(s) sélectionnée(s) de ta vue ActionHub ?\n\nElles resteront dans ta corbeille jusqu’à sa purge par un Superadmin.')) return;
        try {
            const result = await post('resources_forget', { resources });
            if (!result || !result.ok) throw new Error('resources_forget_failed');
            const remove = new Set(indexes);
            globalResources = globalResources.filter((_, i) => !remove.has(i));
            renderGlobal(globalResources, scenarioList);
            toast(resources.length + ' ressource(s) retirée(s) vers ta corbeille.');
        } catch (error) {
            console.error('[ActionHub resources forget]', error);
            toast('Impossible de retirer toute la sélection.');
        }
    }

    function catalogActions() {
        const out = [];
        (Array.isArray(scenarioCatalog) ? scenarioCatalog : []).forEach(module => {
            (Array.isArray(module.actions) ? module.actions : []).forEach(action => {
                out.push({
                    module: safeText(module.module, ''),
                    moduleName: safeText(module.name, module.module || ''),
                    id: safeText(action.id, ''),
                    label: safeText(action.label, action.id || ''),
                    group: safeText(action.group, 'Général'),
                    description: safeText(action.description, ''),
                    icon: safeText(action.icon, '⚡'),
                    inputs: Array.isArray(action.inputs) ? action.inputs : [],
                    dangerous: !!action.dangerous,
                    confirm: safeText(action.confirm, '')
                });
            });
        });
        return out.filter(item => item.module && item.id);
    }

    function findCatalogAction(moduleId, actionId) {
        return catalogActions().find(item => item.module === moduleId && item.id === actionId) || null;
    }

    function scenarioModules() {
        const seen = new Map();
        catalogActions().forEach(action => {
            if (!seen.has(action.module)) seen.set(action.module, action.moduleName);
        });
        return Array.from(seen.entries()).map(entry => ({ id: entry[0], name: entry[1] }));
    }

    function scenarioActionsForModule(moduleId) {
        return catalogActions().filter(action => action.module === moduleId);
    }

    function scenarioGroupsForModule(moduleId) {
        return Array.from(new Set(scenarioActionsForModule(moduleId).map(action => safeText(action.group, 'Général'))));
    }

    function scenarioActionsForGroup(moduleId, group) {
        return scenarioActionsForModule(moduleId).filter(action => safeText(action.group, 'Général') === group);
    }

    function resetScenarioStep(step, action) {
        if (!step || !action) return;
        step.module = action.module;
        step.action_id = action.id;
        step.payload = {};
        action.inputs.forEach(input => {
            step.payload[input.id] = defaultValueForInput(input);
        });
    }

    async function ensureScenarioCatalog() {
        if (scenarioCatalog.length) return scenarioCatalog;
        const data = await get('scenario_catalog');
        scenarioCatalog = Array.isArray(data.catalog) ? data.catalog : [];
        scenarioUsers = Array.isArray(data.users) ? data.users : [];
        return scenarioCatalog;
    }

    async function loadScenarios(query) {
        const data = await get('scenarios', { q: safeText(query, '') });
        scenarioList = Array.isArray(data.scenarios) ? data.scenarios : [];
        return scenarioList;
    }

    function scenarioKeywordsText(scenario) {
        return Array.isArray(scenario && scenario.keywords) ? scenario.keywords.join(', ') : safeText(scenario && scenario.keywords, '');
    }

    function renderScenarioCards(scenarios) {
        const items = Array.isArray(scenarios) ? scenarios : [];
        if (!items.length) {
            return '<p class="dmd-action-hub-empty">Aucun scénario. Crée ton premier scénario avec le bouton « + Scénario ».</p>';
        }

        return '<div class="dmd-action-hub-scenario-list">' + items.map(scenario => {
            const steps = Number(scenario.step_count || (Array.isArray(scenario.steps) ? scenario.steps.length : 0)) || 0;
            const keywords = scenarioKeywordsText(scenario);
            return `<article class="dmd-action-hub-scenario-card">
                <div class="dmd-action-hub-scenario-info">
                    <strong>▶ ${esc(scenario.name || 'Scénario')}</strong>
                    <small>${steps} étape${steps > 1 ? 's' : ''}${keywords ? ' · ' + esc(keywords) : ''}${scenario.workspace && scenario.workspace.create_dashboard ? ' · 🖥 Dashboard' : ''}</small>
                </div>
                <div class="dmd-action-hub-scenario-actions">
                    <button type="button" data-dmd-ah-scenario-run="${esc(scenario.id)}" title="Exécuter" aria-label="Exécuter">▶</button>
                    <button type="button" data-dmd-ah-scenario-edit="${esc(scenario.id)}" title="Modifier" aria-label="Modifier">✎</button>
                    <button type="button" data-dmd-ah-scenario-delete="${esc(scenario.id)}" title="Supprimer" aria-label="Supprimer">×</button>
                </div>
                ${scenario.description ? `
                    <span class="dmd-action-hub-scenario-infos" tabindex="0" aria-label="Informations sur le scénario">
                        ⓘ Infos
                        <span class="dmd-action-hub-scenario-tooltip" role="tooltip">
                            <strong>Description du scénario</strong>
                            <span>${esc(scenario.description)}</span>
                        </span>
                    </span>
                ` : ''}
            </article>`;
        }).join('') + '</div>';
    }

    function bindGlobalScenarioSearch() {
        const el = ensureOverlay();
        const input = el.querySelector('#dmdAhScenarioSearch');
        if (!input) return;

        input.addEventListener('input', function () {
            window.clearTimeout(scenarioSearchTimer);
            scenarioSearchTimer = window.setTimeout(async function () {
                try {
                    const list = await loadScenarios(input.value);
                    if (currentMode !== 'global') return;
                    const host = el.querySelector('#dmdAhScenarioResults');
                    if (host) host.innerHTML = renderScenarioCards(list);
                } catch (error) {
                    console.error('[ActionHub scenarios search]', error);
                }
            }, 180);
        });
    }

    function defaultValueForInput(input) {
        if (!input || typeof input !== 'object') return '';
        if (input.type === 'boolean') return !!input.default;
        if (input.type === 'users') return Array.isArray(input.default) ? input.default.slice() : [];
        if (input.type === 'list') {
            return Array.isArray(input.default) ? input.default.join('\n') : safeText(input.default, '');
        }
        if (input.type === 'select') {
            if (input.default != null && String(input.default) !== '') return String(input.default);
            const options = Array.isArray(input.options) ? input.options : [];
            for (const option of options) {
                const value = safeText(option && option.value, '');
                if (value !== '') return value;
            }
            return '';
        }
        return input.default == null ? '' : input.default;
    }

    function createEmptyScenarioStep() {
        const action = catalogActions()[0] || null;
        const payload = {};
        if (action) {
            action.inputs.forEach(input => {
                payload[input.id] = defaultValueForInput(input);
            });
        }
        return {
            id: 'step_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            module: action ? action.module : '',
            action_id: action ? action.id : '',
            payload
        };
    }

    function normalizeDraftScenario(scenario) {
        const source = scenario && typeof scenario === 'object' ? scenario : {};
        return {
            id: safeText(source.id, ''),
            name: safeText(source.name, ''),
            description: safeText(source.description, ''),
            keywords: scenarioKeywordsText(source),
            workspace: {
                create_dashboard: !!(source.workspace && source.workspace.create_dashboard),
                dashboard_name: safeText(source.workspace && source.workspace.dashboard_name, '')
            },
            steps: Array.isArray(source.steps) ? source.steps.map((step, index) => ({
                id: safeText(step.id, 'step_' + (index + 1)),
                module: safeText(step.module, ''),
                action_id: safeText(step.action_id, ''),
                payload: Object.assign({}, step.payload || {})
            })) : []
        };
    }

    function inputHtml(input, value, stepIndex) {
        const id = safeText(input.id, '');
        const label = safeText(input.label, id);
        const required = input.required ? ' <span aria-hidden="true">*</span>' : '';
        const attr = `data-dmd-ah-step-input="${stepIndex}" data-dmd-ah-input-id="${esc(id)}"`;
        const placeholder = input.placeholder ? ` placeholder="${esc(input.placeholder)}"` : '';
        let control = '';

        if (input.type === 'textarea' || input.type === 'list') {
            const textValue = Array.isArray(value) ? value.join('\n') : String(value == null ? '' : value);
            control = `<textarea ${attr}${placeholder} rows="${input.type === 'list' ? 6 : 4}">${esc(textValue)}</textarea>`;
        } else if (input.type === 'users') {
            const selectedUsers = Array.isArray(value) ? value.map(String) : [];
            const usersHtml = (Array.isArray(scenarioUsers) ? scenarioUsers : []).map(user => {
                const email = safeText(user && user.email, '');
                const name = safeText(user && user.name, email);
                if (!email) return '';
                return `<label class="dmd-action-hub-user-option">
                    <input type="checkbox" data-dmd-ah-users-step="${stepIndex}" data-dmd-ah-users-input="${esc(id)}" value="${esc(email)}"${selectedUsers.includes(email) ? ' checked' : ''}>
                    <span><strong>${esc(name)}</strong><small>${esc(email)}</small></span>
                </label>`;
            }).join('');
            control = `<div class="dmd-action-hub-user-options">${usersHtml || '<small>Aucun autre utilisateur disponible.</small>'}</div>`;
        } else if (input.type === 'select') {
            const options = (Array.isArray(input.options) ? input.options : []).map(option => {
                const optionValue = safeText(option.value, '');
                return `<option value="${esc(optionValue)}"${String(value == null ? '' : value) === optionValue ? ' selected' : ''}>${esc(option.label || optionValue)}</option>`;
            }).join('');
            control = `<select ${attr}>${options}</select>`;
        } else if (input.type === 'boolean') {
            return `<label class="dmd-action-hub-field dmd-action-hub-field--boolean">
                <span class="dmd-action-hub-boolean-line">
                    <input ${attr} type="checkbox"${value ? ' checked' : ''}>
                    <strong>${esc(label)}${required}</strong>
                </span>
                ${input.help ? `<small>${esc(input.help)}</small>` : ''}
            </label>`;
        } else {
            const type = input.type === 'date' || input.type === 'number' ? input.type : 'text';
            control = `<input ${attr} type="${type}" value="${esc(value == null ? '' : value)}"${placeholder}>`;
        }

        return `<label class="dmd-action-hub-field">
            <span>${esc(label)}${required}</span>
            ${control}
            ${input.help ? `<small>${esc(input.help)}</small>` : ''}
        </label>`;
    }

    function renderScenarioEditor() {
        const el = ensureOverlay();
        currentMode = 'scenario-editor';
        currentContext = null;
        el.dataset.dmdAhMode = 'scenario-editor';
        overlay._actions = [];
        overlay._resources = [];

        const actions = catalogActions();
        el.querySelector('.dmd-action-hub-head strong').textContent = scenarioDraft && scenarioDraft.id ? '⚡ Modifier le scénario' : '⚡ Nouveau scénario';
        el.querySelector('.dmd-action-hub-meta').textContent = 'Le scénario est créé par toi. ActionHub ne contient aucun scénario prédéfini.';

        if (!actions.length) {
            el.querySelector('.dmd-action-hub-content').innerHTML = `
                <p class="dmd-action-hub-empty">Aucune action compatible avec les scénarios n’est déclarée par les modules installés.</p>
                <button type="button" class="dmd-action-hub-secondary" data-dmd-ah-scenario-back>Retour</button>`;
            return;
        }

        let stepsHtml = '';
        (scenarioDraft.steps || []).forEach((step, index) => {
            let selected = findCatalogAction(step.module, step.action_id);
            if (!selected) selected = actions[0];

            if (step.module !== selected.module || step.action_id !== selected.id) {
                step.module = selected.module;
                step.action_id = selected.id;
                step.payload = {};
                selected.inputs.forEach(input => {
                    step.payload[input.id] = defaultValueForInput(input);
                });
            }

            const moduleOptions = scenarioModules().map(module =>
                `<option value="${esc(module.id)}"${module.id === step.module ? ' selected' : ''}>${esc(module.name)}</option>`
            ).join('');
            const currentGroup = safeText(selected.group, 'Général');
            const groupOptions = scenarioGroupsForModule(step.module).map(group =>
                `<option value="${esc(group)}"${group === currentGroup ? ' selected' : ''}>${esc(group)}</option>`
            ).join('');
            const actionOptions = scenarioActionsForGroup(step.module, currentGroup).map(action =>
                `<option value="${esc(action.id)}"${action.id === step.action_id ? ' selected' : ''}>${esc(action.label)}</option>`
            ).join('');

            const fields = selected.inputs.map(input => inputHtml(input, step.payload ? step.payload[input.id] : '', index)).join('');

            stepsHtml += `<section class="dmd-action-hub-step">
                <div class="dmd-action-hub-step-head">
                    <strong>Étape ${index + 1}</strong>
                    <button type="button" data-dmd-ah-step-remove="${index}" aria-label="Supprimer l’étape">×</button>
                </div>
                <div class="dmd-action-hub-step-selector">
                    <label class="dmd-action-hub-field">
                        <span>Module</span>
                        <select data-dmd-ah-step-module="${index}">${moduleOptions}</select>
                    </label>
                    <label class="dmd-action-hub-field">
                        <span>Catégorie</span>
                        <select data-dmd-ah-step-group="${index}">${groupOptions}</select>
                    </label>
                    <label class="dmd-action-hub-field">
                        <span>Action</span>
                        <select data-dmd-ah-step-action="${index}">${actionOptions}</select>
                    </label>
                </div>
                ${selected.description ? `<p class="dmd-action-hub-step-description">${esc(selected.description)}</p>` : ''}
                <div class="dmd-action-hub-step-fields">${fields}</div>
            </section>`;
        });

        el.querySelector('.dmd-action-hub-content').innerHTML = `
            <form class="dmd-action-hub-scenario-form" onsubmit="return false;">
                <label class="dmd-action-hub-field">
                    <span>Nom du scénario *</span>
                    <input type="text" data-dmd-ah-scenario-field="name" maxlength="160" value="${esc(scenarioDraft.name || '')}" placeholder="Ex. Liste de courses">
                </label>
                <label class="dmd-action-hub-field">
                    <span>Mots-clés</span>
                    <input type="text" data-dmd-ah-scenario-field="keywords" value="${esc(scenarioDraft.keywords || '')}" placeholder="courses, week-end">
                </label>
                <label class="dmd-action-hub-field">
                    <span>Description du scénario</span>
                    <textarea data-dmd-ah-scenario-field="description" rows="3" placeholder="Ce que fait ce scénario">${esc(scenarioDraft.description || '')}</textarea>
                </label>

                <div class="dmd-action-hub-section-title">Après exécution</div>
                <label class="dmd-action-hub-workspace-toggle">
                    <input type="checkbox" data-dmd-ah-workspace-toggle${scenarioDraft.workspace && scenarioDraft.workspace.create_dashboard ? ' checked' : ''}>
                    <span>
                        <strong>Créer / ouvrir un dashboard dédié</strong>
                        <small>Décoche cette option pour exécuter le scénario sans créer ni changer de dashboard.</small>
                    </span>
                </label>
                <label class="dmd-action-hub-field" data-dmd-ah-workspace-name-wrap${scenarioDraft.workspace && scenarioDraft.workspace.create_dashboard ? '' : ' hidden'}>
                    <span>Nom du dashboard</span>
                    <input type="text" data-dmd-ah-workspace-name maxlength="64" value="${esc((scenarioDraft.workspace && scenarioDraft.workspace.dashboard_name) || '')}" placeholder="Vide = nom du scénario">
                    <small>Le dashboard recevra automatiquement les modules utilisés par le scénario.</small>
                </label>

                <div class="dmd-action-hub-section-title">Étapes</div>
                <div class="dmd-action-hub-steps">${stepsHtml || '<p class="dmd-action-hub-empty">Aucune étape.</p>'}</div>

                <div class="dmd-action-hub-editor-actions">
                    <button type="button" data-dmd-ah-step-add>＋ Ajouter une étape</button>
                    <span></span>
                    <button type="button" class="dmd-action-hub-secondary" data-dmd-ah-scenario-back>Annuler</button>
                    <button type="button" data-dmd-ah-scenario-save>Enregistrer</button>
                </div>
            </form>`;

        el.querySelectorAll('[data-dmd-ah-scenario-field]').forEach(field => {
            field.addEventListener('input', function () {
                const name = String(field.dataset.dmdAhScenarioField || '');
                scenarioDraft[name] = field.value;
            });
        });

        const workspaceToggle = el.querySelector('[data-dmd-ah-workspace-toggle]');
        const workspaceName = el.querySelector('[data-dmd-ah-workspace-name]');
        const workspaceWrap = el.querySelector('[data-dmd-ah-workspace-name-wrap]');

        if (workspaceToggle) {
            workspaceToggle.addEventListener('change', function () {
                scenarioDraft.workspace = scenarioDraft.workspace || { create_dashboard: false, dashboard_name: '' };
                scenarioDraft.workspace.create_dashboard = !!workspaceToggle.checked;
                if (workspaceWrap) workspaceWrap.hidden = !workspaceToggle.checked;
            });
        }

        if (workspaceName) {
            workspaceName.addEventListener('input', function () {
                scenarioDraft.workspace = scenarioDraft.workspace || { create_dashboard: false, dashboard_name: '' };
                scenarioDraft.workspace.dashboard_name = workspaceName.value;
            });
        }

        el.querySelectorAll('[data-dmd-ah-users-step]').forEach(field => {
            field.addEventListener('change', function () {
                const index = Number(field.dataset.dmdAhUsersStep);
                const inputId = String(field.dataset.dmdAhUsersInput || '');
                if (!scenarioDraft.steps[index] || !inputId) return;
                const selector = `[data-dmd-ah-users-step="${index}"][data-dmd-ah-users-input="${CSS.escape(inputId)}"]:checked`;
                scenarioDraft.steps[index].payload[inputId] = Array.from(el.querySelectorAll(selector)).map(item => item.value);
            });
        });

        el.querySelectorAll('[data-dmd-ah-step-module],[data-dmd-ah-step-group],[data-dmd-ah-step-action]').forEach(select => {
            select.addEventListener('change', function () {
                const isModule = select.hasAttribute('data-dmd-ah-step-module');
                const isGroup = select.hasAttribute('data-dmd-ah-step-group');
                const index = Number(
                    isModule ? select.dataset.dmdAhStepModule :
                    isGroup ? select.dataset.dmdAhStepGroup :
                    select.dataset.dmdAhStepAction
                );
                const step = scenarioDraft.steps[index];
                if (!step) return;

                let action = null;
                if (isModule) action = scenarioActionsForModule(String(select.value || ''))[0] || null;
                else if (isGroup) action = scenarioActionsForGroup(step.module, String(select.value || ''))[0] || null;
                else action = findCatalogAction(step.module, String(select.value || ''));

                if (!action) return;
                resetScenarioStep(step, action);
                renderScenarioEditor();
            });
        });

        el.querySelectorAll('[data-dmd-ah-step-input]').forEach(field => {
            const update = function () {
                const index = Number(field.dataset.dmdAhStepInput);
                const inputId = String(field.dataset.dmdAhInputId || '');
                if (!scenarioDraft.steps[index] || !inputId) return;
                scenarioDraft.steps[index].payload[inputId] = field.type === 'checkbox' ? !!field.checked : field.value;
            };
            field.addEventListener('input', update);
            field.addEventListener('change', update);
        });
    }

    async function openScenarioEditor(scenario) {
        try {
            await ensureScenarioCatalog();
            scenarioDraft = normalizeDraftScenario(scenario);
            if (!scenarioDraft.steps.length) scenarioDraft.steps.push(createEmptyScenarioStep());
            renderScenarioEditor();
            show();
        } catch (error) {
            console.error('[ActionHub scenario catalog]', error);
            toast('Impossible de charger les actions disponibles pour les scénarios.');
        }
    }

    function addScenarioStep() {
        if (!scenarioDraft) return;
        scenarioDraft.steps.push(createEmptyScenarioStep());
        renderScenarioEditor();
    }

    function removeScenarioStep(index) {
        if (!scenarioDraft || !Array.isArray(scenarioDraft.steps)) return;
        scenarioDraft.steps.splice(index, 1);
        renderScenarioEditor();
    }

    function syncScenarioDraftFromEditor() {
        if (!scenarioDraft) return;
        const el = ensureOverlay();

        el.querySelectorAll('[data-dmd-ah-scenario-field]').forEach(field => {
            const name = String(field.dataset.dmdAhScenarioField || '');
            if (name) scenarioDraft[name] = field.value;
        });

        const workspaceToggle = el.querySelector('[data-dmd-ah-workspace-toggle]');
        const workspaceName = el.querySelector('[data-dmd-ah-workspace-name]');
        scenarioDraft.workspace = scenarioDraft.workspace || { create_dashboard: false, dashboard_name: '' };
        if (workspaceToggle) scenarioDraft.workspace.create_dashboard = !!workspaceToggle.checked;
        if (workspaceName) scenarioDraft.workspace.dashboard_name = workspaceName.value;

        el.querySelectorAll('[data-dmd-ah-step-input]').forEach(field => {
            const index = Number(field.dataset.dmdAhStepInput);
            const inputId = String(field.dataset.dmdAhInputId || '');
            if (!scenarioDraft.steps[index] || !inputId) return;
            scenarioDraft.steps[index].payload[inputId] = field.type === 'checkbox' ? !!field.checked : field.value;
        });
    }

    async function saveScenarioDraft() {
        if (!scenarioDraft || scenarioBusy) return;
        syncScenarioDraftFromEditor();
        scenarioBusy = true;
        try {
            const result = await post('scenario_save', { scenario: scenarioDraft });
            toast('Scénario enregistré.');
            scenarioDraft = null;
            await loadScenarios('');
            renderGlobal(globalResources, scenarioList);
        } catch (error) {
            console.error('[ActionHub scenario save]', error);
            toast(error && error.message ? error.message : 'Impossible d’enregistrer le scénario.');
        } finally {
            scenarioBusy = false;
        }
    }

    async function deleteScenario(id) {
        if (!id || scenarioBusy) return;
        const scenario = scenarioList.find(item => String(item.id || '') === id);
        if (!window.confirm('Supprimer le scénario « ' + safeText(scenario && scenario.name, id) + ' » ?')) return;

        scenarioBusy = true;
        try {
            await post('scenario_delete', { id });
            await loadScenarios('');
            renderGlobal(globalResources, scenarioList);
            toast('Scénario supprimé.');
        } catch (error) {
            console.error('[ActionHub scenario delete]', error);
            toast('Impossible de supprimer le scénario.');
        } finally {
            scenarioBusy = false;
        }
    }

    async function openScenarioDashboard(result, scenario) {
        const workspace = result && result.workspace && typeof result.workspace === 'object'
            ? result.workspace
            : (scenario && scenario.workspace ? scenario.workspace : null);

        if (!workspace || !workspace.create_dashboard) return false;

        const modules = [];
        (Array.isArray(result.results) ? result.results : []).forEach(step => {
            if (!step || !step.ok) return;
            const moduleId = safeText(step.module, '');
            if (moduleId && !modules.includes(moduleId)) modules.push(moduleId);
        });

        const dashboardName = safeText(workspace.dashboard_name, safeText(scenario && scenario.name, 'scenario'));
        const response = await fetch('users/create_dashboard.php', {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: dashboardName, modules: modules })
        });

        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.ok) {
            const message = data.error === 'dashboard_limit'
                ? 'Le scénario a été exécuté, mais la limite de dashboards est atteinte.'
                : 'Le scénario a été exécuté, mais le dashboard n’a pas pu être préparé.';
            toast(message);
            return false;
        }

        const finalName = safeText(data.name, dashboardName);
        location.href = 'dashboard.php?dashboard=' + encodeURIComponent(finalName);
        return true;
    }

    function renderScenarioExecution(result) {
        const el = ensureOverlay();
        currentMode = 'scenario-result';
        el.dataset.dmdAhMode = 'scenario-result';
        const rows = Array.isArray(result.results) ? result.results : [];
        const title = result.scenario && result.scenario.name ? result.scenario.name : 'Scénario';
        el.querySelector('.dmd-action-hub-head strong').textContent = '⚡ ' + title;
        el.querySelector('.dmd-action-hub-meta').textContent = result.message || '';

        const html = rows.map((row, index) => `
            <div class="dmd-action-hub-run-step ${row.ok ? 'is-ok' : 'is-error'}">
                <span>${row.ok ? '✅' : '❌'}</span>
                <div><strong>Étape ${index + 1} · ${esc(row.label || row.action_id || '')}</strong><small>${esc(row.message || '')}</small></div>
            </div>`).join('');

        el.querySelector('.dmd-action-hub-content').innerHTML = `
            <div class="dmd-action-hub-run-results">${html || '<p class="dmd-action-hub-empty">Aucune étape exécutée.</p>'}</div>
            <div class="dmd-action-hub-editor-actions">
                <span></span><span></span>
                <button type="button" data-dmd-ah-scenario-back>Retour aux scénarios</button>
            </div>`;
    }

    function requestScenarioInteraction(interaction, scenarioTitle) {
        return new Promise((resolve) => {
            const el = ensureOverlay();
            const spec = interaction && typeof interaction === 'object' ? interaction : {};
            const fields = Array.isArray(spec.fields) ? spec.fields : [];
            currentMode = 'scenario-interaction';
            el.dataset.dmdAhMode = 'scenario-interaction';
            el.querySelector('.dmd-action-hub-head strong').textContent = safeText(spec.title, '🔐 Validation requise');
            el.querySelector('.dmd-action-hub-meta').textContent = safeText(spec.status, 'Le scénario est en attente. Aucune étape n’a encore été exécutée.');

            const fieldsHtml = fields.map(field => {
                const id = safeText(field.id, '');
                if (!id) return '';
                const label = safeText(field.label, id);
                const type = ['password','text','number'].includes(String(field.type || '')) ? String(field.type) : 'text';
                const autocomplete = safeText(field.autocomplete, type === 'password' ? 'current-password' : 'off');
                const inputmode = safeText(field.inputmode, '');
                const maxlength = Number(field.maxlength || 0);
                return `<label>${esc(label)}<input type="${esc(type)}" data-dmd-ah-interaction-field="${esc(id)}" autocomplete="${esc(autocomplete)}"${inputmode ? ` inputmode="${esc(inputmode)}"` : ''}${maxlength > 0 ? ` maxlength="${maxlength}"` : ''}${field.required ? ' required' : ''}></label>`;
            }).join('');

            el.querySelector('.dmd-action-hub-content').innerHTML = `
                <div class="dmd-action-hub-mfa-box">
                    <strong>${esc(safeText(spec.heading, scenarioTitle || 'Validation requise'))}</strong>
                    ${spec.message ? `<p>${esc(spec.message)}</p>` : ''}
                    ${fieldsHtml}
                    <div class="dmd-action-hub-mfa-message" data-dmd-ah-interaction-message></div>
                    <div class="dmd-action-hub-editor-actions"><span></span><button type="button" data-dmd-ah-interaction-cancel>Annuler</button><button type="button" data-dmd-ah-interaction-submit>${esc(safeText(spec.submit_label, 'Valider et continuer'))}</button></div>
                </div>`;

            const content = el.querySelector('.dmd-action-hub-content');
            const message = content.querySelector('[data-dmd-ah-interaction-message]');
            const submit = content.querySelector('[data-dmd-ah-interaction-submit]');
            const cancel = content.querySelector('[data-dmd-ah-interaction-cancel]');
            let done = false;
            const finish = value => { if (done) return; done = true; resolve(value); };

            cancel.addEventListener('click', () => finish(false));
            submit.addEventListener('click', async () => {
                const values = {};
                let missing = '';
                content.querySelectorAll('[data-dmd-ah-interaction-field]').forEach(input => {
                    const id = String(input.dataset.dmdAhInteractionField || '');
                    values[id] = input.value;
                    if (!missing && input.required && !String(input.value || '').trim()) missing = id;
                });
                if (missing) { message.textContent = 'Tous les champs obligatoires doivent être remplis.'; return; }

                submit.disabled = true;
                message.textContent = 'Validation…';
                try {
                    await post('scenario_interaction', {
                        id: String(spec.scenario_id || ''),
                        module: String(spec.module || ''),
                        action_id: String(spec.action_id || ''),
                        values
                    });
                    message.textContent = safeText(spec.success_message, 'Validation réussie — reprise du scénario…');
                    finish(true);
                } catch (e) {
                    message.textContent = e && e.message ? e.message : 'Validation refusée.';
                    submit.disabled = false;
                    const focus = content.querySelector('[data-dmd-ah-interaction-field]');
                    if (focus) focus.focus();
                }
            });

            content.querySelectorAll('[data-dmd-ah-interaction-field]').forEach(input => {
                input.addEventListener('keydown', e => { if (e.key === 'Enter') submit.click(); });
            });
            const first = content.querySelector('[data-dmd-ah-interaction-field]');
            if (first) first.focus();
        });
    }

    async function ensureUiModuleOpen(item) {
        const ui = item && item.ui && typeof item.ui === 'object' ? item.ui : {};
        if (!ui.open_module) return true;

        const moduleId = String(item.module || '');
        if (!moduleId) return false;

        const findOpen = () => Array.from(document.querySelectorAll('.module')).find(node => String(node.dataset.id || '') === moduleId) || null;
        if (findOpen()) return true;

        const select = document.getElementById('addModuleSelect');
        if (!select) return false;
        const option = Array.from(select.options || []).find(opt => String(opt.value || '') === moduleId);
        if (!option) return false;

        select.value = moduleId;
        select.dispatchEvent(new Event('change', { bubbles: true }));

        for (let i = 0; i < 30; i++) {
            if (findOpen()) {
                await new Promise(resolve => window.setTimeout(resolve, 180));
                return true;
            }
            await new Promise(resolve => window.setTimeout(resolve, 100));
        }
        return false;
    }

    async function executeScenario(id) {
        if (!id || scenarioBusy) return;
        const scenario = scenarioList.find(item => String(item.id || '') === id);
        if (!scenario) return;

        scenarioBusy = true;
        const el = ensureOverlay();
        el.querySelector('.dmd-action-hub-meta').textContent = 'Exécution du scénario « ' + safeText(scenario.name, id) + ' »…';

        try {
            let result = await executeScenarioRequest(id);
            if (result && result.error === 'interaction_required' && result.interaction) {
                const interaction = Object.assign({}, result.interaction, { scenario_id: id });
                const accepted = await requestScenarioInteraction(interaction, scenario.name);
                if (!accepted) {
                    toast('Scénario annulé : validation non effectuée.');
                    await loadScenarios('');
                    renderGlobal(globalResources, scenarioList);
                    return;
                }
                result = await executeScenarioRequest(id);
            }
            renderScenarioExecution(result);
            const pendingUiActions = [];
            (Array.isArray(result.results) ? result.results : []).forEach(step => {
                const stepData = Object.assign({}, step.data || {});
                if (stepData.ui) {
                    pendingUiActions.push({
                        module: String(step.module || ''),
                        ui: stepData.ui,
                        action: String(step.action_id || '')
                    });
                }
                if (stepData.reload) {
                    const moduleId = String(step.module || '');
                    const moduleEl = Array.from(document.querySelectorAll('.module')).find(el => String(el.dataset.id || '') === moduleId) || null;
                    if (moduleEl && typeof window.loadModuleContent === 'function') {
                        window.setTimeout(() => window.loadModuleContent(moduleEl, moduleId), 120);
                    }
                    delete stepData.reload;
                }

                document.dispatchEvent(new CustomEvent('dmd:actionhub-action-complete', {
                    detail: {
                        action: { id: step.action_id, module: step.module, label: step.label },
                        result: { ok: step.ok, message: step.message, data: stepData },
                        context: { source: step.module, module: step.module, type: 'scenario', id: id, label: scenario.name }
                    }
                }));
            });
            document.dispatchEvent(new CustomEvent('dmd:actionhub-scenario-complete', {
                detail: { scenario, result }
            }));

            if (result.ok && result.workspace && result.workspace.create_dashboard) {
                if (pendingUiActions.length) {
                    try {
                        sessionStorage.setItem('dmd-actionhub-pending-ui', JSON.stringify(pendingUiActions));
                    } catch (e) {}
                }
                const redirected = await openScenarioDashboard(result, scenario);
                if (redirected) return;
            }

            for (const item of pendingUiActions) {
                await ensureUiModuleOpen(item);
                document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action', { detail: item }));
            }

            if (!result.ok) {
                const failedStep = (Array.isArray(result.results) ? result.results : []).find(step => step && !step.ok);
                toast((failedStep && failedStep.message) || result.message || 'Le scénario s’est arrêté sur une étape en erreur.');
            } else {
                toast(result.message || 'Scénario exécuté.');
            }
        } catch (error) {
            console.error('[ActionHub scenario execute]', error);
            toast(error && error.message ? error.message : 'Le scénario n’a pas pu être exécuté.');
            try {
                await loadScenarios('');
                renderGlobal(globalResources, scenarioList);
            } catch (ignored) {}
        } finally {
            scenarioBusy = false;
        }
    }

    function renderGlobal(resources, scenarios) {
        const el = ensureOverlay();
        currentMode = 'global';
        currentContext = null;
        el.dataset.dmdAhMode = 'global';
        globalResources = Array.isArray(resources) ? resources : [];
        scenarioList = Array.isArray(scenarios) ? scenarios : scenarioList;
        overlay._actions = [];
        overlay._resources = globalResources;
        overlay._scenarios = scenarioList;

        el.querySelector('.dmd-action-hub-head strong').textContent = '⚡ ActionHub';
        el.querySelector('.dmd-action-hub-meta').textContent = 'Lance un scénario que tu as créé ou ouvre une ressource mémorisée par ActionHub.';

        let html = `
            <div class="dmd-action-hub-scenario-toolbar">
                <input id="dmdAhScenarioSearch" type="search" autocomplete="off" placeholder="Rechercher un scénario…">
                <button type="button" data-dmd-ah-scenario-new>＋ Scénario</button>
            </div>
            <div class="dmd-action-hub-section-title">Scénarios</div>
            <div id="dmdAhScenarioResults">${renderScenarioCards(scenarioList)}</div>
            <div class="dmd-action-hub-section-title dmd-action-hub-resource-title">Ressources récentes</div>
            <div class="dmd-action-hub-resource-bulk">
                <label><input type="checkbox" data-dmd-ah-resource-select-all> Tous</label>
                <button type="button" data-dmd-ah-resource-forget-selected disabled>🗑 Retirer la sélection</button>
            </div>
            <div class="dmd-action-hub-resource-list">`;

        globalResources.forEach((entry, index) => {
            const ctx = entry.resource;
            html += `<div class="dmd-action-hub-resource-row">
                <label class="dmd-action-hub-resource-check" title="Sélectionner"><input type="checkbox" data-dmd-ah-resource-select="${index}" aria-label="Sélectionner ${esc(ctx.label)}"></label>
                <button type="button" class="dmd-action-hub-resource" data-dmd-ah-resource-index="${index}">
                    <span class="dmd-action-hub-resource-icon">⚡</span>
                    <span class="dmd-action-hub-resource-text"><strong>${esc(ctx.label)}</strong><small>${esc(ctx.type)}${ctx.source ? ' · ' + esc(ctx.source) : ''}</small></span>
                </button>
                <button type="button" class="dmd-action-hub-resource-forget" data-dmd-ah-resource-forget="${index}" title="Retirer de mes ressources récentes" aria-label="Retirer ${esc(ctx.label)} de mes ressources récentes">×</button>
            </div>`;
        });

        if (!globalResources.length) {
            html += '<p class="dmd-action-hub-empty">Aucune ressource mémorisée pour le moment.</p>';
        }

        html += '</div>';
        el.querySelector('.dmd-action-hub-content').innerHTML = html;
        bindGlobalScenarioSearch();
    }

    async function openGlobal() {
        /*
         * La vue globale ActionHub ne doit afficher que les ressources
         * réellement mémorisées côté serveur.
         *
         * Important :
         * - ne pas scanner le DOM du dashboard ici ;
         * - ne pas injecter les ressources temporaires des providers ici.
         *
         * Les contextes présents sur les modules restent utilisables via
         * leur bouton ActionHub, mais leur simple présence à l'écran ne les
         * transforme plus en « ressources récentes ».
         */
        const collected = { seen: new Set(), resources: [] };

        show();
        const el = ensureOverlay();
        el.dataset.dmdAhMode = 'global';
        el.querySelector('.dmd-action-hub-head strong').textContent = '⚡ ActionHub';
        el.querySelector('.dmd-action-hub-meta').textContent = 'Chargement des scénarios et ressources mémorisées…';
        el.querySelector('.dmd-action-hub-content').innerHTML = '<p class="dmd-action-hub-empty">Chargement…</p>';

        try {
            await Promise.all([
                serverResources(collected.seen, collected.resources),
                loadScenarios('')
            ]);

            collected.resources.sort((a, b) => (Number(b.last_seen) || 0) - (Number(a.last_seen) || 0));
            globalResources = collected.resources;
            renderGlobal(globalResources, scenarioList);

            document.dispatchEvent(new CustomEvent('dmd:action-hub-global-open', {
                detail: { resources: globalResources, scenarios: scenarioList }
            }));
        } catch (error) {
            console.error('[ActionHub global]', error);
            collected.resources.sort((a, b) => (Number(b.last_seen) || 0) - (Number(a.last_seen) || 0));
            globalResources = collected.resources;
            renderGlobal(globalResources, scenarioList);
        }
    }

    function toggleGlobal() {
        if (overlay && overlay.classList.contains('is-open') && currentMode === 'global') close();
        else openGlobal();
    }

    function decorate(root) {
        const scope = root || document;
        const hosts = [];
        if (scope.matches && scope.matches('[data-dmd-context], [data-dmd-context-type][data-dmd-context-id]')) hosts.push(scope);
        if (scope.querySelectorAll) scope.querySelectorAll('[data-dmd-context], [data-dmd-context-type][data-dmd-context-id]').forEach(el => hosts.push(el));
        hosts.forEach(host => {
            host.classList.add('dmd-context-host');
            if (host.dataset.dmdContextAutoAction === '1' && !host.querySelector('[data-dmd-action-hub-trigger]')) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'dmd-action-hub-trigger dmd-action-hub-auto';
                btn.dataset.dmdActionHubTrigger = '1';
                btn.title = 'Actions DoMyDesk';
                btn.setAttribute('aria-label', 'Actions DoMyDesk');
                btn.textContent = '⚡';
                host.appendChild(btn);
            }
        });
    }

    document.addEventListener('click', event => {
        const trigger = event.target.closest('[data-dmd-action-hub-trigger], .dmd-action-hub-trigger');
        if (!trigger) return;
        const context = contextFromElement(trigger);
        if (!context) return;
        event.preventDefault();
        event.stopPropagation();
        open(context);
    }, true);

    const observer = new MutationObserver(mutations => {
        mutations.forEach(m => m.addedNodes.forEach(node => {
            if (node.nodeType === 1) decorate(node);
        }));
    });

    document.addEventListener('DOMContentLoaded', () => {
        decorate(document);
        if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    });

    window.DMDActionHub = {
        configure(next) { config = Object.assign({}, config, next || {}); },
        registerProvider(provider) {
            if (!provider || typeof provider !== 'object') return false;
            if (providers.includes(provider)) return true;
            providers.push(provider);
            return true;
        },
        decorate,
        open,
        openHub: open,
        openGlobal,
        toggleGlobal,
        close,
        contextFromElement,
        normalizeContext
    };

    function restorePendingUiActions() {
        let items = [];
        try { items = JSON.parse(sessionStorage.getItem('dmd-actionhub-pending-ui') || '[]'); }
        catch (e) { items = []; }
        if (!Array.isArray(items) || !items.length) return;

        let pending = items.slice();
        let attempts = 0;
        let timer = null;

        const save = () => {
            try {
                if (pending.length) sessionStorage.setItem('dmd-actionhub-pending-ui', JSON.stringify(pending));
                else sessionStorage.removeItem('dmd-actionhub-pending-ui');
            } catch (e) {}
        };

        const handled = event => {
            const detail = event && event.detail && typeof event.detail === 'object' ? event.detail : {};
            pending = pending.filter(item => {
                const ui = item && item.ui && typeof item.ui === 'object' ? item.ui : {};
                if (String(item.module || '') !== String(detail.module || '')) return true;
                if (String(ui.type || '') !== String(detail.ui_type || detail.type || '')) return true;
                if (detail.printer_id && String(ui.printer_id || '') !== String(detail.printer_id)) return true;
                return false;
            });
            save();
            if (!pending.length && timer) {
                clearInterval(timer);
                document.removeEventListener('dmd:actionhub-ui-action-handled', handled);
            }
        };

        document.addEventListener('dmd:actionhub-ui-action-handled', handled);

        const dispatch = async () => {
            attempts += 1;
            for (const item of pending) {
                await ensureUiModuleOpen(item);
                document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action', { detail: item }));
            }
            if (!pending.length || attempts >= 30) {
                if (timer) clearInterval(timer);
                document.removeEventListener('dmd:actionhub-ui-action-handled', handled);
                save();
            }
        };

        setTimeout(dispatch, 250);
        timer = setInterval(dispatch, 500);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', restorePendingUiActions, { once: true });
    } else {
        restorePendingUiActions();
    }

})();
