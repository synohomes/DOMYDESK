<?php
/**
 * DoMyDesk 1.2.0 - ActionHub service.
 *
 * Ce fichier contient le contrat serveur d'ActionHub : ressources, contrôle
 * d'autorisation et catalogue léger. L'interface est dans action-hub.js/css.
 */

if (!defined('DMD_ACTIONHUB_ROOT')) {
    define('DMD_ACTIONHUB_ROOT', dirname(__DIR__));
}

if (!function_exists('dmd_actionhub_clean_text')) {
    function dmd_actionhub_clean_text($value, $maxLen = 240) {
        $value = trim(strip_tags((string)$value));
        if (function_exists('mb_substr')) {
            return mb_substr($value, 0, $maxLen, 'UTF-8');
        }
        return substr($value, 0, $maxLen);
    }
}

if (!function_exists('dmd_actionhub_normalize_resource')) {
    function dmd_actionhub_normalize_resource($resource) {
        if (function_exists('dmd_activity_normalize_resource')) {
            return dmd_activity_normalize_resource($resource);
        }
        if (!is_array($resource)) return null;
        $type = strtolower(dmd_actionhub_clean_text(isset($resource['type']) ? $resource['type'] : 'object', 80));
        $type = preg_replace('/[^a-z0-9._-]+/', '_', $type);
        $id = dmd_actionhub_clean_text(isset($resource['id']) ? $resource['id'] : '', 180);
        if ($id === '') return null;
        $name = dmd_actionhub_clean_text(isset($resource['name']) ? $resource['name'] : (isset($resource['label']) ? $resource['label'] : $id), 180);
        $source = dmd_actionhub_clean_text(isset($resource['source']) ? $resource['source'] : (isset($resource['module']) ? $resource['module'] : ''), 100);
        $tags = array();
        foreach ((array)(isset($resource['tags']) ? $resource['tags'] : array()) as $tag) {
            $tag = dmd_actionhub_clean_text($tag, 80);
            if ($tag !== '' && !in_array($tag, $tags, true)) $tags[] = $tag;
            if (count($tags) >= 20) break;
        }
        return array(
            'type' => $type !== '' ? $type : 'object',
            'id' => $id,
            'name' => $name !== '' ? $name : $id,
            'label' => $name !== '' ? $name : $id,
            'source' => $source,
            'tags' => $tags,
        );
    }
}

if (!function_exists('dmd_actionhub_authorize_checks')) {
    function dmd_actionhub_authorize_checks($email, $checks) {
        $email = trim((string)$email);
        $checks = is_array($checks) ? array_slice($checks, 0, 150) : array();
        $allowed = array();
        $cache = array();

        foreach ($checks as $check) {
            if (!is_array($check)) {
                $allowed[] = false;
                continue;
            }
            $moduleId = function_exists('dmd_safe_module_id')
                ? dmd_safe_module_id(isset($check['module']) ? $check['module'] : (isset($check['moduleId']) ? $check['moduleId'] : ''))
                : preg_replace('/[^a-zA-Z0-9._-]+/', '_', trim((string)(isset($check['module']) ? $check['module'] : '')));
            $permission = isset($check['permission']) ? trim((string)$check['permission']) : 'use';
            if (function_exists('dmd_normalize_module_permission_id')) {
                $permission = dmd_normalize_module_permission_id($moduleId, $permission);
            }
            if ($moduleId === '' || $permission === '') {
                $allowed[] = false;
                continue;
            }

            if (!array_key_exists($moduleId, $cache)) {
                $cache[$moduleId] = function_exists('dmd_effective_module_access')
                    ? dmd_effective_module_access($email, $moduleId)
                    : array('allowed' => false, 'permissions' => array());
            }
            $access = $cache[$moduleId];
            if (empty($access['allowed'])) {
                $allowed[] = false;
                continue;
            }
            if ($permission === 'use' || $permission === 'module.view' || $permission === 'view') {
                $allowed[] = true;
                continue;
            }
            $permissions = isset($access['permissions']) && is_array($access['permissions']) ? $access['permissions'] : array();
            if (function_exists('dmd_normalize_permissions')) {
                $permissions = dmd_normalize_permissions($permissions);
            }
            $allowed[] = in_array('*', $permissions, true) || in_array($permission, $permissions, true);
        }
        return $allowed;
    }
}

if (!function_exists('dmd_actionhub_recent_resources')) {
    function dmd_actionhub_recent_resources($email, $limit = 80) {
        $items = function_exists('dmd_activity_recent_resources')
            ? dmd_activity_recent_resources($email, $limit * 2)
            : array();
        $out = array();
        foreach ($items as $item) {
            if (!is_array($item) || empty($item['resource']) || !is_array($item['resource'])) continue;
            $resource = dmd_actionhub_normalize_resource($item['resource']);
            if (!$resource) continue;
            $moduleId = trim((string)(isset($item['module']) ? $item['module'] : $resource['source']));
            if ($moduleId !== '' && function_exists('dmd_effective_module_access')) {
                $access = dmd_effective_module_access($email, $moduleId);
                if (empty($access['allowed'])) continue;
            }
            $out[] = array(
                'resource' => $resource,
                'module' => $moduleId,
                'last_action' => isset($item['last_action']) ? (string)$item['last_action'] : '',
                'last_status' => isset($item['last_status']) ? (string)$item['last_status'] : '',
                'last_seen' => isset($item['last_seen']) ? (int)$item['last_seen'] : 0,
            );
            if (count($out) >= $limit) break;
        }
        return $out;
    }
}

if (!function_exists('dmd_actionhub_forget_resource')) {
    /**
     * Retire une ressource de la vue récente de l'utilisateur sans toucher à
     * l'objet réel. L'historique ActionHub est déplacé dans la corbeille
     * personnelle et n'est purgé que par un Superadmin depuis l'administration.
     */
    function dmd_actionhub_forget_resource($email, $resource) {
        $email = trim((string)$email);
        $resource = dmd_actionhub_normalize_resource($resource);
        if ($email === '' || !$resource) {
            return array('ok' => false, 'error' => 'invalid_resource');
        }
        if (!function_exists('dmd_activity_trash_resource')) {
            return array('ok' => false, 'error' => 'activity_service_unavailable');
        }
        return dmd_activity_trash_resource($email, $resource);
    }
}

if (!function_exists('dmd_actionhub_is_superadmin')) {
    function dmd_actionhub_is_superadmin($email) {
        $email = function_exists('dmd_activity_safe_email') ? dmd_activity_safe_email($email) : trim((string)$email);
        if ($email === '') return false;
        $profile = function_exists('dmd_read_profile') ? dmd_read_profile($email) : array();
        if (!is_array($profile) || !$profile) {
            $file = DMD_ACTIONHUB_ROOT . '/users/profiles/' . $email . '/profile/profile.json';
            $profile = is_file($file) ? json_decode((string)@file_get_contents($file), true) : array();
        }
        return is_array($profile) && strtolower((string)($profile['role_system'] ?? 'user')) === 'superadmin';
    }
}

if (!function_exists('dmd_actionhub_require_superadmin')) {
    function dmd_actionhub_require_superadmin($email) {
        return dmd_actionhub_is_superadmin($email)
            ? array('ok' => true)
            : array('ok' => false, 'error' => 'superadmin_required', 'message' => 'Cette opération est réservée au Superadmin.');
    }
}

if (!function_exists('dmd_actionhub_trash_users')) {
    function dmd_actionhub_trash_users($requesterEmail) {
        $auth = dmd_actionhub_require_superadmin($requesterEmail);
        if (empty($auth['ok'])) return $auth;
        if (!function_exists('dmd_activity_trash_summary')) {
            return array('ok' => false, 'error' => 'activity_service_unavailable');
        }

        $profilesDir = DMD_ACTIONHUB_ROOT . '/users/profiles';
        $users = array();
        $total = 0;
        $entries = is_dir($profilesDir) ? @scandir($profilesDir) : array();
        if (!is_array($entries)) $entries = array();

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $email = function_exists('dmd_activity_safe_email') ? dmd_activity_safe_email($entry) : trim((string)$entry);
            if ($email === '' || !is_dir($profilesDir . '/' . $entry)) continue;
            $summary = dmd_activity_trash_summary($email);
            $count = (int)($summary['count'] ?? 0);
            if ($count <= 0) continue;

            $profile = function_exists('dmd_read_profile') ? dmd_read_profile($email) : array();
            if (!is_array($profile)) $profile = array();
            $name = trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? ''));
            if ($name === '') $name = (string)($profile['pseudo'] ?? '');
            if ($name === '') $name = $email;

            $users[] = array(
                'email' => $email,
                'name' => $name,
                'role_system' => (string)($profile['role_system'] ?? 'user'),
                'count' => $count,
                'last_trashed_at' => (int)($summary['last_trashed_at'] ?? 0),
            );
            $total += $count;
        }

        usort($users, function($a, $b) {
            $byDate = (int)($b['last_trashed_at'] ?? 0) <=> (int)($a['last_trashed_at'] ?? 0);
            if ($byDate !== 0) return $byDate;
            return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        });

        return array('ok' => true, 'users' => $users, 'total' => $total);
    }
}

if (!function_exists('dmd_actionhub_trash_items')) {
    function dmd_actionhub_trash_items($requesterEmail, $ownerEmail, $limit = 250) {
        $auth = dmd_actionhub_require_superadmin($requesterEmail);
        if (empty($auth['ok'])) return $auth;
        $ownerEmail = function_exists('dmd_activity_safe_email') ? dmd_activity_safe_email($ownerEmail) : trim((string)$ownerEmail);
        if ($ownerEmail === '') return array('ok' => false, 'error' => 'invalid_user');
        if (!function_exists('dmd_activity_trash_items')) return array('ok' => false, 'error' => 'activity_service_unavailable');

        $profile = function_exists('dmd_read_profile') ? dmd_read_profile($ownerEmail) : array();
        if (!is_array($profile)) $profile = array();
        $name = trim((string)($profile['prenom'] ?? '') . ' ' . (string)($profile['nom'] ?? ''));
        if ($name === '') $name = (string)($profile['pseudo'] ?? '');
        if ($name === '') $name = $ownerEmail;

        $items = dmd_activity_trash_items($ownerEmail, max(1, min(500, (int)$limit)), true);
        return array(
            'ok' => true,
            'owner' => array('email' => $ownerEmail, 'name' => $name, 'role_system' => (string)($profile['role_system'] ?? 'user')),
            'count' => count($items),
            'items' => $items,
        );
    }
}

if (!function_exists('dmd_actionhub_trash_empty')) {
    function dmd_actionhub_trash_empty($requesterEmail, $ownerEmail) {
        $auth = dmd_actionhub_require_superadmin($requesterEmail);
        if (empty($auth['ok'])) return $auth;
        $ownerEmail = function_exists('dmd_activity_safe_email') ? dmd_activity_safe_email($ownerEmail) : trim((string)$ownerEmail);
        if ($ownerEmail === '') return array('ok' => false, 'error' => 'invalid_user');
        if (!function_exists('dmd_activity_purge_trash')) return array('ok' => false, 'error' => 'activity_service_unavailable');
        return dmd_activity_purge_trash($ownerEmail);
    }
}

if (!function_exists('dmd_actionhub_procedure_suggestions')) {
    function dmd_actionhub_procedure_suggestions($email, $context, $limit = 5) {
        $resource = dmd_actionhub_normalize_resource($context);
        if (!$resource || !function_exists('dmd_qs_suggest_procedures')) return array();

        $modules = array();
        if ($resource['source'] !== '') $modules[] = array('id' => $resource['source']);
        $current = array(
            'modules' => $modules,
            'resources' => array(array(
                'type' => $resource['type'],
                'id' => $resource['id'],
                'label' => $resource['label'],
                'source' => $resource['source'],
                'tags' => $resource['tags'],
            )),
            'tags' => $resource['tags'],
        );
        $suggestions = dmd_qs_suggest_procedures($email, $current, $limit);
        $out = array();
        foreach ($suggestions as $suggestion) {
            if (empty($suggestion['procedure'])) continue;
            $relative = !empty($suggestion['procedure_path']) ? (string)$suggestion['procedure_path'] : basename((string)$suggestion['procedure']);
            $parts = array();
            foreach (explode('/', str_replace('\\', '/', $relative)) as $part) {
                if ($part !== '' && $part !== '.' && $part !== '..') $parts[] = rawurlencode(basename($part));
            }
            $out[] = array(
                'procedure' => basename((string)$suggestion['procedure']),
                'score' => (int)(isset($suggestion['score']) ? $suggestion['score'] : 0),
                'url' => 'data/procedures/documents/' . implode('/', $parts),
            );
        }
        return $out;
    }
}

/* =========================================================
   Registre d'actions ActionHub 1.2.0

   Manifeste attendu :
   "actionhub": {
     "enabled": true,
     "handler": "actionhub_handler.php",
     "callable": "dmd_xxx_actionhub_handle",
     "actions": [
       {"id":"resource.open","label":"Ouvrir","permission":"module.view","resource_types":["type"]}
     ]
   }

   Le handler reçoit un contexte validé par le Core :
   callable(array $context) -> array('ok'=>bool,'message'=>string,'data'=>array,...)
   ========================================================= */
if (!function_exists('dmd_actionhub_safe_module_id')) {
    function dmd_actionhub_safe_module_id($value) {
        $value = trim((string)$value);
        if (function_exists('dmd_safe_module_id')) return dmd_safe_module_id($value);
        return preg_match('/^[a-zA-Z0-9._-]+$/', $value) ? $value : '';
    }
}

if (!function_exists('dmd_actionhub_manifest')) {
    function dmd_actionhub_manifest($moduleId) {
        $moduleId = dmd_actionhub_safe_module_id($moduleId);
        if ($moduleId === '') return null;
        $file = DMD_ACTIONHUB_ROOT . '/modules/' . $moduleId . '/dmd_module.json';
        if (!is_file($file)) return null;
        $data = json_decode((string)@file_get_contents($file), true);
        return is_array($data) ? $data : null;
    }
}

if (!function_exists('dmd_actionhub_normalize_action')) {
    function dmd_actionhub_normalize_action($moduleId, $action) {
        if (!is_array($action)) return null;

        $id = trim((string)($action['id'] ?? ''));
        $label = dmd_actionhub_clean_text($action['label'] ?? $id, 120);
        $scope = strtolower(trim((string)($action['scope'] ?? 'resource')));
        if (!in_array($scope, array('resource', 'module'), true)) $scope = 'resource';

        $permissions = array();
        $rawPermissions = isset($action['permissions']) && is_array($action['permissions'])
            ? $action['permissions']
            : array($action['permission'] ?? 'module.view');

        foreach ($rawPermissions as $permission) {
            $permission = trim((string)$permission);
            if ($permission === '' || !preg_match('/^[a-zA-Z0-9._:-]+$/', $permission)) continue;
            if (!in_array($permission, $permissions, true)) $permissions[] = $permission;
        }
        if (!$permissions) $permissions[] = 'module.view';

        if ($id === '' || !preg_match('/^[a-zA-Z0-9._:-]+$/', $id) || $label === '') return null;

        $types = array();
        foreach ((array)($action['resource_types'] ?? array()) as $type) {
            $type = strtolower(trim((string)$type));
            if ($type !== '' && preg_match('/^[a-z0-9._:-]+$/', $type) && !in_array($type, $types, true)) {
                $types[] = $type;
            }
        }
        if ($scope === 'resource' && !$types) return null;

        $inputs = array();
        foreach ((array)($action['inputs'] ?? array()) as $input) {
            if (!is_array($input)) continue;
            $inputId = trim((string)($input['id'] ?? ''));
            if ($inputId === '' || !preg_match('/^[a-zA-Z0-9._-]+$/', $inputId)) continue;

            $type = strtolower(trim((string)($input['type'] ?? 'text')));
            if (!in_array($type, array('text', 'textarea', 'list', 'date', 'number', 'boolean', 'select', 'users'), true)) {
                $type = 'text';
            }

            $options = array();
            foreach ((array)($input['options'] ?? array()) as $option) {
                if (is_array($option)) {
                    $value = dmd_actionhub_clean_text($option['value'] ?? '', 120);
                    $optionLabel = dmd_actionhub_clean_text($option['label'] ?? $value, 120);
                } else {
                    $value = dmd_actionhub_clean_text($option, 120);
                    $optionLabel = $value;
                }
                if ($value === '') continue;
                $options[] = array('value' => $value, 'label' => $optionLabel !== '' ? $optionLabel : $value);
            }

            $inputs[] = array(
                'id' => $inputId,
                'label' => dmd_actionhub_clean_text($input['label'] ?? $inputId, 120),
                'type' => $type,
                'required' => !empty($input['required']),
                'placeholder' => dmd_actionhub_clean_text($input['placeholder'] ?? '', 220),
                'help' => dmd_actionhub_clean_text($input['help'] ?? '', 300),
                'default' => $input['default'] ?? ($type === 'boolean' ? false : ($type === 'users' ? array() : '')),
                'options' => $options,
            );
        }

        $group = dmd_actionhub_clean_text($action['group'] ?? ($action['category'] ?? 'Général'), 100);
        if ($group === '') $group = 'Général';

        $meta = array();
        foreach ((array)($action['meta'] ?? array()) as $metaKey => $metaValue) {
            $metaKey = preg_replace('/[^a-zA-Z0-9._-]+/', '_', trim((string)$metaKey));
            if ($metaKey === '' || count($meta) >= 30) continue;
            if (is_bool($metaValue) || is_int($metaValue) || is_float($metaValue)) {
                $meta[$metaKey] = $metaValue;
            } elseif (is_scalar($metaValue)) {
                $meta[$metaKey] = dmd_actionhub_clean_text((string)$metaValue, 220);
            }
        }

        return array(
            'id' => $id,
            'label' => $label,
            'description' => dmd_actionhub_clean_text($action['description'] ?? '', 240),
            'icon' => dmd_actionhub_clean_text($action['icon'] ?? '⚡', 20),
            'group' => $group,
            'permission' => $permissions[0],
            'permissions' => $permissions,
            'resource_types' => $types,
            'scope' => $scope,
            'scenario' => !empty($action['scenario']),
            'inputs' => $inputs,
            'dangerous' => !empty($action['dangerous']),
            'confirm' => dmd_actionhub_clean_text($action['confirm'] ?? '', 240),
            'meta' => $meta,
            'module' => $moduleId,
        );
    }
}

if (!function_exists('dmd_actionhub_module_definition')) {
    function dmd_actionhub_module_definition($moduleId) {
        $moduleId = dmd_actionhub_safe_module_id($moduleId);
        $manifest = dmd_actionhub_manifest($moduleId);
        if (!$manifest || empty($manifest['actionhub']) || !is_array($manifest['actionhub'])) return null;
        $block = $manifest['actionhub'];
        if (array_key_exists('enabled', $block) && empty($block['enabled'])) return null;
        $handler = str_replace('\\', '/', trim((string)($block['handler'] ?? '')));
        $callable = trim((string)($block['callable'] ?? ''));
        $catalogCallable = trim((string)($block['catalog_callable'] ?? ''));
        $preflightCallable = trim((string)($block['preflight_callable'] ?? ''));
        $interactionCallable = trim((string)($block['interaction_callable'] ?? ''));
        if ($handler === '' || substr($handler, 0, 1) === '/' || strpos($handler, '..') !== false || strtolower(pathinfo($handler, PATHINFO_EXTENSION)) !== 'php') return null;
        if ($callable === '' || !preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $callable)) return null;
        if ($catalogCallable !== '' && !preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $catalogCallable)) return null;
        if ($preflightCallable !== '' && !preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $preflightCallable)) return null;
        if ($interactionCallable !== '' && !preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $interactionCallable)) return null;
        $handlerFile = DMD_ACTIONHUB_ROOT . '/modules/' . $moduleId . '/' . $handler;
        $realModule = realpath(DMD_ACTIONHUB_ROOT . '/modules/' . $moduleId);
        $realHandler = realpath($handlerFile);
        if ($realModule === false || $realHandler === false || strpos(str_replace('\\', '/', $realHandler), rtrim(str_replace('\\', '/', $realModule), '/') . '/') !== 0) return null;
        $actions = array();
        foreach ((array)($block['actions'] ?? array()) as $action) {
            $clean = dmd_actionhub_normalize_action($moduleId, $action);
            if ($clean) $actions[$clean['id']] = $clean;
        }
        if (!$actions) return null;
        return array(
            'module' => $moduleId,
            'name' => trim((string)($manifest['name'] ?? $moduleId)),
            'handler' => $handlerFile,
            'callable' => $callable,
            'catalog_callable' => $catalogCallable,
            'preflight_callable' => $preflightCallable,
            'interaction_callable' => $interactionCallable,
            'actions' => $actions,
        );
    }
}


if (!function_exists('dmd_actionhub_runtime_actions')) {
    function dmd_actionhub_runtime_actions($email, $moduleId, $resource = null) {
        $moduleId = dmd_actionhub_safe_module_id($moduleId);
        $definition = $moduleId !== '' ? dmd_actionhub_module_definition($moduleId) : null;
        if (!$definition) return array();

        $actions = $definition['actions'];
        $catalogCallable = trim((string)($definition['catalog_callable'] ?? ''));
        if ($catalogCallable === '') return $actions;

        require_once $definition['handler'];
        if (!is_callable($catalogCallable)) return $actions;

        $context = array(
            'email' => trim((string)$email),
            'module' => $moduleId,
            'resource' => $resource !== null ? dmd_actionhub_normalize_resource($resource) : null,
            'actions' => array_values($actions),
        );

        try {
            $provided = call_user_func($catalogCallable, $context);
        } catch (Throwable $e) {
            return $actions;
        }

        if (!is_array($provided)) return $actions;
        $replace = !empty($provided['replace']);
        $providedActions = isset($provided['actions']) && is_array($provided['actions'])
            ? $provided['actions']
            : $provided;

        $runtime = $replace ? array() : $actions;
        foreach ($providedActions as $action) {
            $clean = dmd_actionhub_normalize_action($moduleId, $action);
            if ($clean) $runtime[$clean['id']] = $clean;
        }
        return $runtime;
    }
}

if (!function_exists('dmd_actionhub_runtime_action')) {
    function dmd_actionhub_runtime_action($email, $moduleId, $actionId, $resource = null) {
        $actions = dmd_actionhub_runtime_actions($email, $moduleId, $resource);
        return isset($actions[$actionId]) && is_array($actions[$actionId]) ? $actions[$actionId] : null;
    }
}

if (!function_exists('dmd_actionhub_action_authorized')) {
    function dmd_actionhub_action_authorized($email, $moduleId, $action) {
        if (!is_array($action)) return false;
        $checks = array();
        $permissions = isset($action['permissions']) && is_array($action['permissions'])
            ? $action['permissions']
            : array($action['permission'] ?? 'module.view');

        foreach ($permissions as $permission) {
            $checks[] = array('module' => $moduleId, 'permission' => $permission);
        }

        $decisions = dmd_actionhub_authorize_checks($email, $checks);
        if (count($decisions) !== count($checks)) return false;
        foreach ($decisions as $allowed) {
            if (!$allowed) return false;
        }
        return true;
    }
}

if (!function_exists('dmd_actionhub_actions_for_resource')) {
    function dmd_actionhub_actions_for_resource($email, $resource) {
        $resource = dmd_actionhub_normalize_resource($resource);
        if (!$resource) return array();
        $moduleId = dmd_actionhub_safe_module_id($resource['source']);
        if ($moduleId === '') return array();
        $definition = dmd_actionhub_module_definition($moduleId);
        if (!$definition) return array();

        $runtimeActions = dmd_actionhub_runtime_actions($email, $moduleId, $resource);
        $out = array();
        foreach ($runtimeActions as $action) {
            if (($action['scope'] ?? 'resource') !== 'resource') continue;
            if (!in_array($resource['type'], $action['resource_types'], true)) continue;
            if (!dmd_actionhub_action_authorized($email, $moduleId, $action)) continue;
            $out[] = $action;
        }
        return $out;
    }
}

if (!function_exists('dmd_actionhub_execute')) {
    function dmd_actionhub_execute($email, $moduleId, $actionId, $resource = null, $payload = array(), $runtime = array()) {
        $email = trim((string)$email);
        $moduleId = dmd_actionhub_safe_module_id($moduleId);
        $actionId = trim((string)$actionId);

        if ($email === '' || $moduleId === '' || $actionId === '') {
            return array('ok' => false, 'error' => 'invalid_action_request');
        }

        $definition = dmd_actionhub_module_definition($moduleId);
        if (!$definition) {
            return array('ok' => false, 'error' => 'action_not_declared');
        }

        $normalizedResource = $resource !== null ? dmd_actionhub_normalize_resource($resource) : null;
        $action = dmd_actionhub_runtime_action($email, $moduleId, $actionId, $normalizedResource);
        if (!$action) {
            return array('ok' => false, 'error' => 'action_not_declared');
        }

        $scope = isset($action['scope']) ? (string)$action['scope'] : 'resource';

        if ($scope === 'resource') {
            if (!$normalizedResource || strcasecmp($normalizedResource['source'], $moduleId) !== 0) {
                return array('ok' => false, 'error' => 'invalid_action_request');
            }
            if (!in_array($normalizedResource['type'], $action['resource_types'], true)) {
                return array('ok' => false, 'error' => 'resource_type_not_allowed');
            }
        }

        if (!dmd_actionhub_action_authorized($email, $moduleId, $action)) {
            return array('ok' => false, 'error' => 'permission_denied');
        }

        require_once $definition['handler'];
        if (!is_callable($definition['callable'])) {
            return array('ok' => false, 'error' => 'handler_unavailable');
        }

        $context = array(
            'email' => $email,
            'module' => $moduleId,
            'action' => $action,
            'resource' => $normalizedResource,
            'payload' => is_array($payload) ? $payload : array(),
            'runtime' => is_array($runtime) ? $runtime : array(),
        );

        try {
            $handlerResult = call_user_func($definition['callable'], $context);
        } catch (Throwable $e) {
            $handlerResult = array(
                'ok' => false,
                'message' => 'Erreur du handler ActionHub.',
                'internal_error' => $e->getMessage()
            );
        }

        if (!is_array($handlerResult)) {
            $handlerResult = array('ok' => false, 'message' => 'Réponse ActionHub invalide.');
        }

        $success = !empty($handlerResult['ok']);

        if (
            $scope === 'resource' &&
            $normalizedResource &&
            empty($handlerResult['event_emitted']) &&
            function_exists('dmd_module_event')
        ) {
            dmd_module_event($moduleId, $actionId, $normalizedResource, array(
                'email' => $email,
                'label' => $action['label'],
                'target' => $normalizedResource['name'],
                'status' => $success ? 'success' : 'error',
                'details' => isset($handlerResult['message']) ? (string)$handlerResult['message'] : '',
                'changes' => isset($handlerResult['changes']) && is_array($handlerResult['changes']) ? $handlerResult['changes'] : array(),
                'meta' => array('source' => 'actionhub'),
            ));
        }

        return array(
            'ok' => $success,
            'error' => $success ? '' : (string)($handlerResult['error'] ?? 'action_failed'),
            'message' => dmd_actionhub_clean_text(
                $handlerResult['message'] ?? ($success ? 'Action exécutée.' : 'Action échouée.'),
                300
            ),
            'data' => isset($handlerResult['data']) && is_array($handlerResult['data']) ? $handlerResult['data'] : array(),
        );
    }
}

/* =========================================================
   Scénarios ActionHub 1.2.0
   - Les scénarios appartiennent à l'utilisateur.
   - Ils ne contiennent jamais de code PHP ni de secret.
   - Une étape référence uniquement une action ActionHub déclarée par un module.
   - Le moteur exécute les étapes séquentiellement et s'arrête au premier échec.
   ========================================================= */

if (!function_exists('dmd_actionhub_safe_email')) {
    function dmd_actionhub_safe_email($email) {
        $email = trim((string)$email);
        if (function_exists('dmd_sys_safe_email')) return dmd_sys_safe_email($email);
        if ($email === '' || basename($email) !== $email || strpos($email, "\0") !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false) return '';
        return preg_match('/^[a-zA-Z0-9_@.\-+]+$/', $email) ? $email : '';
    }
}

if (!function_exists('dmd_actionhub_scenario_dir')) {
    function dmd_actionhub_scenario_dir($email, $create = true) {
        $email = dmd_actionhub_safe_email($email);
        if ($email === '') return '';

        $dir = DMD_ACTIONHUB_ROOT . '/users/profiles/' . $email . '/actionhub/scenarios';
        if ($create && !is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }

        if ($create && is_dir($dir)) {
            if (function_exists('dmd_ensure_denied_directory')) {
                dmd_ensure_denied_directory(dirname($dir));
                dmd_ensure_denied_directory($dir);
            } else {
                $rules = "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
                foreach (array(dirname($dir), $dir) as $protectedDir) {
                    $htaccess = $protectedDir . '/.htaccess';
                    if (is_dir($protectedDir) && !is_file($htaccess)) {
                        @file_put_contents($htaccess, $rules, LOCK_EX);
                        @chmod($htaccess, 0640);
                    }
                }
            }
        }

        return is_dir($dir) ? $dir : '';
    }
}

if (!function_exists('dmd_actionhub_read_json')) {
    function dmd_actionhub_read_json($file) {
        if (!is_file($file)) return null;
        $raw = @file_get_contents($file);
        if ($raw === false || $raw === '') return null;
        $data = json_decode($raw, true);
        return (json_last_error() === JSON_ERROR_NONE && is_array($data)) ? $data : null;
    }
}

if (!function_exists('dmd_actionhub_write_json')) {
    function dmd_actionhub_write_json($file, array $data) {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;

        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;

        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);

        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }

        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_actionhub_scenario_id')) {
    function dmd_actionhub_scenario_id() {
        try {
            $suffix = strtoupper(bin2hex(random_bytes(4)));
        } catch (Exception $e) {
            $suffix = strtoupper(substr(md5(uniqid('', true)), 0, 8));
        }
        return 'SCN-' . date('Ymd-His') . '-' . $suffix;
    }
}

if (!function_exists('dmd_actionhub_safe_scenario_id')) {
    function dmd_actionhub_safe_scenario_id($value) {
        $value = trim((string)$value);
        return preg_match('/^SCN-[A-Za-z0-9._-]+$/', $value) ? $value : '';
    }
}

if (!function_exists('dmd_actionhub_scenario_file')) {
    function dmd_actionhub_scenario_file($email, $scenarioId) {
        $scenarioId = dmd_actionhub_safe_scenario_id($scenarioId);
        $dir = dmd_actionhub_scenario_dir($email, true);
        if ($scenarioId === '' || $dir === '') return '';
        return $dir . '/' . $scenarioId . '.json';
    }
}

if (!function_exists('dmd_actionhub_normalize_keywords')) {
    function dmd_actionhub_normalize_keywords($keywords) {
        if (is_string($keywords)) {
            $keywords = preg_split('/[,;\r\n]+/', $keywords);
        }
        $out = array();
        foreach ((array)$keywords as $keyword) {
            $keyword = dmd_actionhub_clean_text($keyword, 80);
            if ($keyword === '') continue;
            $key = function_exists('mb_strtolower') ? mb_strtolower($keyword, 'UTF-8') : strtolower($keyword);
            if (!isset($out[$key])) $out[$key] = $keyword;
            if (count($out) >= 40) break;
        }
        return array_values($out);
    }
}

if (!function_exists('dmd_actionhub_payload_from_inputs')) {
    function dmd_actionhub_payload_from_inputs($action, $payload, &$error = '', $email = '') {
        $error = '';
        $payload = is_array($payload) ? $payload : array();
        $clean = array();

        foreach ((array)($action['inputs'] ?? array()) as $input) {
            if (!is_array($input) || empty($input['id'])) continue;

            $id = (string)$input['id'];
            $type = (string)($input['type'] ?? 'text');
            $required = !empty($input['required']);
            $value = array_key_exists($id, $payload) ? $payload[$id] : ($input['default'] ?? '');

            if ($type === 'list') {
                if (is_string($value)) {
                    $value = preg_split('/[\r\n]+/', $value);
                }
                $items = array();
                foreach ((array)$value as $item) {
                    $item = dmd_actionhub_clean_text($item, 220);
                    if ($item !== '' && !in_array($item, $items, true)) $items[] = $item;
                    if (count($items) >= 200) break;
                }
                $value = $items;
                if ($required && !$value) {
                    $error = 'Champ requis : ' . (string)($input['label'] ?? $id);
                    return null;
                }
            } elseif ($type === 'users') {
                if (is_string($value)) {
                    $value = preg_split('/[,;\r\n]+/', $value);
                }

                $users = array();
                $profilesRoot = DMD_ACTIONHUB_ROOT . '/users/profiles/';
                foreach ((array)$value as $candidate) {
                    $candidate = dmd_actionhub_safe_email($candidate);
                    if ($candidate === '' || strcasecmp($candidate, $email ?? '') === 0) continue;
                    if (!is_dir($profilesRoot . $candidate)) continue;
                    if (!in_array($candidate, $users, true)) $users[] = $candidate;
                    if (count($users) >= 100) break;
                }

                $value = $users;
                if ($required && !$value) {
                    $error = 'Champ requis : ' . (string)($input['label'] ?? $id);
                    return null;
                }
            } elseif ($type === 'boolean') {
                $value = !empty($value);
            } elseif ($type === 'number') {
                if ($value === '' && !$required) {
                    $value = '';
                } elseif (!is_numeric($value)) {
                    $error = 'Valeur numérique invalide : ' . (string)($input['label'] ?? $id);
                    return null;
                } else {
                    $value = 0 + $value;
                }
            } elseif ($type === 'date') {
                $value = trim((string)$value);
                if ($value !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                    $error = 'Date invalide : ' . (string)($input['label'] ?? $id);
                    return null;
                }
                if ($required && $value === '') {
                    $error = 'Champ requis : ' . (string)($input['label'] ?? $id);
                    return null;
                }
            } elseif ($type === 'select') {
                $value = dmd_actionhub_clean_text($value, 120);
                $allowed = array();
                foreach ((array)($input['options'] ?? array()) as $option) {
                    if (is_array($option) && isset($option['value'])) $allowed[] = (string)$option['value'];
                }
                if ($value !== '' && $allowed && !in_array($value, $allowed, true)) {
                    $error = 'Choix invalide : ' . (string)($input['label'] ?? $id);
                    return null;
                }
                if ($required && $value === '') {
                    $error = 'Champ requis : ' . (string)($input['label'] ?? $id);
                    return null;
                }
            } else {
                $maxLen = $type === 'textarea' ? 5000 : 500;
                $value = dmd_actionhub_clean_text($value, $maxLen);
                if ($required && $value === '') {
                    $error = 'Champ requis : ' . (string)($input['label'] ?? $id);
                    return null;
                }
            }

            $clean[$id] = $value;
        }

        return $clean;
    }
}


if (!function_exists('dmd_actionhub_user_catalog')) {
    function dmd_actionhub_user_catalog($email) {
        $email = dmd_actionhub_safe_email($email);
        $root = DMD_ACTIONHUB_ROOT . '/users/profiles/';
        if ($email === '' || !is_dir($root)) return array();

        $dirs = glob($root . '*', GLOB_ONLYDIR);
        if (!$dirs) return array();

        $out = array();
        foreach ($dirs as $dir) {
            $candidate = dmd_actionhub_safe_email(basename($dir));
            if ($candidate === '' || strcasecmp($candidate, $email) === 0) continue;

            $profile = function_exists('dmd_read_profile') ? dmd_read_profile($candidate) : array();
            $first = is_array($profile) ? trim((string)($profile['prenom'] ?? ($profile['first_name'] ?? ($profile['firstname'] ?? '')))) : '';
            $last = is_array($profile) ? trim((string)($profile['nom'] ?? ($profile['last_name'] ?? ($profile['lastname'] ?? '')))) : '';
            $name = trim($first . ' ' . $last);

            if ($name === '' && is_array($profile)) {
                foreach (array('name', 'display_name', 'username') as $key) {
                    if (!empty($profile[$key])) {
                        $name = trim((string)$profile[$key]);
                        break;
                    }
                }
            }
            if ($name === '') $name = $candidate;

            $out[] = array(
                'email' => $candidate,
                'first_name' => dmd_actionhub_clean_text($first, 90),
                'last_name' => dmd_actionhub_clean_text($last, 90),
                'name' => dmd_actionhub_clean_text($name, 180),
            );
        }

        usort($out, function ($a, $b) {
            return strcasecmp((string)$a['name'], (string)$b['name']);
        });

        return $out;
    }
}

if (!function_exists('dmd_actionhub_scenario_catalog')) {
    function dmd_actionhub_scenario_catalog($email) {
        $root = DMD_ACTIONHUB_ROOT . '/modules';
        if (!is_dir($root)) return array();

        $dirs = glob($root . '/*', GLOB_ONLYDIR);
        if (!$dirs) return array();

        $catalog = array();
        foreach ($dirs as $dir) {
            $moduleId = dmd_actionhub_safe_module_id(basename($dir));
            if ($moduleId === '') continue;

            $definition = dmd_actionhub_module_definition($moduleId);
            if (!$definition) continue;

            $actions = array();
            $runtimeActions = dmd_actionhub_runtime_actions($email, $moduleId, null);
            foreach ($runtimeActions as $action) {
                if (empty($action['scenario']) || ($action['scope'] ?? 'resource') !== 'module') continue;
                if (!dmd_actionhub_action_authorized($email, $moduleId, $action)) continue;

                $actions[] = array(
                    'id' => $action['id'],
                    'label' => $action['label'],
                    'description' => $action['description'],
                    'icon' => $action['icon'],
                    'group' => $action['group'] ?? 'Général',
                    'dangerous' => !empty($action['dangerous']),
                    'confirm' => $action['confirm'],
                    'inputs' => $action['inputs'],
                    'meta' => $action['meta'] ?? array(),
                );
            }

            if ($actions) {
                $catalog[] = array(
                    'module' => $moduleId,
                    'name' => $definition['name'],
                    'actions' => $actions,
                );
            }
        }

        usort($catalog, function ($a, $b) {
            return strcasecmp((string)$a['name'], (string)$b['name']);
        });

        return $catalog;
    }
}

if (!function_exists('dmd_actionhub_scenario_normalize')) {
    function dmd_actionhub_scenario_normalize($email, $scenario, $existing = null, &$error = '') {
        $error = '';
        if (!is_array($scenario)) {
            $error = 'Scénario invalide.';
            return null;
        }

        $name = dmd_actionhub_clean_text($scenario['name'] ?? '', 160);
        if ($name === '') {
            $error = 'Le nom du scénario est obligatoire.';
            return null;
        }

        $scenarioId = isset($existing['id'])
            ? dmd_actionhub_safe_scenario_id($existing['id'])
            : dmd_actionhub_safe_scenario_id($scenario['id'] ?? '');

        if ($scenarioId === '') $scenarioId = dmd_actionhub_scenario_id();

        $steps = array();
        foreach ((array)($scenario['steps'] ?? array()) as $index => $step) {
            if (!is_array($step)) continue;

            $moduleId = dmd_actionhub_safe_module_id($step['module'] ?? '');
            $actionId = trim((string)($step['action_id'] ?? ''));
            if ($moduleId === '' || $actionId === '') {
                $error = 'Étape ' . ($index + 1) . ' incomplète.';
                return null;
            }

            $action = dmd_actionhub_runtime_action($email, $moduleId, $actionId, null);

            if (!$action || empty($action['scenario']) || ($action['scope'] ?? 'resource') !== 'module') {
                $error = 'Action de scénario non disponible à l’étape ' . ($index + 1) . '.';
                return null;
            }

            if (!dmd_actionhub_action_authorized($email, $moduleId, $action)) {
                $error = 'Permission refusée à l’étape ' . ($index + 1) . '.';
                return null;
            }

            $payloadError = '';
            $payload = dmd_actionhub_payload_from_inputs($action, $step['payload'] ?? array(), $payloadError, $email);
            if ($payload === null) {
                $error = 'Étape ' . ($index + 1) . ' : ' . $payloadError;
                return null;
            }

            $steps[] = array(
                'id' => !empty($step['id']) && preg_match('/^[a-zA-Z0-9._-]+$/', (string)$step['id'])
                    ? (string)$step['id']
                    : 'step_' . ($index + 1),
                'module' => $moduleId,
                'action_id' => $actionId,
                'payload' => $payload,
            );

            if (count($steps) >= 50) break;
        }

        if (!$steps) {
            $error = 'Ajoute au moins une étape au scénario.';
            return null;
        }

        $workspaceInput = isset($scenario['workspace']) && is_array($scenario['workspace'])
            ? $scenario['workspace']
            : array();

        $createDashboard = !empty($workspaceInput['create_dashboard']);
        $dashboardNameRaw = dmd_actionhub_clean_text($workspaceInput['dashboard_name'] ?? '', 64);
        if ($dashboardNameRaw === '') $dashboardNameRaw = $name;
        $dashboardName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $dashboardNameRaw);
        $dashboardName = trim((string)$dashboardName, '_-');
        if ($dashboardName === '') $dashboardName = 'scenario';
        $dashboardName = substr($dashboardName, 0, 64);

        $now = time();
        return array(
            'version' => 2,
            'id' => $scenarioId,
            'name' => $name,
            'description' => dmd_actionhub_clean_text($scenario['description'] ?? '', 1000),
            'keywords' => dmd_actionhub_normalize_keywords($scenario['keywords'] ?? array()),
            'workspace' => array(
                'create_dashboard' => $createDashboard,
                'dashboard_name' => $dashboardName,
            ),
            'steps' => $steps,
            'created_at' => isset($existing['created_at']) ? (int)$existing['created_at'] : $now,
            'created_at_iso' => isset($existing['created_at_iso']) ? (string)$existing['created_at_iso'] : date('c', $now),
            'updated_at' => $now,
            'updated_at_iso' => date('c', $now),
            'last_run_at' => isset($existing['last_run_at']) ? (int)$existing['last_run_at'] : null,
            'last_run_ok' => isset($existing['last_run_ok']) ? (bool)$existing['last_run_ok'] : null,
        );
    }
}

if (!function_exists('dmd_actionhub_scenario_save')) {
    function dmd_actionhub_scenario_save($email, $scenario) {
        $requestedId = is_array($scenario) ? dmd_actionhub_safe_scenario_id($scenario['id'] ?? '') : '';
        $existing = null;

        if ($requestedId !== '') {
            $existingFile = dmd_actionhub_scenario_file($email, $requestedId);
            if ($existingFile !== '' && is_file($existingFile)) {
                $existing = dmd_actionhub_read_json($existingFile);
            }
        }

        $error = '';
        $clean = dmd_actionhub_scenario_normalize($email, $scenario, $existing, $error);
        if (!$clean) return array('ok' => false, 'error' => 'invalid_scenario', 'message' => $error);

        $file = dmd_actionhub_scenario_file($email, $clean['id']);
        if ($file === '' || !dmd_actionhub_write_json($file, $clean)) {
            return array('ok' => false, 'error' => 'write_failed', 'message' => 'Impossible d’enregistrer le scénario.');
        }

        return array('ok' => true, 'scenario' => $clean);
    }
}

if (!function_exists('dmd_actionhub_search_fold')) {
    function dmd_actionhub_search_fold($value) {
        $value = html_entity_decode(strip_tags((string)$value), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        if (function_exists('transliterator_transliterate')) {
            $tmp = @transliterator_transliterate('NFD; [:Nonspacing Mark:] Remove; NFC', $value);
            if (is_string($tmp) && $tmp !== '') $value = $tmp;
        } elseif (function_exists('iconv')) {
            $tmp = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if (is_string($tmp) && $tmp !== '') $value = $tmp;
        }

        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/i', ' ', $value);
        return trim(preg_replace('/\s+/', ' ', (string)$value));
    }
}

if (!function_exists('dmd_actionhub_scenario_search_score')) {
    function dmd_actionhub_scenario_search_score($scenario, $query) {
        $query = dmd_actionhub_search_fold($query);
        if ($query === '') return 1;

        $name = dmd_actionhub_search_fold($scenario['name'] ?? '');
        $keywords = dmd_actionhub_search_fold(implode(' ', (array)($scenario['keywords'] ?? array())));
        $description = dmd_actionhub_search_fold($scenario['description'] ?? '');
        $haystack = trim($name . ' ' . $keywords . ' ' . $description);

        $tokens = array_values(array_filter(preg_split('/\s+/', $query), 'strlen'));
        $matched = 0;
        foreach ($tokens as $token) {
            if (strpos($haystack, (string)$token) !== false) $matched++;
        }

        if ($matched < count($tokens)) return 0;
        if ($name === $query) return 100;
        if (strpos($name, $query) !== false) return 95;
        if (strpos($keywords, $query) !== false) return 90;

        return 70 + min(20, $matched * 5);
    }
}

if (!function_exists('dmd_actionhub_scenarios')) {
    function dmd_actionhub_scenarios($email, $query = '') {
        $dir = dmd_actionhub_scenario_dir($email, false);
        if ($dir === '' || !is_dir($dir)) return array();

        $files = glob($dir . '/SCN-*.json');
        if (!$files) return array();

        $out = array();
        foreach ($files as $file) {
            $scenario = dmd_actionhub_read_json($file);
            if (!$scenario || empty($scenario['id']) || empty($scenario['name'])) continue;

            $score = dmd_actionhub_scenario_search_score($scenario, $query);
            if ($score <= 0) continue;

            $scenario['score'] = $score;
            $scenario['step_count'] = count((array)($scenario['steps'] ?? array()));
            $out[] = $scenario;
        }

        usort($out, function ($a, $b) {
            $scoreA = (int)($a['score'] ?? 0);
            $scoreB = (int)($b['score'] ?? 0);
            if ($scoreA !== $scoreB) return $scoreB <=> $scoreA;
            return ((int)($b['updated_at'] ?? 0)) <=> ((int)($a['updated_at'] ?? 0));
        });

        return array_slice($out, 0, 100);
    }
}

if (!function_exists('dmd_actionhub_scenario_delete')) {
    function dmd_actionhub_scenario_delete($email, $scenarioId) {
        $file = dmd_actionhub_scenario_file($email, $scenarioId);
        if ($file === '' || !is_file($file)) {
            return array('ok' => false, 'error' => 'scenario_not_found', 'message' => 'Scénario introuvable.');
        }

        if (!@unlink($file)) {
            return array('ok' => false, 'error' => 'delete_failed', 'message' => 'Impossible de supprimer le scénario.');
        }

        return array('ok' => true, 'deleted' => true);
    }
}


if (!function_exists('dmd_actionhub_scenario_preflight')) {
    /**
     * Préflight générique : chaque module peut demander une interaction avant
     * qu'aucune étape du scénario ne soit exécutée (MFA, confirmation externe,
     * déverrouillage, etc.). ActionHub ne connaît pas la logique métier.
     */
    function dmd_actionhub_scenario_preflight($email, $scenario) {
        foreach ((array)($scenario['steps'] ?? array()) as $index => $step) {
            $moduleId = dmd_actionhub_safe_module_id($step['module'] ?? '');
            $actionId = trim((string)($step['action_id'] ?? ''));
            if ($moduleId === '' || $actionId === '') continue;

            $definition = dmd_actionhub_module_definition($moduleId);
            $action = $definition ? dmd_actionhub_runtime_action($email, $moduleId, $actionId, null) : null;
            if (!$definition || !$action) continue;

            $callable = trim((string)($definition['preflight_callable'] ?? ''));
            if ($callable === '') continue;

            require_once $definition['handler'];
            if (!is_callable($callable)) continue;

            try {
                $result = call_user_func($callable, array(
                    'email' => $email,
                    'module' => $moduleId,
                    'action' => $action,
                    'payload' => is_array($step['payload'] ?? null) ? $step['payload'] : array(),
                    'scenario' => array('id' => (string)($scenario['id'] ?? ''), 'name' => (string)($scenario['name'] ?? '')),
                    'step' => array('index' => $index, 'id' => (string)($step['id'] ?? ('step_' . ($index + 1)))),
                ));
            } catch (Throwable $e) {
                return array('ok'=>false,'error'=>'preflight_failed','message'=>'Préparation du scénario impossible.');
            }

            if (!is_array($result) || !empty($result['ok'])) continue;
            if (($result['error'] ?? '') !== 'interaction_required') {
                return array(
                    'ok'=>false,
                    'error'=>(string)($result['error'] ?? 'preflight_failed'),
                    'message'=>dmd_actionhub_clean_text($result['message'] ?? 'Préparation du scénario impossible.', 300),
                );
            }

            $interaction = isset($result['interaction']) && is_array($result['interaction']) ? $result['interaction'] : array();
            $interaction['module'] = $moduleId;
            $interaction['action_id'] = $actionId;
            $interaction['step_id'] = (string)($step['id'] ?? ('step_' . ($index + 1)));
            return array(
                'ok'=>false,
                'error'=>'interaction_required',
                'message'=>dmd_actionhub_clean_text($result['message'] ?? 'Une interaction est requise avant de continuer.', 300),
                'interaction'=>$interaction,
            );
        }
        return array('ok'=>true);
    }
}

if (!function_exists('dmd_actionhub_scenario_interaction')) {
    function dmd_actionhub_scenario_interaction($email, $scenarioId, $moduleId, $actionId, $values) {
        $file = dmd_actionhub_scenario_file($email, $scenarioId);
        $scenario = $file !== '' ? dmd_actionhub_read_json($file) : null;
        if (!$scenario) return array('ok'=>false,'error'=>'scenario_not_found','message'=>'Scénario introuvable.');

        $moduleId = dmd_actionhub_safe_module_id($moduleId);
        $actionId = trim((string)$actionId);
        $matched = false;
        foreach ((array)($scenario['steps'] ?? array()) as $step) {
            if (strcasecmp((string)($step['module'] ?? ''), $moduleId) === 0 && (string)($step['action_id'] ?? '') === $actionId) {
                $matched = true;
                break;
            }
        }
        if (!$matched) return array('ok'=>false,'error'=>'interaction_not_allowed','message'=>'Interaction non liée à ce scénario.');

        $definition = dmd_actionhub_module_definition($moduleId);
        $action = $definition ? dmd_actionhub_runtime_action($email, $moduleId, $actionId, null) : null;
        if (!$definition || !$action || !dmd_actionhub_action_authorized($email, $moduleId, $action)) {
            return array('ok'=>false,'error'=>'permission_denied','message'=>'Interaction refusée.');
        }

        $callable = trim((string)($definition['interaction_callable'] ?? ''));
        if ($callable === '') return array('ok'=>false,'error'=>'interaction_unavailable','message'=>'Interaction indisponible pour ce module.');

        require_once $definition['handler'];
        if (!is_callable($callable)) return array('ok'=>false,'error'=>'interaction_unavailable','message'=>'Interaction indisponible pour ce module.');

        try {
            $result = call_user_func($callable, array(
                'email'=>$email,
                'module'=>$moduleId,
                'action'=>$action,
                'values'=>is_array($values) ? $values : array(),
                'scenario'=>array('id'=>(string)$scenario['id'],'name'=>(string)$scenario['name']),
            ));
        } catch (Throwable $e) {
            return array('ok'=>false,'error'=>'interaction_failed','message'=>'Validation de l’interaction impossible.');
        }

        if (!is_array($result)) return array('ok'=>false,'error'=>'interaction_failed','message'=>'Réponse d’interaction invalide.');
        return $result;
    }
}

if (!function_exists('dmd_actionhub_scenario_execute')) {
    function dmd_actionhub_scenario_execute($email, $scenarioId) {
        $file = dmd_actionhub_scenario_file($email, $scenarioId);
        $scenario = $file !== '' ? dmd_actionhub_read_json($file) : null;
        if (!$scenario) {
            return array('ok' => false, 'error' => 'scenario_not_found', 'message' => 'Scénario introuvable.');
        }

        $results = array();
        $allOk = true;

        $preflight = dmd_actionhub_scenario_preflight($email, $scenario);
        if (empty($preflight['ok'])) {
            return array(
                'ok'=>false,
                'error'=>(string)($preflight['error'] ?? 'preflight_failed'),
                'message'=>(string)($preflight['message'] ?? 'Préparation du scénario impossible.'),
                'interaction'=>isset($preflight['interaction']) && is_array($preflight['interaction']) ? $preflight['interaction'] : array(),
                'scenario'=>array('id'=>(string)$scenario['id'],'name'=>(string)$scenario['name']),
                'results'=>array()
            );
        }

        foreach ((array)($scenario['steps'] ?? array()) as $index => $step) {
            $moduleId = dmd_actionhub_safe_module_id($step['module'] ?? '');
            $actionId = trim((string)($step['action_id'] ?? ''));
            $action = $moduleId !== '' ? dmd_actionhub_runtime_action($email, $moduleId, $actionId, null) : null;

            if (!$action || empty($action['scenario']) || ($action['scope'] ?? 'resource') !== 'module') {
                return array(
                    'ok' => false,
                    'error' => 'scenario_action_unavailable',
                    'message' => 'Action indisponible à l’étape ' . ($index + 1) . '.'
                );
            }

            if (!dmd_actionhub_action_authorized($email, $moduleId, $action)) {
                return array(
                    'ok' => false,
                    'error' => 'permission_denied',
                    'message' => 'Permission refusée à l’étape ' . ($index + 1) . '.'
                );
            }
        }

        foreach ((array)($scenario['steps'] ?? array()) as $index => $step) {
            $moduleId = (string)$step['module'];
            $actionId = (string)$step['action_id'];
            $action = dmd_actionhub_runtime_action($email, $moduleId, $actionId, null);
            if (!$action) {
                $results[] = array(
                    'index' => $index,
                    'step_id' => (string)($step['id'] ?? ('step_' . ($index + 1))),
                    'module' => $moduleId,
                    'action_id' => $actionId,
                    'label' => $actionId,
                    'ok' => false,
                    'message' => 'Action indisponible à l’étape ' . ($index + 1) . '.',
                    'data' => array(),
                );
                $allOk = false;
                break;
            }

            $payloadError = '';
            $payload = dmd_actionhub_payload_from_inputs($action, $step['payload'] ?? array(), $payloadError, $email);
            if ($payload === null) {
                $result = array(
                    'ok' => false,
                    'error' => 'invalid_payload',
                    'message' => $payloadError,
                    'data' => array()
                );
            } else {
                $previous = $results ? $results[count($results) - 1] : null;
                $runtime = array(
                    'step_index' => $index,
                    'previous' => is_array($previous) ? $previous : null,
                    'results' => $results,
                );
                $result = dmd_actionhub_execute($email, $moduleId, $actionId, null, $payload, $runtime);
            }

            $results[] = array(
                'index' => $index,
                'step_id' => (string)($step['id'] ?? ('step_' . ($index + 1))),
                'module' => $moduleId,
                'action_id' => $actionId,
                'label' => (string)$action['label'],
                'ok' => !empty($result['ok']),
                'message' => (string)($result['message'] ?? ''),
                'data' => isset($result['data']) && is_array($result['data']) ? $result['data'] : array(),
            );

            if (empty($result['ok'])) {
                $allOk = false;
                break;
            }
        }

        $scenario['last_run_at'] = time();
        $scenario['last_run_at_iso'] = date('c', $scenario['last_run_at']);
        $scenario['last_run_ok'] = $allOk;
        dmd_actionhub_write_json($file, $scenario);

        return array(
            'ok' => $allOk,
            'error' => $allOk ? '' : 'scenario_failed',
            'message' => $allOk
                ? 'Scénario exécuté avec succès.'
                : 'Le scénario s’est arrêté sur une étape en erreur.',
            'scenario' => array(
                'id' => (string)$scenario['id'],
                'name' => (string)$scenario['name'],
            ),
            'workspace' => isset($scenario['workspace']) && is_array($scenario['workspace'])
                ? $scenario['workspace']
                : array('create_dashboard' => false, 'dashboard_name' => ''),
            'results' => $results,
        );
    }
}
