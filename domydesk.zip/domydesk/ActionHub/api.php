<?php
require_once dirname(__DIR__) . '/dmd_runtime.php';

$email = dmd_api_require_user();
if (!dmd_ui_tool_api_allowed('actionhub', $email)) {
    dmd_json_response(array(
        'ok' => false,
        'error' => 'service_disabled',
        'message' => 'ActionHub est désactivé par l’administrateur.',
    ), 403);
}
$action = strtolower(trim((string)(isset($_GET['action']) ? $_GET['action'] : 'status')));

if ($action === 'status') {
    dmd_json_response(array(
        'ok' => true,
        'service' => 'ActionHub',
        'version' => 2,
        'resources' => count(dmd_actionhub_recent_resources($email, 250)),
        'scenarios' => count(dmd_actionhub_scenarios($email, '')),
    ));
}

if ($action === 'resources') {
    dmd_api_require_method('GET');
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 80;
    dmd_json_response(array('ok' => true, 'resources' => dmd_actionhub_recent_resources($email, max(1, min(150, $limit)))));
}

if ($action === 'trash_users') {
    dmd_api_require_method('GET');
    $result = dmd_actionhub_trash_users($email);
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'superadmin_required' ? 403 : 400));
}

if ($action === 'trash_items') {
    dmd_api_require_method('GET');
    $owner = isset($_GET['user']) ? (string)$_GET['user'] : '';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 250;
    $result = dmd_actionhub_trash_items($email, $owner, max(1, min(500, $limit)));
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'superadmin_required' ? 403 : 400));
}


if ($action === 'scenarios') {
    dmd_api_require_method('GET');
    $query = isset($_GET['q']) ? (string)$_GET['q'] : '';
    dmd_json_response(array(
        'ok' => true,
        'scenarios' => dmd_actionhub_scenarios($email, $query),
    ));
}

if ($action === 'scenario_catalog') {
    dmd_api_require_method('GET');
    dmd_json_response(array(
        'ok' => true,
        'catalog' => dmd_actionhub_scenario_catalog($email),
        'users' => dmd_actionhub_user_catalog($email),
    ));
}

if ($action === 'resource_actions') {
    dmd_api_require_method('POST');
    $payload = dmd_json_body(array());
    dmd_api_require_csrf('actionhub', $payload);
    $context = isset($payload['context']) && is_array($payload['context']) ? $payload['context'] : array();
    dmd_json_response(array('ok' => true, 'actions' => dmd_actionhub_actions_for_resource($email, $context)));
}

if ($action === 'execute') {
    dmd_api_require_method('POST');
    $payload = dmd_json_body(array());
    dmd_api_require_csrf('actionhub', $payload);
    $result = dmd_actionhub_execute(
        $email,
        isset($payload['module']) ? $payload['module'] : '',
        isset($payload['action_id']) ? $payload['action_id'] : '',
        isset($payload['resource']) && is_array($payload['resource']) ? $payload['resource'] : array(),
        isset($payload['payload']) && is_array($payload['payload']) ? $payload['payload'] : array()
    );
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'permission_denied' ? 403 : 400));
}

dmd_api_require_method('POST');
$payload = dmd_json_body(array());
dmd_api_require_csrf('actionhub', $payload);


if ($action === 'resource_forget') {
    $resource = isset($payload['resource']) && is_array($payload['resource']) ? $payload['resource'] : array();
    $result = dmd_actionhub_forget_resource($email, $resource);
    dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
}

if ($action === 'resources_forget') {
    $resources = isset($payload['resources']) && is_array($payload['resources']) ? $payload['resources'] : array();
    if (count($resources) > 250) $resources = array_slice($resources, 0, 250);
    $removed = 0; $errors = array();
    foreach ($resources as $resource) {
        if (!is_array($resource)) continue;
        $result = dmd_actionhub_forget_resource($email, $resource);
        if (!empty($result['ok'])) $removed++;
        else $errors[] = isset($result['error']) ? (string)$result['error'] : 'remove_failed';
    }
    dmd_json_response(array('ok' => empty($errors), 'removed' => $removed, 'errors' => $errors), empty($errors) ? 200 : 400);
}

if ($action === 'trash_empty') {
    $owner = isset($payload['user']) ? (string)$payload['user'] : '';
    $result = dmd_actionhub_trash_empty($email, $owner);
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'superadmin_required' ? 403 : 400));
}

if ($action === 'scenario_save') {
    $scenario = isset($payload['scenario']) && is_array($payload['scenario']) ? $payload['scenario'] : array();
    $result = dmd_actionhub_scenario_save($email, $scenario);
    dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
}

if ($action === 'scenario_delete') {
    $result = dmd_actionhub_scenario_delete($email, isset($payload['id']) ? $payload['id'] : '');
    dmd_json_response($result, !empty($result['ok']) ? 200 : 404);
}


if ($action === 'scenario_interaction') {
    $result = dmd_actionhub_scenario_interaction(
        $email,
        isset($payload['id']) ? $payload['id'] : '',
        isset($payload['module']) ? $payload['module'] : '',
        isset($payload['action_id']) ? $payload['action_id'] : '',
        isset($payload['values']) && is_array($payload['values']) ? $payload['values'] : array()
    );
    $status = !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'permission_denied' ? 403 : 400);
    dmd_json_response($result, $status);
}

if ($action === 'scenario_execute') {
    $result = dmd_actionhub_scenario_execute($email, isset($payload['id']) ? $payload['id'] : '');
    $status = !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'permission_denied' ? 403 : 400);
    dmd_json_response($result, $status);
}

if ($action === 'authorize') {
    $checks = isset($payload['checks']) && is_array($payload['checks']) ? $payload['checks'] : array();
    dmd_json_response(array('ok' => true, 'allowed' => dmd_actionhub_authorize_checks($email, $checks)));
}

if ($action === 'procedures') {
    $context = isset($payload['context']) && is_array($payload['context']) ? $payload['context'] : null;
    if (!dmd_actionhub_normalize_resource($context)) {
        dmd_json_response(array('ok' => false, 'error' => 'invalid_context'), 400);
    }
    dmd_json_response(array('ok' => true, 'procedures' => dmd_actionhub_procedure_suggestions($email, $context, 5)));
}

dmd_json_response(array('ok' => false, 'error' => 'unknown_action'), 400);
